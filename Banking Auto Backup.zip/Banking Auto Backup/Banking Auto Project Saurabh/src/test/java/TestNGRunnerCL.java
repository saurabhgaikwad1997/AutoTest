import com.selenium.utillity.TestNGCucumberExecutable;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = {"src/Feature"},
        glue = {"com.cucumber.stepdefinition"}
        /*      format = {"pretty",
                      "html:target/site/cucumber-pretty","json:target/cucumber-reports/cucumber.json"*/
        ,




        // Sanity tags= Banking_SanityNew_UAT,Banking_SanityNew_SIT,Banking_SanityNew_Prod
        //12 Tags={"@B2B_Part_1,@B2B_Part_2,@BNK_Part_1,@BNK_Part_2,@BNK_Part_3,@BNK_FxConfirmation,@BNK_Message,@PM_Part_1,@PM_Part_2,@QM_Part_1,@QM_Part_2,@BNK_RFQ"}
        //tags = {"@B2B_03,@BNK_124,@BNK_115,@BNK_107,@BNK_125,@BNK_135,@BNK_137,@BNK_138,@BNK_177,@BNK_136"},//BNK_137
        //tags = {"@BNK_04,@BNK_05,@BNK_09,@BNK_10,@BNK_12,@BNK_37,@BNK_34,@BNK_25,@BNK_47,@BNK_48,@BNK_41,@BNK_40"}, @BNK_119,@BNK_135,@BNK_136,BNK_69
        //Banking_Locally_1, JPM_Payment_In, Payment_In_CAMT54_52_53
//        @RR_22.1



//        tags = {"@Payment_In_CAMT52_ROF_Accept, @Payment_In_CAMT52_ROF_Reject, @Payment_In_CAMT52_ROF_DuplicateReject"},


        tags = {"@PayIn_JPMG_RemitterDetails_06"},


        //tags ={"@QM_05,@QM_08,@BNK_QueryManagement_QM_29,@QM_19,@QM_20,@QM_24,@QM_33,@QM_02,@QM_03"},
        //tags = {"@BNK_38,@BNK_04,@BNK_37,@BNK_27,@BNK_28,@BNK_34,@BNK_31,@BNK_47,@BNK_48,@BNK-54,@BNK_Banking_HAD-26,@BNK_43,@BNK_03"},







        plugin = {"pretty", "html:target/site/cucumber-pretty", "json:target/cucumber-reports/cucumber.json", "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/ExtentReport.html"},
        //plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/Extentreport.html", "json:target/cucumber-reports/cucumber.json"},
        monochrome = true)
//AbstractTestNGCucumberTests
public class TestNGRunnerCL extends TestNGCucumberExecutable {
}