package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;
import com.utility.LogCapture;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.apache.commons.lang.RandomStringUtils;
import org.testng.Assert;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.selenium.utillity.Constants.*;
import static java.lang.String.valueOf;


public class API {
    public String RandomNumber;
    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for (Atlas|Enterprise|Banking)$")
    public void forACallUserCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String enviroment, String App) throws Throwable {
//Constants.APIkey.checkNotEnabled(testCaseID);
        Constants.TCCaseID = testCaseID;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }


    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\"$")
    public void userValidateResponseCodeAndResponseDescription(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("responseDescription")));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @Then("^User validate response code \"([^\"]*)\"$")
    public void userValidateResponseCode(String arg0) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        System.out.println(jp);
        LogCapture.info("----------------Response Validations Ended-------------------");

    }


    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Banking \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForBanking(String methodType, String statCode, String testCaseID, String Environment, String customerType, String Currency, String legal_entity, String BeneAccount_no, String country_code, String BenefType, String PreferredPaymentType) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<customerType>",customerType);
        DynamicValue.put("<Currency>",Currency);
        DynamicValue.put("<legal_entity>",legal_entity);
        if(Objects.equals(BeneAccount_no1, "000")){
            BeneAccount_no1=RandomStringUtils.randomNumeric(11);
            BeneAccount_no1=BeneAccount_no1.startsWith("0") ? BeneAccount_no1.substring(1) : BeneAccount_no1;
        }

        DynamicValue.put("<BeneAccount_no>",Constants.BeneAccount_no1);
        DynamicValue.put("<country_code>",country_code);
        DynamicValue.put("<BenefType>",BenefType);
        DynamicValue.put("<PreferredPaymentType>",PreferredPaymentType);

//      DynamicValue.put("<methodType>",methodType);
        LogCapture.info("----------------Started API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info(jp+"---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        Assert.assertFalse(RESPONSE.contains("null"));
        String external_reference_id=RESPONSE.split(":")[3].split("}")[0];
        LogCapture.info("ID =" + external_reference_id);
        Constants.ID=external_reference_id;
        Constants.Kafka_ID=external_reference_id;
    }

    @And("^Check (BARC|RBS|Yes|JPMG|CITI|AIP) for Extra Values \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void checkForExtraValues(String Data,String Organization, String customer_country_code, String sub_category, String charge_type, String Priority, String BIC_CODE, String purpose_of_transaction) throws Throwable {
        DynamicValue.put("<BIC_CODE>", BIC_CODE);
        Map<String, String> result = Reusables.getSqlQueryResult("TIPaymentDetail_GlobalRef");
        int value = Integer.parseInt(result.get("global_reference_id"));
        value += 1;
        globalreferenceid = String.valueOf(value);
        DynamicValue.put("<globalreferenceid>", globalreferenceid);
        if (Data.equalsIgnoreCase("BARC")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<customer_country_code>", customer_country_code);
            DynamicValue.put("<sub_category>", sub_category);
            DynamicValue.put("<charge_type>", charge_type);
            DynamicValue.put("<Priority>", Priority);
        }
        if (Data.equalsIgnoreCase("RBS")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("Yes")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("CITI")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("AIP")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("JPMG")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<Priority>", Priority);
            DynamicValue.put("<purpose_of_transaction>", purpose_of_transaction);
        }
    }

    // Added by Omkar
    @And("^Check (Yes|JPMG|BARC|RBS) for Extra Values \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void checkYesForExtraValues(String Data,String Organization, String customer_country_code, String sub_category, String charge_type, String Priority, String BIC_CODE, String remittance_information, String ordering_customer_name, String beneficiary_name) throws Throwable {
        DynamicValue.put("<BIC_CODE>", BIC_CODE);
        Map<String, String> result = Reusables.getSqlQueryResult("TIPaymentDetail_GlobalRef");
        int value = Integer.parseInt(result.get("global_reference_id"));
        value += 1;
        globalreferenceid = String.valueOf(value);
        DynamicValue.put("<globalreferenceid>", globalreferenceid);
        if (Data.equalsIgnoreCase("BARC")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<customer_country_code>", customer_country_code);
            DynamicValue.put("<sub_category>", sub_category);
            DynamicValue.put("<charge_type>", charge_type);
            DynamicValue.put("<Priority>", Priority);
        }
        if (Data.equalsIgnoreCase("RBS")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<remittance_information>", remittance_information);

        }
        if (Data.equalsIgnoreCase("Yes")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<remittance_information>", remittance_information);
            DynamicValue.put("<ordering_customer_name>", ordering_customer_name);
            DynamicValue.put("<beneficiary_name>", beneficiary_name);
        }
        if (Data.equalsIgnoreCase("CITI")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("AIP")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("JPMG")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<Priority>", Priority);
        }
    }
    @Given("^User adding new bank with help of API For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment$")
    public void userAddingNewBankWithHelpOfAPIForACallUserCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String Environment) throws Throwable {
        LogCapture.info("----------------Started API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        String BankName = "test"+RandomStringUtils.randomNumeric(7);
        //Constants.BankName1=BankName;
        DynamicValue.put("<BankName>", BankName);
        if (methodType.equalsIgnoreCase("POST")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            Assert.assertTrue(true, String.valueOf(Constants.RESPONSE.contains("Success")));
//            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info(jp+"---------------POST call ended----------------");
//            Assert.assertFalse(RESPONSE.contains("null"));
            String NewBankId=RESPONSE.split(":")[7].split("\"")[0].trim();
            LogCapture.info("New Bank Added with Id =" + NewBankId);
            Constants.ID=NewBankId;

        } else if (methodType.equalsIgnoreCase("PostDelete")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info(jp+"---------------POSTDelete call ended----------------");
        }
        LogCapture.info("----------------Ended API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @When("^User deleting new bank with help of API For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment$")
    public void userDeletingNewBankWithHelpOfAPIForACallUserCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String Environment) throws Throwable {
        LogCapture.info("----------------Started API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        String BankName = "test"+RandomStringUtils.randomNumeric(7);
        //Constants.BankName1=BankName;
        DynamicValue.put("<ID>", ID);

        if (methodType.equalsIgnoreCase("POST")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            Assert.assertEquals("PASS",Constants.RESPONSE.contains("Success"));
            Assert.assertTrue(true, String.valueOf(Constants.RESPONSE.contains("Success")));
//            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info(jp+"---------------POST call ended----------------");

        }else if (methodType.equalsIgnoreCase("GET")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            Assert.assertTrue(true, String.valueOf(Constants.RESPONSE.contains("Success")));
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info(jp+"---------------GET call started----------------");

        };
    }

    @When("^For a \"([^\"]*)\" call user generates messageIn and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void forACallUserGeneratesMessageInAndCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String Environment, String Bank, String msg_type, String msg_ID, String queue_Name, String message_No) throws Throwable {
        key.pause("7","");
        Constants.message_No=message_No;
        Constants.TCCaseID=testCaseID;
        Constants.SHEET_NAME=Environment;
        DateTimeFormatter date=DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime today=LocalDateTime.now();
        String nameDate=date.format(today);
        String destinationPath ="";
        if(msg_type.equalsIgnoreCase("002.001.03")) {
            destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/psr/" + nameDate + "/" + NewFileName;
        }else{
            destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/camt/" + nameDate + "/" + NewFileName;
        }
        DynamicValue.put("<destinationPath>", destinationPath);
        DynamicValue.put("<msg_type>", msg_type);
        DynamicValue.put("<msg_ID>", msg_ID);
        DynamicValue.put("<queue_Name>", queue_Name);
        DynamicValue.put("<message_No>", message_No);

        LogCapture.info("---------------POST call started----------------");
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        LogCapture.info(jp+"---------------POST call ended----------------");
        Assert.assertFalse(RESPONSE.contains("null"));
        String external_reference_id=RESPONSE.split(":")[3].split("}")[0];
        LogCapture.info("MessageInId for "+message_No+" is: " + external_reference_id);

//        Constants.MessageInId=external_reference_id;
        MessageInIdMap.put("MessageInId for "+message_No,external_reference_id);
    }


    @And("^Check (BARC|RBS|Yes|JPMG|CITI|AIP) for Extra Values \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void checkJPMGForExtraValues(String Data,String Organization, String customer_country_code, String sub_category, String charge_type, String Priority, String BIC_CODE, String purpose_of_transaction) throws Throwable {
        DynamicValue.put("<BIC_CODE>", BIC_CODE);
        Map<String, String> result = Reusables.getSqlQueryResult("TIPaymentDetail_GlobalRef");
        int value = Integer.parseInt(result.get("global_reference_id"));
        value += 1;
        globalreferenceid = String.valueOf(value);
        DynamicValue.put("<globalreferenceid>", globalreferenceid);
        if (Data.equalsIgnoreCase("BARC")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<customer_country_code>", customer_country_code);
            DynamicValue.put("<sub_category>", sub_category);
            DynamicValue.put("<charge_type>", charge_type);
            DynamicValue.put("<Priority>", Priority);
        }
        if (Data.equalsIgnoreCase("RBS")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<purpose_of_transaction>", purpose_of_transaction);
        }
        if (Data.equalsIgnoreCase("Yes")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<purpose_of_transaction>", purpose_of_transaction);
        }
        if (Data.equalsIgnoreCase("CITI")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("AIP")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("JPMG")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<Priority>", Priority);
            DynamicValue.put("<purpose_of_transaction>", purpose_of_transaction);
        }
    }

    @Given("^User Generate (new|wrong|Existing) ClientAccountKey for VBAN Request for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userGenerateNewClientAccountKeyForVBANRequestForOn(String menu,String Currency, String Environment) throws Throwable {
        if (menu.equalsIgnoreCase("new")) {
            RandomNumber = RandomStringUtils.randomNumeric(16);
            RandomNumber = RandomNumber.startsWith("0") ? RandomNumber.substring(1) : RandomNumber;
            ClientAccountKey = RandomNumber;
        }else if (menu.equalsIgnoreCase("wrong")) {
            RandomNumber = RandomStringUtils.randomNumeric(14);
            RandomNumber = RandomNumber.startsWith("0") ? RandomNumber.substring(1) : RandomNumber;
            ClientAccountKey = RandomNumber;
        }else if (menu.equalsIgnoreCase("Existing")) {
            Map<String, String> auditRecord = ReusableMethod.getSqlQueryResult("VBANRequest_CR", Environment, "ACCP");
            ClientAccountKey = auditRecord.get("ordering_customer_no");
            LogCapture.info("Value of ClientAccountKey: " + ClientAccountKey);
            Assert.assertFalse(ClientAccountKey.contains("null"));
        }
        DynamicValue.put("<ClientAccountKey>",ClientAccountKey);
        String newTransactionReference=ClientAccountKey + "-" + Currency;
        Constants.TransactionReferenceNumber=newTransactionReference;
        DynamicValue.put("<TransactionReferenceNumber>",TransactionReferenceNumber);
        LogCapture.info("New Transaction Reference Number : " + newTransactionReference);
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now=LocalDateTime.now();
        String currentDate=dtf.format(now);
        DynamicValue.put("<currentDate>",currentDate);
        DynamicValue.put("<Currency>",Currency);
    }

    @When("^For VBAN Request a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Banking \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void forVBANRequestACallUserCheckStatusCodeAsForOnEnvironmentForBanking(String methodType, String statCode, String testCaseID, String Environment,String Source, String Organization, String legal_entity, String LicensedState, String Product) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<Source>",Source);
        DynamicValue.put("<Organization>",Organization);
        DynamicValue.put("<legal_entity>",legal_entity);
        DynamicValue.put("<LicensedState>",LicensedState);
        DynamicValue.put("<Product>",Product);

        LogCapture.info("----------------Started API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        LogCapture.info("---------------POST call started----------------");
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        LogCapture.info(jp+"---------------POST call ended----------------");
    }

    @Then("^User validate response code \"([^\"]*)\" for Error code \"([^\"]*)\"$")
    public void userValidateResponseCodeForErrorCode(String code,String ErrorCode) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        System.out.println(jp);
        String response_code=RESPONSE.split(":")[1].split(",")[0];
        LogCapture.info("response_code for is: " + response_code);
        Assert.assertTrue(true, valueOf(response_code.contains(ErrorCode)));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Given("^User Request a \"([^\"]*)\" call to close VBAN wallet for \"([^\"]*)\" and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Banking \"([^\"]*)\"\"([^\"]*)\"$")
    public void userRequestACallToCloseVBANWalletForAndCheckStatusCodeAsForOnEnvironmentForBanking(String methodType, String Currency, String statCode, String testCaseID, String Environment,String Source, String Organization) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<Source>",Source);
        DynamicValue.put("<Organization>",Organization);
        DynamicValue.put("<ClientAccountKey>",ClientAccountKey);
        DynamicValue.put("<TransactionReferenceNumber>",TransactionReferenceNumber);
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now=LocalDateTime.now();
        String currentDate=dtf.format(now);
        DynamicValue.put("<currentDate>",currentDate);
        DynamicValue.put("<Currency>",Currency);
        DynamicValue.put("<VirtualAccountNumber>",VirtualAccountNumber);
        DynamicValue.put("<VirtualAccountIdentificationCode>",VirtualAccountIdentificationCode);

        LogCapture.info("----------------Started API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        LogCapture.info("---------------POST call started----------------");
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        LogCapture.info(jp+"---------------POST call ended----------------");
    }
}
