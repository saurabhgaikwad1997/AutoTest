package com.cucumber.stepdefinition;
import com.google.gson.Gson;
import com.selenium.utillity.Reusables;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;

//import com.sun.org.apache.bcel.internal.Const;
import cucumber.api.PendingException;
import io.restassured.RestAssured;
import com.jcraft.jsch.*;
import com.selenium.utillity.Constants;
import org.json.JSONObject;
import com.utility.LogCapture;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.velocity.runtime.directive.Break;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;

import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.util.*;

//import static com.selenium.utillity.Constants.TradeContractNumber;
//import static com.selenium.utillity.Reusables.pressEnter;
//import static com.selenium.utillity.Reusables.typeCommand;
import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.Constants.hyperion_reference_id;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import static io.restassured.RestAssured.config;
import static io.restassured.RestAssured.given;
import static java.lang.String.valueOf;

import java.time.LocalDate;

import java.io.File;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import org.openqa.selenium.chrome.ChromeOptions;

public class BankingStepDefinition {

    public Float SpotRate;
    public Float SellAmountValue;
    public String ValueDate;
    public String ActualSpot;
    public Integer ActualBuyCurrValue;
    public Integer BuyAmountValue1;
    public String PaymentApprovalRecordID;
    public String SecondPaymentApprovalRecordID;
    public String PaymentID;
    public String RandomNumber;
    public String SafeModeValue;
    public List<String> MultiPaymentID;
    public String QueryID;
    public String RelatedReference;
    public String TransactionReference;
    public String QueryIdValue;
    public String QueryID2;
    public String FilePath;
    public String CurrencyPosition;
    static boolean isKafkaLaunched;
    public String BankRef;
    ArrayList<Double> amountsList = new ArrayList<>();

    @Given("^User launched application through \"([^\"]*)\" browser$")
    public void userLaunchedApplicationThrough(String data) throws Throwable {

        LogCapture.info(data + " Application is launching....");
        String vBrowserName = Constants.CONFIG.getProperty("browser");
        try {
            if (Objects.equals(Constants.JenkinsBrowser, null)) {
                Constants.JenkinsBrowser = "";
            } else if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                vBrowserName = Constants.JenkinsBrowser;
                LogCapture.info("Browser is :" + Constants.JenkinsBrowser);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));

    }


    @Given("^User launched Incognito browser through \"([^\"]*)\" browser$")
    public void userLaunchedApplicationThroughIncognitoBrowser(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        String vBrowserName = Constants.CONFIG.getProperty("browser");

        try {
            if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                vBrowserName = Constants.JenkinsBrowser;
                LogCapture.info("Browser is :" + vBrowserName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));
        LogCapture.info("Browser is :" + vBrowserName);
    }


    @And("^User navigate to Banking Application \"([^\"]*)\"$")
    public void userNavigateToBankingApplication(String vUrl) throws Exception {
        LogCapture.info("Banking Portal is loading....");

        String url = Constants.CONFIG.getProperty(vUrl);
        System.out.println("URLLInk:-> " + url);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
    }

    @When("^User enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click log In button on Banking Application$")
    public void userEnterUserNamePasswordAndClickLogInButtonOnBankingApplication(String userName, String password) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.B2BOR.getProperty("Banking_Username");
        String vObjPass = Constants.B2BOR.getProperty("Banking_Password");

        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));

        String vObjLoginButton = Constants.B2BOR.getProperty("Banking_LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));

    }


    @Then("^User successfully landed on (TradingDashboardReport|DashBoard|Swapdeal|LimitDeal|BlotterReport|SpotDeal|Banking Dashboard|Banking Home|Spot Forward Deal|Swap Deal|AllTrade|MyTrade|TodayTrade|LiveTrade|PotentialDuplicateQueue|Account Balance|Balance Exception|Balance Entry|Bank Account|FXConfirmation Entries|Limit Deal|ROF Queue) page$")
    public void userShouldNavigateToTradingDashboardReportHomeScreen(String data) throws Exception {
        key.pause("6", "");
        if (data.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("Trading dashboard screen loading ......");

            String vObjAllTrade = Constants.B2BOR.getProperty("B2B_TradingDashboard_Alltrade");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjAllTrade, "All Trade"));
            String vObjMyTrade = Constants.B2BOR.getProperty("B2B_TradingDashboard_Mytrade");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMyTrade, "My Trade"));
            String vObjTodayTrade = Constants.B2BOR.getProperty("B2B_TradingDashboard_Todaytrade");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTodayTrade, "Today Trade"));
            String vObjLiveTrade = Constants.B2BOR.getProperty("B2B_TradingDashboard_Livetrade");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjLiveTrade, "Live Trade(Limit Order)"));

        }
        if (data.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Trading dashboard screen loading ......");
            String vObjOrganization = Constants.B2BOR.getProperty("B2B_BlotterReport_Organization");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjOrganization, "Organization:"));
            String vObjTreasureCategory = Constants.B2BOR.getProperty("B2B_BlotterReport_TreasuryCategory");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTreasureCategory, "Treasury Category"));

        }
        if (data.equalsIgnoreCase("Banking Dashboard")) {
            LogCapture.info("Dashboard loading ......");
            String vobjectDashboard = Constants.B2BOR.getProperty("Banking_Dashboard");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Banking Accounts"));
        }
        if (data.equalsIgnoreCase("Banking Home")) {
            LogCapture.info("Banking Home Page loading ......");

            String vobjectDashboard = Constants.B2BOR.getProperty("Banking_Dashboard");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Banking Accounts"));

        }
        if (data.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("Dashboard Page loading ......");

            String vObjectB2BPage = Constants.B2BOR.getProperty("B2BPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectB2BPage, ""));
            //Assert.assertEquals("PASS", Constants.key.verifyText(vObjectB2BPage, "Banking Accounts"));

        }
        if (data.equalsIgnoreCase("Spot Forward Deal")) {
            LogCapture.info("Spot Forward Deal Page loading ......");

            String vObjSpotDealBooing = Constants.B2BOR.getProperty("SpotDealBooking");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooing, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjSpotDealBooing, "Spot deal booking"));

        }
        if (data.equalsIgnoreCase("Swap Deal")) {
            LogCapture.info("Swap Deal Page loading ......");

            String vObjSwapDeal_Text = Constants.B2BOR.getProperty("SwapDeal_Text");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_Text, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjSwapDeal_Text, "Book swap deal"));

        }
        if (data.equalsIgnoreCase("AllTrade") || data.equalsIgnoreCase("MyTrade") || data.equalsIgnoreCase("TodayTrade")) {
            String vObjTradeData = Constants.B2BOR.getProperty("B2B_TradingDashboard_Trade_count");
            Assert.assertNotEquals("PASS", vObjTradeData, "0");
        }
        if (data.equalsIgnoreCase("PotentialDuplicateQueue")) {

            String vObjBankingMenu_DuplicateQueue = Constants.BankingOR.getProperty("BankingMenu_DuplicateQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_DuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBankingMenu_DuplicateQueue, "Duplicate Queue"));


        }
        if (data.equalsIgnoreCase("ROF Queue")) {
            LogCapture.info("User Click on ROF Queue ......");
            String vObjBankingMenu_ROFQueue = Constants.BankingOR.getProperty("BankingMenu_ROFQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_ROFQueue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBankingMenu_ROFQueue, "ROF Queue"));
            LogCapture.info("User Clicked on ROF Queue and ROF Queue is opened......");

        }
        if (data.equalsIgnoreCase("Account Balance")) {

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjBnkOpeningAccBalance = Constants.BankingOR.getProperty("BNK_AccountBalance_OpeningBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBnkOpeningAccBalance, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBnkOpeningAccBalance, "OpeningBalance"));
            String vObjBnkClosingAccBalance = Constants.BankingOR.getProperty("BNK_AccountBalance_ClosingBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBnkClosingAccBalance, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBnkClosingAccBalance, "ClosingBalance"));

        }
        if (data.equalsIgnoreCase("Balance Exception")) {

            String vObjBnkOpeningAccBalance = Constants.BankingOR.getProperty("BNK_BalanceException_OpeningBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBnkOpeningAccBalance, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBnkOpeningAccBalance, "OpeningBalance"));
            String vObjBnkClosingAccBalance = Constants.BankingOR.getProperty("BNK_BalanceException_ClosingBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBnkClosingAccBalance, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBnkClosingAccBalance, "ClosingBalance"));

        }
        if (data.equalsIgnoreCase("Balance Entry")) {

            String vObjBalanceEntry_Table = Constants.BankingOR.getProperty("BalanceEntry_Table");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBalanceEntry_Table, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjBalanceEntry_Table, ""));

        }

        if (data.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("Bank Account Page loading ......");

            String vObjBankAccountTable = Constants.BankingOR.getProperty("BNK_BankAccountTableID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankAccountTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjBankAccountTable, ""));

        }
        if (data.equalsIgnoreCase("FXConfirmation Entries")) {
            LogCapture.info("FXConfirmation Entries Page loading ......");

            String vObjInstitutionColumnHeader = Constants.FXConfirmationOR.getProperty("InstitutionColumnHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstitutionColumnHeader, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjInstitutionColumnHeader, ""));
            String vObjSendersReferenceColumnHeader = Constants.FXConfirmationOR.getProperty("SendersReferenceColumnHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendersReferenceColumnHeader, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjSendersReferenceColumnHeader, ""));
            String URL = Constants.key.getPageURL("", "");
            String vObjFXConfirmationEntriesPage = Constants.FXConfirmationOR.getProperty("FXCorimationPage");
            Assert.assertEquals("PASS", Constants.key.VerifySubstring(URL, vObjFXConfirmationEntriesPage));

        }
        if (data.equalsIgnoreCase("Limit Deal")) {
            LogCapture.info("Dashboard loading ......");

            String vB2B_LimitDealText = Constants.B2BOR.getProperty("B2B_LimitDealText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2B_LimitDealText, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vB2B_LimitDealText, "Limit deal booking"));

        }
    }

    @And("^User click on (AllTrade|MyTrade|TodayTrade|LiveTrade) icon$")
    public void userNavigateToAllTradeIcon(String value) throws Exception {
        if (value.equalsIgnoreCase("AllTrade")) {
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjAlltrade = Constants.B2BOR.getProperty("B2B_TradingDashboard_Alltrade");
            WebElement ele = Constants.driver.findElement(By.xpath(vObjAlltrade));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        }
        if (value.equalsIgnoreCase("MyTrade")) {
            String vObjMytrade = Constants.B2BOR.getProperty("B2B_TradingDashboard_Mytrade");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMytrade, ""));
            // Assert.assertEquals("PASS", Constants.key.click(vObjMytrade, ""));
            WebElement ele = Constants.driver.findElement(By.xpath(vObjMytrade));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        }
        if (value.equalsIgnoreCase("TodayTrade")) {
            String vObjTodaytrade = Constants.B2BOR.getProperty("B2B_TradingDashboard_Todaytrade");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTodaytrade, ""));
            //Assert.assertEquals("PASS", Constants.key.click(vObjTodaytrade, ""));
            WebElement ele = Constants.driver.findElement(By.xpath(vObjTodaytrade));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        }
    }

    @And("^User click on (OrgName|Sell Amount) from (Pending B2B Deals) page$")
    public void userClickOnB2BDealsColumns(String Value, String Menu) throws Throwable {
        if (Value.equalsIgnoreCase("OrgName") && Menu.equalsIgnoreCase("Pending B2B Deals")) {
            LogCapture.info("User Click on Org Name ......");

            String vObjOrgName = Constants.B2BOR.getProperty("B2B_PendingB2BDeals_OrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrgName, ""));

        } else if (Value.equalsIgnoreCase("Sell Amount") && Menu.equalsIgnoreCase("Pending B2B Deals")) {
            LogCapture.info("User Click on Sell Amount ......");

            String vObjSellAmount = Constants.B2BOR.getProperty("B2B_PendingB2BDeals_SellAmount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSellAmount, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSellAmount, ""));

        }
    }

    @When("^User click on (Reset Filter1|FXConfirmation Entries|FXConfirmation|B2B|Dashboard|Spot Forward Deal|TradingDashBoardReport|BlotterReport|Swap Deal|Banking|Potential Duplicate Queue|RFQ|Event Log|Organization Details|Opening Closing|OrgCurrency Details|One Time Configurable|Rule Engine|Pending B2B Deals|CounterParty|Account Balance|Balance Exception|Balance Entry|Payment Monitoring|Payment Approval|Rejected Payment List|Bank Account|Message|Message Out|Failed Payment Out|Query Management|Queries|Manual Payment Upload|Manual PSR Upload|FX Confirmation|Limit Deal|ROF Queue) Menu from (Dashboard|B2B|Banking|RFQ|Payment Monitoring|Message|Query Management|FXConfirmation)$")
    public void userClickOnBBMenuFromDashboard(String MainMenu, String SubMenu) throws Exception {
        key.pause("10", "");
        if (MainMenu.equalsIgnoreCase("B2B") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on B2B Menu ......");

            //String vPageLoader=Constants.BankingOR.getProperty("Banking_PageLoader");
            //Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjectB2BMenu = Constants.B2BOR.getProperty("B2BMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectB2BMenu, ""));
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vObjectB2BMenu, ""));
            key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjectB2BMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Dashboard") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Dashboard Menu from B2B ......");

            String vObjectB2B_Dashboard = Constants.B2BOR.getProperty("B2B_Dashboard");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectB2B_Dashboard, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectB2B_Dashboard, ""));


        } else if (MainMenu.equalsIgnoreCase("Spot Forward Deal") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Spot Forward Deal Menu from B2B ......");

            String vObjSpotForwadDeal = Constants.B2BOR.getProperty("SpotForwadDeal");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotForwadDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotForwadDeal, ""));


        } else if (MainMenu.equalsIgnoreCase("Swap Deal") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Swap Deal Menu from B2B ......");

            String vObjSwapDeal = Constants.B2BOR.getProperty("SwapDeal");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapDeal, ""));

        } else if (MainMenu.equalsIgnoreCase("TradingDashBoardReport") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Trading dashboard report Menu from B2B ......");

            String vObjTradingDashboardReport = Constants.B2BOR.getProperty("B2B_TradingDashboard");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTradingDashboardReport, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjTradingDashboardReport, ""));


        } else if (MainMenu.equalsIgnoreCase("BlotterReport") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Blotter report Menu from B2B ......");

            String vObjBlotterReport = Constants.B2BOR.getProperty("B2B_BlotterReport");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlotterReport, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBlotterReport, ""));


        } else if (MainMenu.equalsIgnoreCase("Trading Dash Board Report") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Trading Dash Board Report Menu from B2B ......");

            String vObjBlotterReport = Constants.B2BOR.getProperty("B2B_TrandingDashboardReport");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlotterReport, ""));


        } else if (MainMenu.equalsIgnoreCase("Banking") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Banking Menu from Dashboard ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjBanking_BankingMenu = Constants.BankingOR.getProperty("Banking_BankingMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBanking_BankingMenu, ""));
            key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjBanking_BankingMenu, ""));


        } else if (MainMenu.equalsIgnoreCase("Potential Duplicate Queue") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Potential Duplicate Queue Menu from Dashboard ......");

            String vObjBankingMenu_PotentialDuplicateQueue = Constants.BankingOR.getProperty("BankingMenu_PotentialDuplicateQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_PotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBankingMenu_PotentialDuplicateQueue, ""));


        } else if (MainMenu.equalsIgnoreCase("ROF Queue") && SubMenu.equalsIgnoreCase("Banking")) {
            key.pause("2", "");
            LogCapture.info("User Click on ROF Queue Menu from Dashboard 1......");
            key.pause("4", "");
            String vObjBankingMenu_ROF_Queue = Constants.BankingOR.getProperty("BankingMenu_ROF_Queue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_ROF_Queue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBankingMenu_ROF_Queue, ""));
            LogCapture.info("User Clicked on ROF Queue Menu from Dashboard ......");

        } else if (MainMenu.equalsIgnoreCase("RFQ") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on RFQ Menu ......");

            String vObjectRFQMenu = Constants.RFQOR.getProperty("RFQMenu");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectRFQMenu, ""));
            key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjectRFQMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Event Log") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Event Log Menu from RFQ ......");

            String vObjEventLog = Constants.RFQOR.getProperty("RFQ_EventLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEventLog, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjEventLog, ""));
        } else if (MainMenu.equalsIgnoreCase("Organization Details") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Organization details Menu from RFQ ......");

            String vObjOrganizationDetails = Constants.RFQOR.getProperty("RFQ_OrganizationDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganizationDetails, ""));

            Assert.assertEquals("PASS", Constants.key.ClickableConditionWait(vObjOrganizationDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrganizationDetails, ""));
        } else if (MainMenu.equalsIgnoreCase("Opening Closing") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Opening Closing Menu from RFQ ......");

            String vObjOpeningClosing = Constants.RFQOR.getProperty("RFQ_OpeningClosingDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOpeningClosing, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOpeningClosing, ""));
        } else if (MainMenu.equalsIgnoreCase("OrgCurrency Details") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on OrgCurrency Details Menu from RFQ ......");

            String vObjOrgCurrencyDetails = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrgCurrencyDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrgCurrencyDetails, ""));
        } else if (MainMenu.equalsIgnoreCase("One Time Configurable") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on One Time Configurable Menu from RFQ ......");

            String vObjOneTimeConfigurable = Constants.RFQOR.getProperty("RFQ_OneTimeConfigurableScheduler");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOneTimeConfigurable, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOneTimeConfigurable, ""));
        } else if (MainMenu.equalsIgnoreCase("Pending B2B Deals") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Pending B2B Deals Menu from RFQ ......");

            String vObjOPendingB2B = Constants.RFQOR.getProperty("RFQ_PendingB2BDeals");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOPendingB2B, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOPendingB2B, ""));
        }
        // CounterParty
        else if (MainMenu.equalsIgnoreCase("CounterParty") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on CounterParty Menu from RFQ ......");

            String vObjCounterParty = RFQOR.getProperty("RFQ_CounterParty");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCounterParty, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCounterParty, ""));
        }
        // CounterParty
        else if (MainMenu.equalsIgnoreCase("Rule Engine") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Rule Engine Menu from RFQ ......");
            key.pause("7", "");
            String vObjRuleEngine = Constants.RFQOR.getProperty("RFQ_RuleEngine");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRuleEngine, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjRuleEngine, ""));
        } else if (MainMenu.equalsIgnoreCase("Account Balance") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Account Balance Menu from Dashboard ......");

            String vObjBNKAccountBalance = Constants.BankingOR.getProperty("BNK_AccountBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNKAccountBalance, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBNKAccountBalance, ""));

        } else if (MainMenu.equalsIgnoreCase("Balance Exception") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Balance Exception Menu from Dashboard ......");

            String vObjBNKBalException = Constants.BankingOR.getProperty("BNK_BalanceException");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNKBalException, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBNKBalException, ""));

        } else if (MainMenu.equalsIgnoreCase("Balance Entry") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Balance Entry ......");

            String vObjBankingMenu_BalanceEntries = Constants.BankingOR.getProperty("BankingMenu_BalanceEntries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_BalanceEntries, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBankingMenu_BalanceEntries, ""));


        } else if (MainMenu.equalsIgnoreCase("Payment Monitoring") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Payment Monitoring Menu ......");

            String vObjectPaymentMonitoringMenu = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

            Assert.assertEquals("PASS", Constants.key.click(vObjectPaymentMonitoringMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Payment Approval") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Payment Approval ......");

            String vBanking_PaymentMonitoring_PaymentApproval = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_PaymentApproval");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_PaymentApproval, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_PaymentMonitoring_PaymentApproval, ""));

        } else if (MainMenu.equalsIgnoreCase("Payment Approval") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Payment Approval ......");

            String vBanking_RejectedPayment = Constants.PaymentMonitoringOR.getProperty("Banking_RejectedPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_RejectedPayment, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_RejectedPayment, ""));
        } else if (MainMenu.equalsIgnoreCase("Bank Account") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Bank Account Menu from Dashboard ......");

            String vObjBNKBankAccount = Constants.BankingOR.getProperty("BNK_BankAccount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNKBankAccount, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBNKBankAccount, ""));

        } else if (MainMenu.equalsIgnoreCase("Message") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Message Menu from Dashboard ......");

            String vBanking_Message = Constants.MessageOR.getProperty("Banking_Message");
            key.pause("6", "");
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vBanking_Message, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_Message, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_Message, ""));

        } else if (MainMenu.equalsIgnoreCase("Message Out") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Message Out Menu from Message ......");

            String vBanking_Message_MessageOut = Constants.MessageOR.getProperty("Banking_Message_MessageOut");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_Message_MessageOut, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_Message_MessageOut, ""));

        } else if (MainMenu.equalsIgnoreCase("Failed Payment Out") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Failed Payment Out from Dashboard ......");
            key.pause("4", "");
            String vBanking_Message_FailedPaymentOut = Constants.MessageOR.getProperty("Banking_Message_FailedPaymentOut");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_Message_FailedPaymentOut, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_Message_FailedPaymentOut, ""));

        } else if (MainMenu.equalsIgnoreCase("Payment Monitoring") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Payment Monitoring Menu from Dashboard ......");

            String vObjBanking_BankingMenu = Constants.BankingOR.getProperty("BNK_PaymentMonitoring");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBanking_BankingMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBanking_BankingMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Query Management") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Query Management Menu from Dashboard ......");

            String vQueryMgmt = Constants.QueryManagementOR.getProperty("BNK_QM");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueryMgmt, ""));
            key.pause("7", "");
            Assert.assertEquals("PASS", Constants.key.click(vQueryMgmt, ""));


        } else if (MainMenu.equalsIgnoreCase("Queries") && SubMenu.equalsIgnoreCase("Query Management")) {
            LogCapture.info("User Click on Queries Menu from Query Management ......");

            String vQueryMgmt_Queries = Constants.QueryManagementOR.getProperty("BNK_QM_Queries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueryMgmt_Queries, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQueryMgmt_Queries, ""));

        } else if (MainMenu.equalsIgnoreCase("Manual Payment Upload") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Manual Payment Upload from Message ......");

            String vBanking_ManualPaymentUpload = Constants.MessageOR.getProperty("Banking_ManualPaymentUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPaymentUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUpload, ""));
        } else if (MainMenu.equalsIgnoreCase("Manual PSR Upload") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Manual PSR Upload from Message ......");

            String vBanking_ManualPSRUpload = Constants.MessageOR.getProperty("Banking_ManualPSRUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPSRUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPSRUpload, ""));
        } else if (MainMenu.equalsIgnoreCase("FXConfirmation") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on FXConfirmation from Dashboard ......");

            String vObjFXConfirmationMenu = Constants.FXConfirmationOR.getProperty("FXConfirmationMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXConfirmationMenu, ""));
            key.pause("6", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjFXConfirmationMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("FXConfirmation Entries") && SubMenu.equalsIgnoreCase("FXConfirmation")) {
            LogCapture.info("User Click on FXConfirmation Entries Menu from FXConfirmation ......");

            String vObjFXConfirmationEntriesSubmenu = Constants.FXConfirmationOR.getProperty("FXConfirmationEntriesSubmenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXConfirmationEntriesSubmenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFXConfirmationEntriesSubmenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Message") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Message Menu from Dashboard ......");

            String vMessage = Constants.MessageOR.getProperty("BNK_Message");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMessage, ""));
            Assert.assertEquals("PASS", Constants.key.click(vMessage, ""));
        } else if (MainMenu.equalsIgnoreCase("Failed Payment Out") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Failed Payment Out Sub Menu from Message ......");

            String vMessage_FPO = Constants.MessageOR.getProperty("BNK_Message_FPO");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMessage_FPO, ""));
            Assert.assertEquals("PASS", Constants.key.click(vMessage_FPO, ""));

        } else if (MainMenu.equalsIgnoreCase("FX Confirmation") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on FX Confirmation Menu ......");

            String vFXConfirmation = Constants.FXConfirmationOR.getProperty("BNK_FXConfirmation");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFXConfirmation, ""));
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vFXConfirmation, ""));
            key.pause("6", "");
            Assert.assertEquals("PASS", Constants.key.click(vFXConfirmation, ""));

        } else if (MainMenu.equalsIgnoreCase("Limit Deal") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Limit Deal Menu ......");

            String vB2B_LimitDealMenu = Constants.B2BOR.getProperty("B2B_LimitDealMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2B_LimitDealMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vB2B_LimitDealMenu, ""));


        }

    }

    @And("^User click on (All Treasury deal) SubMenu from (FX Confirmation)$")
    public void userClickOnAllTreasuryDealSubMenuFromFXConfirmation(String SubMenu, String MainMenu) throws Throwable {
        if (SubMenu.equalsIgnoreCase("All Treasury deal") && MainMenu.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("User Click on All Treasury deal SubMenu from FX Confirmation ......");

            String vFXC_AllTreasuryDeal = Constants.FXConfirmationOR.getProperty("BNK_FXConfirmation_AllTreasuryDeal");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFXC_AllTreasuryDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFXC_AllTreasuryDeal, ""));

        }
    }


    @And("^User double click on the AddCurrency pair box$")
    public void userDoubleClickOnTheAddCurrencyPairBox() throws Exception {
        LogCapture.info("User Double Click on AddCurrency pair box ......");

        String vObjAddcurencyPairBox = Constants.B2BOR.getProperty("AddcurencyPairBox");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddcurencyPairBox, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjAddcurencyPairBox, "DoubleClick"));

    }

    @Then("^User Verify the Details of selected Account on Balance Entry page$")
    public void UserVerifyTheDetailsOfSelectedAccountOnBalanceEntryPage() throws Throwable {
        LogCapture.info("Selected Record Details is loading ......");

        String vSelectedAccount = Constants.CalypsologinPageOR.getProperty("BNK_BalanceEntries_DetailsOfSelectedRecord");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectedAccount, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSelectedAccount, "Details of selected Account"));
    }


    @And("^Verify the subscription is added successfully with specific provider \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyTheSubscriptionIsAddedSuccessfullyWithSpecificProviderAnd(String Sell, String Buy) throws Throwable {
        LogCapture.info("Verify the subscription is added successfully with specific provider ......");

        String vObjBarClaysProviderGBPINR = Constants.B2BOR.getProperty("BarClaysProviderGBPINR");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBarClaysProviderGBPINR, ""));


    }

    @And("^Verify the subscription is (added|deleted) successfully on the dashboard$")
    public void verifyTheSubscriptionIsAddedSuccessfullyOnTheDashboard(String Operation) throws Exception {
        if (Operation.equalsIgnoreCase("added")) {
            LogCapture.info("Verify the subscription is added successfully with specific provider ......");

            String vObjBarClaysProviderGBPAED = Constants.B2BOR.getProperty("BarClaysProviderGBPAED");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBarClaysProviderGBPAED, ""));
        } else if (Operation.equalsIgnoreCase("deleted")) {
            LogCapture.info("Verify the subscription is deleted successfully with specific provider ......");

            String vObjBarClaysProviderGBPAED = Constants.B2BOR.getProperty("BarClaysProviderGBPAED");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjBarClaysProviderGBPAED, ""));
        }
    }

    @And("^User click on Delete from B2B Dashboard with specific provider \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userClickOnDeleteFromBBDashboardWithSpecificProviderAndAndAnd(String Sell, String Buy, String OrgName, String BankName) throws Throwable {
        LogCapture.info("Verify the subscription is deleted successfully with specific provider ......");

        String vObjProviderNotExit = "//*[@id='SP-" + BankName + "-PRICING-" + Sell + "/" + Buy + "-0M-1M-" + OrgName + "-SP-" + Sell + "']";
        System.out.println(vObjProviderNotExit);
        Assert.assertEquals("PASS", Constants.key.notexist(vObjProviderNotExit, ""));

    }

    @And("^User click on (PotentialDuplicateQueue|Manual Balance Upload|Manual Entries Upload) Menu from (Banking)$")
    public void userClickOnPotentialDuplicateQueueMenuFromDashboard(String MainMenu, String SubMenu) throws Exception {
        if (MainMenu.equalsIgnoreCase("PotentialDuplicateQueue") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Potential Duplicate Queue ......");

            String vPotentialDuplicateQueue = Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPotentialDuplicateQueue, ""));

        }
        if (MainMenu.equalsIgnoreCase("Manual Balance Upload") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Manual Balance Upload ......");

            String vPotentialDuplicateQueue = Constants.BankingOR.getProperty("BNK_ManualBalanceUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPotentialDuplicateQueue, ""));

        }
        if (MainMenu.equalsIgnoreCase("Manual Entries Upload") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Manual Entries Upload ......");

            String vPotentialDuplicateQueue = Constants.BankingOR.getProperty("BNK_ManualEntriesUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPotentialDuplicateQueue, ""));

        }
    }

    @And("^User click on (Payment Entries|Property Log|Incoming Queries|Pending Authorise) Menu from (Payment Monitoring|Query Management)$")
    public void userClickOnPaymentMonitoringMenuFromDashboard(String MainMenu, String SubMenu) throws Exception {
        key.pause("6", "");
        if (MainMenu.equalsIgnoreCase("Payment Entries") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Payment Entries ......");
            key.pause("2", "");
            String vPotentialDuplicateQueue = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPotentialDuplicateQueue, ""));

        }
        if (MainMenu.equalsIgnoreCase("Property Log") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Property Log  ......");

            String vPotentialDuplicateQueue = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PropertyLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPotentialDuplicateQueue, ""));

        }
        if (MainMenu.equalsIgnoreCase("Incoming Queries") && SubMenu.equalsIgnoreCase("Query Management")) {
            LogCapture.info("User Click on Incoming Queries ......");
            key.pause("2", "");
            String vQMIncomingQueries = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQueries, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQMIncomingQueries, ""));

        }
        if (MainMenu.equalsIgnoreCase("Pending Authorise") && SubMenu.equalsIgnoreCase("Query Management")) {
            LogCapture.info("User Click on Pending Authorise ......");

            String vQMPendingAuthorise = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_PendingAuthorise");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMPendingAuthorise, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQMPendingAuthorise, ""));

        }
    }

    @Then("^User successfully landed on (Payment Entries|Property Log|Payment Entries Page|Trading Dashboard Report) page$")
    public void userShouldNavigateToPaymentEntries(String data) throws Exception {
        if (data.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("Payment Entries screen loading ......");

            String vInstitution = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_Table");
            Assert.assertEquals("PASS", Constants.key.exist(vInstitution, ""));

        }
        if (data.equalsIgnoreCase("Property Log")) {
            LogCapture.info("Property Log screen loading ......");

            String vInstitution = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_Table");
            Assert.assertEquals("PASS", Constants.key.exist(vInstitution, ""));

        }
        if (data.equalsIgnoreCase("Payment Entries Page")) {
            LogCapture.info("Payment Entries screen loading ......");

            String vPaymentEntriesTable = Constants.BankingOR.getProperty("BNK_PAymentMonitoring_PymtEntries_Table");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentEntriesTable, ""));

        }
        if (data.equalsIgnoreCase("Trading Dashboard Report")) {
            LogCapture.info("Trading Dashboard Report screen loading ......");

            String vPaymentEntriesTable = Constants.B2BOR.getProperty("B2B_TradingDashboardReport_Table");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentEntriesTable, ""));

        }
    }


    @Then("^User successfully landed on (Potential Duplicate Queue|Manual Balance Upload|Manual Entries Upload|Queries|Incoming Queries|Pending Authorise|Failed Payment Out|FX Confirmation|Query Exception) page$")
    public void userShouldNavigateToPotentialDuplicateQueue(String data) throws Exception {
        if (data.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("Potential Duplicate Queue screen loading ......");

            String vDuplicateQueue = Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue_DuplicateQueue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDuplicateQueue, "Duplicate Queue"));
        }
        if (data.equalsIgnoreCase("Manual Balance Upload")) {
            LogCapture.info("Manual Balance Upload screen loading ......");

            String vDuplicateQueue = Constants.BankingOR.getProperty("BNK_ManualBalanceUpload_SelectExcelFile");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDuplicateQueue, "Please select a excel file for process:"));

        }
        if (data.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info("Manual Entries Upload screen loading ......");

            String vDuplicateQueue = Constants.BankingOR.getProperty("BNK_ManualEntriesUpload_Tab");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDuplicateQueue, "Manual Entries Upload"));

        }
        if (data.equalsIgnoreCase("Queries")) {
            LogCapture.info("Queries screen loading ......");

            String vQMQueriesTable = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Table");
            //Assert.assertEquals("PASS", Constants.key.verifyText(vQMQueriesTable, "Manual Entries Upload"));
            Assert.assertEquals("PASS", Constants.key.exist(vQMQueriesTable, ""));

        }
        if (data.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("Incoming Queries screen loading ......");

            String vQMIncomingQueriesTable = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_Table");
            //Assert.assertEquals("PASS", Constants.key.verifyText(vQMQueriesTable, "Manual Entries Upload"));
            Assert.assertEquals("PASS", Constants.key.exist(vQMIncomingQueriesTable, ""));

        }
        if (data.equalsIgnoreCase("Query Exception")) {
            LogCapture.info("Query Exception screen loading ......");

            String vBNK_QM_QueryException_Table = Constants.QueryManagementOR.getProperty("BNK_QM_QueryException_Table");
            //Assert.assertEquals("PASS", Constants.key.verifyText(vQMQueriesTable, "Manual Entries Upload"));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_QueryException_Table, ""));
        }
        if (data.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("Pending Authorise screen loading ......");

            String vQMPendingAuthoriseTable = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_PendingAuthoriseTable");
            Assert.assertEquals("PASS", Constants.key.exist(vQMPendingAuthoriseTable, ""));
        }
        if (data.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("Failed Payment Out screen loading ......");

            String vMessageFPOTable = Constants.MessageOR.getProperty("BNK_Message_FPOTable");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPOTable, ""));

        }
        if (data.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("FX Confirmation screen loading ......");

            String vFXC_Organization = Constants.FXConfirmationOR.getProperty("BNK_FXC_Organization");
            Assert.assertEquals("PASS", Constants.key.exist(vFXC_Organization, ""));

        }
    }

    @And("^User click on (Checkbox|Select Bank|ChangePreference|Institution|ApplyChangePreference|Payment Type|Status|State|Import Query|Reset Filter|ID|Submit|Bank|Status Search|Organization|Titan Against MT300|Raise Query|Checkbox1|Query ID|MT300 against Titan|Reset Filter1|Enter OrgName) from (Payment Entries|Queries|Incoming Queries|Pending Authorise|Failed Payment Out|FX Confirmation|TradingDashboardReport) page$")
    public void userClickOnCheckboxFromPaymentEntriesPage(String Value, String Menu) throws Throwable {
        key.pause("7", "");
        if (Value.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on checkbox ......");

            String vCheckbox = Constants.BankingOR.getProperty("BNK_BalanceEntries_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vCheckbox, ""));

        }
        if (Value.equalsIgnoreCase("Select Bank") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on Select Bank ......");

            String vObjSelectBank = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectBank, ""));
        }
        if (Value.equalsIgnoreCase("ChangePreference") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjChangePreference, ""));
        }
        if (Value.equalsIgnoreCase("Institution") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User deselect Institution ChangePreference change preference at top right corner.....");

            String vInstitutionChangePreference = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_chngPreference_Institution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vInstitutionChangePreference, ""));
            if (Constants.key.verifyElementProperties(vInstitutionChangePreference, "unselected").equalsIgnoreCase("PASS")) {
                Constants.key.click(vInstitutionChangePreference, "");
            }
            Assert.assertEquals("PASS", Constants.key.click(vInstitutionChangePreference, ""));
        }
        if (Value.equalsIgnoreCase("ApplyChangePreference") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on Apply change preference at top right corner.....");

            String vObjApplyChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ApplyChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjApplyChangePreference, ""));
        }
        if (Value.equalsIgnoreCase("Payment Type") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on Payment Type ......");

            String vObjSelectBank = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_PaymentType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectBank, ""));

        }
        if (Value.equalsIgnoreCase("Reset Filter1") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on reset filter at top right corner.....");

            String vQMResetFilter = Constants.BankingOR.getProperty("BNK_BalanceException_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMResetFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQMResetFilter, ""));

        }
        if (Value.equalsIgnoreCase("Checkbox1") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on checkbox ......");

            String vQueriesCheckbox = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueriesCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQueriesCheckbox, ""));

        }
        if (Value.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User Click on checkbox ......");

            String vQueriesCheckbox = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueriesCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQueriesCheckbox, ""));

        }
        if (Value.equalsIgnoreCase("Status") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User Click on Status ......");

            String vObjSelectStatus = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_SelectStatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectStatus, ""));

        }
        if (Value.equalsIgnoreCase("State") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User Click on State ......");

            String vObjSelectState = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_SelectState");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectState, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectState, ""));

        }
        if (Value.equalsIgnoreCase("Import Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on Import Query ......");

            String vImportQuery = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ImportQueries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vImportQuery, ""));
            Assert.assertEquals("PASS", Constants.key.click(vImportQuery, ""));

        }
        if (Value.equalsIgnoreCase("Status") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on Status ......");

            String vObjSelectStatus = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_SelectStatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectStatus, ""));

        }
        if (Value.equalsIgnoreCase("State") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on State ......");

            String vObjSelectState = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_SelectState");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectState, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectState, ""));

        }
        if (Value.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on checkbox ......");

            String vQueriesCheckbox = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueriesCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQueriesCheckbox, ""));

        }
        if (Value.equalsIgnoreCase("Reset Filter1") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on reset filter at top right corner.....");

            String vQMResetFilter = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMResetFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQMResetFilter, ""));

        }
        if (Value.equalsIgnoreCase("Bank") && Menu.equalsIgnoreCase("Payment Entries ")) {
            LogCapture.info("User Click on Bank.....");

            String vBanking_PymtEntries_SelectBank = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_Bank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PymtEntries_SelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_PymtEntries_SelectBank, ""));

        }

        if (Value.equalsIgnoreCase("ID") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on ID.....");

            String vQMIDSearch = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_IDSearch");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIDSearch, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQMIDSearch, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vQMIDSearch));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vQMIDSearch, QueryIdValue));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vQMIDSearch, "enter"));

        }
        if (Value.equalsIgnoreCase("Query ID") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on ID.....");

            String vQMIDSearch1 = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_IDSearch");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIDSearch1, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQMIDSearch1, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vQMIDSearch1));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vQMIDSearch1, QueryID2));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vQMIDSearch1, "enter"));

        }
        if (Value.equalsIgnoreCase("ID") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on ID.....");

            String vQMIDSearch = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_IDSearch");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIDSearch, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQMIDSearch, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vQMIDSearch));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vQMIDSearch, QueryIdValue));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vQMIDSearch, "enter"));

        }
        if (Value.equalsIgnoreCase(" Enter OrgName ") && Menu.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("User Enter Org Name.....");

            String vB2BOrgName = Constants.QueryManagementOR.getProperty("B2B_TrandingDashboardReport_OrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2BOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.click(vB2BOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vB2BOrgName));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vB2BOrgName, "TofFx"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vB2BOrgName, "enter"));
        }

        if (Value.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User Click on checkbox ......");

            String vCheckbox = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vCheckbox, ""));
        }
        if (Value.equalsIgnoreCase("Status Search") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Click on Status......");

            String vMessage_StatusSearch = Constants.MessageOR.getProperty("BNK_Message_FPO_StatusSearch");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMessage_StatusSearch, ""));
            Assert.assertEquals("PASS", Constants.key.click(vMessage_StatusSearch, ""));


        }
        if (Value.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Click on checkbox ......");

            String vCheckbox = Constants.MessageOR.getProperty("BNK_Message_FPO_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vCheckbox, ""));

        }
        if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("User Click on Organization ......");

            String vFXC_SelectOrganization = Constants.FXConfirmationOR.getProperty("BNK_FXC_SelectOrganization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFXC_SelectOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFXC_SelectOrganization, ""));
        }
        if (Value.equalsIgnoreCase("Titan Against MT300") && Menu.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("User Click on Titan Against MT300 ......");

            String vFXC_TitanAgainstMT300 = Constants.FXConfirmationOR.getProperty("BNK_FXC_TitanAgainstMT300");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFXC_TitanAgainstMT300, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFXC_TitanAgainstMT300, ""));
        }
        if (Value.equalsIgnoreCase("MT300 against Titan") && Menu.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("User Click on MT300 against Titan ......");

            String vFXC_MT300TitanAgainst = Constants.FXConfirmationOR.getProperty("BNK_FXC_MT300AgainstTitan");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFXC_MT300TitanAgainst, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFXC_MT300TitanAgainst, ""));
        }
        if (Value.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User click on Submit from Payment entries page......");

            String vBNK_QM_SubmitQuery = Constants.QueryManagementOR.getProperty("BNK_QM_SubmitQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_SubmitQuery, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_QM_SubmitQuery, ""));

        }
    }

    @And("^User click on (Select Institution|FCG|Reset Filter|Choose File|PotentialDuplicateQueueRecord|Upload Button|Reference|OrganizationName|Rename File) from (Potential Duplicate Queue|Manual Balance Upload|Manual Entries Upload|Pending Authorise|Queries|TradingDashboardReport|Lacaxia Upload|Manual Payment Upload_JPMG|Manual Payment Upload_CITI|Manual PSR Uploads|Manual Payment Upload_JPY|Manual Payment Upload_BARC|Manual Payment Upload_BARC_DPQ|Manual PSR Uploads CDSA) page$")
    public void userClickOnSelectInstitutionFromPotentialDuplicateQueuePage(String Value, String Menu) throws Throwable {
        key.pause("2", "");
        if (Value.equalsIgnoreCase("Select Institution") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on Select Institution ......");

            String vSelectInstitution = Constants.BankingOR.getProperty("BNK_BankAccount_Institution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectInstitution, ""));
        }
        if (Value.equalsIgnoreCase("FCG") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on FCG ......");

            String vSelectInstitutionFCG = Constants.BankingOR.getProperty("BNK_BankAccount_InstituteValue_FCG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectInstitutionFCG, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectInstitutionFCG, ""));
        }
        if (Value.equalsIgnoreCase("Reset Filter") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on reset filter at top right corner.....");

            String vResetFilter = Constants.BankingOR.getProperty("BNK_AccountBalance_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vResetFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vResetFilter, ""));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Balance Upload")) {
            LogCapture.info("User Click on Choose file.....");

            String pathtoUpload = System.getProperty("user.dir") + "/files/ManualBalanceUpload.xlsx";
            String vBanking_ManualBalanceUploadFile = Constants.BankingOR.getProperty("BNK_ManualBalanceUpload_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualBalanceUploadFile, pathtoUpload));

        }
        if (Value.equalsIgnoreCase("Upload Button") && Menu.equalsIgnoreCase("Manual Balance Upload")) {
            LogCapture.info("User Click on Upload.....");

            String vFileUpload = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_Upload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFileUpload, ""));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info("User Click on Choose file.....");
            Constants.key.pause("5", "");
            String vBNK_ChooseFile = Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            //String pathtoUpload=System.getProperty("user.dir") + "/Files/ManualEnteriesUpload_2022-07-28-18-08-07.xlsx";

//            Assert.assertEquals("PASS", Constants.key.click(vBNK_ChooseFile, ""));    // already commented

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);

            File camtFile = null;
            File directoryPath = new File("Files/");

            String contents[] = directoryPath.list();

            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].contains("ManualEnteriesUpload")) {
                    camtFile = new File("Files/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            File Rename = new File("Files/ManualEnteriesUpload_" + currentDate + ".xlsx");
            camtFile.renameTo(Rename);

            String newFileName = System.getProperty("user.dir") + "/Files/" + Rename.getName();
            String vBanking_ManualBalanceUploadFile = Constants.BankingOR.getProperty("BNK_ManualBalanceUpload_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualBalanceUploadFile, newFileName));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Lacaxia Upload")) {
            LogCapture.info("User Click on Choose file.....");
            Constants.key.pause("5", "");
            String vBNK_ChooseFile = Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            //String pathtoUpload=System.getProperty("user.dir") + "/Files/ManualEnteriesUpload_2022-07-28-18-08-07.xlsx";

//            Assert.assertEquals("PASS", Constants.key.click(vBNK_ChooseFile, ""));    // already commented

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);

            File camtFile = null;
            File directoryPath = new File("Files/Manual Entries/");

            String contents[] = directoryPath.list();

            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].contains("ManualEnteriesUpload")) {
                    camtFile = new File("Files/Manual Entries/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename = new File("Files/Manual Entries/ManualEnteriesUpload_" + currentDate + ".xlsx");
            camtFile.renameTo(Rename);

//            String newFileName=System.getProperty("user.dir") + "/Files/Manual Entries/"+Rename.getName();
//            String vBanking_ManualBalanceUploadFile=Constants.BankingOR.getProperty("BNK_ManualBalanceUpload_ChooseFile");
//            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualBalanceUploadFile, newFileName));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual PSR Uploads")) {
            LogCapture.info("User verify file upload ......");
            String vBNK_ChooseFile = Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            File camtFile = null;
            File directoryPath = new File("Files/PSR_Files/");
            String contents[] = directoryPath.list();
            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].contains("AIP")) {
                    camtFile = new File("Files/PSR_Files/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename = new File("Files/PSR_Files/AIP_" + currentDate + ".xlsx");
            camtFile.renameTo(Rename);
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Payment Upload_JPMG")) {
            LogCapture.info("User verify file upload ......");
            String vBNK_ChooseFile = Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            File camtFile = null;
            File directoryPath = new File("Files/Manual_Payment/");
            String contents[] = directoryPath.list();
            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].contains("Manual_Payment_Upload_USD")) {
                    camtFile = new File("Files/Manual_Payment/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename = new File("Files/Manual_Payment/Manual_Payment_Upload_USD" + currentDate + ".xlsx");
            camtFile.renameTo(Rename);
//            String newFileName = System.getProperty("user.dir") + "/Files/Manual_Payment/" + Rename.getName();
//            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
//            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Payment Upload_CITI")) {
            LogCapture.info("User verify file upload ......");
            String vBNK_ChooseFile = Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            File camtFile = null;
            File directoryPath = new File("Files/Manual_Payment/");
            String contents[] = directoryPath.list();
            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].contains("Manual_Payment_Upload_CITI")) {
                    camtFile = new File("Files/Manual_Payment/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename = new File("Files/Manual_Payment/Manual_Payment_Upload_CITI" + currentDate + ".xlsx");
            camtFile.renameTo(Rename);

        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Payment Upload_BARC")) {
            LogCapture.info("User verify file upload ......");
            String vBNK_ChooseFile = Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            File camtFile = null;
            File directoryPath = new File("Files/Manual_Payment/");
            String contents[] = directoryPath.list();
            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].contains("BARC_MT101_")) {
                    camtFile = new File("Files/Manual_Payment/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename = new File("Files/Manual_Payment/BARC_MT101_" + currentDate + ".xlsx");
            camtFile.renameTo(Rename);
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Payment Upload_BARC_DPQ")) {
            LogCapture.info("User verify file upload ......");
            String vBNK_ChooseFile = Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            File camtFile = null;
            File directoryPath = new File("Files/Manual_Payment/");
            String contents[] = directoryPath.list();
            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].contains("BARC_MT101_")) {
                    camtFile = new File("Files/Manual_Payment/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename = new File("Files/Manual_Payment/BARC_MT101_" + currentDate + ".xlsx");
            camtFile.renameTo(Rename);
            String newFileName = System.getProperty("user.dir") + "/Files/Manual_Payment/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Payment Upload_JPY")) {
            String pathtoUpload = System.getProperty("user.dir") + "/Files/Manual_Payment/Manual_Payment_Upload_JPY.xlsx";
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
//            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUploadFile, ""));
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualPaymentUploadFile, pathtoUpload));
        }
        if (Value.equalsIgnoreCase("Upload Button") && Menu.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info("User Click on Upload.....");

            String vFileUpload = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_Upload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFileUpload, ""));

        }
        if (Value.equalsIgnoreCase("Rename File") && Menu.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info("File is renamed.....");
            String FolderPath1 = System.getProperty("user.dir") + "/files/";
            File f1 = new File(FilePath);
            f1.renameTo(new File(FolderPath1 + "ManualEnteriesUpload.xlsx"));
            System.out.println(f1.getName() + "File Renamed");
        }
        if (Value.equalsIgnoreCase("PotentialDuplicateQueueRecord") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on Potential Duplicate Queue record.....");

            String vBNK_PotentialDuplicateQueue_FirstRecord = Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue_FirstRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PotentialDuplicateQueue_FirstRecord, ""));

            Assert.assertEquals("PASS", Constants.key.click(vBNK_PotentialDuplicateQueue_FirstRecord, ""));

        }
        if (Value.equalsIgnoreCase("Select Institution") && Menu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User Click on Select Institution ......");

            String vMessage_SelectInstitution1 = Constants.QueryManagementOR.getProperty("BNK_QM_PendingAuthorise_AuthoriseQuery_SelectInstitution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMessage_SelectInstitution1, ""));
            Assert.assertEquals("PASS", Constants.key.click(vMessage_SelectInstitution1, ""));
        }
        if (Value.equalsIgnoreCase("Reference") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on Reference ......");

            String vQueries_RaiseQuery_Reference = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_Reference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueries_RaiseQuery_Reference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQueries_RaiseQuery_Reference, ""));
        }
        if (Value.equalsIgnoreCase("OrganizationName") && Menu.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("User Click on OrgName ......");

            String vSelectORgName = Constants.B2BOR.getProperty("B2B_TrandingDashboardReport_OrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectORgName, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectORgName, ""));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual PSR Uploads CDSA")) {
            LogCapture.info("User verify file upload ......");
            String vBNK_ChooseFile = Constants.BankingOR.getProperty("BNK_ChooseFileCDSA");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            File camtFile = null;
            File directoryPath = new File("Files/PSR_Files/");
            String contents[] = directoryPath.list();
            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i = 0; i < contents.length; i++) {
                if (contents[i].contains("CDSA")) {
                    camtFile = new File("Files/PSR_Files/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename = new File("Files/PSR_Files/CDSA_" + currentDate + ".xlsx");
            camtFile.renameTo(Rename);
        }
    }


    @Then("^User should successfully see (Reset Filter|Export|Print|Audit Trail|Raise Query|Institution not Present) on (Payment Entries) page$")
    public void userShouldSuccessfullySeeRaiseQueryOptionPage(String Data, String Menu) throws Throwable {
        key.pause("2", "");
        if (Data.equalsIgnoreCase("Raise Query") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("Raise Query option is loading ......");

            String vRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_RaiseQuery");
            //Assert.assertEquals("PASS", Constants.key.verifyText(vRaiseQuery, "Raise Query"));
            Assert.assertEquals("PASS", Constants.key.exist(vRaiseQuery, ""));

        }
        if (Data.equalsIgnoreCase("Institution not Present") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("Payment Entries Records data loading ......");

            String vInstitution = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntires_Institution");
            Assert.assertEquals("PASS", Constants.key.exist(vInstitution, ""));
            //Assert.assertEquals("PASS", Constants.key.notexist(vInstitution, ""));
        }


    }


    @Then("^User verify (All Options|All Fields) are present on (Payment Entries|Property Log|Failed Payment Out) page$")
    public void userVerifyAllOptionsArePresentOnPaymentEntriesPage(String Options, String Menu) throws Throwable {
        key.pause("6", "");
        if (Options.equalsIgnoreCase("All Options") && Menu.equalsIgnoreCase("Payment Entries")) {

            LogCapture.info("User Verifying Reset Filter Option on Payment Entries page......");
            String vPaymentMonitoringResetFilter = Constants.BankingOR.getProperty("BNK_AccountBalance_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentMonitoringResetFilter, ""));

            LogCapture.info("User Verifying Export Option on Payment Entries page......");
            String vPaymentMonitoringExport = Constants.BankingOR.getProperty("BNK_BalanceEntries_Export");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentMonitoringExport, ""));

            LogCapture.info("User Verifying Print Option on Payment Entries page......");
            String vPaymentMonitoringPrint = Constants.BankingOR.getProperty("BNK_BAnkAccount_PrintIcon");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentMonitoringPrint, ""));

            LogCapture.info("User Verifying Audit Trail Option on Payment Entries page......");
            String vPaymentMonitoringAuditTrail = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_AuditTrail");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentMonitoringAuditTrail, ""));

            LogCapture.info("User Verifying Raise Query Option on Payment Entries page......");
            String vPaymentMonitoringRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentMonitoringAuditTrail, ""));
        }
        if (Options.equalsIgnoreCase("All Options") && Menu.equalsIgnoreCase("Property Log")) {

            LogCapture.info("User Verifying Reset Filter Option on Payment Entries page......");
            String vPaymentMonitoringResetFilter = Constants.BankingOR.getProperty("BNK_AccountBalance_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentMonitoringResetFilter, ""));

            LogCapture.info("User Verifying Export Option on Payment Entries page......");
            String vPaymentMonitoringExport = Constants.BankingOR.getProperty("BNK_BalanceEntries_Export");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentMonitoringExport, ""));

            LogCapture.info("User Verifying Print Option on Payment Entries page......");
            String vPaymentMonitoringPrint = Constants.BankingOR.getProperty("BNK_BAnkAccount_PrintIcon");
            Assert.assertEquals("PASS", Constants.key.exist(vPaymentMonitoringPrint, ""));
        }
        if (Options.equalsIgnoreCase("All Options") && Menu.equalsIgnoreCase("Failed Payment Out")) {

            LogCapture.info("User Verifying ID Option on Failed Payment Out page......");

            String vMessageFPO_ID = Constants.MessageOR.getProperty("BNK_Message_FPO_ID");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_ID, ""));

            LogCapture.info("User Verifying Message No on Failed Payment Out page......");

            String vMessageFPO_MessageNo = Constants.MessageOR.getProperty("BNK_Message_FPO_MessageNo");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_MessageNo, ""));

            LogCapture.info("User Verifying Source on Failed Payment Out page......");

            String vMessageFPO_Source = Constants.MessageOR.getProperty("BNK_Message_FPO_Source");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_Source, ""));

            //String vMessageFPO_SourceDropdown = Constants.MessageOR.getProperty("BNK_Message_FPO_SourceDropdown");
            //Assert.assertEquals("PASS", Constants.key.click(vMessageFPO_SourceDropdown,""));
            //

            LogCapture.info("User Verifying Created on Failed Payment Out page......");

            String vMessageFPO_Created = Constants.MessageOR.getProperty("BNK_Messaage_FPO_Created");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_Created, ""));

            LogCapture.info("User Verifying Status on Failed Payment Out page......");

            String vMessageFPO_Status = Constants.MessageOR.getProperty("BNK_Message_FPO_Status");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_Status, ""));

            LogCapture.info("User Verifying Error Code on Failed Payment Out page......");

            String vMessageFPO_ErrorCode = Constants.MessageOR.getProperty("BNK_Message_FPO_ErrorCode");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_ErrorCode, ""));

            LogCapture.info("User Verifying Error Description on Failed Payment Out page......");

            String vMessageFPO_ErrorDescription = Constants.MessageOR.getProperty("BNK_Message_FPO_ErrorDescription");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_ErrorDescription, ""));

            LogCapture.info("User Verifying Transaction Reference on Failed Payment Out page......");

            String vMessageFPO_TransactionReference = Constants.MessageOR.getProperty("BNK_Message_FPO_TransactionReference");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_TransactionReference, ""));

            LogCapture.info("User Verifying Senders Reference on Failed Payment Out page......");

            String vMessageFPO_SendersReference = Constants.MessageOR.getProperty("BNK_Message_FPO_SendersReference");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPO_SendersReference, ""));
        }
        if (Options.equalsIgnoreCase("All Fields") && Menu.equalsIgnoreCase("Failed Payment Out")) {

            LogCapture.info("User Verifying Id Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_ID = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_ID");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_ID, ""));

            LogCapture.info("User Verifying Senders Reference: Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_SendersReference = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_SendersReference");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_SendersReference, ""));

            LogCapture.info("User Verifying Bank operationCode Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_BankOperationCode = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_BankoperationCode");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_BankOperationCode, ""));

            LogCapture.info("User Verifying InstructionCode Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_InstructionCode = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_InstructionCode");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_InstructionCode, ""));

            LogCapture.info("User Verifying InterBank currency Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_InterBankCurrency = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_InterBankcurrency");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_InterBankCurrency, ""));

            LogCapture.info("User Verifying InterBankAmount Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_InterBankAmount = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_InterBankAmount");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_InterBankAmount, ""));

            LogCapture.info("User Verifying OderingCustomer Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_OrderingCustomer = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_OderingCustomer");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_OrderingCustomer, ""));

            LogCapture.info("User Verifying OrderingInstitution Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_orderingInstitution = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_OrderingInstitution");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_orderingInstitution, ""));

            LogCapture.info("User Verifying ISOCountry Code Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_ISOCountryCode = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_ISOCountryCode");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_ISOCountryCode, ""));

            LogCapture.info("User Verifying Senders Correspondant Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_SendersCorrespondant = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_SendersCorrespondant");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_SendersCorrespondant, ""));

            LogCapture.info("User Verifying Receivers Correspondant Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_ReceiversCorrespondant = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_ReceiversCorrespondant");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_ReceiversCorrespondant, ""));

            LogCapture.info("User Verifying BeneficiaryCustomer Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_BeneficiaryCustomer = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_BeneficiaryCustomer");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_BeneficiaryCustomer, ""));

            LogCapture.info("User Verifying IntermediaryInstitution Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_IntermediaryInstitution = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_IntermediaryInstitution");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_IntermediaryInstitution, ""));

            LogCapture.info("User Verifying AccountWithInstitution Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_AccountWithInstitution = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_AccountWithInstitution");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_AccountWithInstitution, ""));

            LogCapture.info("User Verifying RemittanceInformation Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_RemittanceInformation = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_RemittanceInformation");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_RemittanceInformation, ""));

            LogCapture.info("User Verifying Details ofCharges Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_DetailsofCharges = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_DetailsofCharges");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_DetailsofCharges, ""));

            LogCapture.info("User Verifying SendersToReceiverInformation Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_SendersToReceiverInfo = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_SendersToReceiverInformation");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_SendersToReceiverInfo, ""));

            LogCapture.info("User Verifying PaymentType Option on Failed Payment Out......");

            String vMessage_FPO_SelectQuery_PaymentType = Constants.MessageOR.getProperty("BNK_Message_FPO_SelectedQuery_PaymentType");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_SelectQuery_PaymentType, ""));


        }
    }

    @Then("^User should not see right click (Raise Query Option for BOM Bank|Raise Query Option for Deutsche Bank|Raise Query Option for Silicon Valley Bank) on (Payment Entries) page$")
    public void userShouldNotSeeRaiseQueryOnPaymentEntriesPage(String Options, String Menu) throws Throwable {
        key.pause("2", "");
        if (Options.equalsIgnoreCase("Raise Query") && Menu.equalsIgnoreCase("Payment Entries")) {

            LogCapture.info("User Verifying Raise Query Option not present on right click......");
            String vRightClickRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.notexist(vRightClickRaiseQuery, ""));


        } else if (Options.equalsIgnoreCase("Raise Query Option for Deutsche Bank") && Menu.equalsIgnoreCase("Payment Entries")) {

            LogCapture.info("User Verifying Raise Query Option not present on right click......");
            String vRightClickRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.notexist(vRightClickRaiseQuery, ""));


        } else if (Options.equalsIgnoreCase("Raise Query Option for Silicon Valley Bank") && Menu.equalsIgnoreCase("Payment Entries")) {

            LogCapture.info("User Verifying Raise Query Option not present on right click......");
            String vRightClickRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.notexist(vRightClickRaiseQuery, ""));


        }
    }

    @Then("^User should see right click (Raise Query Option for RBOS Bank|Raise Query Option for Barclays Bank|Raise Query Option for CITI Bank) on (Payment Entries) page$")
    public void userShouldNSeeRaiseQueryOnPaymentEntriesPage(String Options, String Menu) throws Throwable {
        if (Options.equalsIgnoreCase("Raise Query Option for RBOS Bank") && Menu.equalsIgnoreCase("Payment Entries")) {

            LogCapture.info("User Verifying Raise Query Option  present on right click......");
            String vRightClickRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.exist(vRightClickRaiseQuery, ""));


        } else if (Options.equalsIgnoreCase("Raise Query Option for Barclays Bank") && Menu.equalsIgnoreCase("Payment Entries")) {

            LogCapture.info("User Verifying Raise Query Option  present on right click......");
            String vRightClickRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.exist(vRightClickRaiseQuery, ""));


        } else if (Options.equalsIgnoreCase("Raise Query Option for CITI Bank") && Menu.equalsIgnoreCase("Payment Entries")) {

            LogCapture.info("User Verifying Raise Query Option present on right click......");
            String vRightClickRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.exist(vRightClickRaiseQuery, ""));


        }
    }


    @Then("^User should see right click (All Options|Raise Query|Close Queries) on (Payment Entries|Queries) page$")
    public void userShouldSeeAllOptionsOnPaymentEntriesPage(String Options, String Menu) throws Throwable {
        if (Options.equalsIgnoreCase("All Options") && Menu.equalsIgnoreCase("Payment Entries")) {

            LogCapture.info("User Verifying Audit Trail Option on right click......");
            String vRightClickAuditTrail = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_RightClick_AuditTrail");
            Assert.assertEquals("PASS", Constants.key.exist(vRightClickAuditTrail, ""));

            LogCapture.info("User Verifying Copy Of MT Option on right click......");
            String vRightClickCopyOfMP = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_RightClick_CopyOfMT");
            Assert.assertEquals("PASS", Constants.key.exist(vRightClickCopyOfMP, ""));

/*
                        LogCapture.info("User Verifying Audit Trail Option on right click......");
                        String vBNK_BalanceException_ResetFilter=Constants.BankingOR.getProperty("BNK_PaymentMonitoring_RightClick_AuditTrail");
                        Assert.assertEquals("PASS",Constants.key.exist(vBNK_BalanceException_ResetFilter,""));  */
        }
        if (Options.equalsIgnoreCase("Raise Query") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Verifying Raise Query Option on right click......");
            String vRightClickRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.click(vRightClickRaiseQuery, ""));
        }
        if (Options.equalsIgnoreCase("Close Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Verifying Close Query Option on right click......");
            String vRightClickcloseQuery = Constants.BankingOR.getProperty("BNK_QM_Queries_CloseQuery");
            Assert.assertEquals("PASS", Constants.key.click(vRightClickcloseQuery, ""));
        }
    }

    @Then("^User should successfully see (FCG Details|Potential Duplicate Queue Present Records|File Uploaded Successfully|State and Status|Amendment Type|Cancellation Type|Recall Type|BCNR Type|Additional Information Type|State and Status for closed Query|State and Status for Re-Opened Query|Miscellaneous Type|Message No|Details of selected Entry|Message Details|All the Deals|State and Status for Rejected Query|TorFx Details) on (Potential Duplicate Queue|Manual Balance Upload|Manual Entries Upload|Incoming Queries|Queries|Failed Payment Out|FX Confirmation|Payment Entries|TradingDashboardReport) page$")
    public void userShouldSuccessfullySeeFCGDetailsOnPotentialDuplicateQueuePage(String Data, String Menu) throws Throwable {
        key.pause("7", "");
        if (Data.equalsIgnoreCase("FCG Details") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("FCG data loading ......");
            String vObjBlotterTotal = Constants.BankingOR.getProperty("BNK_BankAccount_FCG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlotterTotal, "FCG"));

        }
        if (Data.equalsIgnoreCase("Potential Duplicate Queue Present Records") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("Potential Duplicate Queue Records data loading ......");

            String vPagerInformation = Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue_NoOfRecords");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPagerInformation, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vPagerInformation, ""));

        }
        if (Data.equalsIgnoreCase("File Uploaded Successfully") && Menu.equalsIgnoreCase("Manual Balance Upload")) {
            LogCapture.info(" File Successfully Uploaded ......");
            String vFileUploadSuccessMsg = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_SuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFileUploadSuccessMsg, "\"File uploaded successfully\""));
            //Assert.assertEquals("PASS", Constants.key.exist(vFileUploadSuccessMsg, ""));

        }
        if (Data.equalsIgnoreCase("File Uploaded Successfully") && Menu.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info(" File Successfully Uploaded ......");
            String vFileUploadSuccessMsg = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_SuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFileUploadSuccessMsg, "\"File uploaded successfully\""));
            //Assert.assertEquals("PASS", Constants.key.exist(vFileUploadSuccessMsg, ""));


            //Constants.filerename.renameToOriginal(Constants.latestFile);


        }
        if (Data.equalsIgnoreCase("State and Status") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("Incoming Queries data loading ......");

            String vQMIncomingQueriesStatus = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_Status");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMIncomingQueriesStatus, "Initiated"));


            String vQMIncomingQueriesState = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_State");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMIncomingQueriesState, "Import"));

        }
        if (Data.equalsIgnoreCase("State and Status") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("State Status data loading ......");

            String vQMStatusValue = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStatusValue, "Open"));

            String vQMStateValue = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStateValue, "Raised"));

        }
        if (Data.equalsIgnoreCase("State and Status") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("State Status data loading ......");

            String vPaymentEntriesStatusValue = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_StatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentEntriesStatusValue, "Processing"));

            String vPaymentEntriesStateValue = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_StateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentEntriesStateValue, "Confirmed"));

        }
        if (Data.equalsIgnoreCase("Amendment Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Amendment Type data loading ......");

            String vQMTypeValueAmendment = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueAmendment, "Amendment"));

        }
        if (Data.equalsIgnoreCase("Cancellation Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Cancellation Type data loading ......");

            String vQMTypeValueCancellation = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueCancellation, "Cancellation"));

        }
        if (Data.equalsIgnoreCase("Recall Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Recall Type data loading ......");

            String vQMTypeValueRecall = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "Recall"));
        }
        if (Data.equalsIgnoreCase("Additional Information Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Additional Information Type data loading ......");

            String vQMTypeValueRecall = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "Additional Information"));

        }
        if (Data.equalsIgnoreCase("State and Status for closed Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("State Status data loading ......");

            String vQMStatusValue = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStatusValue, "Complete"));

            String vQMStateValue = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStateValue, "Closed"));
        }
        if (Data.equalsIgnoreCase("State and Status for Rejected Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("State Status data loading ......");

            String vQMStatusValue = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStatusValue, "Complete"));

            String vQMStateValue = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStateValue, "Closed"));
        }
        if (Data.equalsIgnoreCase("State and Status for Re-Opened Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("State Status data loading ......");

            String vQMStatusValue = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStatusValue, "Open"));

            String vQMStateValue = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStateValue, "Re-open"));

        }
        if (Data.equalsIgnoreCase("BCNR Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" BCNR Type data loading ......");

            String vQMTypeValueRecall = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "BCNR"));

        }
        if (Data.equalsIgnoreCase("Miscellaneous Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Miscellaneous Type data loading ......");

            String vQMTypeValueRecall = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "Miscellaneous"));

        }
        if (Data.equalsIgnoreCase("Message No") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("Message No data loading ......");

            String vQMTypeValueRecall = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_MessageNo");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "MT199"));
        }
        if (Data.equalsIgnoreCase("Details of selected Entry") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("Details of selected Entry data loading ......");

            String vMessage_FPO_DetailsOfSelectedRecord = Constants.MessageOR.getProperty("BNK_Message_FPO_DetailsOfSelectedRecord");
            Assert.assertEquals("PASS", Constants.key.verifyText(vMessage_FPO_DetailsOfSelectedRecord, "Details of selected Entry"));

        }
        if (Data.equalsIgnoreCase("Message Details") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("Message data loading ......");

            String vMessage_FPO_MessageDetails = Constants.MessageOR.getProperty("BNK_Message_FPO_MessageDetails");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_MessageDetails, ""));
        }
        if (Data.equalsIgnoreCase("All the Deals") && Menu.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("All the Deals Tital Against MT300 data loading ......");

            String vFXC_AllTheDealsTitanAgainstMt300 = Constants.FXConfirmationOR.getProperty("BNK_FXC_AllTheDealsTitalAgainstMT300");
            Assert.assertEquals("PASS", Constants.key.exist(vFXC_AllTheDealsTitanAgainstMt300, ""));
        }
        if (Data.equalsIgnoreCase("TorFx") && Menu.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("TorFX data loading ......");
            String vObjBlotterTotal = Constants.BankingOR.getProperty("B2B_TrandingDashboardReport_TorFX");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlotterTotal, "TorFX"));

        }

    }


    @And("^User select (Institution|Logical Group|ID|Source|Organization|OrgName) \"([^\"]*)\" from (Potential Duplicate Queue|Account Balance|Failed Payment Out|FX Confirmation|TradingDashboardReport) page$")
    public void userSelectInstitutionFromPotentialDuplicateQueuePage(String Value, String Opt, String Menu) throws Throwable {
        key.pause("7", "");
        if (Value.equalsIgnoreCase("Institution") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User select Institution ......");

            String vSelectInstitution = Constants.BankingOR.getProperty("BNK_BankAccount_Institution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vSelectInstitution, Opt));

        } else if (Value.equalsIgnoreCase("Logical Group") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User select Logical Group on Account Balance Page ......");

            String vBNK_AccountBalance_ThCount = Constants.BankingOR.getProperty("BNK_AccountBalance_ThCount");
            List<WebElement> elements = driver.findElements(By.xpath(vBNK_AccountBalance_ThCount));
            String ExpectedText = "LogicalGroup";
            for (int i = 0; i <= elements.size(); i++) {
                String data = "//table[@id='balanceDIV']//thead//tr[2]//th[" + (i + 1) + "]//div";
                if (Constants.key.getText(data).equalsIgnoreCase(ExpectedText)) {
                    LogCapture.info("Table Heading is --> " + data);
                    String Object = "//table[@id='balanceDIV']//thead//tr[3]//td[" + (i + 1) + "]//select";
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(Object, ""));
                    Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(Object, Opt));
                    break;
                }
            }
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        } else if (Value.equalsIgnoreCase("ID") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User select ID on Account Balance Page ......");

            String vBNK_AccountBalanceIDInput = Constants.BankingOR.getProperty("BNK_AccountBalanceIDInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AccountBalanceIDInput, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_AccountBalanceIDInput, Opt));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_AccountBalanceIDInput, "enter"));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        } else if (Value.equalsIgnoreCase("Source") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User select Source on Failed Payment Out Page ......");

            String vBNK_FailedPaymentOut_SelectSource = Constants.MessageOR.getProperty("BNK_FailedPaymentOut_SelectSource");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_FailedPaymentOut_SelectSource, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_FailedPaymentOut_SelectSource, Opt));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

        } else if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("User select Organization ......");

            String vFXCSelectOrganization = Constants.FXConfirmationOR.getProperty("BNK_FXC_SelectOrganization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFXCSelectOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vFXCSelectOrganization, Opt));
        } else if (Value.equalsIgnoreCase("OrgName") && Menu.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("User select OrgName ......");

            String vSelectInstitution = Constants.B2BOR.getProperty("B2B_TrandingDashboardReport_OrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vSelectInstitution, Opt));
        }
    }

    @And("^Verify the subscription is deleted successfully on the dashboard with specific provider \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyTheSubscriptionIsDeletedSuccessfullyOnTheDashboardWithSpecificProviderAndAndAnd(String Sell, String Buy, String OrgName, String BankName) throws Throwable {
        LogCapture.info("User Click on Delete ......");

        String vObjDeleteProvider = "//*[@id='SP-" + BankName + "-PRICING-" + Sell + "/" + Buy + "-0M-1M-" + OrgName + "-SP-" + Sell + "']//following::th[@class='CloseButton']//img";
        System.out.println(vObjDeleteProvider);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteProvider, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjDeleteProvider, ""));

    }

    @And("^Verify the subscription is added successfully with specific provider \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyTheSubscriptionIsAddedSuccessfullyWithSpecificProviderAndAndAnd(String Sell, String Buy, String OrgName, String BankName) throws Throwable {
        LogCapture.info("Verify the subscription is added successfully with specific provider ......");

        String vObjProvider = "//*[@id='SP-" + BankName + "-PRICING-" + Sell + "/" + Buy + "-0M-1M-" + OrgName + "-SP-" + Sell + "']";
        System.out.println(vObjProvider);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProvider, ""));
    }

    @And("^User select (QueryType|Bank|Rows Per Page|Payment Type|Status|State|Raise Query Type|Sub type|Sender BIC Code|QueryType Answer|Answer Code|Authorise Type|Institution|Select Bank) \"([^\"]*)\" from (Payment Entries|Incoming Queries|Queries|Pending Authorise) page$")
    public void userSelectQueryTypeFromPaymentEntriesPage(String Value, String Opt, String Menu) throws Throwable {
        key.pause("2", "");
        if (Value.equalsIgnoreCase("QueryType") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User select QueryType from drop down ......");

            String vObjQueryType = Constants.BankingOR.getProperty("BNK_AccountBalance_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjQueryType, Opt));

        }
        if (Value.equalsIgnoreCase("Bank") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User select Bank from OPtion ......");

            String vObjSelectBank = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_Bank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectBank, Opt));

        }
        if (Value.equalsIgnoreCase("Rows Per Page") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User select Rows Per Page from OPtion ......");

            String vObjSelectBank = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_RowPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectBank, Opt));

        }
        if (Value.equalsIgnoreCase("Payment Type") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User select PAIN OPtion ......");

            String vPymtEntriesPymtType = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_PaymentType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPymtEntriesPymtType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vPymtEntriesPymtType, Opt));

        }
        if (Value.equalsIgnoreCase("Status") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User select Initiated Status ......");

            String vQMIncomingQueriesStatus = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_SelectStatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQueriesStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMIncomingQueriesStatus, Opt));

        }
        if (Value.equalsIgnoreCase("State") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User select Import Status ......");

            String vQMIncomingQueriesState = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_SelectState");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQueriesState, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMIncomingQueriesState, Opt));

        }
        if (Value.equalsIgnoreCase("Status") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User select Initiated Status ......");

            String vQMIncomingQueriesStatus = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_SelectStatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQueriesStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMIncomingQueriesStatus, Opt));

        }
        if (Value.equalsIgnoreCase("State") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User select Import Status ......");

            String vQMIncomingQueriesState = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_SelectState");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQueriesState, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMIncomingQueriesState, Opt));

        }
        if (Value.equalsIgnoreCase("QueryType") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User select QueryType from drop down ......");

            String vQMQueryType = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ImportQuery_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMQueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMQueryType, Opt));

        }
        if (Value.equalsIgnoreCase("Raise Query Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User select QueryType from drop down ......");

            String vQMQueryType = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaisedQuery_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMQueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMQueryType, Opt));
        }
        if (Value.equalsIgnoreCase("QueryType") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User select QueryType from drop down ......");

            String vQMIncomingQueryType = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ImportQuery_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMIncomingQueryType, Opt));

        }
        if (Value.equalsIgnoreCase("Raise Query Type") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User select Cancellation request from payment out page ......");

            String vBNK_QM_QueryType = Constants.QueryManagementOR.getProperty("BNK_QM_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_QueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_QM_QueryType, Opt));

        }
        if (Value.equalsIgnoreCase("Sub type") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User select Cancellation request from payment out page ......");

            String vBNK_QM_SubType = Constants.QueryManagementOR.getProperty("BNK_QM_SubType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_SubType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_QM_SubType, Opt));

        }
        if (Value.equalsIgnoreCase("QueryType Answer") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User select QueryType Answer from drop down ......");

            String vQMIncomingQuery_RespondQueryType = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_RespondQuery_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQuery_RespondQueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMIncomingQuery_RespondQueryType, Opt));
        }
        if (Value.equalsIgnoreCase("Answer Code") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User select Answer Code  from drop down ......");

            String vQMIncomingQuery_RespondQueryAnswerCode = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_RespondQuery_AnswerType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQuery_RespondQueryAnswerCode, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMIncomingQuery_RespondQueryAnswerCode, Opt));

        }
        if (Value.equalsIgnoreCase("Bank") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User select Bank from drop down ......");

            String vQMRaiseQueryBankType = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_Bank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMRaiseQueryBankType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMRaiseQueryBankType, Opt));
        }
        if (Value.equalsIgnoreCase("Sender BIC Code") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User select Sender BIC Code from drop down ......");

            String vQMRaiseQuerySenderBicCode = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_SenderBICCode");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMRaiseQuerySenderBicCode, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMRaiseQuerySenderBicCode, Opt));
        }
        if (Value.equalsIgnoreCase("Authorise Type") && Menu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User select Reject ......");

            String vQMAuthoriseQuery_Type = Constants.QueryManagementOR.getProperty("BNK_QM_PendingAuthorise_AuthoriseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMAuthoriseQuery_Type, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMAuthoriseQuery_Type, Opt));

        }
        if (Value.equalsIgnoreCase("Institution") && Menu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User select Institution ......");

            String vQMAuthoriseQuery_Institution = Constants.QueryManagementOR.getProperty("BNK_QM_PendingAuthorise_AuthoriseQuery_SelectInstitution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMAuthoriseQuery_Institution, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vQMAuthoriseQuery_Institution, Opt));

        }
        if (Value.equalsIgnoreCase("Select Bank") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User select Bank from OPtion ......");

            String vObjSelectBank1 = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank1, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectBank1, Opt));

        }
    }


    @And("^User select (Organization|Treasure Category|SellCurr|BuyCurr|bank|Sell Currency|Buy Currency|Tenor Value|Treasury Category|Value Date|Value Date1|Currency|Event|IsSellable|IsBookable|IsBuyable|QueryType|Currencies Direct|Institution|FCG|Bank|OrgName|CLE) \"([^\"]*)\" from (B2B|Dashboard|Spot Forward Deal|TradingDashBoardReport|BlotterReport|option|B2B Dashboard|Spot deal booking|Swap Deal Booking|RFQ|Event Log|OrgCurrency Details|One Time Configurable|Account Balance|Bank Account|Balance Exceptions|Balance Entry) page$")
    public void userSelectOrganizationFromBlotterReportPage(String Value, String Opt, String Menu) throws Throwable {
        key.pause("2", "");
        if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User select Organization ......");

            String vObjSelectOrganization = Constants.B2BOR.getProperty("B2B_BlotterReport_SelectOrganization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectOrganization, Opt));
        }
        if (Value.equalsIgnoreCase("Treasure Category") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User select Treasure Category ......");

            String vObjSelectTreasureCategory = Constants.B2BOR.getProperty("B2B_BlotterReport_SelectTreasureCategory");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectTreasureCategory, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectTreasureCategory, Opt));
        }
        if (Value.equalsIgnoreCase("SellCurr") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User select sell currency on search page ......");

            String vObjSelectSellCurr = Constants.B2BOR.getProperty("B2B_BlotterReport_SelectSellCurr");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectSellCurr, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectSellCurr, Opt));
        }
        if (Value.equalsIgnoreCase("BuyCurr") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User select sell currency on search page ......");

            String vObjSelectBuyCurr = Constants.B2BOR.getProperty("B2B_BlotterReport_SelectBuyCurr");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBuyCurr, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectBuyCurr, Opt));
        }
        if (Value.equalsIgnoreCase("bank") && Menu.equalsIgnoreCase("option")) {
            LogCapture.info("User select BAnk from OPtion ......");

            String vObjSelectBank = Constants.B2BOR.getProperty("SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectBank, Opt));

        }
        if (Value.equalsIgnoreCase("Sell Currency") && Menu.equalsIgnoreCase("option")) {
            LogCapture.info("User select Sell Currency from OPtion ......");

            String vObjSelectCurrencySell = Constants.B2BOR.getProperty("SelectCurrencySell");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCurrencySell, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectCurrencySell, Opt));

        }
        if (Value.equalsIgnoreCase("Buy Currency") && Menu.equalsIgnoreCase("option")) {
            LogCapture.info("User select Buy Currency from OPtion ......");

            String vObjSelectCurrencyBuy = Constants.B2BOR.getProperty("SelectCurrencyBuy");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCurrencyBuy, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectCurrencyBuy, Opt));

        }
        if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("B2B Dashboard")) {
            LogCapture.info("User selects Currencies Direct Organization ......");

            String vObjectB2BPage = Constants.B2BOR.getProperty("B2BPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectB2BPage, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectB2BPage, Opt));

        }
        if (Value.equalsIgnoreCase("Tenor Value") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User selects Tenor Value ......");

            String vObjSpotDealBookingTenorValue = Constants.B2BOR.getProperty("SpotDealBooking_TenorValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBookingTenorValue, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSpotDealBookingTenorValue, Opt));
        }
        if (Value.equalsIgnoreCase("Buy Currency") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User selects Buy Currency ......");

            String vObjSpotDealBooingCCYBuy = Constants.B2BOR.getProperty("SpotDealBooking_CCYBuy");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingCCYBuy, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSpotDealBooingCCYBuy, Opt));
        }
        if (Value.equalsIgnoreCase("Sell Currency") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User selects Sell Currency ......");

            String vObjSpotDealBooingCCYSell = Constants.B2BOR.getProperty("SpotDealBooking_CCYSell");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingCCYSell, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSpotDealBooingCCYSell, Opt));
        }
        if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User selects Organization ......");

            String vObjSpotDealBooingOrganization = Constants.B2BOR.getProperty("SpotDealBooking_Organization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSpotDealBooingOrganization, Opt));
        }
        if (Value.equalsIgnoreCase("Treasury Category") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User selects Treasury Category ......");

            String vObjSpotDealBooingTreasuryCategory = Constants.B2BOR.getProperty("SpotDealBooking_TreasuryCategory");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingTreasuryCategory, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSpotDealBooingTreasuryCategory, Opt));
        }
        if (Value.equalsIgnoreCase("Value Date") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Value Date ......");
            String vObjSwapDeal_ValueDate1 = Constants.B2BOR.getProperty("SwapDeal_ValueDate1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_ValueDate1, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSwapDeal_ValueDate1, Opt));


        }
        if (Value.equalsIgnoreCase("Value Date1") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Value Date1 ......");
            String vObjSwapDeal_ValueDate2 = Constants.B2BOR.getProperty("SwapDeal_ValueDate2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_ValueDate2, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSwapDeal_ValueDate2, Opt));


        }
        if (Value.equalsIgnoreCase("Buy Currency") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Buy Currency ......");

            String vObjSwapDeal_Buy = Constants.B2BOR.getProperty("SwapDeal_Buy");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_Buy, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSwapDeal_Buy, Opt));

        }
        if (Value.equalsIgnoreCase("Sell Currency") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Sell Currency ......");

            String vObjSwapDeal_Sell = Constants.B2BOR.getProperty("SwapDeal_Sell");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_Sell, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSwapDeal_Sell, Opt));

        }
        if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Organization ......");

            String vObjSpotDealBooingOrganization = Constants.B2BOR.getProperty("SpotDealBooking_Organization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSpotDealBooingOrganization, Opt));

        }
        if (Value.equalsIgnoreCase("Currency") && Menu.equalsIgnoreCase("Event Log")) {
            LogCapture.info("User select currency from drop down ......");

            String vObjCurrency = Constants.RFQOR.getProperty("RFQ_EventLog_Currency");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrency, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjCurrency, Opt));

        }
        if (Value.equalsIgnoreCase("Event") && Menu.equalsIgnoreCase("Event Log")) {
            LogCapture.info("User select event from drop down ......");

            String vObjEvent = Constants.RFQOR.getProperty("RFQ_EventLog_Event");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEvent, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjEvent, Opt));
        }
        if (Value.equalsIgnoreCase("IsSellable") && Menu.equalsIgnoreCase("OrgCurrency Detailsg")) {
            LogCapture.info("User select IsSellable from drop down ......");

            String vObjIsSellable = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_IsSelleable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIsSellable, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjIsSellable, Opt));
        }
        if (Value.equalsIgnoreCase("IsBookable") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User select IsBookable from drop down ......");

            String vObjIsBookable = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_IsBookable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIsBookable, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjIsBookable, Opt));
        }
        if (Value.equalsIgnoreCase("IsBuyable") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User select IsBuyable from drop down ......");

            String vObjIsBuyable = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_IsBuyable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIsBuyable, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjIsBuyable, Opt));
        }
        if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("One Time Configurable")) {
            LogCapture.info("User select Organization from drop down ......");

            String vObjOrganization = Constants.RFQOR.getProperty("RFQ_OneTimeScheduler_SelectOrg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjOrganization, Opt));
        }
        if (Value.equalsIgnoreCase("QueryType") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User select QueryType from drop down ......");

            String vObjQueryType = Constants.BankingOR.getProperty("BNK_AccountBalance_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjQueryType, Opt));
        }
        if (Value.equalsIgnoreCase("Institution") && Menu.equalsIgnoreCase("Bank Account ")) {
            LogCapture.info("User selects FCG Institution ......");

            String vFCG = Constants.BankingOR.getProperty("BNK_BankAccount_InstituteValue_FCG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFCG, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vFCG, Opt));

        }
        if (Value.equalsIgnoreCase("Institution") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User selects FCG Institution ......");

            String vFCG = Constants.BankingOR.getProperty("BNK_BankAccount_InstituteValue_FCG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFCG, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vFCG, Opt));

        }
        if (Value.equalsIgnoreCase("Bank") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User select Bank from OPtion ......");

            String vObjSelectBank = Constants.BankingOR.getProperty("BNK_BalanceEntries_SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectBank, Opt));


        }
        if (Value.equalsIgnoreCase("CLE") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User select CLE from Option ......");

            String vObjSelectCLE = Constants.BankingOR.getProperty("BNK_BalanceEntries_SelectCLE");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCLE, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectCLE, Opt));


        }
        if (Value.equalsIgnoreCase("QueryType") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User select QueryType from drop down ......");

            String vObjQueryType = Constants.BankingOR.getProperty("BNK_AccountBalance_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjQueryType, Opt));
        }
        if (Value.equalsIgnoreCase("OrgName") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User select QueryType from drop down ......");

            String vObjQueryType = Constants.BankingOR.getProperty("BNK_AccountBalance_QueryType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueryType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjQueryType, Opt));
        }
    }


    @And("^User click on (GetBlotter|Treasure Category|Update|Submit|DealDetails|ChangePreference|ProfitChangePreference|ApplyChangePreference|ExportToExcel|PrintPdf|Search|Save|Select Organization|Select Bank|Select Sell Currency|Select Buy Currency|Delete|Tenor Value|Treasury category|Sell Currency|Buy Currency|Organization|Fetch Rate|Book Deal|Print|Value Date|Value Date1|By Currency|By Date|By Event|By Organization|OrgName|Edit|Add|Close|Schedule|Enable|Disable|AccBalanceRecord|Statement Number ChangePreference|Reset Filter|Statement Date ChangePreference|BalExceptionRecord|Select Institution|Currencies Direct|FCG|Checkbox|PrintPdf Icon|Institution|Add Button|TypeChangePreference) from (B2B|Dashboard|Spot Forward Deal|TradingDashBoardReport|BlotterReport|B2B Dashboard|Option|B2B Screen|Spot deal booking|Swap Deal Booking|Event Log|Organization Details|Opening Closing|OrgCurrency Details|One Time Configurable|Rule Engine|Account Balance|Balance Exception|Balance Entry|Select Institution|Bank Account|Trading Dashboard Report|Swap deal booking) page$")
    public void userClickOnGetBlotterFromBlotterReportPage(String Value, String Menu) throws Throwable {
        key.pause("6", "");
        if (Value.equalsIgnoreCase("GetBlotter") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on GetBlotter ......");


            String vObjectGetBlotter = Constants.B2BOR.getProperty("B2B_BlotterReport_GetBlotter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectGetBlotter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectGetBlotter, ""));

        } else if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on Organization ......");

            String vObjOrganization = Constants.B2BOR.getProperty("B2B_BlotterReport_SelectOrganization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrganization, ""));

        } else if (Value.equalsIgnoreCase("Treasure Category") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on Treasure Category ......");

            String vObjTreasureCategory = Constants.B2BOR.getProperty("B2B_BlotterReport_SelectTreasureCategory");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTreasureCategory, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjTreasureCategory, ""));

        } else if (Value.equalsIgnoreCase("Update") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on Update button ......");

            String vObjBlotterUpdate = Constants.B2BOR.getProperty("B2B_BlotterReport_Update");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlotterUpdate, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBlotterUpdate, ""));

        } else if (Value.equalsIgnoreCase("Search") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on Search button ......");

            String vObjBlotterSearch = Constants.B2BOR.getProperty("B2B_BlotterReport_Search");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlotterSearch, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBlotterSearch, ""));
        } else if (Value.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on Submit button ......");

            String vObjBlotterSubmit = Constants.B2BOR.getProperty("B2B_BlotterReport_Submit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlotterSubmit, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBlotterSubmit, ""));
        } else if (Value.equalsIgnoreCase("DealDetails") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on deal details button ......");

            String vObjDealDetails = Constants.B2BOR.getProperty("B2B_BlotterReport_DealDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjDealDetails, ""));
        } else if (Value.equalsIgnoreCase("ChangePreference") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjChangePreference = Constants.B2BOR.getProperty("B2B_BlotterReport_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChangePreference, ""));
            WebElement ele = Constants.driver.findElement(By.xpath("//a[@id='chooseBalanceColumn']"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        } else if (Value.equalsIgnoreCase("ChangePreference") && Menu.equalsIgnoreCase("Trading Dashboard Report")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjChangePreference = Constants.B2BOR.getProperty("B2B_BlotterReport_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChangePreference, ""));
            WebElement ele = Constants.driver.findElement(By.xpath("//a[@id='chooseBalanceColumn']"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        } else if (Value.equalsIgnoreCase("ProfitChangePreference") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User deselect profit change preference at top right corner.....");

            String vObjProfitChangePreference = Constants.B2BOR.getProperty("B2B_BlotterReport_ChangePreferenceProfitCheckbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProfitChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjProfitChangePreference, ""));
        } else if (Value.equalsIgnoreCase("TypeChangePreference") && Menu.equalsIgnoreCase("Trading Dashboard Report")) {
            LogCapture.info("User deselect Type change preference at top right corner.....");

            String vTypeChangePreference = Constants.B2BOR.getProperty("B2B_TradingDashboardReport_TypeChangepreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTypeChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vTypeChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ApplyChangePreference") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User click on apply change preference at top right corner.....");

            String vObjApplyChangePreference = Constants.B2BOR.getProperty("B2B_BlotterReport_ApplyChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjApplyChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ApplyChangePreference") && Menu.equalsIgnoreCase("Trading Dashboard Report")) {
            LogCapture.info("User click on apply change preference at top right corner.....");

            String vObjApplyChangePreference = Constants.B2BOR.getProperty("B2B_BlotterReport_ApplyChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjApplyChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User click on export to excel at top right corner.....");

            String vObjExportToExcel = Constants.B2BOR.getProperty("B2B_BlotterReport_ExportToExcel");
            WebElement ele = Constants.driver.findElement(By.xpath(vObjExportToExcel));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        } else if (Value.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User click on print pdf at top right corner.....");

            String vObjPrintPdf = Constants.B2BOR.getProperty("B2B_BlotterReport_PrintPdf");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPrintPdf, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPrintPdf, ""));
        } else if (Value.equalsIgnoreCase("Search") && Menu.equalsIgnoreCase("B2B Dashboard")) {
            LogCapture.info("User Click on Search Button ......");

            String vObjectSearchButton = Constants.B2BOR.getProperty("SearchButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectSearchButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectSearchButton, ""));

        } else if (Value.equalsIgnoreCase("Save") && Menu.equalsIgnoreCase("Option")) {
            LogCapture.info("User Click on Save Button ......");

            String vObjSaveButton = Constants.B2BOR.getProperty("SaveButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSaveButton, ""));

        } else if (Value.equalsIgnoreCase("Select Organization") && Menu.equalsIgnoreCase("B2B Dashboard")) {
            LogCapture.info("User Click on Select Organization ......");

            String vObjB2BPage = Constants.B2BOR.getProperty("B2BPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjB2BPage, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BPage, ""));

        } else if (Value.equalsIgnoreCase("Select Bank") && Menu.equalsIgnoreCase("Option")) {
            LogCapture.info("User Click on Select Bank ......");

            String vObjSelectBank = Constants.B2BOR.getProperty("SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectBank, ""));

        } else if (Value.equalsIgnoreCase("Select Sell Currency") && Menu.equalsIgnoreCase("Option")) {
            LogCapture.info("User Click on Sell Currency ......");

            String vObjSelectCurrencySell = Constants.B2BOR.getProperty("SelectCurrencySell");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCurrencySell, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectCurrencySell, ""));

        } else if (Value.equalsIgnoreCase("Select Buy Currency") && Menu.equalsIgnoreCase("Option")) {
            LogCapture.info("User Click on Buy Currency ......");

            String vObjSelectCurrencyBuy = Constants.B2BOR.getProperty("SelectCurrencyBuy");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCurrencyBuy, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectCurrencyBuy, ""));

        } else if (Value.equalsIgnoreCase("Delete") && Menu.equalsIgnoreCase("B2B Dashboard")) {
            LogCapture.info("User Click on Delete ......");

            String vObjDeleteProviderGBPINR = Constants.B2BOR.getProperty("DeleteProviderGBPINR");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteProviderGBPINR, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjDeleteProviderGBPINR, ""));

        } else if (Value.equalsIgnoreCase("Delete") && Menu.equalsIgnoreCase("B2B Screen")) {
            LogCapture.info("User Click on Delete ......");

            String vObjDeleteProviderGBPAED = Constants.B2BOR.getProperty("DeleteProviderGBPAED");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteProviderGBPAED, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjDeleteProviderGBPAED, ""));

        } else if (Value.equalsIgnoreCase("Tenor value") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on Tenor VAlue ......");

            String vObjSpotDealBookingTenorValue = Constants.B2BOR.getProperty("SpotDealBooking_TenorValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBookingTenorValue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBookingTenorValue, ""));

        } else if (Value.equalsIgnoreCase("Buy Currency") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on Buy Currency ......");

            String vObjSpotDealBooingCCYBuy = Constants.B2BOR.getProperty("SpotDealBooking_CCYBuy");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingCCYBuy, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBooingCCYBuy, ""));

        } else if (Value.equalsIgnoreCase("Sell Currency") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on Sell Currency ......");

            String vObjSpotDealBooingCCYSell = Constants.B2BOR.getProperty("SpotDealBooking_CCYSell");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingCCYSell, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBooingCCYSell, ""));

        } else if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on Organization ......");

            String vObjSpotDealBooingOrganization = Constants.B2BOR.getProperty("SpotDealBooking_Organization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBooingOrganization, ""));

        } else if (Value.equalsIgnoreCase("Treasury category") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on Treasury category ......");

            String vObjSpotDealBooingTreasuryCategory = Constants.B2BOR.getProperty("SpotDealBooking_TreasuryCategory");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingTreasuryCategory, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBooingTreasuryCategory, ""));

        } else if (Value.equalsIgnoreCase("Fetch Rate") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on Fetch Rate ......");

            //String vObjSpotDealBooingFetchRate = Constants.B2BOR.getProperty("SpotDealBooking_FetchRate");

            WebElement ele = Constants.driver.findElement(By.xpath("//*[@name='fetchRate']"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);


        } else if (Value.equalsIgnoreCase("Book Deal") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on Fetch Rate ......");

            //String vObjSpotDealBooingFetchRate = Constants.B2BOR.getProperty("SpotDealBooking_FetchRate");

            WebElement ele = Constants.driver.findElement(By.xpath("//*[@id='stopForwardDealRateTable']//tr[2]//td[16]//a//input[@id='bookDeal1']"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        } else if (Value.equalsIgnoreCase("Book Deal") && Menu.equalsIgnoreCase("Swap deal booking")) {
            LogCapture.info("User Click on Fetch Rate ......");

            //String vObjSpotDealBooingFetchRate = Constants.B2BOR.getProperty("SpotDealBooking_FetchRate");

            WebElement ele = Constants.driver.findElement(By.xpath("(//input[@id='bookDeal1'])[1]"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);

        } else if (Value.equalsIgnoreCase("Print") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on Print ......");
            String vObjPrint = Constants.B2BOR.getProperty("Print");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPrint, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPrint, ""));

//                        String vObjCancel = Constants.B2BOR.getProperty("Print");
//                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPrint, ""));
//                        Assert.assertEquals("PASS", Constants.key.click(vObjPrint, ""));

        } else if (Value.equalsIgnoreCase("Value Date") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Value Date ......");
            String vObjSwapDeal_ValueDate1 = Constants.B2BOR.getProperty("SwapDeal_ValueDate1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_ValueDate1, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapDeal_ValueDate1, ""));


        } else if (Value.equalsIgnoreCase("Value Date1") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Value Date1 ......");
            String vObjSwapDeal_ValueDate2 = Constants.B2BOR.getProperty("SwapDeal_ValueDate2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_ValueDate2, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapDeal_ValueDate2, ""));


        } else if (Value.equalsIgnoreCase("Fetch Rate") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Fetch Rate ......");

            //String vObjSpotDealBooingFetchRate=Constants.B2BOR.getProperty("SpotDealBooking_FetchRate");

            WebElement ele = Constants.driver.findElement(By.xpath("//*[@name='fetchRate']"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);

        } else if (Value.equalsIgnoreCase("Buy Currency") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Buy Currency ......");

            String vObjSwapDeal_Buy = Constants.B2BOR.getProperty("SwapDeal_Buy");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_Buy, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapDeal_Buy, ""));

        } else if (Value.equalsIgnoreCase("Sell Currency") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Sell Currency ......");

            String vObjSwapDeal_Sell = Constants.B2BOR.getProperty("SwapDeal_Sell");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_Sell, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapDeal_Sell, ""));

        } else if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Organization ......");

            String vObjSpotDealBooingOrganization = Constants.B2BOR.getProperty("SpotDealBooking_Organization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBooingOrganization, ""));

        } else if (Value.equalsIgnoreCase("Book Deal") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Book Deal ......");


            WebElement ele = Constants.driver.findElement(By.xpath("//*[@id='swapDealRateTable']//tr[3]//td[23]//a//input[@id='bookDeal1']"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);


        } else if (Value.equalsIgnoreCase("Print") && Menu.equalsIgnoreCase("Swap Deal Booking")) {
            LogCapture.info("User Click on Print ......");
            String vObjPrint = Constants.B2BOR.getProperty("Print");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPrint, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPrint, ""));


        } else if (Value.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Trading Dashboard Report")) {
            LogCapture.info("User Click on Print ......");

            String vTDReportPrint = Constants.B2BOR.getProperty("B2B_PrintIcon");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTDReportPrint, ""));
            Assert.assertEquals("PASS", Constants.key.click(vTDReportPrint, ""));

            LogCapture.info("User Click on Printpdf ......");

        } else if (Value.equalsIgnoreCase("By Currency") && Menu.equalsIgnoreCase("Event Log")) {
            LogCapture.info("User Click on By Currency from event log page ......");

            String vObjByCurrency = Constants.RFQOR.getProperty("RFQ_EventLog_ByCurrency");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjByCurrency, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjByCurrency, ""));

        } else if (Value.equalsIgnoreCase("By Date") && Menu.equalsIgnoreCase("Event Log")) {
            LogCapture.info("User Click on By Date from event log page ......");

            String vObjByDate = Constants.RFQOR.getProperty("RFQ_EventLog_ByDate");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjByDate, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjByDate, ""));

        } else if (Value.equalsIgnoreCase("By Event") && Menu.equalsIgnoreCase("Event Log")) {
            LogCapture.info("User Click on By Event from event log page ......");

            String vObjByEvent = Constants.RFQOR.getProperty("RFQ_EventLog_ByEvent");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjByEvent, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjByEvent, ""));

        } else if (Value.equalsIgnoreCase("By Organization") && Menu.equalsIgnoreCase("Event Log")) {
            LogCapture.info("User Click on By Organization from event log page ......");

            String vObjSelect_OraganizationCheckbox = Constants.RFQOR.getProperty("Select_OraganizationCheckbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelect_OraganizationCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelect_OraganizationCheckbox, ""));

        } else if (Value.equalsIgnoreCase("Search") && Menu.equalsIgnoreCase("Event Log")) {
            LogCapture.info("User Click on Search button from Event log page......");

            String vObjEventSearch = Constants.RFQOR.getProperty("RFQ_EventLog_Search");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEventSearch, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjEventSearch, ""));
        } else if (Value.equalsIgnoreCase("OrgName") && Menu.equalsIgnoreCase("Organization Details")) {
            LogCapture.info("User Click on OrgName from Organization Details page ......");

            String vObjOrgName = Constants.RFQOR.getProperty("RFQ_OrganizationDetails_OrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrgName, ""));
        } else if (Value.equalsIgnoreCase("Edit") && Menu.equalsIgnoreCase("Organization Details")) {
            LogCapture.info("User Click on edit from Organization Details page ......");
            String vObjEditDetails = Constants.RFQOR.getProperty("RFQ_OrganizationDetails_Edit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEditDetails, ""));
            key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjEditDetails, ""));

        } else if (Value.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Organization Details")) {
            LogCapture.info("User Click on submit from Organization Details page ......");

            String vObjSubmitDetails = Constants.RFQOR.getProperty("RFQ_OrganizationDetails_Submit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSubmitDetails, ""));
        } else if (Value.equalsIgnoreCase("OrgName") && Menu.equalsIgnoreCase("Opening Closing")) {
            LogCapture.info("User Click on OrgName from Opening Closing page ......");

            String vObjOrgName = Constants.RFQOR.getProperty("RFQ_OpeningClosingDetails_OrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrgName, ""));
        } else if (Value.equalsIgnoreCase("Edit") && Menu.equalsIgnoreCase("Opening Closing")) {
            LogCapture.info("User Click on edit from Opening Closing page ......");
            String vObjEditDetails = Constants.RFQOR.getProperty("RFQ_OpeningClosingDetails_Edit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEditDetails, ""));
            key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjEditDetails, ""));

        } else if (Value.equalsIgnoreCase("OrgName") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User Click on OrgName from OrgCurrency Details page ......");

            String vObjOrgName = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_OrgSelect");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrgName, ""));

        } else if (Value.equalsIgnoreCase("Edit") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User Click on edit from OrgCurrency Details page ......");
            String vObjEditDetails = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_Edit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEditDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjEditDetails, ""));

        } else if (Value.equalsIgnoreCase("Add") && Menu.equalsIgnoreCase("One Time Configurable")) {
            LogCapture.info("User Click on Add from One Time Configurable page ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjAdd = Constants.RFQOR.getProperty("RFQ_OneTimeScheduler_ADD");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAdd, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAdd, ""));

        } else if (Value.equalsIgnoreCase("Close") && Menu.equalsIgnoreCase("One Time Configurable")) {
            LogCapture.info("User Click on Close from One Time Configurable page ......");
            String vObjCloseDate = Constants.RFQOR.getProperty("RFQ_OneTimeScheduler_CloseDate");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCloseDate, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCloseDate, ""));

        } else if (Value.equalsIgnoreCase("Enable") || Value.equalsIgnoreCase("Disable") && Menu.equalsIgnoreCase("Rule Engine")) {
            LogCapture.info("User Click on " + Value + " from Rule Engine page ......");
            String vObjEnable = Constants.RFQOR.getProperty("RFQ_RuleEngine_CheckBox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEnable, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjEnable, ""));

        } else if (Value.equalsIgnoreCase("AccBalanceRecord") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Click on AccBalanceRecord from Account Balance page ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjAccBalanceRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_RecordSelect");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAccBalanceRecord, ""));
            //test
            String vObjBNK_AccountBalance_List = Constants.BankingOR.getProperty("BNK_AccountBalance_List");
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjBNK_AccountBalance_List));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 1; i <= listOfElements.size(); i++) {
//                String SelectRecord = "//table[@id='balanceDIV']/tbody/tr["+(i)+"]";
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectRecord, ""));
//                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
//                LogCapture.info("User Click on 1 record ......");
//                String vObjBNK_AccountBalance_AccDetails = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails");
////                List<WebElement> listOfElement = Constants.driver.findElements(By.xpath(vObjBNK_AccountBalance_AccDetails));
////                LogCapture.info("Total number of elements present: " + listOfElement.size());
//
//                LogCapture.info("User Click on Available AccBalanceRecord ......");
//                break;
//
                String SelectRecord1 = "//table[@id='balanceDIV']/tbody/tr[" + (i) + "]/td[1]";//table[@id='balanceDIV']/tbody/tr[1]/td[1]
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectRecord1, ""));
                key.pause("7", "");
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord1, ""));
                LogCapture.info("User Click on Available 1 rec ......");
                key.pause("4", "");
                String vObjBNK_AccountBalance_AccDetails = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails");
                if (Constants.driver.findElement(By.xpath(vObjBNK_AccountBalance_AccDetails)).isSelected()) {
                    LogCapture.info("User Click on Available AccBalanceRecord ......");
                    break;
                }
            }

        } else if (Value.equalsIgnoreCase("AccBalanceRecord") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User Click on AccBalanceRecord from Balance Exception page ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjAccBalanceRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_RecordSelect");
            Assert.assertEquals("PASS", Constants.key.click(vObjAccBalanceRecord, ""));

        } else if (Value.equalsIgnoreCase("ChangePreference") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ChangePreference") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjChangePreference, ""));
        } else if (Value.equalsIgnoreCase("Statement Number ChangePreference") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User deselect Statement Number ChangePreference change preference at top right corner.....");

            String vObjStatementDateChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreferenceStatementDate");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatementDateChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjStatementDateChangePreference, ""));
            String vObjStatementNumChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreferenceStatementNum");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatementNumChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjStatementNumChangePreference, ""));
        } else if (Value.equalsIgnoreCase("Statement Number ChangePreference") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User deselect Statement Number ChangePreference change preference at top right corner.....");

            String vObjStatementNumChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreferenceStatementNum");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatementNumChangePreference, ""));
            if (Constants.key.verifyElementProperties(vObjStatementNumChangePreference, "unselected").equalsIgnoreCase("PASS")) {
                Constants.key.click(vObjStatementNumChangePreference, "");
            }
            Assert.assertEquals("PASS", Constants.key.click(vObjStatementNumChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ApplyChangePreference") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjApplyChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ApplyChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjApplyChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ApplyChangePreference") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjApplyChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ApplyChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjApplyChangePreference, ""));
        } else if (Value.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Click on PrintPdf at top right corner.....");

            String vObjPrintPdf = Constants.BankingOR.getProperty("BNK_AccountBalance_ExportToPdf");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPrintPdf, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPrintPdf, ""));


        } else if (Value.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User Click on PrintPdf at top right corner.....");

            String vObjPrintPdf = Constants.BankingOR.getProperty("BNK_BalanceException_ExportToPdf");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPrintPdf, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPrintPdf, ""));

        } else if (Value.equalsIgnoreCase("Reset Filter") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Click on reset filter at top right corner.....");

            String vObjResetFilter = Constants.BankingOR.getProperty("BNK_AccountBalance_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjResetFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjResetFilter, ""));
        } else if (Value.equalsIgnoreCase("BalExceptionRecord") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User Click on BalExceptionRecord from Balance Exception page ......");
            String vObjRecordSelect = Constants.BankingOR.getProperty("BNK_BalanceException_RecordSelect");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRecordSelect, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjRecordSelect, ""));
        } else if (Value.equalsIgnoreCase("Select Institution") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on Select Institution.....");

            String vSelectInstitution = Constants.BankingOR.getProperty("BNK_BankAccount_Institution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectInstitution, ""));
        } else if (Value.equalsIgnoreCase("Currencies Direct") && Menu.equalsIgnoreCase("Select Institution")) {
            LogCapture.info("User select Currencies Direct from  Select Institution.....");

            String vObjCurrenciesDirect = Constants.BankingOR.getProperty("BNK_BalanceException_CurrenciesDirect");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesDirect, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCurrenciesDirect, ""));
        } else if (Value.equalsIgnoreCase("Print") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on Print ......");

            String vObjBankAccountPrint = Constants.BankingOR.getProperty("BNK_BAnkAccount_PrintIcon");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankAccountPrint, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBankAccountPrint, ""));

        } else if (Value.equalsIgnoreCase("Reset Filter") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on reset filter at top right corner.....");

            String vObjResetFilter1 = Constants.BankingOR.getProperty("BNK_BankAccount_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjResetFilter1, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjResetFilter1, ""));
        } else if (Value.equalsIgnoreCase("FCG") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User select FCG from  Select Institution.....");

            String vObjFCG = Constants.BankingOR.getProperty("BNK_BankAccount_InstituteValue_FCG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFCG, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFCG, ""));

        } else if (Value.equalsIgnoreCase("ChangePreference") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjChangePreference, ""));
        } else if (Value.equalsIgnoreCase("Print") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User Click on Print ......");

            String vObjBalanceEntriesPrint = Constants.BankingOR.getProperty("BNK_BalanceEntries_PrintIcon");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBalanceEntriesPrint, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBalanceEntriesPrint, ""));

        } else if (Value.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User Select the Record.....");

            String vSelectCheckbox = Constants.BankingOR.getProperty("BNK_BalanceEntries_Checkbox1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectCheckbox, ""));

        } else if (Value.equalsIgnoreCase("Statement Date ChangePreference") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User deselect Statement Date ChangePreference change preference at top right corner.....");

            String vObjStatementDateChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreferenceStatementDate");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatementDateChangePreference, ""));
            if (Constants.key.verifyElementProperties(vObjStatementDateChangePreference, "unselected").equalsIgnoreCase("PASS")) {
                Constants.key.click(vObjStatementDateChangePreference, "");
            }
            Assert.assertEquals("PASS", Constants.key.click(vObjStatementDateChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ApplyChangePreference") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User Click on Apply change preference at top right corner.....");

            String vObjApplyChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ApplyChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjApplyChangePreference, ""));
        } else if (Value.equalsIgnoreCase("Select Institution") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on Select Institution.....");

            String vSelectInstitution = Constants.BankingOR.getProperty("BNK_BankAccount_Institution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectInstitution, ""));


        } else if (Value.equalsIgnoreCase("FCG") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User select FCG from  Select Institution.....");

            String vObjFCG = Constants.BankingOR.getProperty("BNK_BankAccount_InstituteValue_FCG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFCG, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFCG, ""));

        } else if (Value.equalsIgnoreCase("Select Bank") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User Click on Select Bank ......");

            String vBalanceEntriesSelectBank = Constants.BankingOR.getProperty("BNK_BalanceEntries_SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBalanceEntriesSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBalanceEntriesSelectBank, ""));
            LogCapture.info("Available......");

        } else if (Value.equalsIgnoreCase("Institution") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on Institution Table Row 1 from Bank Account page ......");

            String vObjInstitutionTable1 = Constants.BankingOR.getProperty("BNK_InstitutionTable_Row1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstitutionTable1, ""));
            //Assert.assertEquals("PASS", Constants.key.click(vObjInstitutionTable1, ""));
            WebElement ele = Constants.driver.findElement(By.xpath(vObjInstitutionTable1));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

        } else if (Value.equalsIgnoreCase("Edit") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on edit from Bank Account page ......");
            String vObjEditDetails = Constants.BankingOR.getProperty("BNK_BankAccount_Edit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEditDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjEditDetails, ""));

        } else if (Value.equalsIgnoreCase("ChangePreference") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjChangePreference = Constants.BankingOR.getProperty("BNK_BankAccount_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjChangePreference, ""));
        } else if (Value.equalsIgnoreCase("Statement Number ChangePreference") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User deselect Statement Number ChangePreference change preference at top right corner.....");

            String vObjStatementNumChangePreference = Constants.BankingOR.getProperty("BNK_BankAccount_ChangePreferenceStatementNum");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatementNumChangePreference, ""));
            if (Constants.key.verifyElementProperties(vObjStatementNumChangePreference, "unselected").equalsIgnoreCase("PASS")) {
                Constants.key.click(vObjStatementNumChangePreference, "");
            }
            Assert.assertEquals("PASS", Constants.key.click(vObjStatementNumChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ApplyChangePreference") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjApplyChangePreference = Constants.BankingOR.getProperty("BNK_BankAccount_ApplyChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjApplyChangePreference, ""));
        } else if (Value.equalsIgnoreCase("Reset Filter") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User Click on reset filter at top right corner.....");

            String vObjResetFilter = Constants.BankingOR.getProperty("BNK_BalanceException_ResetFilter");
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjResetFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjResetFilter, ""));
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

        } else if (Value.equalsIgnoreCase("Add Button") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on Add Button at top right corner.....");

            String vBNK_BankAccount_AddBtn = Constants.BankingOR.getProperty("BNK_BankAccount_AddBtn");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_BankAccount_AddBtn, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_BankAccount_AddBtn, ""));
        } else if (Value.equalsIgnoreCase("Select Bank") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User Click on Select Bank ......");

            String vObjSelectBank = Constants.BankingOR.getProperty("BNK_BalanceEntries_SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectBank, ""));

        } else if (Value.equalsIgnoreCase("Organization") && Menu.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("User Click on TradingDashboardReport ......");

            String vOrgName = Constants.B2BOR.getProperty("B2B_TrandingDashboardReport_OrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.click(vOrgName, ""));

        }
    }

    @And("^User click on (BookDeal|FetchRate Button|B2B Enabled Checkbox) from (BlotterReport|Spot deal booking) page$")
    public void userClickOnBookDealFromBlotterReportPage(String Value, String Menu) throws Throwable {
        if (Value.equalsIgnoreCase("BookDeal") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on Book Deal ......");


            String vBookDeal = Constants.B2BOR.getProperty("B2B_BlotterReport_BookDeal");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBookDeal, ""));
            //Constants.key.switchToWindow("Spot deal booking");
            Assert.assertEquals("PASS", Constants.key.click(vBookDeal, ""));

            Constants.key.switchToWindow("Spot deal booking");

        } else if (Value.equalsIgnoreCase("FetchRate Button") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("User Click on Book Deal ......");

            String vFetchRateButton = Constants.B2BOR.getProperty("B2B_BlotterReport_SpotDealBooking_FetchRateButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFetchRateButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFetchRateButton, ""));

        } else if (Value.equalsIgnoreCase("B2B Enabled Checkbox") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User Click on B2B Enabled Checkbox ......");

            String vObjB2BEnabledCheckbox = Constants.B2BOR.getProperty("SpotDealBooking_B2BEnabled_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjB2BEnabledCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BEnabledCheckbox, ""));

        }
    }

    @And("^User enter (the amount|the value|reason|OrgName|SellAmount) in (Buy Currency|Sell Currency|Swap Deal Buy Currency|Swap Deal Sell Currency|Spot deal booking|Pending B2B deal|Swap deal booking) \"([^\"]*)\"$")
    public void userEnterTheAmountInBuyCurrency(String text, String field, String Value) throws Throwable {
        if (text.equalsIgnoreCase("the amount") && field.equalsIgnoreCase("Buy Currency")) {
            LogCapture.info("User enter the amount in Buy Currency ......");

            String vObjSpotDealBookingBuyCurrencies = Constants.B2BOR.getProperty("SpotDealBooking_BuyCurrencies");
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBookingBuyCurrencies, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSpotDealBookingBuyCurrencies, Value));

        }
        if (text.equalsIgnoreCase("the amount") && field.equalsIgnoreCase("Sell Currency")) {
            LogCapture.info("User enter the amount in Sell Currency ......");

            String vObjSpotDealBookingSellCurrencies = Constants.B2BOR.getProperty("SpotDealBooking_SellCurrencies");
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBookingSellCurrencies, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSpotDealBookingSellCurrencies, Value));

        }
        if (text.equalsIgnoreCase("the amount") && field.equalsIgnoreCase("Swap Deal Buy Currency")) {
            LogCapture.info("User enter the amount in Sell Currency ......");

            String vObjSwapDeal_BuyAmount = Constants.B2BOR.getProperty("SwapDeal_BuyAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapDeal_BuyAmount, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSwapDeal_BuyAmount, Value));

        }
        if (text.equalsIgnoreCase("the amount") && field.equalsIgnoreCase("Swap Deal Sell Currency")) {
            LogCapture.info("User enter the amount in Sell Currency ......");

            String vObjSpotDealBookingSellCurrencies = Constants.B2BOR.getProperty("SwapDeal_SellAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBookingSellCurrencies, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSpotDealBookingSellCurrencies, Value));
        }
        if (text.equalsIgnoreCase("reason") && field.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User enter the reason ......");

            String vObjSpotDealBookingReason = Constants.B2BOR.getProperty("SpotDealBooking_Reason");
            Assert.assertEquals("PASS", Constants.key.javascrpiptEnterText(vObjSpotDealBookingReason, Value));
        }
        if (text.equalsIgnoreCase("reason") && field.equalsIgnoreCase("Swap deal booking")) {
            LogCapture.info("User enter the reason ......");
            Constants.key.pause("7", "");
            String vObjSpotDealBookingReason = Constants.B2BOR.getProperty("SwapDealBooking_Reason");
            Assert.assertEquals("PASS", Constants.key.javascrpiptEnterText(vObjSpotDealBookingReason, Value));
        }
        if (text.equalsIgnoreCase("OrgName") && field.equalsIgnoreCase("Pending B2B deal")) {
            LogCapture.info("User enter the reason ......");

            String vObjOrgName = Constants.B2BOR.getProperty("B2B_PendingB2BDeals_OrgName");
            Assert.assertEquals("PASS", Constants.key.click(vObjOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjOrgName, Value));
        }
        if (text.equalsIgnoreCase("SellAmount") && field.equalsIgnoreCase("Pending B2B deal")) {
            LogCapture.info("User enter the reason ......");

            String vObjSpotDealBookingSellAmount = Constants.B2BOR.getProperty("B2B_PendingB2BDeals_SellAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBookingSellAmount, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSpotDealBookingSellAmount, Value));
        }
    }

    @And("^Verify the data is populated successfully \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyTheDataIsPopulatedSuccessfullyAnd(String Bank, String BuyCurrencyAmt) throws Throwable {
        String vObjSpotDealBooingStopForwardDealRateTable = Constants.B2BOR.getProperty("SpotDealBooking_StopForwardDealRateTable");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooingStopForwardDealRateTable, ""));
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjSpotDealBooingStopForwardDealRateTable));
        LogCapture.info("Total number of elements present: " + listOfElements.size());
        for (int i = 1; i <= listOfElements.size(); i++) {
            String ActualBank = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[1]";
            String ActualBankValue = Constants.driver.findElement(By.xpath(ActualBank)).getText();
            System.out.println(ActualBankValue);

            String OutRightate = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[2]";
            String ActualOutRightate = Constants.driver.findElement(By.xpath(OutRightate)).getText();
            System.out.println(ActualOutRightate);

            String Inverse = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[3]";
            String ActualInverse = Constants.driver.findElement(By.xpath(Inverse)).getText();
            System.out.println(ActualInverse);

            String Spot = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[4]";
            ActualSpot = Constants.driver.findElement(By.xpath(Spot)).getText();
            System.out.println(ActualSpot);
            //ActualSpotValue=ActualSpot+" "+

            String SellAmt = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[5]";
            String ActualSellAmt = Constants.driver.findElement(By.xpath(SellAmt)).getText();
            System.out.println(ActualSellAmt);

            SellAmountValue = Float.parseFloat(ActualSellAmt);

            String ActualBuyCurrAmt = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[6]";
            String ActualBuyCurrAmtValue = Constants.driver.findElement(By.xpath(ActualBuyCurrAmt)).getText();
            System.out.println(ActualBuyCurrAmtValue);

            String Valuedate = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[13]";
            ValueDate = Constants.driver.findElement(By.xpath(Valuedate)).getText();
            System.out.println(ValueDate);


            Assert.assertEquals("PASS", Constants.key.verifyText(ActualBank, Bank));
            int avalue = Integer.parseInt(ActualBuyCurrAmtValue);
            int evalue = Integer.parseInt(BuyCurrencyAmt);
            Float avalue1 = Float.parseFloat(ActualOutRightate);
            SpotRate = Float.parseFloat(ActualSpot);
            System.out.println(avalue1.floatValue() + "::" + SpotRate.floatValue());
            //Assert.assertEquals("PASS", Constants.key.verifyText(ActualBuyCurrAmtValue, BuyCurrencyAmt));

            if (avalue == evalue && avalue1.floatValue() <= SpotRate.floatValue()) {
                LogCapture.info("Success" + ActualOutRightate + "" + ActualInverse + "" + ActualSpot + "" + ActualSellAmt + "" + ActualBankValue + "" + ActualBuyCurrAmtValue);
                break;
            } else {
                LogCapture.info("Failure" + ActualOutRightate + "" + ActualInverse + "" + ActualSpot + "" + ActualSellAmt + "" + ActualBankValue + "" + ActualBuyCurrAmtValue);
                Assert.fail();

            }
        }

    }

    @And("^verify the data is populated successfully \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userClickOnBookDealAndVerifyTheDataIsPopulatedSuccessfullyAndAndAndAnd(String Bank, String BuyCurrAmt, String BuyCurr, String SellCurr, String Org) throws Throwable {
        String vObjSpotDealBookingDealResponseTable = Constants.B2BOR.getProperty("SpotDealBooking_DealResponseTable");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBookingDealResponseTable, ""));
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjSpotDealBookingDealResponseTable));

        String SpotDealBookingSuccessMsg = Constants.B2BOR.getProperty("SpotDealBooking_SuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SpotDealBookingSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(SpotDealBookingSuccessMsg, "Spot deal is booked successfully."));
        LogCapture.info("Total number of elements present: " + listOfElements.size());
        for (int i = 1; i <= listOfElements.size(); i++) {
            //    for (int j=2;j<=listOfElements.size();j++) {
            String Provider = "//*[@id='SPDealResponse']//tr[2]//td[" + (i + 1) + "]";
            // String ActualProvider=Constants.driver.findElement(By.xpath(Provider)).getText();
            // System.out.println(ActualProvider);
            Assert.assertEquals("PASS", Constants.key.verifyText(Provider, Bank));

            String OrderID = "//*[@id='SPDealResponse']//tr[3]//td[" + (i + 1) + "]";
            String ActualOrderID = Constants.driver.findElement(By.xpath(OrderID)).getText();
            System.out.println(ActualOrderID);


            // Assert.assertEquals("PASS", Constants.key.verifyText(Provider, Bank));

            String SellCurrency = "//*[@id='SPDealResponse']//tr[7]//td[" + (i + 1) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(SellCurrency, SellCurr));


            String BuyCurrency = "//*[@id='SPDealResponse']//tr[8]//td[" + (i + 1) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(BuyCurrency, BuyCurr));

            String ValueDt = "//*[@id='SPDealResponse']//tr[11]//td[" + (i + 1) + "]";
            String ActualValueDate = Constants.driver.findElement(By.xpath(ValueDt)).getText();
            System.out.println(ActualValueDate);
            //System.out.println(ValueDate);

            String SpotRateVal = "//*[@id='SPDealResponse']//tr[9]//td[" + (i + 1) + "]";
            String ASpotRateVal = Constants.driver.findElement(By.xpath(SpotRateVal)).getText();
            System.out.println(ASpotRateVal);
            System.out.println(SpotRate);
            String[] ASpotRateVal1 = ASpotRateVal.split(" ");
            String ASpotRateVal2 = ASpotRateVal1[0];
            String ASpotRateVal3 = ASpotRateVal1[1];
            Float ESpotVal = Float.parseFloat(ASpotRateVal2);
            System.out.println(ASpotRateVal2 + "::" + ASpotRateVal3);

            //String Spot=ASpotRateVal+" "+SellCurr+"/"+BuyCurr;

            String Organization = "//*[@id='SPDealResponse']//tr[13]//td[" + (i + 1) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(Organization, Org));

            String BuyAmt = "//*[@id='SPDealResponse']//tr[5]//td[" + (i + 1) + "]";
            String ActualBuyAmt = Constants.driver.findElement(By.xpath(BuyAmt)).getText();
            System.out.println(ActualBuyAmt);
            Float avalue1 = Float.parseFloat(ActualBuyAmt);
            int avalue = Math.round(avalue1);
            int Evalue = Integer.parseInt(BuyCurrAmt);

            String SellAmt = "//*[@id='SPDealResponse']//tr[6]//td[" + (i + 1) + "]";
            String SellAmount = Constants.driver.findElement(By.xpath(SellAmt)).getText();
            System.out.println(SellAmount);
            Float SellingAmount = Float.parseFloat(SellAmount);

            if (ActualOrderID.length() > 0 && avalue == Evalue) {
                LogCapture.info("Success" + ActualOrderID + "" + avalue + "" + Evalue);
            } else {
                LogCapture.info("Failure" + ActualOrderID + ":" + avalue + ":" + Evalue);
                Assert.fail();

            }
            if (SellingAmount.floatValue() == SellAmountValue.floatValue()) {
                LogCapture.info("Success" + SellingAmount.floatValue() + ":" + SellAmountValue.floatValue() + ":");

            } else {
                LogCapture.info("Failure" + SellingAmount.floatValue() + ":" + SellAmountValue.floatValue() + ":");
                Assert.fail();
            }

            if (ValueDate.equals(ActualValueDate)) {
                LogCapture.info("Success" + ValueDate.trim() + ":" + ActualValueDate.trim() + ":");

            } else {
                LogCapture.info("Failure" + ValueDate.trim() + ":" + ActualValueDate.trim() + ":");
                Assert.fail();

            }

            if (SpotRate.floatValue() == ESpotVal.floatValue()) {
                LogCapture.info("Success" + SpotRate + ":" + ESpotVal + ":");


            } else {
                LogCapture.info("Failure" + SpotRate.floatValue() + ":" + ESpotVal.floatValue() + ":");
                Assert.fail();
            }

            if (ASpotRateVal3.equalsIgnoreCase(SellCurr + "/" + BuyCurr)) {
                LogCapture.info("Success" + ASpotRateVal3 + ":" + SellCurr + "/" + BuyCurr + ":");
                break;
            } else {
                LogCapture.info("failure" + ASpotRateVal3 + ":" + SellCurr + "/" + BuyCurr + ":");
                Assert.fail();

            }
        }

    }

    @And("^User verify the (Buy Currency|Sell Currency) amount is swapped to (Sell Currency|Buy Currency) amount \"([^\"]*)\"$")
    public void userVerifyTheBuyCurrencyAmountIsSwappedToSellCurrencyAmount(String Value1, String Value2, String Amount) throws Throwable {
        if (Value1.equalsIgnoreCase("Buy Currency") && Value2.equalsIgnoreCase("Sell Currency")) {
            LogCapture.info("User enter the amount in Buy Currency ......");

            String vObjSpotDealBookingSellCurrencies = Constants.B2BOR.getProperty("SwapDeal_SellAmount1");
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotDealBookingSellCurrencies, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjSpotDealBookingSellCurrencies, Amount));

        }
    }

    @And("^Verify the data is populated successfully for Near leg and Far leg \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyTheDataIsPopulatedSuccessfullyForNearLegAndFarLegAnd(String Bank, String BuyCurrencyAmt) throws Throwable {
        String vObjSwapDeal_SwapDealRateTable = Constants.B2BOR.getProperty("SwapDeal_SwapDealRateTable");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_SwapDealRateTable, ""));
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjSwapDeal_SwapDealRateTable));
        LogCapture.info("Total number of elements present: " + listOfElements.size());
        for (int i = 2; i <= listOfElements.size(); i++) {
            String ActualBank = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[1]";
            String ActualBankValue = Constants.driver.findElement(By.xpath(ActualBank)).getText();
            System.out.println(ActualBankValue);

            String OutRightate = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[2]";
            String ActualOutRightate = Constants.driver.findElement(By.xpath(OutRightate)).getText();
            System.out.println(ActualOutRightate);

            // String Inverse = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[3]";
            // String ActualInverse = Constants.driver.findElement(By.xpath(Inverse)).getText();
            // System.out.println(ActualInverse);

            String Spot = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[3]";
            ActualSpot = Constants.driver.findElement(By.xpath(Spot)).getText();
            System.out.println(ActualSpot);
            //ActualSpotValue=ActualSpot+" "+

            String SellAmt = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[4]";
            String ActualSellAmt = Constants.driver.findElement(By.xpath(SellAmt)).getText();
            System.out.println(ActualSellAmt);
            SellAmountValue = Float.parseFloat(ActualSellAmt);

            String ActualBuyCurrAmt = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[5]";
            String ActualBuyCurrAmtValue = Constants.driver.findElement(By.xpath(ActualBuyCurrAmt)).getText();
            System.out.println(ActualBuyCurrAmtValue);
            ActualBuyCurrValue = Integer.parseInt(ActualBuyCurrAmtValue);

            String Valuedate = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[7]";
            ValueDate = Constants.driver.findElement(By.xpath(Valuedate)).getText();
            System.out.println(ValueDate);


            Assert.assertEquals("PASS", Constants.key.verifyText(ActualBank, Bank));
            int avalue = Integer.parseInt(ActualBuyCurrAmtValue);
            int evalue = Integer.parseInt(BuyCurrencyAmt);
            Float avalue1 = Float.parseFloat(ActualOutRightate);
            SpotRate = Float.parseFloat(ActualSpot);
            System.out.println(avalue1.floatValue() + "::" + SpotRate.floatValue());
            //Assert.assertEquals("PASS", Constants.key.verifyText(ActualBuyCurrAmtValue, BuyCurrencyAmt));

            /*Far Leg Validation */

            String OutRightate1 = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[8]";
            String ActualOutRightate1 = Constants.driver.findElement(By.xpath(OutRightate1)).getText();
            System.out.println(ActualOutRightate1);

            // String Inverse = "//*[@id='stopForwardDealRateTable']//tr[" + (i + 1) + "]//td[3]";
            // String ActualInverse = Constants.driver.findElement(By.xpath(Inverse)).getText();
            // System.out.println(ActualInverse);

            String Spot1 = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[9]";
            String ActualSpot1 = Constants.driver.findElement(By.xpath(Spot1)).getText();
            System.out.println(ActualSpot1);
            //ActualSpotValue=ActualSpot+" "+

            String SellAmt1 = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[11]";
            String ActualSellAmt1 = Constants.driver.findElement(By.xpath(SellAmt1)).getText();
            System.out.println(ActualSellAmt1);
            Integer ActualSellCurrValue = Integer.parseInt(ActualSellAmt1);

            String ActualBuyCurrAmt1 = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[10]";
            String ActualBuyCurrAmtValue1 = Constants.driver.findElement(By.xpath(ActualBuyCurrAmt1)).getText();
            System.out.println(ActualBuyCurrAmtValue1);
            Float BuyAmountValue1 = Float.parseFloat(ActualBuyCurrAmtValue1);

            String Valuedate1 = "//*[@id='swapDealRateTable']//tr[" + (i + 1) + "]//td[17]";
            String ValueDate1 = Constants.driver.findElement(By.xpath(Valuedate1)).getText();
            System.out.println(ValueDate1);

            if (avalue == evalue && avalue1.floatValue() <= SpotRate.floatValue()) {
                LogCapture.info("Success" + ActualOutRightate + "" + "" + ActualSpot + "" + ActualSellAmt + "" + ActualBankValue + "" + ActualBuyCurrAmtValue);
                //break;
            } else {
                LogCapture.info("Failure" + ActualOutRightate + "" + "" + ActualSpot + "" + ActualSellAmt + "" + ActualBankValue + "" + ActualBuyCurrAmtValue);
                Assert.fail();

            }
            if (SellAmountValue.floatValue() == BuyAmountValue1.floatValue() && ActualBuyCurrValue.intValue() == ActualSellCurrValue.intValue()) {
                LogCapture.info("Success");
                break;
            } else {
                LogCapture.info("Failure" + ActualOutRightate + "" + "" + ActualSpot + "" + ActualSellAmt + "" + ActualBankValue + "" + ActualBuyCurrAmtValue);
                Assert.fail();

            }
        }
    }

    @And("^verify the data is populated successfully for Near leg and Far leg \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyTheDataIsPopulatedSuccessfullyForNearLegAndFarLegAndAndAndAnd(String Bank, String BuyCurrAmt, String BuyCurr, String SellCurr, String Org) throws Throwable {
        String vObjSpotDealBookingDealResponseTable = Constants.B2BOR.getProperty("SwapDeal_ResponseTable");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBookingDealResponseTable, ""));
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjSpotDealBookingDealResponseTable));

        String SpotDealBookingSuccessMsg = Constants.B2BOR.getProperty("SwapDeal_SuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SpotDealBookingSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(SpotDealBookingSuccessMsg, "Swap deal is booked successfully"));
        LogCapture.info("Total number of elements present: " + listOfElements.size());
        for (int i = 1; i <= listOfElements.size(); i++) {
            //    for (int j=2;j<=listOfElements.size();j++) {
            String Provider = "//*[@id='SWDealResponse']//tr[2]//td[" + (i + 1) + "]";
            String Provider1 = "//*[@id='SWDealResponse']//tr[2]//td[" + (i + 2) + "]";
            // String ActualProvider=Constants.driver.findElement(By.xpath(Provider)).getText();
            // System.out.println(ActualProvider);
            Assert.assertEquals("PASS", Constants.key.verifyText(Provider, Bank));
            Assert.assertEquals("PASS", Constants.key.verifyText(Provider1, Bank));

            String OrderID = "//*[@id='SWDealResponse']//tr[3]//td[" + (i + 1) + "]";
            String ActualOrderID = Constants.driver.findElement(By.xpath(OrderID)).getText();
            System.out.println(ActualOrderID);

            String OrderID1 = "//*[@id='SWDealResponse']//tr[3]//td[" + (i + 2) + "]";
            String ActualOrderID1 = Constants.driver.findElement(By.xpath(OrderID1)).getText();
            System.out.println(ActualOrderID1);
            Assert.assertEquals("PASS", Constants.key.verifyText(OrderID, ActualOrderID1));

            // Assert.assertEquals("PASS", Constants.key.verifyText(Provider, Bank));

            String SellCurrency = "//*[@id='SWDealResponse']//tr[6]//td[" + (i + 1) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(SellCurrency, SellCurr));


            String BuyCurrency = "//*[@id='SWDealResponse']//tr[7]//td[" + (i + 1) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(BuyCurrency, BuyCurr));

            String SellCurrency1 = "//*[@id='SWDealResponse']//tr[6]//td[" + (i + 2) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(SellCurrency1, BuyCurr));


            String BuyCurrency1 = "//*[@id='SWDealResponse']//tr[7]//td[" + (i + 2) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(BuyCurrency1, SellCurr));


//                        String ValueDt="//*[@id='SPDealResponse']//tr[11]//td[" + (i + 1) + "]";
//                        String ActualValueDate=Constants.driver.findElement(By.xpath(ValueDt)).getText();
//                        System.out.println(ActualValueDate);
            //System.out.println(ValueDate);

            String SpotRateVal = "//*[@id='SWDealResponse']//tr[9]//td[" + (i + 1) + "]";
            String ASpotRateVal = Constants.driver.findElement(By.xpath(SpotRateVal)).getText();
            System.out.println(ASpotRateVal);
            System.out.println(SpotRate);
            String[] ASpotRateVal1 = ASpotRateVal.split(" ");
            String ASpotRateVal2 = ASpotRateVal1[0];
            String ASpotRateVal3 = ASpotRateVal1[1];
            Float ESpotVal = Float.parseFloat(ASpotRateVal2);
            System.out.println(ASpotRateVal2 + "::" + ASpotRateVal3);

            //String Spot=ASpotRateVal+" "+SellCurr+"/"+BuyCurr;

            String Organization = "//*[@id='SWDealResponse']//tr[10]//td[" + (i + 1) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(Organization, Org));
            String Organization1 = "//*[@id='SWDealResponse']//tr[10]//td[" + (i + 2) + "]";
            Assert.assertEquals("PASS", Constants.key.verifyText(Organization1, Org));

            String BuyAmt = "//*[@id='SWDealResponse']//tr[4]//td[" + (i + 1) + "]";
            String ActualBuyAmt = Constants.driver.findElement(By.xpath(BuyAmt)).getText();
            System.out.println(ActualBuyAmt);
            Integer ActualBuyAmt1 = Integer.parseInt(ActualBuyAmt);

            String BuyAmt1 = "//*[@id='SWDealResponse']//tr[5]//td[" + (i + 2) + "]";
            String ActualBuyAmt2 = Constants.driver.findElement(By.xpath(BuyAmt1)).getText();
            System.out.println(ActualBuyAmt2);
            Integer ActualBuyAmt3 = Integer.parseInt(ActualBuyAmt2);
//                        Float avalue1=Float.parseFloat(ActualBuyAmt);
//                        int avalue=Math.round(avalue1);
//                        int Evalue=Integer.parseInt(BuyCurrAmt);

            String SellAmt = "//*[@id='SWDealResponse']//tr[5]//td[" + (i + 1) + "]";
            String SellAmount = Constants.driver.findElement(By.xpath(SellAmt)).getText();
            System.out.println(SellAmount);
            Float SellingAmount = Float.parseFloat(SellAmount);

            String SellAmt1 = "//*[@id='SWDealResponse']//tr[4]//td[" + (i + 2) + "]";
            String SellAmount1 = Constants.driver.findElement(By.xpath(SellAmt1)).getText();
            System.out.println(SellAmount);
            Float SellingAmount1 = Float.parseFloat(SellAmount1);//SellAmountValue


            if (SellingAmount.floatValue() == SellAmountValue.floatValue()) {
                LogCapture.info("Success" + SellingAmount.floatValue() + ":" + SellAmountValue.floatValue() + ":");

            } else {
                LogCapture.info("Failure" + SellingAmount.floatValue() + ":" + SellAmountValue.floatValue() + ":");
                Assert.fail();
            }
            if (SellingAmount.floatValue() == SellingAmount1.floatValue()) {
                LogCapture.info("Success" + SellingAmount.floatValue() + ":" + SellingAmount1.floatValue() + ":");

            } else {
                LogCapture.info("Failure" + SellingAmount.floatValue() + ":" + SellAmountValue.floatValue() + ":");
                Assert.fail();
            }
//                        if(BuyAmountValue1.intValue()==ActualBuyAmt1.intValue()){
//                                LogCapture.info("Success"+BuyAmountValue1.floatValue()+":"+ActualBuyAmt1.floatValue()+":");
//
//
//                        }else{
//                                LogCapture.info("Failure"+SellingAmount.floatValue()+":"+SellAmountValue.floatValue()+":");
//                                Assert.fail();
//                        }
            if (ActualBuyAmt3.intValue() == ActualBuyAmt1.intValue()) {
                LogCapture.info("Success" + ActualBuyAmt3.floatValue() + ":" + ActualBuyAmt1.floatValue() + ":");


            } else {
                LogCapture.info("Failure" + SellingAmount.floatValue() + ":" + SellAmountValue.floatValue() + ":");
                Assert.fail();
            }


            if (ASpotRateVal3.equalsIgnoreCase(SellCurr + "/" + BuyCurr)) {
                LogCapture.info("Success" + ASpotRateVal3 + ":" + SellCurr + "/" + BuyCurr + ":");
                break;
            } else {
                LogCapture.info("failure" + ASpotRateVal3 + ":" + SellCurr + "/" + BuyCurr + ":");
                Assert.fail();

            }
        }
    }

    @Then("^User should successfully see (data|Selected data|Same Day|Next Day|Profit not present|Organization Details|Rule Engine Enabled|Profit present|AccBalance Details|Statement Number not present|Statement Number present|BalException Details|Institution not present|Currencies Direct Details|FCG Details|Details of selected Account|Bank Account Pager Information|Statement Date not present|Type Not Present|Type Present|Load into Panel|Load into Panel Not Displayed) on (B2B|Dashboard|Spot Forward Deal|TradingDashBoardReport|BlotterReport|Organization Details|Opening Closing|OrgCurrency Details|Rule Engine|Account Balance|Balance Exception|PotentialDuplicateQueue|Bank Account|Balance Entry|Trading Dashboard Report) page$")
    public void userShouldSuccessfullySeeRecordsOnBlotterReportPage(String Data, String Menu) throws Throwable {
        key.pause("6", "");
        if (Data.equalsIgnoreCase("data") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report data loading ......");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjBlotterTotal = Constants.B2BOR.getProperty("B2B_BlotterReport_Total");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlotterTotal, "Total"));
        }
        if (Data.equalsIgnoreCase("Selected data") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report search data loading ......");
            String vObjGetSellCurr = Constants.B2BOR.getProperty("B2B_BlotterReport_GetSellCurr");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGetSellCurr, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjGetSellCurr, "GBP"));
            String vObjGetBuyCurr = Constants.B2BOR.getProperty("B2B_BlotterReport_GetBuyCurr");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjGetBuyCurr, "EUR"));
        }
        if (Data.equalsIgnoreCase("Same Day") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report deal details loading ......");
            String vObjDealDate = Constants.B2BOR.getProperty("B2B_BlotterReport_DealDate");
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = new Date();
            String todayDate = dateFormat.format(date);

            String dealDate = Constants.key.getText(vObjDealDate);
            Assert.assertTrue(dealDate.contains(todayDate));
        }
        if (Data.equalsIgnoreCase("Next Day") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report deal details loading ......");
            String vObjDealDate = Constants.B2BOR.getProperty("B2B_BlotterReport_MaturityDealDate");
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            Date date = calendar.getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String tomorrowDate = dateFormat.format(date);

            String dealDate = Constants.key.getText(vObjDealDate);
            Assert.assertTrue(dealDate.contains(tomorrowDate));
        }
        if (Data.equalsIgnoreCase("Profit not present") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report data loading ......");

            String vObjBlotterProfit = Constants.B2BOR.getProperty("B2B_BlotterReport_Profit");
            Assert.assertNotEquals("PASS", Constants.key.exist(vObjBlotterProfit, ""));
        }
        if (Data.equalsIgnoreCase("Type Not Present") && Menu.equalsIgnoreCase("Trading Dashboard Report")) {
            LogCapture.info("TradingDashboardReport data loading ......");

            String vB2BType = Constants.B2BOR.getProperty("B2B_TradingDashboardReport_Type");
            Assert.assertNotEquals("PASS", Constants.key.exist(vB2BType, ""));
        }
        if (Data.equalsIgnoreCase("Type Present") && Menu.equalsIgnoreCase("Trading Dashboard Report")) {
            LogCapture.info("TradingDashboardReport data loading ......");

            String vObjBlotterProfit = Constants.B2BOR.getProperty("B2B_TradingDashboardReport_Type");
            Assert.assertNotEquals("PASS", Constants.key.exist(vObjBlotterProfit, ""));
        }
        if (Data.equalsIgnoreCase("Organization Details") && Menu.equalsIgnoreCase("Organization Details")) {
            LogCapture.info("Organization details data loading ......");

            String vObjOrgDetails = Constants.RFQOR.getProperty("RFQ_OrganizationDetails_OrgDetails");
            Assert.assertEquals("PASS", Constants.key.exist(vObjOrgDetails, ""));
        }
        if (Data.equalsIgnoreCase("Organization Details") && Menu.equalsIgnoreCase("Opening Closing")) {
            LogCapture.info("Organization details data loading ......");

            String vObjOrgDetails = Constants.RFQOR.getProperty("RFQ_OpeningClosingDetails_OrgDetails");
            Assert.assertEquals("PASS", Constants.key.exist(vObjOrgDetails, ""));
        }
        if (Data.equalsIgnoreCase("Organization Details") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("Organization details data loading ......");

            String vObjOrgDetails = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_OrgDetails");
            Assert.assertEquals("PASS", Constants.key.exist(vObjOrgDetails, ""));
        }
        if (Data.equalsIgnoreCase("Profit present") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report data loading ......");

            String vObjBlotterProfit = Constants.B2BOR.getProperty("B2B_BlotterReport_Profit");
            Assert.assertEquals("PASS", Constants.key.exist(vObjBlotterProfit, ""));
        }
        if (Data.equalsIgnoreCase("AccBalance Details") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("AccBalance Details data loading ......");

            String vObjAccBalanceDetails = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails");
            Assert.assertEquals("PASS", Constants.key.exist(vObjAccBalanceDetails, ""));
        }
        if (Data.equalsIgnoreCase("AccBalance Details") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("AccBalance Details data loading ......");

            String vObjAccBalanceDetails = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails");
            Assert.assertEquals("PASS", Constants.key.exist(vObjAccBalanceDetails, ""));
        }
        if (Data.equalsIgnoreCase("Statement Number not present") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Account details data loading ......");

            String vObjStatementNum = Constants.BankingOR.getProperty("BNK_AccountBalance_StatementNum");
            Assert.assertNotEquals("PASS", Constants.key.exist(vObjStatementNum, ""));
        }
        if (Data.equalsIgnoreCase("Statement Number not present") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("Account details data loading ......");

            String vObjStatementNum = Constants.BankingOR.getProperty("BNK_AccountBalance_StatementNum");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjStatementNum, ""));
        }
        if (Data.equalsIgnoreCase("Statement Number present") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Account details data loading ......");

            String vObjStatementNum = Constants.BankingOR.getProperty("BNK_AccountBalance_StatementNum");
            Assert.assertEquals("PASS", Constants.key.exist(vObjStatementNum, ""));
        }
        if (Data.equalsIgnoreCase("BalException Details") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("BalException Details data loading ......");

            String vObjBalExceptionDetails = Constants.BankingOR.getProperty("BNK_BalanceException_AccDetails");
            Assert.assertEquals("PASS", Constants.key.exist(vObjBalExceptionDetails, ""));
        }
        if (Data.equalsIgnoreCase("Institution not present") && Menu.equalsIgnoreCase("PotentialDuplicateQueue")) {
            LogCapture.info("Account details data loading ......");

            String vBNK_PotentialQueue_ChangePreferenceInstitution = Constants.BankingOR.getProperty("BNK_PotentialQueue_ChangePreferenceInstitution");
            Assert.assertEquals("PASS", Constants.key.notexist(vBNK_PotentialQueue_ChangePreferenceInstitution, ""));
        }
        if (Data.equalsIgnoreCase("Currencies Direct Details") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("Currencies Direct data loading ......");
            String vObjCurrenciesDirect = Constants.BankingOR.getProperty("BNK_BankAccount_CurrenciesDirect");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesDirect, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCurrenciesDirect, "Currencies Direct"));
        }
        if (Data.equalsIgnoreCase("FCG Details") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("FCG data loading ......");

            String vObjFCG = Constants.BankingOR.getProperty("BNK_BankAccount_FCG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFCG, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjFCG, "FCG"));
        }
        if (Data.equalsIgnoreCase("Details of selected Account") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("Details of Selected Account data loading ......");

            String vDetailsOfRecords = Constants.BankingOR.getProperty("BNK_BalanceEntries_DetailsOfSelectedRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDetailsOfRecords, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vDetailsOfRecords, "Details of selected Account"));

        }
        if (Data.equalsIgnoreCase("Statement Date not present") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("Account details data loading ......");

            String vObjStatementNum = Constants.BankingOR.getProperty("BNK_AccountBalance_StatementDate");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjStatementNum, ""));
        }
        if (Data.equalsIgnoreCase("Bank Account Pager Information") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("Bank Account Pager Information data loading ......");

            String vPagerInformation = Constants.BankingOR.getProperty("BNK_BankAccount_PagerInformation");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPagerInformation, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vPagerInformation, ""));

        }
        if (Data.equalsIgnoreCase("Selected data") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("Selected Row data loading ......");

            String vObjOrgDetails = Constants.BankingOR.getProperty("BNK_InstitutionRowTableData");
            Assert.assertEquals("PASS", Constants.key.exist(vObjOrgDetails, ""));
            String vBNK_LoadPanelTitle = Constants.BankingOR.getProperty("BNK_LoadPanelTitle");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_LoadPanelTitle, "Details of selected Bank Account"));
        }
        if (Data.equalsIgnoreCase("Statement Number not present") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("Bank Account details data is loading ......");

            String vObjStatementNum = Constants.BankingOR.getProperty("BNK_BankAccount_StatementNum");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjStatementNum, ""));
        }
        if (Data.equalsIgnoreCase("Load into Panel") && Menu.equalsIgnoreCase("PotentialDuplicateQueue")) {
            LogCapture.info("Selected Records data loading ......");

            String vBNK_PotentialQueue_LoadIntoPanel = Constants.BankingOR.getProperty("BNK_PDQ_Panel");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PotentialQueue_LoadIntoPanel, ""));
            String vBNK_PotentialQueue_Pager = Constants.BankingOR.getProperty("BNK_PDQ_Pager");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PotentialQueue_Pager, ""));

        }
        if (Data.equalsIgnoreCase("Load into Panel Not Displayed") && Menu.equalsIgnoreCase("PotentialDuplicateQueue")) {
            LogCapture.info("Deselected Records data loading ......");

            String vBNK_PotentialQueue_LoadIntoPanel = Constants.BankingOR.getProperty("BNK_PDQ_Panel");

            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PotentialQueue_LoadIntoPanel, ""));


        }
    }

    @And("^User right click on (Same Day|Next Day|Pending B2B Deal Record|Pending B2B Deal Record from dealID|PaymentApprovalRecordID|PotentialDuplicateQueueRecord|Checkbox) from (B2B|Dashboard|Spot Forward Deal|TradingDashBoardReport|BlotterReport|Pending B2B Deals|Payment Approval|Potential Duplicate Queue|Queries|Incoming Queries|Payment Entries) page$")
    public void userRightClickOnSameDayFromBlotterReportPage(String Data, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("Same Day") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report data loading ......");
            String vObjSameDay = Constants.B2BOR.getProperty("B2B_BlotterReport_SameDay");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSameDay, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjSameDay, "RightClick"));
        } else if (Data.equalsIgnoreCase("Next Day") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report data loading ......");
            String vObjNextDay = Constants.B2BOR.getProperty("B2B_BlotterReport_NextDay");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNextDay, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjNextDay, "RightClick"));
        } else if (Data.equalsIgnoreCase("Pending B2B Deal Record") && Menu.equalsIgnoreCase("Pending B2B Deals")) {
            LogCapture.info("Pending B2B Deals data loading ......");
            String vObjPendingB2BRecord = Constants.RFQOR.getProperty("RFQ_PendingB2BDeals_Record");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPendingB2BRecord, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPendingB2BRecord, "RightClick"));
        } else if (Data.equalsIgnoreCase("Pending B2B Deal Record from dealID") && Menu.equalsIgnoreCase("Pending B2B Deals")) {
            LogCapture.info("Pending B2B Deals data loading ......");
            String vObjPendingB2BRecord = Constants.RFQOR.getProperty("RFQ_PendingB2BDeal_Record");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPendingB2BRecord, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPendingB2BRecord, "RightClick"));
        } else if (Data.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info(" Options are loading ......");
            key.pause("3", "");
            String vCheckbox1 = Constants.BankingOR.getProperty("BNK_BalanceEntries_Checkbox");
            LogCapture.info("BNK_BalanceEntries_Checkbox display check");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckbox1, ""));
            LogCapture.info("vCheckbox1 is displayed and proceed to right click");

//            Assert.assertEquals("PASS", key.navigateSubMenu(vCheckbox1, "RightClick"));

            Assert.assertEquals("PASS", key.MouseFunctions(vCheckbox1, "RightClick"));
            LogCapture.info("vBNK_Table_raiseQuerycheckbox right click completed");

            // from here
            String vRightClickCopyOfYesBankAPI = Constants.PaymentMonitoringOR.getProperty("copyOfYES");
            LogCapture.info("wait for BNK_PaymentMonitoring_RightClick_CopyOfYes_Bank_API");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRightClickCopyOfYesBankAPI, ""));
            LogCapture.info("Copy Of Yes_Bank_API is displayed and proceed to click");
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vRightClickCopyOfYesBankAPI, "click"));
            LogCapture.info("Copy Of Yes_Bank_API opening....");

            LogCapture.info("Trying to capture vCopyOfYesBankAPIText ....");
            String vCopyOfYesBankAPIText = Constants.PaymentMonitoringOR.getProperty("copyOfYES_msg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCopyOfYesBankAPIText, ""));
            key.pause("3", "");
            LogCapture.info("vCopyOfYesBankAPIText able to see ....");
            CopyofMT = Constants.driver.findElement(By.xpath(vCopyOfYesBankAPIText)).getText();
            LogCapture.info("Copy Of Yes_Bank_API Body - ");
            key.pause("3", "");
            System.out.println(CopyofMT);
            Assert.assertTrue(CopyofMT.contains("Omkar-Jagdale"));
            // come here boy
//            String vRightClickCopyOfMP=Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitoring_RightClick_CopyOfMT");
//            LogCapture.info("wait for BNK_PaymentMonitoring_RightClick_CopyOfMT");
//            while(!key.verifyElementProperties(vRightClickCopyOfMP, "visible").equalsIgnoreCase("PASS")) {
//                LogCapture.info("inside while loop...");
//                Assert.assertEquals("PASS", key.MouseFunctions(vCheckbox1, "RightClick"));
//                LogCapture.info("inside while loop right clicked...");
//
//            }
//            Assert.assertEquals("PASS", key.VisibleConditionWait(vRightClickCopyOfMP, "RightClick"));
            // Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vRightClickCopyOfMP, ""));

        } else if (Data.equalsIgnoreCase("PaymentApprovalRecordID") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User right click on Payment Approval Record id ......");

            String vBanking_PaymentMonitoring_FirstRecordID = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_FirstRecordID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_FirstRecordID, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBanking_PaymentMonitoring_FirstRecordID, "RightClick"));

        } else if (Data.equalsIgnoreCase("PotentialDuplicateQueueRecord") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User right click on PotentialDuplicateQueueRecord ......");

            String vBNK_PotentialDuplicateQueue_FirstRecordId = Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue_FirstRecordID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PotentialDuplicateQueue_FirstRecordId, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PotentialDuplicateQueue_FirstRecordId, "RightClick"));

        } else if (Data.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Options are loading ......");

            String vCheckbox1 = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckbox1, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vCheckbox1, "RightClick"));


        } else if (Data.equalsIgnoreCase("Checkbox") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info(" Options are loading ......");

            String vCheckbox1 = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Checkbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckbox1, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vCheckbox1, "RightClick"));


        }
    }


    @Then("^File is successfully downloaded in the directory from (Account Balance|BlotterReport|Balance Exception|Bank Account|Payment Entries|Balance Entry|Message Out|Potential Duplicate Queue|Failed Payment Out) page$")
    public void fileIsSuccessfullyDownloadedInTheDirectory(String Page) throws Throwable {
        key.pause("6", "");
        if (Page.equalsIgnoreCase("BlotterReport")) {
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "blotterReportDIV.xls";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        } else if (Page.equalsIgnoreCase("Account Balance")) {
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "Banking_Portal_Account_Balance.csv";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        } else if (Page.equalsIgnoreCase("Balance Entry")) {

//                        String downloadPath = System.getProperty("user.home") + "/Downloads/";
//                        LogCapture.info("File download path is "+downloadPath);
//
//                        String fileName = "Banking_Portal_BalanceEntry.csv";

            String vBNK_BankAccount_ProgressIcon = Constants.BankingOR.getProperty("BNK_BankAccount_ProgressIcon");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vBNK_BankAccount_ProgressIcon, ""));
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "Banking_Portal_Balance_Entries.csv";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        } else if (Page.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("Checking for downloaded file in system....");
            String vBNK_BankAccount_ProgressIcon = Constants.BankingOR.getProperty("BNK_BankAccount_ProgressIcon");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vBNK_BankAccount_ProgressIcon, ""));
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "BalanceExceptionData.csv";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        } else if (Page.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("Checking for downloaded file in system....");
            String vBNK_BankAccount_ProgressIcon = Constants.BankingOR.getProperty("BNK_BankAccount_ProgressIcon");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vBNK_BankAccount_ProgressIcon, ""));
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "Banking_Portal_Bank_Account.csv";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        } else if (Page.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("Checking for downloaded file in system....");
            String vBNK_PaymentMonitor_progressIcon = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_progressIcon");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vBNK_PaymentMonitor_progressIcon, ""));
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "PaymentData.csv";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        } else if (Page.equalsIgnoreCase("Message Out")) {
            LogCapture.info("Checking for downloaded file in system....");
            String vBNK_PaymentMonitor_progressIcon = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_progressIcon");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vBNK_PaymentMonitor_progressIcon, ""));
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "Banking_Portal_Message_Generate.xls";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        } else if (Page.equalsIgnoreCase("Potential Duplicate Queue")) {
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "PotentialDuplicateQueueData.csv";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        } else if (Page.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("Checking for downloaded file in system....");

            String vBNK_FailedPaymentOut_Progress = Constants.MessageOR.getProperty("BNK_FailedPaymentOut_Progress");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vBNK_FailedPaymentOut_Progress, ""));
            String oSName = System.getProperty("os.name");
            String downloadPath = "";
            if (oSName.toUpperCase().contains("WIN")) {
                downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            } else {
                downloadPath = System.getProperty("user.dir") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);
            }

            String fileName = "Banking_Portal_Message_Generate.csv";
            Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

            Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));
        }
    }

    @And("^User switch to (PrintPdf|Print) window from (B2B|Dashboard|Spot Forward Deal|TradingDashBoardReport|BlotterReport|Account Balance|Bank Account|Balance Entry|Balance Exception|Potential Duplicate Queue|Message Out|Spot deal booking|Swap deal booking) page$")
    public void userSwitchToPrintPdfWindowFromBlotterReportPage(String Data, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report pdf loading ......");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Untitled Document"));
        } else if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Click on PrintPdf at top right corner.....");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Account Balance Details"));

        } else if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("Bank Account  pdf loading ......");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Bank Account Details"));
        } else if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("Balance Entry pdf loading ......");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Balance Entries Details"));

        } else if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("Balance Exception pdf loading ......");

            Constants.key.switchToWindow("Balance Exception Details");
            //Assert.assertTrue(Constants.key.switchToWindow(""));
            Constants.key.waitForNewWindow(30);
        } else if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Message Out")) {
            LogCapture.info("Message Out pdf loading ......");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Message Out Details"));
        } else if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("Potential Duplicate Queue pdf is loading ......");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Potential Duplicate Queue"));

            Constants.key.waitForNewWindow(120);
        } else if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("TradingDashBoardReport")) {
            LogCapture.info("TradingDashBoardReport pdf loading ......");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Trading Dashboard Details"));
        } else if (Data.equalsIgnoreCase("Print") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info(" Spot deal booking pdf loading ......");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Swap deal booking"));
        } else if (Data.equalsIgnoreCase("Print") && Menu.equalsIgnoreCase("Swap deal booking")) {
            LogCapture.info(" Swap deal booking pdf loading ......");

            Assert.assertEquals("PASS", Constants.key.switchToWindow("Swap deal booking"));
        }
    }


    @Then("^User verify the records are present in (PotentialDuplicateQueue) table$")
    public void userVerifyTheRecordsArePresentInPotentialDuplicateQueueTable(String table) throws Exception {
        if (table.equalsIgnoreCase("PotentialDuplicateQueue")) {
            String vObjDuplicateQueueCount = Constants.BankingOR.getProperty("DuplicateQueueCount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDuplicateQueueCount, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjDuplicateQueueCount));
            LogCapture.info("Total number of elements present: " + listOfElements.size());

            String vObjDuplicateQueue_Table = Constants.BankingOR.getProperty("DuplicateQueue_Table");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDuplicateQueue_Table, ""));
            List<WebElement> listOfElements1 = Constants.driver.findElements(By.xpath(vObjDuplicateQueue_Table));
            LogCapture.info("Total number of elements present: " + listOfElements1.size());

            if (listOfElements.size() == 2 && listOfElements1.size() == 15) {
                for (int i = 1; i <= listOfElements.size(); i++) {

                    String ActualCount = Constants.driver.findElement(By.xpath(vObjDuplicateQueueCount)).getText();
                    System.out.println(ActualCount);
                    String[] ActualCountSplit = ActualCount.split("[)]");
                    String[] ActualCountSplit1 = ActualCountSplit[0].split("[(]");
                    String ActualSplitValue = ActualCountSplit1[1];
                    Integer ActualSplitValue1 = Integer.parseInt(ActualSplitValue);
                    System.out.println(ActualSplitValue1);

                    if (ActualSplitValue1 >= 1) {
                        LogCapture.info("Success");
//                        String Checkbox="//*[@id='potentialDuplicateQueueDiv']//tr[4]//td[1]";
//                        String vObjBankEntriesDetails=Constants.BankingOR.getProperty("BankEntriesDetails");
//                        String vObjBankEntriesDetails_VerifyText=Constants.BankingOR.getProperty("BankEntriesDetails_VerifyText");
                        String Checkbox = "//*[@id='potentialDuplicateQueueDiv']//tr[4]//input[@type='checkbox']";
                        String vObjBankEntriesDetails = Constants.BankingOR.getProperty("BankEntriesDetails");
                        String vObjBankEntriesDetails_VerifyText = Constants.BankingOR.getProperty("BankEntriesDetails_VerifyText");
                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(Checkbox, ""));
                        Assert.assertEquals("PASS", Constants.key.click(Checkbox, ""));

                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankEntriesDetails_VerifyText, ""));
                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankEntriesDetails, ""));
                        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBankEntriesDetails_VerifyText, "Transaction details of selected Account"));
                        break;
                    } else {
                        LogCapture.info("Failure");
                        Assert.fail();

                    }
                }
            }
        }
    }

    @Then("^User should successfully see (records) as per applied filter for (Currency|Event|Organization) \"([^\"]*)\" on (Event Log) page$")
    public void userShouldSuccessfullySeeRecordsAsPerAppliedFilterForCurrencyEventOnEventLogPage(String Data, String Filter, String Value, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("records") && Menu.equalsIgnoreCase("Event Log") && Filter.equalsIgnoreCase("Currency")) {
            LogCapture.info("Event Log data loading ......");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjCurrencyData = Constants.RFQOR.getProperty("RFQ_EventLog_CurrencyData");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCurrencyData, Value));
        } else if (Data.equalsIgnoreCase("records") && Menu.equalsIgnoreCase("Event Log") && Filter.equalsIgnoreCase("Event")) {
            LogCapture.info("Event Log data loading ......");
            String vObjEventData = Constants.RFQOR.getProperty("RFQ_EventLog_EventData");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjEventData, Value));
        } else if (Data.equalsIgnoreCase("records") && Menu.equalsIgnoreCase("Event Log") && Filter.equalsIgnoreCase("Organization")) {
            LogCapture.info("Event Log data loading ......");
            String vObjOrganization = Constants.RFQOR.getProperty("RFQ_Eventlog_Organization");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjOrganization, Value));

        }
    }


    @And("^User enter (Name|OverAllExposureLimit|OverAllExposureLimitOutofOffice|Day|Currency|ExposureLimit|ExposureLimitOutofOffice|OpenPosition|ForwardTradeLimit|SingleTradeLimit|FromDate|QueryNarration|OpeningBalance|RecordID|Cost|Reason|Status|Reference)\"([^\"]*)\" on (Organization Details|Opening Closing|OrgCurrency Details|One Time Configurable|Account Balance|Balance Exception|Balance Entry|Bank Account|Queries|Incoming Queries|Authorise Query|Failed Payment Out|Spot deal booking) page$")
    public void userEnterOverAllExposureLimitOnOrganizationDetailsPage(String Data, String Value, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("OverAllExposureLimit") && Menu.equalsIgnoreCase("Organization Details")) {
            LogCapture.info("User enter overall exposure limit on Organization detail page......");
            String vObjOverallExposure = Constants.RFQOR.getProperty("RFQ_OrgDetail_OverAllExposureLimit");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjOverallExposure));
            Value = Value + RandomStringUtils.randomNumeric(2);
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjOverallExposure, Value));
        } else if (Data.equalsIgnoreCase("OverAllExposureLimitOutofOffice") && Menu.equalsIgnoreCase("Organization Details")) {
            LogCapture.info("User enter overall exposure limit Out of office on Organization detail page......");
            String vObjOverAllExposureOutofOffice = Constants.RFQOR.getProperty("RFQ_OrgDetail_OverAllExposureOutofOffice");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjOverAllExposureOutofOffice));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjOverAllExposureOutofOffice, Value));
        } else if (Data.equalsIgnoreCase("Day") && Menu.equalsIgnoreCase("Opening Closing")) {
            LogCapture.info("User enter day on Opening Closing page......");
            String vObjDay = Constants.RFQOR.getProperty("RFQ_OpeningClosingDetails_Day");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjDay));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjDay, Value));
        } else if (Data.equalsIgnoreCase("SingleTradeLimit") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User enter SingleTradeLimit on Opening Closing page......");
            String vObjSingleTrade = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_SingleTradeLimit");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjSingleTrade));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSingleTrade, Value));
        } else if (Data.equalsIgnoreCase("Currency") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User enter Currency on OrgCurrency Details page......");
            String vObjCurrency = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_Currency");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjCurrency));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrency, Value));
        } else if (Data.equalsIgnoreCase("ExposureLimit") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User enter overall ExposureLimit on OrgCurrency Details page......");
            String vObjExposureLimit = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_ExposureLimit");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjExposureLimit));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjExposureLimit, Value));
        } else if (Data.equalsIgnoreCase("ExposureLimitOutofOffice") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User enter overall exposure limit Out of office on OrgCurrency Details page......");
            String vObjExposureLimitOutofOffice = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_ExposureLimitOutofOffice");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjExposureLimitOutofOffice));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjExposureLimitOutofOffice, Value));
        } else if (Data.equalsIgnoreCase("OpenPosition") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User enter OpenPosition on OrgCurrency Details page......");
            String vObjOpenPosition = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_OpenPosition");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjOpenPosition));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjOpenPosition, Value));
        } else if (Data.equalsIgnoreCase("ForwardTradeLimit") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User enter ForwardTradeLimit on OrgCurrency Details page......");
            String vObjForwardTradeLimit = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_ForwardTradeLimit");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjForwardTradeLimit));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardTradeLimit, Value));
        } else if (Data.equalsIgnoreCase("FromDate") && Menu.equalsIgnoreCase("One Time Configurable")) {
            LogCapture.info("User enter FromDate on One Time Configurable page......");
            String vObjFromDate = Constants.RFQOR.getProperty("RFQ_OneTimeScheduler_FromDate");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjFromDate));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromDate, Value));
        } else if (Data.equalsIgnoreCase("OverAllExposureLimit") && Menu.equalsIgnoreCase("One Time Configurable")) {
            LogCapture.info("User enter OverallExposureLimit on One Time Configurable page......");
            String vObjOverallExposureLimit = Constants.RFQOR.getProperty("RFQ_OneTimeScheduler_OverallExposureLimit");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjOverallExposureLimit));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjOverallExposureLimit, Value));
        } else if (Data.equalsIgnoreCase("QueryNarration") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User enter QueryNarration on Account Balance page......");
            String vObjQueryNarration = Constants.BankingOR.getProperty("BNK_AccountBalance_QueryNarration");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjQueryNarration));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueryNarration, ""));

            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjQueryNarration, Value));

        } else if (Data.equalsIgnoreCase("OpeningBalance") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User enter OpeningBalance on Account Balance page......");
            String vObjOpenBalance = Constants.BankingOR.getProperty("BNK_AccountBalance_OpenBalanceValue");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjOpenBalance));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjOpenBalance, Value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjOpenBalance, "enter"));
        } else if (Data.equalsIgnoreCase("OpeningBalance") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User enter OpeningBalance on Account Balance page......");
            String vObjOpenBalance = Constants.BankingOR.getProperty("BNK_AccountBalance_OpenBalanceValue");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjOpenBalance));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjOpenBalance, Value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjOpenBalance, "enter"));
        } else if (Data.equalsIgnoreCase("RecordID") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User enter RecordID on Account Balance page......");
            String vBNK_BalanceException_EnterID = Constants.BankingOR.getProperty("BNK_BalanceException_EnterID");
            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_BalanceException_EnterID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_BalanceException_EnterID, Value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_BalanceException_EnterID, "enter"));
        } else if (Data.equalsIgnoreCase("QueryNarration") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User enter QueryNarration on Balance Entry page......");
            key.pause("5", "");
            String vObjQueryNarration = Constants.BankingOR.getProperty("BNK_AccountBalance_QueryNarration");
//            Assert.assertEquals("PASS", Constants.key.clearText(vObjQueryNarration));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueryNarration, ""));

            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjQueryNarration, "Test"));
        } else if (Data.equalsIgnoreCase("Cost") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User enter Cost on Bank Account page......");
            String vObjEditCost = Constants.BankingOR.getProperty("BNK_EditCost");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjEditCost));
            Value = Value + RandomStringUtils.randomNumeric(2);
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEditCost, Value));
        } else if (Data.equalsIgnoreCase("QueryNarration") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User enter QueryNarration on Queries page......");
            String vQMRaiseQueryQueryNarration = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_QueryNarration");
            Assert.assertEquals("PASS", Constants.key.clearText(vQMRaiseQueryQueryNarration));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vQMRaiseQueryQueryNarration, Value));
        } else if (Data.equalsIgnoreCase("QueryNarration") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User enter QueryNarration on Queries page......");
            String vQMRaiseQueryQueryNarration = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_QueryNarration");
            Assert.assertEquals("PASS", Constants.key.click(vQMRaiseQueryQueryNarration, ""));
        } else if (Data.equalsIgnoreCase("Reason") && Menu.equalsIgnoreCase("Authorise Query")) {
            LogCapture.info("User enter Reason on Authorise Query page......");
            String vQMAuthoriseQuery_ReasonTextbox = Constants.QueryManagementOR.getProperty("BNK_QM_PendingAuthorise_AuthoriseQuery_ReasonTextbox");
            //Assert.assertEquals("PASS", Constants.key.click(vQMAuthoriseQuery_ReasonTextbox, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vQMAuthoriseQuery_ReasonTextbox));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vQMAuthoriseQuery_ReasonTextbox, Value));
        } else if (Data.equalsIgnoreCase("Status") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Status on Failed Payment Out page......");

            String vMessage_FailedPaymentOut_StatusSearch = Constants.MessageOR.getProperty("BNK_Message_FPO_StatusSearch");
            Assert.assertEquals("PASS", Constants.key.clearText(vMessage_FailedPaymentOut_StatusSearch));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vMessage_FailedPaymentOut_StatusSearch, Value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vMessage_FailedPaymentOut_StatusSearch, "enter"));

        } else if (Data.equalsIgnoreCase("Reference") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Enter Reference No......");
            String vQMQueries_RaiseQuery_Reference = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_Reference");
            Assert.assertEquals("PASS", Constants.key.clearText(vQMQueries_RaiseQuery_Reference));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vQMQueries_RaiseQuery_Reference, Value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vQMQueries_RaiseQuery_Reference, "enter"));
        } else if (Data.equalsIgnoreCase("Name") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User enter Name on Bank Account page......");
            StringBuilder sb = new StringBuilder();
            Random rnd = new Random();
            while (sb.length() < 18) {
                int index = (int) (rnd.nextFloat() * Value.length());
                sb.append(Value.charAt(index));
            }
            String randomName = sb.toString();
            String vObjEditName = Constants.BankingOR.getProperty("BNK_EditName");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjEditName));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEditName, randomName));
        }
    }

    @And("^User click on (Import Query|Close Query|Re-Open Query|RaiseQueryIcon|Respond Query|Authorise Query|Raise Query|Book Deal) and handle alert from (Incoming Queries|Queries|Pending Authorise|Payment Entries|Spot deal booking|Swap deal booking|RBS Spot deal booking|Spots deal booking) page$")
    public void userClickOnImportQueryAndHandleAlertFromIncomingQueriesPage(String Data, String Menu) throws Throwable {
        key.pause("2", "");
        if (Data.equalsIgnoreCase("Import Query") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User click on Import Query and see alert message on Incoming Queries......");

            String vQMIncomingQueries_ImportQuery = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_ImportQueryIcon");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQueries_ImportQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMIncomingQueries_ImportQuery, ""));
        }
        if (Data.equalsIgnoreCase("Import Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User click on Import Query and see alert message on Queries......");

            String vQMQueries_ImportQuery = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ImportQueries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMQueries_ImportQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMQueries_ImportQuery, ""));

        }
        if (Data.equalsIgnoreCase("Close Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User click on Close Query and see alert message on Queries......");

            String vQMQueries_CloseQuery = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_CloseQueryIcon");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMQueries_CloseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMQueries_CloseQuery, ""));
        }
        if (Data.equalsIgnoreCase("RaiseQueryIcon") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User click on Raise Query and see alert message on Incoming Queries......");

            String vBNK_QM_RaiseQueryOption = Constants.QueryManagementOR.getProperty("BNK_QM_RaiseQueryOption");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_RaiseQueryOption, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_QM_RaiseQueryOption, ""));

        }
        if (Data.equalsIgnoreCase("Re-Open Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User click on Re-Open Query and see alert message on Queries......");

            String vQMQueries_ReOpenQuery = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ReOpenQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMQueries_ReOpenQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMQueries_ReOpenQuery, ""));

        }
        if (Data.equalsIgnoreCase("Raise Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User click on Raise Query and see alert message on Queries......");

            String vQMRaiseQueryOption = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQueryOption");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMRaiseQueryOption, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMRaiseQueryOption, ""));
        }
        if (Data.equalsIgnoreCase("Respond Query") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User click on Respond Query and see alert message on Incoming Queries......");

            String vQMIncomingQueries_RespondQuery = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_RespondQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMIncomingQueries_RespondQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMIncomingQueries_RespondQuery, ""));

        }
        if (Data.equalsIgnoreCase("Authorise Query") && Menu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User click on Authorise Query and see alert message on Pending Authorise......");

            String vQMPendingAuthorise_AuthoriseQuery = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_PendingAuthorise_AuthoriseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMPendingAuthorise_AuthoriseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMPendingAuthorise_AuthoriseQuery, ""));
        }
        if (Data.equalsIgnoreCase("Raise Query") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User click on Raise Query and see alert message on Payment Entries......");

            String vQMPaymentEntries_RaiseQuery = Constants.PaymentMonitoringOR.getProperty("BNK_Payment_Entries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMPaymentEntries_RaiseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMPaymentEntries_RaiseQuery, ""));

        }
        if (Data.equalsIgnoreCase("Book Deal") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User click on Book Deal and see alert message on Spot deal booking......");

            String vSpotdealBookingButton = B2BOR.getProperty("SpotDealBooking_BookDealButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSpotdealBookingButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSpotdealBookingButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vSpotdealBookingButton, ""));
            Assert.assertEquals("PASS", Constants.key.isAlertPresent());
        }
        if (Data.equalsIgnoreCase("Book Deal") && Menu.equalsIgnoreCase("RBS Spot deal booking")) {
            LogCapture.info("User click on Book Deal ......");

            String vSpotdealBookingButton = B2BOR.getProperty("RBS_SpotDealBooking_BookDealButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSpotdealBookingButton, ""));
//            Assert.assertEquals("PASS", Constants.key.click(vSpotdealBookingButton,""));
            if (isAlertPresent(driver)) {
                LogCapture.info("User see alert message on Spot deal booking......");
                Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vSpotdealBookingButton, ""));
                Assert.assertEquals("PASS", Constants.key.isAlertPresent());
                LogCapture.info("User enter the reason ......");
                String vObjSpotDealBookingReason = Constants.B2BOR.getProperty("SpotDealBooking_Reason");
                Assert.assertEquals("PASS", Constants.key.javascrpiptEnterText(vObjSpotDealBookingReason, "Testing"));
                Assert.assertEquals("PASS", Constants.key.click(vSpotdealBookingButton, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.click(vSpotdealBookingButton, ""));
            }
        }
        if (Data.equalsIgnoreCase("Book Deal") && Menu.equalsIgnoreCase("Swap deal booking")) {
            LogCapture.info("User click on Book Deal and see alert message on Swap deal booking......");

            String vSwapdealBookingButton = B2BOR.getProperty("SwapDealBooking_BookDealButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSwapdealBookingButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vSwapdealBookingButton, ""));
            Assert.assertEquals("PASS", Constants.key.isAlertPresent());
        }
        if (Data.equalsIgnoreCase("Book Deal") && Menu.equalsIgnoreCase("Spots deal booking")) {
            LogCapture.info("User click on Book Deal and see alert message on Swap deal booking......");

            String vSpotsdealBookingButton = B2BOR.getProperty("SpotsDealBooking_BookDealButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSpotsdealBookingButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vSpotsdealBookingButton, ""));
            Assert.assertEquals("PASS", Constants.key.isAlertPresent());
        }
    }

    private static boolean isAlertPresent(WebDriver driver) {
        try {
            driver.switchTo().alert();
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    @And("^User click on (Submit|Schedule|Accept|Mark as B2B Disable|Invalidate|RaiseQuery|ExportToExcel|Merge|CloseQuery|Save Button|Submit Button) and handle alert from (Organization Details|Opening Closing|OrgCurrency Details|One Time Configurable|Pending B2B Deals|Account Balance|Balance Exception|Balance Entry|Bank Account|Payment Entries|Queries|Incoming Queries|Authorise Query|Failed Payment Out|Message Out) page$")
    public void userClickOnSubmitAndHandleAlertFromOrganizationDetailsPage(String Data, String Menu) throws Throwable {
        key.pause("6", "");
        if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Organization Details")) {
            LogCapture.info("User click on submit and see alert message on organization details page......");

            String vObjSubmitDetails = Constants.RFQOR.getProperty("RFQ_OrganizationDetails_Submit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitDetails, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjSubmitDetails, ""));
        } else if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Opening Closing")) {
            LogCapture.info("User click on submit and see alert message on Opening Closing page......");

            String vObjSubmitDetails = Constants.RFQOR.getProperty("RFQ_OpeningClosingDetails_Submit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitDetails, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjSubmitDetails, ""));
        } else if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User click on submit and see alert message on OrgCurrency Details page......");

            String vObjSubmitDetails = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_Submit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitDetails, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjSubmitDetails, ""));
        } else if (Data.equalsIgnoreCase("Schedule") && Menu.equalsIgnoreCase("One Time Configurable")) {
            LogCapture.info("User click on Schedule and see alert message on One Time Configurable Details page......");

            String vObjSchedule = Constants.RFQOR.getProperty("RFQ_OneTimeScheduler_ScheduleButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSchedule, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjSchedule, ""));
        } else if (Data.equalsIgnoreCase("Accept") && Menu.equalsIgnoreCase("Pending B2B Deals")) {
            LogCapture.info("User click on Accept and see alert message on Pending B2B Deals Details page......");

            String vObjAccept = Constants.RFQOR.getProperty("RFQ_PendingB2BDeals_Accept");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAccept, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjAccept, ""));
        } else if (Data.equalsIgnoreCase("Mark as B2B Disable") && Menu.equalsIgnoreCase("Pending B2B Deals")) {
            LogCapture.info("User click on Mark as B2B Disable and see alert message on Pending B2B Deals Details page......");

            String vObjMarkB2bDiable = Constants.RFQOR.getProperty("RFQ_PendingB2BDeals_MarkB2BDiable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMarkB2bDiable, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjMarkB2bDiable, ""));
        } else if (Data.equalsIgnoreCase("Invalidate") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User click on Invalidatee and see alert message on Account Balance page......");

            String vObjInvalidate = Constants.BankingOR.getProperty("BNK_AccountBalance_Invalidate");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvalidate, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjInvalidate, ""));
        } else if (Data.equalsIgnoreCase("Invalidate") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User click on Invalidate and see alert message on Balance Exception page......");

            String vObjInvalidate = Constants.BankingOR.getProperty("BNK_AccountBalance_Invalidate");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvalidate, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjInvalidate, ""));
        } else if (Data.equalsIgnoreCase("RaiseQuery") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User click on RaiseQuery and see alert message on Account Balance page......");

            String vObjRaiseQuery = Constants.BankingOR.getProperty("BNK_AccountBalance_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRaiseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjRaiseQuery, ""));
        } else if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Click on Submit raise query.....");

            String vObjSubmitQuery = Constants.BankingOR.getProperty("BNK_AccountBalance_QuerySubmit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjSubmitQuery, ""));

        } else if (Data.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Click on ExportToExcel query at top right corer.....");

            String vObjExportToExcel = Constants.BankingOR.getProperty("BNK_AccountBalance_ExportToExcel");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjExportToExcel, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjExportToExcel, ""));
        } else if (Data.equalsIgnoreCase("Merge") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User Click on merge icon.....");

            String vBNK_AccountBalance_AccDetails_RecordMerge = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails_RecordMerge");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AccountBalance_AccDetails_RecordMerge, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_AccountBalance_AccDetails_RecordMerge, ""));
        } else if (Data.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User Click on ExportToExcel query at top right corer.....");

            String vExportToExcel = Constants.BankingOR.getProperty("BNK_BalanceEntries_Export");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vExportToExcel, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vExportToExcel, ""));
        } else if (Data.equalsIgnoreCase("RaiseQuery") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User click on RaiseQuery and see alert message on Balance Entry page......");

            String vObjRaiseQuery = Constants.BankingOR.getProperty("BNK_AccountBalance_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRaiseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjRaiseQuery, ""));
        } else if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Balance Entry")) {
            LogCapture.info("User Click on Submit raise query.....");

            String vObjSubmitQuery = Constants.BankingOR.getProperty("BNK_AccountBalance_QuerySubmit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjSubmitQuery, ""));

        } else if (Data.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User Click on ExportToExcel query at top right corer.....");

            String vObjExportToExcel = Constants.BankingOR.getProperty("BNK_BalanceException_ExportToExcel");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjExportToExcel, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjExportToExcel, ""));
        } else if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User click on submit and see alert message on Bank Account page......");

            String vObjSubmitDetails = Constants.BankingOR.getProperty("BNK_BankAccount_Submit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSubmitDetails, ""));
            String vBNK_LoadingBankAccount = Constants.BankingOR.getProperty("BNK_LoadingBankAccount");
            //Assert.assertEquals("PASS", Constants.key.waitForElementNotVisible(vBNK_LoadingBankAccount,60));
            Assert.assertEquals("PASS", Constants.key.waitForAlert(120));
        } else if (Data.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("User Click on ExportToExcel query at top right corer.....");

            String vObjExportToExcel = Constants.BankingOR.getProperty("BNK_BalanceException_ExportToExcel");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjExportToExcel, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjExportToExcel, ""));
        } else if (Data.equalsIgnoreCase("RaiseQuery") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User click on RaiseQuery and see alert message on Payment Entries page......");

            String vObjRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRaiseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjRaiseQuery, ""));
        } else if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on Submit raise query.....");

            String vObjSubmitQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_SubmitQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjSubmitQuery, ""));

        } else if (Data.equalsIgnoreCase("CloseQuery") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User click on CloseQuery and see alert message on Queries page......");

            String vCloseQuery = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_CloseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCloseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vCloseQuery, ""));
        } else if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on Submit Import query.....");

            String vQMSubmitQuery = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ImportQueries_SubmitQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMSubmitQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMSubmitQuery, ""));

        } else if (Data.equalsIgnoreCase("Submit") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User Click on Submit Import query.....");

            String vQMSubmitQuery = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ImportQueries_SubmitQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMSubmitQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMSubmitQuery, ""));
        } else if (Data.equalsIgnoreCase("Save Button") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on Save button .....");

            String vQMRaiseQuerySaveButton = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_SaveButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMRaiseQuerySaveButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMRaiseQuerySaveButton, ""));
        } else if (Data.equalsIgnoreCase("Save Button") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User Click on Save button .....");

            String vQMRaiseQuery_RespondQuery_SaveButton = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_RespondQuery_SaveButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMRaiseQuery_RespondQuery_SaveButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMRaiseQuery_RespondQuery_SaveButton, ""));

        } else if (Data.equalsIgnoreCase("Submit Button") && Menu.equalsIgnoreCase("Authorise Query")) {
            LogCapture.info("User click on submit Button and see alert message on Authorise page......");

            String vQMAuthoriseQuery_SubmitButton = Constants.QueryManagementOR.getProperty("BNK_QM_PendingAuthorise_AuthoriseQuery_SubmitButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQMAuthoriseQuery_SubmitButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vQMAuthoriseQuery_SubmitButton, ""));
        } else if (Data.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Click on ExportToExcel query at top right corer.....");

            String vExportToExcel = Constants.BankingOR.getProperty("BNK_BalanceEntries_Export");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vExportToExcel, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vExportToExcel, ""));
        } else if (Data.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("Message Out")) {
            LogCapture.info("User Click on ExportToExcel query at top right corer.....");

            String vExportToExcel = Constants.BankingOR.getProperty("BNK_BalanceEntries_Export");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vExportToExcel, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vExportToExcel, ""));
        }

    }

    @Then("^User verify the Banking  Application Title$")
    public void userVerifyTheBankingApplicationTitle() throws Exception {
        LogCapture.info("User is verifying the Banking Application Title ......");
        String vObjPageTitle = Constants.BankingOR.getProperty("BankingHome_PageTitle");
        System.out.println(vObjPageTitle);
        Assert.assertEquals("PASS", Constants.key.VerifyTitle(vObjPageTitle, "Banking"));
    }

    @And("^User enter (QueryNarration)\"([^\"]*)\" on (Payment Entries) page$")
    public void userEnterQueryNarrationOnPaymentEntriesPage(String Data, String Value, String Menu) throws Throwable {
        key.pause("6", "");
        if (Data.equalsIgnoreCase("QueryNarration") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User enter QueryNarration on Payment Entries page......");

            String vObjQueryNarration = Constants.BankingOR.getProperty("BNK_AccountBalance_QueryNarration");
            Assert.assertEquals("PASS", Constants.key.clearText(vObjQueryNarration));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjQueryNarration, Value));

        }
    }


    @Then("^User should successfully see (Rule Engine Status) \"([^\"]*)\" on (Rule Engine) page$")
    public void userShouldSuccessfullySeeRuleEngineStatusOnRuleEnginePage(String Data, String Value, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("Rule Engine Enabled") && Menu.equalsIgnoreCase("Rule Engine")) {
            LogCapture.info("Rule Engine details data loading ......");

            String vObjRuleEngineStatus = Constants.RFQOR.getProperty("RFQ_RuleEngine_Status");
            if (Constants.key.getText(vObjRuleEngineStatus).equalsIgnoreCase(Value)) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vObjRuleEngineStatus, "Enabled"));
            } else {
                Assert.assertEquals("PASS", Constants.key.verifyText(vObjRuleEngineStatus, "Disabled"));


            }

        }
    }

    @And("^User should successfully see alert message \"([^\"]*)\" on (Organization Details|Failed Payment Out|Opening Closing|OrgCurrency Details|One Time Configurable|Pending B2B Deals|Account Balance|Balance Entry|Balance Exception|Payment Approval|Bank Account|Change Properties|Message Out|Manual PSR Upload|Counter Party|ROF Queue) page$")
    public void userShouldSuccessfullySeeMessageOnOrganizationDetailsPage(String Value, String Menu) throws Throwable {
        key.pause("6", "");
        if (Menu.equalsIgnoreCase("Account Balance") || Menu.equalsIgnoreCase("Failed Payment Out") || Menu.equalsIgnoreCase("Opening Closing") || Menu.equalsIgnoreCase("OrgCurrency Details") || Menu.equalsIgnoreCase("Pending B2B Deals") || Menu.equalsIgnoreCase("One Time Configurab") || Menu.equalsIgnoreCase("Balance Entry") || Menu.equalsIgnoreCase("Balance Exception") || Menu.equalsIgnoreCase("Payment Approval") || Menu.equalsIgnoreCase("Bank Account") || Menu.equalsIgnoreCase("Change Properties") || Menu.equalsIgnoreCase("Message Out") || Menu.equalsIgnoreCase("Manual PSR Upload") || Menu.equalsIgnoreCase("Counter Party") || Menu.equalsIgnoreCase("ROF Queue")) {
            LogCapture.info("User see alert message respective page......");
            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + Value);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(Value));
        }
        key.pause("5", "");
    }


    @And("^User click on (AccBalanceRecord|BalanceEntryRecord|Payment Entries Record|RaisedQueryRecord) and check (Raise Query|Invalidate|Close Query) present from (Account Balance|Balance Entry|Payment Entries|Queries|Balance Exception) page$")
    public void userClickOnAccBalanceRecordAndCheckRaiseQueryPresentFromAccountBalancePage(String Data, String Value, String Menu) throws Throwable {
        if (Value.equalsIgnoreCase("Raise Query") && Menu.equalsIgnoreCase("Account Balance") && Data.equalsIgnoreCase("AccBalanceRecord")) {
            LogCapture.info("User Click on AccBalanceRecord checkbox.....");

            String vObjAccBalanceDetailsRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails");
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjAccBalanceDetailsRecord));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 1; i <= listOfElements.size(); i++) {
                String SelectRecord = "//table[@id='bankEntriesDetails']//tr[contains(@onclick,'loadInto')][" + (i) + "]//input";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectRecord, ""));
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
                String vObjRaiseQuery = Constants.BankingOR.getProperty("BNK_AccountBalance_RaiseQuery");
                if (Constants.driver.findElement(By.xpath(vObjRaiseQuery)).isDisplayed()) {
                    break;
                }
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
            }
        } else if (Value.equalsIgnoreCase("Invalidate") && Menu.equalsIgnoreCase("Account Balance") && Data.equalsIgnoreCase("AccBalanceRecord")) {
            LogCapture.info("User Click on AccBalanceRecord checkbox.....");

            String vObjAccBalanceDetailsRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails");
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjAccBalanceDetailsRecord));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 1; i <= listOfElements.size(); i++) {
                String SelectRecord = "//table[@id='bankEntriesDetails']//tr[contains(@onclick,'loadInto')][" + (i) + "]//input";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectRecord, ""));
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
                String vObjInvalidate = Constants.BankingOR.getProperty("BNK_AccountBalance_Invalidate");
                if (Constants.driver.findElement(By.xpath(vObjInvalidate)).isDisplayed()) {
                    break;
                }
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
            }
        } else if (Value.equalsIgnoreCase("Raise Query") && Menu.equalsIgnoreCase("Balance Entry") && Data.equalsIgnoreCase("BalanceEntryRecord")) {
            key.pause("15", "");
            LogCapture.info("User Click on BalanceEntryRecord checkbox.....");

            String vObjAccBalanceDetailsRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAccBalanceDetailsRecord, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjAccBalanceDetailsRecord));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 1; i <= listOfElements.size(); i++) {
                String SelectRecord = "//table[@id='bankEntriesDetails']//tr[contains(@onclick,'loadInto')][" + (i) + "]//input";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectRecord, ""));

                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
                String vObjRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_RaiseQuery");
                if (Constants.driver.findElement(By.xpath(vObjRaiseQuery)).isDisplayed()) {
                    break;
                }
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
            }
        } else if (Value.equalsIgnoreCase("Invalidate") && Menu.equalsIgnoreCase("Balance Exception") && Data.equalsIgnoreCase("AccBalanceRecord")) {
            LogCapture.info("User Click on AccBalanceRecord checkbox.....");

            String vObjAccBalanceDetailsRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails");
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjAccBalanceDetailsRecord));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 1; i <= listOfElements.size(); i++) {
                String SelectRecord = "//table[@id='bankEntriesDetails']//tr[contains(@onclick,'loadInto')][" + (i) + "]//input";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectRecord, ""));
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
                String vObjInvalidate = Constants.BankingOR.getProperty("BNK_AccountBalance_Invalidate");
                if (Constants.driver.findElement(By.xpath(vObjInvalidate)).isDisplayed()) {
                    break;
                }
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
            }
        } else if (Value.equalsIgnoreCase("Raise Query") && Menu.equalsIgnoreCase("Payment Entries") && Data.equalsIgnoreCase("Payment Entries Record")) {
            LogCapture.info("User Click on Payment Entries Record checkbox.....");
            String vObjBNK_PaymentEntries_EnterPaymentType = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_EnterPaymentType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_EnterPaymentType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_EnterPaymentType, "International Payment"));
            key.pause("7", "");
            String vObjBNK_PaymentEntries_SelectBank = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_SelectBank, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_SelectBank, "Barclays"));

            String vPaymentEntriesRecord = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PaymentEntries_Records");
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vPaymentEntriesRecord));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 1; i <= listOfElements.size(); i++) {
                String SelectRecord1 = "//table[@id='paymentEntriesDIV']//tr[contains(@onclick,'loadInto')][" + i + "]//input";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectRecord1, ""));
                key.pause("7", "");
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord1, ""));
                String vPaymentEntriesRaiseQuery = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_RaiseQuery");
                if (Constants.driver.findElement(By.xpath(vPaymentEntriesRaiseQuery)).isDisplayed()) {
                    String vPaymentEntriesCapturedID = "//table[@id='paymentEntriesDIV']//tbody//tr[" + (i) + "]//td[2]";
                    String ID = Constants.key.getText(vPaymentEntriesCapturedID);
                    Constants.QueryIdValue = ID;
                    break;
                }
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord1, ""));
            }
        } else if (Value.equalsIgnoreCase("Close Query") && Menu.equalsIgnoreCase("Queries") && Data.equalsIgnoreCase("RaisedQueryRecord")) {
            LogCapture.info("User Click on Raised Query Record checkbox.....");

            String vQueriesRecord = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Records");
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vQueriesRecord));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 1; i <= listOfElements.size(); i++) {
                String SelectRecord1 = "//table[@id='queryDIV']//tr[contains(@onclick,'loadInto')][\" + (i) + \"]//input";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectRecord1, ""));
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord1, ""));
                String vCloseQuery = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_CloseQuery");
                if (Constants.driver.findElement(By.xpath(vCloseQuery)).isDisplayed()) {
                    break;
                }
                Assert.assertEquals("PASS", Constants.key.click(SelectRecord1, ""));

            }
        }
    }

    @Then("^User verify the data is populated correctly$")
    public void userVerifyTheDataIsPopulatedCorrectly() throws Exception {
        LogCapture.info("Event Log data loading ......");
        String vObjBalance_ChangePreferenceCheckBox = Constants.BankingOR.getProperty("Balance_ChangePreferenceCheckBox");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBalance_ChangePreferenceCheckBox, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjBalance_ChangePreferenceCheckBox, ""));

    }

    @And("^User select (InstitutionFilter|CurrencyFilter) \"([^\"]*)\" from Account Balance page$")
    public void userSelectInstitutionFromAccountBalancePage(String Value, String Data) throws Throwable {
        if (Value.equalsIgnoreCase("InstitutionFilter")) {
            LogCapture.info("User select Organization ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_AccountBalanceInstitutionFilter = Constants.BankingOR.getProperty("BNK_AccountBalanceInstitutionFilter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AccountBalanceInstitutionFilter, ""));
//            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_AccountBalanceInstitutionFilter, "Currencies Direct"));
//            String vBNK_AccountBalanceInstitutionFilter=Constants.BankingOR.getProperty("BNK_AccountBalanceInstitutionFilter");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_AccountBalanceInstitutionFilter, Data));


        }
        if (Value.equalsIgnoreCase("CurrencyFilter")) {
            LogCapture.info("User select Currency ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_PDQ_CurrencyFilter = Constants.BankingOR.getProperty("BNK_DPQ_SelectCurrency");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_PDQ_CurrencyFilter, Data));
        }
    }

    @Then("^verify the data is filtered successfully for (Institution|) \"([^\"]*)\" on (Account Balance) Page$")
    public void verifyTheDataIsFilteredSuccessfullyForInstitutionOnAccountBalancePage(String Value, String Data) throws Throwable {
        if (Value.equalsIgnoreCase("Institution")) {
            LogCapture.info("User select filter institute ......");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_AccountBalanceInstitutionFiltered = Constants.BankingOR.getProperty("BNK_AccountBalanceInstitutionFiltered");
            key.pause("6", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_AccountBalanceInstitutionFiltered, Data));
        }
    }

    @Then("^verify the data is reset successfully on Account Balance page$")
    public void verifyTheDataIsResetSuccessfullyOnAccountBalancePage() throws Throwable {
        LogCapture.info("User select reset filter option ......");
        String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
        Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        String totalRecords = Constants.key.getText(Constants.BankingOR.getProperty("BNK_AccountBalance_TotalRecords"));
        String dataCount = Constants.key.getText(Constants.BankingOR.getProperty("BNK_AccountBalanace_DataCount"));
        Assert.assertTrue(totalRecords.contains(dataCount));
    }

    @Then("^verify the id value on Queries page$")
    public void verifyTheIDValueOnQueriesPage() throws Throwable {
        LogCapture.info("Id Value ......");
        String QueryIdValue = Constants.key.getText(Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ID"));
        System.out.println(QueryIdValue);
        // String dataCount=Constants.key.getText(Constants.BankingOR.getProperty("BNK_AccountBalanace_DataCount"));
        //Assert.assertTrue(totalRecords.contains(dataCount));
    }


    @And("^User click on (ChangePreference|Institution ChangePreference|ApplyChangePreference|Record|User Select multiple Records) from PotentialDuplicateQueue page$")
    public void userClickOnChangePreferenceFromPotentialDuplicateQueuePage(String Value) throws Throwable {
        key.pause("6", "");
        if (Value.equalsIgnoreCase("ChangePreference")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vObjChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjChangePreference, ""));
        } else if (Value.equalsIgnoreCase("Institution ChangePreference")) {
            LogCapture.info("User deselect Institution ChangePreference change preference at top right corner.....");

            String vObjInstituionChangePreference = Constants.BankingOR.getProperty("BNK_PotentialQueue_ChangePreferenceInstitution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstituionChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjInstituionChangePreference, ""));
        } else if (Value.equalsIgnoreCase("ApplyChangePreference")) {
            LogCapture.info("User click on apply change preference at top right corner.....");

            String vObjApplyChangePreference = Constants.BankingOR.getProperty("BNK_AccountBalance_ApplyChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyChangePreference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjApplyChangePreference, ""));
        } else if (Value.equalsIgnoreCase("Record")) {
            LogCapture.info("User Selects  Records.....");

            String vObjPDQRecord = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPDQRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPDQRecord, ""));
        } else if (Value.equalsIgnoreCase(" User Select multiple Records")) {
            LogCapture.info("User Selects multiple  Records.....");

            String vObjPDQRecord = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPDQRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPDQRecord, ""));
            String vObjPDQSecondRecord = Constants.BankingOR.getProperty("BANK_PDQ_SecondRowInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPDQSecondRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPDQSecondRecord, ""));
            String vObjPDQThirdRecord = Constants.BankingOR.getProperty("Bank_PDQ_ThirdRowInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPDQThirdRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPDQThirdRecord, ""));
        }
    }

    @And("^User click on (FirstAccBalanceRecord|SecondAccBalanceRecord) from Balance Exception page$")
    public void userClickOnFirstAccBalanceRecordFromBalanceExceptionPage(String Value) throws Throwable {
        if (Value.equalsIgnoreCase("FirstAccBalanceRecord")) {
            LogCapture.info("User Click on FirstAccBalanceRecord ......");

            String vBNK_AccountBalance_AccDetails_SelectFirstRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails_SelectFirstRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AccountBalance_AccDetails_SelectFirstRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_AccountBalance_AccDetails_SelectFirstRecord, ""));
        } else if (Value.equalsIgnoreCase("SecondAccBalanceRecord")) {
            LogCapture.info("User Click on SecondAccBalanceRecord ......");

            String vBNK_AccountBalance_AccDetails_SelectSecondRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_AccDetails_SelectSecondRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AccountBalance_AccDetails_SelectSecondRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_AccountBalance_AccDetails_SelectSecondRecord, ""));
        }
    }

    @And("^User click on (PaymentApprovalRecord|AuditTrail|SecondPaymentApprovalRecord) from Payment Approval page$")
    public void userClickOnPaymentApprovalRecordFromPaymentApprovalPage(String Value) throws Throwable {
        key.pause("6", "");
        if (Value.equalsIgnoreCase("PaymentApprovalRecord")) {
            LogCapture.info("User Click on PaymentApprovalRecord ......");

            String vBanking_PaymentMonitoring_PaymentApprovalRecord = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_PaymentApprovalRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_PaymentApprovalRecord, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBanking_PaymentMonitoring_PaymentApprovalRecord, ""));

        } else if (Value.equalsIgnoreCase("AuditTrail")) {
            LogCapture.info("User Click on AuditTrail ......");

            String vBanking_PaymentMonitoring_AuditTrail = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_AuditTrail, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_PaymentMonitoring_AuditTrail, ""));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

        } else if (Value.equalsIgnoreCase("SecondPaymentApprovalRecord")) {
            LogCapture.info("User Click on SecondPaymentApprovalRecord ......");

            String vBanking_PaymentMonitoring_SecondPaymentApprovalRecord = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_SecondPaymentApprovalRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_SecondPaymentApprovalRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_PaymentMonitoring_SecondPaymentApprovalRecord, ""));
        }
    }

    @Then("^User should successfully see (Audit Trails Details|Record Not present|Selected Record Not present) on Payment Approval page$")
    public void userShouldSuccessfullySeeAuditTrailsDetailsOnPaymentApprovalPage(String data) throws Throwable {
        key.pause("6", "");
        if (data.equalsIgnoreCase("Audit Trails Details")) {
            LogCapture.info("Audit Trails Details loading ......");

            String vBanking_PaymentMonitoring_AuditTrailMessageNo = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailMessageNo");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_AuditTrailMessageNo, ""));
            String vBanking_PaymentMonitoring_AuditTrailMessageNoText = key.getText(vBanking_PaymentMonitoring_AuditTrailMessageNo);
            if (vBanking_PaymentMonitoring_AuditTrailMessageNoText.equalsIgnoreCase("PAIN.001")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageNo, "PAIN.001"));
            } else if (vBanking_PaymentMonitoring_AuditTrailMessageNoText.equalsIgnoreCase("MT103")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageNo, "MT103"));
            }
            String vBanking_PaymentMonitoring_AuditTrailMessageType = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailMessageType");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageType, "Message"));
            String vBanking_PaymentMonitoring_AuditTrailDirection = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailDirection");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailDirection, "Received"));
            String vBanking_PaymentMonitoring_AuditTrailUsername = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailUsername");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailUsername, "cd_api_user"));
            String vBanking_PaymentMonitoring_AuditTrailAction = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailAction");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailAction, "OTHER"));

        } else if (data.equalsIgnoreCase("Selected Record Not present")) {
            LogCapture.info("Payment Approval data loading ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBanking_RejectedPayment_SearchID = Constants.PaymentMonitoringOR.getProperty("Banking_RejectedPayment_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_RejectedPayment_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vBanking_RejectedPayment_SearchID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBanking_RejectedPayment_SearchID, PaymentApprovalRecordID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBanking_RejectedPayment_SearchID, "enter"));
            String vBanking_PaymentMonitoring_FirstRecordID = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_FirstRecordID");
            Assert.assertEquals("PASS", Constants.key.notexist(vBanking_PaymentMonitoring_FirstRecordID, ""));

        } else if (data.equalsIgnoreCase("Record Not present")) {
            LogCapture.info("PaymentApproval data loading ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBanking_RejectedPayment_SearchID = Constants.PaymentMonitoringOR.getProperty("Banking_RejectedPayment_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_RejectedPayment_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vBanking_RejectedPayment_SearchID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBanking_RejectedPayment_SearchID, PaymentApprovalRecordID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBanking_RejectedPayment_SearchID, "enter"));
            key.pause("4", "");
            String vBanking_PaymentMonitoring_FirstRecordID = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_FirstRecordID");
            Assert.assertEquals("PASS", Constants.key.notexist(vBanking_PaymentMonitoring_FirstRecordID, ""));

        }
    }

    @And("^User capture the (ID|Query ID) from (Queries|Incoming Queries|Payment Entries|Pending Authorise) page$")
    public void userCaptureTheIDFromQueriesPage(String Data, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("ID") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User capture ID on Queries page......");

            String vQMFirstQueryID = Constants.QueryManagementOR.getProperty("BNK_QM_Queries_ID");
            QueryIdValue = Constants.key.getText(vQMFirstQueryID);

        } else if (Data.equalsIgnoreCase("ID") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User capture ID on Incoming Queries page......");

            String vQMFirstQueryID = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_FirstID");
            QueryIdValue = Constants.key.getText(vQMFirstQueryID);
        } else if (Data.equalsIgnoreCase("Query ID") && Menu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User capture Query ID on Pending Authorise page......");

            String vQMRaiseQueryQueryID = Constants.QueryManagementOR.getProperty("BNK_QM_PAQQueryID");
            QueryID2 = Constants.key.getText(vQMRaiseQueryQueryID);
            LogCapture.info("captured Query ID on Pending Authorise page......" + QueryID2);

        } else if (Data.equalsIgnoreCase("ID") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User capture ID on Payment Entries page......");

            String vPaymentEntriesCapturedID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_CapturedID");
            QueryIdValue = Constants.key.getText(vPaymentEntriesCapturedID);

        }
    }


    @And("^User click on (Reject All|Approve All|Reject|Approve|Submit) Payment and handle alert Payment Approval page$")
    public void userClickOnRejectAllPaymentAndHandleAlertPaymentApprovalPage(String Data) throws Throwable {
        key.pause("6", "");
        if (Data.equalsIgnoreCase("Reject All")) {
            LogCapture.info("User click on Reject All and see alert message on Payment Approval page......");

            String vBanking_PaymentMonitoring_RejectALlPayment = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_RejectALlPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_RejectALlPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBanking_PaymentMonitoring_RejectALlPayment, ""));
        } else if (Data.equalsIgnoreCase("Approve All")) {
            LogCapture.info("User click on Approve All and see alert message on Payment Approval page......");

            String vBanking_PaymentMonitoring_ApprovAllPayment = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_ApprovAllPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_ApprovAllPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBanking_PaymentMonitoring_ApprovAllPayment, ""));

        } else if (Data.equalsIgnoreCase("Reject")) {
            LogCapture.info("User click on Reject and see alert message on Payment Approval page......");

            String vBanking_PaymentMonitoring_RejectPayment = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_RejectPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_RejectPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBanking_PaymentMonitoring_RejectPayment, ""));
        } else if (Data.equalsIgnoreCase("Approve")) {
            LogCapture.info("User click on Approve and see alert message on Payment Approval page......");

            String vBanking_PaymentMonitoring_ApprovePayment = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_ApprovePayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_ApprovePayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBanking_PaymentMonitoring_ApprovePayment, ""));
        } else if (Data.equalsIgnoreCase("Submit")) {
            LogCapture.info("User Click on reject payment submit button ......");

            String vBanking_PaymentMonitoring_SubmitRejectPayment = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_SubmitRejectPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_SubmitRejectPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBanking_PaymentMonitoring_SubmitRejectPayment, ""));
        }
    }


    @And("^User capture the (RecordID|Selected RecordID|Currency Position) from (Payment Approval|BlotterReport) page$")
    public void userCaptureTheRecordIDFromPaymentApprovalPage(String Data, String Menu) throws Throwable {
        key.pause("6", "");
        if (Data.equalsIgnoreCase("RecordID") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User capture Record ID on Payment Approval page......");

            String vBanking_PaymentMonitoring_FirstRecordID = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_FirstRecordID");
            PaymentApprovalRecordID = Constants.key.getText(vBanking_PaymentMonitoring_FirstRecordID);

        } else if (Data.equalsIgnoreCase("Selected RecordID") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User capture Record ID on Payment Approval page......");

            String vBanking_PaymentMonitoring_FirstRecordID = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_FirstRecordID");
            PaymentApprovalRecordID = Constants.key.getText(vBanking_PaymentMonitoring_FirstRecordID);
            String vBanking_PaymentMonitoring_SecondRecordID = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_SecondRecordID");
            SecondPaymentApprovalRecordID = Constants.key.getText(vBanking_PaymentMonitoring_SecondRecordID);
        } else if (Data.equalsIgnoreCase("Currency Position") && Menu.equalsIgnoreCase("BlotterReport Approval")) {
            LogCapture.info("User capture Currency Position on Blotter Report page......");

            String VEURCurrencyPosition = Constants.PaymentMonitoringOR.getProperty("B2B_BlotterReport_SpotDealBooking_EUR_CurrencyPosition");
            CurrencyPosition = Constants.key.getText(VEURCurrencyPosition);
        }
    }

    @And("^Verify the (Record|Selected Records) added successfully with specific ID in Rejected Payment List$")
    public void verifyTheRecordAddedSuccessfullyWithSpecificIDInRejectedPaymentList(String Data) throws Throwable {
        if (Data.equalsIgnoreCase("Record")) {
            LogCapture.info("User verify Record ID on Rejected Payment page......");

            String vBanking_RejectedPayment_SearchID = Constants.PaymentMonitoringOR.getProperty("Banking_RejectedPayment_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_RejectedPayment_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vBanking_RejectedPayment_SearchID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBanking_RejectedPayment_SearchID, PaymentApprovalRecordID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBanking_RejectedPayment_SearchID, "enter"));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBanking_RejectPayment_FirstRecordID = Constants.PaymentMonitoringOR.getProperty("Banking_RejectPayment_FirstRecordID");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_RejectPayment_FirstRecordID, PaymentApprovalRecordID));

        } else if (Data.equalsIgnoreCase("Selected Record")) {
            LogCapture.info("User verify Selected Record ID on Rejected Payment page......");
            String vBanking_RejectedPayment_SearchID = Constants.PaymentMonitoringOR.getProperty("Banking_RejectedPayment_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_RejectedPayment_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vBanking_RejectedPayment_SearchID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBanking_RejectedPayment_SearchID, PaymentApprovalRecordID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBanking_RejectedPayment_SearchID, "enter"));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBanking_RejectPayment_FirstRecordID = Constants.PaymentMonitoringOR.getProperty("Banking_RejectPayment_FirstRecordID");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_RejectPayment_FirstRecordID, PaymentApprovalRecordID));
        }
    }

    @And("^User Apply Filter on (Institution) \"([^\"]*)\" on (Balance Exception) Page$")
    public void userApplyFilterOnInstitutionOnBalanceExceptionPage(String Value, String OptFilter, String Menu) throws Throwable {
        if (Value.equalsIgnoreCase("Institution") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("User is Applying for Filter on Institution Row......");

            String vObjSelectInstitution = Constants.BankingOR.getProperty("BNK_BalanceExceptions_SelectInstitution");
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjSelectInstitution, OptFilter));
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
        }
    }

    @Then("^User should successfully see record as per applied filter for (Institution|Reset Filter) \"([^\"]*)\" on (Balance Exception) page$")
    public void userShouldSuccessfullySeeRecordAsPerAppliedFilterForInstitutionOnBalanceExceptionPage(String Filter, String Value, String Menu) throws Throwable {
        if (Filter.equalsIgnoreCase("Institution") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("Institution Filter Table is loading ......");
            String vObjTableData = Constants.BankingOR.getProperty("BNK_BalanceException_RecordSelect");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTableData, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTableData, Value));

        } else if (Filter.equalsIgnoreCase("Reset Filter") && Menu.equalsIgnoreCase("Balance Exception")) {
            LogCapture.info("Reset Filter is loading ......");
            String vObjSelectDefaultData = Constants.BankingOR.getProperty("BNK_BalanceExceptions_SelectInstitution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectDefaultData, ""));
            String gettingValue = Constants.key.ValueOfIndexAt(vObjSelectDefaultData, "0");
            Assert.assertTrue(gettingValue.contains(Value));
        }
    }

    @And("^User Click on (Add Bank|Add Button) from appeared popup$")
    public void userClickOnAddBankFromAppearedPopup(String Value) throws Exception {
        if (Value.equalsIgnoreCase("Add Bank")) {
            LogCapture.info("User is clicking in Add Bank button ......");

            String vBNK_BankAccount_AddBank = Constants.BankingOR.getProperty("BNK_BankAccount_AddBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_BankAccount_AddBank, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_BankAccount_AddBank, ""));
        } else if (Value.equalsIgnoreCase("Add Button")) {
            LogCapture.info("User is Adding Bank in Bank Account ......");

            String vBNK_AddBankButton = Constants.BankingOR.getProperty("BNK_AddBankButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AddBankButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_AddBankButton, ""));
            //Assert.assertEquals("PASS", Constants.key.waitForAlert(120));
        }
    }

    @And("^User Enter Vaild Details on (BankName) (BankDescription) and (BankCode) Fields$")
    public void userEnterVaildDetailsOnBankNameBankDescriptionAndBankCodeFields(String Name, String Dec, String Code) throws Exception {
        if (Name.equalsIgnoreCase("BankName") && Dec.equalsIgnoreCase("BankDescription") && Code.equalsIgnoreCase("BankCode")) {
            LogCapture.info("User Entering vaild details on all Fileds ......");

            String vBNK_AddBank_Name = Constants.BankingOR.getProperty("BNK_AddBank_Name");
            String vBNK_AddBank_Description = Constants.BankingOR.getProperty("BNK_AddBank_Description");
            String vBNK_AddBank_Code = Constants.BankingOR.getProperty("BNK_AddBank_Code");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AddBank_Name, ""));
            Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vBNK_AddBank_Name, 5));
            Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vBNK_AddBank_Description, 10));
            String Value = RandomStringUtils.randomNumeric(3);
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_AddBank_Code, Value));
        }
    }

    @And("^User click on (Payment Monitoring) Menu from Main (Dashboard) for Payment TC$")
    public void userClickOnPaymentMonitoringMenuFromMainDashboardForPaymentTc(String MainMenu, String SubMenu) throws Exception {
        key.pause("3", "");
        if (MainMenu.equalsIgnoreCase("Payment Monitoring") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Payment Monitoring Menu ......");

                        /*String vBNK_PaymentMonitoringMenu=Constants.BankingOR.getProperty("BNK_PaymentMonitoringMenu");
                        String vBNK_PaymentMonitoringMenuLoader=Constants.BankingOR.getProperty("BNK_PaymentMonitoringMenuLoader");
                        Assert.assertEquals("PASS", Constants.key.waitForElementNotVisible(vBNK_PaymentMonitoringMenuLoader, 90));*/
            String vBNK_PaymentMonitoringMenu = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitoringMenu");
            String vBNK_PaymentMonitoringMenuLoader = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitoringMenuLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vBNK_PaymentMonitoringMenuLoader, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentMonitoringMenu, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_PaymentMonitoringMenu, ""));

        }
    }

    @And("^User Click on (Payment Entries|Duplicate Payment Queue|Payment Approval|Rejected Payment List|Property Log|Change Properties) SubMenu from (Payment Monitoring) for Payment TC$")
    public void
    userClickOnPaymentEntriesSubMenuFromPaymentMonitoringForPaymentTc(String MainMenu, String SubMenu) throws Exception {
        key.pause("6", "");
        if (MainMenu.equalsIgnoreCase("Payment Entries") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Payment Entries from Payment Monitoring Menu ......");
            key.pause("4", "");
            String vBNK_PaymentEntriesSubMenu = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntriesSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentEntriesSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_PaymentEntriesSubMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Duplicate Payment Queue") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Duplicate Payment Queue from Payment Monitoring Menu ......");

            String vBNK_duplicatePaymentQueueSubMenu = Constants.PaymentMonitoringOR.getProperty("BNK_duplicatePaymentQueueSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_duplicatePaymentQueueSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_duplicatePaymentQueueSubMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Payment Approval") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Payment Approval from Payment Monitoring Menu ......");

            String vBNK_PaymentApprovalSubMenu = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApprovalSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApprovalSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_PaymentApprovalSubMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Rejected Payment List") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Rejected Payment List from Payment Monitoring Menu ......");

            String vBNK_RejectedPaymentListSubMenu = Constants.PaymentMonitoringOR.getProperty("BNK_RejectedPaymentListSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_RejectedPaymentListSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_RejectedPaymentListSubMenu, ""));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        } else if (MainMenu.equalsIgnoreCase("Change Properties") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Change Properties from Payment Monitoring Menu ......");

            String vBanking_ChangeProperty = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ChangeProperty, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ChangeProperty, ""));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        } else if (MainMenu.equalsIgnoreCase("Property Log") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Property Log List from Payment Monitoring Menu ......");

            String vBNK_PropertiesLogSubMenu = Constants.PaymentMonitoringOR.getProperty("BNK_PropertiesLogSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PropertiesLogSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_PropertiesLogSubMenu, ""));
        }  /*else if (MainMenu.equalsIgnoreCase("Change Properties") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
                        LogCapture.info("User Click on Change Properties from Payment Monitoring Menu ......");

                        String vBNK_ChangePropertiesSubMenu=Constants.PaymentMonitoringOR.getProperty("BNK_ChangePropertiesSubMenu");
                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChangePropertiesSubMenu, ""));
                        Assert.assertEquals("PASS", Constants.key.click(vBNK_ChangePropertiesSubMenu, ""));
                }*/
    }

    @And("^User click on (ExportToExcel|PrintPdf|AuditTrail|Accept|Ok) and handle alerts from (Payment Entries|Duplicate Payment Queue|Potential Duplicate Queue|Spot Deal Booking)$")
    public void userClickOnExportToExcelAndHandleAlertsFromPaymentEntries(String Data, String Menu) throws Exception {
        if (Data.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on ExportToExcel from Payment Entries......");

            String vBNK_PaymentMonitor_ExportToExcel = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_ExportToExcel");
            String vBNK_PaymentEntriesSubMenu = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntriesSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentEntriesSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentMonitor_ExportToExcel, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_PaymentMonitor_ExportToExcel, ""));
        } else if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on PrintPdf from Payment Entries......");

            String vBNK_PaymentMonitor_Print = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_Print");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentMonitor_Print, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_PaymentMonitor_Print, ""));
        } else if (Data.equalsIgnoreCase("AuditTrail") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Click on AuditTrail from Payment Entries......");

            String vBNK_PaymentMonitor_Audit = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_Audit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentMonitor_Audit, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_PaymentMonitor_Audit, ""));
            String vBNK_PaymentMonitor_AuditPopup = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_AuditPopup");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentMonitor_AuditPopup, ""));
        } else if (Data.equalsIgnoreCase("AuditTrail") && Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User Click on AuditTrail from Duplicate Payment Queue......");

            String vBNK_DuplicatePaymentQueue_Audit = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_Audit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_Audit, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_DuplicatePaymentQueue_Audit, ""));
            String vBNK_PaymentMonitor_AuditPopup = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_AuditPopup");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentMonitor_AuditPopup, ""));
        } else if (Data.equalsIgnoreCase("Accept") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on Accept from Potential Duplicate Queue......");

            String vBNK_PotentialDuplicateQueue_Accept = Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue_Accept");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PotentialDuplicateQueue_Accept, ""));

            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_PotentialDuplicateQueue_Accept, ""));
        } else if (Data.equalsIgnoreCase("Ok") && Menu.equalsIgnoreCase("Spot Deal Booking")) {
            LogCapture.info("User Click on Ok ......");

            String vBNK_SpotDealBooking_BookDealButton = Constants.BankingOR.getProperty("SpotDealBooking_BookDealButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_SpotDealBooking_BookDealButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_SpotDealBooking_BookDealButton, ""));
        }
    }

    @And("^User should successfully see alert message \"([^\"]*)\" on (Payment Entries|Queries|Incoming Queries|Pending Authorise|Trading Dashboard) page$")
    public void userShouldSuccessfullySeeAlertMessageOnPaymentEntriesPage(String Value, String Menu) throws Throwable {
        key.pause("6", "");
        if (Menu.equalsIgnoreCase("Payment Entries") || Menu.equalsIgnoreCase("Queries") || Menu.equalsIgnoreCase("Incoming Queries") || Menu.equalsIgnoreCase("Pending Authorise") || Menu.equalsIgnoreCase("Trading Dashboard")) {
            LogCapture.info("User see alert message respective page......");

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + Value);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(Value));

        }
    }

    @Then("^User switch to (PrintPdf) window from (Payment Entries) page and verify title$")
    public void userSwitchToPrintPdfWindowFromPaymentEntriesPageAndVerifyTitle(String Data, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("Payment Entries pdf loading ......");

            Constants.key.switchToWindow("Payment Details");
        }
    }

    @And("^User Select (AnyRow|Multiple Row|First Row) from (Payment Entries|Duplicate Payment Queue|Potential Duplicate Queue|Account Balance|Payment Approval) Table$")
    public void userSelectAnyRowFromPaymentEntriesTable(String Data, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("AnyRow") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Selecting Row from Payment Entries Table......");

            String vBNK_PaymentEntries_TableRowOne = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_TableRowOne");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentEntries_TableRowOne, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_PaymentEntries_TableRowOne, ""));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

        } else if (Data.equalsIgnoreCase("AnyRow") && Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User Selecting Row from Duplicate Payment Queue Table......");

            String vBNK_DuplicatePaymentQueue_TableRowOne = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_TableRowOne");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_TableRowOne, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_DuplicatePaymentQueue_TableRowOne, ""));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

        } else if (Data.equalsIgnoreCase("Multiple Row") && Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User Selecting Multiple Row from Duplicate Payment Queue Table......");

            String vBNK_DuplicatePaymentQueue_PaymentID = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_PaymentID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_PaymentID, ""));
            PaymentID = Constants.key.getText(vBNK_DuplicatePaymentQueue_PaymentID, "");
            int MaxIndex = PaymentID.length() - 1;
            PaymentID = PaymentID.substring(0, MaxIndex);

        } else if (Data.equalsIgnoreCase("AnyRow") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Selecting Row from Potential Duplicate Queue Table......");

            String vBNK_PDQ_FirstRowInput = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_FirstRowInput, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_PDQ_FirstRowInput, ""));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
        } else if (Data.equalsIgnoreCase("AnyRow") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User Selecting Row from Account Balance Table......");

            String vBNK_AccountBalance_TableID = Constants.BankingOR.getProperty("BNK_AccountBalance_TableID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AccountBalance_TableID, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_AccountBalance_TableID, ""));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
        } else if (Data.equalsIgnoreCase("Multiple Row") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Selecting Multiple Row from Potential Duplicate Queue Table......");

            String vBNK_PDQ_FirstRowIDSearch = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowIDSearch");
            String vBNK_PDQ_FirstRowID = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_FirstRowID, ""));
            String TextToBeEnter = Constants.key.getText(vBNK_PDQ_FirstRowID, "");
            int MaxIndex = TextToBeEnter.length() - 1;
            TextToBeEnter = TextToBeEnter.substring(0, MaxIndex);
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_PDQ_FirstRowIDSearch, TextToBeEnter));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_PDQ_FirstRowIDSearch, "enter"));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        } else if (Data.equalsIgnoreCase("First Row") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User Selecting first Row from Payment Entries Table......");

            String vBNK_PaymentEntries_TableRowOne = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_TableRowOne");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentEntries_TableRowOne, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_PaymentEntries_TableRowOne, ""));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

        }

    }

    @Then("^User Verify (AuditTrail) All Available (Option)\"([^\"]*)\"$")
    public void userVerifyAuditTrailAllAvailableOption(String Menu, String Value, String AllOption) throws Throwable {
        if (Menu.equalsIgnoreCase("AuditTrail") && Value.equalsIgnoreCase("Option")) {
            LogCapture.info("User Verifying Table Header for AuditTrail......");

            String vBNK_AuditTrail_TableHeadRow = Constants.PaymentMonitoringOR.getProperty("BNK_AuditTrail_TableHeadRow");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AuditTrail_TableHeadRow, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_AuditTrail_TableHeadRow, AllOption));
        }
    }

    @Then("^User Verify (All|Made Changes) Option is Present in (Duplicate Payment Queue|Payment Approval|Property Log)$")
    public void userVerifyReleaseAllPaymentOptionIsPresentInDuplicatePaymentQueue(String Option, String Menu) throws Throwable {
        if (Option.equalsIgnoreCase("All") && Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User Verifying Release All Payment Option Present in Duplicate Payment Queue......");

            String vBNK_DPQ_page = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_page");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_page, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_DPQ_page, ""));
            LogCapture.info("User Verifying Release Payment Option Present in Duplicate Payment Queue......");
            String vBNK_DPQ_ReleasePayment = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_ReleasePayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_ReleasePayment, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_DPQ_ReleasePayment, ""));
            LogCapture.info("User Verifying Reject Payment Option Present in Duplicate Payment Queue......");

            String vBNK_DPQ_RejectPayment = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectPayment");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_DPQ_RejectPayment, ""));
            LogCapture.info("User Verifying Reject All Payment Option Present in Duplicate Payment Queue......");
            String vBNK_DPQ_RejectAllPayment = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectAllPayment");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_DPQ_RejectAllPayment, ""));
            LogCapture.info("User Verifying Print Option Present in Duplicate Payment Queue......");
            String vBNK_PaymentMonitor_Print = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_Print");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PaymentMonitor_Print, ""));
            LogCapture.info("User Verifying Export Option Present in Duplicate Payment Queue......");
            String vBNK_PaymentMonitor_ExportToExcel = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_ExportToExcel");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PaymentMonitor_ExportToExcel, ""));
            LogCapture.info("User Verifying Reset Filter Option Present in Duplicate Payment Queue......");
            String vBNK_BalanceException_ResetFilter = Constants.BankingOR.getProperty("BNK_BalanceException_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_BalanceException_ResetFilter, ""));
        } else if (Option.equalsIgnoreCase("All") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User Verifying Export Option Present in Payment Approval......");

            String vBNK_PaymentMonitor_ExportToExcel = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_ExportToExcel");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentMonitor_ExportToExcel, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PaymentMonitor_ExportToExcel, ""));
            LogCapture.info("User Verifying Print Option Present in Payment Approval......");
            String vBNK_PaymentMonitor_Print = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_Print");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentMonitor_Print, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PaymentMonitor_Print, ""));
            LogCapture.info("User Verifying Reset Filter Option Present in Payment Approval......");
            String vBNK_BalanceException_ResetFilter = Constants.BankingOR.getProperty("BNK_BalanceException_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_BalanceException_ResetFilter, ""));
            LogCapture.info("User Verifying Audit Trail Option Present in Payment Approval......");

            String vBNK_PaymentMonitor_Audit = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitor_Audit");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PaymentMonitor_Audit, ""));
            LogCapture.info("User Verifying Approve Payment Option Present in Payment Approval......");
            String vBNK_PAQ_ApprovePayment = Constants.PaymentMonitoringOR.getProperty("BNK_PAQ_ApprovePayment");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PAQ_ApprovePayment, ""));
            LogCapture.info("User Verifying Reject Payment Option Present in Payment Approval......");
            String vBNK_DPQ_RejectPayment = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectPayment");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_DPQ_RejectPayment, ""));
            LogCapture.info("User Verifying Reject All Payment Option Present in Payment Approval......");
            String vBNK_DPQ_RejectAllPayment = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectAllPayment");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_DPQ_RejectAllPayment, ""));
        } else if (Option.equalsIgnoreCase("Made Changes") && Menu.equalsIgnoreCase("Property Log")) {
            LogCapture.info("User Verifying Made Changes are Present in Property Log......");

            String vBNK_AutoAuthLimit_Verify = Constants.PaymentMonitoringOR.getProperty("BNK_AutoAuthLimit_Verify");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AutoAuthLimit_Verify, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_AutoAuthLimit_Verify, RandomNumber));

            String vBNK_CP_SafeMode_Verify = Constants.PaymentMonitoringOR.getProperty("BNK_CP_SafeMode_Verify");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_CP_SafeMode_Verify, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_CP_SafeMode_Verify, SafeModeValue));
        }
    }

    @And("^User Click on (Release Payment|Reject Payment|Release All Payment|Reject All Payment|Merge Record|Merge Accept|Approve Payment) for selected Payment ID from (Duplicate Payment Queue|Potential Duplicate Queue|Account Balance|Payment Approval) Page$")
    public void userClickOnReleasePaymentForSelectedPaymentIDFromDuplicatePaymentQueuePage(String Action, String Menu) throws Throwable {
        key.pause("2", "");
        if (Action.equalsIgnoreCase("Release Payment") && Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User is Releasing Payment for selected Payment ID......");

            String vBNK_DuplicatePaymentQueue_PaymentID = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_PaymentID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_PaymentID, ""));
            PaymentID = Constants.key.getText(vBNK_DuplicatePaymentQueue_PaymentID);

            String vBNK_DuplicatePaymentQueue_RowOneCDText = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_RowOneCDText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_RowOneCDText, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_DuplicatePaymentQueue_RowOneCDText, "RightClick"));

            String vBNK_DuplicatePaymentQueue_ReleasePayment = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_ReleasePayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_ReleasePayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DuplicatePaymentQueue_ReleasePayment, ""));

        } else if (Action.equalsIgnoreCase("Reject Payment") && Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User is Rejecting Payment for selected Payment ID......");

            String vBNK_DuplicatePaymentQueue_PaymentID = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_PaymentID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_PaymentID, ""));
            PaymentID = Constants.key.getText(vBNK_DuplicatePaymentQueue_PaymentID);

            String vBNK_DuplicatePaymentQueue_RowOneCDText = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_RowOneCDText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_RowOneCDText, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_DuplicatePaymentQueue_RowOneCDText, "RightClick"));

            String vBNK_DuplicatePaymentQueue_RejectPayment = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_RejectPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_RejectPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DuplicatePaymentQueue_RejectPayment, ""));
        } else if (Action.equalsIgnoreCase("Release All Payment") && Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User is Releasing All Payment for selected Payment ID......");

            String vBNK_DPQ_SearchID = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_DPQ_SearchID, PaymentID));
            LogCapture.info(PaymentID);
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_DPQ_SearchID, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_DPQ_TableRowCount = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_TableRowCount");
            String vBNK_DPQ_ReleaseAllPay = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_ReleaseAllPay");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_ReleaseAllPay, ""));
            List<WebElement> vTotalRows = driver.findElements(By.xpath(vBNK_DPQ_TableRowCount));
            int vTableCount = vTotalRows.size();
            if (vTableCount <= 10) {
                for (int i = 0; i < vTotalRows.size(); i++) {
                    String TableOfAllPaymentID = "//table[@id='duplicatePaymentEntriesDIV']//tbody//tr[" + (i + 1) + "]//td[2]";
                    String PaymentIDOFEachTable = Constants.key.getText(TableOfAllPaymentID);
                    MultiPaymentID = new ArrayList<>();
                    MultiPaymentID.add(PaymentIDOFEachTable);
                    LogCapture.info(PaymentIDOFEachTable);
                }
                Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DPQ_ReleaseAllPay, ""));

            }
        } else if (Action.equalsIgnoreCase("Reject All Payment") && Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User is Reject All Payment for selected Payment ID......");

            String vBNK_DPQ_SearchID = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_DPQ_SearchID, PaymentID));
            LogCapture.info(PaymentID);
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_DPQ_SearchID, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_DPQ_TableRowCount = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_TableRowCount");
            String vBNK_DPQ_RejectAllPay = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectAllPay");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectAllPay, ""));
            List<WebElement> vTotalRows = driver.findElements(By.xpath(vBNK_DPQ_TableRowCount));
            int vTableCount = vTotalRows.size();
            if (vTableCount <= 10) {
                for (int i = 0; i < vTotalRows.size(); i++) {
                    String TableOfAllPaymentID = "//table[@id='duplicatePaymentEntriesDIV']//tbody//tr[" + (i + 1) + "]//td[2]";
                    String PaymentIDOFEachTable = Constants.key.getText(TableOfAllPaymentID);
                    MultiPaymentID = new ArrayList<>();
                    MultiPaymentID.add(PaymentIDOFEachTable);
                    LogCapture.info(PaymentIDOFEachTable);
                }
                Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DPQ_RejectAllPay, ""));
            }
        } else if (Action.equalsIgnoreCase("Reject Payment") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User is Rejecting Payment for selected Payment ID......");

            String vBNK_PDQ_FirstRowID = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_FirstRowID, ""));
            PaymentID = Constants.key.getText(vBNK_PDQ_FirstRowID);

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_FirstRowID, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PDQ_FirstRowID, "RightClick"));
            String vBNK_PDQ_Reject = Constants.BankingOR.getProperty("BNK_PDQ_Reject");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_Reject, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_PDQ_Reject, ""));

        } else if (Action.equalsIgnoreCase("Merge Record") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User is Merge Record for selected record in Load Into Panel......");

            String vBNK_PDQ_FirstRowIDLoadPanel = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowIDLoadPanel");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_FirstRowIDLoadPanel, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PDQ_FirstRowIDLoadPanel, "RightClick"));

            String vBNK_PDQ_Merge = Constants.BankingOR.getProperty("BNK_PDQ_Merge");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_Merge, ""));

            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_PDQ_Merge, ""));
        } else if (Action.equalsIgnoreCase("Merge Record") && Menu.equalsIgnoreCase("Account Balance")) {
            LogCapture.info("User is Merge Record for selected record in Load Into Panel......");

            String vBNK_AccountBalance_IntradayText = Constants.BankingOR.getProperty("BNK_AccountBalance_IntradayText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AccountBalance_IntradayText, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_AccountBalance_IntradayText, ""));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            //Removed Previous List Code Updated with this new one
            String vBNK_AccountBalance_CheckBox1 = Constants.BankingOR.getProperty("BNK_AccountBalance_CheckBox1");
            String vBNK_AccountBalance_CheckBoxLast = Constants.BankingOR.getProperty("BNK_AccountBalance_CheckBoxLast");
            Assert.assertEquals("PASS", Constants.key.click(vBNK_AccountBalance_CheckBox1, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_AccountBalance_CheckBoxLast, ""));
            String vBNK_AccountBalance_MergeRecord = Constants.BankingOR.getProperty("BNK_AccountBalance_MergeRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AccountBalance_MergeRecord, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_AccountBalance_MergeRecord, ""));
        } else if (Action.equalsIgnoreCase("Merge Accept") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User is Merge Accepting the selected record in Potential Duplicate Queue......");

            String vBNK_PDQ_FirstRowID = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_FirstRowID, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PDQ_FirstRowID, "RightClick"));
        } else if (Action.equalsIgnoreCase("Approve Payment") && Menu.equalsIgnoreCase("Payment Approval")) {
//            LogCapture.info("User is Approve Payment for selected Payment ID......");
//
//            String vBNK_PaymentApprovalQueue_PaymentID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApprovalQueue_PaymentID");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApprovalQueue_PaymentID, ""));
//            PaymentID = Constants.key.getText(vBNK_PaymentApprovalQueue_PaymentID);
//
//
//
//            String vBNK_PaymentApprovalQueue_RowOneCDText = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApprovalQueue_RowOneCDText");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApprovalQueue_RowOneCDText, ""));
//            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PaymentApprovalQueue_RowOneCDText, "RightClick"));
//
//
//
//            String vBNK_PaymentApproveQueue_ApprovePayment = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproveQueue_ApprovePayment");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproveQueue_ApprovePayment, ""));
//            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_PaymentApproveQueue_ApprovePayment, ""));


            LogCapture.info("User is Approve Payment for selected Payment ID......");

            String vBNK_PaymentApprovalQueue_PaymentID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApprovalQueue_PaymentID");
            LogCapture.info("check vBNK_PaymentApprovalQueue_PaymentID is visible");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApprovalQueue_PaymentID, ""));
            LogCapture.info("vBNK_PaymentApprovalQueue_PaymentID is visible");
            PaymentID = Constants.key.getText(vBNK_PaymentApprovalQueue_PaymentID);
            LogCapture.info("PaymentID --> " + PaymentID);
            String vBNK_PaymentApprovalQueue_RowOneCDText = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApprovalQueue_RowOneCDText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApprovalQueue_RowOneCDText, ""));
            LogCapture.info("vBNK_PaymentApprovalQueue_RowOneCDText is visible and right click it");
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PaymentApprovalQueue_RowOneCDText, "RightClick"));
            LogCapture.info("vBNK_PaymentApprovalQueue_RowOneCDText is right clicked");
            String vBNK_PaymentApproveQueue_ApprovePayment = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproveQueue_ApprovePayment");
            while (!Constants.key.verifyElementProperties(vBNK_PaymentApproveQueue_ApprovePayment, "visible").equalsIgnoreCase("PASS")) {
                LogCapture.info("while loop...");
                Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PaymentApprovalQueue_RowOneCDText, "RightClick"));
                Assert.assertEquals("PASS", Constants.key.pause("1", "RightClick"));
                LogCapture.info("while loop last...");
            }
            LogCapture.info("while loop exit...");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproveQueue_ApprovePayment, ""));
            LogCapture.info("vBNK_PaymentApproveQueue_ApprovePayment click and handle alert");
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_PaymentApproveQueue_ApprovePayment, ""));

        }


    }


    @Then("^User should successfully see alert messages \"([^\"]*)\" on (Duplicate Payment Queue|Change Properties|Potential Duplicate Queue|Account Balance|Failed Payment Out|Payment Approval|Repush Entry|AIP confirmation upload) Page$")
    public void userShouldSuccessfullySeeAlertMessagesOnDuplicatePaymentQueuePage(String Alert, String Menu) throws Throwable {
        key.pause("6", "");
        if (Menu.equalsIgnoreCase("Duplicate Payment Queue") || Menu.equalsIgnoreCase("Change Properties") || Menu.equalsIgnoreCase("Potential Duplicate Queue") || Menu.equalsIgnoreCase("Account Balance") || Menu.equalsIgnoreCase("Failed Payment Out") || Menu.equalsIgnoreCase("Payment Approval") || Menu.equalsIgnoreCase("Repush Entry") || Menu.equalsIgnoreCase("AIP confirmation upload")) {
            LogCapture.info("User see alert message respective page......");

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + Alert);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(Alert));

        }
    }

    @Then("^User Verify (Released Payment|Rejected Payment|Release All Payment|Rejected All Payment|Approved Payment) is Displayed In (Payment Approval|Rejected Payment List|Payment Entries) Page$")
    public void userVerifyReleasedPaymentIsDisplayedInPaymentApprovalPage(String Action, String Menu) throws Throwable {
        if (Action.equalsIgnoreCase("Released Payment") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User is Verifying Released Payment in Payment Approval Page is Displayed");

            String vBNK_PaymentApproval_SearchID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_PaymentApproval_SearchID, PaymentID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_PaymentApproval_SearchID, "enter"));

            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

            String vBNK_PaymentApproval_SearchResultID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchResultID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SearchResultID, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PaymentApproval_SearchResultID, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_PaymentApproval_SearchResultID, PaymentID));

        } else if (Action.equalsIgnoreCase("Rejected Payment") && Menu.equalsIgnoreCase("Rejected Payment List")) {
            LogCapture.info("User is Verifying Rejected Payment in Rejected Payment List is Displayed");

            String vBNK_PaymentApproval_SearchID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_PaymentApproval_SearchID, PaymentID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_PaymentApproval_SearchID, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_PaymentApproval_SearchResultID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchResultID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SearchResultID, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PaymentApproval_SearchResultID, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_PaymentApproval_SearchResultID, PaymentID));
        } else if (Action.equalsIgnoreCase("Release All Payment") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User is Verifying Release All Payment in Payment Approval Page is Displayed");

            String vBNK_PaymentApproval_SearchID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_PaymentApproval_SearchID, PaymentID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_PaymentApproval_SearchID, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_PaymentApproval_SearchResultID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchResultID");

            List<WebElement> vTotalRows = driver.findElements(By.xpath(vBNK_PaymentApproval_SearchResultID));
            List<String> MultiPaymentIDVerify = new ArrayList<>();
            for (int i = 0; i < vTotalRows.size(); i++) {
                String TableOfAllPaymentID = "//table[@id='paymentEntriesDIV']//tbody//tr[" + (i + 1) + "]//td[2]";
                Assert.assertEquals("PASS", Constants.key.exist(TableOfAllPaymentID, ""));
                String PaymentIDOFEachTable = Constants.key.getText(TableOfAllPaymentID);
                MultiPaymentIDVerify.add(PaymentIDOFEachTable);
                LogCapture.info(PaymentIDOFEachTable);
            }
            MultiPaymentIDVerify.retainAll(MultiPaymentID);
            Assert.assertEquals(MultiPaymentID, MultiPaymentIDVerify);

        } else if (Action.equalsIgnoreCase("Rejected All Payment") && Menu.equalsIgnoreCase("Rejected Payment List")) {
            LogCapture.info("User is Verifying Rejected All Payment in Rejected Payment List Page is Displayed");

            String vBNK_PaymentApproval_SearchID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_PaymentApproval_SearchID, PaymentID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_PaymentApproval_SearchID, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_PaymentApproval_SearchResultID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchResultID");
            List<WebElement> vTotalRows = driver.findElements(By.xpath(vBNK_PaymentApproval_SearchResultID));
            List<String> MultiPaymentIDVerify = new ArrayList<>();
            for (int i = 0; i < vTotalRows.size(); i++) {
                String TableOfAllPaymentID = "//table[@id='paymentEntriesDIV']//tbody//tr[" + (i + 1) + "]//td[2]";
                Assert.assertEquals("PASS", Constants.key.exist(TableOfAllPaymentID, ""));
                String PaymentIDOFEachTable = Constants.key.getText(TableOfAllPaymentID);
                MultiPaymentIDVerify.add(PaymentIDOFEachTable);
                LogCapture.info(PaymentIDOFEachTable);
            }
            MultiPaymentIDVerify.retainAll(MultiPaymentID);
            Assert.assertEquals(MultiPaymentID, MultiPaymentIDVerify);
        } else if (Action.equalsIgnoreCase("Approved Payment") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User is Verifying Approved Payment in Payment Entries Page is Displayed");

            String vBNK_PaymentApproval_SearchID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_PaymentApproval_SearchID, PaymentID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_PaymentApproval_SearchID, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_PaymentApproval_SearchResultID = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SearchResultID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SearchResultID, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PaymentApproval_SearchResultID, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_PaymentApproval_SearchResultID, PaymentID));

        }
    }

    @And("^User Select Reject \"([^\"]*)\" and enter Reason \"([^\"]*)\" for Rejection on (Duplicate Payment Queue|Message Failed Out|Failed Payment Out) Page$")
    public void userSelectRejectAndEnterReasonForRejectionOnDuplicatePaymentQueuePage(String Option, String Reason, String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User Selecting Reject option and Reason for Rejection on Duplicate Payment Queue");

            String vBNK_DPQ_RejectPopup = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectPopup");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectPopup, ""));
            String vBNK_DPQ_RejectDropDown = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectDropDown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectDropDown, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_DPQ_RejectDropDown, Option));
            //Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_DPQ_RejectDropDown,Option));
            String vBNK_DPQ_RejectReason = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectReason");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectReason, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_DPQ_RejectReason, Reason));
            String vBNK_DPQ_RejectSubmit = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectSubmit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectSubmit, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DPQ_RejectSubmit, ""));
        } else if (Menu.equalsIgnoreCase("Message Failed Out")) {
            LogCapture.info("User Selecting Reject option and Reason for Rejection on Message Failed Out");

            String vBNK_DPQ_RejectPopup = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectPopup");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectPopup, ""));
            String vBNK_DPQ_RejectDropDown = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectDropDown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectDropDown, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_DPQ_RejectDropDown, Option));
            String vBNK_DPQ_RejectReason = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectReason");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectReason, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_DPQ_RejectReason, Reason));
            String vBNK_DPQ_RejectSubmit = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectSubmit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectSubmit, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DPQ_RejectSubmit, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DPQ_RejectSubmit, ""));
        } else if (Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Selecting Reject option and Reason for Rejection on Failed Payment Out");

            //String vBNK_DPQ_RejectPopup = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectPopup");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectPopup, ""));
            String vBNK_FPO_RejectDropDown = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_RejectReason");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_FPO_RejectDropDown, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_FPO_RejectDropDown, Option));
            String vBNK_FPO_RejectReason = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_RejectReasonText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_FPO_RejectReason, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_FPO_RejectReason, Reason));

            String vBNK_DPQ_RejectSubmit = Constants.PaymentMonitoringOR.getProperty("BNK_DPQ_RejectSubmit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DPQ_RejectSubmit, ""));

            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DPQ_RejectSubmit, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DPQ_RejectSubmit, ""));


            // String vObjBNK_MessageOut_RejectReason = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_RejectReason");
            // String vObjBNK_MessageOut_RejectReasonText = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_RejectReasonText");
            //String vObjBNK_MessageOut_RejectButton = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_RejectButton");
        }
    }

    @And("^User (Make Changes|Make SafeModeON|Make SafeModeOFF) in (Change Properties) Page$")
    public void userMakeChangesInChangePropertiesPage(String changes, String Menu) throws Throwable {
        if (changes.equalsIgnoreCase("Make Changes") && Menu.equalsIgnoreCase("Change Properties")) {
            LogCapture.info("User is Making Changes in Change Properties");

            String vBNK_AutoAuthLimit = Constants.PaymentMonitoringOR.getProperty("BNK_AutoAuthLimit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AutoAuthLimit, ""));
            RandomNumber = RandomStringUtils.randomNumeric(3);
            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_AutoAuthLimit));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_AutoAuthLimit, RandomNumber));
            String vBNK_CP_SafeOn = Constants.PaymentMonitoringOR.getProperty("BNK_CP_SafeOn");
            String vBNK_CP_SafeOff = Constants.PaymentMonitoringOR.getProperty("BNK_CP_SafeOff");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_CP_SafeOn, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_CP_SafeOff, ""));
            if (Constants.key.verifyElementProperties(vBNK_CP_SafeOn, "unselected").equalsIgnoreCase("PASS")) {
                Constants.key.click(vBNK_CP_SafeOn, "");
                SafeModeValue = "true";
            } else {
                Constants.key.click(vBNK_CP_SafeOff, "");
                SafeModeValue = "false";
            }
            String vBNK_ChangeProperties_SaveButton = Constants.PaymentMonitoringOR.getProperty("BNK_ChangeProperties_SaveButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChangeProperties_SaveButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_ChangeProperties_SaveButton, ""));

            //Assert.assertEquals("PASS", Constants.key.waitForAlert(120));
        } else if (changes.equalsIgnoreCase("Make SafeModeON") && Menu.equalsIgnoreCase("Change Properties")) {
            LogCapture.info("User is Making SafeModeON in Change Properties");

            String vBNK_CP_SafeOn = Constants.PaymentMonitoringOR.getProperty("BNK_CP_SafeOn");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_CP_SafeOn, ""));
            if (Constants.key.verifyElementProperties(vBNK_CP_SafeOn, "unselected").equalsIgnoreCase("PASS")) {
                Constants.key.click(vBNK_CP_SafeOn, "");
            }
            String vBNK_ChangeProperties_SaveButton = Constants.PaymentMonitoringOR.getProperty("BNK_ChangeProperties_SaveButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChangeProperties_SaveButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_ChangeProperties_SaveButton, ""));

            //Assert.assertEquals("PASS", Constants.key.waitForAlert(120));
        } else if (changes.equalsIgnoreCase("Make SafeModeOFF") && Menu.equalsIgnoreCase("Change Properties")) {
            LogCapture.info("User is Making SafeModeOFF in Change Properties");

            String vBNK_CP_SafeOff = Constants.PaymentMonitoringOR.getProperty("BNK_CP_SafeOff");
            String vBNK_ChangePropertyBARCMTOff = Constants.QueryManagementOR.getProperty("BNK_ChangePropertyBARCMTOff");
            String vBNK_ChangePropertyRBSMTOff = Constants.QueryManagementOR.getProperty("BNK_ChangePropertyRBSMTOff");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_CP_SafeOff, ""));
            String[] ObjOnOff = {vBNK_CP_SafeOff, vBNK_ChangePropertyBARCMTOff, vBNK_ChangePropertyRBSMTOff};
            for (int i = 0; i <= ObjOnOff.length - 1; i++) {
                String OnOffObj = ObjOnOff[i];
                if (Constants.key.verifyElementProperties(OnOffObj, "unselected").equalsIgnoreCase("PASS")) {
                    Constants.key.click(OnOffObj, "");
                }
            }
            String vBNK_ChangeProperties_SaveButton = Constants.PaymentMonitoringOR.getProperty("BNK_ChangeProperties_SaveButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChangeProperties_SaveButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_ChangeProperties_SaveButton, ""));

            Assert.assertEquals("PASS", Constants.key.waitForAlert(120));
        }

    }

    @And("^User select (Reject Payment) \"([^\"]*)\" from Payment Approval page$")
    public void userSelectRejectFromPaymentApprovalPage(String Data, String Opt) throws Throwable {
        if (Data.equalsIgnoreCase("Reject Payment")) {
            LogCapture.info("User select Reject payment ......");

            String vBanking_PaymentMonitoring_SelectRejectPayment = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_SelectRejectPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_SelectRejectPayment, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBanking_PaymentMonitoring_SelectRejectPayment, Opt));
        }

    }

    @And("^User enter (RejectReason|RecordID|Auto Authorization Limit|Reason) \"([^\"]*)\" on (Payment Approval|Change Properties|Spot deal booking) page$")
    public void userEnterRejectReasonOnPaymentApprovalPage(String Data, String Value, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("RejectReason") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User enter Reject reason on payment approval page......");
            String vBanking_PaymentMonitoring_RejectReason = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_RejectReason");
            Assert.assertEquals("PASS", Constants.key.clearText(vBanking_PaymentMonitoring_RejectReason));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBanking_PaymentMonitoring_RejectReason, Value));
        } else if (Data.equalsIgnoreCase("RecordID") && Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User enter RecordID on payment approval page......");

            String vBanking_RejectedPayment_SearchID = Constants.PaymentMonitoringOR.getProperty("Banking_RejectedPayment_SearchID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_RejectedPayment_SearchID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vBanking_RejectedPayment_SearchID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBanking_RejectedPayment_SearchID, PaymentApprovalRecordID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBanking_RejectedPayment_SearchID, "enter"));

        } else if (Data.equalsIgnoreCase("Auto Authorization Limit") && Menu.equalsIgnoreCase("Change Properties")) {
            LogCapture.info("User enter RecordID on payment approval page......");
            String vBanking_ChangeProperty_AutoAuthorization = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_AutoAuthorization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ChangeProperty_AutoAuthorization, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vBanking_ChangeProperty_AutoAuthorization));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBanking_ChangeProperty_AutoAuthorization, Value));
        } else if (Data.equalsIgnoreCase("Reason") && Menu.equalsIgnoreCase("Spot deal booking")) {
            LogCapture.info("User enter Reason......");
            String vSpotdealbooking_Reason = Constants.PaymentMonitoringOR.getProperty("SpotDealBooking_Reason");
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSpotdealbooking_Reason, ""));
            //Assert.assertEquals("PASS", Constants.key.clearText(vSpotdealbooking_Reason));
            Assert.assertEquals("PASS", Constants.key.click(vSpotdealbooking_Reason, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vSpotdealbooking_Reason, Value));
        }
    }

    @Then("^User should successfully see (Options|Records) on Reject Payment List page$")
    public void userShouldSuccessfullySeeRejectPaymentOptionsOnRejectPaymentListPage(String data) throws Throwable {
        if (data.equalsIgnoreCase("Options")) {
            LogCapture.info("Reject Payment loading ......");

            String vBanking_RejectPayment_Reset = Constants.PaymentMonitoringOR.getProperty("Banking_RejectPayment_Reset");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_RejectPayment_Reset, ""));
            String vBanking_RejectPayment_Export = Constants.PaymentMonitoringOR.getProperty("Banking_RejectPayment_Export");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_RejectPayment_Export, ""));
            String vBanking_RejectPayment_Print = Constants.PaymentMonitoringOR.getProperty("Banking_RejectPayment_Print");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_RejectPayment_Print, ""));

        } else if (data.equalsIgnoreCase("Records")) {
            LogCapture.info("Reject Payment Records loading ......");

            String vBanking_RejectPayment_Records = Constants.PaymentMonitoringOR.getProperty("Banking_RejectPayment_Records");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_RejectPayment_Records, ""));
        }
    }

    @Then("^User should successfully see (Change Property Options|Safe Mode ON|Safe Mode OFF) on Change Properties page$")
    public void userShouldSuccessfullySeeChangePropertyOptionsOnChangePropertiesPage(String data) throws Throwable {
        if (data.equalsIgnoreCase("Change Property Options")) {
            LogCapture.info("Change Properties loading......");

            String vBanking_ChangeProperty_AutoAuthorizationText = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_AutoAuthorizationText");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_ChangeProperty_AutoAuthorizationText, ""));
            String vBanking_ChangeProperty_SafeModeText = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_SafeModeText");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_ChangeProperty_SafeModeText, ""));
            String vBanking_ChangeProperty_Save = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_Save");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_ChangeProperty_Save, ""));
        } else if (data.equalsIgnoreCase("Safe Mode ON")) {
            LogCapture.info("Change Properties loading ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBanking_ChangeProperty_SafeModeOnChecked = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_SafeModeOnChecked");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_ChangeProperty_SafeModeOnChecked, ""));
        } else if (data.equalsIgnoreCase("Safe Mode OFF")) {
            LogCapture.info("Change Properties loading......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBanking_ChangeProperty_SafeModeOffChecked = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_SafeModeOffChecked");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_ChangeProperty_SafeModeOffChecked, ""));
        }
    }

    @And("^User click on (Safe Mode ON|Safe Mode OFF) from Change Properties page$")
    public void userClickOnSafeModeONFromChangePropertiesPage(String value) throws Throwable {
        if (value.equalsIgnoreCase("Safe Mode ON")) {

            String vBanking_ChangeProperty_SafeModeOn = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_SafeModeOn");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ChangeProperty_SafeModeOn, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ChangeProperty_SafeModeOn, ""));
        } else if (value.equalsIgnoreCase("Safe Mode OFF")) {

            String vBanking_ChangeProperty_SafeModeOff = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_SafeModeOff");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ChangeProperty_SafeModeOff, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ChangeProperty_SafeModeOff, ""));
        }
    }

    @And("^User click on (Save Properties) and handle alert on Change Properties page$")
    public void userClickOnSavePropertyAndHandleAlertOnChangePropertiesPage(String Data) throws Throwable {
        if (Data.equalsIgnoreCase("Save Properties")) {
            LogCapture.info("User click on Save Properties and see alert message on Payment Approval page......");

            String vBanking_ChangeProperty_Save = Constants.PaymentMonitoringOR.getProperty("Banking_ChangeProperty_Save");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ChangeProperty_Save, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBanking_ChangeProperty_Save, ""));
                       /* String vPageLoader=Constants.BankingOR.getProperty("Banking_PageLoader");
                        Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));*/

        }
    }

    @And("^User should successfully see (UI Parameters|Payment Details) on (Message Out|Failed Payment Out|Manual Payment Upload|Manual PSR Upload|Manual PSR Upload CDSA) page$")
    public void userShouldSuccessfullySeeUIParametersOnMessageOutPage(String Data, String Menu) throws Throwable {
        key.pause("6", "");
        if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Message Out")) {
            LogCapture.info("User verify data on Message Out page....");

            String vBanking_MessageOut_ID = Constants.MessageOR.getProperty("Banking_MessageOut_ID");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_ID, ""));
            String vBanking_MessageOut_Institution = Constants.MessageOR.getProperty("Banking_MessageOut_Institution");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_Institution, ""));
            String vBanking_MessageOut_QueryName = Constants.MessageOR.getProperty("Banking_MessageOut_QueryName");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_QueryName, ""));
            String vBanking_MessageOut_MessageType = Constants.MessageOR.getProperty("Banking_MessageOut_MessageType");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_MessageType, ""));
            String vBanking_MessageOut_MessageNo = Constants.MessageOR.getProperty("Banking_MessageOut_MessageNo");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_MessageNo, ""));
        } else if (Data.equalsIgnoreCase("Payment Details") && Menu.equalsIgnoreCase("Message Out")) {
            LogCapture.info("User verify Payment Details on Message Out page....");

            String vBanking_MessageOut_DetailsofEntry = Constants.MessageOR.getProperty("Banking_MessageOut_DetailsofEntry");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_DetailsofEntry, ""));
            String vBanking_MessageOut_MessageDescription = Constants.MessageOR.getProperty("Banking_MessageOut_MessageDescription");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_MessageDescription, ""));
        } else if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User verify Payment Details on Failed Payment Out page....");

            String vBanking_FailedPaymentOut_StatusData = Constants.MessageOR.getProperty("Banking_FailedPaymentOut_StatusData");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_FailedPaymentOut_StatusData, "Rejected"));
            String vBanking_FailedPaymentOut_SourceData = Constants.MessageOR.getProperty("Banking_FailedPaymentOut_SourceData");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_FailedPaymentOut_SourceData, "Titan"));
        } else if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User verify Payment Details on Manual Payment Upload page....");

            String vBanking_ManualPaymentUploadText = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadText");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ManualPaymentUploadText, "Manual Payment Upload"));
            String vBanking_ProcessedManualPaymentText = Constants.MessageOR.getProperty("Banking_ProcessedManualPaymentText");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ProcessedManualPaymentText, "Processed Manual Payments"));
        } else if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Manual PSR Upload")) {
            LogCapture.info("User verify Payment Details on Manual PSR Upload page....");

            String vBanking_ManualPSRUploadText = Constants.MessageOR.getProperty("Banking_ManualPSRUploadText");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_ManualPSRUploadText, ""));
        } else if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Manual PSR Upload CDSA")) {
            LogCapture.info("User verify Payment Details on Manual PSR Upload page....");

            String vBanking_ManualPSRUploadText = Constants.MessageOR.getProperty("Banking_ManualPSRUploadTextCDSA");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_ManualPSRUploadText, ""));
        }
    }

    @And("^User click on (MessageOutRecord|PrintPdf Icon) from Message Out page$")
    public void userClickOnMessageOutRecordFromMessageOutPage(String Value) throws Throwable {
        if (Value.equalsIgnoreCase("MessageOutRecord")) {
            LogCapture.info("User Click on MessageOutRecord ......");

            String vBanking_MessageOut_MessageClick = Constants.MessageOR.getProperty("Banking_MessageOut_MessageClick");
            WebElement ele = Constants.driver.findElement(By.xpath(vBanking_MessageOut_MessageClick));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        } else if (Value.equalsIgnoreCase("PrintPdf Icon")) {
            LogCapture.info("User Click on PrintPdf icon ......");

            String vBanking_MessageOut_PrintPdf = Constants.MessageOR.getProperty("Banking_MessageOut_PrintPdf");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_MessageOut_PrintPdf, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_MessageOut_PrintPdf, ""));
        }

    }

        /* Causing Duplication in feature file hence commented - (Cross check no file was Affected)
        @And("^User select (Source) \"([^\"]*)\" from Failed Payment Out page$")
        public void userSelectSourceFromFailedPaymentOutPage(String Data,String Opt) throws Throwable {
                if (Data.equalsIgnoreCase("Source")) {
                        LogCapture.info("User select Source from failed payment out page ......");

                        String vBanking_FailedPaymentOut_SourceFilter = Constants.MessageOR.getProperty("Banking_FailedPaymentOut_SourceFilter");
                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_FailedPaymentOut_SourceFilter, ""));
                        Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBanking_FailedPaymentOut_SourceFilter, Opt));
                }
        }*/

    @And("^User enter (PaymentStatus) \"([^\"]*)\" on (Failed Payment Out) page$")
    public void userEnterPaymentStatusOnFailedPaymentOutPage(String Data, String Opt, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("PaymentStatus") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User enter PaymentStatus on Failed Payment Out page......");
            String vBanking_FailedPaymentOut_Status = Constants.MessageOR.getProperty("Banking_FailedPaymentOut_Status");
            Assert.assertEquals("PASS", Constants.key.clearText(vBanking_FailedPaymentOut_Status));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBanking_FailedPaymentOut_Status, Opt));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBanking_FailedPaymentOut_Status, "enter"));
        }


    }

    @Then("^verify the data is filtered successfully on (Source|Status)\"([^\"]*)\" on (Failed Payment Out) Page$")
    public void verifyTheDataIsFilteredSuccessfullyForSourceOnFailedPaymentOutPage(String Data, String Value, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("Source") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User select source  ......");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

            String vBanking_FailedPaymentOut_SourceData = Constants.MessageOR.getProperty("Banking_FailedPaymentOut_SourceData");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_FailedPaymentOut_SourceData, "Titan"));
        } else if (Data.equalsIgnoreCase("Status") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User select source  ......");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

            String vBanking_FailedPaymentOut_StatusData = Constants.MessageOR.getProperty("Banking_FailedPaymentOut_StatusData");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_FailedPaymentOut_StatusData, "Rejected"));
        }

    }

    @And("^User click on (ExportToExcel) and handle alert from Message Out page$")
    public void userClickOnSavePropertyAndHandleAlertOnMessageOut(String Data) throws Throwable {
        if (Data.equalsIgnoreCase("ExportToExcel")) {
            LogCapture.info("User click on ExportToExcel and see alert message on Message Out page......");

            String vBanking_MessageOut_ExcelExport = Constants.MessageOR.getProperty("Banking_MessageOut_ExcelExport");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_MessageOut_ExcelExport, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBanking_MessageOut_ExcelExport, ""));

        }
    }

    @Then("^User successfully landed on (Potential Duplicate Queue) page in Banking PDQ$")
    public void userSuccessfullyLandedOnPotentialDuplicateQueuePageInBankingPDQ(String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Successfully Landed On Potential Duplicate Queue Page......");

            String vBNK_PDQ_TableID = Constants.BankingOR.getProperty("BNK_PDQ_TableID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_TableID, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PDQ_TableID, ""));
        }
    }

    @And("^User click on (PrintPdf|Export) option from (Potential Duplicate Queue|Failed Payment Out) page$")
    public void userClickOnPrintPdfOptionFromPotentialDuplicateQueuePage(String Action, String Menu) throws Throwable {
        if (Action.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Verifying Print PDF for Potential Duplicate Queue....");

            String vBNK_PDQ_PrintPdf = Constants.BankingOR.getProperty("BNK_PDQ_PrintPdf");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_PrintPdf, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_PDQ_PrintPdf, ""));
        } else if (Action.equalsIgnoreCase("Export") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Verifying Export Functionality for Potential Duplicate Queue....");

            String vBNK_PDQ_Export = Constants.BankingOR.getProperty("BNK_PDQ_Export");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_Export, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_PDQ_Export, ""));
        } else if (Action.equalsIgnoreCase("PrintPdf") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Verifying Print PDF for Failed Payment Out....");

            String vBNK_FailedPaymentOut_PrintPDF = Constants.MessageOR.getProperty("BNK_FailedPaymentOut_PrintPDF");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_FailedPaymentOut_PrintPDF, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_FailedPaymentOut_PrintPDF, ""));

        } else if (Action.equalsIgnoreCase("Export") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Verifying Export Functionality for Failed Payment Out....");

            String vBNK_FailedPaymentOut_Export = Constants.MessageOR.getProperty("BNK_FailedPaymentOut_Export");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_FailedPaymentOut_Export, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_FailedPaymentOut_Export, ""));
        }
    }

    @Then("^User Verify (Reject Payment|Merge Record) is Not Displayed In (Potential Duplicate Queue|Failed Message Out) Page$")
    public void userVerifyRejectPaymentIsNotDisplayedInDuplicatePaymentQueuePage(String Action, String Menu) throws Throwable {
        key.pause("2", "");
        if (Action.equalsIgnoreCase("Reject Payment") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Verifying Reject Payment is Not Displayed in Potential Duplicate Queue....");

            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_PDQ_FirstRowID = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_FirstRowID, ""));
            String CompareID = Constants.key.getText(vBNK_PDQ_FirstRowID);
            Assert.assertNotEquals(CompareID, PaymentID);
        } else if (Action.equalsIgnoreCase("Merge Record") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Verifying Merge Record is Displayed in Potential Duplicate Queue....");

            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
        } else if (Action.equalsIgnoreCase("Reject Payment") && Menu.equalsIgnoreCase("Failed Message Out")) {
            LogCapture.info("User Verifying Reject Payment is Not Displayed in Failed Message Out Table....");
            String vBNK_Msg_FailedPayment_TableID = Constants.MessageOR.getProperty("BNK_Msg_FailedPayment_TableID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_Msg_FailedPayment_TableID, ""));
            String RejectPaymentIDGet = Constants.key.getText(vBNK_Msg_FailedPayment_TableID);
            Assert.assertNotSame(PaymentID, RejectPaymentIDGet);
            takeSnapShot();
        }
    }

    @And("^User click on (Query Management|Message) Menu from Main (Dashboard) for QM TC$")
    public void userClickOnQueryManagementMenuFromMainDashboardForQMTC(String SubMenu, String MainMenu) throws Throwable {
        key.pause("7", "");
        if (SubMenu.equalsIgnoreCase("Query Management") && MainMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Query Management Menu from Dashboard ......");
            String vBNK_QMMenu = Constants.QueryManagementOR.getProperty("BNK_QMMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QMMenu, ""));
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vBNK_QMMenu, ""));
            key.pause("6", "");
            Assert.assertEquals("PASS", Constants.key.click(vBNK_QMMenu, ""));

        } else if (SubMenu.equalsIgnoreCase("Message") && MainMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Message Menu from Dashboard ......");

            String vBNK_MessageMenu = Constants.QueryManagementOR.getProperty("BNK_MessageMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_MessageMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_MessageMenu, ""));
        }

    }

    @And("^User Click on (Incoming Queries|Queries|Pending Authorise|Message Out|Query Exception) SubMenu from (Query Management|Message) for QM TC$")
    public void userClickOnIncomingQueriesSubMenuFromQueryManagementForQMTC(String option, String MainMenu) throws Throwable {
        key.pause("2", "");
        if (option.equalsIgnoreCase("Incoming Queries") && MainMenu.equalsIgnoreCase("Query Management")) {
            LogCapture.info("User Click on Incoming Queries SubMenu from Query Management ......");

            String vBNK_QM_IncomingQueries = Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_IncomingQueries, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_QM_IncomingQueries, ""));

        } else if (option.equalsIgnoreCase("Queries") && MainMenu.equalsIgnoreCase("Query Management")) {
            LogCapture.info("User Click on Queries SubMenu from Query Management ......");

            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_QM_Queries = Constants.QueryManagementOR.getProperty("BNK_QM_Queries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_Queries, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_QM_Queries, ""));

        } else if (option.equalsIgnoreCase("Pending Authorise") && MainMenu.equalsIgnoreCase("Query Management")) {
            LogCapture.info("User Click on Pending Authorise SubMenu from Query Management ......");

            String vBNK_QM_PendingAuthorise = Constants.QueryManagementOR.getProperty("BNK_QM_PendingAuthorise");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_PendingAuthorise, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_QM_PendingAuthorise, ""));

        } else if (option.equalsIgnoreCase("Message Out") && MainMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Message Out SubMenu from Message......");

            String vBNK_MessageOutSubMenu = Constants.QueryManagementOR.getProperty("BNK_MessageOutSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_MessageOutSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_MessageOutSubMenu, ""));
        } else if (option.equalsIgnoreCase("Query Exception") && MainMenu.equalsIgnoreCase("Query Management")) {
            LogCapture.info("User Click on Query Exception SubMenu from Query Management......");

            String vBNK_Query_QueryExceptionSubMenu = Constants.QueryManagementOR.getProperty("BNK_Query_QueryExceptionSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_Query_QueryExceptionSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_Query_QueryExceptionSubMenu, ""));

        }
    }

    @And("^User Apply Filter On (Status|MessageNo) \"([^\"]*)\" and (State|IsAuthorise) \"([^\"]*)\" for (Incoming Queries|Pending Authorise)$")
    public void userApplyFilterOnStatusAndStateForIncomingQueries(String Status, String agr0, String State, String agr1, String SubMenu) throws Throwable {
        if (Status.equalsIgnoreCase("Status") && State.equalsIgnoreCase("State") && SubMenu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info(" Apply Filter On Status and State for Incoming Queries......");

            String vBNK_QM_IQStatus = Constants.QueryManagementOR.getProperty("BNK_QM_IQStatus");
            String vBNK_QM_IQState = Constants.QueryManagementOR.getProperty("BNK_QM_IQState");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_QM_IQStatus, agr0));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_QM_IQState, agr1));
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

        } else if (Status.equalsIgnoreCase("MessageNo") && State.equalsIgnoreCase("IsAuthorise") && SubMenu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User is Applying for Filter on Message No and & IsAuthorise from Pending Authorise.....");

            String vBNK_PendingAuthoriseMessageNo = Constants.QueryManagementOR.getProperty("BNK_PendingAuthoriseMessageNo");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PendingAuthoriseMessageNo, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_PendingAuthoriseMessageNo, agr0));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_IsAuthorize = Constants.QueryManagementOR.getProperty("BNK_IsAuthorize");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_IsAuthorize, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_IsAuthorize, agr1));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_IsAuthorize, "enter"));
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

        }
    }

    @And("^User Click on (Leave Query Open|Raise Query Option|Respond Query|Authorise Query|Import Query) for selected Query from (Incoming Queries|Queries|Pending Authorise|Query Exception) Page$")
    public void userClickOnLeaveQueryOpenForSelectedQueryFromIncomingQueriesPage(String Option, String SubMenu) throws Throwable {
        if (Option.equalsIgnoreCase("Leave Query Open") && SubMenu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User Select Leave Query Open from Incoming Queries......");

            String vBNK_QM_IQ_TableQueryID = Constants.QueryManagementOR.getProperty("BNK_QM_IQ_TableQueryID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_IQ_TableQueryID, ""));
            QueryID = Constants.key.getText(vBNK_QM_IQ_TableQueryID);
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_QM_IQ_TableQueryID, "RightClick"));
            String vBNK_QM_LeaveQueryOpen = Constants.QueryManagementOR.getProperty("BNK_QM_LeaveQueryOpen");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_LeaveQueryOpen, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_QM_LeaveQueryOpen, ""));

        } else if (Option.equalsIgnoreCase("Raise Query Option") && SubMenu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click On Raise Query Option from Queries SubMenu......");

            String vBNK_QM_RaiseQuery = Constants.QueryManagementOR.getProperty("BNK_QM_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_RaiseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_QM_RaiseQuery, ""));

        } else if (Option.equalsIgnoreCase("Respond Query") && SubMenu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User Click On Respond Query Option from Incoming Queries SubMenu......");

            String vBNK_QM_IQ_TableQueryID = Constants.QueryManagementOR.getProperty("BNK_QM_IQ_TableQueryID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_IQ_TableQueryID, ""));
            QueryID = Constants.key.getText(vBNK_QM_IQ_TableQueryID);
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_QM_IQ_TableQueryID, "RightClick"));
            String vBNK_IncomingQueryRespond = Constants.QueryManagementOR.getProperty("BNK_IncomingQueryRespond");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_IncomingQueryRespond, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_IncomingQueryRespond, ""));

        } else if (Option.equalsIgnoreCase("Authorise Query") && SubMenu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User Apply Filter and Click on Authorise Query from Pending Authorise SubMenu......");

            String vBNK_PendingAuthoriseRelatedReference = Constants.QueryManagementOR.getProperty("BNK_PendingAuthoriseRelatedReference");
            String vBNK_PendingAuthoriseTransactionReference = Constants.QueryManagementOR.getProperty("BNK_PendingAuthoriseTransactionReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PendingAuthoriseRelatedReference, ""));
            RelatedReference = Constants.key.getText(vBNK_PendingAuthoriseRelatedReference);
            TransactionReference = Constants.key.getText(vBNK_PendingAuthoriseTransactionReference);
            String vBNK_PendingAuthoriseTableID = Constants.QueryManagementOR.getProperty("BNK_PendingAuthoriseTableID");
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PendingAuthoriseTableID, "RightClick"));
            String vBNK_AuthoriseImage = Constants.QueryManagementOR.getProperty("BNK_AuthoriseImage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AuthoriseImage, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_AuthoriseImage, ""));
        } else if (Option.equalsIgnoreCase("Import Query") && SubMenu.equalsIgnoreCase("Query Exception")) {
            LogCapture.info("User Select First Row and Click on Import Query form Query Exception SubMenu......");

            String vBNK_QueryException_RowReferenceIDOne = Constants.QueryManagementOR.getProperty("BNK_QueryException_RowReferenceIDOne");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QueryException_RowReferenceIDOne, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_QueryException_RowReferenceIDOne, "RightClick"));
            String vBNK_QueryException_ImportQuery = Constants.QueryManagementOR.getProperty("BNK_QueryException_ImportQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QueryException_ImportQuery, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_QueryException_ImportQuery, ""));

        }
    }

    @Then("^User should successfully see alert messages \"([^\"]*)\" on (Incoming Queries|Queries|Query Exception)$")
    public void userShouldSuccessfullySeeAlertMessagesOnIncomingQueries(String Alert, String SubMenu) throws Throwable {
        if (SubMenu.equalsIgnoreCase("Incoming Queries") || SubMenu.equalsIgnoreCase("Queries") || SubMenu.equalsIgnoreCase("Query Exception")) {
            LogCapture.info("User see alert message respective page......");
            key.pause("7", "");
            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + Alert);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(Alert));

        }
    }

    @Then("^User Verify (Leave Query Open|Raise Query Option|Raise Query Form) is (Displayed) In (Queries Menu)$")
    public void userVerifyLeaveQueryOpenIsDisplayedInQueriesMenu(String Operation, String Visibility, String SubMenu) throws Throwable {
        if (Operation.equalsIgnoreCase("Leave Query Open") && Visibility.equalsIgnoreCase("Displayed") && SubMenu.equalsIgnoreCase("Queries Menu")) {
            LogCapture.info("User Verify Leave Query Open is Displayed in Queries SubMenu......");

            String vBNK_QM_QueriesTableID = Constants.QueryManagementOR.getProperty("BNK_QM_QueriesTableID");
            String vBNK_QM_QueriesTableIDInput = Constants.QueryManagementOR.getProperty("BNK_QM_QueriesTableIDInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_QueriesTableIDInput, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_QM_QueriesTableIDInput, QueryID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_QM_QueriesTableIDInput, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            Assert.assertEquals(QueryID, Constants.key.getText(vBNK_QM_QueriesTableID));

        } else if (Operation.equalsIgnoreCase("Raise Query Option") && Visibility.equalsIgnoreCase("Displayed") && SubMenu.equalsIgnoreCase("Queries Menu")) {
            LogCapture.info("User Verify Raise Query Option is Displayed in Queries SubMenu......");

            String vBNK_QM_RaiseQuery = Constants.QueryManagementOR.getProperty("BNK_QM_RaiseQuery");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_RaiseQuery, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_RaiseQuery, ""));

        } else if (Operation.equalsIgnoreCase("Raise Query Form") && Visibility.equalsIgnoreCase("Displayed") && SubMenu.equalsIgnoreCase("Queries Menu")) {
            LogCapture.info("User Verify Raise Query From is Displayed Properly in Queries SubMenu......");

            String vBNK_QM_RaiseQueryPopUp = Constants.QueryManagementOR.getProperty("BNK_QM_RaiseQueryPopUp");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_RaiseQueryPopUp, ""));
            String vBNK_RaiseQueryForm_QueryType = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_QueryType");
            String vBNK_RaiseQueryForm_Reference = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_Reference");
            String vBNK_RaiseQueryForm_GeneratedReference = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_GeneratedReference");
            String vBNK_RaiseQueryForm_Bank = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_Bank");
            String vBNK_RaiseQueryForm_senderBic = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_senderBic");
            String vBNK_RaiseQueryForm_narration = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_narration");
            String gettingText = Constants.key.ValueOfIndexAt(vBNK_RaiseQueryForm_QueryType, "1");
            Assert.assertTrue(gettingText.contains("Miscellaneous"));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_RaiseQueryForm_Reference, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_RaiseQueryForm_GeneratedReference, ""));
            String gettingTextBank = Constants.key.ValueOfIndexAt(vBNK_RaiseQueryForm_Bank, "1");
            Assert.assertTrue(gettingTextBank.contains("Barclays"));
            String gettingTextBank2 = Constants.key.ValueOfIndexAt(vBNK_RaiseQueryForm_Bank, "2");
            Assert.assertTrue(gettingTextBank2.contains("Royal Bank Of Scotland"));
            String gettingTextBIC = Constants.key.ValueOfIndexAt(vBNK_RaiseQueryForm_senderBic, "1");
            Assert.assertTrue(gettingTextBIC.contains("CDPNGB20AXXX"));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_RaiseQueryForm_narration, ""));
        }
    }

    @And("^User Check for (All Error) Pop-Up on (Raise Query|Import Query) for (Queries|Query Exception) Page$")
    public void userCheckForAllErrorPopUpOnRaiseQueryForQueriesPage(String Validation, String Feature, String SubMenu) throws Throwable {
        if (Validation.equalsIgnoreCase("All Error") && Feature.equalsIgnoreCase("Raise Query") && SubMenu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Check for All Error popup On Raise Query for Queries......");

            String vBNK_QM_RaiseQueryPopUp = Constants.QueryManagementOR.getProperty("BNK_QM_RaiseQueryPopUp");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_RaiseQueryPopUp, ""));
            String vBNK_RaiseQueryForm_QueryType = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_QueryType");
            String vBNK_RaiseQueryForm_Reference = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_Reference");
            String vBNK_RaiseQueryForm_Bank = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_Bank");
            String vBNK_RaiseQueryForm_senderBic = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_senderBic");
            String vBNK_RaiseQueryForm_Save = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_Save");
            String ExpectedAlertQType = "PleaseselectQueryType";
            Assert.assertEquals("PASS", Constants.key.verifyAlertInLine(vBNK_RaiseQueryForm_Save, ExpectedAlertQType));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_RaiseQueryForm_QueryType, "Miscellaneous"));

            String ExpectedAlertReference = "Pleaseenterreferencebetween5and16characters.SpacesandSpecialcharactersarenotallowed.";
            Assert.assertEquals("PASS", Constants.key.verifyAlertInLine(vBNK_RaiseQueryForm_Save, ExpectedAlertReference));
            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_RaiseQueryForm_Reference));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_RaiseQueryForm_Reference, "TESTING"));
            String ExpectedAlertBank = "PleaseselectBank";
            Assert.assertEquals("PASS", Constants.key.verifyAlertInLine(vBNK_RaiseQueryForm_Save, ExpectedAlertBank));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_RaiseQueryForm_Bank, "Barclays"));
            String ExpectedAlertBIC = "PleaseselectSenderBic";
            Assert.assertEquals("PASS", Constants.key.verifyAlertInLine(vBNK_RaiseQueryForm_Save, ExpectedAlertBIC));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_RaiseQueryForm_senderBic, "CDPNGB20AXXX"));
            String ExpectedAlertNarration = "Pleasefillallthefield";
            Assert.assertEquals("PASS", Constants.key.verifyAlertInLine(vBNK_RaiseQueryForm_Save, ExpectedAlertNarration));
        } else if (Validation.equalsIgnoreCase("All Error") && Feature.equalsIgnoreCase("Import Query") && SubMenu.equalsIgnoreCase("Query Exception")) {
            LogCapture.info("User Check for All Error popup On Import Query form Query Exception......");

            String vBNK_PA_AuthorisePopUp = Constants.QueryManagementOR.getProperty("BNK_PA_AuthorisePopUp");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PA_AuthorisePopUp, ""));
            String vBNK_ImportQuery_Heading = Constants.QueryManagementOR.getProperty("BNK_ImportQuery_Heading");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_ImportQuery_Heading, "Leave Query"));
            String vBNK_ImportQueryForm_Type = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_Type");
            String vBNK_ImportQueryForm_TransactionType = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_TransactionType");
            String vBNK_ImportQueryForm_SubmitBtn = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_SubmitBtn");
            String ExpectedAlertType = "PleaseselectaType";
            Assert.assertEquals("PASS", Constants.key.verifyAlertInLine(vBNK_ImportQueryForm_SubmitBtn, ExpectedAlertType));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_ImportQueryForm_Type, "Amendment"));
            String ExpectedAlertTransactionType = "PleaseselectaTransactionType";
            Assert.assertEquals("PASS", Constants.key.verifyAlertInLine(vBNK_ImportQueryForm_SubmitBtn, ExpectedAlertTransactionType));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_ImportQueryForm_TransactionType, "Payment"));
            String ExpectedAlertReferenceID = "PleaseAddaReferenceID";
            Assert.assertEquals("PASS", Constants.key.verifyAlertInLine(vBNK_ImportQueryForm_SubmitBtn, ExpectedAlertReferenceID));
        }
    }

    @And("^User Select (Bank|Query Type|Authorise|Type|Transaction Type|Reference Id) as \"([^\"]*)\" Fill All Details and Procced On (Queries Page|Incoming Queries|Pending Authorise|Import Query)$")
    public void userSelectBankAsFillAllDetailsAndProccedOnQueriesPage(String Filed, String BankName, String SubMenu) throws Throwable {
        if (Filed.equalsIgnoreCase("Bank") && SubMenu.equalsIgnoreCase("Queries Page")) {
            LogCapture.info("User Fill All Details in Raiesed Query For......");

            String vBNK_QM_RaiseQueryPopUp = Constants.QueryManagementOR.getProperty("BNK_QM_RaiseQueryPopUp");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_RaiseQueryPopUp, ""));
            String vBNK_RaiseQueryForm_QueryType = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_QueryType");
            String vBNK_RaiseQueryForm_Reference = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_Reference");
            // Added by Omkar from here
            //String vBNK_RaiseQueryForm_GeneratedReference=Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_GeneratedReference");
            // Added by Omkar till here
            String vBNK_RaiseQueryForm_Bank = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_Bank");
            String vBNK_RaiseQueryForm_senderBic = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_senderBic");
            String vBNK_RaiseQueryForm_Save = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_Save");
            String vBNK_RaiseQueryForm_narration = Constants.QueryManagementOR.getProperty("BNK_RaiseQueryForm_narration");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_RaiseQueryForm_QueryType, "Miscellaneous"));

            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_RaiseQueryForm_Reference));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_RaiseQueryForm_Reference, "1542565232545625"));
            // Added by Omkar from here
//            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_RaiseQueryForm_GeneratedReference));
//            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_RaiseQueryForm_GeneratedReference, "2208010857554294"));
            // Added by Omkar till here
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_RaiseQueryForm_Bank, BankName));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_RaiseQueryForm_senderBic, "CDPNGB20AXXX"));
            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_RaiseQueryForm_narration));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_RaiseQueryForm_narration, "Testing Purpose"));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_RaiseQueryForm_Save, ""));
            Assert.assertEquals("PASS", Constants.key.waitForAlert(120));

        } else if (Filed.equalsIgnoreCase("Query Type") && SubMenu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("User Fill All Details in Raiesed Query For......");

            String vBNK_QM_ResponseQueryPopUp = Constants.QueryManagementOR.getProperty("BNK_QM_ResponseQueryPopUp");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_ResponseQueryPopUp, ""));
            String vBNK_QM_ResponseQueryType = Constants.QueryManagementOR.getProperty("BNK_QM_ResponseQueryType");
            String vBNK_RespondQueryForm_Save = Constants.QueryManagementOR.getProperty("BNK_RespondQueryForm_Save");
            String vBNK_RespondQueryAnswerCode = Constants.QueryManagementOR.getProperty("BNK_RespondQueryAnswerCode");
            String vBNK_RespondQueryNarrative = Constants.QueryManagementOR.getProperty("BNK_RespondQueryNarrative");
            key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_QM_ResponseQueryType, BankName));
            key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_RespondQueryAnswerCode, "/17/"));
            if (Constants.key.getText(vBNK_RespondQueryNarrative).isEmpty()) {
                Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_RespondQueryNarrative, "Testing Purpose"));
            }
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_RespondQueryForm_Save, ""));
            Assert.assertEquals("PASS", Constants.key.waitForAlert(120));

        } else if (Filed.equalsIgnoreCase("Authorise") && SubMenu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User Fill All Details in Authorise PopUp on Pending Authorise......");

            String vBNK_PA_AuthorisePopUp = Constants.QueryManagementOR.getProperty("BNK_PA_AuthorisePopUp");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PA_AuthorisePopUp, ""));
            String vBNK_PA_AuthoriseSelect = Constants.QueryManagementOR.getProperty("BNK_PA_AuthoriseSelect");
            String vBNK_AuthoriseQueryForm_Save = Constants.QueryManagementOR.getProperty("BNK_AuthoriseQueryForm_Save");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_PA_AuthoriseSelect, BankName));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_AuthoriseQueryForm_Save, ""));

        } else if (Filed.equalsIgnoreCase("Type") && SubMenu.equalsIgnoreCase("Import Query")) {
            LogCapture.info("User Fill Query Type in Import Query PopUp on Query Exception......");

            String vBNK_PA_AuthorisePopUp = Constants.QueryManagementOR.getProperty("BNK_PA_AuthorisePopUp");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PA_AuthorisePopUp, ""));
            String vBNK_ImportQuery_Heading = Constants.QueryManagementOR.getProperty("BNK_ImportQuery_Heading");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_ImportQuery_Heading, "Leave Query"));
            String vBNK_ImportQueryForm_Type = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_Type");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_ImportQueryForm_Type, BankName));

        } else if (Filed.equalsIgnoreCase("Transaction Type") && SubMenu.equalsIgnoreCase("Import Query")) {
            LogCapture.info("User Fill Transaction Type in Import Query PopUp on Query Exception......");

            String vBNK_ImportQueryForm_TransactionType = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_TransactionType");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_ImportQueryForm_TransactionType, BankName));

            if (BankName.equalsIgnoreCase("Anonymous Query")) {

                String vBNK_ImportQueryForm_OrgType = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_OrgType");
                String vBNK_ImportQueryForm_BankType = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_BankType");
                String vBNK_ImportQueryForm_SubmitBtn = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_SubmitBtn");
                Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_ImportQueryForm_OrgType, "Currencies Direct"));
                Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_ImportQueryForm_BankType, "Barclays"));
                Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_ImportQueryForm_SubmitBtn, ""));

            }
        } else if (Filed.equalsIgnoreCase("Reference Id") && SubMenu.equalsIgnoreCase("Import Query")) {
            LogCapture.info("User Enter Invalid Reference Id in Import Query PopUp on Query Exception......");

            String vBNK_ImportQueryForm_ReferenceID = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_ReferenceID");
            String vBNK_ImportQueryForm_SubmitBtn = Constants.QueryManagementOR.getProperty("BNK_ImportQueryForm_SubmitBtn");
            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_ImportQueryForm_ReferenceID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_ImportQueryForm_ReferenceID, BankName));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_ImportQueryForm_SubmitBtn, ""));

        }
    }

    @Then("^User Verify (Raised Query|Respond Query|Authorise Query) In (Pending Authorize queue|Queries|Message Out) For Query Management$")
    public void userVerifyRaisedQueryInPendingAuthorizeQueueForQueryManagement(String Operation, String SubMenu) throws Throwable {
        if (Operation.equalsIgnoreCase("Raised Query") && SubMenu.equalsIgnoreCase("Pending Authorize queue")) {
            LogCapture.info("User Verify Raiesed Query in Pending Authorize queue......");

            String vBNK_QM_PAQQueryID = Constants.QueryManagementOR.getProperty("BNK_QM_PAQQueryID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_PAQQueryID, ""));
            String vBNK_QM_PAQQueryRelatedReference = Constants.QueryManagementOR.getProperty("BNK_QM_PAQQueryRelatedReference");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_QM_PAQQueryRelatedReference, "1542565232545625"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_QM_PAQQueryRelatedReference, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_PAQQueryID, ""));
            String QueryID = Constants.key.getText(vBNK_QM_PAQQueryID);
            LogCapture.info("Query ID = " + QueryID);

        } else if (Operation.equalsIgnoreCase("Respond Query") && SubMenu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Verify Respond Query in Queries Page......");

            String vBNK_QM_QueriesTableIDInput = Constants.QueryManagementOR.getProperty("BNK_QM_QueriesTableIDInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_QM_QueriesTableIDInput, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_QM_QueriesTableIDInput, QueryID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_QM_QueriesTableIDInput, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_QueriesCheckBox = Constants.QueryManagementOR.getProperty("BNK_QueriesCheckBox");
            Assert.assertEquals("PASS", Constants.key.click(vBNK_QueriesCheckBox, ""));
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

        } else if (Operation.equalsIgnoreCase("Authorise Query") && SubMenu.equalsIgnoreCase("Message Out")) {
            LogCapture.info("User Verify Authorise Query in Message Out Page......");

            String vBNK_MessageOutRelatedReference = Constants.QueryManagementOR.getProperty("BNK_MessageOutRelatedReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_MessageOutRelatedReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_MessageOutRelatedReference, RelatedReference));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_MessageOutRelatedReference, "enter"));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
            String vBNK_MessageOutTransactionReference = Constants.QueryManagementOR.getProperty("BNK_MessageOutTransactionReference");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_MessageOutTransactionReference, TransactionReference));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_MessageOutTransactionReference, "enter"));
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
        }

    }

    @And("^User select (Message Type|Organization) \"([^\"]*)\" from Manual Payment Upload page$")
    public void userSelectMessageTypeFromManualPaymentUploadPage(String Data, String Value) throws Throwable {
        key.pause("4", "");
        if (Data.equalsIgnoreCase("Message Type")) {
            LogCapture.info("User select Message Type from Manual Payment Upload page ......");

            String vBanking_ManualPaymentMessageType = Constants.MessageOR.getProperty("Banking_ManualPaymentMessageType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPaymentMessageType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBanking_ManualPaymentMessageType, Value));
        } else if (Data.equalsIgnoreCase("Organization")) {
            LogCapture.info("User select Organization from Manual Payment Upload page ......");

            String vBanking_ManualPaymentSelectOrganization = Constants.MessageOR.getProperty("Banking_ManualPaymentSelectOrganization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPaymentSelectOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBanking_ManualPaymentSelectOrganization, Value));
        }
    }

    @And("^User click on (Upload File|Process Manual Payment|Process Manual Payment Record) from (Manual Payment Upload|Manual PSR Upload) page$")
    public void userClickOnUploadFileFromManualPaymentUploadPage(String Data, String Menu) throws Throwable {
        key.pause("4", "");
        if (Data.equalsIgnoreCase("Upload file") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User Click on Upload file ......");

            String vBanking_ManualPaymentUploadButton = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPaymentUploadButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUploadButton, ""));
        } else if (Data.equalsIgnoreCase("Process Manual Payment") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User Click on Process Manual Payment ......");

            String vBanking_ProcessedManualPaymentText = Constants.MessageOR.getProperty("Banking_ProcessedManualPaymentText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ProcessedManualPaymentText, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ProcessedManualPaymentText, ""));
        } else if (Data.equalsIgnoreCase("Process Manual Payment Record") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User Click on Process Manual Payment Record ......");

            String vBanking_ProcessedManualPaymentRecord = Constants.MessageOR.getProperty("Banking_ProcessedManualPaymentRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ProcessedManualPaymentRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ProcessedManualPaymentRecord, ""));
        } else if (Data.equalsIgnoreCase("Upload file") && Menu.equalsIgnoreCase("Manual PSR Upload")) {
            LogCapture.info("User Click on Upload file ......");

            String vBanking_ManualPSRUploadButton = Constants.MessageOR.getProperty("Banking_ManualPSRUploadButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPSRUploadButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPSRUploadButton, ""));
        }
    }

    @And("^User verify (file Successfully uploaded|Bank Holiday|Other Day) on (Manual PSR Upload|Manual Payment Upload) page$")
    public void userVerifyFileSuccessfullyUploadedOnManualPSRUploadPage(String Data, String Menu) throws Throwable {
        key.pause("8", "");
        if (Data.equalsIgnoreCase("file Successfully uploaded") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User verify file upload ......");

            String vBanking_ManualPaymentSuccessfulUpload = Constants.MessageOR.getProperty("Banking_ManualPaymentSuccessfulUpload");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ManualPaymentSuccessfulUpload, "File uploaded successfully"));
        } else if (Data.equalsIgnoreCase("file Successfully uploaded") && Menu.equalsIgnoreCase("Manual PSR Upload")) {
            LogCapture.info("User verify file upload ......");

            String vBanking_ManualPaymentSuccessfulUpload = Constants.MessageOR.getProperty("Banking_ManualPaymentSuccessfulUpload");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ManualPaymentSuccessfulUpload, "File uploaded successfully"));
        } else if (Data.equalsIgnoreCase("Bank Holiday") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User verify file upload ......");

            String vBanking_ManualPaymentError = Constants.MessageOR.getProperty("Banking_ManualPaymentError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ManualPaymentError, "Today Is Bank Holiday Upload File On Next Working Day"));
        } else if (Data.equalsIgnoreCase("Other Day") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User verify file upload ......");

            String vBanking_ManualPaymentSuccessfulUpload = Constants.MessageOR.getProperty("Banking_ManualPaymentSuccessfulUpload");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ManualPaymentSuccessfulUpload, "File uploaded successfully"));
        }
    }

    @Then("^User Verify (Message No|Status) \"([^\"]*)\" on (Queries|Message Out) Page$")
    public void userVerifyMessageNoOnQueriesPage(String Verify, String MessageNO, String SubMenu) throws Throwable {
        if (Verify.equalsIgnoreCase("Message No") && SubMenu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Verify Message No for Respond Query in Queries SubMenu");

            String vBNK_SelectQueriesMesNo = Constants.QueryManagementOR.getProperty("BNK_SelectQueriesMesNo");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_SelectQueriesMesNo, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_SelectQueriesMesNo, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vBNK_SelectQueriesMesNo, MessageNO));

        } else if (Verify.equalsIgnoreCase("Status") && SubMenu.equalsIgnoreCase("Message Out")) {
            LogCapture.info("User Verify Message Status for Authorise Query in Message Out");

            String vBNK_MessageOut_Status = Constants.QueryManagementOR.getProperty("BNK_MessageOut_Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_MessageOut_Status, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_MessageOut_Status, ""));
            String vBNK_MessageOut_RowCount = Constants.QueryManagementOR.getProperty("BNK_MessageOut_RowCount");
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vBNK_MessageOut_RowCount));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 1; i <= listOfElements.size(); i++) {
                String SelectRecord = "//table[@id='messageOutDIV']//tbody//tr[" + (i) + "]//td[9]";
                if (Constants.key.verifyText(SelectRecord, MessageNO).equalsIgnoreCase("PASS")) {
                    break;
                }
            }
        }
    }

    @And("^User click on (Message) Menu from Main (Dashboard) for Message Out TC$")
    public void userClickOnMessageMenuFromMainDashboardForMessageOutTC(String Menu, String Main) throws Throwable {
        key.pause("10", "");
        if (Menu.equalsIgnoreCase("Message") && Main.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Message Menu from Dashboard ......");

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_MessageMenu = Constants.QueryManagementOR.getProperty("BNK_MessageMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_MessageMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_MessageMenu, ""));

        }
    }

    @And("^User Click on (Failed Payment Out) SubMenu from (Message) Out Menu for Message Out TC$")
    public void userClickOnFailedPaymentOutSubMenuFromMessageOutMenuForMessageOutTC(String SubMenu, String Menu) throws Throwable {
        key.pause("6", "");
        if (SubMenu.equalsIgnoreCase("Failed Payment Out") && Menu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Failed Payment Out SubMenu from Message......");
            key.pause("4", "");
            String vBNK_Message_FailedPayment = Constants.MessageOR.getProperty("BNK_Message_FailedPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_Message_FailedPayment, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_Message_FailedPayment, ""));

        }
    }


    @And("^User (Upload file|Upload incorrect file) from (Manual Payment Upload|Manual PSR Upload) page$")
    public void userUploadFileFromManualPaymentUploadPage(String Data, String Menu) throws Throwable {
        key.pause("4", "");
        if (Data.equalsIgnoreCase("Upload file") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User verify file upload ......");

            String pathtoUpload = System.getProperty("user.dir") + "/Files/Manual Payment Upload.xlsx";
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUploadFile, ""));
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualPaymentUploadFile, pathtoUpload));
        } else if (Data.equalsIgnoreCase("Upload file") && Menu.equalsIgnoreCase("Manual PSR Upload")) {
            LogCapture.info("User verify file upload ......");

            String pathtoUpload = System.getProperty("user.dir") + "/files/Manual PSR Upload.xlsx";
            String vBanking_ManualPSRUploadFile = Constants.MessageOR.getProperty("Banking_ManualPSRUploadFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualPSRUploadFile, pathtoUpload));
        } else if (Data.equalsIgnoreCase("Upload incorrect file") && Menu.equalsIgnoreCase("Manual PSR Upload")) {
            LogCapture.info("User verify file upload ......");

            String pathtoUpload = System.getProperty("user.dir") + "/files/test.txt";
            String vBanking_ManualPSRUploadFile = Constants.MessageOR.getProperty("Banking_ManualPSRUploadFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualPSRUploadFile, pathtoUpload));
        }
    }

    @And("^User click on (Upload File) and handle alert from Manual PSR Upload page$")
    public void userClickOnUploadFileAndHandleAlertFromManualPSRUploadPage(String Data) throws Throwable {
        if (Data.equalsIgnoreCase("Upload File")) {
            LogCapture.info("User click on Upload File and see alert message on Message Out page......");

            String vBanking_ManualPSRUploadButton = Constants.MessageOR.getProperty("Banking_ManualPSRUploadButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPSRUploadButton, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBanking_ManualPSRUploadButton, ""));

        }
    }

    @Then("^User should get Reset Filter, Print and Export option on FXConfirmation Entries page$")
    public void userShouldGetResetFilterPrintAndExportOptionOnFXConfirmationEntriesPage() throws Throwable {
        LogCapture.info("Checking Reset Filter, Print and Export option are visible on FXConfirmation Entries page......");

        String vObjGenerateCSVFile = Constants.FXConfirmationOR.getProperty("GenerateCSVFile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateCSVFile, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjGenerateCSVFile, ""));

        String vObjPrintFXConfirmationEntries = Constants.FXConfirmationOR.getProperty("GenerateCSVFile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPrintFXConfirmationEntries, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjPrintFXConfirmationEntries, ""));

        String vObjChooseBalanceConfirmationEntries = Constants.FXConfirmationOR.getProperty("GenerateCSVFile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChooseBalanceConfirmationEntries, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjChooseBalanceConfirmationEntries, ""));

        String vObjFXConfiramtionEntriesResetFilter = Constants.FXConfirmationOR.getProperty("GenerateCSVFile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXConfiramtionEntriesResetFilter, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjFXConfiramtionEntriesResetFilter, ""));

        LogCapture.info("Reset Filter, Print and Export option are visible on FXConfirmation Entries page......");

    }

    @And("^User Upload Empty \"([^\"]*)\" from Manual PSR Upload page$")
    public void userUploadEmptyFromManualPSRUploadPage(String Data) throws Throwable {
        if (Data.equalsIgnoreCase("Serial Number")) {
            LogCapture.info("User verify file upload ......");

            String pathtoUpload = System.getProperty("user.dir") + "/files/BlankSerialNumber.xlsx";
            String vBanking_ManualPSRUploadFile = Constants.MessageOR.getProperty("Banking_ManualPSRUploadFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualPSRUploadFile, pathtoUpload));
        } else if (Data.equalsIgnoreCase("Account Number")) {
            LogCapture.info("User verify file upload ......");

            String pathtoUpload = System.getProperty("user.dir") + "/files/BlankAccountNumber.xlsx";
            String vBanking_ManualPSRUploadFile = Constants.MessageOR.getProperty("Banking_ManualPSRUploadFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualPSRUploadFile, pathtoUpload));
        } else if (Data.equalsIgnoreCase("Bank Code")) {
            LogCapture.info("User verify file upload ......");

            String pathtoUpload = System.getProperty("user.dir") + "/files/BlankBankCode.xlsx";
            String vBanking_ManualPSRUploadFile = Constants.MessageOR.getProperty("Banking_ManualPSRUploadFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualPSRUploadFile, pathtoUpload));
        }

    }

    @And("^User verify Upload Error \"([^\"]*)\" on Manual PSR Upload page$")
    public void userVerifyUploadErrorOnManualPSRUploadPage(String Data) throws Throwable {
        LogCapture.info("User capture error message ......");

        String vBanking_ManualPSRUploadError = Constants.MessageOR.getProperty("Banking_ManualPSRUploadError");
        String errorMsg = Constants.key.getText(vBanking_ManualPSRUploadError);
        System.out.println("error message" + errorMsg);
        System.out.println("data is" + Data);
        Assert.assertTrue(errorMsg.contains(Data));

    }

    @And("^User verify Upload (CDH Error|Error) \"([^\"]*)\" on Manual Payment Upload page$")
    public void userVerifyUploadErrorOnManualPaymentUploadPage(String menu, String Data) throws Throwable {
        LogCapture.info("User capture error message ......");
        key.pause("6", "");
        if (menu.equalsIgnoreCase("CDH Error")) {
            String vBanking_ManualPaymentCDHOrganizationError = Constants.MessageOR.getProperty("Banking_ManualPaymentCDHOrganizationError");
            String errorMsg = Constants.key.getText(vBanking_ManualPaymentCDHOrganizationError);
            System.out.println("error message" + errorMsg);
            System.out.println("data is" + Data);
            Assert.assertTrue(errorMsg.contains(Data));
        } else if (menu.equalsIgnoreCase("Error")) {
            String vBanking_ManualPaymentError = Constants.MessageOR.getProperty("Banking_ManualPaymentError");
            String errorMsg = Constants.key.getText(vBanking_ManualPaymentError);
            System.out.println("error message" + errorMsg);
            System.out.println("data is" + Data);
            Assert.assertTrue(errorMsg.contains(Data));
        }
    }

    @And("^User click on PaymentEnteriesRecord and check for Raise Query option present$")
    public void userClickOnPaymentEnteriesRecordAndCheckForRaiseQueryOptionPresent() throws Throwable {
        LogCapture.info("User capture error message ......");

        String vBanking_ManualPSRUploadError = Constants.QueryManagementOR.getProperty("Banking_PaymentEnteriesSelectRecord");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPSRUploadError, ""));
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vBanking_ManualPSRUploadError));
        LogCapture.info("Total number of elements present: " + listOfElements.size());

        for (int i = 1; i <= listOfElements.size(); i++) {
            String SelectRecord = "//table[@id='paymentEntriesDIV']//tbody//tr[" + (i) + "]//td[1]";
            key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
            String vBNK_QM_RaiseQueryOption = Constants.QueryManagementOR.getProperty("BNK_QM_RaiseQueryOption");
            if (Constants.driver.findElement(By.xpath(vBNK_QM_RaiseQueryOption)).isDisplayed()) {
                break;
            }
            Assert.assertEquals("PASS", Constants.key.click(SelectRecord, ""));
        }

    }

    @And("^User verify (Query Type options) available on Payment Enteries page$")
    public void userVerifyQueryTypeOptionsAvailableOnPaymentEnteriesPage(String Data) throws Throwable {
        if (Data.equalsIgnoreCase("Query Type options")) {
            LogCapture.info("User verify Query Type options on Payment Enteries page......");

            String vBNK_QM_QueryType = Constants.QueryManagementOR.getProperty("BNK_QM_QueryType");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_QueryType, ""));
            String vBNK_QM_CancellationType = Constants.QueryManagementOR.getProperty("BNK_QM_CancellationType");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_CancellationType, ""));
            String vBNK_QM_AmendmentType = Constants.QueryManagementOR.getProperty("BNK_QM_AmendmentType");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_AmendmentType, ""));
            String vBNK_QM_MiscellaneousType = Constants.QueryManagementOR.getProperty("BNK_QM_MiscellaneousType");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_MiscellaneousType, ""));
            String vBNK_QM_Cancellation292 = Constants.QueryManagementOR.getProperty("BNK_QM_Cancellation292");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_Cancellation292, ""));

        }
    }

    @And("^User enter (Narrative|Reason) on Payment Enteries page$")
    public void userEnterNarrativeOnPaymentEnteriesPage(String Data) throws Throwable {
        key.pause("4", "");
        if (Data.equalsIgnoreCase("Narrative")) {
            LogCapture.info("User enter PaymentStatus on Failed Payment Out page......");

            String vBNK_QM_Narrative = Constants.QueryManagementOR.getProperty("BNK_QM_Narrative");
            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_QM_Narrative));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_QM_Narrative, "Test"));

        }

    }

    @And("^User Select (First Row) from (Failed Payment Out) Table in Message Out Page$")
    public void userSelectFirstRowFromFailedPaymentOutTableInMessageOutPage(String Row, String SubMenu) throws Throwable {
        if (Row.equalsIgnoreCase("First Row") && SubMenu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Right click on First Row fromFailed Payment Out......");

            String vBNK_Msg_FailedPayment_TableID = Constants.MessageOR.getProperty("BNK_Msg_FailedPayment_TableID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_Msg_FailedPayment_TableID, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_Msg_FailedPayment_TableID, "RightClick"));
            PaymentID = Constants.key.getText(vBNK_Msg_FailedPayment_TableID);

        }
    }

    @And("^User Click on (Reject Payment) for selected Payment ID from (Failed Payment Out) in Message Out Page$")
    public void userClickOnRejectPaymentForSelectedPaymentIDFromFailedPaymentOutInMessageOutPage(String Operation, String SubMenu) throws Throwable {
        if (Operation.equalsIgnoreCase("Reject Payment") && SubMenu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Verify Reject Payment Option from Failed Payment Out......");

            String vBNK_FailedPaymentOut_RejectPayment = Constants.MessageOR.getProperty("BNK_FailedPaymentOut_RejectPayment");
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_FailedPaymentOut_RejectPayment, ""));
        }
    }

    @Then("^User Verify (Reject Payment Option) is Displayed In (Failed Payment Out) page in Message Out$")
    public void userVerifyRejectPaymentOptionIsDisplayedInFailedPaymentOutPageInMessageOut(String Operation, String SubMenu) throws Throwable {
        if (Operation.equalsIgnoreCase("Reject Payment Option") && SubMenu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User Verify Reject Payment Option from Failed Payment Out......");

            String vBNK_FailedPaymentOut_RejectPayment = Constants.MessageOR.getProperty("BNK_FailedPaymentOut_RejectPayment");
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_FailedPaymentOut_RejectPayment, ""));

        }
    }

    @And("^User switch to (Print PDF) window from (Failed Payment Out)$")
    public void userSwitchToPrintPDFWindowFromFailedPaymentOut(String Option, String SubMenu) throws Throwable {
        if (Option.equalsIgnoreCase("Print PDF") && SubMenu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("Failed Payment Out pdf is loading ......");

            Constants.key.switchToWindow("Payment Details");
        }
    }

    @Then("^User successfully landed on (SpotDealBooking) page$")
    public void userShouldNavigateToSpotDealBooking(String data) throws Exception {

        if (data.equalsIgnoreCase("SpotDealBooking")) {
            LogCapture.info("Spot Deal Booking screen loading ......");
            String vObjSpotDealBookingHeader = Constants.B2BOR.getProperty("B2B_BlotterReport_SpotDealBookingHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjSpotDealBookingHeader, "Spot deal booking"));

        }
    }

    @And("^User select (Tenor Value) \"([^\"]*)\" from (Spot Deal Booking) page$")
    public void userSelectTenorValueFromSpotDealBooking(String Value, String Opt, String Menu) throws Throwable {
        if (Value.equalsIgnoreCase("Tenor Value") && Menu.equalsIgnoreCase("Spot Deal Booking")) {
            LogCapture.info("User select Tenor Value ......");

            String vObjTenorValue = Constants.B2BOR.getProperty("B2B_BlotterReport_SpotDealBooking_TenorValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTenorValue, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjTenorValue, Opt));
        }
    }

    @Then("^User Verify (Currency Position) on (BlotterReport) page$")
    public void userVerifyCurrencyPositionOnBlotterReportPage(String Data, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("Currency Position") && Menu.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Blotter report data loading ......");
            String vPageLoader = Constants.BankingOR.getProperty("B2B_BlotterReport_SpotDealBooking_CurrencyPosition");
            //Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            //String vObjBlotterTotal = Constants.B2BOR.getProperty("B2B_BlotterReport_Total");
            //Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlotterTotal, "Total"));
        }
    }


    @And("^User click on (Change Preference|ExportToExcel) Icon from (Trading Dashboard) Report$")
    public void userClickOnChangePreferenceIconFromTradingDashboardReport(String Icon, String Menu) throws Throwable {
        if (Icon.equalsIgnoreCase("Change Preference") && Menu.equalsIgnoreCase("Trading Dashboard")) {
            LogCapture.info("User Click on change preference at top right corner.....");

            String vB2B_BlotterReport_ChangePreference = Constants.B2BOR.getProperty("B2B_BlotterReport_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2B_BlotterReport_ChangePreference, ""));
            WebElement ele = Constants.driver.findElement(By.xpath("//a[@id='chooseBalanceColumn']"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        } else if (Icon.equalsIgnoreCase("ExportToExcel") && Menu.equalsIgnoreCase("Trading Dashboard")) {
            LogCapture.info("User Click on ExportToExcel at top right corner.....");

            String vB2B_TradingDashboard_ExportToExcelIcon = Constants.B2BOR.getProperty("B2B_TradingDashboard_ExportToExcelIcon");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2B_TradingDashboard_ExportToExcelIcon, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vB2B_TradingDashboard_ExportToExcelIcon, ""));
        }
    }

    @And("^User Change Preference for (Trading Dashboard) Report$")
    public void userChangePreferenceForTradingDashboardReport(String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("Trading Dashboard")) {
            LogCapture.info("User deselect Type ChangePreference change preference at top right corner.....");

            String vB2B_TradingDashboard_ChangePreference = Constants.B2BOR.getProperty("B2B_TradingDashboard_ChangePreference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2B_TradingDashboard_ChangePreference, ""));
            if (Constants.key.verifyElementProperties(vB2B_TradingDashboard_ChangePreference, "unselected").equalsIgnoreCase("PASS")) {
                Constants.key.click(vB2B_TradingDashboard_ChangePreference, "");
            }
            Assert.assertEquals("PASS", Constants.key.click(vB2B_TradingDashboard_ChangePreference, ""));
        }
    }

    @And("^User click on Apply Change Preference from (TradingDashboardReport)$")
    public void userClickOnApplyChangePreferenceFromTradingDashboardReport(String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("User Apply ChangePreference for selected column.....");

            String vB2B_TradingDashboard_ChangePreferenceApply = Constants.B2BOR.getProperty("B2B_TradingDashboard_ChangePreferenceApply");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2B_TradingDashboard_ChangePreferenceApply, ""));
            WebElement ele = Constants.driver.findElement(By.xpath("//form[@id='detailsForm']//input[@name='applyFilter']"));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
        }
    }

    @Then("^User should successfully see Preferred changed preference not present on (Trading Dashboard Report)$")
    public void userShouldSuccessfullySeePreferredChangedPreferenceNotPresentOnTradingDashboardReport(String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("Trading Dashboard Report")) {
            LogCapture.info("User verify selected column is not present in table.....");

            String vB2B_TradingDashboard_ChangePreferenceType = Constants.B2BOR.getProperty("B2B_TradingDashboard_ChangePreferenceType");
            Assert.assertEquals("PASS", Constants.key.notexist(vB2B_TradingDashboard_ChangePreferenceType, ""));
        }
    }

    @Then("^File is successfully downloaded in the directory from (Trading Dashboard|Manual Payment Upload) Report$")
    public void fileIsSuccessfullyDownloadedInTheDirectoryFromTradingDashboardReport(String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("Trading Dashboard")) {
            if (Menu.equalsIgnoreCase("Trading Dashboard")) {
                LogCapture.info("File download path is " + System.getProperty("user.home"));
                String downloadPath = System.getProperty("user.home") + "/Downloads/";
                LogCapture.info("File download path is " + downloadPath);

                String fileName = "Banking_Portal_Trade_Report.csv";
                Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));
            }
        }
    }

    @Then("^User should successfully land on (Organization Details|Opening Closing|One Time Configurable|OrgCurrency Details|Rule Engine|Event Log|Pending B2B Deals) Menu from RFQ$")
    public void userShouldSuccessfullyLandOnOrganizationDetailsMenuFromRFQ(String data) throws Throwable {
        if (data.equalsIgnoreCase("Organization Details")) {
            LogCapture.info("User landed on Organization Details page ......");
            String vRFQ_OrganizationDetails_VerifyOrgName = Constants.RFQOR.getProperty("RFQ_OrganizationDetails_VerifyOrgName");
            key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRFQ_OrganizationDetails_VerifyOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vRFQ_OrganizationDetails_VerifyOrgName, "orgName"));
        } else if (data.equalsIgnoreCase("Opening Closing")) {
            LogCapture.info("User landed on Opening Closing page ......");
            key.pause("4", "");
            String vRFQ_OpeningClosing_VerifyOpeningTime = Constants.RFQOR.getProperty("RFQ_OpeningClosing_VerifyOpeningTime");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRFQ_OpeningClosing_VerifyOpeningTime, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vRFQ_OpeningClosing_VerifyOpeningTime, "OpeningTime"));
        } else if (data.equalsIgnoreCase("One Time Configurable")) {
            LogCapture.info("User landed on One Time Configurable page ......");
            String vRFQ_OneTimeConfig_VerifyText = Constants.RFQOR.getProperty("RFQ_OneTimeConfig_VerifyText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRFQ_OneTimeConfig_VerifyText, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vRFQ_OneTimeConfig_VerifyText, "One Time Configuration"));
        } else if (data.equalsIgnoreCase("OrgCurrency Details")) {
            LogCapture.info("User landed on OrgCurrency Details page ......");
            String vRFQ_OrganizationDetails_VerifyOrgName = Constants.RFQOR.getProperty("RFQ_OrganizationDetails_VerifyOrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRFQ_OrganizationDetails_VerifyOrgName, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vRFQ_OrganizationDetails_VerifyOrgName, "orgName"));
        } else if (data.equalsIgnoreCase("Rule Engine")) {
            LogCapture.info("User landed on Rule Engine page ......");
            key.pause("2", "");
            String vRFQ_RuleEngine_VerifyText = Constants.RFQOR.getProperty("RFQ_RuleEngine_VerifyText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRFQ_RuleEngine_VerifyText, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vRFQ_RuleEngine_VerifyText, "Rule Engine Status"));
        } else if (data.equalsIgnoreCase("Event Log")) {
            LogCapture.info("User landed on Event Log page ......");
            String vRFQ_EventLog_Text = Constants.RFQOR.getProperty("RFQ_EventLog_Text");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRFQ_EventLog_Text, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vRFQ_EventLog_Text, "Event"));
        } else if (data.equalsIgnoreCase("Pending B2B Deals")) {
            LogCapture.info("User landed on Pending B2B Deals page ......");
            String vRFQ_PendingB2B_OrgNameText = Constants.RFQOR.getProperty("RFQ_PendingB2B_OrgNameText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRFQ_PendingB2B_OrgNameText, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vRFQ_PendingB2B_OrgNameText, "orgName"));
        }
    }

    @And("^User click on (AuditLog|User Audit Log) Menu from (Dashboard|Audit Log)$")
    public void userClickOnAuditLogMenuFromDashboard(String MainMenu, String SubMenu) throws Throwable {
        key.pause("6", "");
        if (MainMenu.equalsIgnoreCase("AuditLog") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Audit Log Menu ......");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vAuditLogMenu = Constants.RFQOR.getProperty("AuditLogMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vAuditLogMenu, ""));

            Assert.assertEquals("PASS", Constants.key.click(vAuditLogMenu, ""));
        } else if (MainMenu.equalsIgnoreCase("User Audit Log") && SubMenu.equalsIgnoreCase("Audit Log")) {
            LogCapture.info("User Click on User Audit Log Menu ......");
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vUserAuditLogMenu = Constants.RFQOR.getProperty("UserAuditLogMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vUserAuditLogMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vUserAuditLogMenu, ""));
        }
    }

    @Then("^User should successfully land on User Audit Log page$")
    public void userShouldSuccessfullyLandOnUserAuditLogPage() throws Throwable {
        LogCapture.info("User Audit Log Page loading ......");
        String vAuditLog_TableVerify = Constants.RFQOR.getProperty("AuditLog_TableVerify");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vAuditLog_TableVerify, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vAuditLog_TableVerify, ""));
    }


    @And("^User Open Duplicate tab for (Potential Duplicate Queue)$")
    public void userOpenDuplicateTabForPotentialDuplicateQueue(String Menu) throws Throwable {
        LogCapture.info("User Open Duplicate tab for " + Menu);
        if (Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            key.pause("5", "");
            String vObjBankingMenu_DuplicateQueue = Constants.BankingOR.getProperty("BankingMenu_DuplicateQueue");
            Assert.assertEquals("PASS", key.OpenDuplicateTab(vObjBankingMenu_DuplicateQueue));
        }
    }

    @And("^User Apply Filter On State \"([^\"]*)\" and Status \"([^\"]*)\"$")
    public void userApplyFilterOnStatusAndState(String State, String Status) throws Throwable {

        LogCapture.info("User Apply Filter On Status as " + Status + " and State as " + State + "");
        String vBNK_Table_State = Constants.PaymentMonitoringOR.getProperty("BNK_Table_State");
        Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_State, ""));
        Assert.assertEquals("PASS", key.SelectDropDownValue(vBNK_Table_State, State));

        String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
        Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        String vBNK_Table_Status = Constants.PaymentMonitoringOR.getProperty("BNK_Table_Status");
        Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_Status, ""));
        Assert.assertEquals("PASS", key.SelectDropDownValue(vBNK_Table_Status, Status));

        Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

    }

    @And("^User Apply Filter on Bank \"([^\"]*)\"$")
    public void userApplyFilterOnBank(String Bank) throws Throwable {
        LogCapture.info("User Select Bank as " + Bank);

        String vBNK_Table_Bank = Constants.PaymentMonitoringOR.getProperty("BNK_Table_Bank");
        Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_Bank, ""));
        Assert.assertEquals("PASS", key.SelectDropDownValue(vBNK_Table_Bank, Bank));
        String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
        Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

    }

    @Then("^User verify Raise Query Option is (displayed|not displayed) for Selected Bank$")
    public void userVerifyRaiseQueryOptionIsDisplayedForSelectedBank(String Visibility) throws Exception {
        LogCapture.info("User verify Raise Query Option is " + Visibility + " for Selected Bank");
        if (Visibility.equalsIgnoreCase("displayed")) {
            LogCapture.info("Displayed loop entered");

            //String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            //Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_Table_raiseQuerycheckbox = Constants.PaymentMonitoringOR.getProperty("BNK_Table_raiseQuerycheckbox");
            LogCapture.info("vBNK_Table_raiseQuerycheckbox display check");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_raiseQuerycheckbox, ""));
            LogCapture.info("vBNK_Table_raiseQuerycheckbox is displayed and proceed to right click");

            Assert.assertEquals("PASS", key.navigateSubMenu(vBNK_Table_raiseQuerycheckbox, "RightClick"));

            Assert.assertEquals("PASS", key.MouseFunctions(vBNK_Table_raiseQuerycheckbox, "RightClick"));
            LogCapture.info("vBNK_Table_raiseQuerycheckbox right click completed");

            String vBNK_Table_liRaiseQuery = Constants.PaymentMonitoringOR.getProperty("BNK_Table_liRaiseQuery");
            LogCapture.info("wait for vBNK_Table_liRaiseQuery");
            int count = 10;
            while (!key.verifyElementProperties(vBNK_Table_liRaiseQuery, "visible").equalsIgnoreCase("PASS")) {
                LogCapture.info("inside while loop...");
                Assert.assertEquals("PASS", key.MouseFunctions(vBNK_Table_raiseQuerycheckbox, "RightClick"));
                LogCapture.info("inside while loop right clicked...");

                count++;
                if (count > 10) {
                    break;
                }
            }
            LogCapture.info("got out of while loop...");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_liRaiseQuery, ""));
            LogCapture.info("vBNK_Table_liRaiseQuery is visible");
//                String vBankingPagerDetails=Constants.BankingOR.getProperty("Banking_PagerDetails");
//                WebElement ele=Constants.driver.findElement(By.xpath(vBankingPagerDetails));
//                JavascriptExecutor executor=((JavascriptExecutor) Constants.driver);
//                executor.executeScript("arguments[0].click();", ele);
//
//                LogCapture.info("vBankingPagerDetails elements is clicked");
//                //String vBankingPagerDetails = Constants.BankingOR.getProperty("Banking_PagerDetails");
//                //Assert.assertEquals("PASS", key.click(vBankingPagerDetails,""));


        } else if (Visibility.equalsIgnoreCase("not displayed")) {

            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_Table_raiseQuerycheckbox = Constants.PaymentMonitoringOR.getProperty("BNK_Table_raiseQuerycheckbox");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_raiseQuerycheckbox, ""));
            Assert.assertEquals("PASS", key.MouseFunctions(vBNK_Table_raiseQuerycheckbox, "RightClick"));
            String vBNK_Table_liRaiseQuery = Constants.PaymentMonitoringOR.getProperty("BNK_Table_liRaiseQuery");
            Assert.assertEquals("PASS", key.notexist(vBNK_Table_liRaiseQuery, ""));
            Assert.assertEquals("PASS", key.click(vBNK_Table_raiseQuerycheckbox, ""));
        }

    }

    @And("^User Switch to (First|Second) tab and Reject Payment$")
    public void userSwitchToFirstTabAndRejectPayment(String Tab) throws Exception {
        LogCapture.info("User Reject Payment form " + Tab + " tab");
        if (Tab.equalsIgnoreCase("First")) {

            ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(tabs2.get(0));
            String vBNK_Table_raiseQuerycheckbox = Constants.PaymentMonitoringOR.getProperty("BNK_Table_raiseQuerycheckbox");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_raiseQuerycheckbox, ""));
            Assert.assertEquals("PASS", key.click(vBNK_Table_raiseQuerycheckbox, ""));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_PDQ_RejectPayment = Constants.PaymentMonitoringOR.getProperty("BNK_PDQ_RejectPayment");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_PDQ_RejectPayment, ""));
            Assert.assertEquals("PASS", key.clickAndHandleAlert(vBNK_PDQ_RejectPayment, ""));
        } else if (Tab.equalsIgnoreCase("Second")) {

            ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(tabs2.get(1));
            String vBNK_Table_raiseQuerycheckbox = Constants.PaymentMonitoringOR.getProperty("BNK_Table_raiseQuerycheckbox");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_raiseQuerycheckbox, ""));
            Assert.assertEquals("PASS", key.click(vBNK_Table_raiseQuerycheckbox, ""));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vBNK_PDQ_RejectPayment = Constants.PaymentMonitoringOR.getProperty("BNK_PDQ_RejectPayment");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_PDQ_RejectPayment, ""));
            Assert.assertEquals("PASS", key.clickAndHandleAlert(vBNK_PDQ_RejectPayment, ""));
        }
    }

    @Then("^User verify Alert \"([^\"]*)\" for (Rejected|already Rejected) Payment$")
    public void userVerifyAlertForRejectedPayment(String Alert, String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("Rejected") | Menu.equalsIgnoreCase("already Rejected")) {
            LogCapture.info("User see alert message respective page......");

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + Alert);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(Alert));
        }
    }

    @Then("^User verify (Sucessful|Unsucessful) Alert \"([^\"]*)\" for Rejected Payment$")
    public void userVerifySucessfulAlertForRejectedPayment(String Menu, String Alert) throws Throwable {
        key.pause("6", "");
        if (Menu.equalsIgnoreCase("Sucessful") | Menu.equalsIgnoreCase("Unsucessful")) {
            LogCapture.info("User see alert message respective page......");

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + Alert);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(Alert));
        }
    }


    @And("^User select (status|source|state|bank|paymentType|paymentCode|Payment) from dropdown \"([^\"]*)\"$")
    public void userSelectStatusFromDropdown(String value, String dropdownVal) throws Throwable {
        Constants.key.pause("5", "");
        if (value.equalsIgnoreCase("status")) {
            Constants.key.pause("5", "");
            String vObjBNK_PaymentEntries_SelectStatus = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_SelectStatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_SelectStatus, ""));
            //Assert.assertEquals("PASS", Constants.key.click(vObjBNK_PaymentEntries_SelectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_SelectStatus, dropdownVal));

        } else if (value.equalsIgnoreCase("source")) {
            Constants.key.pause("5", "");
            String vObjBNK_PaymentEntries_SelectSource = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_SelectSource");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_SelectSource, ""));
            //Assert.assertEquals("PASS", Constants.key.click(vObjBNK_PaymentEntries_SelectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_SelectSource, dropdownVal));

        } else if (value.equalsIgnoreCase("state")) {
            Constants.key.pause("5", "");
            String vObjBNK_PaymentEntries_SelectState = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_SelectState");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_SelectState, ""));
            //Assert.assertEquals("PASS", Constants.key.click(vObjBNK_PaymentEntries_SelectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_SelectState, dropdownVal));

        } else if (value.equalsIgnoreCase("bank")) {
            Constants.key.pause("5", "");
            String vObjBNK_PaymentEntries_SelectBank = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_SelectBank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_SelectBank, ""));
            //Assert.assertEquals("PASS", Constants.key.click(vObjBNK_PaymentEntries_SelectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_SelectBank, dropdownVal));

        } else if (value.equalsIgnoreCase("paymentType")) {
            Constants.key.pause("5", "");
            String vObjBNK_PaymentEntries_EnterPaymentType = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_EnterPaymentType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_EnterPaymentType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_EnterPaymentType, dropdownVal));


        } else if (value.equalsIgnoreCase("Payment")) {
            Constants.key.pause("5", "");
            String vObjBNK_PaymentEntries_EnterPaymentType = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_PaymentType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_EnterPaymentType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_EnterPaymentType, dropdownVal));

        } else if (value.equalsIgnoreCase("paymentCode")) {
            Constants.key.pause("5", "");
            String vObjBNK_PaymentEntries_EnterPaymentCode = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_EnterPaymentCode");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_EnterPaymentCode, ""));
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vObjBNK_PaymentEntries_EnterPaymentCode, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_PaymentEntries_EnterPaymentCode, dropdownVal));

        }
    }

    @And("^User note down the PaymentRef Number from Payment Entries Table$")
    public void userNoteDownThePaymentRefNumberFromPaymentEntriesTable() throws Exception {
        String vObjBNK_PaymentEntries_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_PaymentRef");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_PaymentRef, ""));
        PaymentRef = Constants.driver.findElement(By.xpath(vObjBNK_PaymentEntries_PaymentRef)).getText();
        System.out.println(PaymentRef);

    }

    @And("^User select decending order for Amount column$")
    public void userSelectDecendingOrderForAmountColumn() throws Exception {
        LogCapture.info("User Click on B2B Menu ......");

        //String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
        //Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        String vObjBNK_PaymentEntries_Amount = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_Amount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_Amount, ""));

        Assert.assertEquals("PASS", Constants.key.click(vObjBNK_PaymentEntries_Amount, ""));

    }

    @And("^User Verify auto approval limit is (greater|less) than for any currency \"([^\"]*)\"$")
    public void userVerifyAutoApprovalLimitIsGreaterThanForAnyCurrency(String option, String limit) throws Throwable {
        if (option.equalsIgnoreCase("greater")) {
            String vObjBNK_PaymentApproval_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_PaymentRef");
            String vObjBNK_PaymentApproval_Amount = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_Amount");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentApproval_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_PaymentApproval_PaymentRef));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_PaymentApproval_PaymentRef, PaymentRef));

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentApproval_Amount, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_PaymentApproval_Amount));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_PaymentApproval_Amount, ">" + limit));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_PaymentApproval_Amount, "enter"));


            String vObjBNK_PaymentApproval_PaymentRefValue = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_PaymentRefValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentApproval_PaymentRefValue, ""));
            String actualPaymentRef = Constants.driver.findElement(By.xpath(vObjBNK_PaymentApproval_PaymentRefValue)).getText();
            System.out.println(actualPaymentRef);


            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBNK_PaymentApproval_PaymentRefValue, PaymentRef));

        } else if (option.equalsIgnoreCase("less")) {
            String vObjBNK_PaymentApproval_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_PaymentRef");
            String vObjBNK_PaymentApproval_Amount = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_Amount");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentApproval_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_PaymentApproval_PaymentRef));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_PaymentApproval_PaymentRef, PaymentRef));

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentApproval_Amount, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_PaymentApproval_Amount));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_PaymentApproval_Amount, "<" + limit));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_PaymentApproval_Amount, "enter"));


            String vObjBNK_PaymentApproval_PaymentRefValue = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_PaymentRefValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentApproval_PaymentRefValue, ""));
            String actualPaymentRef = Constants.driver.findElement(By.xpath(vObjBNK_PaymentApproval_PaymentRefValue)).getText();
            System.out.println(actualPaymentRef);


            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBNK_PaymentApproval_PaymentRefValue, PaymentRef));

        }
    }

    @And("^User make changes on Auto Authorization Limit (high|low) \"([^\"]*)\"$")
    public void userMakeChangesOnAutoAuthorizationLimitHigh(String Option, String autoAuthorizationLimit) throws Throwable {
        if (Option.equalsIgnoreCase("high")) {
            LogCapture.info("User is Making Changes in Change Properties");

            String vBNK_AutoAuthLimit = Constants.PaymentMonitoringOR.getProperty("BNK_AutoAuthLimit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AutoAuthLimit, ""));
            //RandomNumber = RandomStringUtils.randomNumeric(3);
            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_AutoAuthLimit));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_AutoAuthLimit, autoAuthorizationLimit));

            String vBNK_ChangeProperties_SaveButton = Constants.PaymentMonitoringOR.getProperty("BNK_ChangeProperties_SaveButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChangeProperties_SaveButton, ""));

            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_ChangeProperties_SaveButton, ""));


            Alert alert = driver.switchTo().alert();
            alert.accept();
            Constants.key.pause("5", "");
        } else if (Option.equalsIgnoreCase("less")) {
            LogCapture.info("User is Making Changes in Change Properties");

            String vBNK_AutoAuthLimit = Constants.PaymentMonitoringOR.getProperty("BNK_AutoAuthLimit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_AutoAuthLimit, ""));
            //RandomNumber = RandomStringUtils.randomNumeric(3);
            Assert.assertEquals("PASS", Constants.key.clearText(vBNK_AutoAuthLimit));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_AutoAuthLimit, autoAuthorizationLimit));

            String vBNK_ChangeProperties_SaveButton = Constants.PaymentMonitoringOR.getProperty("BNK_ChangeProperties_SaveButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChangeProperties_SaveButton, ""));

            Assert.assertEquals("PASS", Constants.key.click(vBNK_ChangeProperties_SaveButton, ""));

//
//                        Alert alert=driver.switchTo().alert();
//                        alert.accept();
            Constants.key.pause("5", "");
        }
    }

    @Then("^User Verify Payment State\"([^\"]*)\" and Status\"([^\"]*)\" on (Payment Entries|Rejected Payment List) Page$")
    public void userVerifyPaymentStateAndStatusOnPaymentEntriesForPaymentTC(String State, String Status, String Page) throws Throwable {
        if (Page.equalsIgnoreCase("Payment Entries") || Page.equalsIgnoreCase("Rejected Payment List")) {
            String vBNK_PaymentEntriesApproval_State = "//table[@id='paymentEntriesDIV']/tbody/tr/td[text()='" + State + "']";
            LogCapture.info("vBNK_PaymentEntriesApproval_State xpath" + vBNK_PaymentEntriesApproval_State);

            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vBNK_PaymentEntriesApproval_State, "visible"));
            LogCapture.info("vBNK_PaymentEntriesApproval_State xpath is visible" + vBNK_PaymentEntriesApproval_State);
            LogCapture.info("Verified payment State as " + State);
            String vBNK_PaymentEntriesApproval_Status = "//table[@id='paymentEntriesDIV']/tbody/tr/td[7]";
            String ActualStatus = driver.findElement(By.xpath(vBNK_PaymentEntriesApproval_Status)).getText();
            LogCapture.info("ActualStatus --> " + ActualStatus);

            if (Status.equals("Confirmed") || Status.equals("Ready") || Status.equalsIgnoreCase("Approved")) {
                if (ActualStatus.equals("Confirmed") || ActualStatus.equals("Ready") || ActualStatus.equals("Approved")) {
                    LogCapture.info("Payment Status is " + ActualStatus);
                } else {
                    Assert.fail();
                    LogCapture.info("Actual Payment Status is " + ActualStatus);

                }

            } else if (Status.equals("Rejected")) {
                String vBNK_PaymentEntriesRejected_Status = "//table[@id=\"paymentEntriesDIV\"]/tbody/tr/td[text()='" + State + "']";
                Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vBNK_PaymentEntriesRejected_Status, "visible"));
                LogCapture.info("Verified payment Status as " + Status);
            }
        }

    }

    @And("^User copy the MT on Payment Entries page$")
    public void userCopyTheMTOnPaymentEntriesPage() throws Exception {
        String vObjBNK_PaymentEntries_CopyOfMTText = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_CopyOfMTText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_CopyOfMTText, ""));
        CopyofMT = Constants.driver.findElement(By.xpath(vObjBNK_PaymentEntries_CopyOfMTText)).getText();
        System.out.println(CopyofMT);

    }

    @And("^User click on Close button on Copy Of MT Screen$")
    public void userClickOnCloseButtonOnCopyOfMTScreen() throws Exception {
        LogCapture.info("User click on Close button on Copy Of MT Screen......");
        String vObjBNK_PaymentEntries_Close = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_Close");
        Assert.assertEquals("PASS", Constants.key.exist(vObjBNK_PaymentEntries_Close, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjBNK_PaymentEntries_Close, ""));

    }

    @And("^User enters (Transaction Reference|Sender Reference) number on message out$")
    public void userEnterTransactionReferenceNumberOnMessageOut(String ref) throws Exception {
        if (ref.equalsIgnoreCase("Transaction Reference")) {
            String vObjBNK_MessageOut_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_PaymentRef");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOut_PaymentRef));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOut_PaymentRef, PaymentRef));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOut_PaymentRef, "enter"));


        } else if (ref.equalsIgnoreCase("Sender Reference")) {
            String vObjBNK_MessageOut_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_SenderRef");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOut_PaymentRef));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOut_PaymentRef, PaymentRef));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOut_PaymentRef, "enter"));


        }
    }

    @And("^User enters (Payment Reference) number on Payment Entries$")
    public void userEnterPaymentReferenceNumberOnPaymentEntries(String ref) throws Exception {
        if (ref.equalsIgnoreCase("Payment Reference")) {
            String vObjBNK_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_SenderRef");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_PaymentRef));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_PaymentRef, PaymentRef));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_PaymentRef, "enter"));


        }
    }


    @And("^User Select (First Row) from (MessageOut) Table$")
    public void userSelectAnyRowFromTable(String Data, String Menu) throws Throwable {
        if (Data.equalsIgnoreCase("First Row") && Menu.equalsIgnoreCase("MessageOut")) {
            LogCapture.info("User Selecting Row from MessageOut Table......");

            String vObjBNK_MessageOut_SelectRow = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_SelectRow");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_SelectRow, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBNK_MessageOut_SelectRow, ""));
        }
    }

    @And("^User validate copyofMt between Paymententries and Messageout$")
    public void userValidateCopyofMtBetweenPaymententriesAndMessageout() throws Exception {
        String vObjBNK_MessageOut_CopyOfMTText = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_CopyOfMTText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_CopyOfMTText, ""));
        String actualCopyOfMT = Constants.driver.findElement(By.xpath(vObjBNK_MessageOut_CopyOfMTText)).getText();
        System.out.println(actualCopyOfMT);


        String[] actualcopyofMT1 = actualCopyOfMT.split("\n");
        System.out.println(actualcopyofMT1[1]);

        String[] actualcopyofMT2 = CopyofMT.split("\n");
        System.out.println(actualcopyofMT2[1]);

        for (int i = 0; i < actualcopyofMT1.length; i++) {
            for (int j = 0; j < actualcopyofMT2.length; j++) {
                if (actualcopyofMT1[i].equalsIgnoreCase(actualcopyofMT2[j])) {
                    System.out.println("Actual:: " + actualcopyofMT1[i] + "  Expected:: " + actualcopyofMT1[j]);
                    LogCapture.info("Actual:: " + actualcopyofMT1[i] + "  Expected:: " + actualcopyofMT1[j]);
                }
            }
        }


    }

    @And("^User click on (Submit Payment|Reject Payment|Submit) button$")
    public void userClickOnButton(String button) throws Exception {
        if (button.equalsIgnoreCase("Submit Payment")) {
            LogCapture.info("User click on Submit Payment .....");

            String vObjBNK_MessageOut_SubmitPayment = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_SubmitPayment");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_SubmitPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjBNK_MessageOut_SubmitPayment, ""));

            Alert alert = Constants.driver.switchTo().alert();
            alert.accept();


            Alert alert1 = Constants.driver.switchTo().alert();
            alert1.accept();

        } else if (button.equalsIgnoreCase("Reject Payment")) {
            LogCapture.info("User click on Reject Payment .....");
            String vObjBNK_MessageOut_Reject = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_Reject");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_Reject, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjBNK_MessageOut_Reject, ""));

            Alert alert = Constants.driver.switchTo().alert();
            alert.accept();


//            Alert alert1=Constants.driver.switchTo().alert();
//            alert1.accept();
//

//                        String vObjBNK_MessageOut_RejectReason=Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_RejectReason");
//                        String vObjBNK_MessageOut_RejectReasonText=Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_RejectReasonText");
//                        String vObjBNK_MessageOut_RejectButton=Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_RejectButton");
//
//
//                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_RejectReason, ""));
//                        Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjBNK_MessageOut_RejectReason, "Reject"));
//
//                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_RejectReasonText, ""));
//                        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOut_RejectReasonText, "Testing"));
//
//                        Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjBNK_MessageOut_RejectButton, ""));
//
//                        Alert alert2=Constants.driver.switchTo().alert();
//                        alert2.accept();
//
//


        } else if (button.equalsIgnoreCase("Submit")) {
            LogCapture.info("User click on Submit .....");
            String vObjBNK_MessageOut_SubmitPayment = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_Submit");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_SubmitPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjBNK_MessageOut_SubmitPayment, ""));


            Alert alert = Constants.driver.switchTo().alert();
            alert.accept();


        }
    }

    @Then("^User Verify Payment State\"([^\"]*)\" and Status\"([^\"]*)\"$")
    public void userVerifyPaymentStateAndStatusOnPaymentEntries(String State, String Status) throws Throwable {
        LogCapture.info("State Status data loading ......");

        String vPaymentEntriesStatusValue = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_StatusValue");
        String actual = Constants.driver.findElement(By.xpath(vPaymentEntriesStatusValue)).getText();
        if (actual.length() < 1) {
            actual = Constants.driver.findElement(By.xpath(vPaymentEntriesStatusValue)).getAttribute("value");
            System.out.println("actual value->>>>" + actual);
        }
        String expected = Status;
        System.out.println("actual value->>>>" + actual);
        System.out.println("data value->>>>" + Status);
        if (actual.equals("pendingMX") || actual.equals("pending")) {
            LogCapture.info("Actual Value:->" + actual);

        } else {
            LogCapture.info("Actual Value:->" + actual);
            Assert.fail();

        }
        //Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentEntriesStatusValue, Status));

        String vPaymentEntriesStateValue = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_StateValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentEntriesStateValue, State));

    }


    @Then("^User Verify Payment State\"([^\"]*)\" and Status\"([^\"]*)\" and PaymentType\"([^\"]*)\" and PaymentCode\"([^\"]*)\"$")
    public void userVerifyPaymentStateAndStatusAndPaymentType(String State, String Status, String PaymentType, String PaymentCode) throws Throwable {
        LogCapture.info("State Status data loading ......");
        String vPaymentEntriesStatusValue = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_StatusValue");

        String actual = Constants.driver.findElement(By.xpath(vPaymentEntriesStatusValue)).getText();
        if (actual.length() < 1) {
            actual = Constants.driver.findElement(By.xpath(vPaymentEntriesStatusValue)).getAttribute("value");
            System.out.println("actual value->>>>" + actual);
        }
        String expected = Status;
        System.out.println("actual value->>>>" + actual);
        System.out.println("data value->>>>" + Status);
        if (actual.equals("pendingMX") || actual.equals("pending")) {
            LogCapture.info("Actual Value:->" + actual);

        } else {
            LogCapture.info("Actual Value:->" + actual);
            Assert.fail();

        }

        //Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentEntriesStatusValue, Status));

        String vPaymentEntriesStateValue = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_StateValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentEntriesStateValue, State));
        String vObjBNK_PaymentEntries_PaymentType = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_PaymentType");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBNK_PaymentEntries_PaymentType, PaymentType));
        String vObjBNK_PaymentEntries_PaymentCode = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_PaymentCode");
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjBNK_PaymentEntries_PaymentCode, PaymentCode));


        String ActualPaymentCode = driver.findElement(By.xpath(vObjBNK_PaymentEntries_PaymentCode)).getText();
        LogCapture.info("ActualStatus --> " + ActualPaymentCode);
        if (Status.equals("International Payment") || Status.equals("LOCAL TRANSFER")) {
            if (ActualPaymentCode.equals("International Payment") || ActualPaymentCode.equals("LOCAL TRANSFER")) {
                LogCapture.info("Payment Code is " + ActualPaymentCode);
            } else {
                Assert.fail();
                LogCapture.info("Actual Payment Code is " + ActualPaymentCode);
            }


        }
    }

    @And("^User enter (Transaction Reference for CD|Transaction Reference for TorFx|Message out ID|Normal MessageOut ID) \"([^\"]*)\" on message out$")
    public void userEnterReferenceNumberOnMessageOut(String ref, String value) throws Exception {
        if (ref.equalsIgnoreCase("Transaction Reference for CD") || ref.equalsIgnoreCase("Transaction Reference for TorFx")) {
            String vObjBNK_MessageOut_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_PaymentRef");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOut_PaymentRef));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOut_PaymentRef, value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOut_PaymentRef, "enter"));
        } else if (ref.equalsIgnoreCase("Message out ID")) {
            String vObjBNK_MessageOutID = Constants.MessageOR.getProperty("MessageOutID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOutID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOutID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOutID, Kafka_ID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOutID, "enter"));
        } else if (ref.equalsIgnoreCase("Normal MessageOut ID")) {
            String vObjBNK_MessageOutID = Constants.MessageOR.getProperty("MessageOutID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOutID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOutID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOutID, MessageOutID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOutID, "enter"));
        }
    }

    @And("^User enter (Receiver BIC) \"([^\"]*)\" on message out$")
    public void userEnterReceiverBICOnMessageOut(String ref, String value) throws Exception {
        if (ref.equalsIgnoreCase("Receiver BIC")) {
            String vObjBNK_MessageOut_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_ReceiverBIC");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOut_PaymentRef));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOut_PaymentRef, value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOut_PaymentRef, "enter"));

        }
    }

    @And("^User validate the BIC Code \"([^\"]*)\"$")
    public void userValidateTheBICCode(String biccode) throws Throwable {
        LogCapture.info("User Validate the BIC Code ......");
        String vObjBanking_MessageOut_SenderBIC = Constants.MessageOR.getProperty("Banking_MessageOut_SenderBIC");

        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBanking_MessageOut_SenderBIC, biccode));
    }

//    @And("^User verify BtoB Deal Details$")
//    public void userVerifyBBDealDetails() throws Throwable {
//            LogCapture.info("User verify db details ......");
//            Assert.assertEquals("12390584", Constants.key.VerifyDBDetails("UAT", "","Verify Deal Details"));
//    }

    @And("^User verify the (Swap deal|Spot deal|Forward deal) data Populated data Populated in DB for (RBOS|JPM|DB) provider$")
    public void userVerifyTheSpotDealDataPopulatedInDB(String Deal, String Provider) throws Throwable {
        LogCapture.info("User verify DB Details ......");
        if (Deal.equalsIgnoreCase("Swap deal") && Provider.equalsIgnoreCase("RBOS")) {
            Assert.assertEquals("12390584", Constants.key.VerifyDBDetails("UAT", "", "Verify Deal Details"));


        } else if (Deal.equalsIgnoreCase("Spot deal") && Provider.equalsIgnoreCase("JPM")) {
            Assert.assertEquals("12390584", Constants.key.VerifyDBDetails("UAT", "", "Verify Deal Details"));

        }

    }


    @And("^User enter (Partial Transaction Reference|Sender Reference) number on message out$")
    public void userEnterPartialTransactionReferenceNumberOnMessageOut(String ref) throws Exception {
        if (ref.equalsIgnoreCase("Partial Transaction Reference")) {
            String vObjBNK_MessageOut_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_PaymentRef");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOut_PaymentRef));
            String PartialPaymentRef = PaymentRef.substring(1);
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOut_PaymentRef, PartialPaymentRef));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOut_PaymentRef, "enter"));


        } else if (ref.equalsIgnoreCase("Sender Reference")) {
            String vObjBNK_MessageOut_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_SenderRef");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_PaymentRef, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOut_PaymentRef));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOut_PaymentRef, PaymentRef));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOut_PaymentRef, "enter"));


        }
    }

    @And("^Validates copy of JPM message having \"([^\"]*)\" as \"([^\"]*)\"$")
    public void validatesCopyOfJPMMessageHavingAs(String key, String value) throws Throwable {
        Constants.key.pause("4", "");
        String vObj_Copymessage_api = Constants.PaymentMonitoringOR.getProperty("BNK_Copy_api_message");
        String api = Constants.driver.findElement(By.xpath(vObj_Copymessage_api)).getText();
        JsonPath jp = new JsonPath(api);
        String val = jp.get(key);
        Assert.assertEquals(val, value);
    }

    @And("^User should select Audit Trails on the Payment Entries and validate latest status as \"([^\"]*)\"$")
    public void userShouldSelectAuditTrailsOnThePaymentEntriesAndValidateLatestStatusAs(String status) throws Throwable {

        String vObj_AuditTrial = Constants.PaymentMonitoringOR.getProperty("BNK_audit_trial");
        String vObj_AuditTrial_close = Constants.PaymentMonitoringOR.getProperty("BNK_audit_trial_close");
        String vCheckbox1 = Constants.BankingOR.getProperty("BNK_BalanceEntries_Checkbox");
        LogCapture.info("wait for vObj_AuditTrial");
        while (!key.verifyElementProperties(vObj_AuditTrial, "visible").equalsIgnoreCase("PASS")) {
            LogCapture.info("inside while loop...");
            Assert.assertEquals("PASS", key.MouseFunctions(vCheckbox1, "RightClick"));
            LogCapture.info("inside while loop right clicked...");

        }
        Assert.assertEquals("PASS", key.VisibleConditionWait(vObj_AuditTrial, "RightClick"));


//        String vObj_AuditTrial=Constants.PaymentMonitoringOR.getProperty("BNK_audit_trial");
//        String vObj_AuditTrial_close=Constants.PaymentMonitoringOR.getProperty("BNK_audit_trial_close");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObj_AuditTrial, ""));
        String vObj_AuditTrialStatus = Constants.PaymentMonitoringOR.getProperty("BNK_audit_trial_status");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObj_AuditTrialStatus, ""));
        String audit_status = Constants.driver.findElement(By.xpath(vObj_AuditTrialStatus)).getText();
        Assert.assertEquals(status, audit_status);
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObj_AuditTrial_close, ""));
    }

    @And("^User tried to download payment file$")
    public void userTriedToDownloadPaymentFile() throws Exception {

        String vMessageOut = Constants.PaymentMonitoringOR.getProperty("BNK_messageout");
        System.out.println("vMessageOut --> " + vMessageOut);
        String vDownloadPaymentFile = Constants.PaymentMonitoringOR.getProperty("BNK_downoadpaymentfile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMessageOut, ""));

        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vMessageOut, "RightClick"));

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDownloadPaymentFile, ""));
    }

    @And("^Verify the SenderBIC is of type \"([^\"]*)\" and ReceiverBIC is of type \"([^\"]*)\"$")
    public void verifyTheSenderBICIsOfTypeAndReceiverBICIsOfType(String senderBIC, String receiverBIC) throws Throwable {

        String vObjBNK_MessageOut_reveiverBIC = Constants.PaymentMonitoringOR.getProperty("BNK_receiverBIC");
        String vObjBNK_MessageOut_senderBIC = Constants.PaymentMonitoringOR.getProperty("BNK_senderBIC");
        String vsenderBIC = Constants.key.getText(vObjBNK_MessageOut_reveiverBIC, "");
        String vreceiverBIC = Constants.key.getText(vObjBNK_MessageOut_senderBIC, "");
        if (vreceiverBIC.contains(receiverBIC) && vsenderBIC.contains(senderBIC)) {
            LogCapture.info("The sender and receiver BIC is correct for the selected bank");
        } else {
            LogCapture.info("The sender and receiver BIC is WRONG for the selected bank");
            Assert.fail();
        }


    }

    @And("^User enters (CDLEU|CDLGB) in CLE textbox and hits enter$")
    public void userEntersCDLEUInCLETextboxAndHitsEnter(String type) throws Exception {

        String vonj_CLE_text = "//input[@placeholder='e.g.CDLGB']";
        Assert.assertEquals("PASS", Constants.key.writeInInput(vonj_CLE_text, type));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vonj_CLE_text, "enter"));


    }

    @Then("^User select (copy of MT|copy of JPM|Copy Of CITI_PAIN) on (Payment Entries) page$")
    public void userShouldselectCopyOfMT(String Options, String Menu) throws Throwable {
        if (Options.equalsIgnoreCase("copy of MT") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Verifying Copy Of MT Option on right click......");
            String vCheckbox1 = Constants.BankingOR.getProperty("BNK_BalanceEntries_Checkbox");
            String vRightClickCopyOfMP = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitoring_RightClick_CopyOfMT");
            LogCapture.info("wait for BNK_PaymentMonitoring_RightClick_CopyOfMT");

//            while(!key.verifyElementProperties(vRightClickCopyOfMP, "visible").equalsIgnoreCase("PASS")) {
//                LogCapture.info("inside while loop...");
//                Assert.assertEquals("PASS", key.MouseFunctions(vCheckbox1, "RightClick"));
//                LogCapture.info("inside while loop right clicked...");
//
//
//
//            }
            // from here
            if (key.verifyElementProperties(vRightClickCopyOfMP, "visible").equalsIgnoreCase("PASS")) {
                LogCapture.info("right clicking on Copy of MT...");
                Assert.assertEquals("PASS", key.MouseFunctions(vCheckbox1, "RightClick"));
                LogCapture.info("right click performed on Copy of MT...");

            }

            // till here
            // Assert.assertEquals("PASS", key.VisibleConditionWait(vRightClickCopyOfMP, "RightClick"));

            //String vRightClickCopyOfMP=Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitoring_RightClick_CopyOfMT");
            String vObjBNK_PaymentEntries_CopyOfMTText = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_CopyOfMTText");

            Assert.assertEquals("PASS", Constants.key.exist(vRightClickCopyOfMP, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vRightClickCopyOfMP, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_PaymentEntries_CopyOfMTText, ""));


        } else if (Options.equalsIgnoreCase("copy of JPM") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Verifying Copy Of MT Option on right click......");
            String vRightClickCopyOfJPM = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitoring_RightClick_CopyOfJPM");
            // String vObjBNK_PaymentEntries_CopyOfMTText=Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_CopyOfMTText");
            String vCheckbox1 = Constants.BankingOR.getProperty("BNK_BalanceEntries_Checkbox");

            while (!key.verifyElementProperties(vRightClickCopyOfJPM, "visible").equalsIgnoreCase("PASS")) {
                LogCapture.info("inside while loop...");
                Assert.assertEquals("PASS", key.MouseFunctions(vCheckbox1, "RightClick"));
                LogCapture.info("inside while loop right clicked...");

            }
            Assert.assertEquals("PASS", key.VisibleConditionWait(vRightClickCopyOfJPM, "RightClick"));

            Assert.assertEquals("PASS", Constants.key.exist(vRightClickCopyOfJPM, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vRightClickCopyOfJPM, ""));

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRightClickCopyOfJPM, ""));
        } else if (Options.equalsIgnoreCase("Copy Of CITI_PAIN") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("User Verifying Copy Of CITI_PAIN Option on right click......");
            String vRightClickCopyOfCitiPain = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitoring_RightClick_CopyOfCitiPain");
            String vCheckbox1 = Constants.BankingOR.getProperty("BNK_BalanceEntries_Checkbox");
            String vObjBNK_PaymentEntries_CopyOfMTText = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_CopyOfMTText");
            while (!key.verifyElementProperties(vRightClickCopyOfCitiPain, "visible").equalsIgnoreCase("PASS")) {
                LogCapture.info("inside while loop...");
                Assert.assertEquals("PASS", key.MouseFunctions(vCheckbox1, "RightClick"));
                LogCapture.info("inside while loop right clicked...");


            }
            Assert.assertEquals("PASS", key.VisibleConditionWait(vRightClickCopyOfCitiPain, "RightClick"));
            Assert.assertEquals("PASS", Constants.key.exist(vRightClickCopyOfCitiPain, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vRightClickCopyOfCitiPain, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRightClickCopyOfCitiPain, ""));
        }
    }

    @And("^Validates copy of Citi message having \"([^\"]*)\" and saves it in a variable and searched it in message out page$")
    public void validatesCopyOfCitiMessageHavingAndSavesItInAVariable(String arg0) throws Throwable {

        String vObj_Copymessage_api = Constants.PaymentMonitoringOR.getProperty("BNK_Copy_api_message");
        String vObj_close_copyOf = Constants.PaymentMonitoringOR.getProperty("BNK_Copy_of");

        String api = Constants.driver.findElement(By.xpath(vObj_Copymessage_api)).getText();
        String vXmvValue = api.split("<MsgId>")[1].split("</MsgId>")[0];

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObj_close_copyOf, ""));

        LogCapture.info("User Click on Message Menu from Dashboard ......");

        String vBanking_Message = Constants.MessageOR.getProperty("Banking_Message");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_Message, ""));
        Assert.assertEquals("PASS", Constants.key.click(vBanking_Message, ""));

        LogCapture.info("User Click on Message Out Menu from Message ......");

        String vBanking_Message_MessageOut = Constants.MessageOR.getProperty("Banking_Message_MessageOut");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_Message_MessageOut, ""));
        Assert.assertEquals("PASS", Constants.key.click(vBanking_Message_MessageOut, ""));

        String vObjBNK_MessageOut_PaymentRef = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_PaymentRef");

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_PaymentRef, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjBNK_MessageOut_PaymentRef));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBNK_MessageOut_PaymentRef, vXmvValue));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBNK_MessageOut_PaymentRef, "enter"));


    }

    @And("^User checks in payments of selected file if CLE type is (CDLEU|CDLGB)$")
    public void userChecksInPaymentsOfSelectedFileIfCLETypeIsCDLEU(String type) {

        String vObj_CLE = "//table[@id='paymentEntriesDIV']//tbody//td[3]";
        List<WebElement> ele = driver.findElements(By.xpath(vObj_CLE));
        for (WebElement e : ele) {
            if (e.getText().equalsIgnoreCase(type)) {
                LogCapture.info("CLE type is correct");
            } else {
                LogCapture.info("CLE type is wrong");
                Assert.fail();
            }
        }
    }

    // CounterParty methods
    @And("^User select Organization \"([^\"]*)\" and User see alert \"([^\"]*)\" from CounterParty$")
    public void userSelectOrganizationAndUserSeeAlertFromCounterParty(String Org, String alert1) throws Throwable {
        if (Org.equalsIgnoreCase("Currencies Direct") && alert1.equalsIgnoreCase("PleaseSelectProvider")) {
            LogCapture.info("User select Organization Currencies Direct ......");

            String vObjOrganization = Constants.RFQOR.getProperty("RFQ_Organization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjOrganization, Org));
            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            //System.out.println("Value is " + Value);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(alert1));

        }
    }

    @And("^User select Provider \"([^\"]*)\" and User see alert \"([^\"]*)\" from CounterParty$")
    public void userSelectProviderAndUserSeeAlertFromCounterParty(String Prov, String alert2) throws Throwable {
        if (Prov.equalsIgnoreCase("BARCLAYS") && alert2.equalsIgnoreCase("PleaseSelectCurrencyPair")) {
            LogCapture.info("User select Provider Barclays ......");

            String vObjProvider = Constants.RFQOR.getProperty("RFQ_Provider");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProvider, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjProvider, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjProvider, Prov));
            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            //System.out.println("Value is " + Value);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(alert2));

        }
    }

    @And("^User select Currency Pair \"([^\"]*)\" from CounterParty$")
    public void userSelectCurrencyPairFromCounterParty(String CurrP) throws Throwable {
        if (CurrP.equalsIgnoreCase("EURUSD")) {
            LogCapture.info("User select Currency Pair EURUSD ......");

            String vObjCurrencyPair = Constants.RFQOR.getProperty("RFQ_CurrencyPair");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyPair, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyPair, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjCurrencyPair, CurrP));

        }
    }

    @And("^User select Offset \"([^\"]*)\" and User see alert \"([^\"]*)\" from CounterParty$")
    public void userSelectOffsetAndUserSeeAlertFromCounterParty(String Ofs, String alert3) throws Throwable {
        if (Ofs.equalsIgnoreCase("0") && alert3.equalsIgnoreCase("ToUpdateOffsetClickOnUpdateButton")) {
            LogCapture.info("User select Offset 0 ......");

            String vObjOffset = Constants.RFQOR.getProperty("RFQ_Offset");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOffset, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOffset, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjOffset, Ofs));

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            //System.out.println("Value is " + Value);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(alert3));
            key.pause("5", "");
        } else if (Ofs.equalsIgnoreCase("1") && alert3.equalsIgnoreCase("ToUpdateOffsetClickOnUpdateButton")) {
            LogCapture.info("User select Offset 1 ......");

            String vObjOffset = Constants.RFQOR.getProperty("RFQ_Offset");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOffset, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOffset, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjOffset, Ofs));

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            //System.out.println("Value is " + Value);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(alert3));

        } else if (Ofs.equalsIgnoreCase("2") && alert3.equalsIgnoreCase("ToUpdateOffsetClickOnUpdateButton")) {
            LogCapture.info("User select Offset 2 ......");

            String vObjOffset = Constants.RFQOR.getProperty("RFQ_Offset");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOffset, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOffset, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjOffset, Ofs));

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            //System.out.println("Value is " + Value);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(alert3));

        }
    }

    @And("^User clicks on Update Button and User see alert \"([^\"]*)\" from CounterParty$") // need to change this
    public void userClicksOnUpdateButtonAndUserSeeAlertFromCounterParty(String alert4) throws Throwable {
        String vObjUpdateButton = Constants.RFQOR.getProperty("RFQ_UpdateButton");
        LogCapture.info("On click on Update ......");
        Assert.assertEquals("PASS", Constants.key.click(vObjUpdateButton, ""));

        if (alert4.equalsIgnoreCase("OffsetUpdatedSuccessfully")) {
            key.pause("2", "");
            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            //System.out.println("Value is " + Value);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(alert4));
            LogCapture.info("Update button clicked ......");
        }
    }

    @And("^User clicks on Reset Button$")
    public void userClicksOnResetButton() throws Throwable {
        String vObjResetButton = Constants.RFQOR.getProperty("RFQ_ResetButton");
        LogCapture.info("Before click on Reset......");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjResetButton, ""));

        LogCapture.info("Reset button clicked ......");
    }

    @And("^User select B2B enable/disable and User see alert \"([^\"]*)\" and alert \"([^\"]*)\" from CounterParty$")
    public void userSelectBBEnableDisableAndUserSeeAlertAndAlertFromCounterParty(String alert5, String alert6) throws Throwable {
        String vobjB2BEnable = Constants.RFQOR.getProperty("RFQ_B2B_enable");
        String vobjB2BDisable = Constants.RFQOR.getProperty("RFQ_B2B_disable");
        if (Constants.key.verifyElementProperties(vobjB2BEnable, "visible").equalsIgnoreCase("PASS")) {
            LogCapture.info("User disabled B2B......");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vobjB2BEnable, ""));
            Constants.key.pause("4", "");
            if (alert5.equalsIgnoreCase("B2BIsInActive")) {
                Constants.key.pause("4", "");
                String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());

                System.out.println("Alert message is " + alertMessage);
                Assert.assertTrue(alertMessage.contains(alert5));
                LogCapture.info("B2B Disabled ......");

            }
        }

        if (Constants.key.verifyElementProperties(vobjB2BDisable, "visible").equalsIgnoreCase("PASS")) {
            LogCapture.info("User enabled B2B......");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vobjB2BDisable, ""));
            Constants.key.pause("4", "");
            if (alert6.equalsIgnoreCase("B2BIsActiveSuccessfully")) {
                Constants.key.pause("4", "");
                String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());

                System.out.println("Alert message is " + alertMessage);
                Assert.assertTrue(alertMessage.contains(alert6));
                LogCapture.info("B2B Enabled ......");
                Constants.key.pause("4", "");
            }
        }
    }

    @And("^User select RFQ enable/disable User see alert \"([^\"]*)\" and alert \"([^\"]*)\" from CounterParty$")
    public void userSelectRFQEnableDisableUserSeeAlertAndAlertFromCounterParty(String alert7, String alert8) throws Throwable {
        String vobjRFQEnable = Constants.RFQOR.getProperty("RFQ_RFQ_enable");
        String vobjRFQDisable = Constants.RFQOR.getProperty("RFQ_RFQ_disable");
        if (Constants.key.verifyElementProperties(vobjRFQEnable, "visible").equalsIgnoreCase("PASS")) {
            LogCapture.info("User Disabled RFQ......");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vobjRFQEnable, ""));
            Constants.key.pause("4", "");
            if (alert7.equalsIgnoreCase("RFQIsInActive")) {
                Constants.key.pause("4", "");
                String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());

                System.out.println("Alert message is " + alertMessage);
                Assert.assertTrue(alertMessage.contains(alert7));
                LogCapture.info("RFQ Disabled ......");
                Constants.key.pause("4", "");
            }
        }

        if (Constants.key.verifyElementProperties(vobjRFQDisable, "visible").equalsIgnoreCase("PASS")) {
            LogCapture.info("User enabled RFQ......");
            Assert.assertEquals("PASS", Constants.key.click(vobjRFQDisable, ""));
            Constants.key.pause("4", "");
            if (alert8.equalsIgnoreCase("RFQIsActiveSuccessfully")) {
                String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());

                System.out.println("Alert message is " + alertMessage);
                Assert.assertTrue(alertMessage.contains(alert8));
                LogCapture.info("RFQ Enabled ......");
                Constants.key.pause("4", "");
            }
        }

    }

    @And("^User should successfully see Provider \"([^\"]*)\" streaming$")
    public void userShouldSuccessfullySeeProviderStreaming(String prov) throws Throwable {
        LogCapture.info("Checking for streaming......");
        System.out.println("prov is " + prov);
        //
//       if(prov.equalsIgnoreCase(prov)){
//           System.out.println("inside prov.equalsIgnoreCase ");
//
//            String vObjB2BProvider=Constants.B2BOR.getProperty("B2B_Provider");
//            System.out.println("vObjB2BProvider is "+vObjB2BProvider);
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjB2BProvider, ""));
//
//            System.out.println("vObjB2BProvider is " + vObjB2BProvider);
//            Assert.assertEquals("PASS", Constants.key.verifyText(vObjB2BProvider, prov));
//
//            LogCapture.info("Streaming is happening successfully for "+prov);
//
//       }
        String providerList = Constants.B2BOR.getProperty("B2B_providerList");

        List<WebElement> ele = driver.findElements(By.xpath(providerList));
        for (WebElement e : ele) {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(e.getText().trim(), prov));
            LogCapture.info(e.getText().trim());
        }
        LogCapture.info("Streaming is happening for " + prov);

    }

    @And("^User should not see Provider \"([^\"]*)\" streaming$")
    public void userShouldNotSeeProviderStreaming(String prov) throws Throwable {
        LogCapture.info("Checking for streaming......");
        String providerList = Constants.B2BOR.getProperty("B2B_providerList");

        List<WebElement> ele = driver.findElements(By.xpath(providerList));
        for (WebElement e : ele) {
            //Assert.assertNotEquals(e.getText().trim(),prov);
            //Assert.assertNotEquals("PASS", Constants.key.VisibleConditionWait(e.getText().trim(),prov));
            LogCapture.info(e.getText().trim());
        }
        LogCapture.info("Streaming is not happening for " + prov);

    }


    @Then("^User enters Queue name \"([^\"]*)\" on message out$")
    public void userEntersQueueNameOnMessageOut(String QueueName) throws Throwable {
        key.pause("6", "");
        String CDQueueName = Constants.MessageOR.getProperty("vQueueName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CDQueueName, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(CDQueueName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CDQueueName, QueueName));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CDQueueName, "enter"));
        LogCapture.info("Checking for BACS Name......");
    }

    @And("^User goes to last page and selects first row$")
    public void userGoesToLastPageAndSelectsFirstRow() throws Throwable {
        key.pause("12", "");
        LogCapture.info("User sorting data as per created date from MessageOut Table......");
        String vObjCreated = Constants.MessageOR.getProperty("SortwithCreated");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCreated, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCreated, ""));
        Constants.key.pause("6", "");
        String vObjBNK_MessageOut_SelectRow = Constants.PaymentMonitoringOR.getProperty("BNK_MessageOut_SelectRow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNK_MessageOut_SelectRow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjBNK_MessageOut_SelectRow, ""));
        Constants.key.pause("4", "");
        LogCapture.info("User came to latest record of table......");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjBNK_MessageOut_SelectRow, "RightClick"));
    }

    @And("^user Right click the row and click to download files$")
    public void userRightClickTheRowAndClickToDownloadFiles() throws Throwable {
        String vMsgOut_Downloadfile = Constants.MessageOR.getProperty("MsgOut_Downloadfile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMsgOut_Downloadfile, ""));
        Assert.assertEquals("PASS", Constants.key.click(vMsgOut_Downloadfile, ""));
        LogCapture.info("Downloading of file started......");
    }

    @Then("^User verify the downloaded file$")
    public void userVerifyTheDownloadedFile() throws Throwable {
        Constants.key.pause("4", "");
        LogCapture.info("Downloaded......");
        String oSName = System.getProperty("os.name");
        String downloadPath = "";  //edge://settings/downloads
        if (oSName.toUpperCase().contains("WIN")) {
            downloadPath = System.getProperty("user.home") + "\\Downloads\\";
            LogCapture.info("File download path is " + downloadPath);
        } else {
            downloadPath = System.getProperty("user.dir") + "\\Downloads\\";
            LogCapture.info("File download path is " + downloadPath);
        }


        //String fileName="BACS20230310143009703231.txt";
        String MessageContent = Constants.key.VerifyDBDetails("UAT", "", "Fetch latest message out BACS file name");
        String fileName = MessageContent.split("/")[7].trim();
        Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));

    }

    @And("^User select (Currencies Direct|FCG|TorFX) from (Institution) dropdown$")
    public void userSelectCurrenciesDirectFromInstitutionDropdown(String MainMenu, String SubMenu) throws Throwable {
        key.pause("6", "");
        if (MainMenu.equalsIgnoreCase("Currencies Direct") && SubMenu.equalsIgnoreCase("Institution")) {
            LogCapture.info("User Click on Currencies direct......");

            String vObjectInstitution = Constants.MessageOR.getProperty("Institution_dropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectInstitution, ""));
            // Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vObjectB2BMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectInstitution, "Currencies Direct"));

        } else if (MainMenu.equalsIgnoreCase("FCG") && SubMenu.equalsIgnoreCase("Institution")) {
            LogCapture.info("User Click on FCG ......");

            String vObjectInstitution = Constants.MessageOR.getProperty("Institution_dropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectInstitution, "FCG"));


        } else if (MainMenu.equalsIgnoreCase("TorFX") && SubMenu.equalsIgnoreCase("Institution")) {
            LogCapture.info("User Click on TorFX ......");

            String vObjectInstitution = Constants.MessageOR.getProperty("Institution_dropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectInstitution, "TorFX"));

        }
    }

    @And("^User selects (Sent|Failed|Scheduled) from (status) dropdown and clicks on enter button$")
    public void userSelectsSentFromStatusDropdownAndClicksOnEnterButton(String MainMenu, String SubMenu) throws Throwable {
        key.pause("6", "");
        if (MainMenu.equalsIgnoreCase("Sent") && SubMenu.equalsIgnoreCase("status")) {
            LogCapture.info("User Click on Sent from status......");

            String vObjectStatus = Constants.MessageOR.getProperty("Status_dropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectStatus, ""));
            // Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vObjectB2BMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectStatus, "Sent"));

        } else if (MainMenu.equalsIgnoreCase("Failed") && SubMenu.equalsIgnoreCase("status")) {
            LogCapture.info("User Click on Failed from status ......");

            String vObjectStatus = Constants.MessageOR.getProperty("Status_dropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectStatus, "Failed"));

        } else if (MainMenu.equalsIgnoreCase("Scheduled") && SubMenu.equalsIgnoreCase("status")) {
            LogCapture.info("User Click on Scheduled from status ......");

            String vObjectStatus = Constants.MessageOR.getProperty("Status_dropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectStatus, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectStatus, "Scheduled"));
        }
    }

    @Then("^User search for BIC code (Currencies Direct|FCG|TorFX) and verify the BIC code of first row$")
    public void userSearchForBICCodeAndVerifyTheBICCodeOfFirstRow(String Menu) throws Throwable {
        key.pause("4", "");
        if (Menu.equalsIgnoreCase("Currencies Direct")) {

            String vObjBNK_MessageOut_senderBIC = Constants.PaymentMonitoringOR.getProperty("BNK_senderBIC");
            String vsenderBIC = Constants.key.getText(vObjBNK_MessageOut_senderBIC, "");
            if (vsenderBIC.contains("CDPNGB20AXXX")) {
                LogCapture.info("The sender and receiver BIC is correct for the selected bank" + vsenderBIC);
            }
            if (vsenderBIC.contains("CDPNGB2LAXXX")) {
                LogCapture.info("The sender and receiver BIC is correct for the selected bank " + vsenderBIC);
            } else {
                LogCapture.info("The sender and receiver BIC is WRONG for the selected bank");
                Assert.fail();
            }
        }
        if (Menu.equalsIgnoreCase("FCG")) {

            String vObjBNK_MessageOut_senderBIC = Constants.PaymentMonitoringOR.getProperty("BNK_senderBIC");
            String vsenderBIC = Constants.key.getText(vObjBNK_MessageOut_senderBIC, "");
            if (vsenderBIC.contains("CDPNGB20AXXX")) {
                LogCapture.info("The sender and receiver BIC is correct for the selected bank");
            }
            if (vsenderBIC.contains("CDPNGB2LAXXX")) {
                LogCapture.info("The sender and receiver BIC is correct for the selected bank " + vsenderBIC);
            } else {
                LogCapture.info("The sender and receiver BIC is WRONG for the selected bank");
                Assert.fail();
            }
        }
        if (Menu.equalsIgnoreCase("TorFX")) {

            String vObjBNK_MessageOut_senderBIC = Constants.PaymentMonitoringOR.getProperty("BNK_senderBIC");
            String vsenderBIC = Constants.key.getText(vObjBNK_MessageOut_senderBIC, "");
            if (vsenderBIC.contains("CDPNGB20ATOR")) {
                LogCapture.info("The sender and receiver BIC is correct for the selected bank");
            }
            if (vsenderBIC.contains("CDPNGB2LAXXX")) {
                LogCapture.info("The sender and receiver BIC is correct for the selected bank " + vsenderBIC);
            }
            if (vsenderBIC.contains("CDPNGB2LATOR")) {
                LogCapture.info("The sender and receiver BIC is correct for the selected bank " + vsenderBIC);
            } else {
                LogCapture.info("The sender and receiver BIC is WRONG for the selected bank");
                Assert.fail();
            }
        }
    }

    @Then("^User clicks on Reset Button List page$")
    public void userClicksOnResetButtonListPage() throws Throwable {
        key.pause("4", "");
        String vBanking_RejectPayment_Reset = Constants.PaymentMonitoringOR.getProperty("Banking_RejectPayment_Reset");
        Assert.assertEquals("PASS", Constants.key.click(vBanking_RejectPayment_Reset, ""));
    }

    @And("^User checks for payment reference with invalid BIC code$")
    public void userChecksForPaymentReferenceWithInvalidBICCode() throws Throwable {

        key.pause("5", "");
        String vObjPaymentRef_no = Constants.MessageOR.getProperty("PaymentRef_no");
        vPaymentRef_no = Constants.driver.findElement(By.xpath(vObjPaymentRef_no)).getText();
        System.out.println(vPaymentRef_no);


    }

    @Then("^User check the Error code for the given payment reference$")
    public void userCheckTheErrorCodeForTheGivenPaymentReference() throws Throwable {
        key.pause("4", "");
        String vSenderRef_No = Constants.MessageOR.getProperty("SenderRef_No");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSenderRef_No, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSenderRef_No, vPaymentRef_no));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSenderRef_No, "Enter"));
        key.pause("4", "");
        String vInvalidBICcode = Constants.MessageOR.getProperty("Bic_Invalid");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vInvalidBICcode, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vInvalidBICcode, "Sender BIC code Not supported"));
        LogCapture.info("Invalid BIC code verified ");
    }


    // CounterParty methods

    @And("^User Apply Filter on (TitanTransactionReference|Payment Reference|PaymentID)$")
    public void userApplyFilterOnTitanTransactionReference(String data) throws Throwable {
        LogCapture.info("User Apply Filter on " + data + " ......");
        key.pause("4", "");
        if (data.equalsIgnoreCase("TitanTransactionReference")) {

            String vEnterTitanTransactionReference = Constants.PaymentMonitoringOR.getProperty("enterTitanTransactionReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEnterTitanTransactionReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterTitanTransactionReference, TransactionReferenceNumber));
            Constants.key.KeyboardAction(vEnterTitanTransactionReference, "enter");
        } else if (data.equalsIgnoreCase("Payment Reference")) {

            String vPaymentReference = Constants.PaymentMonitoringOR.getProperty("PaymentReferencepath");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPaymentReference, Transaction_Reference));
            Constants.key.KeyboardAction(vPaymentReference, "enter");
        } else if (data.equalsIgnoreCase("PaymentID")) {

            String vPaymentReference = Constants.PaymentMonitoringOR.getProperty("PaymentIDsearch");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPaymentReference, Constants.PaymentID));
            Constants.key.KeyboardAction(vPaymentReference, "enter");
        }
    }


    @And("^User click on reset filter and wait to generate a instructions$")
    public void userClickOnResetFilterAndWaitToGenerateAInstructions() throws Exception {
        String vResetFilter = Constants.PaymentMonitoringOR.getProperty("ResetFilter");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vResetFilter, ""));
        Assert.assertEquals("PASS", Constants.key.click(vResetFilter, ""));
        key.pause("20", "");
        LogCapture.info("Waiting reflecting lead on UI for 20 sec....");
        //Constants.driver.navigate().refresh();

    }

    @And("^User Verify TitanTransactionReference is present in payment entries with \"([^\"]*)\"\"([^\"]*)\"$")
    public void userVerifyTitanTransactionReferenceIsPresentInPaymentEntries(String Currency, String BankName) throws Exception {
//        key.pause("11", "");
        LogCapture.info("Verify TitanTransactionReference of latest instruction ");
        String vTitanTransactionReference = Constants.PaymentMonitoringOR.getProperty("TitanTransactionReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTitanTransactionReference, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vTitanTransactionReference, TransactionReferenceNumber));
        LogCapture.info("Verify PaymentOutCurrency of latest instruction ");
        String vPaymentOutCurrency = Constants.PaymentMonitoringOR.getProperty("PaymentOutCurrency");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentOutCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentOutCurrency, Currency));
        LogCapture.info("Verify PaymentOutAmount of latest instruction ");
        String vPaymentOutAmount = Constants.PaymentMonitoringOR.getProperty("PaymentOutAmount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentOutAmount, ""));
        String ActualAmount = key.getText(vPaymentOutAmount, "").replace(",", "");
        Assert.assertEquals("PASS", Constants.key.VerifySubstring(ActualAmount, Amount), "");
        LogCapture.info("Verify PaymentOut Bank Name of latest instruction ");
        String vPaymentOutBankName = Constants.PaymentMonitoringOR.getProperty("PaymentOutBankName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentOutBankName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentOutBankName, BankName));

    }

    @And("^User fetches the Latest TitanTransactionReference using ClientAccountKey \"([^\"]*)\"\"([^\"]*)\" and (Current Date|MoreThan 10 Date|within 10 Days)$")
    public void userFetchesTheLatestTitanTransactionReferenceUsingClientAccountKey(String ClientAccountKey, String Environment, String Data) throws Throwable {
        String TransactionReference = Constants.key.VerifyDBDetails(Environment, ClientAccountKey, "Fetch Latest Payment Titan Transaction Reference Number");
        LogCapture.info("Latest Trade Account Number : " + TransactionReference);
        String vFirst = TransactionReference.split("-")[0].trim();
        int vLast = Integer.parseInt(TransactionReference.split("-")[1].trim()) + 1;
        String vLastest = Integer.toString(vLast);
        String newTransactionReference = vFirst + "-" + vLastest;
        Constants.TransactionReferenceNumber = newTransactionReference;
        DynamicValue.put("<TransactionReferenceNumber>", TransactionReferenceNumber);
        LogCapture.info("New Transaction Reference Number : " + newTransactionReference);
        DynamicValue.put("<ClientAccountKey>", ClientAccountKey);
        if (Data.equalsIgnoreCase("Current Date")) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            DynamicValue.put("<currentDate>", currentDate);
        } else if (Data.equalsIgnoreCase("MoreThan 10 Date")) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime morethan10Days = now.plusDays(11);
            String currentDate = dtf.format(morethan10Days);
            DynamicValue.put("<currentDate>", currentDate);
        } else if (Data.equalsIgnoreCase("within 10 Days")) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime within10Days = now.plusDays(10);
            String currentDate = dtf.format(within10Days);
            DynamicValue.put("<currentDate>", currentDate);
        }
    }

    @When("^User Select (normal|Large|OneApproval|TwoApproval|ThreeApproval|OneApprovals) payment out Amount$")
    public void userSelectNormalPaymentOutAmount(String data) {
        if (data.equalsIgnoreCase("normal")) {
            RandomNumber = RandomStringUtils.randomNumeric(2);
        } else if (data.equalsIgnoreCase("Large")) {
            RandomNumber = RandomStringUtils.randomNumeric(5);
        } else if (data.equalsIgnoreCase("OneApproval")) {
            RandomNumber = RandomStringUtils.randomNumeric(6);
        } else if (data.equalsIgnoreCase("OneApprovals")) {
            RandomNumber = RandomStringUtils.randomNumeric(4);
        } else if (data.equalsIgnoreCase("TwoApproval")) {
            RandomNumber = RandomStringUtils.randomNumeric(6);
        } else if (data.equalsIgnoreCase("ThreeApproval")) {
            RandomNumber = RandomStringUtils.randomNumeric(7);
        }
        RandomNumber = RandomNumber.startsWith("0") ? RandomNumber.substring(1) : RandomNumber;
// double newAmount=Double.parseDouble(RandomNumber);
        String newAmount = RandomNumber + ".00";
        LogCapture.info("New Trade Amount : " + newAmount);
        Constants.Amount = newAmount;
        DynamicValue.put("<Amount>", Amount);
    }


    @And("^User select Upload file (AIP|CDSA|E4F) from the dropdown$")
    public void userSelectUploadFileFromTheDropdown(String Menu) throws Throwable {
        key.pause("4", "");
        if (Menu.equalsIgnoreCase("AIP")) {
            LogCapture.info("User Click on AIP Manual PSR Upload......");

            String vObjectPSRFileUpload = Constants.MessageOR.getProperty("PSRFileUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectPSRFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectPSRFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectPSRFileUpload, "AIP Manual PSR Upload"));
            // Assert.assertEquals("PASS",Constants.key.KeyboardAction("","enter"));

        } else if (Menu.equalsIgnoreCase("CDSA")) {
            LogCapture.info("User Click on CDSA Payment Reconciliation ......");

            String vObjectPSRFileUpload = Constants.MessageOR.getProperty("PSRFileUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectPSRFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectPSRFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectPSRFileUpload, "CDSA Payment Reconciliation"));


        } else if (Menu.equalsIgnoreCase("E4F")) {
            LogCapture.info("User Click on E4F Payment Reconciliation ......");

            String vObjectPSRFileUpload = Constants.MessageOR.getProperty("PSRFileUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectPSRFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectPSRFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectPSRFileUpload, "E4F Payment Reconciliation"));


        }
    }

    @Then("^User take the Payment Reference and Check the routing rule (Local Transfer|wire Transfer|URGP|SEPA) of the entry from Audit trail$")
    public void userTakeThePaymentReferenceAndCheckTheRoutingRuleOfTheEntryFromAuditTrail(String Menu) throws Throwable {
        key.pause("5", "");
        String vObjPaymentRef_no = Constants.MessageOR.getProperty("PaymentRef_no");
        vPaymentRef_no = Constants.driver.findElement(By.xpath(vObjPaymentRef_no)).getText();
        //System.out.println(vPaymentRef_no);
        LogCapture.info("Taking the Reference No ......" + vPaymentRef_no);

        String vFirstEntry = Constants.MessageOR.getProperty("FirstEntry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vFirstEntry, "RightClick"));
        String VObjAuditTrail = Constants.MessageOR.getProperty("AuditTrail");
        Assert.assertEquals("PASS", Constants.key.click(VObjAuditTrail, ""));
        key.pause("5", "");
        if (Menu.equalsIgnoreCase("Local Transfer")) {
            String vObjRoutingRuleNo = Constants.MessageOR.getProperty("RoutingRuleNo101");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRoutingRuleNo, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRoutingRuleNo, "OneHundredOne"));
            LogCapture.info("Routing rule verified ......");

        }
        if (Menu.equalsIgnoreCase("wire Transfer")) {
            String vObjRoutingRuleNo = Constants.MessageOR.getProperty("RoutingRuleNo100");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRoutingRuleNo, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRoutingRuleNo, "OneHundred"));
            LogCapture.info("Routing rule verified ......");

        }
        if (Menu.equalsIgnoreCase("URGP")) {
            String vObjRoutingRuleNo = Constants.MessageOR.getProperty("RoutingRuleNo20");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRoutingRuleNo, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRoutingRuleNo, "Twenty"));
            LogCapture.info("Routing rule verified ......");

        }
        if (Menu.equalsIgnoreCase("SEPA")) {
            String vObjRoutingRuleNo = Constants.MessageOR.getProperty("RoutingRuleNo21");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRoutingRuleNo, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRoutingRuleNo, "TwentyOne"));
            LogCapture.info("Routing rule verified ......");

        }
        String vObj_AuditTrial_close = Constants.PaymentMonitoringOR.getProperty("BNK_audit_trial_close");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObj_AuditTrial_close, ""));
    }

    @And("^User approves the payment from approval Queue$")
    public void userApprovesThePaymentFromApprovalQueue() throws Throwable {

        key.pause("4", "");
        String vPayAprovPR = Constants.MessageOR.getProperty("PayAprovPR");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPayAprovPR, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPayAprovPR, vPaymentRef_no));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPayAprovPR, "Enter"));
        String vFirstEntry = Constants.MessageOR.getProperty("FirstEntry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vFirstEntry, "RightClick"));
        String vApprovePayment = Constants.MessageOR.getProperty("ApprovePayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vApprovePayment, ""));
        //Assert.assertEquals("PASS",Constants.key.click(vApprovePayment,""));
        Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vApprovePayment, ""));
        LogCapture.info("User Approved the payment from payment approval queue......");

    }

    @And("^User goes to last page and selects latest record$")
    public void userGoesToLastPageAndSelectsLatestRecord() throws Throwable {
        key.pause("7", "");
        String VobjLastpage = Constants.MessageOR.getProperty("Lastpage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VobjLastpage, ""));
        Assert.assertEquals("PASS", Constants.key.click(VobjLastpage, ""));
        key.pause("7", "");
        String vLast_Record = Constants.MessageOR.getProperty("Last_Record");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vLast_Record, ""));
        Assert.assertEquals("PASS", Constants.key.click(vLast_Record, ""));
        LogCapture.info("User came to last page and selecte last record ......");
    }

    @Then("^User verify the payment reference with record$")
    public void userVerifyThePaymentReferenceWithRecord() throws Throwable {
        key.pause("5", "");
        String vObjPaymentref = "//td[text()='" + vPaymentRef_no + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentref, ""));
        LogCapture.info("User verified the for Barclays PAIN payment......");
    }

    @And("^User get the successful alert \"([^\"]*)\" message$")
    public void userGetTheSuccessfulAlertMessage(String Alert) throws Throwable {
        LogCapture.info("User see alert message respective page......");

        String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
        System.out.println("Value is " + Alert);
        System.out.println("Alert message is " + alertMessage);
        Assert.assertTrue(alertMessage.contains(Alert));

    }

    @And("^Do \"([^\"]*)\" DB verification and get (StatementLineID|UpdateUKHoliday_FileUploadError|UpdateUKHoliday_FileUploadSucess)$")
    public void doDBVerificationAndGetStatementLineID(String Environment, String data) throws Exception {
        if (data.equalsIgnoreCase("StatementLineID")) {
            String MessageInId = MessageInIdMap.get("MessageInId for 53");
            if (MessageInId == null) {
                Object firstKey = MessageInIdMap.keySet().toArray()[0];
                MessageInId = MessageInIdMap.get(firstKey);
            }
            if (PTData != null) {
                key.pause("50", "");
                LogCapture.info("waiting for 50 seconds");
            } else {
                key.pause("5", "");
                LogCapture.info("waiting for 5 seconds");
            }
            key.pause("10", "");
            String StatementLine = Constants.key.VerifyDBDetails(Environment, MessageInId, "Find the StatementLineID");
            Constants.StatementLineID = StatementLine;
            LogCapture.info("StatementLineID : " + StatementLineID);
        } else if (data.equalsIgnoreCase("UpdateUKHoliday_FileUploadError")) {
            LogCapture.info("Update Query For UK Holiday");
            Date date = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = formatter.format(date);
            Constants.key.VerifyDBDetails(Environment, strDate, "User Hits Holiday Update Query Error");
        } else if (data.equalsIgnoreCase("UpdateUKHoliday_FileUploadSucess")) {
            LogCapture.info("Update Query For UK Holiday");
            Constants.key.VerifyDBDetails(Environment, "", "User Hits Holiday Update Query Sucess");
        }
    }

    @And("^User gets MSL_ID from \"([^\"]*)\" DB$")
    public void userGetsMSL_IDFromDB(String Environment) throws Exception {
        String MSL = Constants.key.VerifyDBDetails(Environment, StatementLineID, "Find the MSL_ID");
        Constants.EODMSL_ID = MSL;
        Constants.Kafka_ID = MSL;
        LogCapture.info("MSL_ID : " + EODMSL_ID);
    }

    @And("^User Verify the (Region|Payment Method|ClientReference) \"([^\"]*)\" from \"([^\"]*)\" DB$")
    public void userVerifyTheRegionFromDB(String Menu, String Data, String Environment) throws Throwable {
        String Event = Constants.key.VerifyDBDetails(Environment, Kafka_ID, Menu);
        LogCapture.info(Menu + "is : " + Event);
        Assert.assertTrue(Event.contains(Data));
    }

    @And("^user verify MSL_ID on Balance Entry Page\"([^\"]*)\"$")
    public void userVerifyMSL_IDOnBalanceEntryPage(String BankName) throws Exception {
        if (Kafka_ID == null) {
            LogCapture.info("MSL_ID is null ");
            Kafka_ID = EODMSL_ID;
        }
        LogCapture.info("Verify MSL_ID present on UI ");
        String vMSL_ID = Constants.BankingOR.getProperty("BNK_MSL_ID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMSL_ID, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vMSL_ID, Kafka_ID));
        key.pause("2", "");
        Constants.key.KeyboardAction(vMSL_ID, "enter");
        LogCapture.info("MSL_ID entered at Search box ");
        key.pause("7", "");
        String vVerify_MSL_ID = Constants.BankingOR.getProperty("verify_MSL_ID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vVerify_MSL_ID, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vVerify_MSL_ID, Kafka_ID));
        LogCapture.info("Verified MSL_ID present on UI is " + Kafka_ID);
//        String vPaymentOutCurrency=Constants.PaymentMonitoringOR.getProperty("PaymentOutCurrency");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentOutCurrency, ""));
//        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentOutCurrency, Currency));
//        LogCapture.info("Verify PaymentOutAmount of latest instruction ");
        String vPaymentInAmount = Constants.BankingOR.getProperty("PaymentInAmount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentInAmount, ""));
        LogCapture.info("Payment In amount of latest instruction " + PaymentInAmount);
        String ActualAmount = key.getText(vPaymentInAmount, "").replace(",", "");
//        Assert.assertEquals("PASS", Constants.key.VerifySubstring(ActualAmount,PaymentInAmount),"");
        Assert.assertTrue(ActualAmount.equals(PaymentInAmount));
        LogCapture.info("Verify PaymentIn Bank Name of latest instruction ");
        String vPaymentInBankName = Constants.BankingOR.getProperty("PaymentInBankName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentInBankName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentInBankName, BankName));

    }


    @When("^Update \"([^\"]*)\" xml file for \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void updateXmlFileFor(String FileType, String Bank, String AccountNumber, String CdtDbtInd, String Currency) throws ParserConfigurationException, IOException, SAXException, TransformerException, InterruptedException {

        File NewCamtFile = new File("Files/" + Bank + "/" + NewFileName);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  // Using XML classes to modify file content
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(NewCamtFile);
        Constants.doc1 = doc;
        LogCapture.info(" Selected Document/File for updates is " + NewFileName);
//        DateTimeFormatter dtf=DateTimeFormatter.ISO_LOCAL_DATE;
//        DateTimeFormatter dtf1=DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        double InAmount = 0;
        if (Amount == null) {
            String RandomNumber = RandomStringUtils.randomNumeric(3);
            InAmount = Double.parseDouble(RandomNumber);
            LogCapture.info("New Trade Amount : " + InAmount);
        } else {
            InAmount = Double.parseDouble(Amount);
        }
//            String RandomNumber = RandomStringUtils.randomNumeric(3);
//            double InAmount = Double.parseDouble(RandomNumber);
//            LogCapture.info("New Trade Amount : " + InAmount);
        if (Transaction_Reference_MessageOut != null || Transaction_Reference != null) {
            Constants.key.updateXmlFile("MsgId", Transaction_Reference_MessageOut);
            Constants.key.updateXmlFile("AcctSvcrRef", Transaction_Reference_MessageOut);
            Constants.key.updateXmlFile("EndToEndId", Transaction_Reference);
            Constants.key.updateXmlParentChild("Ntfctn", "Id", Transaction_Reference_MessageOut);
            Constants.key.updateXmlParentChild("Stmt", "Id", Transaction_Reference_MessageOut);
            Constants.key.updateXmlParentChild("Rpt", "Id", Transaction_Reference_MessageOut);
        }
        Constants.key.updateXmlFile("CdtDbtInd", "CdtDbtInd");
        Constants.key.updateXmlFile("CreDtTm", String.valueOf(now));  //Updating tag (CretTm) of xml files using new value
        Constants.key.updateXmlFile("DtTm", String.valueOf(now));
        Constants.key.updateXmlParentChild("Othr", "Id", AccountNumber);
        if (FileType.equalsIgnoreCase("camt.053.") || FileType.equalsIgnoreCase("camt.053ALLEN.") || FileType.equalsIgnoreCase("camt.053JPM1.") || FileType.equalsIgnoreCase("camt.053JPM2.") || FileType.equalsIgnoreCase("camt.053TREAS.") || FileType.equalsIgnoreCase("camt.053Slash.") || FileType.equalsIgnoreCase("camt.053ROFNoBankReference") || FileType.equalsIgnoreCase("camt.053ISO.") || FileType.equalsIgnoreCase("camt.053ROF.")) {
            Constants.key.updateXmlParentChild("Dt", "Dt", currentDate);
            Constants.key.updateXmlParentChild("BookgDt", "Dt", currentDate);
            Constants.key.updateXmlParentChild("ValDt", "Dt", currentDate);
        } else {
            Constants.key.updateXmlFile("Dt", currentDate);
        }
//        Constants.key.updateXmlFile("Amt",String.valueOf(InAmount));

        double sum = 0;
//        NodeList nodeList=doc.getElementsByTagName("Amt");
//        LogCapture.info("Number of Amt fields are " + nodeList.getLength());
//        for (int j=0; j < nodeList.getLength(); j++) {
//            Node node=nodeList.item(j);
//            node.setTextContent(String.valueOf(InAmount));
//            LogCapture.info("Value ot Amt(" + j + ") is " + InAmount);
//            sum=sum + InAmount;
//            InAmount=InAmount + 1.00;
//
//        }
        double lastAmount = 0;                           //lastAmount = Amount used in last transaction


        if (FileType.equalsIgnoreCase("camt.05.2.") || FileType.equalsIgnoreCase("camt.052ROF.") || FileType.equalsIgnoreCase("camt.052ISO.") || FileType.equalsIgnoreCase("camt.053ISO.")) {
            NodeList nodeList = doc.getElementsByTagName("Amt");
            LogCapture.info("Number of Amt fields are " + nodeList.getLength());
            for (int j = 0; j < nodeList.getLength(); j++) {
                Node node = nodeList.item(j);
//                if (firstPayment == -1) {
//                    // Store the first payment value globally
//                    firstPayment = InAmount;
//                }
                node.setTextContent(String.valueOf(InAmount));
                LogCapture.info("Value ot Amt(" + j + ") is " + InAmount);
                sum = sum + InAmount;
                InAmount = InAmount + 1.00;

            }
            lastAmount = InAmount - 1;
//            for (int j = 0; j < nodeList.getLength(); j++) {
//                Node node = nodeList.item(j);
//                // Assuming `InAmount` is defined earlier
//                amountsList.add(InAmount);
//                node.setTextContent(String.valueOf(InAmount));
//                LogCapture.info("Value of Amt(" + j + ") is " + InAmount);
//                InAmount = InAmount + 1.00;
//            }
//// Use the data from amountsList if it's not empty
//            if (!amountsList.isEmpty()) {
//                for (Double amount : amountsList) {
//                    sum = sum + amount;
//                }
//                lastAmount = amountsList.get(amountsList.size() - 1);
//            }
        } else {
            LogCapture.info("payment in amount is " + PaymentInAmount);
            if (PaymentInAmount.isEmpty()) {
                Constants.key.updateXmlFile("Amt", String.valueOf(InAmount));
            } else {
                InAmount = Double.parseDouble(PaymentInAmount);
                Constants.key.updateXmlFile("Amt", String.valueOf(InAmount));
            }

            lastAmount = InAmount;
        }
        // if you want to change AddtlNtryInf for single transaction then use below commented lines
//         if specific AddtlNtryInf need to change at config AddtlNtryInf
//        if (FileType.equalsIgnoreCase("camt.052REMI.")||FileType.equalsIgnoreCase("camt.053REMI.")){
//            String AddtlNtryInf = Constants.CONFIG.getProperty("AddtlNtryInf");
//            Constants.key.updateXmlFile("AddtlNtryInf", AddtlNtryInf);
//        }
        Constants.key.updateXmlFile("CdtDbtInd", CdtDbtInd);
        Constants.key.updateXmlFile("Sum", String.valueOf(sum));
        Constants.key.updateCurrencyXmlFile("Amt", Currency);
        //PSR file updates
        if (Transaction_Reference_MessageOut == null) {
            Transaction_Reference_MessageOut = "PET503825125";
        }
        if (Transaction_Reference == null) {
            Transaction_Reference = "PET503825125";
        }
        Constants.key.updateXmlFile("MsgId", Transaction_Reference_MessageOut);
        Constants.key.updateXmlFile("OrgnlMsgId", Transaction_Reference_MessageOut);
        Constants.key.updateXmlFile("OrgnlPmtInfId", Transaction_Reference);
        Constants.key.updateXmlFile("OrgnlEndToEndId", Transaction_Reference);
        Constants.key.updateXmlFile("OrgnlCtrlSum", Amount);
        Constants.key.updateXmlFile("ReqdExctnDt", currentDate);

        if (FileType.equalsIgnoreCase("camt.052ISO.") || FileType.equalsIgnoreCase("camt.053ISO.")) {
            RandomNumber = RandomStringUtils.randomNumeric(9);
            RandomNumber = RandomNumber.startsWith("0") ? RandomNumber.substring(1) : RandomNumber;
            if (BankRef == null) {
                BankRef = "PET" + RandomNumber;
            }
            Constants.key.updateXmlFile("AcctSvcrRef", BankRef);
            PTData = FileType;
        }

        LogCapture.info("Required Tags are modified for file: " + NewFileName);

        TransformerFactory transformerFactory = TransformerFactory.newInstance(); //Updated information send to local NewCamtFile
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc1);
        StreamResult result = new StreamResult(NewCamtFile);
        transformer.transform(source, result);
        LogCapture.info(" Updates are saved in document/file: " + NewFileName);

        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        Constants.PaymentInAmount = decimalFormat.format((lastAmount));
        LogCapture.info("value of Payment In Amount at last transaction is: " + PaymentInAmount);
    }

    @When("^Update BMO PaymentIn file$")
    public void updateBMOPaymentInFile() throws ParserConfigurationException, IOException, SAXException {
        String path = "Files/BMO/" + NewFileName;
        LogCapture.info("New file name with paths is: " + path);
        Constants.filePath = path;

        Constants.key.modifyFile(filePath, dateReplace, currentDate);
        Constants.key.modifyFile(filePath, oldAmountStarting, newAmount);
        String lastAmount = newAmount + "9";
        double Amount = Integer.parseInt(lastAmount);
        double valueOfLastAmount = Amount / 100;
        Constants.PaymentInAmount = String.valueOf(valueOfLastAmount);
    }


    @And("^Do \"([^\"]*)\" DB verification and get ConfirmationPaymentAdvice ID for CAMT54$")
    public void doDBVerificationAndGetConfirmationPaymentAdviceIDForCAMT54(String Environment) throws Exception {
        String MessageInId = MessageInIdMap.get("MessageInId for 54");
        String PaymentConfirmation = Constants.key.VerifyDBDetails(Environment, MessageInId, "ConfirmationPaymentAdvice ID");
        Constants.ConfirmationID = PaymentConfirmation;
        LogCapture.info("Payment Confirmation ID : " + ConfirmationID);
    }

    @And("^User \"([^\"]*)\" gets MSL_ID from DB for CAMT54$")
    public void userGetsMSL_IDFromDBForCAMT54(String Environment) throws Exception {
        String MSL = Constants.key.VerifyDBDetails(Environment, ConfirmationID, "Find the MSL_ID for CAMT54");
        Constants.MSL_ID = MSL;
        Constants.Kafka_ID = MSL;
        LogCapture.info("MSL_ID : " + MSL_ID);
    }

    @And("^Do \"([^\"]*)\" DB verification and get IntradayStatementLineID for Indraday$")
    public void doDBVerificationAndGetIntraStatementLineIDForIndraday(String Environment) throws Exception {
        String MessageInId = MessageInIdMap.get("MessageInId for 52");
        if (MessageInId == null) {
            Object firstKey = MessageInIdMap.keySet().toArray()[0];
            MessageInId = MessageInIdMap.get(firstKey);
        }
        if (PTData != null) {
            key.pause("50", "");
            LogCapture.info("waiting for 50 seconds");
        } else {
            key.pause("5", "");
            LogCapture.info("waiting for 5 seconds");
        }
        Constants.IntradayStatementLineID = Constants.key.VerifyDBDetails(Environment, MessageInId, "Find the StatementLineID for Indraday");
        LogCapture.info("IntradayStatementLineID : " + IntradayStatementLineID);
//        HashMap<String,List<String>> remitter=new HashMap();
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo1"),List.of("20608830513822", "BROWN S"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo2"),List.of("NULL", "D+WOJC"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo3"),List.of("ES4721006073101300205825", "SIGNLED IMAGEN S.L. "));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo4"),List.of("20821330680435", "HUGHES B+K"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo5"),List.of("IE93IPBS99072625410215", ""));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo6"),List.of("IE93IPBS99072625410215", "HIGH TECH DEV LIMITED"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo7"),List.of("IE93IPBS99072625410215", "ADRIAN CHARLES LINDE CASTLEHILL CRESCENT"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo8"),List.of("NULL",""));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo9"),List.of("NULL", ""));
//        Assert.assertEquals("PASS",remitter.equals(ActualRemitterMap));

    }


    @And("^User gets MSL_ID for Indraday from \"([^\"]*)\" DB$")
    public void userGetsMSL_IDForIndradayFromDB(String Environment) throws Exception {
        String MSL = Constants.key.VerifyDBDetails(Environment, IntradayStatementLineID, "Find the MSL_ID for Indraday");
        Constants.IndradayMSL_ID = MSL;
        Constants.Kafka_ID = MSL;
        LogCapture.info("MSL_ID : " + IndradayMSL_ID);
    }

    @When("^Change the \"([^\"]*)\" file name for \"([^\"]*)\"\"([^\"]*)\"$")
    public void changeTheFileNameFor(String FileType, String Bank, String AccountNumber) throws Exception {
        key.pause("60", "");
        Constants.Bank = Bank;
        Constants.FileType = FileType;
        File Rename = Constants.key.RenameCAMTFile(FileType, Bank, AccountNumber);
        String newFileName = Rename.getName();
        Constants.NewFileName = newFileName;
        LogCapture.info(Rename.getName());

    }

    @And("^User selects institution and Bank Account Legal Entity$")
    public void userSelectsInstitutionAndBankAccountLegalEntity() throws Exception {
        key.pause("5", "");
        LogCapture.info("User Click on institution ......");
        String vObjectInstitution = BankingOR.getProperty("BNK_Institution");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectInstitution, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectInstitution, "TorFX"));
        LogCapture.info("User selected TorFX ......");

        LogCapture.info("User Click on bank Account Legal Entity ......");
        String vSelectBankAccLegalEntity = Constants.BankingOR.getProperty("BNK_bankAccLegalEntity");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectBankAccLegalEntity, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSelectBankAccLegalEntity, "TORGB"));
        LogCapture.info("User selected bank Account Legal Entity as TORGB ......");
        String vSelectBNK_LE = Constants.BankingOR.getProperty("BNK_LE");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectBNK_LE, ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectBNK_LE, ""));
        LogCapture.info("User selected on TORGB as a legal Entity......");
    }

    @And("^User selects\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userSelects(String Bank, String Branch, String LogicalGroup, String AccountType) throws Throwable {
        LogCapture.info("User Click on Bank ......");
        String vObjectBank = BankingOR.getProperty("BNK_Bank");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectBank, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectBank, Bank));
        LogCapture.info("User Clicked on Barclays ......");


        LogCapture.info("User Click on Branch ......");
        String vObjectBranch = BankingOR.getProperty("BNK_Branch");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectBranch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectBranch, Branch));
        LogCapture.info("User Clicked on " + Branch + " ......");

        LogCapture.info("User Click on LogicalGroup ......");
        String vObjectLogicalGroup = BankingOR.getProperty("BNK_LogicalGroup");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectLogicalGroup, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectLogicalGroup, LogicalGroup));
        LogCapture.info("User Clicked on " + LogicalGroup + " ......");

        LogCapture.info("User Click on AccountType ......");
        String vObjectAccountType = BankingOR.getProperty("BNK_AccountType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectAccountType, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectAccountType, AccountType));
        LogCapture.info("User Clicked on " + AccountType + " ......");

    }

    @And("^user click on Add bank account Button$")
    public void userClickOnAddBankAccountButton() throws Exception {
        LogCapture.info("User Click on Add bank account Button ......");
        String vObjectAddBankAccountButton = BankingOR.getProperty("BNK_AddBankAccount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectAddBankAccountButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjectAddBankAccountButton, ""));
    }

    @And("^User enters \"([^\"]*)\"\"([^\"]*)\" AccountNumber bBAN iBAN \"([^\"]*)\"\"([^\"]*)\"$")
    public void userEntersAccountNumberBBANIBAN(String BankAccountName, String AccountIdentifier, String country, String currency) throws Throwable {
        LogCapture.info("User Provides BankAccountName  ......");
        String vObjectBanckAccountName = BankingOR.getProperty("BNK_BanckAccountName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectBanckAccountName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectBanckAccountName, BankAccountName));
        LogCapture.info("User Provides AccountIdentifier  ......");
        String vObjectAccountIdentifier = BankingOR.getProperty("BNK_AccountIdentifier");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectAccountIdentifier, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectAccountIdentifier, AccountIdentifier));
        LogCapture.info("User Provides AccountIdentifier  ......");
        String vObjectAccountNumber = BankingOR.getProperty("BNK_AccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectAccountNumber, AccountIdentifier));
        LogCapture.info("User Provides bBAN  ......");
        String vObjectbBAN = BankingOR.getProperty("BNK_bBAN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectbBAN, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectbBAN, AccountIdentifier));
        LogCapture.info("User Provides iBAN  ......");
        String vObjectiBAN = BankingOR.getProperty("BNK_iBAN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectiBAN, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectiBAN, AccountIdentifier));
        LogCapture.info("User Provides country  ......");
        String vObjectCountry = BankingOR.getProperty("BNK_countryBA");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectCountry, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectCountry, country));
        LogCapture.info("User Provides currency  ......");
        String vObjecCurrency = BankingOR.getProperty("BNK_Currency");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjecCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjecCurrency, currency));
        LogCapture.info("User click on Add button  ......");
        String vObjecAdd = BankingOR.getProperty("BNK_ADD");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjecAdd, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjecAdd, ""));
    }

    @Then("^User search for Message No in Failed Payment out$")
    public void userSearchForMessageNoInFailedPaymentOut() throws Throwable {
        key.pause("7", "");
        String vObjMessage_No = Constants.MessageOR.getProperty("Message_No");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMessage_No, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjMessage_No, "PAIN.001"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjMessage_No, "Enter"));

    }

    @Then("^User Take the Payment Reference then check load panel and change the payment type (MT103|PAIN.001) and then click on submit$")
    public void userTakeThePaymentReferenceThenCheckLoadPanelAndChangeThePaymentTypeAndThenClickOnSubmit(String Menu) throws Throwable {
        key.pause("5", "");

        if (Menu.equalsIgnoreCase("MT103")) {
            String vObjPaymentType = Constants.MessageOR.getProperty("PaymentType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjPaymentType, "MT103"));
        }
        if (Menu.equalsIgnoreCase("PAIN.001")) {
            String vObjPaymentType = Constants.MessageOR.getProperty("PaymentType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectByValue(vObjPaymentType, "PAIN.001"));
        }
        LogCapture.info("User change the payment type......");
        key.pause("6", "");
        String vObjSubmitButton = Constants.MessageOR.getProperty("FPQSubmitButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSubmitButton, ""));
        Alert alert = driver.switchTo().alert();
        alert.accept();
        LogCapture.info("User Submited Successfully......");
    }

    @Then("^User Search the Payment Reference and verify the Payment type$")
    public void userSearchThePaymentReferenceAndVerifyThePaymentType() throws Throwable {
        key.pause("4", "");
        String vPayAprovPR = Constants.MessageOR.getProperty("PayAprovPR");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPayAprovPR, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPayAprovPR, vPaymentRef_no));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPayAprovPR, "Enter"));

        String vObjPayTyp = Constants.MessageOR.getProperty("PayTyp");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjPayTyp, "MT"));
        LogCapture.info("Payment type as MT verified successfully.....");
    }

    @And("^User Select First Row from (FPO|Orgcurrency|CounterParty) Table in (Message Out|RFQ) Page$")
    public void userSelectFirstRowFromFPOTableInMessageOutPage(String Data, String Menu) throws Throwable {
        key.pause("7", "");
        if (Data.equalsIgnoreCase("FPO") && Menu.equalsIgnoreCase("Message Out")) {
            String vObjPaymentRef_no = Constants.MessageOR.getProperty("PaymentRef_no");
            vPaymentRef_no = Constants.driver.findElement(By.xpath(vObjPaymentRef_no)).getText();
            LogCapture.info("Taking the Reference No ......" + vPaymentRef_no);

            String vFirstEntry = Constants.MessageOR.getProperty("FirstEntry");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirstEntry, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFirstEntry, ""));
        }
        if (Data.equalsIgnoreCase("Orgcurrency") || Data.equalsIgnoreCase("CounterParty") && Menu.equalsIgnoreCase("RFQ")) {
            String vObjSelectFirstrow = Constants.RFQOR.getProperty("SelectFirstrow");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectFirstrow, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectFirstrow, ""));
        }
    }


    @Then("^User check the state and status and Takes the payment reference$")
    public void userCheckTheStateAndStatusAndTakesThePaymentReference() throws Throwable {
        key.pause("4", "");
        String vCheckState = Constants.MessageOR.getProperty("CheckState");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckState, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vCheckState, "Failed"));
        LogCapture.info("User verified State......");
        String vCheckStatus = Constants.MessageOR.getProperty("CheckStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckStatus, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vCheckStatus, "Rejected"));
        LogCapture.info("User verified status......");
        String vObjPaymentRef_no = Constants.MessageOR.getProperty("PaymentRef_no");
        vPaymentRef_no = Constants.driver.findElement(By.xpath(vObjPaymentRef_no)).getText();
        LogCapture.info("Taking the Reference No ......" + vPaymentRef_no);
    }

    @Then("^User search for Payment reference and Verify the Error discription$")
    public void userSearchForPaymentReferenceAndVerifyTheErrorDiscription() throws Throwable {
        key.pause("4", "");
        String vSenderRef_No = Constants.MessageOR.getProperty("SenderRef_No");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSenderRef_No, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSenderRef_No, vPaymentRef_no));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSenderRef_No, "Enter"));

        key.pause("4", "");
        String vErrorDisc = Constants.MessageOR.getProperty("ErrorDisc");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vErrorDisc, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vErrorDisc, "BIC length is incorrect"));
    }

    @And("^User select B2B_enabled checkbox$")
    public void userSelectBB_enabledCheckbox() throws Throwable {
        key.pause("4", "");
        String vRFQ_B2B_Enabled = Constants.RFQOR.getProperty("RFQ_B2B_Enabled");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRFQ_B2B_Enabled, ""));
        Assert.assertEquals("PASS", Constants.key.click(vRFQ_B2B_Enabled, ""));
    }

    @Then("^Get the order id to verify in TradingDashBoardReport$")
    public void getTheOrderIdToVerifyInTradingDashBoardReport() throws Throwable {
        key.pause("7", "");
        String BuyAmtDate = Constants.RFQOR.getProperty("B2BOrderID");
        vPaymentRef_no = Constants.driver.findElement(By.xpath(BuyAmtDate)).getText();
        LogCapture.info("Taking the Order ID ......" + vPaymentRef_no);
    }

    @And("^User search for order id and verify the Buy amount \"([^\"]*)\"$")
    public void userSearchForOrderIdAndVerifyTheBuyAmount(String Value) throws Throwable {
        key.pause("4", "");
        String vOrderIDSearch = Constants.RFQOR.getProperty("OrderIDSearch");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vOrderIDSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOrderIDSearch, vPaymentRef_no));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOrderIDSearch, "Enter"));
        key.pause("7", "");
        String BuyAmtMessage = Constants.RFQOR.getProperty("BuyAmount");
        System.out.println("Value is " + Value);
        System.out.println("Alert message is " + BuyAmtMessage);
        Assert.assertEquals("PASS", Constants.key.verifyText(BuyAmtMessage, Value));

        String vBuyAmtDate = Constants.RFQOR.getProperty("Deal_ID");
        DealID = Constants.key.getText(vBuyAmtDate);
        LogCapture.info("Taking the Deal No ......" + DealID);
    }

    @Then("^User Search the Deal ID and enter and right click the given record$")
    public void userSearchTheDealIDAndEnterAndRightClickTheGivenRecord() throws Throwable {
        key.pause("4", "");
        String vOrderIDSearch = Constants.RFQOR.getProperty("SearchDealID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vOrderIDSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOrderIDSearch, DealID));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOrderIDSearch, "Enter"));
        key.pause("4", "");
        String vObjSelectFirstrow = Constants.RFQOR.getProperty("SelectFirstrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectFirstrow, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjSelectFirstrow, "RightClick"));
    }

    @Then("^User verify the deal number from event log$")
    public void userVerifyTheDealNumberFromEventLog() throws Throwable {
        key.pause("5", "");
        String vEventLogDeal = Constants.RFQOR.getProperty("EventLogDeal");
        System.out.println("Value is " + DealID);
        System.out.println("message is " + vEventLogDeal);
        String EventMsg = Constants.driver.findElement(By.xpath(vEventLogDeal)).getText();

        if (EventMsg.contains(DealID)) {
            // Assert.assertEquals("PASS", Constants.key.verifyText(vEventLogDeal, DealID));
            LogCapture.info("Event log message is " + DealID + " Verified Succesfully");
//            Assert.assertEquals("PASS", "FAIL");
        } else {
            LogCapture.info("Event log text failed " + EventMsg);
            Assert.fail();
        }
    }

    @And("^User verify all required banks available \"([^\"]*)\"$")
    public void userVerifyAllRequiredBanksAvailable(String Menu) throws Throwable {
        key.pause("20", "");
        String vSpotDealBanks = Constants.B2BOR.getProperty("SpotDealBanks");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSpotDealBanks, ""));
        List<WebElement> rows_table = driver.findElements(By.xpath(vSpotDealBanks));
        //To calculate no of rows In table.
        int rows_count = rows_table.size();
        String vReqest_Timeout = Constants.B2BOR.getProperty("Reqest_Timeout");
        Assert.assertEquals("PASS", Constants.key.exist(vReqest_Timeout, ""));
        String ReqTimot = Constants.driver.findElement(By.xpath(vReqest_Timeout)).getText();
        //Checking Request Timeout
        if (ReqTimot.contains("REQUEST TIMEOUT")) {
            LogCapture.info("Failed due to Request Timeout");
            Assert.fail();
        }
        System.out.println("number of rows is " + rows_count);
        if (Menu.equalsIgnoreCase("Currencies Direct")) {
            if (rows_count == 5) {
                for (int i = 0; i < rows_table.size() - 1; i++) {
//                    Assert.assertEquals("PASS", "FAIL");
                    String BankName = Constants.driver.findElement(By.xpath("(//td[@id='idProvider'])[" + (i + 1) + "]")).getText();
                    System.out.println("Bank name is " + BankName);
                }
                LogCapture.info("All banks are available");
            } else {
                LogCapture.info("All banks are Not available");
                Assert.fail();
            }
        }
        if (Menu.equalsIgnoreCase("TorFX")) {
            if (rows_count == 3) {
                for (int i = 0; i < rows_table.size() - 1; i++) {
                    String BankName = Constants.driver.findElement(By.xpath("(//td[@id='idProvider'])[" + (i + 1) + "]")).getText();
                    System.out.println("Bank name is " + BankName);
                }
                LogCapture.info("All banks are available");
            } else {
                LogCapture.info("All banks are Not available");
                Assert.fail();
            }
        }
        if (Menu.equalsIgnoreCase("TorFXOz")) {
            if (rows_count == 2) {
                for (int i = 0; i < rows_table.size() - 1; i++) {
                    String BankName = Constants.driver.findElement(By.xpath("(//td[@id='idProvider'])[" + (i + 1) + "]")).getText();
                    System.out.println("Bank name is " + BankName);
                }
                LogCapture.info("All banks are available");
            } else {
                LogCapture.info("All banks are Not available");
                Assert.fail();
            }
        }
    }

    @Then("^User should get Reset Filter, Print and Export option on All Treasury deal page$")
    public void userShouldGetResetFilterPrintAndExportOptionOnAllTreasuryDealPage() throws Throwable {
        LogCapture.info("Checking Reset Filter, Print and Export option are visible on All Treasury deal page......");

        String vObjGenerateCSVFile = Constants.FXConfirmationOR.getProperty("GenerateCSVFile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateCSVFile, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjGenerateCSVFile, ""));

        String vObjPrintTreasurydeal = Constants.FXConfirmationOR.getProperty("PrintTreasurydeal");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPrintTreasurydeal, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjPrintTreasurydeal, ""));

//        String vObjChooseBalanceConfirmationEntries=Constants.FXConfirmationOR.getProperty("ChooseBalanceConfirmationEntries");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjChooseBalanceConfirmationEntries, ""));
//        Assert.assertEquals("PASS", Constants.key.exist(vObjChooseBalanceConfirmationEntries, ""));

        String vObjFXConfiramtionEntriesResetFilter = Constants.FXConfirmationOR.getProperty("FXConfiramtionEntriesResetFilter");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXConfiramtionEntriesResetFilter, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjFXConfiramtionEntriesResetFilter, ""));

        LogCapture.info("Reset Filter, Print and Export option are visible on All Treasury deal page......");

    }

    @And("^User click on Book Deal for (JPMG|DB|RBS|RBOS) from Spot deal booking page$")
    public void userClickOnBookDealForJPMGFromSpotDealBookingPage(String Menu) throws Throwable {
        LogCapture.info("User click on Book Deal on Spot deal booking......");

        if (Menu.contentEquals("JPMG")) {
            String vJPMGDeal = B2BOR.getProperty("JPMGDeal");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vJPMGDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vJPMGDeal, ""));
        }
        if (Menu.contentEquals("DB")) {
            String vDBDeal = B2BOR.getProperty("BookDeal2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDBDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vDBDeal, ""));
        }
        if (Menu.contentEquals("RBS")) {
            String vRBSDeal = B2BOR.getProperty("BookDeal3");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRBSDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vRBSDeal, ""));
        }
        if (Menu.contentEquals("RBOS")) {
            key.pause("5", "");
            String vRBSDeal = B2BOR.getProperty("BookDeal2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRBSDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vRBSDeal, ""));
        }
    }

    @And("^User select B2B_enabled for (JPMG|DB|RBS)$")
    public void userSelectBB_enabledForRBS(String Menu) throws Throwable {
        key.pause("4", "");
        LogCapture.info("User is clicking on B2B Enabled checkbox......");

        if (Menu.contentEquals("JPMG")) {
            String vJPMGB2BEnabled = Constants.B2BOR.getProperty("JPMGB2BEnabled");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vJPMGB2BEnabled, ""));
            Assert.assertEquals("PASS", Constants.key.click(vJPMGB2BEnabled, ""));
        }
        if (Menu.contentEquals("DB")) {
            String vDBB2BEnabled = Constants.B2BOR.getProperty("DBB2BEnabled");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDBB2BEnabled, ""));
            Assert.assertEquals("PASS", Constants.key.click(vDBB2BEnabled, ""));
        }
        if (Menu.contentEquals("RBS")) {
            String vRBSB2BEnabled = Constants.B2BOR.getProperty("RBSB2BEnabled");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRBSB2BEnabled, ""));
            Assert.assertEquals("PASS", Constants.key.click(vRBSB2BEnabled, ""));
        }
    }

    @Then("^User Checks For Request Timeout Error$")
    public void userChecksForRequestTimeoutError() throws Throwable {
        key.pause("15", "");
        String vReqest_Timeout = Constants.B2BOR.getProperty("Reqest_Timeout");
        String ReqTimot = Constants.driver.findElement(By.xpath(vReqest_Timeout)).getText();
        //Checking Request Timeout
        if (ReqTimot.contains("REQUEST TIMEOUT")) {
            LogCapture.info("Failed due to Request Timeout");
            Assert.fail();
        } else {
            LogCapture.info("No Request Timeout present in Deal Booking");
        }
    }

    @Then("^User Checks the (Table sort) for (Transaction Time|Organization|Event|Amount|Currency|Leg|Isbuyable)$")
    public void userChecksTheTableSortForTransactionTime(String Value, String Menu) throws Throwable {
        key.pause("5", "");

        if (Value.equalsIgnoreCase("Table sort") && Menu.equalsIgnoreCase("Transaction Time")) {
            String vEventlog_TransactionTime = Constants.RFQOR.getProperty("Eventlog_TransactionTime");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEventlog_TransactionTime, ""));
            Assert.assertEquals("PASS", Constants.key.click(vEventlog_TransactionTime, ""));
        } else if (Value.equalsIgnoreCase("Table sort") && Menu.equalsIgnoreCase("Organization")) {
            String vEventlog_Organization = Constants.RFQOR.getProperty("Eventlog_Organization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEventlog_Organization, ""));
            Assert.assertEquals("PASS", Constants.key.click(vEventlog_Organization, ""));
        } else if (Value.equalsIgnoreCase("Table sort") && Menu.equalsIgnoreCase("Event")) {
            String vEventlog_Event = Constants.RFQOR.getProperty("Eventlog_Event");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEventlog_Event, ""));
            Assert.assertEquals("PASS", Constants.key.click(vEventlog_Event, ""));
        } else if (Value.equalsIgnoreCase("Table sort") && Menu.equalsIgnoreCase("Amount")) {
            String vEventlog_Amount = Constants.RFQOR.getProperty("Eventlog_Amount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEventlog_Amount, ""));
            Assert.assertEquals("PASS", Constants.key.click(vEventlog_Amount, ""));
        } else if (Value.equalsIgnoreCase("Table sort") && Menu.equalsIgnoreCase("Currency")) {
            String vEventlog_Currency = Constants.RFQOR.getProperty("Eventlog_Currency");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEventlog_Currency, ""));
            Assert.assertEquals("PASS", Constants.key.click(vEventlog_Currency, ""));
        } else if (Value.equalsIgnoreCase("Table sort") && Menu.equalsIgnoreCase("Leg")) {
            String vEventlog_Leg = Constants.RFQOR.getProperty("Eventlog_Leg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEventlog_Leg, ""));
            Assert.assertEquals("PASS", Constants.key.click(vEventlog_Leg, ""));
        } else if (Value.equalsIgnoreCase("Table sort") && Menu.equalsIgnoreCase("Isbuyable")) {
            String vIsbuyablesort = Constants.RFQOR.getProperty("Isbuyablesort");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vIsbuyablesort, ""));
            Assert.assertEquals("PASS", Constants.key.click(vIsbuyablesort, ""));
        }
    }

    @Then("^User checks on (Next|Last) page and comes back to first page and checks$")
    public void userChecksOnNextPageAndComesBackToFirstPageAndChecks(String Menu) throws Throwable {
        key.pause("4", "");
        LogCapture.info("User is checking on pages......");

        if (Menu.contentEquals("Next")) {
            String vNext_Page = Constants.RFQOR.getProperty("Next_Page");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vNext_Page, ""));
            Assert.assertEquals("PASS", Constants.key.click(vNext_Page, ""));
            String vObjOrganization = Constants.RFQOR.getProperty("RFQ_Eventlog_Organization");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjOrganization, "Currencies Direct"));
            key.pause("2", "");
            String vFirst_Page = Constants.RFQOR.getProperty("First_Page");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirst_Page, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFirst_Page, ""));
        } else if (Menu.contentEquals("Last")) {
            String vLast_Page = Constants.RFQOR.getProperty("Last_Page");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vLast_Page, ""));
            Assert.assertEquals("PASS", Constants.key.click(vLast_Page, ""));
            String vObjOrganization = Constants.RFQOR.getProperty("RFQ_Eventlog_Organization");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjOrganization, "Currencies Direct"));
            key.pause("2", "");
            String vFirst_Page = Constants.RFQOR.getProperty("First_Page");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirst_Page, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFirst_Page, ""));
        }
    }


    @And("^User Selects (\\d+) records and clicks on reject all$")
    public void userSelectsRecordsAndClicksOnRejectAll(int arg0) throws Throwable {
        key.pause("4", "");
        String vBNK_Table_raiseQuerycheckbox = Constants.PaymentMonitoringOR.getProperty("BNK_Table_raiseQuerycheckbox");
        Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_raiseQuerycheckbox, ""));
        Assert.assertEquals("PASS", key.click(vBNK_Table_raiseQuerycheckbox, ""));
        String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
        Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        String vBNK_Table_raiseQuerycheckbox2 = Constants.PaymentMonitoringOR.getProperty("BNK_Table_raiseQuerycheckbox2");
        Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_Table_raiseQuerycheckbox2, ""));
        Assert.assertEquals("PASS", key.click(vBNK_Table_raiseQuerycheckbox2, ""));
        String vBNK_PDQ_RejectPayment = Constants.PaymentMonitoringOR.getProperty("BNK_PDQ_RejectPayment");
        Assert.assertEquals("PASS", key.VisibleConditionWait(vBNK_PDQ_RejectPayment, ""));
        Assert.assertEquals("PASS", key.clickAndHandleAlert(vBNK_PDQ_RejectPayment, ""));
    }

    //Routing Rule Verification
    @Then("^User Verify the routing rule of the entry for \"([^\"]*)\" from Audit trail$")
    public void userVerifyTheRoutingRuleOfTheEntryForFromAuditTrail(String Opt) throws Throwable {
        key.pause("3", "");
        String vFirstEntry = Constants.MessageOR.getProperty("FirstEntry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vFirstEntry, "RightClick"));
        String VObjAuditTrail = Constants.MessageOR.getProperty("AuditTrail");
        Assert.assertEquals("PASS", Constants.key.click(VObjAuditTrail, ""));
        key.pause("4", "");
        String vObjRoutingRuleNo = Constants.MessageOR.getProperty("ReasonID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRoutingRuleNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjRoutingRuleNo, Opt));
        LogCapture.info("Routing rule verified ......");
    }

    @Then("^User Verify the Error Message \"([^\"]*)\"of TitanTransactionReference$")
    public void userVerifyTheErrorMessageOfTitanTransactionReference(String Opt) throws Throwable {
        key.pause("3", "");
        String vFirstEntry = Constants.MessageOR.getProperty("FirstEntry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFirstEntry, ""));
        key.pause("4", "");
        String vObjValueDateErrormsg = Constants.MessageOR.getProperty("ValueDateErrormsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjValueDateErrormsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjValueDateErrormsg, Opt));
        LogCapture.info("Routing rules Error Message verified ......");
    }

    @Then("^User clicks on MessageType to search \"([^\"]*)\"$")
    public void userClicksOnMessageTypeToSearchMTType(String value) throws Throwable {
        key.pause("3", "");
        String messagetype = Constants.MessageOR.getProperty("MTsearch");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(messagetype, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(messagetype, value));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(messagetype, "enter"));
    }

    @And("^User should be able to see search result for (Messagetype|uploadedby)$")
    public void userShouldBeAbleToSeeSearchResultForMessagetype(String menu) throws Throwable {
        key.pause("3", "");
        if (menu.equalsIgnoreCase("Messagetype")) {
            String objMTverify = Constants.MessageOR.getProperty("MTverify");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(objMTverify, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(objMTverify, ""));
        }
        if (menu.equalsIgnoreCase("uploadedby")) {
            String objMTverify = Constants.MessageOR.getProperty("MTverify");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(objMTverify, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(objMTverify, ""));
        }
    }

    @Then("^User goes to (next|last|previous|first) page$")
    public void userGoesToNextPage(String Menu) throws Throwable {
        key.pause("3", "");
        if (Menu.equalsIgnoreCase("next")) {
            String objNextpage = Constants.MessageOR.getProperty("Nextpage");
            Assert.assertEquals("PASS", Constants.key.click(objNextpage, ""));
        }
        if (Menu.equalsIgnoreCase("last")) {
            String objNextpage = Constants.MessageOR.getProperty("Lastpage");
            Assert.assertEquals("PASS", Constants.key.click(objNextpage, ""));
        }
        if (Menu.equalsIgnoreCase("previous")) {
            String objprevpage = Constants.MessageOR.getProperty("prevpage");
            Assert.assertEquals("PASS", Constants.key.click(objprevpage, ""));
        }
        if (Menu.equalsIgnoreCase("first")) {
            String objfirstpage = Constants.MessageOR.getProperty("firstpage");
            Assert.assertEquals("PASS", Constants.key.click(objfirstpage, ""));
        }
    }

    @Then("^User Checks in the DB for the deal verification \"([^\"]*)\"$")
    public void userChecksInTheDBForTheDealVerification(String Description) throws Throwable {
        key.pause("50", "");
        String DealDescription = Constants.key.VerifyDBDetails("UAT", PendingB2BID, "Checking Description");
        LogCapture.info("Latest Trade Description is : " + DealDescription);
        Assert.assertTrue(DealDescription.contains(Description));
        LogCapture.info("Deal Description Verified");
    }

    @And("^Get PendingB(\\d+)B ID and Right Click the record$")
    public void getPendingBBIDAndRightClickTheRecord(int arg0) throws Throwable {
        key.pause("3", "");
        String PendingID = Constants.MessageOR.getProperty("PendingID");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(PendingB2BID, ""));
        PendingB2BID = Constants.driver.findElement(By.xpath(PendingID)).getText();
        LogCapture.info("PendingB2BID is ......" + PendingB2BID);
        key.pause("4", "");
        String vLast_Record = Constants.MessageOR.getProperty("Last_Record");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vLast_Record, ""));
        Assert.assertEquals("PASS", Constants.key.click(vLast_Record, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vLast_Record, "RightClick"));
    }


    @Then("^User should successfully see CounterParty page\\.$")
    public void userShouldSuccessfullySeeCounterPartyPage() throws Exception {
        LogCapture.info("User successfully seen CounterParty page ......");

        String vObjOrganization = Constants.RFQOR.getProperty("RFQ_Organization");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganization, ""));

    }


    @Then("^User verify Bank name in DB$")
    public void userVerifyBankNameInDB() throws Exception {
        String BankNameAtDB = Constants.key.VerifyDBDetails("UAT", NewName, "Verify Bank Name");
        Assert.assertEquals("PASS", BankNameAtDB.equalsIgnoreCase(NewName));
    }


    @Then("^User verify the \"([^\"]*)\"$")
    public void userVerifyThe(String MessageType) throws Throwable {
        String VobjMessageType = "//tr[last()]/td[last()and text()='" + MessageType + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VobjMessageType, ""));
        LogCapture.info("User verified that last record is of " + MessageType + "......");
    }


    @And("^apply filter at Source on (payment approval|Duplicate Payment Queue) page$")
    public void applyFilterAtSourceOnPaymentApprovalPage(String Data) throws Exception {
        if (Data.equalsIgnoreCase("payment approval")) {
            LogCapture.info("User select Source on payment approval Page ......");
        } else if (Data.equalsIgnoreCase("Duplicate Payment Queue")) {
            LogCapture.info("User select Source on Duplicate Payment Queue Page ......");
        }

        String vBNK_PaymentApproval_SelectSource = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SelectSource");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SelectSource, ""));
        Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_PaymentApproval_SelectSource, "Titan"));
        String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
        Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
    }

    @And("^user selects Total User Approval as One$")
    public void userSelectsTotalUserApprovalAsOne() throws Exception {
        LogCapture.info("User select Total User Approval as One payment approval Page ......");

        String vBNKTotalUserApproval = Constants.PaymentMonitoringOR.getProperty("TotalUserApproval");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNKTotalUserApproval, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vBNKTotalUserApproval, "1"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNKTotalUserApproval, "enter"));
    }


    @And("^apply filter at amount on Duplicate Payment Queue page$")
    public void applyFilterAtAmountOnDuplicatePaymentQueuePage() throws Exception {
        key.pause("4", "");
        LogCapture.info("User apply filter at amount on Duplicate Payment Queue page ......");
        String vBNK_DoublicatePayment_Amount = Constants.PaymentMonitoringOR.getProperty("BNK_DoublicatePayment_Amount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DoublicatePayment_Amount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vBNK_DoublicatePayment_Amount, "<1000"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBNK_DoublicatePayment_Amount, "enter"));
    }

    @Given("^User Provides \"([^\"]*)\"$")
    public void userProvides(String BankName) throws Throwable {
        String number = RandomStringUtils.randomAlphabetic(6);
        String Name = BankName + number;
        LogCapture.info("New name is " + Name);
        Constants.NewName = Name;
        DynamicValue.put("<NewBankName>", NewName);

    }

    @Given("^User Provides \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userProvides(String AccountName, String AccountNumber, String ClientAccountKey) throws Throwable {
        String number = RandomStringUtils.randomNumeric(6);
        String Name = AccountName + number;
        String Number = AccountNumber + number;
        LogCapture.info("New name is " + Name);
        LogCapture.info("New AccountNumber is " + Number);
        Constants.NewName = Name;
        Constants.NewAccountNumber = Number;
//        DynamicValue.put("<NewBankName>", NewName);
        DynamicValue.put("<AccountName>", NewName);
        DynamicValue.put("<AccountNumber>", Number);
        DynamicValue.put("<ClientAccountKey>", ClientAccountKey);
    }


    @When("^For a \"([^\"]*)\" call user push file from local to S3 bucket and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment\"([^\"]*)\"$")
    public void forACallUserPushFileFromLocalToSBucketAndCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID1, String Environment, String Bank) throws Throwable {
        DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime today = LocalDateTime.now();
        String nameDate = date.format(today);
        Constants.TCCaseID = testCaseID1;
        Constants.SHEET_NAME = Environment;

        String filePath = "Files/" + Bank + "/" + NewFileName;
        String destinationPath;
        if (NewFileName.contains("pain")) {
            destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/psr/" + nameDate + "/" + NewFileName;
        } else {
            destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/camt/" + nameDate + "/" + NewFileName;
        }
//        key.pause("2", "");
        Constants.RESPONSE = ServiceMethod.postAdvanceFileUploadToS3Bucket(testCaseID1, statCode, Constants.DynamicValue, filePath, destinationPath);
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);

        LogCapture.info(jp + "---------------POST call ended----------------");
    }

    @When("^For a \"([^\"]*)\" call user generates messageIn and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment\"([^\"]*)\"$")
    public void forACallUserGeneratesMessageInAndCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String Environment, String Bank) throws Throwable {
        key.pause("7", "");
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime today = LocalDateTime.now();
        String nameDate = date.format(today);
        String destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/camt/" + nameDate + "/" + NewFileName;
        DynamicValue.put("<destinationPath>", destinationPath);
        LogCapture.info("---------------POST call started----------------");
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        LogCapture.info(jp + "---------------POST call ended----------------");
        Assert.assertFalse(RESPONSE.contains("null"));
        String external_reference_id = RESPONSE.split(":")[3].split("}")[0];
        LogCapture.info("MessageInId =" + external_reference_id);
        Constants.MessageInId = external_reference_id;
    }

    @Then("^User need to remove linking of other tables to delete Bank Account$")
    public void userNeedToRemoveLinkingOfOtherTablesToDeleteBankAccount() throws Exception {
        String MSL = Constants.key.VerifyDBDetails("UAT", ID, "remove linking of other tables");

    }

    @And("^User selects (Bank|Branch)$")
    public void userSelectsBank(String data) throws Exception {
        if (data.equalsIgnoreCase("Bank") || data.equalsIgnoreCase("Branch")) {
            LogCapture.info("User Click on Bank ......");
            String vObjectBank = BankingOR.getProperty("BNK_Bank");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectBank, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectBank, NewName));
            LogCapture.info("User Clicked on " + NewName + " ......");
        }
    }

    @Then("^User enter Bank Account Number on Bank Account page$")
    public void userEnterBankAccountNumberOnBankAccountPage() throws Exception {
        LogCapture.info("Verify Bank Account Number present on UI ");
        String vBankAccountNumber = Constants.BankingOR.getProperty("BankAccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBankAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vBankAccountNumber, NewAccountNumber));
        key.pause("2", "");
        Constants.key.KeyboardAction(vBankAccountNumber, "enter");
        LogCapture.info("Bank Account Numbe entered at Search box ");
        key.pause("7", "");
        String vUniqueSearchResult = Constants.BankingOR.getProperty("UniqueSearchResult");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vUniqueSearchResult, ""));
        LogCapture.info("Verified MSL_ID present on UI is " + MSL_ID);
    }

    @And("^User verify the Remitter Account name and Remitter account Number is captured correctly for \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userVerifyTheRemitterAccountNameAndRemitterAccountNumberIsCapturedCorrectlyFor(String Bank, String FileType, String Environment) throws Throwable {
        String remitterCheck = Constants.key.VerifyDBDetails(Environment, IntradayStatementID, "Validating remitter account name and remitter account number");
        LogCapture.info("remitter Account info: validating remitter account name and remitter account number");
        LogCapture.info("remitterCheck table is :" + remitterCheck);
//            Assert.assertEquals("PASS",remitterCheck.isEmpty());
        try {
            Assert.assertTrue(remitterCheck.isEmpty());
        } catch (Exception e) {

            LogCapture.info("remitterCheck table is : Empty");
        }
    }

    @And("^User click on Processed Manual Payments from Manual Payment Upload$")
    public void userClickOnProcessedManualPaymentsFromManualPaymentUpload() throws Throwable {
        key.pause("5", "");
        String vObjectProcessedManualPayments = Constants.MessageOR.getProperty("ProcessedManualPayments");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectProcessedManualPayments, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjectProcessedManualPayments, ""));
        LogCapture.info("User Click on Processed Manual Payments Menu ......");
    }

    @Then("^User Search by (Time|MessageType|uploadedBy) Tab in (Processed Manual Payment) by Entering \"([^\"]*)\"$")
    public void userSearchByTimeTabInProcessedManualPaymentByEntering(String SubMenu, String Menu, String Value) throws Throwable {
        key.pause("5", "");
        if (SubMenu.equalsIgnoreCase("Time") && Menu.equalsIgnoreCase("Processed Manual Payment")) {
            LogCapture.info("User Click on Time Tab ......");
            String vObjectTimeTab = Constants.MessageOR.getProperty("TimeTab");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTimeTab, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectTimeTab, Value));

        }
        if (SubMenu.equalsIgnoreCase("MessageType") && Menu.equalsIgnoreCase("Processed Manual Payment")) {
            LogCapture.info("User Click on MessageType Tab ......");
            String vObjectMessageType = Constants.MessageOR.getProperty("MessageType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectMessageType, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectMessageType, Value));

        }
        if (SubMenu.equalsIgnoreCase("uploadedBy") && Menu.equalsIgnoreCase("Processed Manual Payment")) {
            LogCapture.info("User Click on uploadedBy Tab ......");
            String vObjectuploadedBy = Constants.MessageOR.getProperty("uploadedBy");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectuploadedBy, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjectuploadedBy, Value));
        }
    }

    @Then("^User verify search Result form (Time|MessageType|uploadedBy) Tab with given \"([^\"]*)\"$")
    public void userVerifySearchResultFormTimeTabWithGiven(String Menu, String arg0) throws Throwable {
        key.pause("5", "");
        if (Menu.equalsIgnoreCase("Time")) {
            LogCapture.info("User Click on Time Tab ......");
        }
        if (Menu.equalsIgnoreCase("MessageType")) {
            LogCapture.info("User Click on Time Tab ......");
        }
        if (Menu.equalsIgnoreCase("uploadedBy")) {
            LogCapture.info("User Click on Time Tab ......");
        }
    }

    @Then("^User Clicks on Export from Load Panel$")
    public void userClicksOnExportFromLoadPanel() throws Throwable {
        key.pause("5", "");
        String vObjectExport_loadpanel = Constants.MessageOR.getProperty("Export_loadpanel");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectExport_loadpanel, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjectExport_loadpanel, ""));
        Constants.key.pause("4", "");

        driver.findElement(By.xpath("//*[contains(text(), 'Save')]")).click();

        LogCapture.info("Downloaded......");
        String oSName = System.getProperty("os.name");
        String downloadPath = "";  //edge://settings/downloads
        if (oSName.toUpperCase().contains("WIN")) {
            downloadPath = System.getProperty("user.home") + "\\Downloads\\";
            LogCapture.info("File download path is " + downloadPath);
        } else {
            downloadPath = System.getProperty("user.dir") + "\\Downloads\\";
            LogCapture.info("File download path is " + downloadPath);
        }

    }

    @And("^User checks the Titan Reference from Load panel$")
    public void userChecksTheTitanReferenceFromLoadPanel() throws Throwable {
        key.pause("4", "");
        String vMsg_TitanRef_loadpanel = Constants.MessageOR.getProperty("Msg_TitanRef_loadpanel");
        TransactionReferenceNumber = Constants.key.getText(vMsg_TitanRef_loadpanel);
        LogCapture.info("Taking the Titan Reference No ......" + TransactionReferenceNumber);
    }

    @Given("^Update (JPMG|JPMG2) PaymentIn file \"([^\"]*)\"$")
    public void updateJPMGPaymentInFile(String fileType, String AccountNumber) throws InterruptedException {
        if (fileType.equals("JPMG")) {
            String path = "Files/JPMG/" + NewFileName;
            LogCapture.info("New file name with paths is: " + path);
            Constants.filePath = path;
            Constants.key.modifyFile(filePath, dateReplace, currentDate);
            Reusables.modifyFile(filePath, OldAccountNumber, AccountNumber);
            Reusables.modifyFile(filePath, oldAmountStarting, newAmount);
            DecimalFormat decimalFormat = new DecimalFormat("#0.00");
            double one = Double.parseDouble(newAmount);
            Constants.PaymentInAmount = decimalFormat.format((one + 0.37));
            LogCapture.info("Payment In amount is " + PaymentInAmount);
            if (Transaction_Reference_MessageOut != null) {
                Reusables.modifyFile(filePath, old_Transaction_Reference_MessageOut, Transaction_Reference_MessageOut);
            }
        } else {
            String path = "Files/JPMG2/" + NewFileName;
            LogCapture.info("New file name with paths is: " + path);
            Constants.filePath = path;
            Constants.key.modifyFile(filePath, dateReplace, currentDate);
            Reusables.modifyFile(filePath, OldAccountNumber, AccountNumber);
            Reusables.modifyFile(filePath, oldAmountStarting, newAmount);
            DecimalFormat decimalFormat = new DecimalFormat("#0.00");
            double one = Double.parseDouble(newAmount);
            Constants.PaymentInAmount = decimalFormat.format((one + 0.37));
            LogCapture.info("Payment In amount is " + PaymentInAmount);
            if (Transaction_Reference_MessageOut != null) {
                Reusables.modifyFile(filePath, old_Transaction_Reference_MessageOut, Transaction_Reference_MessageOut);
            }
        }
    }

    @Given("^Update (JPMG) PaymentIn file \"([^\"]*)\" with Payment Reference$")
    public void updateJPMGPaymentInFile_PaymentReference(String AccountNumber) throws InterruptedException {
        String path = "Files/JPMG/" + NewFileName;
        LogCapture.info("New file name with paths is: " + path);
        Constants.filePath = path;
        Constants.key.modifyFile(filePath, dateReplace, currentDate);
        Reusables.modifyFile(filePath, OldAccountNumber, AccountNumber);
        Reusables.modifyFile(filePath, oldAmountStarting, newAmount);
        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        double one = Double.parseDouble(newAmount);
        Constants.PaymentInAmount = decimalFormat.format((one + 0.37));
        LogCapture.info("Payment In amount is " + PaymentInAmount);
        if (Transaction_Reference_MessageOut != null) {
            Reusables.modifyFile(filePath, old_Transaction_Reference_MessageOut, Transaction_Reference_MessageOut);
        }
    }

    @Given("^take a \"([^\"]*)\"script for \"([^\"]*)\" and insert into messageIn on \"([^\"]*)\"$")
    public void takeAScriptForAndInsertIntoMessageIn(String arg0, String Bank, String Environment) throws Throwable {
        String path = "Files/" + Bank + "/" + NewFileName;
        LogCapture.info("New file name with paths is: " + path);
        Constants.filePath = path;

        Reusables.modifyFile(filePath, dateReplace, currentDate);
        Reusables.modifyFile(filePath, oldAmountStarting, newAmount);
        if (currentDate1 != null) {
            Reusables.modifyFile(filePath, Olddate, currentDate1);
        }
        String messageInId = Constants.key.VerifyDBDetails(Environment, "QueryForInsert", "Insert into MessageIn Table");
        LogCapture.info(Bank + " messageInId is " + messageInId);
        if (arg0.contains("MT942")) {
            MessageInIdMap.put("MessageInId for 52", messageInId); //to have a less variable for MT942 taken MessageInId for 52
        } else if (arg0.contains("MT940")) {
            MessageInIdMap.put("MessageInId for 53", messageInId);
        } else if (arg0.contains("MT103")) {
            MessageInIdMap.put("MessageInId for 103", messageInId);
        }

        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        double one = Double.parseDouble(newAmount);
        Constants.PaymentInAmount = decimalFormat.format((one));
        LogCapture.info("Payment In amount is " + PaymentInAmount);
    }

    @And("^Do DB verification and get CreditAdviceID \"([^\"]*)\"$")
    public void doDBVerificationAndGetCreditAdviceID(String Environment) throws Exception {

        if (MessageInId == null) {
            Object firstKey = MessageInIdMap.keySet().toArray()[0];
            MessageInId = MessageInIdMap.get(firstKey);
        }
        String CreditAdvice = Constants.key.VerifyDBDetails(Environment, MessageInId, "Find the CreditAdviceID");
        Constants.CreditAdviceID = CreditAdvice;
        LogCapture.info("CreditAdviceID : " + CreditAdviceID);
    }

    @And("^User gets MSL_ID from \"([^\"]*)\" DB from CreditAdviceID$")
    public void userGetsMSL_IDFromDBFromCreditAdviceID(String Environment) throws Exception {
        String MSL = Constants.key.VerifyDBDetails(Environment, CreditAdviceID, "MSL_ID from CreditAdviceID");
        Constants.MSL_ID = MSL;
        Constants.Kafka_ID = MSL;
        LogCapture.info("MSL_ID : " + MSL_ID);

    }

    @And("^User gets ROF_ID from \"([^\"]*)\" DB from CreditAdviceID$")
    public void userGetsROF_IDFromDBFromCreditAdviceID(String Environment) throws Exception {
        String ROF = Constants.key.VerifyDBDetails(Environment, CreditAdviceID, "ROF_ID from CreditAdviceID");
        Constants.ROF_ID = ROF;
        LogCapture.info("ROF_ID  is : " + ROF_ID);
    }

    @When("^User modifies \"([^\"]*)\" timing for 10 sec and reschedule timing to 60 sec for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userModifiesSchedulerTimingForSecAndRescheduleTimingToSecForOn(String scheduler, String testCaseID, String Environment) throws Throwable {
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<scheduler>", scheduler);
        try {
            DynamicValue.put("<CronExpression>", "0/10 * * 1/1 * ? *");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, "200", Constants.DynamicValue);
            LogCapture.info(" Scheduler is modified to trigger after 10 sec");
            LogCapture.info(" Scheduler is awaiting for 7 sec for parsing files");
            key.pause("14", "");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            DynamicValue.put("<CronExpression>", "0 0/1 * 1/1 * ? *");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, "200", Constants.DynamicValue);
            LogCapture.info(" Scheduler is modified to trigger after 60 sec");
        }
    }

    @When("^User modifies \"([^\"]*)\"(ON|OFF) action for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userModifiesPauseActionForOn(String scheduler, String action, String testCaseID, String Environment) throws Throwable {
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<scheduler>", scheduler);
        DynamicValue.put("<CronExpression>", action);
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, "200", Constants.DynamicValue);
        LogCapture.info(" Scheduler is modified to " + action);
        key.pause("14", "");
    }

    @Then("^User verify the Titan Reference from CSV file$")
    public void userVerifyTheTitanReferenceFromCSVFile() throws Throwable {
        key.pause("12", "");
        LogCapture.info("Taking the Titan Reference No ......" + TransactionReferenceNumber);
    }

    @And("^User validate (Transaction Reference|TIPaymentDetails|PaymentID|MessageOut|AuditTrail|ROF Transaction Reference|PaymentID_For_MT|Transaction Reference PaymentID|FPQ_Payment_Reference|Paymentstatus|ROF|JPM Merge|ISOCountryCode|CamtISOCountryCode|ACHDirectDebit Request Response) in DB for \"([^\"]*)\"$")
    public void userValidateTransactionReferenceInDBFor(String Menu, String Environment) throws Throwable {
        if (Menu.equalsIgnoreCase("Transaction Reference")) {
            String Transaction_Reference = Constants.key.VerifyDBDetails(Environment, ID, "Transaction Reference for Paymentout");
            LogCapture.info("Transaction Reference is " + Transaction_Reference);
            Constants.Transaction_Reference = Transaction_Reference;
        } else if (Menu.equalsIgnoreCase("Transaction Reference PaymentID")) {
            String Transaction_Reference = Constants.key.VerifyDBDetails(Environment, ID, "Transaction Reference");
            LogCapture.info("Transaction Reference is " + Transaction_Reference);
            Constants.Transaction_Reference = Transaction_Reference;
        } else if (Menu.equalsIgnoreCase("ROF Transaction Reference")) {
            String PayRef = "ROF " + Kafka_ID;
            Constants.Transaction_Reference = PayRef;
            String ROF_Transaction_Reference = Constants.key.VerifyDBDetails(Environment, PayRef, "ROF Transaction Reference for Paymentout");
        } else if (Menu.equalsIgnoreCase("TIPaymentDetails")) {
            String TI_PaymentInstructionsDetails_ID = Constants.key.VerifyDBDetails(Environment, ID, "TIPaymentDetails");
            LogCapture.info("TIPaymentDetails is " + TI_PaymentInstructionsDetails_ID);
            Constants.Kafka_ID = TI_PaymentInstructionsDetails_ID;
        } else if (Menu.equalsIgnoreCase("PaymentID")) {
            String Payment_ID = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "PaymentID");
            LogCapture.info("PaymentID is " + Payment_ID);
            Constants.PaymentID = Payment_ID;
            Constants.Kafka_ID = Payment_ID;
        } else if (Menu.equalsIgnoreCase("PaymentID_For_MT")) {
            key.pause("60", "");
            String Payment_ID = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "PaymentID_For_MT");
            LogCapture.info("PaymentID is " + Payment_ID);
            Constants.Kafka_ID = Payment_ID;
        } else if (Menu.equalsIgnoreCase("Paymentstatus")) {
            key.pause("50", "");
            PaymentStatusIs = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "PaymentStatus");
            LogCapture.info("PaymentID is " + PaymentStatusIs);
            Assert.assertEquals("PASS", Constants.key.VerifySubstring(PaymentStatusIs, "Duplicate"));
        } else if (Menu.equalsIgnoreCase("MessageOut")) {
            key.pause("35", "");
            String MessageOut = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "MessageOut");
            LogCapture.info("MessageOut is " + MessageOut);
            Constants.Kafka_ID = MessageOut;
        } else if (Menu.equalsIgnoreCase("FPQ_Payment_Reference")) {
            String FPQ_Payment_Reference = Constants.key.VerifyDBDetails(Environment, PaymentID, "FPQ_Payment_Reference");
            LogCapture.info("FPQ_Payment_Reference is " + FPQ_Payment_Reference);
            Constants.Transaction_Reference = FPQ_Payment_Reference;
        } else if (Menu.equalsIgnoreCase("ROF")) {
            String ROF_ID = Constants.key.VerifyDBDetails(Environment, IntradayStatementLineID, "ROFID");
            LogCapture.info("FPQ_Payment_Reference is " + ROF_ID);
            Constants.ROFQeueueID = ROF_ID;
        } else if (Menu.equalsIgnoreCase("JPM Merge")) {
            Map<String, String> result1 = Reusables.getSqlQueryResult("Statement_940", MessageInId);
            String ID = result1.get("ID");
            LogCapture.info("Value of StatementID: " + MessageInId);
            Assert.assertTrue(true, valueOf(ID.contains("null")));
        } else if (Menu.equalsIgnoreCase("ISOCountryCode")) {
            Map<String, String> result1 = Reusables.getSqlQueryResult("OriginatorISOCountryCode", Kafka_ID);
            OriginatorISOCountryCode = result1.get("OriginatorISOCountryCode");
            LogCapture.info("Value of OriginatorISOCountryCode: " + OriginatorISOCountryCode);
            Assert.assertFalse(OriginatorISOCountryCode.contains("null"));
            PaymentInAmount = "";
        } else if (Menu.equalsIgnoreCase("CamtISOCountryCode")) {
            Map<String, String> result1 = Reusables.getSqlQueryResult("CamtOriginatorISOCountryCode", BankRef);
            String ID = result1.get("ID");
            Assert.assertNull(ID, "Value of OriginatorISOCountryCode is present for all payments");
//            LogCapture.info("Value of OriginatorISOCountryCode is present for all payments");
        } else if (Menu.equalsIgnoreCase("ACHDirectDebit Request Response")) {
            hyperion_reference_id = Constants.key.VerifyDBDetails(Environment, TransactionReferenceNumber, "ACHDirectDebit Request Response");
            LogCapture.info("hyperion_reference_id is " + hyperion_reference_id);
        }
    }

    @And("^User Apply Filter On ValueDate of Payment Entries$")
    public void userApplyFilterOnValueDate() throws Throwable {

        //DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now).replace("-", "/");
        LogCapture.info("Todays date :" + currentDate);
        String paymentEntryValDate = Constants.PaymentMonitoringOR.getProperty("paymentEntryValueDate");
        Assert.assertEquals("PASS", Constants.key.writeInInput(paymentEntryValDate, currentDate + "-" + currentDate));
        //Assert.assertEquals("PASS",Constants.key.KeyboardAction(paymentEntryValDate,"enter"));
        //LogCapture.info("we reached here");

        //paymentEntryValueDate


    }

    @And("^User copies PaymentReference$")
    public void userCopiesPaymentReference() throws Exception {
        String PaymentReference = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_PaymentRef");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(PaymentReference, ""));

    }

    @And("^User click on (ROF Queue | Banking) Menu from Banking$")
    public void userClickOnROFQueueMenuFromBanking(String MainMenu, String SubMenu) throws Exception {
        if (MainMenu.equalsIgnoreCase("ROF Queue") && SubMenu.equalsIgnoreCase("Banking")) {
            key.pause("5", "");
            LogCapture.info("User Click on ROF Queue Menu from Dashboard 2......");
            key.pause("5", "");
            String vObjBNKROFQueue = Constants.BankingOR.getProperty("BNK_ROFQueue");
            key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNKROFQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBNKROFQueue, ""));

        }
    }

    @And("^User click on Checkbox and click on Copy Of MT$")
    public void userClickOnCheckboxAndClickOnCopyOfMT() throws Exception {

        String vCheckbox = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCheckbox");
        Assert.assertEquals("PASS", Constants.key.click(vCheckbox, ""));
        key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vCheckbox, "RightClick"));
        key.pause("3", "");

        String vCopyOfMT = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfMTText");
        key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vCopyOfMT, ""));
        LogCapture.info("User Clicked on copy of MT");
        key.pause("10", "");

        String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfMTMsg");
        String VCopyOfMTMsg1 = Constants.key.getText(VCopyOfMTMsg);
        if (Bank.equalsIgnoreCase("BARC")) {
            Assert.assertTrue(VCopyOfMTMsg1.contains(":71A:SHA"));
            LogCapture.info("In copy of MT able to see :71A:SHA");
        } else {
            Assert.assertTrue(VCopyOfMTMsg1.contains(":71A:OUR"));
            LogCapture.info("In copy of MT able to see :71A:OUR");
        }
        Assert.assertTrue(VCopyOfMTMsg1.contains(":20:ROF"));
        LogCapture.info("In copy of MT able to see :20:ROF");
    }

    @And("^User click on Export button in ROF Queue$")
    public void userClickOnExportButtonInROFQueue() throws Throwable {
        key.pause("3", "");
        String vExportButton = Constants.BankingOR.getProperty("BNKROFQueueExportButton");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vExportButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vExportButton, ""));
        key.pause("3", "");

        Alert alert = driver.switchTo().alert();
        alert.accept();

        Constants.key.pause("4", "");
        LogCapture.info("Downloaded......");
        String oSName = System.getProperty("os.name");
        String downloadPath = "";  //edge://settings/downloads
        if (oSName.toUpperCase().contains("WIN")) {
            downloadPath = System.getProperty("user.home") + "\\Downloads\\";
            LogCapture.info("File download path is " + downloadPath);
        } else {
            downloadPath = System.getProperty("user.dir") + "\\Downloads\\";
            LogCapture.info("File download path is " + downloadPath);
        }


//        String fileName = "ROFQueue.csv";
//        Assert.assertTrue(Constants.key.isFileDownloaded(downloadPath, fileName));
        //Assert.assertTrue(Constants.key.FileDelete(downloadPath, fileName));


    }

    @And("^User click on Export button in ROF Queue Report$")
    public void userClickOnExportButtonInROFQueueReport() throws Exception {
        LogCapture.info("clicking on ROF Queue Report");
        key.pause("10", "");
        String vROFQueueReportTab = Constants.BankingOR.getProperty("BNKROFQueueReportTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueReportTab, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vROFQueueReportTab, "ROF Queue Report"));
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueReportTab, ""));
        key.pause("3", "");
        LogCapture.info("ROF Queue Report opened....");

        Constants.key.pause("4", "");
        LogCapture.info("Downloaded......");
        String oSName = System.getProperty("os.name");
        String downloadPath = "";  //edge://settings/downloads
        if (oSName.toUpperCase().contains("WIN")) {
            downloadPath = System.getProperty("user.home") + "\\Downloads\\";
            LogCapture.info("File download path is " + downloadPath);
        } else {
            downloadPath = System.getProperty("user.dir") + "\\Downloads\\";
            LogCapture.info("File download path is " + downloadPath);
        }
        driver.switchTo().alert().sendKeys(downloadPath);
        driver.switchTo().alert().accept();


    }

    @And("^User captures the ROF ID from ROF Queue$")
    public void userCapturesTheROFIDFromROFQueue() throws Exception {
        key.pause("4", "");
        Constants.ROFQeueueID = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFID"));
        LogCapture.info("Latest ROF ID copied is :" + ROFQeueueID);
        key.pause("4", "");

        Constants.ROFQueueAccountNumber = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueAccountNumber"));
        LogCapture.info("Account Number is :" + ROFQueueAccountNumber);
        key.pause("4", "");

        Constants.ROFQueueAmount = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueAmount")).replace(",", "");
        LogCapture.info("Amount is :" + ROFQueueAmount);
        key.pause("4", "");

        Constants.ROFQueueCurrency = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueCurrency"));
        LogCapture.info("Currency is :" + ROFQueueCurrency);
        key.pause("4", "");

        String vROFQueueFilter = Constants.BankingOR.getProperty("BNKROFQueueFilter");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueFilter, ROFQeueueID));
        LogCapture.info("Latest ROF ID added in ROF Queue Filter");
        key.pause("4", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vROFQueueFilter, "enter"));
        key.pause("4", "");
        LogCapture.info("Enter clicked");
    }

    @And("^User clicks on Filter option in ROF Queue and paste ROF ID and Accept and ROF UpdatedBy$")
    public void userClicksOnFilterOptionInROFQueueAndPasteROFIDAndAcceptAndROFUpdatedBy() throws Exception {
        key.pause("4", "");
        Constants.ROFQeueueID = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFID"));
        LogCapture.info("Latest ROF ID copied is :" + ROFQeueueID);
        key.pause("4", "");

        Constants.ROFQueueAccountNumber = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueAccountNumber"));
        LogCapture.info("Account Number is :" + ROFQueueAccountNumber);
        key.pause("4", "");

        Constants.ROFQueueAmount = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueAmount")).replace(",", "");
        LogCapture.info("Amount is :" + ROFQueueAmount);
        key.pause("4", "");

        Constants.ROFQueueCurrency = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueCurrency"));
        LogCapture.info("Currency is :" + ROFQueueCurrency);
        key.pause("4", "");

        String vROFQueueFilter = Constants.BankingOR.getProperty("BNKROFQueueFilter");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueFilter, ROFQeueueID));
        LogCapture.info("Latest ROF ID added in ROF Queue Filter");
        key.pause("4", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vROFQueueFilter, "enter"));
        key.pause("4", "");
        LogCapture.info("Enter clicked");

        String vROFQueueCheckbox = Constants.BankingOR.getProperty("BNKROFQueueCheckbox");
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueCheckbox, ""));
        key.pause("6", "");
        LogCapture.info("Checkbox clicked");

        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vROFQueueCheckbox, "RightClick"));
        key.pause("4", "");
        LogCapture.info("Checkbox Right-clicked");

        String vROFQueueAccept = Constants.BankingOR.getProperty("BNKROFQueueAccept");
//        key.pause("2","");
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueAccept, ""));
        key.pause("4", "");

        Alert alert = driver.switchTo().alert();
        alert.accept();
        Constants.key.pause("4", "");

        // need to add code here to select Wallet Credit
        Constants.key.pause("2", "");
        String vROFActionDropDown = Constants.BankingOR.getProperty("ROFActionDropDown");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFActionDropDown, "Wallet Credit"));
        LogCapture.info(" Wallet Credit selected");
        Constants.key.pause("2", "");

        String vROFQueueLegalEntity = Constants.BankingOR.getProperty("BNKROFQueueLegalEntity");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueLegalEntity, Legal_Entity));
        LogCapture.info(Legal_Entity + " is entered on UI");
        Constants.key.pause("4", "");

        String vROFQueueClientReference = Constants.BankingOR.getProperty("BNKROFQueueClientReference");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueClientReference, "Test 123"));
        LogCapture.info(" ROF Queue Client Reference = Test 123 is entered on UI");
        Constants.key.pause("4", "");

        String BNKROFQueuePaymentReference = Constants.BankingOR.getProperty("BNKROFQueuePaymentReference");
        Assert.assertEquals("PASS", Constants.key.writeInInput(BNKROFQueuePaymentReference, "Test 123"));
        LogCapture.info(" ROF Queue Payment Reference = Test 123 is entered on UI");
        Constants.key.pause("4", "");

        String vROFQueueReasonOfROF = Constants.BankingOR.getProperty("BNKROFQueueReasonOfROF");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReasonOfROF, "Test ROF"));
        LogCapture.info(" ROF Queue Reason Of ROF = Test ROF is entered on UI");
        Constants.key.pause("4", "");

        String vROFQueueSubmit = Constants.BankingOR.getProperty("BNKROFQueueSubmit");
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueSubmit, ""));
        LogCapture.info(" User click on ROF Queue Submit Button");
        Constants.key.pause("4", "");

        Alert alert1 = driver.switchTo().alert();
        alert1.accept();
        Constants.key.pause("4", "");

//        String vROFQueueResetFilter = Constants.BankingOR.getProperty("BNKROFQueueResetFilter");
//        Assert.assertEquals("PASS", Constants.key.click(vROFQueueResetFilter,""));
//        Constants.key.pause("7", "");

        String vROFQueueReportTab = Constants.BankingOR.getProperty("BNKROFQueueReportTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueReportTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueReportTab, ""));
        key.pause("4", "");

        String vROFQueueReportFilter = Constants.BankingOR.getProperty("BNKROFQueueReportFilter");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReportFilter, ROFQeueueID));
        key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vROFQueueFilter, "enter"));
        key.pause("2", "");
        LogCapture.info("Enter clicked");

        String vROFQueueReportStatus = Constants.BankingOR.getProperty("ROFQueueReportStatus");
        Assert.assertEquals("PASS", Constants.key.verifyText(vROFQueueReportStatus, "Accepted"));
        LogCapture.info("ROF record is Accepted.");
        String vROFUpdatedBy = Constants.BankingOR.getProperty("ROFUpdatedBy");
        Assert.assertEquals("PASS", Constants.key.verifyText(vROFUpdatedBy, "SuperAdmin"));
        LogCapture.info("ROF record is updated by SuperAdmin");

        String ROFQueueReportResetFilter = Constants.BankingOR.getProperty("BNKROFQueueReportResetFilter");
        Assert.assertEquals("PASS", Constants.key.click(ROFQueueReportResetFilter, ""));
        Constants.key.pause("2", "");

    }

    @And("^User click on Balance Entry Menu from Banking to check MSL ID generated for ROF record$")
    public void userClickOnBalanceEntryMenuFromBankingToCheckMSLIDGeneratedForROFRecord() throws Exception {
        LogCapture.info("Now checking inside Balance Entry");

        String vObjBankingMenu_BalanceEntries = Constants.BankingOR.getProperty("BankingMenu_BalanceEntries");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_BalanceEntries, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjBankingMenu_BalanceEntries, ""));
        LogCapture.info("Balance Entry page loaded");
        key.pause("10", "");

        String ROFBalanceEntryAccountNumberFilter = Constants.BankingOR.getProperty("BNKROFBalanceEntryAccount");
        LogCapture.info("Account Number in Balance Entry :" + ROFQueueAccountNumber);
        Assert.assertEquals("PASS", Constants.key.writeInInput(ROFBalanceEntryAccountNumberFilter, ROFQueueAccountNumber));
        key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(ROFBalanceEntryAccountNumberFilter, "enter"));
        key.pause("3", "");
        LogCapture.info("Enter clicked");

        String ROFBalanceEntryAmountFilter = Constants.BankingOR.getProperty("BNKROFBalanceEntryAmount");
        LogCapture.info("Amount in Balance Entry :" + ROFQueueAmount);
        Assert.assertEquals("PASS", Constants.key.writeInInput(ROFBalanceEntryAmountFilter, ROFQueueAmount));
        key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(ROFBalanceEntryAmountFilter, "enter"));
        key.pause("3", "");
        LogCapture.info("Enter clicked");

        String ROFBalanceEntryCurrencyFilter = Constants.BankingOR.getProperty("BNKROFBalanceEntryCurrency");
        LogCapture.info("Currency in Balance Entry :" + ROFQueueCurrency);
        Assert.assertEquals("PASS", Constants.key.writeInInput(ROFBalanceEntryCurrencyFilter, ROFQueueCurrency));
        key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(ROFBalanceEntryAmountFilter, "enter"));
        key.pause("3", "");
        LogCapture.info("Enter clicked");

        String BalanceEntryMSL = Constants.key.getText(Constants.BankingOR.getProperty("BNKBalanceEntryMSL"));
        LogCapture.info("MSL ID is :" + BalanceEntryMSL);
        ROFPaymentReference = "ROF " + BalanceEntryMSL;
        LogCapture.info("ROF PaymentReference is :" + ROFPaymentReference);

    }

    @And("^User verifies if ROF Payment-Out is generated by ROF Payment Reference$")
    public void userVerifiesIfROFPaymentOutIsGeneratedByAddingAccountNumberCurrencyAmount() throws Exception {
        key.pause("3", "");
        LogCapture.info("Now inside Payment Entry");
        String PaymentOutPaymentReferenceFilter = Constants.PaymentMonitoringOR.getProperty("BNKROFPaymentOutPaymentreferenceFilter");
        LogCapture.info("ROF PaymentReference in Payment Entry :" + ROFPaymentReference);
        Assert.assertEquals("PASS", Constants.key.writeInInput(PaymentOutPaymentReferenceFilter, ROFPaymentReference));

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(PaymentOutPaymentReferenceFilter, "enter"));
        key.pause("3", "");
        LogCapture.info("Enter clicked");

    }

    @And("^User clicks on Filter option in ROF Queue and paste ROF ID and Reject and ROF UpdatedBy$")
    public void userClicksOnFilterOptionInROFQueueAndPasteROFIDAndRejectAndROFUpdatedBy() throws Exception {
        key.pause("3", "");
        String vROFQeueueID = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFID"));
        LogCapture.info("Latest ROF ID copied is :" + vROFQeueueID);
//        key.pause("3","");

        Constants.ROFQueueAccountNumber = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueAccountNumber"));
        LogCapture.info("Account Number is :" + ROFQueueAccountNumber);
//        key.pause("2","");

        Constants.ROFQueueAmount = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueAmount")).replace(",", "");
        LogCapture.info("Amount is :" + ROFQueueAmount);
//        key.pause("2","");

        Constants.ROFQueueCurrency = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFQueueCurrency"));
        LogCapture.info("Currency is :" + ROFQueueCurrency);
//        key.pause("2","");

//        String vROFQueueFilter = Constants.BankingOR.getProperty("BNKROFQueueFilter");
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueFilter, vROFQeueueID));
//        LogCapture.info("Latest ROF ID added in ROF Queue Filter");
//        key.pause("7","");

//        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vROFQueueFilter, "enter"));
//        key.pause("3","");
//        LogCapture.info("Enter clicked");

        String vROFQueueCheckbox = Constants.BankingOR.getProperty("BNKROFQueueCheckbox");
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueCheckbox, ""));
        key.pause("3", "");
        LogCapture.info("Checkbox clicked");

        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vROFQueueCheckbox, "RightClick"));
        key.pause("3", "");
        LogCapture.info("Checkbox Right-clicked");

        String vROFQueueReject = Constants.BankingOR.getProperty("BNKROFQueueReject");
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueReject, ""));
        key.pause("3", "");
        LogCapture.info("ROF ID " + vROFQeueueID + " rejected");

        Alert alert = driver.switchTo().alert();
        alert.accept();
        Constants.key.pause("3", "");
        LogCapture.info("first alert handled");

        Alert alert1 = driver.switchTo().alert();
        alert1.accept();
        Constants.key.pause("3", "");
        LogCapture.info("second alert handled");

        Constants.key.pause("7", "");
//        String vROFQueueResetFilter = Constants.BankingOR.getProperty("BNKROFQueueResetFilter");
//        Assert.assertEquals("PASS", Constants.key.click(vROFQueueResetFilter,""));
//        LogCapture.info("ROF Queue Reset filter clicked");
//
//        key.pause("7", "");
        String vROFQueueReportTab = Constants.BankingOR.getProperty("BNKROFQueueReportTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueReportTab, ""));
        Assert.assertEquals("PASS", Constants.key.Mouse_Hover(vROFQueueReportTab, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vROFQueueReportTab, "click"));
        LogCapture.info("clicked on ROF Queue Report tab");

        Constants.key.pause("07", "");
//        String vROFQueueReportResetFilter = Constants.BankingOR.getProperty("BNKROFQueueReportResetFilter");
//        Assert.assertEquals("PASS", Constants.key.click(vROFQueueReportResetFilter,""));
//        Constants.key.pause("3", "");
//        LogCapture.info("clicked on ROF Queue Report Reset filter");

        String vROFQueueReportFilter = Constants.BankingOR.getProperty("BNKROFQueueReportFilter");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReportFilter, CreditAdviceID));
        LogCapture.info("clicked on ROF Queue Report filter");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vROFQueueReportFilter, "enter"));
        key.pause("7", "");
        LogCapture.info("Enter clicked");

        String vROFQueueReportStatus = Constants.BankingOR.getProperty("ROFQueueReportStatus");
        Assert.assertEquals("PASS", Constants.key.verifyText(vROFQueueReportStatus, "Rejected"));
        String vROFUpdatedBy = Constants.BankingOR.getProperty("ROFUpdatedBy");
        Assert.assertEquals("PASS", Constants.key.verifyText(vROFUpdatedBy, "SuperAdmin"));
        LogCapture.info("Verify that ROF record is updated by SuperAdmin");

//        String ROFQueueReportResetFilter = Constants.BankingOR.getProperty("BNKROFQueueReportResetFilter");
//        Assert.assertEquals("PASS", Constants.key.click(ROFQueueReportResetFilter,""));
//        Constants.key.pause("2", "");

    }

    @And("^User click on Balance Entry Menu from Banking to check MSL ID generated for Non-ROF record$")
    public void userClickOnBalanceEntryMenuFromBankingToCheckMSLIDGeneratedForNonROFRecord() throws Exception {
        LogCapture.info("Now checking inside Balance Entry");

        String vObjBankingMenu_BalanceEntries = Constants.BankingOR.getProperty("BankingMenu_BalanceEntries");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_BalanceEntries, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjBankingMenu_BalanceEntries, ""));
        LogCapture.info("Balance Entry page loaded");
        key.pause("10", "");

        String ROFBalanceEntryAccountNumberFilter = Constants.BankingOR.getProperty("BNKROFBalanceEntryAccount");
        LogCapture.info("Account Number in Balance Entry :" + ROFQueueAccountNumber);
        Assert.assertEquals("PASS", Constants.key.writeInInput(ROFBalanceEntryAccountNumberFilter, ROFQueueAccountNumber));
        key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(ROFBalanceEntryAccountNumberFilter, "enter"));
        key.pause("3", "");
        LogCapture.info("Enter clicked");

        String ROFBalanceEntryAmountFilter = Constants.BankingOR.getProperty("BNKROFBalanceEntryAmount");
        LogCapture.info("Amount in Balance Entry :" + ROFQueueAmount);
        Assert.assertEquals("PASS", Constants.key.writeInInput(ROFBalanceEntryAmountFilter, ROFQueueAmount));
        key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(ROFBalanceEntryAmountFilter, "enter"));
        key.pause("3", "");
        LogCapture.info("Enter clicked");

        String ROFBalanceEntryCurrencyFilter = Constants.BankingOR.getProperty("BNKROFBalanceEntryCurrency");
        LogCapture.info("Currency in Balance Entry :" + ROFQueueCurrency);
        Assert.assertEquals("PASS", Constants.key.writeInInput(ROFBalanceEntryCurrencyFilter, ROFQueueCurrency));
        key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(ROFBalanceEntryAmountFilter, "enter"));
        key.pause("3", "");
        LogCapture.info("Enter clicked");

        String BalanceEntryMSL = Constants.key.getText(Constants.BankingOR.getProperty("BNKBalanceEntryMSL"));
        LogCapture.info("MSL ID is :" + BalanceEntryMSL);
    }

    @And("^User clicks on Filter option in ROF Queue and paste ROF ID and Duplicate Reject$")
    public void userClicksOnFilterOptionInROFQueueAndPasteROFIDAndDuplicateReject() throws Exception {
        key.pause("3", "");
        String vROFQeueueID = Constants.key.getText(Constants.BankingOR.getProperty("BNKROFID"));
        LogCapture.info("Latest ROF ID copied is :" + vROFQeueueID);
//        key.pause("3","");

//        String vROFQueueFilter = Constants.BankingOR.getProperty("BNKROFQueueFilter");
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueFilter, vROFQeueueID));
//        LogCapture.info("Latest ROF ID added in ROF Queue Filter");
////        key.pause("3","");
//
//        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vROFQueueFilter, "enter"));
//        key.pause("3","");
//        LogCapture.info("Enter clicked");

        String vROFQueueCheckbox = Constants.BankingOR.getProperty("BNKROFQueueCheckbox");
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueCheckbox, ""));
        key.pause("1", "");
        LogCapture.info("Checkbox clicked");

        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vROFQueueCheckbox, "RightClick"));
        key.pause("3", "");
        LogCapture.info("Checkbox Right-clicked");

        String vROFQueueDuplicateReject = Constants.BankingOR.getProperty("BNKROFQueueDuplicateReject");
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueDuplicateReject, ""));
        key.pause("3", "");
        LogCapture.info("ROF ID" + vROFQeueueID + "Duplicate Rejected");

        Alert alert = driver.switchTo().alert();
        alert.accept();
        Constants.key.pause("3", "");
        LogCapture.info("first alert handled");

        Alert alert1 = driver.switchTo().alert();
        alert1.accept();
        Constants.key.pause("3", "");
        LogCapture.info("second alert handled");

        Constants.key.pause("6", "");
//        String vROFQueueResetFilter = Constants.BankingOR.getProperty("BNKROFQueueResetFilter");
//        Assert.assertEquals("PASS", Constants.key.click(vROFQueueResetFilter,""));
//        Constants.key.pause("3", "");
//        LogCapture.info("ROF Queue Reset filter clicked");

        String vROFQueueReportTab = Constants.BankingOR.getProperty("BNKROFQueueReportTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueReportTab, ""));
        Assert.assertEquals("PASS", Constants.key.Mouse_Hover(vROFQueueReportTab, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vROFQueueReportTab, "click"));

        key.pause("3", "");
        LogCapture.info("clicked on ROF Queue Report tab");

        Constants.key.pause("6", "");
//        String vROFQueueReportResetFilter = Constants.BankingOR.getProperty("BNKROFQueueReportResetFilter");
//        Assert.assertEquals("PASS", Constants.key.click(vROFQueueReportResetFilter,""));
//        Constants.key.pause("3", "");
//        LogCapture.info("clicked on ROF Queue Report Reset filter");

        String vROFQueueReportFilter = Constants.BankingOR.getProperty("BNKROFQueueReportFilter");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReportFilter, CreditAdviceID));
        key.pause("07", "");
        LogCapture.info("clicked on ROF Queue Report filter");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vROFQueueReportFilter, "enter"));
        key.pause("3", "");
        LogCapture.info("Enter clicked");

        String vROFQueueReportStatus = Constants.BankingOR.getProperty("ROFQueueReportStatus");
        Assert.assertEquals("PASS", Constants.key.verifyText(vROFQueueReportStatus, "Duplicate"));
        String vROFUpdatedBy = Constants.BankingOR.getProperty("ROFUpdatedBy");
        Assert.assertEquals("PASS", Constants.key.verifyText(vROFUpdatedBy, "SuperAdmin"));
        LogCapture.info("Verify that ROF record is updated by SuperAdmin");
    }

    @And("^User get ROF_ID from DB from CreditAdviceID \"([^\"]*)\"$")
    public void userGetROF_IDFromDBFromCreditAdviceID(String Environment) throws Exception {
        String ROF = Constants.key.VerifyDBDetails(Environment, CreditAdviceID, "ROF_ID from CreditAdviceID");
        Constants.ROF_ID = ROF;
        Constants.ROFQeueueID = ROF;
        LogCapture.info("ROF_ID  is : " + ROF_ID);
    }

    @And("^user verify ROF_ID on ROF Queue Page")
    public void userVerifyROF_IDOnROFQueuePage() throws Throwable {
        LogCapture.info("Verify ROF_ID present on UI ");
        String vROF_ID = Constants.BankingOR.getProperty("BNKROFQueueFilter");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROF_ID, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROF_ID, ROF_ID));
        key.pause("2", "");
        Constants.key.KeyboardAction(vROF_ID, "enter");
        LogCapture.info("ROF_ID entered at Search box ");
        key.pause("7", "");
        String vVerify_ROF_ID = Constants.BankingOR.getProperty("BNKROFID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vVerify_ROF_ID, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vVerify_ROF_ID, ROF_ID));
        LogCapture.info("Verified ROF_ID present on UI is " + ROF_ID);

    }

    @And("^User gets Legal Entity for Indraday from \"([^\"]*)\" DB$")
    public void userGetsAccountNumberAndLegalEntityForIndradayFromDB(String Environment) throws Throwable {
        String LegalEntity = Constants.key.VerifyDBDetails(Environment, IntradayStatementLineID, "Find Legal Entity for IntradayStatmentLineID");
        Constants.Legal_Entity = LegalEntity;
        LogCapture.info("Legal Entity is : " + LegalEntity);
    }

    @And("^User gets Legal Entity for (EOD|MT103ROF) from \"([^\"]*)\" DB$")
    public void userGetsLegalEntityForEODFromDB(String data, String Environment) throws Throwable {
        String LegalEntity = null;
        if (data.equalsIgnoreCase("EOD")) {
            LegalEntity = Constants.key.VerifyDBDetails(Environment, StatementLineID, "Find Legal Entity for StatementLineID");
        } else if (data.equalsIgnoreCase("MT103ROF")) {
            LegalEntity = Constants.key.VerifyDBDetails(Environment, CreditAdviceID, "Find Legal Entity for MT103ROF");
        }
        Constants.Legal_Entity = LegalEntity;
        LogCapture.info("Legal Entity is : " + LegalEntity);
    }


    @And("^User get Transaction Reference From Message Out table DB for \"([^\"]*)\"$")
    public void userGetTransactionReferenceFromMessageOutTableDBFor(String Environment) throws Throwable {
        String Transaction_Reference_MessageOut = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "Transaction Reference From Message Out table");
        LogCapture.info("MessageOut Transaction Reference is " + Transaction_Reference_MessageOut);
        Constants.Transaction_Reference_MessageOut = Transaction_Reference_MessageOut;
    }

    @Then("^User search deal (with|More than) 180 days filter as per \"([^\"]*)\"$")
    public void userSearchDealWith180DaysFilterAsPer(String data, String AccountInfo) throws Throwable {
        String vAccountInfo = Constants.BankingOR.getProperty("AccountInfo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vAccountInfo, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vAccountInfo, AccountInfo));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vAccountInfo, "enter"));
        LogCapture.info("User entered AccountInfo as : " + AccountInfo);
        key.pause("2", "");
        if (data.equalsIgnoreCase("with")) {
            String vBankEntriesDetails = Constants.BankingOR.getProperty("bankEntriesDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBankEntriesDetails, ""));
            LogCapture.info("User able to search result for AccountInfo as : " + AccountInfo);
        } else if (data.equalsIgnoreCase("More than")) {
            String vSelectStatementDateWithIn180days = Constants.BankingOR.getProperty("SelectStatementDateWithIn180days");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectStatementDateWithIn180days, ""));
            LogCapture.info("user is getting error as statement date range is more than 180 days and accountInfo column filter is used ");
        }
    }


    @And("^User Apply filter for (less than|More than|Current to last 10 days) 180 days in statementDate on Balance Entry page$")
    public void userApplyFilterForDaysInStatementDateOnBalanceEntryPage(String data) throws Exception {
        String statmentDateRage = null;
        if (data.equalsIgnoreCase("less than")) {
            statmentDateRage = "19/03/2023-13/09/2023";
        } else if (data.equalsIgnoreCase("More than")) {
            statmentDateRage = "17/03/2023-13/09/2023";
        } else if (data.equalsIgnoreCase("Current to last 10 days")) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            LocalDateTime Less10Days = now.minusDays(30);
            String minus10day = dtf.format(Less10Days);
            statmentDateRage = currentDate + "-" + minus10day;
        }
        String vSelectStatementDate = Constants.BankingOR.getProperty("SelectStatementDate");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectStatementDate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSelectStatementDate, statmentDateRage));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSelectStatementDate, "enter"));
        LogCapture.info("User Apply filter for " + data + " 180 days in statementDate on Balance Entry page : " + statmentDateRage);
        key.pause("2", "");
    }

    @And("^User validate Routing Rule in DB for \"([^\"]*)\"\"([^\"]*)\"$")
    public void userValidateRoutingRuleInDBFor(String Environment, String rule) throws Throwable {
        String Rule = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "Verify Routing Rule");
        LogCapture.info("Applied Routing Rule is" + Rule);
        Assert.assertTrue(Rule.equalsIgnoreCase(rule));
    }

    @And("^User click on Checkbox and click on Copy Of (PAIN|MT) for (Revolut|Wise|Charge type|Transaction Reference|FPSDOM|FPSPOO|Field72|Field70)$")
    public void userClickOnCheckboxAndClickOnCopyOfPAIN(String Menu, String data) throws Exception {
        key.pause("7", "");
        String vCheckbox = Constants.PaymentMonitoringOR.getProperty("CheckBoxclick");
        Assert.assertEquals("PASS", Constants.key.click(vCheckbox, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vCheckbox, "RightClick"));
        key.pause("5", "");

        if (Menu.equalsIgnoreCase("PAIN")) {
            String vCopyOfPAIN = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfPAINText");
            key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.click(vCopyOfPAIN, ""));
            LogCapture.info("User Clicked on copy of PAIN");
            key.pause("7", "");
            if (data.equalsIgnoreCase("Revolut")) {
                String VCopyOfPAINMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfPAINMsg");
                String CopyOfPAINMsg = Constants.key.getText(VCopyOfPAINMsg);
                Assert.assertTrue(CopyOfPAINMsg.contains("REVOGB21XXX"));
                LogCapture.info("In copy of PAIN able to see correct BIC tag <BIC>REVOGB21XXX</BIC>");
            } else if (data.equalsIgnoreCase("Wise")) {
                String VCopyOfPAINMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfPAINMsg");
                String CopyOfPAINMsg = Constants.key.getText(VCopyOfPAINMsg);
                Assert.assertTrue(CopyOfPAINMsg.contains("<BIC>TRWIBEB1XXX</BIC>"));
                LogCapture.info("In copy of PAIN able to see correct BIC tag <BIC>TRWIBEB1XXX</BIC>");
            } else if (data.equalsIgnoreCase("Charge type")) {
                String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfPAINMsg");
                String CopyOfMTMsg = Constants.key.getText(VCopyOfMTMsg);
                Assert.assertTrue(CopyOfMTMsg.contains("<ChrgBr>SHAR</ChrgBr>"));
                LogCapture.info("In copy of PAIN able to see charge type : SHA");
            } else if (data.equalsIgnoreCase("FPSDOM") || data.equalsIgnoreCase("FPSPOO")) {
                String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfPAINMsg");
                String CopyOfMTMsg = Constants.key.getText(VCopyOfMTMsg);
                Assert.assertTrue(CopyOfMTMsg.contains("<Cd>URNS</Cd>"));
                Assert.assertTrue(CopyOfMTMsg.contains(" <Prtry>" + data + "</Prtry>"));
                LogCapture.info("In copy of PAIN able to see URNS and " + data);
            }
        }
        if (Menu.equalsIgnoreCase("MT")) {
            String vCopyOfMT = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentMonitoring_RightClick_CopyOfMT");
            key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.click(vCopyOfMT, ""));
            LogCapture.info("User Clicked on copy of MT");
            key.pause("7", "");
            if (data.equalsIgnoreCase("Revolut")) {
                String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfMTMsg");
                String CopyOfMTMsg = Constants.key.getText(VCopyOfMTMsg);
                Assert.assertTrue(CopyOfMTMsg.contains("57A:REVOGB21XXX"));
                LogCapture.info("In copy of MT able to see correct BIC tag 57A:REVOGB21XXX");
            } else if (data.equalsIgnoreCase("Wise")) {
                String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfMTMsg");
                String CopyOfMTMsg = Constants.key.getText(VCopyOfMTMsg);
                Assert.assertTrue(CopyOfMTMsg.contains("57A:TRWIBEB1XXX"));
                LogCapture.info("In copy of MT able to see correct BIC tag 57A:TRWIBEB1XXX");
            } else if (data.equalsIgnoreCase("Charge type")) {
                String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfMTMsg");
                String CopyOfMTMsg = Constants.key.getText(VCopyOfMTMsg);
                Assert.assertTrue(CopyOfMTMsg.contains("71A:SHA"));
                LogCapture.info("In copy of MT able to see charge type : SHA");
            } else if (data.equalsIgnoreCase("Transaction Reference")) {
                String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfMTMsg");
                String CopyOfMTMsg = Constants.key.getText(VCopyOfMTMsg);
                Assert.assertTrue(CopyOfMTMsg.contains(Transaction_Reference));
                LogCapture.info("In copy of MT able to see Transaction Reference");
                String VClose = Constants.PaymentMonitoringOR.getProperty("CLose");
                Assert.assertEquals("PASS", Constants.key.click(VClose, ""));
            } else if (data.equalsIgnoreCase("Field72")) {
                String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfMTMsg");
                String CopyOfMTMsg = Constants.key.getText(VCopyOfMTMsg);
                Assert.assertTrue(CopyOfMTMsg.contains(":72:/ACC/"));
                LogCapture.info("In copy of MT able to see ACC instead of REC");
            } else if (data.equalsIgnoreCase("Field70")) {
                String VCopyOfMTMsg = Constants.PaymentMonitoringOR.getProperty("BNKPaymentOutCopyOfMTMsg");
                String CopyOfMTMsg = Constants.key.getText(VCopyOfMTMsg);
                if (CopyOfMTMsg.contains("/B/O  CLI INV\\t03391 BSB 010001 BUSINESS INVOICES") || CopyOfMTMsg.contains("/B/O  CLI INV\\n03391 BSB 010001 BUSINESS INVOICES") || CopyOfMTMsg.contains("/B/O  CLI INV\\r03391 BSB 010001 BUSINESS INVOICES")) {
                    LogCapture.info("extra space observed in tag 70");
                } else {
                    LogCapture.info("No extra space observed in tag 70");
                }
            }

        }
    }

    @Given("^Change the \"([^\"]*)\" file name and update for \"([^\"]*)\"\"([^\"]*)\"$")
    public void changeTheFileNameAndUpdateFor(String FileType, String Bank, String AccpRjct) throws Exception {
        Constants.Bank = Bank;
        Constants.FileType = FileType;
        DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        LocalDateTime today = LocalDateTime.now();
        String nameDate = date.format(today);

        String RandomNumber = RandomStringUtils.randomNumeric(5);
        String number = RandomNumber;

        File camtFile = null;
        File Rename = null;
        File directoryPath = new File("Files/" + Bank + "/");

        String[] contents = directoryPath.list(); //List of all files and directories
        // key.pause("2","");
        LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
        for (int i = 0; i < contents.length; i++) {
            if (contents[i].contains(FileType)) {
                camtFile = new File("Files/" + Bank + "/" + contents[i]);
                LogCapture.info("old file name " + camtFile.getName());
                break;
            }
        }
        if (FileType.contains("pain.002")) {
            Rename = new File("Files/" + Bank + "/" + FileType + ".001.03.D" + nameDate + "_R667" + number + ".F020002.SNL35343D23678530057799989S");
        }
        camtFile.renameTo(Rename);

        String newFileName = Rename.getName();
        Constants.NewFileName = newFileName;
        LogCapture.info(Rename.getName());

        File NewCamtFile = new File("Files/" + Bank + "/" + NewFileName);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  // Using XML classes to modify file content
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(NewCamtFile);
        Constants.doc1 = doc;
        LogCapture.info(" Selected Document/File for updates is " + NewFileName);
        //PSR file updates

        Reusables.updateXmlFile("CreDtTm", String.valueOf(now));
        Reusables.updateXmlFile("MsgId", Transaction_Reference_MessageOut);
        Reusables.updateXmlFile("OrgnlMsgId", Transaction_Reference_MessageOut);
        Reusables.updateXmlFile("OrgnlPmtInfId", Transaction_Reference);
        Reusables.updateXmlFile("OrgnlEndToEndId", Transaction_Reference);
        Reusables.updateXmlFile("OrgnlCtrlSum", Amount);
        Reusables.updateXmlFile("InstdAmt", Amount);
        Reusables.updateXmlFile("ReqdExctnDt", currentDate);

        TransformerFactory transformerFactory = TransformerFactory.newInstance(); //Updated information send to local NewCamtFile
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc1);
        StreamResult result = new StreamResult(NewCamtFile);
        transformer.transform(source, result);
        LogCapture.info(" Updates are saved in document/file: " + NewFileName);

    }

    @And("^User Make sure that Payment is in Confirmed and Processing$")
    public void userMakeSureThatPaymentIsInConfirmedAndProcessing() throws Exception {
//        key.pause("7", "");
//        String VPaymentStatus = Constants.PaymentMonitoringOR.getProperty("PaymentStatusIsProcessing");
//        String StatusIs = key.notVisible(VPaymentStatus, "");
        if (PaymentStatusIs.equalsIgnoreCase("Duplicate")) {

            String vBNK_duplicatePaymentQueueSubMenu = Constants.PaymentMonitoringOR.getProperty("BNK_duplicatePaymentQueueSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_duplicatePaymentQueueSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_duplicatePaymentQueueSubMenu, ""));
            key.pause("7", "");
//                String VTextPaymentReference = "//*[text()='" + Transaction_Reference + "']";
//                String TextPaymentReference = key.notVisible(VTextPaymentReference,"");
//                        //VisibleConditionWait(VTextPaymentReference, "");
//                if (TextPaymentReference.equalsIgnoreCase("PASS")) {
            String vPaymentReference = Constants.PaymentMonitoringOR.getProperty("PaymentReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPaymentReference, Transaction_Reference));
            Constants.key.KeyboardAction(vPaymentReference, "enter");
            key.pause("2", "");
            LogCapture.info("User Selecting Row from Duplicate Payment Queue Table......");

            String vBNK_DuplicatePaymentQueue_TableRowOne = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_TableRowOne");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_TableRowOne, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_DuplicatePaymentQueue_TableRowOne, ""));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));
//                    LogCapture.info("User is Releasing Payment for selected Payment ID......");
//
//                    String vBNK_DuplicatePaymentQueue_PaymentID = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_PaymentID");
//                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_PaymentID, ""));
//                    PaymentID = Constants.key.getText(vBNK_DuplicatePaymentQueue_PaymentID);

            String vBNK_DuplicatePaymentQueue_RowOneCDText = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_RowOneCDText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_RowOneCDText, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_DuplicatePaymentQueue_RowOneCDText, "RightClick"));

            String vBNK_DuplicatePaymentQueue_ReleasePayment = Constants.PaymentMonitoringOR.getProperty("BNK_DuplicatePaymentQueue_ReleasePayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_ReleasePayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DuplicatePaymentQueue_ReleasePayment, ""));
            LogCapture.info("User see alert message respective page......");

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + "DoyouwanttoReleaseselected1payments?");
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains("DoyouwanttoReleaseselected1payments?"));
            key.pause("1", "");
            LogCapture.info("User see alert message respective page......");

            String alertMessage1 = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + "Total1paymentsrealeasedsuccessfully.");
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage1.contains("Total1paymentsrealeasedsuccessfully."));
        }

        if (PaymentStatusIs.equalsIgnoreCase("Duplicate") || PaymentStatusIs.equalsIgnoreCase("Pending")) {
            LogCapture.info("User Click on Payment Approval from Payment Monitoring Menu ......");

            String vBNK_PaymentApprovalSubMenu = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApprovalSubMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApprovalSubMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBNK_PaymentApprovalSubMenu, ""));
            key.pause("7", "");
            String vPaymentReference = Constants.PaymentMonitoringOR.getProperty("PaymentReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPaymentReference, Transaction_Reference));
            Constants.key.KeyboardAction(vPaymentReference, "enter");
            key.pause("2", "");

            LogCapture.info("User Selecting first Row from Payment Entries Table......");

            String vBNK_PaymentEntries_TableRowOne = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_TableRowOne");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentEntries_TableRowOne, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vBNK_PaymentEntries_TableRowOne, ""));
            String vObjLoader = Constants.BankingOR.getProperty("BNK_Loader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vObjLoader, ""));

            String vBNK_PaymentApprovalQueue_RowOneCDText = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApprovalQueue_RowOneCDText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApprovalQueue_RowOneCDText, ""));
            LogCapture.info("vBNK_PaymentApprovalQueue_RowOneCDText is visible and right click it");
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vBNK_PaymentApprovalQueue_RowOneCDText, "RightClick"));
            LogCapture.info("vBNK_PaymentApprovalQueue_RowOneCDText is right clicked");
            String vBNK_PaymentApproveQueue_ApprovePayment = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproveQueue_ApprovePayment");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproveQueue_ApprovePayment, ""));
            LogCapture.info("vBNK_PaymentApproveQueue_ApprovePayment click and handle alert");
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_PaymentApproveQueue_ApprovePayment, ""));

            LogCapture.info("User see alert message respective page......");

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is Doyouwanttoapproveselected1payments?");
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains("Doyouwanttoapproveselected1payments?"));
            key.pause("2", "");
            LogCapture.info("User see alert message respective page......");

            String alertMessage1 = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is Total1paymentsapprovedsuccessfully.");
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage1.contains("Total1paymentsapprovedsuccessfully."));


        }
    }

    @And("^User check PSR file is parsed and deal went to PaymentStatusReport \"([^\"]*)\"$")
    public void userCheckPSRFileIsParsedAndDealWentToPaymentStatusReport(String Environment) throws Throwable {
        String MessageInId = MessageInIdMap.get("MessageInId for 2");
        String PaymentStatus = Constants.key.VerifyDBDetails(Environment, MessageInId, "PSR Payment Status");
        LogCapture.info("After Uploading PSR Payment Status is" + PaymentStatus);
        Constants.PaymentStatusIs = PaymentStatus;
        Assert.assertTrue(PaymentStatus.equalsIgnoreCase("Approved"));

    }

    @And("^User checks the (Bank|CLE) column on (Bank Account|Balance Entries) page$")
    public void userChecksTheBankColumnOnBankAccountPage(String Menu, String submenu) throws Throwable {
        if (Menu.equalsIgnoreCase("Bank") || submenu.equalsIgnoreCase("Bank Account")) {
            String vObjectBNK_BankAcc_BankName = Constants.BankingOR.getProperty("BNK_BankAcc_BankName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectBNK_BankAcc_BankName, ""));
            LogCapture.info("Bank Column is Present ......");
        }
        if (Menu.equalsIgnoreCase("CLE") || submenu.equalsIgnoreCase("Balance Entries")) {
            String vObjectBNK_BankEntry_CLE = Constants.BankingOR.getProperty("BNK_BankEntry_CLE");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectBNK_BankEntry_CLE, ""));
            LogCapture.info("CLE Column is Present ......");
        }
    }

    @When("^User search for \"([^\"]*)\" from (Currency|orgName|Bank) column$")
    public void userSearchForFromBankColumn(String Value, String Menu) throws Throwable {
        key.pause("3", "");
        if (Menu.equalsIgnoreCase("Currency")) {
            String vObjt_OrgCurrencyDetails_SearchCry = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_SearchCry");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjt_OrgCurrencyDetails_SearchCry, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjt_OrgCurrencyDetails_SearchCry, Value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjt_OrgCurrencyDetails_SearchCry, "enter"));
            LogCapture.info("User searching for " + Value + " Currency");
        }
        if (Menu.equalsIgnoreCase("orgName")) {
            String vObjt_OrgCurrencyDetails_SearchCry = Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails_SearchOrg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjt_OrgCurrencyDetails_SearchCry, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjt_OrgCurrencyDetails_SearchCry, Value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjt_OrgCurrencyDetails_SearchCry, "enter"));
            LogCapture.info("User searching for " + Value + " orgName");
        }
        if (Menu.equalsIgnoreCase("Bank")) {
            String vObjt_BankName_searchbar = Constants.BankingOR.getProperty("BNK_BankAcc_BankName_searchbar");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjt_BankName_searchbar, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjt_BankName_searchbar, Value));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjt_BankName_searchbar, "enter"));
            LogCapture.info("User searching for " + Value + " Bank");
        }

    }

    @Then("^User will be able to see the search Result as \"([^\"]*)\" from (Bank|CLE) column$")
    public void userWillBeAbleToSeeTheSearchResultAsFromBankColumn(String Value, String Menu) throws Throwable {
        key.pause("8", "");
        if (Menu.equalsIgnoreCase("Bank")) {
            String vObjtFirst_Entry_BankName = Constants.BankingOR.getProperty("First_Entry_BankName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjtFirst_Entry_BankName, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjtFirst_Entry_BankName, Value));
            LogCapture.info("User search Result of Bank column is " + Value);
        }
        if (Menu.equalsIgnoreCase("CLE")) {
            String vObjtFirst_Entry_BE_CLE = Constants.BankingOR.getProperty("First_Entry_BE_CLE");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjtFirst_Entry_BE_CLE, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjtFirst_Entry_BE_CLE, Value));
            LogCapture.info("User search Result of Bank column is " + Value);
        }
    }


    @Then("^User Go \"([^\"]*)\" to DB, Check the cutoff time and then change the cutoff time \"([^\"]*)\" For (GBP|AUD|ZAR)$")
    public void userGoToDBCheckTheCutoffTimeAndThenChangeTheCutoffTimeFor(String Environment, String Organization, String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("GBP")) {
            Constants.CutOffTimeEnd = Constants.key.VerifyDBDetails(Environment, Organization, "Find the CUTTOFFTIME_CD_GBP");
            LogCapture.info("CutOffTimeEnd Original: " + CutOffTimeEnd);
            String CutOffTimeEndUpdated = Constants.key.VerifyDBDetails(Environment, Organization, "Find the CUTTOFFTIME_CD_GBP_Update");
            LogCapture.info("CutOffTimeEnd Updated: " + CutOffTimeEndUpdated);
        }
        if (Menu.equalsIgnoreCase("AUD")) {
            Constants.CutOffTimeEnd = Constants.key.VerifyDBDetails(Environment, Organization, "Find the CUTTOFFTIME_TorFXOz_AUD");
            LogCapture.info("CutOffTimeEnd Original: " + CutOffTimeEnd);
            String CutOffTimeEndUpdated = Constants.key.VerifyDBDetails(Environment, Organization, "Find the CUTTOFFTIME_TorFXOz_AUD_Update");
            LogCapture.info("CutOffTimeEnd Updated: " + CutOffTimeEndUpdated);
        }
        if (Menu.equalsIgnoreCase("ZAR")) {
            Constants.CutOffTimeEnd = Constants.key.VerifyDBDetails(Environment, Organization, "Find the CUTTOFFTIME_CDSA_ZAR");
            LogCapture.info("CutOffTimeEnd Original: " + CutOffTimeEnd);
            String CutOffTimeEndUpdated = Constants.key.VerifyDBDetails(Environment, Organization, "Find the CUTTOFFTIME_CDSA_ZAR_Update");
            LogCapture.info("CutOffTimeEnd Updated: " + CutOffTimeEndUpdated);
        }
    }

    @When("^User Apply Filter on PaymentReference$")
    public void userApplyFilterOnPaymentReference() throws Throwable {
        LogCapture.info("User Apply Filter on PaymentReference ......");
        key.pause("2", "");
        String venterPaymentReference = Constants.PaymentMonitoringOR.getProperty("enterPaymentReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(venterPaymentReference, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(venterPaymentReference, PaymentRef));
        Constants.key.KeyboardAction(venterPaymentReference, "enter");
    }

    @Then("^User Verify the PaymentReference is present in Duplicate Payment Queue with \"([^\"]*)\"\"([^\"]*)\"$")
    public void userVerifyThePaymentReferenceIsPresentInDuplicatePaymentQueueWith(String Currency, String BankName) throws Throwable {
        key.pause("5", "");
        LogCapture.info("Verify verifyPaymentReference of latest instruction ");
        String verifyPaymentReference = Constants.PaymentMonitoringOR.getProperty("verifyPaymentReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(verifyPaymentReference, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(verifyPaymentReference, PaymentRef));
        LogCapture.info("Verify DPQCurrency of latest instruction ");
        String vPaymentOutCurrency = Constants.PaymentMonitoringOR.getProperty("DPQCurrency");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentOutCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentOutCurrency, Currency));
        LogCapture.info("Verify DPQAmount of latest instruction ");
        String vPaymentOutAmount = Constants.PaymentMonitoringOR.getProperty("DPQAmount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentOutAmount, ""));
        String ActualAmount = key.getText(vPaymentOutAmount, "").replace(",", "");
        Assert.assertEquals("PASS", Constants.key.VerifySubstring(ActualAmount, Amount), "");
        LogCapture.info("Verify DPQBankName of latest instruction ");
        String vPaymentOutBankName = Constants.PaymentMonitoringOR.getProperty("DPQBankName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentOutBankName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentOutBankName, BankName));
    }

    @Then("^User Verify the PaymentReference is not present$")
    public void userVerifyThePaymentReferenceIsNotPresent() throws Throwable {
        key.pause("5", "");
        LogCapture.info("Verify verifyPaymentReference of latest instruction ");
        String verifyPaymentReference = Constants.PaymentMonitoringOR.getProperty("verifyPaymentReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(verifyPaymentReference, ""));
        Assert.assertFalse(verifyPaymentReference.contains(PaymentRef));
    }

    @Then("^User checks the Sort Value for \"([^\"]*)\" coulmn in first row$")
    public void userChecksTheSortValueForCoulmnInFirstRow(String Data) throws Throwable {
        LogCapture.info("Verifying Isbuyabledata");
        key.pause("5", "");
        String vIsbuyabledata = Constants.RFQOR.getProperty("Isbuyabledata");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vIsbuyabledata, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vIsbuyabledata, Data));
    }

    @And("^User Verify the \"([^\"]*)\" and \"([^\"]*)\" for the TitanTransactionReference$")
    public void userVerifyTheAndForTheTitanTransactionReference(String state, String status) throws Throwable {
        key.pause("5", "");
        String vStateoffirstRec = Constants.PaymentMonitoringOR.getProperty("StateoffirstRec");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vStateoffirstRec, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vStateoffirstRec, state));
        String vstatusoffirstRec = Constants.PaymentMonitoringOR.getProperty("statusoffirstRec");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vstatusoffirstRec, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vstatusoffirstRec, status));
    }

    @Then("^User Go \"([^\"]*)\" to DB and change the cutoff time to the original Time for (Currencies Direct|TorFX|TorFXOz|CD SA)$")
    public void userGoToDBAndChangeTheCutoffTimeToTheOriginalTimeFor(String Environment, String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("Currencies Direct")) {
            Constants.CutOffTimeEnd = Constants.key.VerifyDBDetails(Environment, CutOffTimeEnd, "Find the CUTTOFFTIME_CD_To_Original");
            LogCapture.info("CutOffTimeEnd : " + CutOffTimeEnd);
        }
        if (Menu.equalsIgnoreCase("TorFX")) {
            Constants.CutOffTimeEnd = Constants.key.VerifyDBDetails(Environment, CutOffTimeEnd, "Find the CUTTOFFTIME_TorFX_To_Original");
            LogCapture.info("CutOffTimeEnd : " + CutOffTimeEnd);
        }
        if (Menu.equalsIgnoreCase("TorFXOz")) {
            Constants.CutOffTimeEnd = Constants.key.VerifyDBDetails(Environment, CutOffTimeEnd, "Find the CUTTOFFTIME_TorFXOz_To_Original");
            LogCapture.info("CutOffTimeEnd : " + CutOffTimeEnd);
        }
        if (Menu.equalsIgnoreCase("CD SA")) {
            Constants.CutOffTimeEnd = Constants.key.VerifyDBDetails(Environment, CutOffTimeEnd, "Find the CUTTOFFTIME_CDSA_To_Original");
            LogCapture.info("CutOffTimeEnd : " + CutOffTimeEnd);
        }
        if (Menu.equalsIgnoreCase("E4F")) {
            Constants.CutOffTimeEnd = Constants.key.VerifyDBDetails(Environment, CutOffTimeEnd, "Find the CUTTOFFTIME_E4F_To_Original");
            LogCapture.info("CutOffTimeEnd : " + CutOffTimeEnd);
        }
    }

    @And("^User Right clicks and select Copy Of JPM_BANK_API$")
    public void userRightClicksAndSelectCopyOfJPM_BANK_API() throws Throwable {
        key.pause("5", "");
        String vFirstEntry = Constants.MessageOR.getProperty("FirstEntry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vFirstEntry, "RightClick"));
        String VObjCopyofJPM = Constants.MessageOR.getProperty("CopyofJPM");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjCopyofJPM, ""));
        Assert.assertEquals("PASS", Constants.key.click(VObjCopyofJPM, ""));
    }

    @Then("^User Verify the debtor details of the (ACH|Wire) payment$")
    public void userVerifyTheDebtorDetailsOfTheACHPayment(String Menu) throws Throwable {
        key.pause("5", "");
        if (Menu.equalsIgnoreCase("ACH")) {
            String VCopyofJPMText = Constants.MessageOR.getProperty("CopyofJPMText");
            String CopyofJPMText = Constants.key.getText(VCopyofJPMText);
            Assert.assertTrue(CopyofJPMText.contains("\"name\" : \"Currencies Direct Inc.\""));
            LogCapture.info("Debtor Name is Currencies Direct Inc.");
            Assert.assertTrue(CopyofJPMText.contains("\"streetName\" : \"4705 South Apopka-Vineland Rd\""));
            LogCapture.info("Debtor streetName is 4705 South Apopka-Vineland Rd");
            Assert.assertTrue(CopyofJPMText.contains("\"townName\" : \" Orlando FL 32819\""));
            LogCapture.info("Debtor townName is Orlando FL 32819");
            Assert.assertTrue(CopyofJPMText.contains("\"country\" : \"US\""));
            LogCapture.info("Debtor country is US");
        }
        if (Menu.equalsIgnoreCase("Wire")) {
            String VCopyofJPMText = Constants.MessageOR.getProperty("CopyofJPMText");
            String CopyofJPMText = Constants.key.getText(VCopyofJPMText);
            Assert.assertTrue(CopyofJPMText.contains("\"name\" : \"Currencies Direct Inc.\""));
            LogCapture.info("Debtor Name is Currencies Direct Inc.");
            Assert.assertTrue(CopyofJPMText.contains("\"country\" : \"US\""));
            LogCapture.info("Debtor country is US");
            Assert.assertTrue(CopyofJPMText.contains("\"addressLine\" : [ \"4705 South Apopka-Vineland Rd, Orlando FL 32819\" ]"));
            LogCapture.info("Debtor addressLine is 4705 South Apopka-Vineland Rd, Orlando FL 32819");
        }
    }


    @Given("^User launches Kafka UI application for \"([^\"]*)\"\"([^\"]*)\" topic$")
    public void launchKafkaUI(String topic, String Environment) throws Exception {

        key.pause("50", "");
        if (!isKafkaLaunched) {
            if (Constants.JenkinsBrowser == null || Constants.JenkinsBrowser.isEmpty()) {
                Constants.JenkinsBrowser = Constants.CONFIG.getProperty("browser");
            }

            Assert.assertTrue(Reusables.openBrowser("", Constants.JenkinsBrowser));
            LogCapture.info("Kafka UI is launching....");
            String kafkaUrl = Constants.CONFIG.getProperty("KafkaUIUrl");
            kafkaUrl = kafkaUrl.replace("{TOPIC}", topic).replace("{ENV}", Environment).replace("{MSL}", Kafka_ID);
            Assert.assertEquals("PASS", Reusables.navigate("", kafkaUrl));

            Reusables.loginToKafkaUI();
//            System.out.println("Waiting for 20 seconds to login manually...");
//            ReusableMethod.pause(20);

//            int time = 0; LocalDateTime localDateTime = LocalDateTime.now();
//            while(time < 2000 && ReusableMethod.getTimeLapsedInSeconds(localDateTime) < 30) {
//                Constants.key.isElementDisplayed(Constants.KafkaUI.getProperty("LoadingTime"), 10);
//                String loadingTimeText = Constants.key.getText(Constants.KafkaUI.getProperty("LoadingTime"));
//                loadingTimeText = loadingTimeText.replace(" ms", "");
//                time = Integer.parseInt(loadingTimeText);
//            }
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Constants.driver.navigate().refresh();

            isKafkaLaunched = true;
        } else if (isKafkaLaunched) {
            String kafkaUrl = Constants.CONFIG.getProperty("KafkaUIUrl");
            kafkaUrl = kafkaUrl.replace("{TOPIC}", topic).replace("{ENV}", Environment).replace("{MSL}", Kafka_ID);
            Assert.assertEquals("PASS", Reusables.navigate("", kafkaUrl));
//            Constants.driver.navigate().refresh();
        } else {
            Constants.driver.navigate().refresh();
        }
    }

    @Then("^Verify kafka message for (PaymentIn|TIPaymentInstruction|TIPayInstructionDetails|PaymentID|MessageOut|AuditTrail) \"([^\"]*)\"$")
    public void verify_kafka_message_for_offline_presentment(String data, String Environment) throws Exception {
        JsonPath actualKafkaMsgJsonObj = Reusables.waitForKafkaMessage(Kafka_ID);
        ExpectedKafkaKeyValues = Reusables.verifyDBDetailsEnhanced(Environment, Kafka_ID, data);
//            ExpectedKafkaKeyValues = ReusableMethod.getSqlQueryResult(expectedMsgFieldsSqlQueryProperty, Environment, Kafka_ID);
        System.out.println(ExpectedKafkaKeyValues);
//            ExpectedJsonPath= Reusables.mapToJsonPath(DBData);
//            Reusables.validateKafkaMessage(ExpectedJsonPath, actualKafkaMsgJsonObj, mappingFilePath,false);
        ReusableMethod.verifyKafkaMessage(ExpectedKafkaKeyValues, actualKafkaMsgJsonObj);
        Constants.driver.navigate().refresh();
    }

    @And("^Verify Kafka message audit logs for \"([^\"]*)\"\"([^\"]*)\"$")
    public void verifyKafkaMessageAuditLogsFor(String AuditLogSqlQueryProperty, String Environment) throws Throwable {
        Map<String, String> auditRecord = ReusableMethod.getSqlQueryResult(AuditLogSqlQueryProperty, Environment, Kafka_ID);
//        Gson gson = new Gson();
//        String json = gson.toJson(auditRecord);
//        JsonPath jsonPath = JsonPath.from(json);
        System.out.println(auditRecord);
//        Reusables.validateKafkaMessage(ExpectedJsonPath, jsonPath, mappingFilePath, true);
        ReusableMethod.verifyKafkaAuditLog(ExpectedKafkaKeyValues, auditRecord);
    }

    @Then("^user verify Remitter (Name|Number|Address)\"([^\"]*)\" is captured correctly$")
    public void userVerifyRemitterNameIsCapturedCorrectly(String Menu, String data) throws Throwable {
        if (Menu.equalsIgnoreCase("Name")) {
            String vBanking_RemitterAccountName = Constants.BankingOR.getProperty("RemitterAccountName");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_RemitterAccountName, data));
            LogCapture.info("Verified Remitter Account Name on UI is " + vBanking_RemitterAccountName);
        }
        if (Menu.equalsIgnoreCase("Number")) {
            String vBanking_RemitterAccountName = Constants.BankingOR.getProperty("RemitterAccountNumber");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_RemitterAccountName, data));
            LogCapture.info("Verified Remitter Account Name on UI is " + vBanking_RemitterAccountName);
        }
        if (Menu.equalsIgnoreCase("Address")) {
            String vBanking_RemitterAccountName = Constants.BankingOR.getProperty("RemitterAddress");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_RemitterAccountName, data));
            LogCapture.info("Verified Remitter Account Name on UI is " + vBanking_RemitterAccountName);
        }
    }

//    @And("^Update xml file for $")
//    public void updateXmlFileFor() throws Throwable {
//        File NewCamtFile=new File("Files/"+Bank+"/" + NewFileName);
//        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();  // Using XML classes to modify file content
//        DocumentBuilder builder=factory.newDocumentBuilder();
//        Document doc=builder.parse(NewCamtFile);
//        Constants.doc1=doc;
//        LogCapture.info(" Selected Document/File for updates is "+NewFileName);
//        NodeList nodeList=doc.getElementsByTagName("Ustrd");
//        LogCapture.info("Number of Amt fields are " + nodeList.getLength());
//        for (int j=0; j < nodeList.getLength(); j++) {
//            Constants.key.updateXmlFile("Ustrd", Constants.CONFIG.getProperty("Ustrd"+j));
//        }
////            Constants.key.updateXmlParentChild("RmtInf","Ustrd", Ustrd);
//            Constants.key.updateXmlFile("AddtlNtryInf", Constants.CONFIG.getProperty("AddtlNtryInf1"));
////        String Ustrd = Constants.CONFIG.getProperty("Ustrd");
//        // if you want to change AddtlNtryInf for single transaction then use below commented lines
//        // if specific AddtlNtryInf need to change at config AddtlNtryInf
////         String AddtlNtryInf = Constants.CONFIG.getProperty("AddtlNtryInf");
//        LogCapture.info("Required Tags are modified for file: "+NewFileName);
//        TransformerFactory transformerFactory=TransformerFactory.newInstance(); //Updated information send to local NewCamtFile
//        Transformer transformer=transformerFactory.newTransformer();
//        DOMSource source=new DOMSource(doc1);
//        StreamResult result=new StreamResult(NewCamtFile);
//        transformer.transform(source, result);
//        LogCapture.info(" Updates are saved in document/file: "+NewFileName);
//    }

    @Then("^User search the (IntradayStatementLineID|StatementLineID) and (Accept|Reject) the Record for (PDQ|ROF)$")
    public void userSearchTheIntradayStatementLineIDAndAcceptTheRecordFor(String ID, String Menu, String SubMenu) throws Throwable {
        key.pause("5", "");
        if (Menu.equalsIgnoreCase("Accept") && SubMenu.equalsIgnoreCase("PDQ")) {
            String CDPDQ_ItraStmID = Constants.BankingOR.getProperty("PDQ_ItraStmID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CDPDQ_ItraStmID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(CDPDQ_ItraStmID, IntradayStatementLineID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CDPDQ_ItraStmID, "enter"));
            key.pause("5", "");
            String vObjPDQRecord = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPDQRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPDQRecord, ""));

            String vBNK_DuplicatePaymentQueue_AcceptPayment = Constants.BankingOR.getProperty("BNK_DuplicatePaymentQueue_AcceptPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_AcceptPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DuplicatePaymentQueue_AcceptPayment, ""));
        }
        if (Menu.equalsIgnoreCase("Reject") && SubMenu.equalsIgnoreCase("PDQ")) {
            String CDPDQ_ItraStmID = Constants.BankingOR.getProperty("PDQ_ItraStmID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CDPDQ_ItraStmID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(CDPDQ_ItraStmID, IntradayStatementLineID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CDPDQ_ItraStmID, "enter"));
            key.pause("5", "");
            String vObjPDQRecord = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPDQRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPDQRecord, ""));

            String vBNK_DuplicatePaymentQueue_Reject = Constants.BankingOR.getProperty("BNK_DuplicatePaymentQueue_Reject");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_Reject, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DuplicatePaymentQueue_Reject, ""));
        }
        if (SubMenu.equalsIgnoreCase("ROF")) {
            String CDROF_ID = Constants.BankingOR.getProperty(ID);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CDROF_ID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(CDROF_ID, IntradayStatementLineID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CDROF_ID, "enter"));
            key.pause("4", "");
            String vROFQueueCheckbox = Constants.BankingOR.getProperty("BNKROFQueueCheckbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vROFQueueCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vROFQueueCheckbox, "RightClick"));
            String vROFQueueAccept = Constants.BankingOR.getProperty("BNKROFQueueAccept");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueAccept, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vROFQueueAccept, ""));
            Alert alert = driver.switchTo().alert();
            alert.accept();
            Constants.key.pause("2", "");
            String vROFQueueLegalEntity = Constants.BankingOR.getProperty("BNKROFQueueLegalEntity");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueLegalEntity, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueLegalEntity, Legal_Entity));
            LogCapture.info(Legal_Entity + " is entered on UI");
            Constants.key.pause("2", "");
            String vROFQueueClientReference = Constants.BankingOR.getProperty("BNKROFQueueClientReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueClientReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueClientReference, "Test 123"));
            LogCapture.info(" ROF Queue Client Reference = Test 123 is entered on UI");
            String BNKROFQueuePaymentReference = Constants.BankingOR.getProperty("BNKROFQueuePaymentReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(BNKROFQueuePaymentReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(BNKROFQueuePaymentReference, "Test 123"));
            LogCapture.info(" ROF Queue Payment Reference = Test 123 is entered on UI");
            Constants.key.pause("2", "");
            String vROFQueueReasonOfROF = Constants.BankingOR.getProperty("BNKROFQueueReasonOfROF");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueReasonOfROF, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReasonOfROF, "Test ROF"));
            LogCapture.info(" ROF Queue Reason Of ROF = Test ROF is entered on UI");
            Constants.key.pause("2", "");
            String vROFQueueSubmit = Constants.BankingOR.getProperty("BNKROFQueueSubmit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueSubmit, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vROFQueueSubmit, ""));
            Constants.key.pause("2", "");
            Alert alert1 = driver.switchTo().alert();
            alert1.accept();
            LogCapture.info(" User click on ROF Queue Submit Button");
        }
    }

    @When("^Update the Excel file and Upload (ManualEntries|ManualPayment_JPMG|ManualPayment_CITI|ManualPSR_AIP_Accept|ManualPSR_AIP_Reject|ManualPayment_BARC|ManualPSR_CDSA_Accept)$")
    public void updateTheExcelFileAndUploadAndReference(String Menu) throws Exception {
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
//        LocalDateTime now = LocalDateTime.now();
//        LocalDateTime currentDate = LocalDateTime.parse(dtf.format(now));
        RandomNumber = RandomStringUtils.randomNumeric(10);
        RandomNumber = RandomNumber.startsWith("0") ? RandomNumber.substring(1) : RandomNumber;
//     double newAmount=Double.parseDouble(RandomNumber);
//    String newAmount=RandomNumber;
//        LogCapture.info("New Trade Amount : " + newAmount);
        if (Menu.equalsIgnoreCase("ManualEntries")) {
            BankRef = "CAXIA" + RandomNumber;
            LogCapture.info("New Reference : " + BankRef);
            Reusables.writeDataFromExcel(1, 1, Rename, "Sheet1", BankRef);
//        Reusables.writeAmountFromExcel(1,4,Rename,"Sheet1",newAmount);
//        Reusables.writeDateFromExcel(1,5,Rename,"Sheet1",currentDate);
            String newFileName = System.getProperty("user.dir") + "/Files/Manual Entries/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        } else if (Menu.equalsIgnoreCase("ManualPayment_JPMG")) {
            Transaction_Reference = "JPMG" + RandomNumber;
            LogCapture.info("New BankRef : " + Transaction_Reference);
            Reusables.writeDataFromExcel(1, 0, Rename, "Sheet2", Transaction_Reference);
            String newFileName = System.getProperty("user.dir") + "/Files/Manual_Payment/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        } else if (Menu.equalsIgnoreCase("ManualPayment_CITI")) {
            Transaction_Reference = "CITI" + RandomNumber;
            LogCapture.info("New BankRef : " + Transaction_Reference);
            Reusables.writeDataFromExcel(1, 0, Rename, "Sheet2", Transaction_Reference);
            String newFileName = System.getProperty("user.dir") + "/Files/Manual_Payment/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        } else if (Menu.equalsIgnoreCase("ManualPSR_AIP_Accept")) {
            key.pause("8", "");
            Reusables.writeDataFromExcel(5, 1, Rename, "交易回盘", Transaction_Reference);
            String newFileName = System.getProperty("user.dir") + "/Files/PSR_Files/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
            String vBanking_ManualPaymentUploadButton = Constants.MessageOR.getProperty("vBanking_ManualPaymentUploadButton");
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUploadButton, ""));
        } else if (Menu.equalsIgnoreCase("ManualPSR_AIP_Reject")) {
            key.pause("8", "");
            Reusables.writeDataFromExcel(6, 1, Rename, "交易回盘", Transaction_Reference);
            String newFileName = System.getProperty("user.dir") + "/Files/PSR_Files/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
            String vBanking_ManualPaymentUploadButton = Constants.MessageOR.getProperty("vBanking_ManualPaymentUploadButton");
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUploadButton, ""));
        } else if (Menu.equalsIgnoreCase("ManualPayment_BARC")) {
            Transaction_Reference = "TEST" + RandomNumber;
            LogCapture.info("New TranRef : " + Transaction_Reference);
            Reusables.writeDataFromExcel(1, 0, Rename, "Sheet1", Transaction_Reference);
            Reusables.writeDataFromExcel(1, 8, Rename, "Sheet1", Transaction_Reference);
            String newFileName = System.getProperty("user.dir") + "/Files/Manual_Payment/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        } else if (Menu.equalsIgnoreCase("ManualPSR_CDSA_Accept")) {
            key.pause("8", "");
            Reusables.writeDataFromExcel(4, 1, Rename, "Sheet1", Transaction_Reference);
            String newFileName = System.getProperty("user.dir") + "/Files/PSR_Files/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFileCDSA");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
            String vBanking_ManualPaymentUploadButton = Constants.MessageOR.getProperty("vBanking_ManualPaymentUploadButtonCDSA");
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUploadButton, ""));
        }
    }

    @And("^User validate AuditTrailID in DB for (Record1|Record2|Record3|Record4|Record5|Record6|Record7|Record8)$")
    public void userValidateAuditTrailIDInDBForRecord(String REC) throws Exception {
        List<Map<String, String>> result = Reusables.getSqlQueryResultForMultiRows("PayRefAuditTrail", Transaction_Reference);
        for (int i = 0; i < result.size(); i++) {
            Map<String, String> record = new HashMap<>();
            record.put("ID", result.get(i).get("ID"));
            AuditTable.add(record);
        }
        if (REC.equalsIgnoreCase("Record1")) {
            Map<String, String> selectedRecord = AuditTable.get(0);
            idValue = selectedRecord.get("ID");
        }
        if (REC.equalsIgnoreCase("Record2")) {
            Map<String, String> selectedRecord = AuditTable.get(1);
            idValue = selectedRecord.get("ID");
        }
        if (REC.equalsIgnoreCase("Record3")) {
            Map<String, String> selectedRecord = AuditTable.get(2);
            idValue = selectedRecord.get("ID");
        }
        if (REC.equalsIgnoreCase("Record4")) {
            Map<String, String> selectedRecord = AuditTable.get(3);
            idValue = selectedRecord.get("ID");
        }
        if (REC.equalsIgnoreCase("Record5")) {
            Map<String, String> selectedRecord = AuditTable.get(4);
            idValue = selectedRecord.get("ID");
        }
        if (REC.equalsIgnoreCase("Record6")) {
            Map<String, String> selectedRecord = AuditTable.get(5);
            idValue = selectedRecord.get("ID");
        }
        if (REC.equalsIgnoreCase("Record7")) {
            Map<String, String> selectedRecord = AuditTable.get(6);
            idValue = selectedRecord.get("ID");
        }
        if (REC.equalsIgnoreCase("Record8")) {
            Map<String, String> selectedRecord = AuditTable.get(7);
            idValue = selectedRecord.get("ID");
        }
        LogCapture.info("AuditTrailID is " + idValue);
        Constants.Kafka_ID = idValue;
    }

    @When("^User click on \"([^\"]*)\"dropdown for (Organization|Provider|CurrencyPair|OFFSET|CountryPartyDropDownAll) column$")
    public void userClickOnDropdownForOrganizationColumn(String data, String Menu) throws Throwable {
        key.pause("6", "");
        if (Menu.equalsIgnoreCase("Organization")) {
            LogCapture.info("User Click on Organization Column ......");
            String vObjectCP_Organization = Constants.RFQOR.getProperty("CP_Organization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectCP_Organization, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectCP_Organization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectCP_Organization, data));
        }
        if (Menu.equalsIgnoreCase("Provider")) {
            LogCapture.info("User Click on Organization Column ......");
            String vObjectCP_Provider = Constants.RFQOR.getProperty("CP_Provider");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectCP_Provider, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectCP_Provider, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectCP_Provider, data));
        }
        if (Menu.equalsIgnoreCase("CurrencyPair")) {
            LogCapture.info("User Click on Organization Column ......");
            String vObjectCP_CurrencyPair = Constants.RFQOR.getProperty("CP_CurrencyPair");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectCP_CurrencyPair, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectCP_CurrencyPair, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectCP_CurrencyPair, data));
        }
        if (Menu.equalsIgnoreCase("OFFSET")) {
            LogCapture.info("User Click on Organization Column ......");
            String vObjectCP_OFFSET = Constants.RFQOR.getProperty("CP_OFFSET");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectCP_OFFSET, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectCP_OFFSET, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectCP_OFFSET, data));
        }
        if (Menu.equalsIgnoreCase("CountryPartyDropDownAll")) {
            LogCapture.info("User Click on Enable/Disable B2B all......");
            String vObjectDropDownIsActiveAll = Constants.RFQOR.getProperty("DropDownIsActiveAll");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectDropDownIsActiveAll, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectDropDownIsActiveAll, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjectDropDownIsActiveAll, data));
        }
    }

    @And("^User Add \"([^\"]*)\" for Yes Bank$")
    public void userAddForYesBank(String purpose) throws Throwable {
        DynamicValue.put("<purpose>", purpose);
    }

    @Then("^User verify the \"([^\"]*)\" (Organization|Provider|CurrencyPair|OFFSET) for first row$")
    public void userVerifyTheOrganizationForFirstRow(String data, String Menu) throws Throwable {
        key.pause("4", "");
        String vObjFirst_Row_CP = Constants.RFQOR.getProperty("First_Row_CP");
        vObjFirst_Row_CP = vObjFirst_Row_CP.replace("{uniqueMessageId}", data);
        if (Menu.equalsIgnoreCase("Organization")) {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirst_Row_CP, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjFirst_Row_CP, data));
        }
        if (Menu.equalsIgnoreCase("Provider")) {
            LogCapture.info("User Click on Organization Column ......");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirst_Row_CP, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjFirst_Row_CP, data));
        }
        if (Menu.equalsIgnoreCase("CurrencyPair")) {
            LogCapture.info("User Click on Organization Column ......");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirst_Row_CP, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjFirst_Row_CP, data));
        }
        if (Menu.equalsIgnoreCase("OFFSET")) {
            LogCapture.info("User Click on Organization Column ......");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirst_Row_CP, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjFirst_Row_CP, data));
        }
    }

    @When("^User click on Tablesorter for (ID|Organization|Provider|CurrencyPair|OFFSET|CUT_OFF_TIME|IS_B2B_ACTIVE|IS_RFQ_ACTIVE)$")
    public void userClickOnTablesorterForID(String Menu) throws Throwable {
        key.pause("4", "");
        String vObjectTableSorter = Constants.RFQOR.getProperty("TableSorter");
        if (Menu.equalsIgnoreCase("ID")) {
            LogCapture.info("User Click on ID Column ......");
            vObjectTableSorter = vObjectTableSorter.replace("{Text}", "ID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTableSorter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectTableSorter, ""));
        }
        if (Menu.equalsIgnoreCase("Organization")) {
            LogCapture.info("User Click on Organization Column ......");
            vObjectTableSorter = vObjectTableSorter.replace("{Text}", "Organization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTableSorter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectTableSorter, ""));
        }
        if (Menu.equalsIgnoreCase("Provider")) {
            LogCapture.info("User Click on Provider Column ......");
            vObjectTableSorter = vObjectTableSorter.replace("{Text}", "Provider");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTableSorter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectTableSorter, ""));
        }
        if (Menu.equalsIgnoreCase("CurrencyPair")) {
            LogCapture.info("User Click on CurrencyPair Column ......");
            vObjectTableSorter = vObjectTableSorter.replace("{Text}", "CurrencyPair");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTableSorter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectTableSorter, ""));
        }
        if (Menu.equalsIgnoreCase("OFFSET")) {
            LogCapture.info("User Click on OFFSET Column ......");
            vObjectTableSorter = vObjectTableSorter.replace("{Text}", "OFFSET");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTableSorter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectTableSorter, ""));
        }
        if (Menu.equalsIgnoreCase("CUT_OFF_TIME")) {
            LogCapture.info("User Click on OFFSET Column ......");
            vObjectTableSorter = vObjectTableSorter.replace("{Text}", "CUT_OFF_TIME");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTableSorter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectTableSorter, ""));
        }
        if (Menu.equalsIgnoreCase("IS_B2B_ACTIVE")) {
            LogCapture.info("User Click on OFFSET Column ......");
            vObjectTableSorter = vObjectTableSorter.replace("{Text}", "IS_B2B_ACTIVE");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTableSorter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectTableSorter, ""));
        }
        if (Menu.equalsIgnoreCase("IS_RFQ_ACTIVE")) {
            LogCapture.info("User Click on OFFSET Column ......");
            vObjectTableSorter = vObjectTableSorter.replace("{Text}", "IS_RFQ_ACTIVE");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectTableSorter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectTableSorter, ""));
        }
    }

    @Then("^User Search the bank Reference to get the MSL_ID from \"([^\"]*)\" DB$")
    public void userSearchTheBankReferenceToGetTheMSL_IDFromDB(String Environment) throws Throwable {
        key.pause("20", "");
        String MSL = Constants.key.VerifyDBDetails(Environment, BankRef, "Find the MSL_ID for Manual Entry");
        Constants.EODMSL_ID = MSL;
        Constants.Kafka_ID = MSL;
        LogCapture.info("MSL_ID : " + EODMSL_ID);
    }

    @And("^User click on Checkbox and click on Copy Of copyOfYES for \"([^\"]*)\" \"([^\"]*)\"$")
    public void userClickOnCheckboxAndClickOnCopyOfCopyOfYESFor(String Data_1, String Data_2) throws Throwable {
        key.pause("7", "");
        String vCheckbox = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_FirstRecordID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCheckbox, ""));
        Assert.assertEquals("PASS", Constants.key.click(vCheckbox, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vCheckbox, "RightClick"));
        key.pause("3", "");
        String vcopyOfYES = Constants.PaymentMonitoringOR.getProperty("copyOfYES");
        key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vcopyOfYES, ""));
        Assert.assertEquals("PASS", Constants.key.click(vcopyOfYES, ""));
        LogCapture.info("User Clicked on copy of Yes");
        key.pause("7", "");
        String VcopyOfYES_msg = Constants.PaymentMonitoringOR.getProperty("copyOfYES_msg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VcopyOfYES_msg, ""));
        String CopyOfYesMsg = Constants.key.getText(VcopyOfYES_msg);
        Assert.assertTrue(CopyOfYesMsg.contains(Data_1));
        Assert.assertTrue(CopyOfYesMsg.contains(Data_2));
        LogCapture.info("In copy of MT able to see correct Data " + Data_1 + " and  " + Data_2);
    }

    @Then("^User Disable the IS_B(\\d+)B_ACTIVE Toggle And Handle the Alert$")
    public void userDisableTheIS_BB_ACTIVEToggleAndHandleTheAlert(int arg0) throws Throwable {
        String VObjB2BSlider = Constants.RFQOR.getProperty("B2BSlider");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjB2BSlider, ""));
        Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(VObjB2BSlider, ""));

        String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
        System.out.println("Alert message is " + alertMessage);
        Assert.assertTrue(alertMessage.contains("DoyouwanttochangetheStatus?"));
        key.pause("1", "");
        LogCapture.info("User see alert message respective page......");

        String alertMessage1 = Constants.key.removeSpaces(Constants.key.getAlertText());
        System.out.println("Alert message is " + alertMessage);
        Assert.assertTrue(alertMessage1.contains("B2BIsInActive"));
    }

    @Then("^User verify the status of the payment$")
    public void userVerifyTheStatusOfThePayment() throws Throwable {
        Map<String, String> result1 = Reusables.getSqlQueryResult("PaymentID", Transaction_Reference);
        String PaymentStatus = result1.get("Status");
        LogCapture.info("Payment out Status is: " + PaymentStatus);
        Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
        if (PaymentStatus.equalsIgnoreCase("Processing")) {
            String vObjPendingMX = Constants.KafkaUI.getProperty("PendingMXstatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPendingMX, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjPendingMX, ""));
            String vObjApproved = Constants.KafkaUI.getProperty("Approvedstatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApproved, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjApproved, ""));
            String vObjReady = Constants.KafkaUI.getProperty("Readystatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReady, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjReady, ""));
        }
        if (PaymentStatus.equalsIgnoreCase("Approved")) {
            String vObjPendingMX = Constants.KafkaUI.getProperty("PendingMXstatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPendingMX, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjPendingMX, ""));
        }
    }

    @And("^User check the Streaming is available$")
    public void userCheckTheStreamingIsAvailable() throws Throwable {
        key.pause("5", "");
        String vObjRFQ_RBS_TimoutError = Constants.RFQOR.getProperty("RFQ_RBS_TimoutError");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjRFQ_RBS_TimoutError, ""));
    }

    @And("^User check the \"([^\"]*)\" column of the Table$")
    public void userCheckTheIsRepushAllowColumnOfTheTable(String Repush) throws Throwable {
        LogCapture.info("Checking the IsRepushAllow column value");
        String vObjIsRepushAllow = Constants.BankingOR.getProperty("IsRepushAllow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIsRepushAllow, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjIsRepushAllow, Repush));

    }

    @When("^User clicks on Repush Entry$")
    public void userClicksOnRepushEntry() throws Throwable {
        key.pause("5", "");
        LogCapture.info("Clicking on Repush Entry");
        String vObjIsRepushAllow = Constants.BankingOR.getProperty("IsRepushAllow");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjIsRepushAllow, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjIsRepushAllow, "RightClick"));
        String vObjRepushButton = Constants.BankingOR.getProperty("RepushButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRepushButton, ""));
        Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjRepushButton, ""));
    }

    @Then("^User Validates the Titan Response \"([^\"]*)\"$")
    public void userValidatesTheTitanResponse(String Response) throws Throwable {
        key.pause("50", "");
        Constants.driver.navigate().refresh();
        LogCapture.info("Checking the IsRepushAllow column value");
        String vObjTitanResponse = Constants.BankingOR.getProperty("TitanResponse");
        vObjTitanResponse = vObjTitanResponse.replace("{Response}", Response);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTitanResponse, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjTitanResponse, ""));
    }

    @And("^User checks if camt52 and camt53 got merged in ROF Queue$")
    public void userChecksIfCamtAndCamtGotMergedInROFQueue() {
        LogCapture.info("IntradayStatementLineID : " + IntradayStatementLineID + " StatementLineID : " + StatementLineID + " ROF ID : " + ROFQeueueID);

    }

    @And("^User checks if Duplicate ROF record is captured under PotentialDuplicateQueue page$")
    public void userChecksIfDuplicateROFRecordIsCapturedUnderPotentialDuplicateQueuePage() throws Exception {

//        String PDQ_ID=Constants.key.VerifyDBDetails(Environment, IntradayStatementLineID, "Find the PDQ ID for Indraday");
//        Constants.PDQ_ID=PDQ_ID;
//        LogCapture.info("PDQ ID is : " + Constants.PDQ_ID);


        key.pause("4", "");


        Constants.PDQ_ID = Constants.key.getText(Constants.BankingOR.getProperty("Latest_PDQ_ID"));
        LogCapture.info("Latest PDQ ID copied is :" + PDQ_ID);
        key.pause("4", "");

        String PDQ_ID_Filter = Constants.BankingOR.getProperty("PDQ_ID_Filter");
        Assert.assertEquals("PASS", Constants.key.writeInInput(PDQ_ID_Filter, PDQ_ID));
        LogCapture.info("Latest PDQ ID added in PDQ Filter");
        key.pause("4", "");

        String IntradayStatementLineIDFilter = Constants.BankingOR.getProperty("PDQ_IntradayStatementLineID_Filter");
        Assert.assertEquals("PASS", Constants.key.writeInInput(IntradayStatementLineIDFilter, IntradayStatementLineID));
        LogCapture.info(IntradayStatementLineID + " added in PDQ");
        key.pause("4", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(IntradayStatementLineIDFilter, "enter"));
        key.pause("4", "");
        LogCapture.info("PDQ Enter clicked");
    }

    @And("^User validate \"([^\"]*)\" and \"([^\"]*)\" Payment Status in DB for \"([^\"]*)\"$")
    public void userValidateAndPaymentStatusInDBFor(String state, String status, String Environment) throws Throwable {
        key.pause("10", "");
        String vobjstate = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "Payment State");
        Assert.assertEquals("PASS", Constants.key.VerifySubstring(vobjstate, state));
        String vobjstatus = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "Payment Status");
        Assert.assertEquals("PASS", Constants.key.VerifySubstring(vobjstatus, status));

    }

    @And("^User Validate the split Payment Entries and Amount$")
    public void userValidateTheSplitPaymentEntriesAndAmount(String menu) throws Throwable {
        Map<String, String> result = Reusables.getSqlQueryResult("AIPSplit", Kafka_ID);
        String Entiescount = result.get("Entires");
        String Totalmount = result.get("TotalAmount");
        LogCapture.info("Value of Enties count is: " + Entiescount);
        Assert.assertTrue(true, valueOf(Entiescount.contains("2")));
        LogCapture.info("Value of Total Amount is: " + Totalmount);
        Assert.assertTrue(true, valueOf(Totalmount.contains(Amount)));
    }

    @Then("^User submit the upload Confirmation for AIP payment$")
    public void userSubmitTheUploadConfirmationForAIPPayment() throws Throwable {
        key.pause("6", "");
        String vFirstEntry = Constants.MessageOR.getProperty("FirstEntry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vFirstEntry, "RightClick"));
        String vUploadConfirmation = Constants.MessageOR.getProperty("UploadConfirmation");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vUploadConfirmation, ""));
        Assert.assertEquals("PASS", Constants.key.click(vUploadConfirmation, ""));
        key.pause("6", "");
        String vAIPBatchReference = Constants.MessageOR.getProperty("AIPBatchReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vAIPBatchReference, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vAIPBatchReference, "Testing"));
        String vSubmitButton = Constants.MessageOR.getProperty("FPQSubmitButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSubmitButton, ""));
        Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vSubmitButton, ""));
    }

    @And("^User verify the \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userVerifyTheAnd(String PaymentType, String PaymentCode) throws Throwable {
        String vObjBNK_PaymentEntries_PaymentType = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_PaymentType");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBNK_PaymentEntries_PaymentType, PaymentType));
        String vObjBNK_PaymentEntries_PaymentCode = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_PaymentCode");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBNK_PaymentEntries_PaymentCode, PaymentCode));
    }

    @Then("^User verfiy the sent to bank status$")
    public void userVerfiyTheSentToBankStatus() throws Exception {
        key.pause("6", "");
        String vObjCheckStatus = Constants.MessageOR.getProperty("CheckStatus");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCheckStatus, "Sent"));
    }

    @And("^User validate Payment Status in DB for \"([^\"]*)\"$")
    public void userValidatePaymentStatusInDBFor(String Environment) throws Throwable {
        String vobjstatus = Constants.key.VerifyDBDetails(Environment, ID, "Payment Status");
        Assert.assertNotEquals("PASS", Constants.key.VerifySubstring(vobjstatus, "Processing"));
    }

    @Then("^User search the Payment Reference and submits the Record$")
    public void userSearchThePaymentReferenceAndSubmitsTheRecord() throws Throwable {
        key.pause("6", "");
        String vSenderRef_No = Constants.MessageOR.getProperty("SenderRef_No");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSenderRef_No, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSenderRef_No, Transaction_Reference));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSenderRef_No, "Enter"));
        key.pause("6", "");
        String vFirstEntry = Constants.MessageOR.getProperty("FirstEntry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFirstEntry, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFirstEntry, ""));
        key.pause("4", "");
        String vObjSubmitButton = Constants.MessageOR.getProperty("FPQSubmitButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSubmitButton, ""));
        Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vObjSubmitButton, ""));
        Alert alert = driver.switchTo().alert();
        alert.accept();
        LogCapture.info("User Submited Successfully......");
    }

    @Then("^user check the cutoff time for \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userCheckTheCutoffTimeForAnd(String Bank, String Organization, String Paymenttype, String Currency) throws Throwable {

        Map<String, String> result = Reusables.getSqlQueryResultDB("CUTTOFFTIME", Bank, Organization, Paymenttype, Currency);
        CutOffTimeEnd = result.get("CutOffTimeEnd");
        LogCapture.info("CutOffTimeEnd Original: " + CutOffTimeEnd);
    }

    @And("^User update the cutoff time to (zero|Original) for \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userUpdateTheCutoffTimeToZeroForAnd(String Menu, String Bank, String Organization, String Paymenttype, String Currency) throws Throwable {
        String CutOffTimeEndUpdated = "";
        if (Menu.equalsIgnoreCase("zero")) {
            Map<String, String> result1 = Reusables.getSqlQueryResultDB("CUTTOFFTIME_Update", "00:00:00.0000000", Bank, Organization, Paymenttype, Currency);
            Map<String, String> result2 = Reusables.getSqlQueryResultDB("CUTTOFFTIME", Bank, Organization, Paymenttype, Currency);
            CutOffTimeEndUpdated = result2.get("CutOffTimeEnd");

        }
        if (Menu.equalsIgnoreCase("Original")) {
            Map<String, String> result1 = Reusables.getSqlQueryResultDB("CUTTOFFTIME_Update", CutOffTimeEnd, Bank, Organization, Paymenttype, Currency);
            Map<String, String> result2 = Reusables.getSqlQueryResultDB("CUTTOFFTIME", Bank, Organization, Paymenttype, Currency);
            CutOffTimeEndUpdated = result2.get("CutOffTimeEnd");
        }
        LogCapture.info("CutOffTimeEnd Updated: " + CutOffTimeEndUpdated);
    }

    @When("^For ROF Accept a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Banking \"([^\"]*)\"$")
    public void forROFAcceptACallUserCheckStatusCodeAsForOnEnvironmentForBanking(String methodType, String statCode, String testCaseID, String Environment, String ClientAccountKey) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<ROFID>", ROFQeueueID);
        if (Legal_Entity != null) {
            DynamicValue.put("<LegalEntity>", Legal_Entity);
        } else {
            DynamicValue.put("<LegalEntity>", legal_entity);
        }
        DynamicValue.put("<ClientReference>", ClientAccountKey);
        if (Transaction_Reference == null) {
            DynamicValue.put("<PaymentReference>", "PET503825125");
        } else {
            DynamicValue.put("<PaymentReference>", Transaction_Reference);
        }

        LogCapture.info("----------------Started API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info(jp + "---------------POST call ended----------------");
        }
        LogCapture.info("----------------Ended API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
//        Assert.assertFalse(RESPONSE.contains("null"));
        JSONObject jsonObject = new JSONObject(RESPONSE);

        JSONObject responseStatusHeader = jsonObject.getJSONObject("responseStatusHeader");
        String description = responseStatusHeader.getString("description");
        Assert.assertTrue(description.equalsIgnoreCase("Success"));
        LogCapture.info("description : " + description);
    }

    @Then("^User validates if Record are merged for (Camt54|MT103|MT103Blank) and (Camt52|MT940|MT942|Camt53|MT103)$")
    public void userValidatesIfRecordAreMergedForCamt54AndCamt52(String value, String Data) throws Exception {
        if (value.equalsIgnoreCase("Camt54") && (Data.equalsIgnoreCase("Camt52") || Data.equalsIgnoreCase("MT942"))) {
            Assert.assertEquals(MSL_ID, IndradayMSL_ID);
        } else if (value.equalsIgnoreCase("MT103") && Data.equalsIgnoreCase("MT940")) {
            Assert.assertEquals(MSL_ID, EODMSL_ID);
        } else if (value.equalsIgnoreCase("MT103Blank") && Data.equalsIgnoreCase("MT103")) {
            String Environment = CONFIG.getProperty("Environment");
            String CreditAdviceid = Constants.key.VerifyDBDetails(Environment, ROF_ID, "CreditAdviceID from ROF_ID");
            Assert.assertNotEquals(CreditAdviceID, CreditAdviceid);
        }
        LogCapture.info("ROF " + value + " and " + Data + " are merged");
    }

    @Given("^Take a \"([^\"]*)\"\"([^\"]*)\"script the \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\" and update the file on \"([^\"]*)\"$")
    public void takeAScriptTheAndUpdateTheFileOn(String BankName, String PaymentInMethod, String Currency, String AccountNo, String AccountInfo, String Environment) throws Throwable {
        String PaymentIn = Constants.SQL_Queries.getProperty(BankName + PaymentInMethod);
        PaymentIn = PaymentIn.replace("\r\n", System.lineSeparator());
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMddMMdd");
        LocalDateTime now = LocalDateTime.now();
        Constants.currentDate = dtf.format(now);
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyMMdd");
        Constants.currentDate1 = dtf1.format(now);

        if (PaymentInAmount.equalsIgnoreCase("")) {
            Random random = new Random();
            double randomNumber = 10 + random.nextDouble() * (999 - 10);
            DecimalFormat decimalFormat = new DecimalFormat("#.00");
            String formattedNumber = decimalFormat.format(randomNumber);
            formattedNumber = formattedNumber.replace('.', ',');
            System.out.println("Random number with comma as decimal separator: " + formattedNumber);
            Constants.PaymentInAmount = formattedNumber;
        }

        if ((BankName + PaymentInMethod).equalsIgnoreCase("RBSMT103") || (BankName + PaymentInMethod).equalsIgnoreCase("BarclaysMT103") || (BankName + PaymentInMethod).equalsIgnoreCase("RBSMT103Blank")) {
            String newContent = Constants.SQL_Queries.getProperty(AccountInfo);
            newContent = newContent.replace("\r\n", System.lineSeparator());
            Constants.messageInQuery = PaymentIn.replace("{Date}", currentDate1).replace("{Amount}", PaymentInAmount).replace("{Currency}", Currency).replace("{AccountNo}", AccountNo).replace("{AccountInfo}", newContent);
        } else if ((BankName + PaymentInMethod).equalsIgnoreCase("BarclaysMT940") || (BankName + PaymentInMethod).equalsIgnoreCase("BarclaysMT942") || (BankName + PaymentInMethod).equalsIgnoreCase("BarclaysMT942_2")) {
            String newContent = Constants.SQL_Queries.getProperty(AccountInfo);
            newContent = newContent.replace("\r\n", System.lineSeparator());
            Constants.messageInQuery = PaymentIn.replace("{AccountInfo}", newContent).replace("{Date}", currentDate1).replace("{Date2}", currentDate).replace("{Amount}", PaymentInAmount).replace("{Currency}", Currency).replace("{AccountNo}", AccountNo);
        } else if ((BankName + PaymentInMethod).equalsIgnoreCase("RBSMT942") || (BankName + PaymentInMethod).equalsIgnoreCase("RBSMT940")) {
            Constants.messageInQuery = PaymentIn.replace("{Date}", currentDate1).replace("{Date2}", currentDate).replace("{Amount}", PaymentInAmount).replace("{Currency}", Currency).replace("{AccountNo}", AccountNo);
        }
        LogCapture.info(messageInQuery);

        String messageInId = Constants.key.VerifyDBDetails(Environment, "QueryForInsert", "Insert into MessageIn Table");
        LogCapture.info(BankName + " messageInId is " + messageInId);

        if (PaymentInMethod.contains("MT942") || PaymentInMethod.contains("MT942_2")) {
            MessageInIdMap.put("MessageInId for 52", messageInId); //to have a less variable for MT942 taken MessageInId for 52
        } else if (PaymentInMethod.contains("MT940")) {
            MessageInIdMap.put("MessageInId for 53", messageInId);
        } else if (PaymentInMethod.contains("MT103") || PaymentInMethod.contains("MT103Blank")) {
            MessageInIdMap.put("MessageInId for 103", messageInId);
        }
    }

    @Then("^User check the mail Notification by using \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userCheckTheMailNotificationByUsing(String emailAddress, String subject, String emailTask) throws Throwable {
        LogCapture.info("Validating email " + emailTask);
        String subjectContent = Reusables.getEmailUsingSubject(emailAddress, emailTask, subject);
        LogCapture.info("email Body : " + subjectContent);
        Assert.assertTrue(subjectContent.contains(idValue.toLowerCase()));
        LogCapture.info("Email Notification Validated..");
    }

    @Then("^User checks the Rule Engine status on Rule Engine page and change it to get Email Notification$")
    public void userChecksTheRuleEngineStatusOnRuleEnginePageAndChangeItToGetEmailNotification() throws Throwable {
        LogCapture.info("Rule Engine details data loading ......");
        key.pause("5", "");

        String vObjRuleEngineStatus = Constants.key.getText(Constants.RFQOR.getProperty("RFQ_RuleEngine_Status"));
        LogCapture.info("User check Rule Engine Status as " + vObjRuleEngineStatus + " from Rule Engine page ......");

        String vObjEnable = Constants.RFQOR.getProperty("RFQ_RuleEngine_CheckBox");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEnable, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjEnable, ""));
        Constants.driver.navigate().refresh();
        key.pause("10", "");
        vObjRuleEngineStatus = Constants.RFQOR.getProperty("RFQ_RuleEngine_Status");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRuleEngineStatus, ""));
        idValue = Constants.key.getText(vObjRuleEngineStatus);
        LogCapture.info("User Changed Rule Engine Status as " + idValue + " from Rule Engine page ......");
    }

    @And("^User update the \"([^\"]*)\" in xml file$")
    public void userUpdateTheInXmlFile(String AddtlNtryInf) throws ParserConfigurationException, IOException, SAXException, TransformerException, InterruptedException, Throwable {
        File NewCamtFile = new File("Files/" + Bank + "/" + NewFileName);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  // Using XML classes to modify file content
        DocumentBuilder builder = factory.newDocumentBuilder();
        Constants.doc1 = builder.parse(NewCamtFile);
        LogCapture.info(" Selected Document/File for updates is " + NewFileName);

        AddtlNtryInf = Constants.CONFIG.getProperty(AddtlNtryInf);
        Constants.key.updateXmlFile("AddtlNtryInf", AddtlNtryInf);

        LogCapture.info("Required Tags are modified for file: " + NewFileName);

        TransformerFactory transformerFactory = TransformerFactory.newInstance(); //Updated information send to local NewCamtFile
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc1);
        StreamResult result = new StreamResult(NewCamtFile);
        transformer.transform(source, result);
        LogCapture.info(" Updates are saved in document/file: " + NewFileName);
    }

    @Then("^User Validate the ISOCountryCode \"([^\"]*)\"$")
    public void userValidateTheISOCountryCode(String ISOCountryCode) throws Throwable {
        Assert.assertTrue(OriginatorISOCountryCode.contains(ISOCountryCode));
        LogCapture.info("Validated the OriginatorISOCountryCode as : " + OriginatorISOCountryCode);
    }

    @And("^User checks the ErrorCode & ErrorDescription$")
    public void userChecksTheErrorCodeErrorDescription() throws Exception {
        key.pause("3", "");
        String vErrorCode = Constants.PaymentMonitoringOR.getProperty("ErrorCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vErrorCode, ""));
        String vErrorCodeText = Constants.key.getText(vErrorCode);
        Assert.assertFalse(vErrorCodeText.contains("PMT-E007"));

    }

    @And("^Check (BARC|RBS|Yes|JPMG|CITI|AIP) for Extra Values \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void checkYesForExtraValues(String Data, String Organization, String customer_country_code, String sub_category, String charge_type, String Priority, String BIC_CODE, String remittance_information, String ordering_customer_name, String beneficiary_name, String purpose_of_transaction) throws Throwable {
        // line 140
        DynamicValue.put("<BIC_CODE>", BIC_CODE);
        Map<String, String> result = Reusables.getSqlQueryResult("TIPaymentDetail_GlobalRef");
        int value = Integer.parseInt(result.get("global_reference_id"));
        value += 1;
        globalreferenceid = String.valueOf(value);
        DynamicValue.put("<globalreferenceid>", globalreferenceid);
        if (Data.equalsIgnoreCase("BARC")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<customer_country_code>", customer_country_code);
            DynamicValue.put("<sub_category>", sub_category);
            DynamicValue.put("<charge_type>", charge_type);
            DynamicValue.put("<Priority>", Priority);
        }
        if (Data.equalsIgnoreCase("RBS")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<remittance_information>", remittance_information);
            DynamicValue.put("<purpose_of_transaction>", purpose_of_transaction);

        }
        if (Data.equalsIgnoreCase("Yes")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<remittance_information>", remittance_information);
            DynamicValue.put("<ordering_customer_name>", ordering_customer_name);
            DynamicValue.put("<beneficiary_name>", beneficiary_name);
            DynamicValue.put("<purpose_of_transaction>", purpose_of_transaction);
        }
        if (Data.equalsIgnoreCase("CITI")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("AIP")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("JPMG")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<Priority>", Priority);
            DynamicValue.put("<purpose_of_transaction>", purpose_of_transaction);
        }
    }

    @And("^User verifies Bank , \"([^\"]*)\" , State , Status$")
    public void userVerifiesBankStateStatus(String le) throws Throwable {
//        String vBank = Constants.PaymentMonitoringOR.getProperty("PaymentMonitoringBank");
//        Assert.assertEquals("PASS",Constants.key.VisibleConditionWait(vBank,""));
//        String vBankText = Constants.key.getText(vBank);
//        Assert.assertTrue(vBankText.contains("Yes Bank"));
//        LogCapture.info("Bank is :"+vBankText);
//
//        String vLegalEntity = Constants.PaymentMonitoringOR.getProperty("PaymentMonitoringLegalEntity");
//        Assert.assertEquals("PASS",Constants.key.VisibleConditionWait(vLegalEntity,""));
//        String vLegalEntityText = Constants.key.getText(vLegalEntity);
//        Assert.assertTrue((vLegalEntityText.contains("CDLGB")));
//        LogCapture.info("CLE is :"+vLegalEntityText);
//
//        String vLegalEntity1 = Constants.PaymentMonitoringOR.getProperty("PaymentMonitoringLegalEntity");
//        Assert.assertEquals("PASS",Constants.key.VisibleConditionWait(vLegalEntity1,""));
//        String vLegalEntityText1 = Constants.key.getText(vLegalEntity1);
//        Assert.assertTrue((vLegalEntityText1.contains("TORAU")));
//        LogCapture.info("CLE is :"+vLegalEntityText1);
        key.pause("3", "");
        if (le.equals("CDLGB") || le.equals("TORAU")) {
            String vState = Constants.PaymentMonitoringOR.getProperty("PaymentMonitoringState");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vState, ""));
            String vStateText = Constants.key.getText(vState);
            Assert.assertTrue((vStateText.contains("Failed")));
            LogCapture.info("State is :" + vStateText);

            String vStatus = Constants.PaymentMonitoringOR.getProperty("PaymentMonitoringStatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vStatus, ""));
            String vStatusText = Constants.key.getText(vStatus);
            Assert.assertTrue((vStatusText.contains("Rejected")));
            LogCapture.info("Status is :" + vStatusText);
        }
    }

    @Given("^User fetches the Latest ACH Direct Debit TransactionReference using ClientAccountKey \"([^\"]*)\"\"([^\"]*)\"$")
    public void userFetchesTheLatestACHDirectDebitTransactionReferenceUsingClientAccountKey(String ClientAccountKey, String Environment) throws Throwable {
        String TransactionReference = Constants.key.VerifyDBDetails(Environment, ClientAccountKey, "Fetch Latest ACH Direct Debit Transaction Reference Number");
        LogCapture.info("Latest ACH Direct Debit TransactionReference Number : " + TransactionReference);
        String vFirst = TransactionReference.split("-")[0].trim();
        int vLast = Integer.parseInt(TransactionReference.split("-")[1].trim()) + 1;
        String vLastest = String.format("%09d", vLast);
//        String vLastest=Integer.toString(result);
        String newTransactionReference = vFirst + "-" + vLastest;
        Constants.TransactionReferenceNumber = newTransactionReference;
        DynamicValue.put("<TransactionReferenceNumber>", TransactionReferenceNumber);
        LogCapture.info("New Transaction Reference Number : " + newTransactionReference);
        DynamicValue.put("<ClientAccountKey>", ClientAccountKey);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        DynamicValue.put("<currentDate>", currentDate);
        Map<String, String> result = Reusables.getSqlQueryResult("TIPaymentDetail_GlobalRef");
        int value = Integer.parseInt(result.get("global_reference_id"));
        value += 1;
        globalreferenceid = String.valueOf(value);
        DynamicValue.put("<globalreferenceid>", globalreferenceid);

    }

    @When("^For ACH Direct Debit a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Banking \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void forACHDirectDebitACallUserCheckStatusCodeAsForOnEnvironmentForBanking(String methodType, String statCode, String testCaseID, String Environment, String Organization, String Currency, String legal_entity, String debtorAccountNumber, String debtorCountrySpecificBankCode, String debtorBankBic) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<Organization>", Organization);
        DynamicValue.put("<Currency>", Currency);
        DynamicValue.put("<legal_entity>", legal_entity);
        DynamicValue.put("<debtorAccountNumber>", debtorAccountNumber);
        DynamicValue.put("<debtorCountrySpecificBankCode>", debtorCountrySpecificBankCode);
        DynamicValue.put("<debtorBankBic>", debtorBankBic);

        LogCapture.info("----------------Started API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        LogCapture.info("---------------POST call started----------------");
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        LogCapture.info(jp + "---------------POST call ended----------------");
    }

    @Then("^User checks the Toggle switch for (B2BIsActive|B2BInActive|RFQIsActive|RFQInActive) all Enabled$")
    public void userChecksTheToggleSwitchForBBIsActiveAllEnabled(String menu) throws Throwable {
        Constants.driver.navigate().refresh();
        key.pause("6", "");
        String vObjectCheckIsB2BAVorIAV1 = Constants.RFQOR.getProperty("Check" + menu);
        boolean isPresent = Reusables.isElementPresent(vObjectCheckIsB2BAVorIAV1);
        String vObjectCheckIsB2BAVorIAV2 = Constants.RFQOR.getProperty("Check" + menu + "2");
        boolean isPresent2 = Reusables.isElementPresent(vObjectCheckIsB2BAVorIAV2);
        if (isPresent || isPresent2) {
            System.out.println("Element is present.");
        } else {
            System.out.println("Element is not present.");
        }
    }

    @And("^User should successfully see alert message and (Accept|Reject) it$")
    public void userShouldSuccessfullySeeAlertMessageAndAcceptIt(String menu) throws Throwable {
        if (menu.equalsIgnoreCase("Accept")) {
            Constants.key.isAlertPresent();
            Constants.key.isAlertPresent();
        }
        if (menu.equalsIgnoreCase("Reject")) {
            Constants.key.isAlertReject();
        }
    }

    @And("^User click on (Book Deal) Button from (Spot Deal Booking) Page$")
    public void userClickOnBookDealButtonFromSpotDealBookingPage() throws Exception {
        key.pause("5", "");
        LogCapture.info("User Click on Book Deal ......");
        WebElement ele = Constants.driver.findElement(By.xpath("//*[@id='stopForwardDealRateTable']//tr[2]//td[16]//a//input[@id='bookDeal1']"));
        JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
        executor.executeScript("arguments[0].click();", ele);
//        WebElement ele=Constants.driver.findElement(By.xpath("//*[@id='stopForwardDealRateTable']//tr[4]//td[16]//a//input[@id='bookDeal1']"));
//        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", ele);
    }

    @And("^User right click on booked deal & click on deal details$")
    public void rightClickOnBookedDealClickOnDealDetails() throws Exception {
        LogCapture.info("right click on deal......");
        String eurSpotDeal = Constants.B2BOR.getProperty("eurSpot");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(eurSpotDeal, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(eurSpotDeal, "RightClick"));
        Constants.key.pause("2", "");
        LogCapture.info("User Click on Deal Details ......");
        String dealDetails = Constants.B2BOR.getProperty("viewDealDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(dealDetails, ""));
        Assert.assertEquals("PASS", Constants.key.click(dealDetails, ""));
        Constants.key.pause("5", "");
    }

    @And("^User verify the \"([^\"]*)\" from deal details$")
    public void userVerifyTheFromDealDetails(String data) throws Throwable {
        if (data.equalsIgnoreCase("EUR")) {
            String actBuyCurrency = data;
            String expBuyCurrencyEle = Constants.B2BOR.getProperty("buyCurrencyAfterDealBooking");
            String expBuyCurrency = Constants.driver.findElement(By.xpath(expBuyCurrencyEle)).getText();

            if (actBuyCurrency.equals(expBuyCurrency)) {
                Assert.assertTrue(true);
            } else {
                Assert.assertFalse(false);
            }
        } else if (data.equalsIgnoreCase("USD")) {
            String actSellCurrency = data;
            String expSellCurrencyEle = Constants.B2BOR.getProperty("sellCurrencyAfterDealBooking");
            String expBuyCurrency = Constants.driver.findElement(By.xpath(expSellCurrencyEle)).getText();

            if (actSellCurrency.equals(expBuyCurrency)) {
                Assert.assertTrue(true);
            } else {
                Assert.assertFalse(false);
            }
        } else {
            String actBuyAmt = data;
            String expBuyAmtEle = Constants.B2BOR.getProperty("buyAmountAfterDealBooking");
            String expBuyAmt = Constants.driver.findElement(By.xpath(expBuyAmtEle)).getText();

            if (actBuyAmt.equals(expBuyAmt)) {
                Assert.assertTrue(true);
            } else {
                Assert.assertFalse(false);
            }
        }
    }

    @And("^User give the \"([^\"]*)\" for (Spot Deal|Swap Deal|Limit Deal) Booking Page$")
    public void userGiveTheReasonForBooking(String rsn, String dealType) throws Throwable {
        if (dealType.equals("Spot Deal")) {
            Constants.key.pause("10", "");
            String reason = Constants.B2BOR.getProperty("giveReason");
            Constants.driver.findElement(By.xpath(reason)).sendKeys(rsn);
            Constants.key.pause("5", "");
        } else if (dealType.equals("Swap Deal")) {
            Constants.key.pause("10", "");
            String reason = Constants.B2BOR.getProperty("giveReason");
            Constants.driver.findElement(By.xpath(reason)).sendKeys(rsn);
            Constants.key.pause("5", "");
        } else if (dealType.equals("Limit Deal")) {
            Constants.key.pause("10", "");
            String reason = Constants.B2BOR.getProperty("giveReason");
            Constants.driver.findElement(By.xpath(reason)).sendKeys(rsn);
            Constants.key.pause("5", "");
        }
    }

    @And("^User verify the \"([^\"]*)\" in Load Panel for (Spot|Swap|Limit) Deal$")
    public void userVerifyInLoadPanel(String buyAmt, String dealType) throws Throwable {
        if (dealType.equals("Spot")) {
            Constants.key.pause("5", "");
            String actBuyAmt = buyAmt;
            String expBuyAmtEle = Constants.B2BOR.getProperty("buyAmountAfterDealBookingLoadPanel1");
            String expBuyAmt = Constants.driver.findElement(By.xpath(expBuyAmtEle)).getText();

            if (actBuyAmt.equals(expBuyAmt)) {
                Assert.assertTrue(true);
            } else {
                Assert.assertFalse(false);
            }
            Constants.key.pause("5", "");
        } else if (dealType.equals("Swap")) {
            Constants.key.pause("5", "");
            String actBuyAmt = buyAmt;
            String expBuyAmtEle = Constants.B2BOR.getProperty("buyAmountAfterDealBookingLoadPanel2");
            String expBuyAmt = Constants.driver.findElement(By.xpath(expBuyAmtEle)).getText();

            if (actBuyAmt.equals(expBuyAmt)) {
                Assert.assertTrue(true);
            } else {
                Assert.assertFalse(false);
            }
            Constants.key.pause("5", "");
        } else {
            Constants.key.pause("5", "");
            String actBuyAmt = buyAmt;
            String expBuyAmtEle = Constants.B2BOR.getProperty("buyAmountAfterDealBookingLoadPanel2");
            String expBuyAmt = Constants.driver.findElement(By.xpath(expBuyAmtEle)).getText();

            if (actBuyAmt.equals(expBuyAmt)) {
                Assert.assertTrue(true);
            } else {
                Assert.assertFalse(false);
            }
            Constants.key.pause("5", "");
        }
    }

    @And("^Verify order id and \"([^\"]*)\" in TradingDashBoardReport$")
    public void verifyOrderIdAndInTradingDashBoardReport(String buyCurrAmt) throws Throwable {
        if (buyCurrAmt.equals(buyCurrAmt)) {
            String actBuyAmt = buyCurrAmt;
            String expBuyAmtEle = Constants.B2BOR.getProperty("buyAmountTradingDashBoard");
            String expBuyAmt = Constants.driver.findElement(By.xpath(expBuyAmtEle)).getText();

            if (actBuyAmt.equals(expBuyAmt)) {
                Assert.assertTrue(true);
            } else {
                Assert.assertFalse(false);
            }
        } else {
            String actOrderID = vPaymentRef_no;
            String expBuyAmtEle = Constants.B2BOR.getProperty("B2BOrderIDFromTDBR");
            String expBuyAmt = Constants.driver.findElement(By.xpath(expBuyAmtEle)).getText();

            if (actOrderID.equals(expBuyAmt)) {
                Assert.assertTrue(true);
            } else {
                Assert.assertFalse(false);
            }
        }
    }

    @And("^User verify the (Spot deal|Swap deal|Swap Deal Booking|RAName & RANo|TI_CommonRestReq) data Populated data Populated in DB for (RBOS|JPMG9|DB|BARCLAYS) provider for \"([^\"]*)\"$")
    public void userVerifyTheSpotDealsDataPopulatedDataPopulatedInDBForRBOSProviderFor(String datas, String Provider, String values) throws Throwable {
        LogCapture.info("User verify DB Details ......");
        if (datas.equalsIgnoreCase("Spot deal") && Provider.equalsIgnoreCase("RBOS")) {
            Assert.assertEquals(values, Constants.key.VerifyDBDetails("UAT", dealID, "Verify Deal BuyAmount Details"));
        } else if (datas.equalsIgnoreCase("Swap deal") && Provider.equalsIgnoreCase("RBOS")) {
            Assert.assertEquals(values, Constants.key.VerifyDBDetails("UAT", dealID, "Verify Deal BuyAmount Details"));
        } else if (datas.equalsIgnoreCase("Swap deal") && Provider.equalsIgnoreCase("BARCLAYS")) {
            Assert.assertEquals(values, Constants.key.VerifyDBDetails("UAT", dealID, "Verify Deal BuyAmount Details"));
        } else if (datas.equalsIgnoreCase("Spot deal") && Provider.equalsIgnoreCase("BARCLAYS")) {
            Assert.assertEquals(values, Constants.key.VerifyDBDetails("UAT", dealID, "Verify Deal BuyAmount Details"));
        } else if (datas.equalsIgnoreCase("Swap Deal Booking") && Provider.equalsIgnoreCase("BARCLAYS")) {
            LogCapture.info("Latest Buying Amount From Feature File is ......" + values);
            Assert.assertEquals(values, Constants.key.VerifyDBDetails("SIT", dealID, "Verify Deal BuyAmount Details"));
        } else if (datas.equalsIgnoreCase("RAName & RANo") && Provider.equalsIgnoreCase("JPMG9") && values.equalsIgnoreCase("MR PASCAL ERIC INARD")) {
            Assert.assertEquals(values, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify Remitter Accounts Name for Not Null"));
        } else if (datas.equalsIgnoreCase("RAName & RANo") && Provider.equalsIgnoreCase("JPMG9") && values.equalsIgnoreCase("563990036")) {
            System.out.println("values-->>" + values);
            Assert.assertEquals(values, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify Remitter Accounts Number for Not Null"));
        } else if (datas.equalsIgnoreCase("RAName & RANo") && Provider.equalsIgnoreCase("JPMG9") && values.equalsIgnoreCase("")) {
            Assert.assertEquals(values, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify Remitter Accounts Name for Null"));
        }
    }

    @And("^User enters the OrderID in TradingDashBoardReport to find dealID for (Spot Deal|SwapNearLeg Deal|SwapFarLeg Deal) Booking$")
    public void userEntersTheOrderIDInTradingDashBoardReportToFindDealID(String dealType) throws Exception {
        if (dealType.equalsIgnoreCase("Spot Deal")) {
            Constants.key.pause("7", "");
            LogCapture.info("User Click and Enter Order ID.....");
            String orderID = vPaymentRef_no;
            String eleOrderID = Constants.B2BOR.getProperty("orderIdPath");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(eleOrderID, ""));
            Assert.assertEquals("PASS", Constants.key.click(eleOrderID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(eleOrderID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(eleOrderID, orderID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(eleOrderID, "enter"));
            Constants.key.pause("5", "");
        } else if (dealType.equalsIgnoreCase("SwapNearLeg Deal")) {
            Constants.key.pause("7", "");
            LogCapture.info("User Click and Enter Order ID.....");
            String orderID = vPaymentRef_no;
            String eleOrderID = Constants.B2BOR.getProperty("orderIdPath");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(eleOrderID, ""));
            Assert.assertEquals("PASS", Constants.key.click(eleOrderID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(eleOrderID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(eleOrderID, orderID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(eleOrderID, "enter"));
            Constants.key.pause("5", "");
        } else if (dealType.equalsIgnoreCase("SwapFarLeg Deal")) {
            Constants.key.pause("7", "");
            LogCapture.info("User Click and Enter Order ID.....");
            String orderID = vPaymentRef_no;
            String eleOrderID = Constants.B2BOR.getProperty("orderIdPath");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(eleOrderID, ""));
            Assert.assertEquals("PASS", Constants.key.click(eleOrderID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(eleOrderID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(eleOrderID, orderID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(eleOrderID, "enter"));
            Constants.key.pause("5", "");
        }
    }

    @And("^User gets the dealID as dealNumber from OrderID in TradingDashBoardReport for (Spot Deal|SwapNearLeg Deal|SwapFarLeg Deal) Booking$")
    public void UsergetsthedealIDasdealNumberfromOrderIDInTradingDashBoardReport(String dealType) throws InterruptedException {
        if (dealType.equalsIgnoreCase("SwapNearLeg Deal")) {
            key.pause("5", "");
            dealID = Constants.driver.findElement(By.xpath("(//*[@id=\"tradeDetailsDIV\"]/tbody/tr[1]/td[19])[1]")).getText();
            System.out.println("SwapNearLeg_dealID-->>" + dealID);
            Constants.key.pause("2", "");
        } else if (dealType.equalsIgnoreCase("SwapFarLeg Deal")) {
            key.pause("5", "");
            dealID = Constants.driver.findElement(By.xpath("(//*[@id=\"tradeDetailsDIV\"]/tbody/tr[1]/td[19])[2]")).getText();
            System.out.println("SwapFarLeg_dealID-->>" + dealID);
            Constants.key.pause("2", "");
        } else if (dealType.equalsIgnoreCase("Spot Deal")) {
            key.pause("7", "");
            dealID = Constants.driver.findElement(By.xpath("//*[@id=\"tradeDetailsDIV\"]/tbody/tr/td[19]")).getText();
            System.out.println("Spot_dealID-->>" + dealID);
            Constants.key.pause("2", "");
        }
    }

    @And("^User Tear Down the Browser$")
    public void userTearDownTheBrowser() throws InterruptedException {
        Constants.key.pause("5", "");
        Constants.driver.quit();
    }

    @And("^User Close the Audit Trails Popup$")
    public void userCloseTheAuditTrailsPopup() throws InterruptedException {
        Constants.key.pause("2", "");
        LogCapture.info("User Close the Audit Trial Popup.....");
        Constants.driver.findElement(By.xpath("//*[@id=\"popupAudit\"]/div/center[2]/input")).click();
        Constants.key.pause("5", "");
    }

    @And("^User enters (RecordID|TransactionReference|Transaction_Reference) for checking of (Audit Trial Details) from Payment Approval page$")
    public void userEntersRecordIDForCheckingOfAuditTrialFromPaymentApprovalPage(String data, String ATD) throws Exception {
        if (data.equalsIgnoreCase("RecordID")) {
            Constants.key.pause("7", "");
            LogCapture.info("User Click and Enter RecordID.....");
            String recordID = PaymentApprovalRecordID;
            String eleRecordID = Constants.B2BOR.getProperty("recordIDPath");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(eleRecordID, ""));
            Assert.assertEquals("PASS", Constants.key.click(eleRecordID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(eleRecordID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(eleRecordID, recordID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(eleRecordID, "enter"));
            Constants.key.pause("5", "");
        } else if (data.equalsIgnoreCase("TransactionReference")) {
            Constants.key.pause("7", "");
            LogCapture.info("User Click and Enter TransanctionReference.....");
            String transanctionID = Transaction_Reference;
            System.out.println("TransactionReference--->>>" + Transaction_Reference);
            String elePaymentID = Constants.B2BOR.getProperty("paymentRefPath");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(elePaymentID, ""));
            Assert.assertEquals("PASS", Constants.key.click(elePaymentID, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(elePaymentID));
            Assert.assertEquals("PASS", Constants.key.writeInInput(elePaymentID, transanctionID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(elePaymentID, "enter"));
            Constants.key.pause("5", "");
        } else if (data.equalsIgnoreCase("Transaction_Reference")) {
            Constants.key.pause("7", "");
            LogCapture.info("User Click and Enter TransanctionReference.....");
            System.out.println("TransactionReference--->>>" + Transaction_Reference);
            String elePaymentID = Constants.B2BOR.getProperty("paymentRefPath");
            Assert.assertEquals("PASS", Constants.key.writeInInput(elePaymentID, Transaction_Reference));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(elePaymentID, "enter"));
            Constants.key.pause("5", "");
        }
    }

    @Then("^User Verify the (Audit Trails Details) on Payment Approval page for (FirstUser|SecondUser|ThirdUser)$")
    public void userVerifyTheAuditTrailsDetailsOnPaymentApprovalPage(String data, String userApprovals) throws Exception {
        if (userApprovals.equalsIgnoreCase("FirstUser")) {
            LogCapture.info("Audit Trails Details loading ......");

            String vBanking_PaymentMonitoring_AuditTrailMessageNo = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailMessageNo");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_AuditTrailMessageNo, ""));
            String vBanking_PaymentMonitoring_AuditTrailMessageNoText = key.getText(vBanking_PaymentMonitoring_AuditTrailMessageNo);
            if (vBanking_PaymentMonitoring_AuditTrailMessageNoText.equalsIgnoreCase("PAIN.001")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageNo, "PAIN.001"));
            } else if (vBanking_PaymentMonitoring_AuditTrailMessageNoText.equalsIgnoreCase("MT103")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageNo, "MT103"));
            }
            String vBanking_PaymentMonitoring_AuditTrailMessageType = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailMessageType");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageType, "Message"));
            String vBanking_PaymentMonitoring_AuditTrailDirection = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailDirection");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailDirection, "Received"));
            String vBanking_PaymentMonitoring_AuditTrailUsername = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailUsername");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailUsername, "cd_api_user"));
            String vBanking_PaymentMonitoring_AuditTrailAction = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailAction");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailAction, "OTHER"));
        } else if (userApprovals.equalsIgnoreCase("SecondUser")) {
            LogCapture.info("Audit Trails Details loading ......");

            String vBanking_PaymentMonitoring_AuditTrailMessageNo = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailMessageNo");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_AuditTrailMessageNo, ""));
            String vBanking_PaymentMonitoring_AuditTrailMessageNoText = key.getText(vBanking_PaymentMonitoring_AuditTrailMessageNo);
            if (vBanking_PaymentMonitoring_AuditTrailMessageNoText.equalsIgnoreCase("PAIN.001")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageNo, "PAIN.001"));
            } else if (vBanking_PaymentMonitoring_AuditTrailMessageNoText.equalsIgnoreCase("MT103")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageNo, "MT103"));
            }
            String vBanking_PaymentMonitoring_AuditTrailMessageType = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailMessageType");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageType, "Message"));
            String vBanking_PaymentMonitoring_AuditTrailDirection = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailDirection");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailDirection, "Received"));
            String vBanking_PaymentMonitoring_AuditTrailUsername = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailUsername");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailUsername, "cd.bank.su"));
            String vBanking_PaymentMonitoring_AuditTrailAction = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailAction");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailAction, "APPROVE_FROM_APPROVAL_QUEUE"));
        } else if (userApprovals.equalsIgnoreCase("ThirdUser")) {
            LogCapture.info("Audit Trails Details loading ......");

            String vBanking_PaymentMonitoring_AuditTrailMessageNo = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailMessageNo");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_AuditTrailMessageNo, ""));
            String vBanking_PaymentMonitoring_AuditTrailMessageNoText = key.getText(vBanking_PaymentMonitoring_AuditTrailMessageNo);
            if (vBanking_PaymentMonitoring_AuditTrailMessageNoText.equalsIgnoreCase("PAIN.001")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageNo, "PAIN.001"));
            } else if (vBanking_PaymentMonitoring_AuditTrailMessageNoText.equalsIgnoreCase("MT103")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageNo, "MT103"));
            }
            String vBanking_PaymentMonitoring_AuditTrailMessageType = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailMessageType");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailMessageType, "Message"));
            String vBanking_PaymentMonitoring_AuditTrailDirection = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailDirection");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailDirection, "Received"));
            String vBanking_PaymentMonitoring_AuditTrailUsername = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailUsername");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailUsername, "nilam.bagate"));
            String vBanking_PaymentMonitoring_AuditTrailAction = Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_AuditTrailAction");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_PaymentMonitoring_AuditTrailAction, "APPROVE_FROM_APPROVAL_QUEUE"));
        }
    }

    @And("^apply filter at Source on payment approval page for (manual|titan)$")
    public void applyFilterAtSourceOnPaymentApprovalPageForManual(String sourceType) throws Exception {
        if (sourceType.equals("titan")) {
            String vBNK_PaymentApproval_SelectSource = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SelectSource");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SelectSource, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_PaymentApproval_SelectSource, "Titan"));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        } else if (sourceType.equals("manual")) {
            String vBNK_PaymentApproval_SelectSource = Constants.PaymentMonitoringOR.getProperty("BNK_PaymentApproval_SelectSource");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PaymentApproval_SelectSource, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBNK_PaymentApproval_SelectSource, "Manual"));
            String vPageLoader = Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
        }
    }

    @And("^User verify the (Remitter Account Name & Remitter Account Number|TI_CommonRestReq) in DB for \"([^\"]*)\"$")
    public void userVerifyTheRemitterAccountNameAndRemitterAccountNumberInDB(String vData, String environment) throws Exception {
        LogCapture.info("User verify DB Details ......");
        String data1 = null;
        String data2 = null;
        String TICR = null;
        if (vData.equalsIgnoreCase("TI_CommonRestReq")) {
            Assert.assertEquals(data1, Constants.key.VerifyDBDetails("UAT", StatementLineID, "Verify TI_CRQ Massage Details"));
        } else {
            Assert.assertEquals(data1, Constants.key.VerifyDBDetails("UAT", StatementLineID, "Verify Remitter Account Name Details"));
        }
    }

    @And("^User verify Remitter Account name and Remitter account Number for \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userVerifyRemitterAccountNameAndRemitterAccountNumberFor(String Bank, String FileType, String Environment) throws Throwable {
        String remitterCheck = Constants.key.VerifyDBDetails(Environment, StatementLineID, "Validating remitter account name and remitter account number for SLID");
        LogCapture.info("remitter Account info: validating remitter account name and remitter account number");
        LogCapture.info("remitterCheck table is :" + remitterCheck);
        try {
            Assert.assertTrue(remitterCheck.isEmpty());
        } catch (Exception e) {
            LogCapture.info("remitterCheck table is : Empty");
        }
    }

    @And("^User verify the (Remitter Account name|Remitter account Number|TI_CommRequestMsg|OriginalISOCountryCode) is captured correctly for \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\" for StatementLineID with \"([^\"]*)\"$")
    public void userVerifyTheRemitterAccountNameAndRemitterAccountNumberIsCapturedCorrectlyForSLID(String data, String Bank, String FileType, String Environment, String remDetails) throws Throwable {
        if (data.equalsIgnoreCase("Remitter Account name") && Environment.equalsIgnoreCase("SIT")) {
            if (remDetails.isEmpty()) {
                remDetails = null;
                LogCapture.info("Remitter Account Name from Feature File-->>" + remDetails);
                Constants.key.pause("5", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify RemitterAccountNameNull Details"));
            } else {
                LogCapture.info("Remitter Account Name from Feature File-->>" + remDetails);
                Constants.key.pause("5", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify RemitterAccountName Details"));
            }
        } else if (data.equalsIgnoreCase("Remitter account Number") && Environment.equalsIgnoreCase("SIT")) {
            if (remDetails.isEmpty()) {
                remDetails = null;
                LogCapture.info("Remitter Account Number from Feature File-->>" + remDetails);
                Constants.key.pause("7", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify RemitterAccountNumberNull Details"));
            } else {
                LogCapture.info("Remitter Account Number from Feature File-->>" + remDetails);
                Constants.key.pause("7", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify RemitterAccountNumber Details"));
            }
        } else if (data.equalsIgnoreCase("OriginalISOCountryCode") && Environment.equalsIgnoreCase("SIT")) {
            if (remDetails.isEmpty()) {
                remDetails = null;
                LogCapture.info("OriginalISOCountryCode from Feature File-->>" + remDetails);
                Constants.key.pause("7", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify ISO Country Code Null"));
            } else {
                LogCapture.info("OriginalISOCountryCode from Feature File-->>" + remDetails);
                Constants.key.pause("7", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("SIT", StatementLineID, "Verify ISO Country Code"));
            }
        } else if (data.equalsIgnoreCase("Remitter Account name") && Environment.equalsIgnoreCase("UAT")) {
            if (remDetails.isEmpty()) {
                remDetails = null;
                LogCapture.info("Remitter Account Name from Feature File-->>" + remDetails);
                Constants.key.pause("5", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("UAT", StatementLineID, "Verify RemitterAccountNameNull Details"));
            } else {
                LogCapture.info("Remitter Account Name from Feature File-->>" + remDetails);
                Constants.key.pause("5", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("UAT", StatementLineID, "Verify RemitterAccountName Details"));
            }
        } else if (data.equalsIgnoreCase("Remitter account Number") && Environment.equalsIgnoreCase("UAT")) {
            if (remDetails.isEmpty()) {
                remDetails = null;
                LogCapture.info("Remitter Account Number from Feature File-->>" + remDetails);
                Constants.key.pause("7", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("UAT", StatementLineID, "Verify RemitterAccountNumberNull Details"));
            } else {
                LogCapture.info("Remitter Account Number from Feature File-->>" + remDetails);
                Constants.key.pause("7", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("UAT", StatementLineID, "Verify RemitterAccountNumber Details"));
            }
        } else if (data.equalsIgnoreCase("OriginalISOCountryCode") && Environment.equalsIgnoreCase("UAT")) {
            if (remDetails.isEmpty()) {
                remDetails = null;
                LogCapture.info("OriginalISOCountryCode from Feature File-->>" + remDetails);
                Constants.key.pause("7", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("UAT", StatementLineID, "Verify ISO Country Code Null"));
            } else {
                LogCapture.info("OriginalISOCountryCode from Feature File-->>" + remDetails);
                Constants.key.pause("7", "");
                Assert.assertEquals(remDetails, Constants.key.VerifyDBDetails("UAT", StatementLineID, "Verify ISO Country Code"));
            }
        }
    }

    @Then("^Get the order id for (Spot|Swap) deal to verify in TradingDashBoardReport$")
    public void getTheOrderIdToForSpotSwapVerifyInTradingDashBoardReport(String dealType) throws Throwable {
        key.pause("7", "");
        if (dealType.equals("Spot")) {
            String BuyAmtDate = Constants.RFQOR.getProperty("B2BOrderID1");
            vPaymentRef_no = Constants.driver.findElement(By.xpath(BuyAmtDate)).getText();
            LogCapture.info("Taking the Order ID For Spot Deal ......" + vPaymentRef_no);
        } else if (dealType.equals("Swap")) {
            String BuyAmtDate = Constants.RFQOR.getProperty("B2BOrderID2");
            vPaymentRef_no = Constants.driver.findElement(By.xpath(BuyAmtDate)).getText();
            LogCapture.info("Taking the Order ID For Swap Deal......" + vPaymentRef_no);
        }
    }

    @And("^User Validate the \"([^\"]*)\" and \"([^\"]*)\" of (First|Second) Paymentout$")
    public void userValidateTheStateAndStatusOfStPaymentout(String state, String status, String PayOut) throws InterruptedException {
        key.pause("40", "");
        driver.navigate().refresh();
        if (PayOut.equals("First")) {
            String stateEle = Constants.B2BOR.getProperty("statePayOut2");
            String actualState = Constants.driver.findElement(By.xpath(stateEle)).getText();
            String statusEle = Constants.B2BOR.getProperty("statusPayOut2");
            String actualStatus = Constants.driver.findElement(By.xpath(statusEle)).getText();
            LogCapture.info("actualState From UI-->>" + actualState);
            LogCapture.info("expectedState From Feature File-->>" + state);
            Assert.assertEquals(actualState, state);
            Assert.assertEquals(actualStatus, status);
        } else if (PayOut.equals("Second")) {
            String stateEle = Constants.B2BOR.getProperty("statePayOut1");
            String actualState = Constants.driver.findElement(By.xpath(stateEle)).getText();
            String statusEle = Constants.B2BOR.getProperty("statusPayOut1");
            String actualStatus = Constants.driver.findElement(By.xpath(statusEle)).getText();
            LogCapture.info("actualState From UI-->>" + actualState);
            LogCapture.info("expectedState From Feature File-->>" + state);
            Assert.assertEquals(actualState, state);
            Assert.assertEquals(actualStatus, status);
        }
    }


    @And("^User validate \"([^\"]*)\" and \"([^\"]*)\" Payment Status in DB for \"([^\"]*)\" for Exchangeforfree$")
    public void userValidateAndPaymentStatusInDBForForExchangeforfree(String state, String status, String Environment) throws Throwable {
        key.pause("10", "");
        String vobjstate = Constants.key.VerifyDBDetails(Environment, "2405101031204205", "Payment State");
        Assert.assertEquals("PASS", Constants.key.VerifySubstring(vobjstate, state));
        String vobjstatus = Constants.key.VerifyDBDetails(Environment, "2405101031204205", "Payment Status");
        Assert.assertEquals("PASS", Constants.key.VerifySubstring(vobjstatus, status));
    }

    @And("^User select the (Value Date) and Click on (Approval All|Donot) Payment Button$")
    public void userSelectTheValueDateAndClickOnApprovalAllPaymentBtn(String vDate, String btn) throws Exception {
        if (btn.equals("Approval All")) {
            String valueDateBox = Constants.PaymentMonitoringOR.getProperty("valueDateBox1");
            Assert.assertEquals("PASS", Constants.key.click(valueDateBox, ""));
            Date date = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("d");
            String strDate = formatter.format(date);
            List<WebElement> dateElements = Constants.driver.findElements(By.xpath("//table[@class=\"month1\"]//td"));
            for (WebElement dateElement : dateElements) {
                if (dateElement.getText().equals(strDate)) {
                    Actions act = new Actions(driver);
                    act.doubleClick(dateElement).perform();
                    break;
                }
            }
            key.pause("2", "");
            String approveAllBtn = Constants.PaymentMonitoringOR.getProperty("approveAllPay");
            Assert.assertEquals("PASS", Constants.key.click(approveAllBtn, ""));
        } else {
            key.pause("7", "");
            String valueDateBox = Constants.PaymentMonitoringOR.getProperty("valueDateBox2");
            Assert.assertEquals("PASS", Constants.key.click(valueDateBox, ""));
            Date date = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("d");
            String strDate = formatter.format(date);
            List<WebElement> dateElements = Constants.driver.findElements(By.xpath("//table[@class=\"month1\"]//td"));
            for (WebElement dateElement : dateElements) {
                if (dateElement.getText().equals(strDate)) {
                    Actions act = new Actions(driver);
                    act.doubleClick(dateElement).perform();
                    break;
                }
            }
        }
    }

    @And("^User enter the (dealID) in PendingB2B Menu$")
    public void userEnterThedealIDPendingB2BMenu(String data) throws Throwable {
        Constants.key.pause("7", "");
        LogCapture.info("User Click and Enter dealID in PendingB2B.....");
        String spotDealID = dealID;
        String spotDealIDEle = Constants.B2BOR.getProperty("dealNumberPendingB2B");
        Assert.assertEquals("PASS", Constants.key.click(spotDealIDEle, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(spotDealIDEle, spotDealID));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(spotDealIDEle, "enter"));
        Constants.key.pause("5", "");
    }

    @And("^User Right Click on (MessageOutID) and Click on (Download Payment file)$")
    public void userRightClickAndDownloadPaymentFile(String id, String check) throws Exception {
        Constants.key.pause("5", "");
        String vFirstEntry = Constants.MessageOR.getProperty("msgOut_ID_Entry");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vFirstEntry, "RightClick"));
        Constants.key.pause("5", "");
        String vFirstEntry2 = Constants.MessageOR.getProperty("DownloadFile");
        Assert.assertEquals("PASS", Constants.key.click(vFirstEntry2, ""));
        Constants.key.pause("5", "");
    }

    @And("^User Verify (AIP First Party|AIP Third Party) Payment File Name as \"([^\"]*)\"$")
    public void userVerifyFileNameAs(String type, String data) throws Throwable {
        LogCapture.info("Validating File Name");
        String oSName = System.getProperty("os.name");
        String downloadPath = "";
        String fileName = data;
        if (oSName.toUpperCase().contains("WIN")) {
            downloadPath = System.getProperty("user.home") + "/Downloads/";
            File dir = new File(downloadPath);
            File[] dir_contents = dir.listFiles();
            boolean fileFound = false;
            for (File files : dir_contents) {
                if (files.getName().contains(fileName)) {
                    fileFound = true;
                    files.delete();
                    break;
                }
            }
        } else {
            downloadPath = System.getProperty("user.dir") + "/Downloads/";
            File dir = new File(downloadPath);
            File[] dir_contents = dir.listFiles();
            boolean fileFound = false;
            for (File files : dir_contents) {
                if (files.getName().contains(fileName)) {
                    fileFound = true;
                    files.delete();
                    break;
                }
            }
        }
    }

    @And("^User should handle the alert popup (One|Two) times$")
    public void userShouldHandleAlertPopup(String alerts) throws InterruptedException {
        if (alerts.equalsIgnoreCase("One")) {
            Alert alert = driver.switchTo().alert();
            alert.accept();
            key.pause("5", "");
        } else {
            Alert alert1 = driver.switchTo().alert();
            alert1.accept();
            key.pause("3", "");
            Alert alert2 = driver.switchTo().alert();
            alert2.accept();
        }
    }

    @And("^User click on (Organization|Provider|CurrencyPair) and Select \"([^\"]*)\" from CounterParty SubMenu$")
    public void userClickAndSelectDataFromCounterParty(String data1, String data2) throws Exception {
        if (data2.equalsIgnoreCase("Currencies Direct")) {
            LogCapture.info("User select Organization Currencies Direct ......");
            String vObjOrganization = Constants.RFQOR.getProperty("RFQ_Orgn");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrganization, ""));
            key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjOrganization, data2));
            key.pause("3", "");
        } else if (data2.equalsIgnoreCase("BARCLAYS")) {
            LogCapture.info("User select Provider ......");
            String vObjProvider = Constants.RFQOR.getProperty("RFQ_Provr");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProvider, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjProvider, ""));
            key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjProvider, data2));
            key.pause("3", "");
        } else if (data2.equalsIgnoreCase("EURUSD")) {
            LogCapture.info("User select CurrencyPair ......");
            String vObjCurrenciesPair = Constants.RFQOR.getProperty("RFQ_CurrenciesPair");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesPair, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCurrenciesPair, ""));
            key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjCurrenciesPair, data2));
            key.pause("3", "");
        }
    }

    @And("^User user donot want to change the status then click on Cancel Button for \"([^\"]*)\" and Handle Alert for \"([^\"]*)\"$")
    public void userUserDonotWantToChangeTheStatusThenClickOnCancelButtonForAndHandleAlertFor(String alert3, String alert4) throws Throwable {
        String vobjB2BDisable = Constants.RFQOR.getProperty("RFQ_ChangeStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjB2BDisable, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjB2BDisable, ""));
        key.pause("3", "");

        if (alert3.equalsIgnoreCase("Do you want to change")) {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (alertText.contains(alert3)) {
                alert.dismiss();
            }
            key.pause("3", "");
        } else if (alert3.equalsIgnoreCase("Status Not Changed")) {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (alertText.contains(alert4)) {
                alert.accept();
            }
            key.pause("3", "");
        }
    }

    @And("^User clicks on Filter option in ROF Queue and paste ROF ID and Accept and Select Re-Route Action for WhiteList ON Type (Payee|LocalCode|One-Off|Payee Error Message)$")
    public void userClicksOnFilterOptionInROFQueueAndPasteROFIDAndAcceptAndSelectReRouteAction(String WhiteListONType) throws Exception {
        key.pause("4", "");
        String CDROF_ID = Constants.BankingOR.getProperty("StatementLineID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CDROF_ID, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CDROF_ID, StatementLineID));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CDROF_ID, "enter"));
        key.pause("4", "");
        String vROFQueueCheckbox = Constants.BankingOR.getProperty("BNKROFQueueCheckbox");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueCheckbox, ""));
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueCheckbox, ""));

        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vROFQueueCheckbox, "RightClick"));
        key.pause("4", "");
        LogCapture.info("Checkbox Right-clicked");

        String vROFQueueAccept = Constants.BankingOR.getProperty("BNKROFQueueAccept");
        Assert.assertEquals("PASS", Constants.key.click(vROFQueueAccept, ""));
        key.pause("4", "");

        Alert alert = driver.switchTo().alert();
        alert.accept();
        Constants.key.pause("6", "");

        String vROFActionDropDown = Constants.BankingOR.getProperty("ROFActionDropDown");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vROFActionDropDown, "Re-Route"));
        LogCapture.info(" Re-Route selected");
        Constants.key.pause("6", "");
        if (WhiteListONType.equalsIgnoreCase("Payee")) {
            String vBNKROFAcceptWhiteListON = Constants.BankingOR.getProperty("BNKROFAcceptWhiteListON_Payee");
            Assert.assertEquals("PASS", Constants.key.click(vBNKROFAcceptWhiteListON, ""));
            key.pause("6", "");

            LogCapture.info(" Payment Reference From Payment Out is: " + Transaction_Reference);
            String BNKROFQueuePaymentReference = Constants.BankingOR.getProperty("BNKROFQueuePaymentRef");
            Assert.assertEquals("PASS", Constants.key.writeInInput(BNKROFQueuePaymentReference, Transaction_Reference));
            Constants.key.pause("4", "");

            String vROFQueueReasonOfROF = Constants.BankingOR.getProperty("BNKROFQueueRsnOfROF");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReasonOfROF, "Test ROF"));
            LogCapture.info(" ROF Queue Reason Of ROF = Test ROF is entered on UI");
            Constants.key.pause("4", "");

            String vROFQueueSubmit = Constants.BankingOR.getProperty("BNKROFQueueSubmit");
            Assert.assertEquals("PASS", Constants.key.click(vROFQueueSubmit, ""));
            LogCapture.info(" User click on ROF Queue Submit Button");
            Constants.key.pause("4", "");

            Alert alert1 = driver.switchTo().alert();
            alert1.accept();
            Constants.key.pause("5", "");
        } else if (WhiteListONType.equalsIgnoreCase("LocalCode")) {

            String vBNKROFAcceptWhiteListON = Constants.BankingOR.getProperty("BNKROFAcceptWhiteListON_LocalCode");
            Assert.assertEquals("PASS", Constants.key.click(vBNKROFAcceptWhiteListON, ""));
            key.pause("6", "");

            LogCapture.info(" Payment Reference From Payment Out is: " + Transaction_Reference);
            String BNKROFQueuePaymentReference = Constants.BankingOR.getProperty("BNKROFQueuePaymentRef");
            Assert.assertEquals("PASS", Constants.key.writeInInput(BNKROFQueuePaymentReference, Transaction_Reference));
            Constants.key.pause("4", "");

            String vROFQueueReasonOfROF = Constants.BankingOR.getProperty("BNKROFQueueRsnOfROF");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReasonOfROF, "Test ROF"));
            LogCapture.info(" ROF Queue Reason Of ROF = Test ROF is entered on UI");
            Constants.key.pause("4", "");

            String vROFQueueSubmit = Constants.BankingOR.getProperty("BNKROFQueueSubmit");
            Assert.assertEquals("PASS", Constants.key.click(vROFQueueSubmit, ""));
            LogCapture.info(" User click on ROF Queue Submit Button");
            Constants.key.pause("4", "");

            Alert alert1 = driver.switchTo().alert();
            alert1.accept();
            Constants.key.pause("5", "");
        } else if (WhiteListONType.equalsIgnoreCase("One-Off")) {
            String vBNKROFAcceptWhiteListON = Constants.BankingOR.getProperty("BNKROFAcceptWhiteListON_OneOff");
            Assert.assertEquals("PASS", Constants.key.click(vBNKROFAcceptWhiteListON, ""));
            key.pause("6", "");

            LogCapture.info(" Payment Reference From Payment Out is: " + Transaction_Reference);
            String BNKROFQueuePaymentReference = Constants.BankingOR.getProperty("BNKROFQueuePaymentRef");
            Assert.assertEquals("PASS", Constants.key.writeInInput(BNKROFQueuePaymentReference, Transaction_Reference));
            Constants.key.pause("4", "");

            String vROFQueueReasonOfROF = Constants.BankingOR.getProperty("BNKROFQueueRsnOfROF");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReasonOfROF, "Test ROF"));
            LogCapture.info(" ROF Queue Reason Of ROF = Test ROF is entered on UI");
            Constants.key.pause("4", "");

            String vROFQueueSubmit = Constants.BankingOR.getProperty("BNKROFQueueSubmit");
            Assert.assertEquals("PASS", Constants.key.click(vROFQueueSubmit, ""));
            LogCapture.info(" User click on ROF Queue Submit Button");
            Constants.key.pause("4", "");

            Alert alert1 = driver.switchTo().alert();
            alert1.accept();
            Constants.key.pause("5", "");
        } else if (WhiteListONType.equalsIgnoreCase("Payee Error Message")) {
            String vBNKROFAcceptWhiteListON = Constants.BankingOR.getProperty("BNKROFAcceptWhiteListON_Payee");
            Assert.assertEquals("PASS", Constants.key.click(vBNKROFAcceptWhiteListON, ""));
            key.pause("6", "");
            LogCapture.info(" Payment Reference From Payment Out is: " + Transaction_Reference);
            String BNKROFQueuePaymentReference = Constants.BankingOR.getProperty("BNKROFQueuePaymentRef");
            Assert.assertEquals("PASS", Constants.key.writeInInput(BNKROFQueuePaymentReference, "2405281833307704"));
            Constants.key.pause("4", "");
            String vROFQueueReasonOfROF = Constants.BankingOR.getProperty("BNKROFQueueRsnOfROF");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReasonOfROF, "Test ROF"));
            LogCapture.info(" ROF Queue Reason Of ROF = Test ROF is entered on UI");
            Constants.key.pause("4", "");
            String vROFQueueSubmit = Constants.BankingOR.getProperty("BNKROFQueueSubmit");
            Assert.assertEquals("PASS", Constants.key.click(vROFQueueSubmit, ""));
            LogCapture.info(" User click on ROF Queue Submit Button");
        }
    }

    @And("^User gets Legal Entity from \"([^\"]*)\" DB for \"([^\"]*)\"$")
    public void userGetsLegalEntityFromDBFor(String Environment, String AccountNumber) throws Throwable {
        String LegalEntity = null;
        AccountsNumber = AccountNumber;
        LegalEntity = Constants.key.VerifyDBDetails(Environment, AccountsNumber, "Find Legal Entity for the AccountNumber");
    }

    @And("^User Delete Record from WhiteListing table with \"([^\"]*)\" DB for \"([^\"]*)\"$")
    public void userDeleteRecordFromWhiteListingTableWithDB(String specificBankCode, String Environment) throws Throwable {
        countrySpecificBankCode = specificBankCode;
        Constants.key.VerifyDBDetails(Environment, countrySpecificBankCode, "Delete WhiteListning Record");
    }

    @And("^User Validate the PreferredPaymentMethod from \"([^\"]*)\" DB for \"([^\"]*)\"$")
    public void userValidateThePreferredPaymentMethodFromFor(String Environment, String PaymentType) throws Throwable {
        String PaymentTypeFeaFile = PaymentType;
        LogCapture.info("PaymentTypeFeaFile:" + PaymentTypeFeaFile);
        String PaymentTypeDB = Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "Validate PaymentType In DB In WhiteListening Table");
        Assert.assertEquals(PaymentTypeFeaFile, PaymentTypeDB);
    }

    @And("^Do \"([^\"]*)\" DB verification and get verifyROFID$")
    public void doDBVerificationAndGetVerifyROFID(String Environment) throws Throwable {
        String ROFID = Constants.key.VerifyDBDetails(Environment, StatementLineID, "Find the ROF ID form StatementLineID");
        LogCapture.info("ROF ID is : " + ROFID);
        LogCapture.info("Payment is went to ROF with ROF ID as : " + ROFID);

    }

    @And("^User Verify Fund type from \"([^\"]*)\" DB$")
    public void userVerifyFundTypeFromDB(String Environment) throws Throwable {
        String Funds_type = Constants.key.VerifyDBDetails(Environment, EODMSL_ID, "Fund Type");
        LogCapture.info("VBAN Banking Status is " + Funds_type);
        Assert.assertTrue(true, valueOf(Funds_type.contains("CVA")));

    }


    @And("^User Verify Fund type value as \"([^\"]*)\" from \"([^\"]*)\" DB$")
    public void userVerifyFundTypeValueAsFromDB(String ValueType, String Environment) throws Throwable {
        String Funds_type = Constants.key.VerifyDBDetails(Environment, EODMSL_ID, "Fund Type");
        LogCapture.info("VBAN Banking Status is " + Funds_type);
        Assert.assertTrue(true, valueOf(Funds_type.contains(ValueType)));
    }

    @Then("^user verify Remitter Name\"([^\"]*)\" and \"([^\"]*)\" is captured correctly in Banking DB$")
    public void userVerifyRemitterNameAndIsCapturedCorrectlyInBankingDB(String ExpRemitterAccountName, String ExpRemitterAddress) throws Throwable {

        Map<String, String> RemitterDetails = Constants.key.verifyDBDetailsEnhanced("UAT", EODMSL_ID, "RemitterName");
        String RemitterAccountName = RemitterDetails.get("RemitterAccountName");
        String RemitterAddress = RemitterDetails.get("RemitterAddress");

        if(RemitterAccountName.equals(ExpRemitterAccountName) && RemitterAddress.equals(ExpRemitterAddress))
        {
            LogCapture.info("Remitter Name is [" + RemitterAccountName + "] and Address is ["+RemitterAddress+"] then User verified name and address is splited as per expected condition");
        }else
        {
            LogCapture.info("TC Failed : User verified name and address is not splited as per expected condition");
            Assert.fail();
        }
    }

    @Then("^user verify Remitter Name\"([^\"]*)\" captured correctly in Banking DB$")
    public void userVerifyRemitterNameCapturedCorrectlyInBankingDB(String ExpRemitterAccountName) throws Throwable {

        Map<String, String> RemitterDetails = Constants.key.verifyDBDetailsEnhanced("UAT", EODMSL_ID, "RemitterName");
        String RemitterAccountName = RemitterDetails.get("RemitterAccountName");
        String RemitterAddress = RemitterDetails.get("RemitterAddress");

        if(RemitterAccountName.equals(ExpRemitterAccountName))
        {
            LogCapture.info("Remitter Name is [" + RemitterAccountName + "] and Address is captured in JPMG as expected");
        }else
        {
            LogCapture.info("TC Failed : User verified name and address is not splited as per expected condition");
            Assert.fail();
        }

    }

    @Then("^user verify Remitter Name\"([^\"]*)\" and Remitter Number \"([^\"]*)\" is captured correctly in Banking DB$")
    public void userVerifyRemitterNameAndRemitterNumberIsCapturedCorrectlyInBankingDB(String ExpRemitterAccountName, String ExpRemitterAccountNumber) throws Throwable {

        Map<String, String> RemitterDetails = Constants.key.verifyDBDetailsEnhanced("UAT", EODMSL_ID, "RemitterName");
        String RemitterAccountName = RemitterDetails.get("RemitterAccountName");
        String RemitterAccountNumber = RemitterDetails.get("RemitterAccountNumber");

        if(RemitterAccountName.equals(ExpRemitterAccountName) && RemitterAccountNumber.equals(ExpRemitterAccountNumber))
        {
            LogCapture.info("Remitter Name is [" + RemitterAccountName + "] and Remitter Account Number is ["+ExpRemitterAccountNumber+"] then User verified name and Remitter Account Number is splited as per expected condition");
        }else
        {
            LogCapture.info("TC Failed : User verified name and address is not splited as per expected condition");
            Assert.fail();
        }
    }


    @Then("^User verify duplicate transaction captured in Banking DB$")
    public void userVerifyDuplicateTransactionCapturedInBankingDB() throws Exception {

        Map<String, String> RemitterDetail1 = Constants.key.verifyDBDetailsEnhanced("UAT", ReusableEODMSL_ID1, "DuplicateTransaction1");
        String RemitterDetail1AccountName = RemitterDetail1.get("RemitterAccountName");
        String RemitterDetail1AccountNumber = RemitterDetail1.get("RemitterAccountNumber");


        Map<String, String> RemitterDetail2 = Constants.key.verifyDBDetailsEnhanced("UAT", ReusableEODMSL_ID2, "DuplicateTransaction2");
        String RemitterDetail2AccountName = RemitterDetail2.get("RemitterAccountName");
        String RemitterDetail2AccountNumber = RemitterDetail2.get("RemitterAccountNumber");


        if(RemitterDetail1AccountName.equals(RemitterDetail2AccountName) && RemitterDetail1AccountNumber.equals(RemitterDetail2AccountNumber))
        {
            LogCapture.info("User verified Duplicate Transactions Received From JPM bank");

        }else
        {
            LogCapture.info("TC Failed : User verified Duplicate Transactions Not Received From JPM bank");
            Assert.fail();
        }

    }


    @And("^User gets MSL_ID from \"([^\"]*)\" Banking DB$")
    public void userGetsMSL_IDFromBankingDB(String Environment) throws Throwable {
        String MSL = Constants.key.VerifyDBDetails(Environment, StatementLineID, "Find the MSL_ID");
        Constants.EODMSL_ID = MSL;
        Constants.Kafka_ID = MSL;
        Constants.ReusableEODMSL_ID1 = EODMSL_ID;
        LogCapture.info("MSL_ID 1 : " + ReusableEODMSL_ID1);
    }

    @And("^User gets MSL_ID(\\d+) from \"([^\"]*)\" Banking DB$")
    public void userGetsMSL_IDFromBankingDB(int MSLID, String Environment) throws Throwable {
        String MSL = Constants.key.VerifyDBDetails(Environment, StatementLineID, "Find the MSL_ID");
        Constants.EODMSL_ID = MSL;
        Constants.Kafka_ID = MSL;
        if(MSLID==1)
        {
            Constants.ReusableEODMSL_ID1 = EODMSL_ID;
            LogCapture.info("MSL_ID 1 : " + ReusableEODMSL_ID1);
        }else if(MSLID==2)
        {
            Constants.ReusableEODMSL_ID2 = EODMSL_ID;
            LogCapture.info("MSL_ID 2 : " + ReusableEODMSL_ID2);
        }
        else
        {
            LogCapture.info("TC Failed : MSL_ID not captured : " + EODMSL_ID);
            Assert.fail();
        }

    }

    @And("^User Verify Fund type value as \"([^\"]*)\" from \"([^\"]*)\" Banking DB$")
    public void userVerifyFundTypeValueAsFromBankingDB(String ValueType, String Environment) throws Throwable {


        Map<String, String> bankingManuallyApprovedBy = Constants.key.verifyDBDetailsEnhanced(Environment, EODMSL_ID, "banking_manually_approved_by");
        String ActualMessage = bankingManuallyApprovedBy.get("Message");
        JsonPath jsonMessage = Constants.APIkey.rawToJason(ActualMessage);
        String Value = jsonMessage.get("banking_manually_approved_by");

        String TitanbankingManuallyApprovedBy = Constants.key.VerifyDBDetails("Titan_UAT", EODMSL_ID, "Titanbanking_manually_approved_by");

        LogCapture.info("}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}} " + Value);
        LogCapture.info("}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}} cd_api_user");

        if(ValueType.equals("cd_api_user"))
        {
            if(Value.equals("cd_api_user"))
            {
                LogCapture.info("User verify banking_manually_approved_by as " + Value);
            }else
            {
                LogCapture.info("TC Failed : User unable to verify banking_manually_approved_by as cd_api_user ");
                Assert.fail();
            }
        }


        if(ValueType.equalsIgnoreCase("NULL"))
        {
            if(Value==null || Value == "" || Value!= "cd_api_user")
            {
                LogCapture.info("User verify banking_manually_approved_by as null");
            }else
            {
                LogCapture.info("TC Failed : User unable to verify banking_manually_approved_by as null ");
                Assert.fail();
            }

            if(TitanbankingManuallyApprovedBy==null || Value == "")
            {
                LogCapture.info("User verify Record not present on Titan Database as expected");
            }else
            {
                LogCapture.info("TC Failed : User verified record present on Titan database ");
                Assert.fail();
            }


        }
    }

    @Then("^user verify Remitter Address \"([^\"]*)\" and Remitter Number \"([^\"]*)\" is captured correctly in Banking DB$")
    public void userVerifyRemitterAddressAndRemitterNumberIsCapturedCorrectlyInBankingDB(String ExpRemitterAddress, String ExpRemitterAccountNumber) throws Throwable {

        Map<String, String> RemitterDetails = Constants.key.verifyDBDetailsEnhanced("UAT", EODMSL_ID, "RemitterName");
        String RemitterAddress = RemitterDetails.get("RemitterAddress");
        String RemitterAccountNumber = RemitterDetails.get("RemitterAccountNumber");

        LogCapture.info(RemitterAddress + ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> RemitterAddress Actual   ");
        LogCapture.info(ExpRemitterAddress + ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> RemitterAddress Expected ");

        LogCapture.info(RemitterAccountNumber + ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> RemitterAccountNumber Actual   ");
        LogCapture.info(ExpRemitterAccountNumber + ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> RemitterAccountNumber Expected ");

        if(RemitterAddress.contains(ExpRemitterAddress)  && !RemitterAccountNumber.equals(""))
        {
            LogCapture.info("Remitter Address is [" + RemitterAddress + "] and Remitter Account Number is ["+ExpRemitterAccountNumber+"] then User verified name and Remitter Account Number is splited as per expected condition");
        }else
        {
            LogCapture.info("TC Failed : User verified Address and Account Number is not splited as per expected condition");
            Assert.fail();
        }

    }
}