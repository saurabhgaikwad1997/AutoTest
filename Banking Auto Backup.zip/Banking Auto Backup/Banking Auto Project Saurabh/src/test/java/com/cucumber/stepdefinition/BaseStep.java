package com.cucumber.stepdefinition;

import com.cucumber.listener.Reporter;
import com.selenium.utillity.Constants;
import com.selenium.utillity.FileRename;
import com.selenium.utillity.Reusables;
import com.selenium.utillity.grafanaReusables;
import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.apache.commons.io.FileUtils;
import org.junit.Assume;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
//import static com.selenium.utillity.Reusables.takeSnapShot;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
//import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
//import com.utilities.Log;
/*import io.cucumber.java.After;
import io.cucumber.java.Before;*/


public class BaseStep {

    public static String scenarioName;
    //@BeforeClass


    @Before
    public void intialization(Scenario scenario) throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();
        //Constants.key.deleteScreenShotFolderOnRun();
        scenarioName = scenario.getName();
        Constants.key = new Reusables();
        FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//config.properties");
        System.out.println("User dir:->"+System.getProperty("user.dir"));
        Constants.CONFIG = new Properties();
        Constants.CONFIG.load(fs);

        Constants.JenkinsEnvironment = Constants.CONFIG.getProperty("Environment").toUpperCase();

        //Kafka UI
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//KafkaUI.properties");
        Constants.KafkaUI = new Properties();
        Constants.KafkaUI.load(fs);

        //Banking B2B OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//B2BOR.properties");
        Constants.B2BOR = new Properties();
        Constants.B2BOR.load(fs);
        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");


        //Banking OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//BankingOR.properties");
        Constants.BankingOR = new Properties();
        Constants.BankingOR.load(fs);
        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");

        //Banking RFQ OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//RFQOR.properties");
        Constants.RFQOR = new Properties();
        Constants.RFQOR.load(fs);
        LogCapture.startLog("-------------------------Test Case Validation Started for Banking RFQ--------------------");

        //Payment Monitoring OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//PaymentMonitoringOR.properties");
        Constants.PaymentMonitoringOR = new Properties();
        Constants.PaymentMonitoringOR.load(fs);
        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");

        //Message OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//MessageOR.properties");
        Constants.MessageOR = new Properties();
        Constants.MessageOR.load(fs);
        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");

        //Query Management OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//QueryManagementOR.properties");
        Constants.QueryManagementOR = new Properties();
        Constants.QueryManagementOR.load(fs);
        LogCapture.startLog("-------------------------Test Case Validation Started For Query Management--------------------");

        //Query Message OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//MessageOR.properties");
        Constants.MessageOR = new Properties();
        Constants.MessageOR.load(fs);
        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");

        //FX Confirmation OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Banking//FXConfirmationOR.properties");
        Constants.FXConfirmationOR = new Properties();
        Constants.FXConfirmationOR.load(fs);
        //DB Connection OR
        FileInputStream db = new FileInputStream(System.getProperty("user.dir") + "//src//Config//dbconfig.properties");
        System.out.println("User dir:->"+System.getProperty("user.dir"));
        Constants.DBCONFIG = new Properties();
        Constants.DBCONFIG.load(db);
        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");

        fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//SQL_Queries.properties");
        Constants.SQL_Queries = new Properties();
        Constants.SQL_Queries.load(fs);
        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");

        //load dynamic config
        FileInputStream DynamicConfig = new FileInputStream(System.getProperty("user.dir") + "//src//Config//dynamicConfig.properties");
        Constants.OnTheFlyValue = new Properties();
        Constants.OnTheFlyValue.load(DynamicConfig);

        Constants.DynamicValue = ReusableMethod.OnTheFlyValues(System.getProperty("user.dir") + "//src//Config//dynamicConfig.properties");

        //Load xmlconfig
        Reporter.loadXMLConfig(new File(System.getProperty("user.dir") + "/extent-config.xml"));
        String testCaseID = scenario.getName().split("-")[0].trim();

        if(scenario.getName().contains("-")){
            Constants.SHEET_NAME = scenario.getName().split("-")[1].trim();
        }

        Constants.ApplicationName = Constants.SHEET_NAME;
        Constants.tcIDs = testCaseID;
        String isEnabled = Constants.APIkey.readExcel(testCaseID, "Execution");

        LogCapture.info("==========================API Validation Started for testcase " + testCaseID + "======================");
        if(isEnabled!=null){
            Constants.Execution = isEnabled;
            if (isEnabled.equalsIgnoreCase("N") || isEnabled.equalsIgnoreCase("")) {
                ReusableMethod.createReportParameters(testCaseID);
                LogCapture.info("--------------------------------Test Case " + testCaseID + " is disabled in datasheet------------------");
                Reporter.addScenarioLog("<b style=\"color:Red;\">*THIS TEST CASE HAS BEEN MARKED AS 'N' in APIData.xls present at /src/main/resources</b>");
                Assume.assumeTrue(testCaseID + " is skipped", false);

            }
        }
        //-----------------Jenkins-Grafana checkpoint below-------------------------------
        try {
            grafanaReusables.startStopwatch("Start");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        //-----------------Jenkins-Grafana checkpoint above-------------------------------

    }

    @After
    public void finish(Scenario scenario) throws Exception {
            ReusableMethod.softAssert.assertAll();
            if (Constants.CONFIG.getProperty("ScreenshotCaptureOnFailure").equalsIgnoreCase("True")) {
                if (scenario.isFailed()) {
                    takeSnapShotOnFailure();
                }
            }
                if (Constants.CONFIG.getProperty("ScreenshotCaptureOnFailure").equalsIgnoreCase("True")) {
            if (scenario.isFailed()) {
                takeSnapShotOnFailure();
            }
        }
        if (!(Constants.driver == null)) {
//            Constants.driver.close();
            Constants.driver.quit();
        }
        LogCapture.endLog("-------------------------Test Case Validation Ended--------------------");
        //-----------------Jenkins-Grafana checkpoint below-------------------------------
        grafanaReusables.triggerDataPopulation(scenario);
        //-----------------Jenkins-Grafana checkpoint above-------------------------------

    }

    public static void writeExtentReport() throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();
        Reporter.loadXMLConfig(new File(Constants.key.getReportConfigPath()));

    }
}
