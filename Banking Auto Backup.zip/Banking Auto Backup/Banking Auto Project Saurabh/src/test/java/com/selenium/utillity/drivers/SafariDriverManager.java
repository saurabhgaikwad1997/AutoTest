package com.selenium.utillity.drivers;

import com.selenium.utillity.Constants;
import com.selenium.utillity.OSType;
import com.selenium.utillity.WebDriverManagerCustom;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

public class SafariDriverManager extends WebDriverManagerCustom {
    private WebDriver driver;
    private OSType osType;

    public SafariDriverManager(OSType osType) {
        this.osType = osType;
    }

    @Override
    public WebDriver getDriver(String object) {
        if (driver == null) {
            setupDriver(object);
        }
        return driver;
    }

    @Override
    public void setupDriver(String object) {
        if (osType != OSType.MAC) {
            throw new UnsupportedOperationException("Safari is only supported on Mac");
        }

        SafariOptions options = new SafariOptions();
        // Set any options specific to Safari if required

        driver = new SafariDriver(options);
        Constants.driver = driver; // Initializing Constants.driver with the EdgeDriver instance
    }
}
