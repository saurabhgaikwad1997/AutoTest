
/*ClassName: Resuables.java
Date: 17/April/2020
Author: Saurabh Gadgil
Purpose of class: To implement generic methods, all resuable using Xpath and selenium for robust framework.*/

package com.selenium.utillity;

//import com.sun.org.apache.bcel.internal.Const;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import gherkin.formatter.model.Range;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.DateTime;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.*;
//import java.security.Key;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
//import java.util.regex.Pattern;

import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.Constants.StatementLineID;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import static io.restassured.RestAssured.given;
import static java.lang.String.*;
import static java.sql.DriverManager.getConnection;
//import com.sun.org.apache.bcel.internal.Const;
//import com.sun.org.apache.bcel.internal.Const;

import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Reusables {
    public String actual;
    public static String Email;
    public String ScreenshotFlag;
    String downloadFilesPath = System.getProperty("user.dir") + "\\Downloads\\";
    public String emailID;
    public static boolean openBrowser(String object, String data) throws Exception {
        try {
            String vExpected = "Chrome, Firefox, Edge, Safari";
            String vActual = data;

            if (data.isEmpty()) {
                vActual = "No data found";
            }

            //System.out.println("expected value->>>>" + vExpected);
            System.out.println("data value->>>>" + vActual);

            // Identify the operating system
            String oSName = System.getProperty("os.name").toUpperCase();
            OSType osType;
            if (oSName.contains("WIN")) {
                osType = OSType.WINDOWS;
            } else if (oSName.contains("MAC")) {
                osType = OSType.MAC;
            } else if (oSName.contains("NUX")) {
                osType = OSType.LINUX;
            } else {
                throw new UnsupportedOperationException("Unsupported operating system: " + oSName);
            }

            // Identify the driver type
            DriverType driverType;
            switch (data.toLowerCase()) {
                case "chrome":
                    driverType = DriverType.CHROME;
                    break;
                case "firefox":
                    driverType = DriverType.FIREFOX;
                    break;
                case "edge":
                    driverType = DriverType.EDGE;
                    break;
                case "safari":
                    driverType = DriverType.SAFARI;
                    break;
                default:
                    throw new IllegalArgumentException("Invalid browser type: " + data);
            }

            // Get the driver manager
            WebDriverManagerCustom driverManager = DriverFactory.getManager(driverType, osType);

            // Setup the driver
            driverManager.setupDriver(object);

            // Get the driver
            WebDriver driver = driverManager.getDriver(object);

            // From here onwards, you can interact with the WebDriver instance (e.g., navigate to a URL, perform operations on the page, etc.)

            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            // Your log capturing and snapshot taking logic here
            return false;
        }
    }



    public static String navigate(String object, String data) throws Exception {
        try {
            Constants.driver.navigate().to(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";

        }
        return KEYWORD_PASS;
    }

    public String writeInInput(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).sendKeys(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String click(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("actual value->>>>" + actual);
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equalsIgnoreCase(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String pause(String object, String data) throws NumberFormatException, InterruptedException {
        long time = (long) Double.parseDouble(object);
        Thread.sleep(time * 1000L);
        return KEYWORD_PASS;

    }


    public String getReportConfigPath() {
        String reportConfigPath = Constants.CONFIG.getProperty("reportConfigPath");
        if (reportConfigPath != null) return reportConfigPath;
        else
            throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
    }

    public String exist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String navigateSubMenu(String object, String data) throws Exception {
        try {
            WebElement ele = Constants.driver.findElement(By.xpath(object));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String isAlertPresent() {
        try {
            Alert alert = Constants.driver.switchTo().alert();
            System.out.println("Alert Message" + alert.getText());
            alert.accept();
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String isAlertReject() {
        try {
            Alert alert = Constants.driver.switchTo().alert();
            System.out.println("Alert Message: " + alert.getText());
            alert.dismiss(); // Dismiss the alert instead of accepting it
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String clearText(String object) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).clear();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String VerifyTitle(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.getTitle();
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String VisibleConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(120));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String KeyboardAction(String object, String data) throws Exception {
        try {
            if (data.equalsIgnoreCase("enter")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("tab")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.TAB);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("space")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.SPACE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("downArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("selectall")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.chord(Keys.CONTROL, "a"));
                takeSnapShot();
            } else if (data.equalsIgnoreCase("delete")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.DELETE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("upArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_UP);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("esc")) {
                System.out.println("esc");
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ESCAPE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("backSpace")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.BACK_SPACE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("ctrl-a")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.chord(Keys.CONTROL, "a"));
                takeSnapShot();
            } else if (data.equalsIgnoreCase("page-down")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.PAGE_DOWN);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("end")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.END);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("Home")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.HOME);
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;

        }
        return Constants.KEYWORD_PASS;
    }


    public String verifyElementProperties(String object, String data) throws Exception {
        try {
            if (data.contains("disabled")) {
                String buttonDisabled = Constants.driver.findElement(By.xpath(object)).getAttribute("disabled");
                if (buttonDisabled != null) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " - Not Disabled";
                }
            } else if (data.contains("enabled")) {
                String buttonEnabled = Constants.driver.findElement(By.xpath(object)).getAttribute("enabled");
                if (buttonEnabled == null) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " - Not Enabled";
                }

            } else if (data.contains("visible")) {
                if (Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    //takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    //takeSnapShot();
                    return Constants.KEYWORD_FAIL + " -Not Displayed";
                }
            } else if (data.contains("unselected")) {
                if (!Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("selected")) {
                if (Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("Invisible")) {
                if (!Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " -Not Displayed";
                }
            } else if (data.contains("readonly")) {
                String readonly = Constants.driver.findElement(By.xpath(object)).getAttribute("readonly");
                if (readonly != null) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " - Not readonly";
                }

            } else if (data.contains("not present")) {
                int readonly = driver.findElements(By.xpath(object)).size();
                //takeSnapShot();
                if (readonly >= 1) {
                    return Constants.KEYWORD_FAIL + " - Not readonly";
                } else {
                    return Constants.KEYWORD_PASS;
                }

            } else if (data.contains("present")) {
                int readonly = driver.findElements(By.xpath(object)).size();
                //takeSnapShot();
                if (readonly < 1) {
                    return Constants.KEYWORD_FAIL + " - Not readonly";
                } else {
                    return Constants.KEYWORD_PASS;
                }

            }


        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + " -  Could not find element";

        }
        return Constants.KEYWORD_PASS;
    }

    public String notexist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_PASS;
        }
        return KEYWORD_FAIL + "object exist ";
    }

    public String randomWordGenerator(String object, int numberOfWords) throws Exception {
        try {
            String[] randomStrings = new String[numberOfWords];
            Random random = new Random();
            for (int i = 0; i < numberOfWords; i++) {
                char[] word = new char[random.nextInt(1) + 1]; // words of length 3 through 10. (1 and 2 letter words are boring.)
                for (int j = 0; j < word.length; j++) {
                    word[j] = (char) ('a' + random.nextInt(26));
                }
                randomStrings[i] = new String(word);

            }
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(2000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(randomStrings);

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String getText(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("Actual Length:->" + actual.length());
            }
            LogCapture.info("Actual:->" + actual);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return actual;

    }

    public String SelectDropDownValue(String object, String data) throws Exception {
        try {
            System.out.println("Object:->" + object);
            System.out.println("Data:->" + data);
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            objSelect.selectByVisibleText(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    public String MouseFunctions(String object, String data) throws Exception {
        try {
            WebElement Element = driver.findElement(By.xpath(object));
            Actions action = new Actions(Constants.driver);
            if (data.equalsIgnoreCase("clickAndHold")) {
                action.moveToElement(Element).build().perform();
                action.clickAndHold(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("ReleaseMouseClick")) {
                action.moveToElement(Element).build().perform();
                action.release(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("DoubleClick")) {
                action.doubleClick(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("MoveToElement")) {
                action.moveToElement(Element);
                action.perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("RightClick")) {
                action.contextClick(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("MoveToElementClick")) {
                action.moveToElement(Element).click();
                action.perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("click")) {
                action.click(Element).build().perform();
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to clickAndHold...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    /**
     * to get the text
     *
     * @return text from an element
     * @author Avleen
     * @since 2021-05-13
     */
    public String getText(String object) throws Exception {
        String actual = Constants.driver.findElement(By.xpath(object)).getText();
        return actual;
    }

    /**
     * to check if file is present in the directory
     *
     * @return true if file is present
     * @author Avleen
     * @since 2021-05-13
     */
    public boolean isFileDownloaded(String downloadPath, String fileName) throws Throwable {
        boolean flag = false;
        File dir = new File(downloadPath);
        File[] dir_contents = dir.listFiles();
        for (int i = 0; i < dir_contents.length; i++) {
            if (dir_contents[i].getName().equals(fileName)) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    /**
     * click on submit button and alert popup
     *
     * @return PASS if user click and handle alert successfully
     * @author Avleen
     * @since 2021-05-19
     */
    public String clickAndHandleAlert(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("5", "");
        } catch (UnhandledAlertException f) {
            try {
                Alert alert = driver.switchTo().alert();
                alert.accept();
                return KEYWORD_FAIL;
            } catch (NoAlertPresentException e) {
                e.printStackTrace();
            }
        }
        return KEYWORD_PASS;
    }

    /**
     * Wait for element to be clickable
     *
     * @param object the locator
     * @return PASS when element is clickable
     * @author Avleen
     * @since 2021-05-19
     */
    public String ClickableConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(120));
            w.until(ExpectedConditions.elementToBeClickable(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    /**
     * Handle alert and return alert text
     *
     * @return Alert text when alert is present
     * @author Avleen
     * @since 2021-05-19
     */
    public String getAlertText() {
        String alertText = "";
        try {
            Alert alert = Constants.driver.switchTo().alert();
            alertText = alert.getText();
            alert.accept();
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return alertText;
    }

    /**
     * Remove spaces from a string
     *
     * @return String with no space
     * @author Avleen
     * @since 2021-05-20
     */
    public String removeSpaces(String data) {
        String noSpaceStr = data.replaceAll("\\s", "");
        return noSpaceStr;
    }

    /**
     * switch to child window
     *
     * @return true when successfully switched the window
     * @author Avleen
     * @since 2021-05-19
     */
    public String switchToWindow(String data) throws Throwable {
        String title;
        try {
            String mainWindowHandle = Constants.driver.getWindowHandle();
            Set<String> allWindowHandles = Constants.driver.getWindowHandles();
            Iterator<String> iterator = allWindowHandles.iterator();
            while (iterator.hasNext()) {
                String ChildWindow = iterator.next();
                if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
                    Constants.driver.switchTo().window(ChildWindow);
                    title = Constants.driver.switchTo().window(ChildWindow).getTitle();
                    System.out.println("Window title " + title);
                    if (title.equalsIgnoreCase(data)) {
                        LogCapture.info("User successfully verify window title" + title);
                        break;
                    }

                }
            }
            //Constants.driver.findElement(By.xpath(data)).click();
            return KEYWORD_PASS;

        } catch (Exception ex) {
            System.out.println(".....Switch window is not working...  " + ex);
            return KEYWORD_FAIL;
        }
    }


    /**
     * wait for element to be invisible
     *
     * @return PASS when element disappear from the page
     * @author Avleen
     * @since 2021-06-01
     */
    public String invisibleConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(300));
            w.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }
    /**
     * upload file function
     *
     * @return PASS when file is uploaded successfully
     * @author Bhagyashri
     */

    /**
     * wait for Alert to be visible
     *
     * @return PASS when Alert is appeared on page
     * @author Shailendra
     * @since 2021-06-08
     */
    public String waitForAlert(int timeOutInSeconds) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(timeOutInSeconds));
            w.until(ExpectedConditions.alertIsPresent());
        } catch (UnhandledAlertException f) {
            try {
                WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(timeOutInSeconds));
                w.until(ExpectedConditions.alertIsPresent());
                return Constants.KEYWORD_FAIL;
            } catch (Exception e) {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "Alert not visible...." + e.getMessage();
            }
        }
        return Constants.KEYWORD_PASS;
    }

    /**
     * wait for Window to be visible
     *
     * @return true when new window is appeared on page
     * @author Shailendra
     * @since 2021-06-09
     */
    public boolean waitForNewWindow(int timeout) {
        boolean flag = false;
        int counter = 0;
        while (!flag) {
            try {
                Set<String> winId = driver.getWindowHandles();
                if (winId.size() > 1) {
                    flag = true;
                    return flag;
                }
                Thread.sleep(1000);
                counter++;
                if (counter > timeout) {
                    return flag;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return false;
            }
        }
        return flag;
    }

    /**
     * Return String of Specified Index at DropDown
     *
     * @return String
     * @author Shailendra
     * @since 2021-06-10
     */
    public String ValueOfIndexAt(String object, String data) throws Exception {
        try {
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            List<WebElement> list = objSelect.getOptions();
            String IndexValue = list.get(Integer.parseInt(data)).getText();
            System.out.println("Index Value At " + data + ":->" + IndexValue);
            takeSnapShot();
            return IndexValue;
        } catch (Exception e) {
            takeSnapShot();
            String IndexValue = "Drop Down Index Not Present....";
            return IndexValue + e.getMessage();
        }
    }

    public static Integer RandomNumber(Integer data) throws Exception {
        Random rand = new Random();
        int value = rand.nextInt(data);
        return value;
    }

    /**
     * Verify Alert for Multiple PopUp in Page
     *
     * @return String
     * @author Shailendra
     * @since 2021-06-17
     */
    public String verifyAlertInLine(String Object, String ExpectedAlert) throws Exception {
        try {
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(Object, ""));
            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + ExpectedAlert);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(ExpectedAlert));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Alert Not Present...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    /**
     * Return PASS when file successfully uploaded
     *
     * @return String
     * @author Avleen
     * @since 2021-06-18
     */
    public String UploadFile(String object, String pahtToUpload) throws Exception {
        try {
            WebElement uploadElement = Constants.driver.findElement(By.xpath(object));
            uploadElement.sendKeys(pahtToUpload);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Drop Down Index Not Present...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;

    }

    public String getPageURL(String object, String data) throws Exception {
        String URL = "";
        try {
            Constants.key.pause("3", "");
            URL = driver.getCurrentUrl();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Unable to get URL...." + e.getMessage();
        }
        return URL;
    }

    public String VerifySubstring(String data, String data1) throws Exception {
        String match = "";
        try {
            if (data.contains(data1)) {
                match = Constants.KEYWORD_PASS;
            } else {
                match = Constants.KEYWORD_FAIL;
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + " " + data1 + " String is not in " + data + " String..." + e.getMessage();
        }
        return match;
    }

    /**
     * to delete downloaded file in the directory
     *
     * @return true if file is deleted
     * @author Avleen
     * @since 2021-07-07
     */
    public boolean FileDelete(String downloadPath, String fileName) throws Throwable {
        boolean flag = false;
        File dir = new File(downloadPath);
        File[] dir_contents = dir.listFiles();
        for (int i = 0; i < dir_contents.length; i++) {
            if (dir_contents[i].getName().equals(fileName)) {
                dir_contents[i].delete();
                flag = true;
                break;
            }
        }
        return flag;
    }


    public String SelectByValue(String object, String data) throws Exception {
        try {
            System.out.println("Object:->" + object);
            System.out.println("Data:->" + data);
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            objSelect.selectByValue(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }


    public String OpenDuplicateTab(String Path) throws Throwable {
        try {
            key.pause("3", "");
            String CopyURL = Constants.driver.getCurrentUrl();
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("window.open()");
            ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(tabs2.get(1));
            Constants.driver.get(CopyURL);
        } catch (Exception e) {
            e.printStackTrace();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String javascrpiptScroll(String object, String data) throws Exception {
        try {
            WebElement elem = Constants.driver.findElement(By.xpath(object));
            String js = "arguments[0].scrollIntoView();";
            ((JavascriptExecutor) Constants.driver).executeScript(js, elem);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String javascrpiptEnterText(String object, String data) throws Exception {
        try {
            WebElement element = driver.findElement(By.xpath(object));
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].value='" + data + "';", element);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String renameFileBnkManualUpload(String object, String data) throws Exception {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
            String dateString = format.format(new Date());
            String FolderPath = System.getProperty("user.dir") + "/Files/";
            //String FilePath = FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx";
            File f1 = new File(FolderPath + "ManualEntriesUpload.xlsx");
            File rename = new File(FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx");
            //File f2 = new File(rename);
            boolean b = f1.renameTo(rename);
            if (b == true) {
                System.out.println("File renamed successfully");
            } else {
                System.out.println("Operation failed");
            }
            //LogCapture.info("File Path is....." + FilePath);
            // LogCapture.info("Renamed file is....." + f2.getName());
            Constants.key.pause("8", "");
            WebElement uploadElement = Constants.driver.findElement(By.xpath(object));
            uploadElement.sendKeys(FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx");
            //driver.findElement(By.xpath("//input[@id='file']")).sendKeys((CharSequence) f2);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "File not uploaded or renamed " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String renameFileInFolder(String object, String data) throws Exception {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
            String dateString = format.format(new Date());
            String FolderPath = System.getProperty("user.dir") + "/Files/";
            //String FilePath = FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx";
            File f1 = new File(FolderPath + "ManualEntriesUpload.xlsx");
            File f2 = new File(FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx");
            //File f2 = new File(rename);
            boolean b = f1.renameTo(f2);
            if (b == true) {
                System.out.println("File renamed successfully");
            } else {
                System.out.println("Operation failed");
            }
            //LogCapture.info("File Path is....." + FilePath);
            // LogCapture.info("Renamed file is....." + f2.getName());
           /* Constants.key.pause("8", "");
            WebElement uploadElement = Constants.driver.findElement(By.xpath(object));
            uploadElement.sendKeys(FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx");
            //driver.findElement(By.xpath("//input[@id='file']")).sendKeys((CharSequence) f2);*/
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "File not uploaded or renamed " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    /**
     * to delete downloaded file in the directory
     *
     * @return read Value from DB
     * @author Avleen
     * @since 2021-010-13
     */
    public String VerifyDBDetails(String environment, String data, String operationType) throws Exception {
        //For connection
        Connection connection = null;
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String Dealid = null;
        String query = null;
        String value = null;
        String vTitanTransactionReference = null;
        String vTradeAmount = null;
        String StatementID=null;
        String StatementLineID=null;
        String MSL_ID=null;
        String Account_ID=null;
        String Legal_Entity_ID=null;
        String Legal_Entity=null;
        String remDetail=null;
        String ROF_ID=null;
        String Region=null;
        String CutOffTimeEnd=null;
//        String ConfirmationID=null;
        String IntradayStatement=null;
//        String IntradayStatementLineID=null;
        String ActualRemitterAccountNumber =null;
        String ActualRemitterAccountName =null;
        String vIsParsed = null, vParsedStatus = null;
        List<String> list=new ArrayList<String>();
        HashMap<String,List<String>>ActualRemitter = new HashMap<>();
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + DBCONFIG.getProperty("SITDB_URL") + ":" + DBCONFIG.getProperty("SITDB_PORT");
            DB_USER = DBCONFIG.getProperty("SITDB_User");
            DB_PASSWORD = DBCONFIG.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + DBCONFIG.getProperty("UATDB_URL") + ":" + DBCONFIG.getProperty("UATDB_PORT");
            DB_USER = DBCONFIG.getProperty("UATDB_User");
            DB_PASSWORD = DBCONFIG.getProperty("UATDB_Password");
        }
        else if (environment.equalsIgnoreCase("Titan_UAT")) {
            DB_URL = "jdbc:sqlserver://" + DBCONFIG.getProperty("TitanUATDB_URL") + ":" + DBCONFIG.getProperty("TitanUATDB_PORT");
            DB_USER = DBCONFIG.getProperty("TitanUATDB_User");
            DB_PASSWORD = DBCONFIG.getProperty("TitanUATDB_Password");
        }
//        else if (environment.equalsIgnoreCase("UAT")) {
//            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
//            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
//            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
//        }
        connectionUrl = DB_URL;
        dBUsername = DB_USER;
        dbPassword = DB_PASSWORD;

//        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//        Class.forName(dbClass).newInstance();

        LogCapture.info("Get connection to DB");

        if (operationType.equalsIgnoreCase("Verify Deal Details")) {

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN_Order", "");
            Dealid = result.get("ID");
            value = Dealid;
            LogCapture.info("deal id is" + value);
        }
        else if (operationType.equalsIgnoreCase("Verify Deal BuyAmount Details")) {
            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("RFQ_Contract_Detail_Amt", data);
            String DealBuyingAmt = result.get("SellAmount");
            value = DealBuyingAmt;
            LogCapture.info("Latest Buying Amount From DB is-->>" + value);

        } else if (operationType.equalsIgnoreCase("User Hits Holiday Update Query Error")) {

            Map<String, String> result = Reusables.getSqlQueryResult("UKHolidayError", data);
            LogCapture.info("UKHoliday_Error-->>" + result);
        } else if (operationType.equalsIgnoreCase("User Hits Holiday Update Query Sucess")) {
            Map<String, String> result = Reusables.getSqlQueryResult("UKHolidaySucess", data);
            LogCapture.info("UKHoliday_Sucess-->>" + result);
        }

        else if(operationType.equalsIgnoreCase("Verify Remitter Accounts Name for Not Null")){
            Map<String, String> result1 = Reusables.getSqlQueryResult("remAccName_isNotNull", data);
            String remAccName = result1.get("RemitterAccountName");
            RemmiterAccName_NotNull=remAccName;

            LogCapture.info("Remitter Account Name is Not Null-->>" + RemmiterAccName_NotNull);
        }
        else if(operationType.equalsIgnoreCase("Verify Remitter Accounts Number for Not Null")){
            Map<String, String> result1 = Reusables.getSqlQueryResult("remAccNumber_isNotNull", data);
            String remAccNumber = result1.get("RemitterAccountNumber");
            RemmiterAccNumber_NotNull=remAccNumber;

            LogCapture.info("Remitter Account Number is Not Null-->>" + RemmiterAccNumber_NotNull);
        }

        else if(operationType.equalsIgnoreCase("Verify RemitterAccountName Details")){
            Map<String, String> result = Reusables.getSqlQueryResult("remAccName", data);
            String remAccName = result.get("RemitterAccountName");
            value = remAccName;
            LogCapture.info("Remitter Account Name from DB-->>" + value);
        }
        else if(operationType.equalsIgnoreCase("Verify RemitterAccountNumber Details")){
            Map<String, String> result = Reusables.getSqlQueryResult("remAccNum", data);
            String remAccNumber = result.get("RemitterAccountNumber");
            value = remAccNumber;
            LogCapture.info("Remitter Account Number from DB-->>" + value);
        }
        else if(operationType.equalsIgnoreCase("Verify RemitterAccountNameNull Details")){
            Map<String, String> result = Reusables.getSqlQueryResult("remAccNameNull", data);
            String remAccName = result.get("RemitterAccountName");
            value = remAccName;
            LogCapture.info("Remitter Account Name from DB-->>" + value);
        }
        else if(operationType.equalsIgnoreCase("Verify RemitterAccountNumberNull Details")){
            Map<String, String> result = Reusables.getSqlQueryResult("remAccNumNull", data);
            String remAccNumber = result.get("RemitterAccountNumber");
            value = remAccNumber;
            LogCapture.info("Remitter Account Number from DB-->>" + value);
        }
        else if(operationType.equalsIgnoreCase("Verify Remitter Accounts Number for Null")) {
            Map<String, String> result1 = Reusables.getSqlQueryResult("remAccNumber_isNull", data);
            String remAccNumber = result1.get("RemitterAccountNumber");
            RemmiterAccNumber_Null=remAccNumber;

            LogCapture.info("Remitter Account Number is Null-->>" + RemmiterAccNumber_Null);
        }
        else if (operationType.equalsIgnoreCase("Fetch Latest Payment Titan Transaction Reference Number")) {
            Map<String, String> result = Reusables.getSqlQueryResult("TI_PaymentInstructionsDetails", data);
            value = result.get("Td_txn_ref_number");
            LogCapture.info("Latest Payment Titan Transaction Reference Number is" + value);

        } else if (operationType.equalsIgnoreCase("Fetch Latest ACH Direct Debit Transaction Reference Number")) {
            Map<String, String> result = Reusables.getSqlQueryResult("ACHDirectDebitRequest", data);
            value = result.get("transaction_reference");
            LogCapture.info("Latest ACH Direct Debit Transaction Reference Number is" + value);

        } else if (operationType.equalsIgnoreCase("Fetch Latest PaymentIN Amount")) {
            Map<String, String> result = Reusables.getSqlQueryResult("TI_PaymentInstructionsDetails", data);
            value = result.get("Td_Amount");
            LogCapture.info("Latest Payment out amount fetched is" + value);

        }else if (operationType.equalsIgnoreCase("Find the StatementLineID")) {
            key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus=result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);

//            Assert.assertEquals("PASS", vIsParsed.equals("1"));
//            Assert.assertEquals("PASS", vIsParsed.equalsIgnoreCase(vParsedStatus));
//            if(vIsParsed.equalsIgnoreCase("1")){
//                if(vIsParsed.equalsIgnoreCase(vParsedStatus)){}}
            Assert.assertTrue(vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));

            Map<String, String> result1 = Reusables.getSqlQueryResult("Statement_940", data);
            StatementID = result1.get("ID");
            LogCapture.info("Value of StatementID: " + StatementID);
            Assert.assertFalse(false, valueOf(StatementID.contains("null")));
            RemitterNameID=StatementID;
            Map<String, String> result2 = Reusables.getSqlQueryResult("StatementLine_940", StatementID);
            StatementLineID = result2.get("ID");
            LogCapture.info("Value of StatementLineID: " + StatementLineID);
            Assert.assertFalse(false, valueOf(StatementLineID.contains("null")));
            value = StatementLineID;
            LogCapture.info("StatementLineID is " + value);

        }
        else if(operationType.equalsIgnoreCase("Find the PDQ ID for Indraday")){
            key.pauseforSchedular();

//                Map<String, String> result = Reusables.getSqlQueryResult("PDQID", data);
//                vIsParsed = result.get("IsParsed");
//                vParsedStatus=result.get("parsedStatus");
//                LogCapture.info("Value of IsParsed is " + vIsParsed
//                        + "\n and Value of parsedStatus is " + vParsedStatus);
//                Assert.assertTrue(vIsParsed.equals("1"));
//                Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));


            Map<String, String> result1 = Reusables.getSqlQueryResult("PDQID", data);
            PDQ_ID = result1.get("ID");
            LogCapture.info("Value of PDQ ID: " + PDQ_ID);
            Assert.assertFalse(false, valueOf(PDQ_ID.contains("null")));
//                IntradayStatementID=IntradayStatement;

//                Map<String, String> result2 = Reusables.getSqlQueryResult("IntradayStatementLine", IntradayStatement);
//                IntradayStatementLineID = result2.get("ID");
//
//                value = IntradayStatementLineID;
//                LogCapture.info("IntradayStatementLineID is " + IntradayStatementLineID);
        }

        else if (operationType.equalsIgnoreCase("Find the MSL_ID")) {
            String StatementID1 = Constants.StatementLineID;
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine53", StatementID1);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, valueOf(MSL_ID.contains("null")));
            if(ConfirmationID!=null){

                String ConfirmationIDAtCAMT53 = result.get("ConfirmationID");
                LogCapture.info("Value of ConfirmationID at EOD is: " + ConfirmationIDAtCAMT53);
                Assert.assertTrue(ConfirmationIDAtCAMT53.equalsIgnoreCase(ConfirmationID));

            }
            if(IntradayStatementLineID!=null){

                String IntradayStatementLineIDCAtCAMT53 = result.get("IntradayStatementLineID");
                LogCapture.info("Value of IntradayStatementLineID at EOD is: " + IntradayStatementLineIDCAtCAMT53);
                Assert.assertTrue(IntradayStatementLineIDCAtCAMT53.equalsIgnoreCase(IntradayStatementLineID));

            }
            value = MSL_ID;
        }else if (operationType.equalsIgnoreCase("Region")) {
//                String MSL_ID1 = Constants.MSL_ID;
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLineID", data);
            Region = result.get("RemitterRegion");
            LogCapture.info("Region is: " + Region);
            Assert.assertFalse(false, valueOf(Region.contains("null")));
            value = Region;
            } else if (operationType.equalsIgnoreCase("ClientReference")) {
//                String MSL_ID1 = Constants.MSL_ID;
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLineID", data);
            String ClientReference = result.get("ClientReference");
            LogCapture.info("ClientReference is: " + ClientReference);
            Assert.assertTrue(true, valueOf(ClientReference.contains("0000254935Test")));
            String Reference = result.get("Reference");
            LogCapture.info("Reference is: " + Reference);
            Assert.assertTrue(true, valueOf(Reference.contains("0000254935Test")));
            value = Reference;
        }else if (operationType.equalsIgnoreCase("Payment Method")) {
//                String MSL_ID1 = Constants.MSL_ID;
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLineID", data);
            String TransactionMethod = result.get("TransactionMethod");
            LogCapture.info("TransactionMethod is: " + TransactionMethod);
            Assert.assertFalse(false, valueOf(TransactionMethod.contains("null")));
            value = TransactionMethod;
        }else if (operationType.equalsIgnoreCase("Find the MSL_ID for Manual Entry")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MaualMSL_ID", data);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, valueOf(MSL_ID.contains("null")));
            value = MSL_ID;
        }else if (operationType.equalsIgnoreCase("ROFID")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("ROFID", data);
            String ROFId = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + ROFId);
            Assert.assertFalse(false, valueOf(ROFId.contains("null")));
            value = ROFId;
        }else if (operationType.equalsIgnoreCase("ConfirmationPaymentAdvice ID")) {

            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus=result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);
            Assert.assertTrue( vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));

            Map<String, String> result1 = Reusables.getSqlQueryResult("ConfirmationPaymentAdvice", data);
            ConfirmationID = result1.get("ID");
            LogCapture.info("Value of ConfirmationID: " + ConfirmationID);
            Assert.assertFalse(false, valueOf(ConfirmationID.contains("null")));
            value = ConfirmationID;
        }else if (operationType.equalsIgnoreCase("Find the MSL_ID for CAMT54")) {
            String ConfirmationID1 = ConfirmationID;
            key.pause("2", "");
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine54", ConfirmationID1);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, valueOf(MSL_ID.contains("null")));
            value = MSL_ID;
        }else if (operationType.equalsIgnoreCase("Find the StatementLineID for Indraday")) {

            key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus=result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);
            Assert.assertTrue(vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));


            Map<String, String> result1 = Reusables.getSqlQueryResult("IntradayStatement", data);
            IntradayStatement = result1.get("ID");
            LogCapture.info("Value of IntradayStatement: " + IntradayStatement);
            Assert.assertFalse(false, valueOf(IntradayStatement.contains("null")));
            IntradayStatementID=IntradayStatement;

            Map<String, String> result2 = Reusables.getSqlQueryResult("IntradayStatementLine", IntradayStatement);
            IntradayStatementLineID = result2.get("ID");

            value = IntradayStatementLineID;
            LogCapture.info("IntradayStatementLineID is " + IntradayStatementLineID);

        }else if (operationType.equalsIgnoreCase("Find the MSL_ID for Indraday")) {

//            String StatementID1 = IntradayStatementLineID;
            LogCapture.info("IntradayStatementLineID : " + IntradayStatementLineID);
//            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine52", IntradayStatementLineID);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, valueOf(MSL_ID.contains("null")));
            value = MSL_ID;

        }else if (operationType.equalsIgnoreCase("Checking Description")) {
//            String Pendingid = Constants.PendingB2BID;
            Map<String, String> result = Reusables.getSqlQueryResult("RFQ_Contract_Detail", data);
            value = result.get("Description");
            LogCapture.info("Description is : " + value);
            Assert.assertFalse(false, valueOf(value.contains("null")));
        }else if (operationType.equalsIgnoreCase("Fetch latest message out BACS file name")) {

            Map<String, String> result = Reusables.getSqlQueryResult("LatestBACSMessageOutFile", "");
            String MessageText = result.get("Message");

            LogCapture.info("Message string is: " + MessageText);
            value = MessageText;

        }else if (operationType.equalsIgnoreCase("Verify Bank Name")) {
            LogCapture.info("NewBankName is: " + NewName);
            Map<String, String> result = Reusables.getSqlQueryResult("NewBankAdded", NewName);
            String Name = result.get("Name");

            LogCapture.info("New Bank Added is: " + Name);
            value = Name;

        }else if (operationType.equalsIgnoreCase("VBAN Banking Status")) {
            Map<String, String> result = Reusables.getSqlQueryResult("VBANBankingStatus", ClientAccountKey);
            String status = result.get("IsActive");
            LogCapture.info("VBAN IsActive status is: " + status);
            value = status;

        }else if (operationType.equalsIgnoreCase("Verify Branch Name")) {

            Map<String, String> result = Reusables.getSqlQueryResult("NewBranchAdded", "");
            String Name = result.get("Name");

            LogCapture.info("New Brach Added is: " + Name);
            value = Name;

        }else if (operationType.equalsIgnoreCase("Verify Bank Account")) {

            Map<String, String> result = Reusables.getSqlQueryResult("NewBankAccountAdded", "");
            String AccountNumber = result.get("AccountNumber");

            LogCapture.info("Verify Bank Account is: " + AccountNumber);
            value = AccountNumber;

        }else if (operationType.equalsIgnoreCase("remove linking of other tables")) {

            Map<String, String> result = Reusables.getSqlQueryResult("DeleteBankAccountLegalEntityMapping", ID);
            LogCapture.info("Bank Account Legal Entity Mapping is: " + result);
            Map<String, String> result1 = Reusables.getSqlQueryResult("DeleteAccount_Cost_Mapping", ID);
            LogCapture.info("Bank Account Account Cost Mapping is: " + result1);

            value = valueOf(result);

        }else if (operationType.equalsIgnoreCase("Validating remitter account name and remitter account number")) {
            if(IntradayStatementID==null){
                IntradayStatementID=RemitterNameID;
            }
            String RemitterInfo="";
            if (FileType.equalsIgnoreCase("JPM1")){
                RemitterInfo="RemitterInfo" + FileType;
            }else {
                RemitterInfo = "RemitterInfo" + Bank;
            }
            Map<String, String> result3 = Reusables.getSqlQueryResult(RemitterInfo, IntradayStatementID);
            String remitterCheck = result3.get("KeyId");

            value = remitterCheck;

        }
        else if (operationType.equalsIgnoreCase("Insert into MessageIn Table")) {

            Map<String, String> result = Reusables.getSqlQueryResult("QueryForInsert",messageInQuery, "");
            Map<String, String> result3 = Reusables.getSqlQueryResult("MESSAGE_IN_Order", "");
            String messageInID = result3.get("ID");
            Assert.assertFalse(false, valueOf(messageInID.contains("null")));
            value = messageInID;

        }
        else if (operationType.equalsIgnoreCase("Validating remitter account name and remitter account number for SLID")) {
            if(StatementLineID==null){
                StatementLineID=RemitterNameID;
            }
            String RemitterInfo="";
            if (FileType.equalsIgnoreCase("JPM9")){
                RemitterInfo="RemitterInfo" + FileType;
            }else {
                RemitterInfo = "RemitterInfo" + Bank;
            }
            Map<String, String> result3 = Reusables.getSqlQueryResult(RemitterInfo, StatementLineID);
            String remitterCheck = result3.get("KeyId");

            value = remitterCheck;

        }else if (operationType.equalsIgnoreCase("Find the CreditAdviceID")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("CustomerCreditTransfer",MessageInId);
            String CreditAdviceID = result.get("ID");
            LogCapture.info("Value of Credit Advice ID is: " + CreditAdviceID);
            Assert.assertFalse(false, valueOf(CreditAdviceID.contains("null")));

            value = CreditAdviceID;

        }else if (operationType.equalsIgnoreCase("MSL_ID from CreditAdviceID")) {

            Map<String, String> result = Reusables.getSqlQueryResult("MSLFromCreditAdviceID",CreditAdviceID, "");
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, valueOf(MSL_ID.contains("null")));
            value = MSL_ID;

        }else if (operationType.equalsIgnoreCase("ROF_ID from CreditAdviceID")) {

            Map<String, String> result = Reusables.getSqlQueryResult("RFQIDFromCreditAdviceID",CreditAdviceID, "");
            ROF_ID = result.get("ID");
            LogCapture.info("Value of ROF_ID is: " + ROF_ID);
            Assert.assertFalse(false, valueOf(ROF_ID.contains("null")));
            value = ROF_ID;

        }else if (operationType.equalsIgnoreCase("CreditAdviceID from ROF_ID")) {

            Map<String, String> result = Reusables.getSqlQueryResult("ROFCreditAdviceIDfromROFID",ROFQeueueID, "");
            ROF_ID = result.get("CreditAdviceID");
            LogCapture.info("Value of CreditAdviceID is: " + ROF_ID);
            Assert.assertFalse(false, valueOf(ROF_ID.contains("null")));
            value = ROF_ID;

        }else if (operationType.equalsIgnoreCase("Transaction Reference")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("TransactionReferenceForPaymentOut",ID);
            String Transaction_Reference = result.get("TransactionReference");
            LogCapture.info("Value of Transaction Reference is: " + Transaction_Reference);
            Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
            value = Transaction_Reference;

        }else if (operationType.equalsIgnoreCase("Transaction Reference for Paymentout")) {
            pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("TransactionReferenceForPaymentOut",ID);
            String Transaction_Reference = result.get("TransactionReference");
            LogCapture.info("Value of Transaction Reference is: " + Transaction_Reference);
            Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
            Map<String, String> result1 = Reusables.getSqlQueryResult("PaymentStatus",Transaction_Reference);
            PaymentStatusIs = result1.get("PaymentStatus");
            LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
            if(PaymentStatusIs.equalsIgnoreCase("Duplicate")||PaymentStatusIs.contains("Pending")){
                Map<String, String> result2 = Reusables.getSqlQueryResult("UpdatePaymentStatus",Transaction_Reference);
                Map<String, String> result3 = Reusables.getSqlQueryResult("PaymentStatus",Transaction_Reference);
                PaymentStatusIs = result3.get("PaymentStatus");
                LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            }
            value = Transaction_Reference;

        }else if (operationType.equalsIgnoreCase("ROF Transaction Reference for Paymentout")) {
            key.pauseforSchedular();
            Map<String, String> result1 = Reusables.getSqlQueryResult("PaymentStatus",Transaction_Reference);
            PaymentStatusIs = result1.get("PaymentStatus");
            LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
            if(PaymentStatusIs.equalsIgnoreCase("Duplicate")||PaymentStatusIs.contains("Pending")){
                Map<String, String> result2 = Reusables.getSqlQueryResult("UpdatePaymentStatus",Transaction_Reference);
                Map<String, String> result3 = Reusables.getSqlQueryResult("PaymentStatus",Transaction_Reference);
                PaymentStatusIs = result3.get("PaymentStatus");
                LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            }
            value = Transaction_Reference;

        }else if (operationType.equalsIgnoreCase("TIPaymentDetails")) {

            Map<String, String> result = Reusables.getSqlQueryResult("TIPaymentDetails", ID);
            String TI_PaymentInstructionsDetails_ID = result.get("ID");
            LogCapture.info("Value of TIPaymentDetails is: " + TI_PaymentInstructionsDetails_ID);
            Assert.assertFalse(false, valueOf(TI_PaymentInstructionsDetails_ID.contains("null")));
            value = TI_PaymentInstructionsDetails_ID;

        }else if (operationType.equalsIgnoreCase("Delete WhiteListning Record")) {
            String bankCode = Constants.countrySpecificBankCode;
            key.pauseforSchedular();
            LogCapture.info("Record Deleted From WhiteListening Table.");
            Map<String, String> result = Reusables.getSqlQueryResult("WhiteListningRecord",bankCode);
        }else if (operationType.equalsIgnoreCase("Payment State")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("PaymentID",data);
            String ActualState = result.get("State");
            LogCapture.info("Value of ActualState is: " + ActualState);
            value = ActualState;
        }else if (operationType.equalsIgnoreCase("Payment Status")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("PaymentID",data);
            String ActualStatus = result.get("Status");
            LogCapture.info("Value of ActualStatus is: " + ActualStatus);
            value = ActualStatus;
        }else if (operationType.equalsIgnoreCase("PaymentID")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("PaymentID", Transaction_Reference);
            String PaymentID = result.get("ID");
            LogCapture.info("Value of Payment is: " + PaymentID);
            Assert.assertFalse(false, valueOf(PaymentID.contains("null")));
            value = PaymentID;

        }else if (operationType.equalsIgnoreCase("FPQ_Payment_Reference")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("FPQ_Payment_Reference", Constants.PaymentID);
            Transaction_Reference = result.get("PaymentReference");
            LogCapture.info("Value of Payment is: " + Transaction_Reference);
            Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
            Map<String, String> result1 = Reusables.getSqlQueryResult("PaymentStatus", Transaction_Reference);
            PaymentStatusIs = result1.get("PaymentStatus");
            LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
            if(PaymentStatusIs.equalsIgnoreCase("Duplicate") || PaymentStatusIs.contains("Pending")) {
                Map<String, String> result2 = Reusables.getSqlQueryResult("UpdatePaymentStatus", Transaction_Reference);
                Map<String, String> result3 = Reusables.getSqlQueryResult("PaymentStatus", Transaction_Reference);
                PaymentStatusIs = result3.get("PaymentStatus");
                LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            }
            value = Transaction_Reference;

        }else if (operationType.equalsIgnoreCase("PaymentID_For_MT")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("PaymentID", Transaction_Reference);
            String PaymentID = result.get("ID");
            LogCapture.info("Value of Payment is: " + PaymentID);
            Assert.assertFalse(false, valueOf(PaymentID.contains("null")));
            Map<String, String> result1 = Reusables.getSqlQueryResult("PaymentStatus", Transaction_Reference);
            PaymentStatusIs = result1.get("PaymentStatus");
            LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
            if(PaymentStatusIs.equalsIgnoreCase("Duplicate") || PaymentStatusIs.contains("Pending")) {
                Map<String, String> result2 = Reusables.getSqlQueryResult("UpdatePaymentStatus", Transaction_Reference);
                Map<String, String> result3 = Reusables.getSqlQueryResult("PaymentStatus", Transaction_Reference);
                PaymentStatusIs = result3.get("PaymentStatus");
                LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            }
            value = PaymentID;

        }else if (operationType.equalsIgnoreCase("PaymentStatus")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("PaymentStatus", Transaction_Reference);
            PaymentStatusIs = result.get("PaymentStatus");
            LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            value = PaymentStatusIs;

        } else if (operationType.equalsIgnoreCase("MessageOut")) {
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("CCTransferPayment",Transaction_Reference);
            MessageOutID = result.get("MessageOutID");
            LogCapture.info("Value of MessageOutID is: " + MessageOutID);
            Assert.assertFalse(false, valueOf(MessageOutID.contains("null")));
            value = MessageOutID;

        }
        else if (operationType.equalsIgnoreCase("AuditTrail")) {

        }else if (operationType.equalsIgnoreCase("PSR Payment Status")) {
            key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus=result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);

            Assert.assertTrue(vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));

            Map<String, String> result1 = Reusables.getSqlQueryResult("PaymentStatus", Transaction_Reference);
            PaymentStatusIs = result1.get("PaymentStatus");
            LogCapture.info("Payment out Status is: " + PaymentStatusIs);
            Assert.assertFalse(false, valueOf(PaymentStatusIs.contains("null")));
            value = PaymentStatusIs;

        }
        else if (operationType.equalsIgnoreCase("Find Legal Entity for IntradayStatmentLineID")) {

            String StatementID1 = IntradayStatementLineID;
            LogCapture.info("IntradayStatementLineID : " + StatementID1);
//            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("AccountIDLegalEntity", StatementID1);
            Legal_Entity = result.get("LegalEntityCode");
            LogCapture.info("Legal Entity : " + Legal_Entity);
            Assert.assertFalse(false, valueOf(Legal_Entity.contains("null")));
            value = Legal_Entity;

        }
        else if (operationType.equalsIgnoreCase("Find Legal Entity for StatementLineID")) {

            String StatementID1 = Constants.StatementLineID;
            LogCapture.info("StatementLineID : " + StatementID1);
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("StatementLineIDLegalEntity", StatementID1);
            Legal_Entity = result.get("LegalEntityCode");
            LogCapture.info("Legal Entity : " + Legal_Entity);
            Assert.assertFalse(false, valueOf(Legal_Entity.contains("null")));
            value = Legal_Entity;

        }else if (operationType.equalsIgnoreCase("Find Legal Entity for the AccountNumber")) {

            String AccountNumbers = Constants.AccountsNumber;
            LogCapture.info("AccountNumber : " + AccountNumbers);
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("AccountNumberLegalEntity", AccountNumbers);
            Legal_Entity = result.get("LegalEntityCode");
            LogCapture.info("Legal Entity : " + Legal_Entity);
            Assert.assertFalse(false, valueOf(Legal_Entity.contains("null")));
            value = Legal_Entity;
        }else if (operationType.equalsIgnoreCase("Transaction Reference From Message Out table")) {

            String ID = Transaction_Reference;
            LogCapture.info("Payment out Transaction Reference is : " + ID);
            key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("getTransactionReferenceFromMessageOut", ID);
            String TransactionReferenceMessageOut = result.get("TransactionReference");
            LogCapture.info("Message out Transaction Reference is : " + TransactionReferenceMessageOut);
            Assert.assertFalse(false, valueOf(TransactionReferenceMessageOut.contains("null")));
            value = TransactionReferenceMessageOut;
        }else if (operationType.equalsIgnoreCase("Validate PaymentType In DB In WhiteListening Table")) {
            Map<String, String> result = Reusables.getSqlQueryResult("checkPaymentTypeInDB", Transaction_Reference);
            String preferred_payment_method_DB = result.get("NAME");
            LogCapture.info("preferred_payment_method_DB : " + preferred_payment_method_DB);
            Assert.assertFalse(false, valueOf(preferred_payment_method_DB.contains("null")));
            value = preferred_payment_method_DB;

        }else if (operationType.equalsIgnoreCase("Find Legal Entity for MT103ROF")) {

            LogCapture.info("CreditAdviceID is : " + CreditAdviceID);
            //Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("CreditAdviceIDLegalEntity", CreditAdviceID);
            Legal_Entity = result.get("LegalEntityCode");
            LogCapture.info("Legal Entity : " + Legal_Entity);
            Assert.assertFalse(false, valueOf(Legal_Entity.contains("null")));
            value = Legal_Entity;

        }else if (operationType.equalsIgnoreCase("Verify Routing Rule")) {


            LogCapture.info("Transaction_Reference is : " + Transaction_Reference);

            Map<String, String> result = Reusables.getSqlQueryResult("RoutingRule", Transaction_Reference);
            String RoutingRule = result.get("Reason");
            LogCapture.info("Routing Rule applied is : " + RoutingRule);
            Assert.assertFalse(false, valueOf(RoutingRule.contains("null")));
            value = RoutingRule;

        }else if (operationType.equalsIgnoreCase("Message Feild for Kafka Validation")) {

            Map<String, String> result = Reusables.getSqlQueryResult("PaymentInTitanResponse", data);
            String JsonMessage = result.get("Message");
            LogCapture.info("Message for MSL " + EODMSL_ID + " is : " + JsonMessage);
            Assert.assertFalse(false, valueOf(JsonMessage.contains("null")));
            value = JsonMessage;
        }else if (operationType.equalsIgnoreCase("VBAN FundType Validation")) {
            Map<String, String> result = Reusables.getSqlQueryResult("PaymentInTitanResponse", data);
            String JsonMessage = result.get("Message");
            LogCapture.info("Message for MSL " + EODMSL_ID + " is : " + JsonMessage);
            Assert.assertFalse(false, valueOf(JsonMessage.contains("null")));
            value = JsonMessage;
        }else if (operationType.equalsIgnoreCase("VBAN Existing ClientAccountKey")) {
            Map<String, String> result = Reusables.getSqlQueryResult("VBANRequest_CR", data);
            value = ClientAccountKey;
        }else if (operationType.equalsIgnoreCase("VBAN Request and Response")) {
            Map<String, String> result = Reusables.getSqlQueryResult("VBANRequestResponse", data);
            String status = result.get("status");
            LogCapture.info("Value of status: " + status);
            if(status.equalsIgnoreCase("ACK")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDateTime now=LocalDateTime.now();
                String currentDate=dtf.format(now);
                String updatedDateString = updateDateToPreviousDay(currentDate);
                System.out.println("Original Date: " + currentDate);
                System.out.println("Updated Date: " + updatedDateString);
                Map<String, String> result2 = Reusables.getSqlQueryResult("VBAN_statusUpdate", updatedDateString, ClientAccountKey);
                Map<String, String> result3 = Reusables.getSqlQueryResult("VBANRequestResponse", ClientAccountKey);
                status = result3.get("status");
                LogCapture.info("Payment out Status is: " + status);
            }
            value = status;
        }else if (operationType.equalsIgnoreCase("VBAN Response")) {
            Map<String, String> result = Reusables.getSqlQueryResult("VBANRequestResponse", data);
            String virtual_account_number = result.get("virtual_account_number");
            LogCapture.info("Value of virtual_account_number: " + virtual_account_number);
            Assert.assertFalse(virtual_account_number.contains("null"));
            value = virtual_account_number;
        }else if (operationType.equalsIgnoreCase("ACHDirectDebit Request Response")) {
            Map<String, String> result = Reusables.getSqlQueryResult("ACHDDRequest", TransactionReferenceNumber);
            String ID = result.get("id");
            Map<String, String> result1 = Reusables.getSqlQueryResult("ACHDDResponse", ID);
            String status = result1.get("status");
            Assert.assertEquals("RCVD",status);
            String response_description = result1.get("response_description");
            Assert.assertEquals("SUCCESS",response_description);
            hyperion_reference_id = result1.get("hyperion_reference_id");
            LogCapture.info("Value of hyperion_reference_id is: " + hyperion_reference_id);
            Assert.assertFalse(false, valueOf(hyperion_reference_id.contains("null")));
            value = hyperion_reference_id;
        }else if (operationType.equalsIgnoreCase("Find the ROF ID form StatementLineID")) {
            Map<String, String> result = Reusables.getSqlQueryResult("ROFUsingStatementLineID", data);
            String ID = result.get("ID");
            Assert.assertFalse(false, valueOf(ID.contains("null")));
            value = ID;
        }else if (operationType.equalsIgnoreCase("Fund Type")) {
            Map<String, String> result = Reusables.getSqlQueryResult("PaymentInTitanResponse", data);
            value = result.get("Message");
            LogCapture.info("Latest Fund Type" + value);

        }else if (operationType.equalsIgnoreCase("RemitterName")) {
            Map<String, String> result = Reusables.getSqlQueryResult("RemitterDetails", data);
            value = result.get("Message");
            LogCapture.info("Latest Fund Type" + value);

        }
        else if (operationType.equalsIgnoreCase("Titanbanking_manually_approved_by")) {
            Map<String, String> result = Reusables.getSqlQueryResult("SQLTitanbanking_manually_approved_by", data);
            value = result.get("BankingManuallyApprovedBy");
            LogCapture.info("Banking Manually Approved By Status is " + value);

        }
            return value;
       /* } catch (Exception e) {
            System.out.println("Unable to do operation"+operationType+ "--"+ e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        } finally {
            // Close DB connection
            if (connection != null) {
                connection.close();
            }*/
        //}


    }

    // Pricing Enginee Reusables
    public String Mouse_Hover(String Object, String data) throws Exception {
        try {
            Actions action = new Actions(Constants.driver);
            WebElement we = Constants.driver.findElement(By.xpath(Object));
            action.moveToElement(we).build().perform();
            action.click().build().perform();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public static void writeFullExcel(Object[][] bookData, Integer rowNum) throws IOException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String dateString = format.format(new Date());
        for (Object[] aBook : bookData) {
            Row row = Constants.sheetRead.createRow(++rowNum - 1);
            String statusObject = (String) bookData[0][3];
            CellStyle cs;
            int columnCount = -1;
            for (Object field : aBook) {
                Cell cell = row.createCell(++columnCount);
                if (field instanceof String) {
                    cs = Constants.workbookRead.createCellStyle();
                    if (status.equalsIgnoreCase("PASSED")) {
                        cs.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
                    } else if (status.equalsIgnoreCase("SKIPPED")) {
                        cs.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
                    } else if (status.equalsIgnoreCase("FAILED")) {
                        cs.setFillForegroundColor(IndexedColors.RED.getIndex());
                    } else if (status.equalsIgnoreCase("Status")) {
                        cs.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
                    } else {
                        System.out.println("Report Status doesn't match");
                        LogCapture.info("Report status doesn't match");
                    }
                    cs.setFillPattern(FillPatternType.FINE_DOTS);
                    cell.setCellValue((String) field);
                    cell.setCellStyle(cs);

                } else if (field instanceof Integer) {
                    cell.setCellValue((Integer) field);
                }
            }
        }

        try (FileOutputStream outputStream = new FileOutputStream(new File(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "Execution_Reports" + File.separator + "Execution_StatusReport.xlsx"))) {
            Constants.workbookRead.write(outputStream);
        }
    }

    /********************* ATLAS ****************************/
    public String Scroll(String object, String data) throws Exception {
        try {
            WebElement elem = Constants.driver.findElement(By.xpath(object));
            String js = "arguments[0].scrollIntoView();";
            String js1 = "window.scrollBy(0," + data + ")";
            ((JavascriptExecutor) Constants.driver).executeScript(js, elem);
            ((JavascriptExecutor) Constants.driver).executeScript(js1, elem);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String AltasRejectDropDown(String object, String data) throws Exception {
        try {
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            //System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 0; i < dropdown_list.size(); i++) {
                //System.out.println(dropdown_list.get(i).getText());
                if (dropdown_list.get(i).getText().contains(data)) {
                    for (int j = 1; j < 10000; j++) {
                        String vdata = Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).getText();
                        if (vdata.equals(data)) {
                            Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).click();
                            break;
                        }
                    }
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }

    /**************** Titan **********************/

    public String ClickIfEnable(String object, String data) throws Exception {
        try {
            int attempts = 0;
            int maxAttempts = 10;
            Constants.key.VisibleConditionWait(object, "");
            //        boolean buttonDisabled = false;
            while (attempts++ <= maxAttempts) {
                if (Constants.driver.findElement(By.xpath(object)).isEnabled()) {
                    Constants.driver.findElement(By.xpath(object)).click();
                    break;
                } else {
                    Thread.sleep(500);
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }


    public String selectOrganisationBussinessPartner(String object, String data) throws Exception {
        WebElement element = null;
        String vObjOrganisationBussinessPartner = "";
        try {
            for (int i = 0; i <= 100; i++) {

                if (object.equals("Organisation")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisations-" + i + "']";
                } else if (object.equals("Business Partner")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisation-business-partner-" + i + "']";
                }
                //LogCapture.info(vObjOrganisation);

                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisationBussinessPartner, ""));
                String abc = Constants.key.getText(vObjOrganisationBussinessPartner, "");
                //LogCapture.info(abc);

                if (abc.equalsIgnoreCase(data)) {
                    // LogCapture.info("inside");
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "MoveToElement"));
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "click"));
                    //element.findElement(By.xpath(vObjOrganisation)).click();
                    takeSnapShot();
                    break;
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable select" + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyOrganisationIntableCustomer(String object, String data, String column) throws Exception {
        int a = 0, b = 0;
        try {
            List<WebElement> itemsfiler = driver.findElements(By.xpath("//tbody[@id='accountSummaryTableBody']/tr"));
            int trnofilter = itemsfiler.size() + 1;
            //LogCapture.info("Total rows" +trnofilter);
            for (int s = 2; s < trnofilter; s++) {
                String organization = "//tbody[@id='accountSummaryTableBody']/tr[" + s + "]/td[" + column + "]/a[1]";
                String rowdata = Constants.driver.findElement(By.xpath(organization)).getText();
                //LogCapture.info("organization" +rowdata);
                if (rowdata.equals(data)) {
                    a = a + 1;
                } else {
                    b = b + 1;
                }
            }
            //LogCapture.info("Number of match rows->" +a);
            //LogCapture.info("Number of unmatch rows->" +b);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "something went wrong while fetching data " + e.getMessage();
        }
        if (b > 0) {
            return KEYWORD_FAIL;
        } else {
            return KEYWORD_PASS;
        }
    }

    public String scrollIntoViewElement(String object, String data) throws Exception {
        try {
            WebElement vObject = Constants.driver.findElement(By.xpath(object));
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView", vObject);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String defaultDownloadFilesOperations(String object, String data) {
        try {
            if (object.equalsIgnoreCase("deleteAllFiles")) {
                try {
                    LogCapture.info("All files deleted present in directory: " + downloadFilesPath);
                    FileUtils.cleanDirectory(new File(downloadFilesPath));
                } catch (IOException e) {
                }
            } else if (object.equalsIgnoreCase("deleteSelectedFile")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        dir_contents[i].delete();
                        LogCapture.info(data + " file deleted..");
                        LogCapture.info("Number of files got deleted: " + i);
                    }
                }
            } else if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        LogCapture.info(data + " file downloaded..");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String fileDownload(String object, String data) throws Exception {
        try {
            Screen src = new Screen();
            Pattern fileInputTextBox = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "FileTextBox.png");
            LogCapture.info(valueOf(fileInputTextBox));
            src.type(Key.BACKSPACE);
            // src.type(fileInputTextBox,System.getProperty("user.dir") +File.separator+ "DownloadedFiles"+File.separator+data);
            src.type(fileInputTextBox, data);

            Pattern saveButton = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "SaveButton.png");
            LogCapture.info(valueOf(saveButton));
            src.click(saveButton);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    //
    public String fileDownloadOperations(String object, String data) {
        File file = new File(System.getProperty("user.dir") + File.separator + "DownloadedFiles" + File.separator + data);
        try {
            if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                if (file.exists())
                    System.out.println("File Exists on given path : " + data);
                else
                    System.out.println("File Does not Exists on given path");
            } else if (object.equalsIgnoreCase("deleteDownloadedFile")) {
                if (file.delete())
                    System.out.println("File deleted : " + data);
                else
                    System.out.println("File was not deleted");
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    /******************** Affiliates **************************/


    public String generateRandomString(String object, String data) throws Exception {
        String randomString = "";
        try {
            int leftLimit = 97; // letter 'a'
            int rightLimit = 122; // letter 'z'
            int targetStringLength = 10;
            Random random = new Random();
            StringBuilder buffer = new StringBuilder(targetStringLength);
            for (int i = 0; i < targetStringLength; i++) {
                int randomLimitedInt = leftLimit + (int)
                        (random.nextFloat() * (rightLimit - leftLimit + 1));
                buffer.append((char) randomLimitedInt);
            }
            String generatedString = buffer.toString();
            System.out.println(generatedString);
            randomString = generatedString;
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return randomString;
    }

    //1. DatePicker is a function
    //2. Parameter will be three
    //a. Random date(Between min and max)
    //b. MinDate
    //c.maximum date
    public String datePicker(String object, String data) throws Exception {
        try {
            //Create a Calendar Object
            Date date = new Date();
            Calendar calendar = Calendar.getInstance();
            // SimpleDateFormat CurrentMonth= new SimpleDateFormat()
            calendar.setTime(date);
            //Get Current Day as a number
            int todayDayInt = calendar.get(Calendar.DAY_OF_MONTH);
            System.out.println("Today Int: " + todayDayInt + "\n");
            //Integer to String Conversion
            String todayDayStr = Integer.toString(todayDayInt);
            System.out.println("Today Str: " + todayDayStr + "\n");
            //Getting current month
            LocalDate today = LocalDate.now();
            int todayMonthInt = today.getMonthValue();
            String monthName = DateTime.now().withMonthOfYear(todayMonthInt).toString("MMMMMMMMMMMM");
            System.out.println(monthName);
            //Get Current Day as a number
            System.out.println("Current Month Int: " + todayMonthInt + "\n");
            //Integer to String Conversion
            String todayMonthStr = Integer.toString(todayMonthInt);
            System.out.println("Current Month Str: " + todayMonthStr + "\n");
            //Getting Current year
            int todayYearInt = calendar.get(Calendar.YEAR);
            System.out.println("Current Year Int: " + todayYearInt + "\n");
            //Click on calendar
            //Constants.key.MouseFunctions(object, "DoubleClick");
            //Constants.key.navigateSubMenu(object, "");
            Constants.key.click(object, "");
            //Click on year and navigate to particular year
            // String vDefaultYear = Constants.Affiliates_RegisterACustomerOR.getProperty("DefaultYear");
            int MaxYear = todayYearInt - 100; //Maximum Visible year
            int AboveMaxYear = todayYearInt - 101;
            int BelowMaxYear = todayYearInt - 99;
            int MinYear = todayYearInt - 18; //Minimum age limit for DOB is 18 years
            int BelowMinYear = todayYearInt - 17;
            int AboveMinYear = todayYearInt - 19;
            int RandomYearSelection = 0;
            if (data.equalsIgnoreCase("Random")) {
                RandomYearSelection = MinYear + (int) (Math.random() * (MaxYear - MinYear + 1));
            } else if (data.equalsIgnoreCase("MaxYear")) {
                RandomYearSelection = MaxYear;
            }
     /*else if(data.equalsIgnoreCase("BelowMaxYear")){
     RandomYearSelection=BelowMaxYear;
     }*/
            else if (data.equalsIgnoreCase("MinYear")) {
                RandomYearSelection = MinYear;
            }
        /*else if(data.equalsIgnoreCase("AboveMinYear")){
            RandomYearSelection=AboveMinYear;
        }*/
            System.out.println("Random year: " + RandomYearSelection);
            String vDefaultYear = "//button//parent::span//child::h6";
            Constants.key.pause("2", "");
            //Constants.key.navigateSubMenu(vDefaultYear, "");
            // Constants.driver.findElement(By.xpath(vDefaultYear)).click();
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDefaultYear, ""));
            Assert.assertEquals("PASS", Constants.key.click(vDefaultYear, ""));
            // int DOBYearInt = Constants.key.YearSelectionValidation();
            String DOB_YearStr = Integer.toString(RandomYearSelection);
            String YearSelection = "//div[text()='" + DOB_YearStr + "']";
            WebElement DOB_Year = Constants.driver.findElement(By.xpath(YearSelection));
            //Constants.key.navigateSubMenu(YearSelection, "");
            JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
            js.executeScript("arguments[0].scrollIntoView(true);", DOB_Year);
            DOB_Year.click();
            Constants.key.pause("1", "");
            //Constants.driver.findElement(By.xpath("//div[starts-with(@class,'MuiPickersCalendarHeader-switchHeader')]//child::p"));
            //     Constants.Affiliates_RegisterACustomerOR.getProperty("DefaultDate");
            String DefaultDate =  "//div[starts-with(@class,'MuiPickersCalendarHeader-switchHeader')]//child::p";
            String DefaultMonthDateText = Constants.driver.findElement(By.xpath(DefaultDate)).getText();
            //PreviousMonthNavigation
            String PreviousMonthNavigation="//div[starts-with(@class,'MuiPickersCalendarHeader-switchHeader')]//child::button[1]";
            //NextMonthNavigation
            String NextMonthNavigation = "//div[starts-with(@class,'MuiPickersCalendarHeader-switchHeader')]//child::button[2]";
        /*
if(DefaultMonthDateText.equalsIgnoreCase(monthName+" "+DOB_YearStr)){

    if (data.equalsIgnoreCase("MaxYear")) {

        int MaxYearInvalidDate = todayDayInt - 1;
        System.out.println("USer is not MAx year loop...and invalid date: "+MaxYearInvalidDate);
        String DOB_MaxYearInvalidDate = Integer.toString(MaxYearInvalidDate);
        if (DOB_MaxYearInvalidDate.equalsIgnoreCase("0")) {
            String DOB_InvalidDate = "1";
            String DOB_MaxYearInvalidDatePath = "//p[text()='" + DOB_InvalidDate + "']/parent::span//parent::button[@tabindex='0']";
            Assert.assertEquals("PASS", Constants.key.notexist(DOB_MaxYearInvalidDatePath, ""));
            System.out.println("Invalid Greyout date: "+DOB_InvalidDate+"verified.....");
        } else {
            String DOB_MaxYearInvalidDatePath = "//p[text()='" + DOB_MaxYearInvalidDate + "']/parent::span//parent::button[@tabindex='0']";
            Assert.assertEquals("PASS", Constants.key.notexist(DOB_MaxYearInvalidDatePath, ""));
            System.out.println("Invalid Greyout date: "+DOB_MaxYearInvalidDate+" verified.....");
        }
    }
         if (data.equalsIgnoreCase("MinYear")) {
             int MinYearInvalidDate = todayDayInt + 1;
             String DOB_MinYearInvalidDate = Integer.toString(MinYearInvalidDate);
             if ((calendar.DAY_OF_YEAR) > 365) {
                 if (monthName.equalsIgnoreCase("February")) {
                     if (DOB_MinYearInvalidDate.equalsIgnoreCase("30")) {
                         String DOB_InvalidDate = "1";
                         String DOB_MinYearInvalidDatePath = "//p[text()='" + DOB_InvalidDate + "']/parent::span//parent::button[@tabindex='-1']";
                         List<WebElement> AllDates = driver.findElements(By.xpath(DOB_MinYearInvalidDatePath));
                         for (int i = 0; i < AllDates.size(); i++) {
                             WebElement AllDateStrng = AllDates.get(i);

                           Constants.driver.findElement(By.xpath(AllDateStrng), "");
                         }
                         Assert.assertEquals("PASS", Constants.key.notexist(DOB_MinYearInvalidDatePath, ""));
                     } else {
                         String DOB_MinYearInvalidDatePath = "//p[text()='" + DOB_MinYearInvalidDate + "']/parent::span//parent::button[@tabindex='0']";
                         Assert.assertEquals("PASS", Constants.key.notexist(DOB_MinYearInvalidDatePath, ""));
                     }
                 }

             }
             if ((calendar.DAY_OF_YEAR) <= 365) {
                 if (monthName.equalsIgnoreCase("February")) {
                     if (DOB_MinYearInvalidDate.equalsIgnoreCase("29")) {
                         String DOB_InvalidDate = "1";
                         String DOB_MinYearInvalidDatePath = "//p[text()='" + DOB_InvalidDate + "']/parent::span//parent::button[@tabindex='-1']";
                         Constants.driver.findElements(By.xpath(DOB_MinYearInvalidDatePath));
                     }
                 }
                 else{
                     if((todayMonthInt % 2)==0){

                     }
                     if (DOB_MinYearInvalidDate.equalsIgnoreCase("32")) {
                         String DOB_InvalidDate = "31";
                         String DOB_MinYearInvalidDatePath = "//p[text()='" + DOB_InvalidDate + "']/parent::span//parent::button[@tabindex='0']";
                         Assert.assertEquals("PASS", Constants.key.notexist(DOB_MinYearInvalidDatePath, ""));
                     } else {
                         String DOB_MaxYearInvalidDatePath = "//p[text()='" + DOB_MinYearInvalidDate + "']/parent::span//parent::button[@tabindex='0']";
                         Assert.assertEquals("PASS", Constants.key.notexist(DOB_MaxYearInvalidDatePath, ""));
                     }
                 }

             }


         }
}*/
            if (DefaultMonthDateText.equalsIgnoreCase("January " + DOB_YearStr)) {
                //String DOB_Month = Constants.key.getCurrentMonth();
                System.out.println("Month need to select: " + todayMonthStr);
                switch (todayMonthStr) {
                    case "1":
                        String SelectedMonthJan = "January " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthJan));
                        LogCapture.info("Selected January month");
                        break;
                    case "2":
                        for (int i = 1; i < 2; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthFeb = "February " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthFeb));
                        LogCapture.info("Selected February Month");
                        break;
                    case "3":
                        for (int i = 1; i < 3; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthMarch = "March " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthMarch));
                        LogCapture.info("Selected March Month");
                        break;
                    case "4":
                        for (int i = 1; i < 4; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthApr = "April " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthApr));
                        LogCapture.info("Selected April Month");
                        break;
                    case "5":
                        for (int i = 1; i < 5; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthMay = "May " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthMay));
                        LogCapture.info("Selected May Month");
                        break;
                    case "6":
                        for (int i = 1; i < 6; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthJune = "June " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthJune));
                        LogCapture.info("Selected June Month");
                        break;
                    case "7":
                        for (int i = 1; i < 7; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthJuly = "July " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthJuly));
                        LogCapture.info("Selected July Month");
                        break;
                    case "8":
                        for (int i = 1; i < 8; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthAug = "August " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthAug));
                        LogCapture.info("Selected August Month");
                        break;
                    case "9":
                        for (int i = 1; i < 9; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthSep = "September " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthSep));
                        LogCapture.info("Selected September Month");
                        break;
                    case "10":
                        for (int i = 1; i < 10; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthOct = "October " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthOct));
                        LogCapture.info("Selected October Month");
                        break;
                    case "11":
                        for (int i = 1; i < 11; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthNov = "November " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthNov));
                        LogCapture.info("Selected November Month");
                        break;
                    case "12":
                        for (int i = 1; i < 12; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthDec = "December " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthDec));
                        LogCapture.info("Selected December Month");
                        break;
                }

            }

            //Click on particular date
            // String SelectDate = Constants.key.getCurrentDay();
            String DOB_Date = "//p[text()='" + todayDayStr + "']/parent::span//parent::button[@tabindex='0']";
            Constants.driver.findElement(By.xpath(DOB_Date)).

                    click();
            Constants.key.pause("2", "");
            System.out.println("Date selected: " + todayDayStr);

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to Click on Date...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }


    public String VerifyAllDropDownValues(String sheetName, String colName, String object) throws Exception {
        System.out.println("start");
        String fileName = System.getProperty("user.dir") + "/TestData.xlsx";
        File file = new File(fileName);
        FileInputStream inputStream = new FileInputStream(file);
        String fileExtensionName = fileName.substring(fileName.indexOf("."));
        System.out.println("end");
        if (fileExtensionName.equals(".xlsx")) {
            System.out.println("if");
            Workbook DropDownworkbook = null;
            DropDownworkbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = (XSSFSheet) DropDownworkbook.getSheet(sheetName);
            XSSFRow row;
            XSSFCell cell;
            String CellValue = null;
            try {
                int col_Num = -1;
                row = sheet.getRow(0);
                System.out.println("Ronumber" + row);
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    if (row.getCell(j).getStringCellValue().trim().equals(colName.trim())) {
                        col_Num = j;
                        System.out.println("ColNum" + col_Num);
                        //row= sheet.getRow(j);
                        for (int i = 1; i < sheet.getLastRowNum(); i++) {
                            row = sheet.getRow(i);
                            cell = row.getCell(col_Num);
                            if (cell.getStringCellValue().equalsIgnoreCase("")) {
                                System.out.println("Empty Value");
                            } else {
                                if (cell.getCellTypeEnum() == CellType.STRING) {
                                    CellValue = cell.getStringCellValue();
                                    System.out.println("Value" + CellValue);
                                    // return CellValue;
                                } else if (cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA) {
                                    CellValue = valueOf(cell.getNumericCellValue());
                                    if (HSSFDateUtil.isCellDateFormatted(cell)) {
                                        DateFormat df = new SimpleDateFormat("dd/MM/yy");
                                        Date date = cell.getDateCellValue();
                                        CellValue = df.format(date);
                                    }
                                    // return CellValue;
                                } else if (cell.getCellTypeEnum() == CellType.BLANK) {
                                    CellValue = "";
                                    //return CellValue;
                                } else if (cell.getBooleanCellValue()) {
                                    CellValue = valueOf(cell.getBooleanCellValue());
                                    //return CellValue;
                                } else if (!cell.getBooleanCellValue()) {
                                    CellValue = valueOf(cell.getBooleanCellValue());
                                    //return CellValue;
                                }
                            }
                            // return CellValue;
                            System.out.println("Value is: " + CellValue);
                            Constants.driver.findElement(By.xpath(object)).clear();
                            Constants.driver.findElement(By.xpath(object)).click();
                            //Constants.driver.findElement(By.xpath(object)).clear();
                            Constants.driver.findElement(By.xpath(object)).sendKeys(CellValue);
                            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                            takeSnapShot();
                            Constants.key.pause("2", "");
                            //String vCD_PhoneNumber = Constants.Refer_a_Client.getProperty("CD_PhoneNumber");
                            //Constants.key.click(vCD_PhoneNumber, "");
                            String fotter = object + "//following::p[contains(@class,'MuiTypography-body1')][1]";
                            //System.out.println(fotter);
                            Constants.driver.findElement(By.xpath(fotter)).click();
                            Constants.key.pause("2", "");
                            String ActualDropDownValuetrim = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                            String ActualDropDownValue = ActualDropDownValuetrim.trim();
                            // System.out.println("Actual DropDown Value is: " + ActualDropDownValue);
                            //Is assert correct or need to put it into try catch block???
                            if (ActualDropDownValue.equals(CellValue)) {
                                System.out.println("ActualValue: " + ActualDropDownValue + " Matched ExpectedValue: " + CellValue);

                            } else {
                                System.out.println("ActualValue: " + ActualDropDownValue + " NOT Matched ExpectedValue: " + CellValue);
                                break;
                            }
                            // return "row " + rowNum + " or column " + colName + " does not exist  in Excel";
                        }


                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                return "data not found";
            }

        } else {
            Workbook DropDownworkbook = null;
            DropDownworkbook = new HSSFWorkbook(inputStream);
            HSSFSheet sheet = (HSSFSheet) DropDownworkbook.getSheet(sheetName);
            HSSFRow row = null;
            HSSFCell cell = null;
            String CellValue = null;
            try {
                int col_Num = -1;
                row = sheet.getRow(0);
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    if (row.getCell(j).getStringCellValue().trim().equals(colName.trim())) {
                        col_Num = j;
                        row = sheet.getRow(j);
                        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                            row = sheet.getRow(i);
                            cell = row.getCell(col_Num);
                            if (cell.getCellTypeEnum() == CellType.STRING) {
                                CellValue = cell.getStringCellValue();
                                System.out.println("Value" + CellValue);
                                // return CellValue;
                            } else if (cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA) {
                                CellValue = valueOf(cell.getNumericCellValue());
                                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                                    DateFormat df = new SimpleDateFormat("dd/MM/yy");
                                    Date date = cell.getDateCellValue();
                                    CellValue = df.format(date);
                                }
                                // return CellValue;
                            } else if (cell.getCellTypeEnum() == CellType.BLANK) {
                                CellValue = "";
                                //return CellValue;
                            } else if (cell.getBooleanCellValue()) {
                                CellValue = valueOf(cell.getBooleanCellValue());
                                //return CellValue;
                            } else if (!cell.getBooleanCellValue()) {
                                CellValue = valueOf(cell.getBooleanCellValue());
                                //return CellValue;
                            }
                            System.out.println("Value is: " + CellValue);
                            Constants.driver.findElement(By.xpath(object)).click();
                            //Constants.driver.findElement(By.xpath(object)).clear();
                            Constants.driver.findElement(By.xpath(object)).sendKeys(CellValue);
                            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                            takeSnapShot();
                            String vCD_PhoneNumber = "//p[text()='+44 (0) 20 7847 9400']";
                            Constants.driver.findElement(By.xpath(vCD_PhoneNumber)).click();
                            //Constants.Refer_a_Client.getProperty("CD_PhoneNumber");
                            // Constants.key.click(vCD_PhoneNumber, "");
                            String ActualDropDownValue = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                            // System.out.println("Actual DropDown Value is: " + ActualDropDownValue);
                            //Is assert correct or need to put it into try catch block???
                            if (CellValue.equals(ActualDropDownValue)) {
                                Assert.assertEquals("PASS", Constants.key.verifyText(object, CellValue));
                                System.out.println("ActualValue: " + ActualDropDownValue + " Matched ExpectedValue: " + CellValue);

                            } else {
                                System.out.println("ActualValue: " + ActualDropDownValue + " NOT Matched ExpectedValue: " + CellValue);

                            }

                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Data not found...";
            }
        }
        return "row " + " or column " + colName + " does not exist  in Excel";
    }


    public String verifyInnerText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getAttribute("innerText");
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return Constants.KEYWORD_PASS;
            } else {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }


    public String WaitElementToBeVisible(String object, String data) throws Exception {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        if (data.equalsIgnoreCase("VisibilityOf")) {
            try {
                WebElement element = wait.until(ExpectedConditions.visibilityOf(Constants.driver.findElement(By.xpath(object))));
                System.out.println("object exist" + element.isDisplayed());
                takeSnapShot();
            } catch (Exception e) {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "object does not exist " + e.getMessage();
            }

        }
        return Constants.KEYWORD_PASS;

    }


    public String verifyLinkText(String object, String data) throws Exception {
        try {
            String LinkObjectText = Constants.driver.findElement(By.xpath(object)).getText();
            String actual = Constants.driver.findElement(By.linkText(LinkObjectText)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.linkText(LinkObjectText)).getAttribute("value");
            }
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(data)) {
                takeSnapShot();
                return Constants.KEYWORD_PASS;
            } else {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "...Link text not verified " + actual + "  " + data;
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Link not found...." + e.getMessage();
        }

    }


    public String EnterOtp(String object, String data) throws Exception {
        try {
            int i = 0;
            List<WebElement> ele = driver.findElements(By.xpath(object));
            for (WebElement e : ele) {
                e.sendKeys(data.charAt(i) + "");
                i++;
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return Constants.KEYWORD_PASS;
    }


    public String InVisibleConditionWaitWithText(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(10));
            w.until(ExpectedConditions.invisibilityOfElementWithText(By.xpath(object), data));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_PASS;
        }
        return Constants.KEYWORD_FAIL;
    }


    public static String RefreshPage(String object, String data) throws Exception {
        try {
            Constants.driver.navigate().refresh();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }


    public String SelectDropDownAllValues(String object, String data) throws Exception {
        try {
            Constants.key.pause("2", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i <= dropdown_list.size(); i++) {
                System.out.println(dropdown_list.get(i).getText());
                Constants.driver.findElement(By.xpath("//*[contains(@class,'is-active')]//ul//li[" + i + "]")).click();
                if (i == dropdown_list.size() - 1) {
                    System.out.println(i);
                    break;
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return Constants.KEYWORD_PASS;
    }

    public int getCurrentYear() {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int todayYearInt = calendar.get(Calendar.YEAR);
        return todayYearInt;
    }

    public int getPreviousYear() {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int todayYearInt = calendar.get(Calendar.YEAR);
        return (todayYearInt - 1);
    }

    public Month getCurrentMonth() {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        LocalDate today = LocalDate.now();
        Month todayMonthStr = today.getMonth();
        Month month = todayMonthStr.of(calendar.get(Calendar.MONTH));
        System.out.println("Current Month Str: " + month + "\n");
        return month;
    }

    public String verifyFontProperties(String object, String properties, String data) throws Exception {
        try {
            WebElement TextElement = driver.findElement(By.xpath(object));
            String fontProperties = null;
            fontProperties = TextElement.getCssValue(properties);
            if (fontProperties.equals(data)) {
                LogCapture.info("Font Properties Verified: " + properties + " = " + data);
                takeSnapShot();
            } else {
                LogCapture.info("Font Properties NOT Verified: " + properties + " = " + data);
                takeSnapShot();
                return Constants.KEYWORD_FAIL;
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + " -  Could not find element";

        }
        return Constants.KEYWORD_PASS;
    }


    public String ValidateWebtablePagination(String object, String data) throws Exception {
        try {
            List<WebElement> rowsCounts = driver.findElements(By.xpath(object));
            //int pagecounts=pagecount.size();
            System.out.println("Row Size" + rowsCounts.size());
            List<String> details = new ArrayList<String>();
            for (WebElement rowsCount : rowsCounts) {
                details.add(rowsCount.getText());
            }
            String nextButton = driver.findElement(By.xpath("//*[@aria-label='Go to next page']")).getAttribute("class");
            while (!nextButton.contains("Mui-disabled")) {
                int totalentries = details.size();
                System.out.println("Total Entries" + totalentries);
                int No_Of_Pages = totalentries / 10;
                driver.findElement(By.xpath("//*[@aria-label='Go to next page']")).click();
                rowsCounts = driver.findElements(By.xpath("//*[@class='MuiTableBody-root']/tr"));
                for (WebElement rowsCount : rowsCounts) {
                    details.add(rowsCount.getText());
                    // int noRows=Integer.parseInt(rowsCount.getText());
                    if ((rowsCounts.size() / 10 <= No_Of_Pages) && (rowsCounts.size() % 10 == 0)) {
                        System.out.println("TenRecord Present on Page");
                        for (String detail : details) {
                            // System.out.println(detail);
                        }
                    } else
                        System.out.println("Record Present on Last Page" + rowsCounts.size() % 10);
                }
                nextButton = driver.findElement(By.xpath("//*[@aria-label='Go to next page']")).getAttribute("class");
            }
            for (String detail : details) {
                // System.out.println(detail);
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }


    public String verifyHrefText(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getAttribute("href");
            if (actual.length() < 1) {
                String actual = Constants.driver.findElement(By.xpath(object)).getText();
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data   value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return Constants.KEYWORD_PASS;
            } else {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String navigateWithSpecialCharacterCookies(String object, String data) throws Exception {
        try {
            //takeSnapShotOnFailure();
            Constants.driver.navigate().to(data);
            Cookie name = new Cookie("MyCookie!@#$%&", "123456");
            Constants.driver.manage().addCookie(name);
            // After adding the cookie we will check that by displaying all the cookies.
            Set<Cookie> cookiesList = Constants.driver.manage().getCookies();
            for (Cookie getcookies : cookiesList) {
                System.out.println(getcookies);
            }
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "...not able to navigate";

        }
        return Constants.KEYWORD_PASS;
    }

    public String splitAndCompare(String object, String data) throws Exception {
        try {

            String rowValues[] = data.split(",");
            List<WebElement> ele = driver.findElements(By.xpath(object));
            int cnt = 0;
            for (WebElement e : ele) {
                String portalColumnValue = e.getText().replaceAll(",", "").trim();
                String expectedColumnValue = rowValues[cnt].trim();
                cnt++;
                Assert.assertEquals(portalColumnValue, expectedColumnValue);
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return Constants.KEYWORD_PASS;
    }

    /*************************  PFX CFX   ***************************************/

    public String javascriptWriteInInput(String object, String data) throws Exception {
        try {
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].value='" + data + "'", Constants.driver.findElement(By.xpath(object)));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String selectList(String object, String data) throws Exception {
        try {
            int attempt = 0;
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            if (!data.equals(Constants.RANDOM_VALUE)) {
                objSelect.selectByVisibleText(data);
                takeSnapShot();
            } else {
                WebElement droplist = Constants.driver.findElement(By.xpath(object));
                List<WebElement> droplist_contents = droplist.findElements(By.tagName("option"));
                Random num = new Random();
                int index = num.nextInt(droplist_contents.size());
                String selectedVal = droplist_contents.get(index).getText();
                objSelect.selectByVisibleText(selectedVal);
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "---Could not select from the List---" + e.getMessage();

        }
        return KEYWORD_PASS;
    }

    public String SelectRecipient(String object, String data) throws Exception {
        try {
            LogCapture.info("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'Select')]");
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'Select')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String RecipientTransfer(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Transfer')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String RecipientPay(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Pay')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String uniqueEmailID(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            String emailID = "AutoTestUser" + userName + "@gmail.com";

            LogCapture.info("emailID start with xyz is " + ": " + emailID);

            //System.out.println("Result......" + emailID);
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(1000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(emailID);
            // Constants.driver.findElement(By.xpath(object)).sendKeys("autotestuser213440261@gmail.com");
            Email = Constants.driver.findElement(By.xpath(object)).getText();
            System.out.println("AutoTestUser Email ID" + Email);
            Thread.sleep(1000);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String uniqueEmailAddress(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            emailID = "xyz" + userName + "@gmail.com";

            LogCapture.info("emailID is " + ": " + emailID);


        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return emailID;
    }

    public String ClickEachElementOfFrame(String object, String data) throws Exception {
        try {
            //    List<WebElement> Elements = driver.findElements(By.cssSelector(object));
            List<WebElement> Elements = Constants.driver.findElements(By.xpath(object));
            ListIterator<WebElement> ListOfElements = Elements.listIterator();
            while (ListOfElements.hasNext()) {
                WebElement elem = ListOfElements.next();
                // do something with elem
                elem.click();
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String Mouse_Events(String Object, String data) throws Exception {

        try {
            Actions build = new Actions(Constants.driver);
            build.moveToElement(Constants.driver.findElement(By.xpath(Object))).moveByOffset(11, 11).click().build().perform();
        } catch (Exception e) {
            takeSnapShot();
            return
                    KEYWORD_FAIL;
        }
        return
                KEYWORD_PASS;
    }

    public String Enter_OTP(String object, String data) throws Exception {
        try {
            List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
            for (WebElement input : inputs) {
                input.clear();
                input.sendKeys(data);
                break;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String writeInInputObO(String object, String data) throws Exception {
        try {
            String val = data;
            WebElement element = Constants.driver.findElement(By.xpath(object));
            element.clear();
            for (int i = 0; i < val.length(); i++) {
                char c = val.charAt(i);
                String s = new StringBuilder().append(c).toString();
                element.sendKeys(s);
                Thread.sleep(2000);
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write one by one " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public static String[] generateRandomWords(int numberOfWords) {
        String[] randomStrings = new String[numberOfWords];
        Random random = new Random();
        for (int i = 0; i < numberOfWords; i++) {
            char[] word = new char[random.nextInt(8) + 3]; // words of length 3 through 10. (1 and 2 letter words are boring.)
            for (int j = 0; j < word.length; j++) {
                word[j] = (char) ('a' + random.nextInt(26));
            }
            randomStrings[i] = new String(word);
        }
        return randomStrings;
    }


    public String DeleteRecipient(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'x')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String selectPTRecord(String object, String innerObject, String data) throws Exception {
        try {
            List<WebElement> listElements = Constants.driver.findElements(By.xpath(object));
            for (int i = 0; i < listElements.size(); i++) {
                if (i % 5 == 0) {
                    click(Constants.PaymentTrackingOR.getProperty("ShowMoreButton"), "");
                }
                WebElement element = listElements.get(i);
                element.click();
                Thread.sleep(2000);
                try {
                    WebElement referenceElement = element.findElement(By.xpath(innerObject));
                    if (referenceElement != null) {
                        referenceElement.click();
                        LogCapture.info("Record displayed on PT dashboard =" + referenceElement.getText());
                        takeSnapShot();
                        return KEYWORD_PASS;
                    }
                } catch (Exception e) {
                    LogCapture.info(e.getMessage());
                }
            }
            return KEYWORD_FAIL + "Record is not displayed on PT dashboard";

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
    }

    public String LanguageDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("3", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String ConvertStringToCase(String word, String strcase) throws Exception {
        try {

            if (strcase.equalsIgnoreCase("lower")) {
                word = word.toLowerCase();
            } else if (strcase.equalsIgnoreCase("upper")) {
                word = word.toUpperCase();
            }
        } catch (Exception e) {
            LogCapture.info(e.getMessage());
        }
        return word;
    }

    public String ChatFileOperation(String operation, String data) throws IOException {
        try {
            String path = System.getProperty("user.home");

            path = path + "/Downloads";
            LogCapture.info(path);
            File file = new File(path);
            File files[] = file.listFiles();
            String filename, filename1;
            for (File f : files) {
                if (f.getName().contains(data)) {
                    filename = f.getName();
                    System.out.println(f.getName());
                    if (operation.equalsIgnoreCase("delete")) {
                        f.delete();
                        LogCapture.info(f.getName() + " file got deleted successfully");
                    } else if (operation.equalsIgnoreCase("exist")) {
                        if (filename.equalsIgnoreCase(data + ".txt")) {
                            LogCapture.info(f.getName() + " file downloaded successfully");
                        }
                    } else if (operation.equalsIgnoreCase("verifycontent")) {
                        FileInputStream fstream1 = new FileInputStream(path + "/" + data + ".txt");

                        DataInputStream in1 = new DataInputStream(fstream1);
                        //DataInputStream in2= new DataInputStream(fstream2);

                        BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
                        //BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));

                        String strLine1;
                        String strLine2 = "How can I help you?";


                        while ((strLine1 = br1.readLine()) != null) {
                            if (strLine1.contains(strLine2)) {
                                LogCapture.info(f.getName() + " file downloaded has chat conversation");
                                LogCapture.info(strLine1 + " file downloaded has content");
                                LogCapture.info(f.getName() + " file downloaded content has been compare with " + strLine2);

                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return KEYWORD_FAIL;

        }
        return KEYWORD_PASS;
    }

    public String navigateNewTab(String object, String data) throws Exception {
        try {
            String currentHandle = Constants.driver.getWindowHandle();

            ((JavascriptExecutor) Constants.driver).executeScript("window.open()");


            Set<String> handles = Constants.driver.getWindowHandles();
            for (String actual : handles) {

                if (!actual.equalsIgnoreCase(currentHandle)) {
                    //switching to the opened tab
                    Constants.driver.switchTo().window(actual);

                    //opening the URL saved.
                    Constants.driver.navigate().to(data);
                }
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";
        }
        return KEYWORD_PASS;
    }

    public String navigateTab(String Object, int data) throws Exception {
        try {
            ArrayList<String> tabs = new ArrayList<String>(Constants.driver.getWindowHandles());
            Constants.driver.switchTo().window(tabs.get(data));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyElementTitle(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getAttribute("title");
            if (actual.length() < 1) {
                System.out.println("Actual Length:->" + actual.length());
            }
            LogCapture.info("Actual:->" + actual);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return actual;
    }

    //For PFX
    public String updateDB(String environment, String data, String operationType) throws Exception {
        //For connection
        Connection connection = null;
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String OTP = null;
        String query = null;
        String value = null;
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("SITDB_URL") + ":" + Constants.DBCONFIG.getProperty("SITDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("SITDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
        }

        try {
            //LogCapture.info("try");
            //LogCapture.info("DB_URL->"+DB_URL);
            //LogCapture.info("DB_USER->"+DB_USER);
            //LogCapture.info("DB_PASSWORD->"+DB_PASSWORD);
            String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            Class.forName(dbClass).newInstance();

            // Get connection to DB
            LogCapture.info("Get connection to DB");

            connection = getConnection(DB_URL, DB_USER, DB_PASSWORD);
            if (connection != null) {
                LogCapture.info("Connected to DB");
            }
            // Statement object to send the SQL statement to the Database
            //String query = "SELECT TOP  1 Pin FROM [NGOP-UAT].dbo.CustomerPin  where Email =? ORDER by CreatedOn  DESC";
            if (operationType.equalsIgnoreCase("Reset Prefer Phone")) {
                LogCapture.info("In->" + operationType);
                query = "UPDATE [NGOP].[dbo].[Customer]  SET PreferredPhoneNo = NULL , LastPinVerifiedOn = NULL , verificationPreferences = NULL where Email=?";
                ps = connection.prepareStatement(query);
                LogCapture.info("query after connection");
                ps.setNString(1, data);
                LogCapture.info("set first query parameter");
                int recordnumber = ps.executeUpdate();
                LogCapture.info(+recordnumber + " records updated for user " + data);
                value = Constants.KEYWORD_PASS;

            } else if (operationType.equalsIgnoreCase("Set Prefer Phone")) {
                query = "UPDATE [NGOP].[dbo].[Customer] SET PreferredPhoneNo='+91-9000000004' where Email =?";
                ps = connection.prepareStatement(query);
                ps.setNString(1, data);
                int recordnumber = ps.executeUpdate();
                LogCapture.info(+recordnumber + " records updated for user " + data);
                value = Constants.KEYWORD_PASS;

            } else if (operationType.equalsIgnoreCase("OTP")) {
                query = "SELECT TOP  1 Pin FROM [NGOP-UAT].dbo.CustomerPin  where Email =? ORDER by CreatedOn  DESC";

                ps = connection.prepareStatement(query);
                ps.setNString(1, data);
                ResultSet res = ps.executeQuery();
                // Get the contents of CustomerPin table from DB
                while (res.next()) {
                    OTP = res.getString("Pin");
                    break;
                    // System.out.println("OTP :" + OTP);
                }
                value = OTP;
            }
            return value;

        } catch (Exception e) {
            System.out.println("Unable to do operation" + operationType + "--" + e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        } finally {
            // Close DB connection
            if (connection != null) {
                connection.close();
            }
        }
    }

    //For CFX
    public String getOTP(String object, String data) throws Exception {
        //For connection
        Connection connection = null;
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String OTP = null;
        String query = null;
        if (object.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("SITDB_URL") + ":" + Constants.DBCONFIG.getProperty("SITDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("SITDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("SITDB_Password");
            query = "SELECT TOP  1 Pin FROM [NGOP-SIT].dbo.CustomerPin  where Email =? ORDER by CreatedOn  DESC";
            //"jdbc:sqlserver://172.31.4.93:1433
        } else if (object.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
            query = "SELECT TOP  1 Pin FROM ngop.dbo.CustomerPin where Email =? ORDER by CreatedOn  DESC";
        }
        try {
            String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            Class.forName(dbClass).newInstance();
            // Get connection to DB
            connection = getConnection(DB_URL, DB_USER, DB_PASSWORD);
            // Statement object to send the SQL statement to the Database
            //String query = "SELECT TOP  1 Pin FROM [NGOP-UAT].dbo.CustomerPin  where Email =? ORDER by CreatedOn  DESC";

            ps = connection.prepareStatement(query);
            ps.setNString(1, data);
            ResultSet res = ps.executeQuery();
            // Get the contents of CustomerPin table from DB
            while (res.next()) {
                OTP = res.getString("Pin");
                break;
                // System.out.println("OTP :" + OTP);
            }
            return OTP;
        } catch (Exception e) {
            System.out.println("Unable to fetch OTP from Database : " + e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        } finally {
            // Close DB connection
            if (connection != null) {
                connection.close();
            }
        }
    }

    //This mehod used for creating new batch file for Reject batch scenario as same file cannot reject multiple time
    public String getNewDataFile(String srcFileName) {
        String fileName = "B" + System.currentTimeMillis();
        //String fileName = "A"+ TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis());
        File sourceFile = new File(System.getProperty("user.dir") + "/src/main/resources/" + srcFileName);
        File newFile = new File(System.getProperty("user.dir") + "/src/main/resources/" + fileName + ".csv");
        try {
            newFile.createNewFile();
            FileUtils.copyFile(sourceFile, newFile);
            return newFile.getAbsolutePath();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    //After uploading new created file it will be deleted instead storing in resources
    public void deletefile(String fileName) {
        File file = new File(fileName);
        try {
            if (file.delete()) {
                System.out.println("File deleted successfully");
            } else {
                System.out.println("Failed to delete the file");
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public String selectDateFromDatePicker(String object, String data) throws Exception {

        try {
            WebElement dateWidget = Constants.driver.findElement(By.xpath(object));

            List<WebElement> columns = dateWidget.findElements(By.tagName("td"));

            for (WebElement cell : columns) {
                if (cell.getText().equals(data)) {
                    cell.click();
                    return KEYWORD_PASS;
                }
            }

            return Constants.KEYWORD_FAIL;
        } catch (Exception e) {
            System.out.println(" Invalid date : " + e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
    }

    public String elementNotClickable(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_PASS;
        }
        return KEYWORD_FAIL + "element is clickable";
    }


    public String RecipientEdit(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Edit')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String WaitByTime(String object, Integer time) throws Exception {
        try {

            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(time));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to find...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String SelectValueFromDropDown(String object, String data) {
        try {
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            for (int i = 1; i <= 15; i++) {
                //System.out.println(dropdown_list.get(i).getText());
                //ul[@id="select2-txnValue_id-results"]//li[1]
                String vPath = "//ul[@id='select2-txnValue_id-results']//li[" + i + "]";
                String vdata = key.getText(vPath, "");
                if (vdata.equalsIgnoreCase(data)) {
                    Constants.driver.findElement(By.xpath(vPath)).click();
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String dropdown(String object, String data) {
        try {
            Select option = new Select(Constants.driver.findElement(By.xpath(object)));
            option.selectByVisibleText(data);

        } catch (Exception e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String DeleteRelevantRecipient(String object, String data) {
        try {
            List<WebElement> RecipientSize = Constants.driver.findElements(By.xpath("//*[@id=\"payees\"]/tbody/tr/td[1]/span"));
            for (int i = 1; i < RecipientSize.size(); i++) {
                String Element = "//*[@id=\"payees\"]/tbody/tr[" + i + "]/td[1]/span";
                String ActualName = key.getText(Element, "");
                if (ActualName.equalsIgnoreCase(data)) {
                    String vClose = "//*[@id=\"payees\"]/tbody/tr[" + i + "]/td[5]/div/a[3]/span";
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vClose, ""));
                    String vConfirm = Constants.loginPageOR.getProperty("ConfirmDelete");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vConfirm, ""));
                }
            }
        } catch (Exception e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String AcceptCookies() {
        try {
            //If Cookies window exist then accept the cookies and proceed or else skip
            // Waiting for cookies to load hence 10 sec pause is implemented
            String vCookies_Accept = Constants.SignUp.getProperty("Cookies_Accept");
            if (Constants.key.dynamicVisibleConditionWait(vCookies_Accept, 20).equalsIgnoreCase("Pass")) {
                Assert.assertEquals("PASS", Constants.key.click(vCookies_Accept, ""));
                Constants.key.pause("1", "");
                LogCapture.info("Cookies Accepted");
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogCapture.info("Cookies Not Accepted");
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String ClickConfirm(String object, String actual, Range re) {
        try {

            String status = "";
            do {
                if (re.isInclude(Integer.parseInt(actual))) {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(object, ""));
                    status = Constants.key.click(object, "");
                    LogCapture.info("Confirm button clicked...");

                    Constants.key.pause("5", "");
                }
            } while (status.equalsIgnoreCase("pass"));
        } catch (Exception e) {
            e.printStackTrace();
            LogCapture.info("Failed to click conirf");
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String dynamicVisibleConditionWait(String object, int TimeoutSec) throws Exception {
        try {

            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(TimeoutSec));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to find...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String RemoveSpace(String object) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.CONTROL, Keys.chord("a"));
            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.BACK_SPACE);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    /****************************** SF **********************************/


    public String SfLeadDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("2", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String CurrentDay(String Format) throws Exception {
        Date date = new Date();
        SimpleDateFormat formatter;
        if (Format.equalsIgnoreCase("dd/MM/yyyy")) {
            formatter = new SimpleDateFormat("dd/MM/yyyy");
            return formatter.format(date);
        } else if (Format.equalsIgnoreCase("MM/dd/yyyy")) {
            formatter = new SimpleDateFormat("MM/dd/yyyy");
            return formatter.format(date);
        } else if (Format.equalsIgnoreCase("dd MMMM yyyy")) {
            formatter = new SimpleDateFormat("dd MMMM yyyy");
            return formatter.format(date);
        }
        return "NoDate";
    }


    public String waitForPageLoad() {
        try {
            ExpectedCondition<Boolean> pageLoadCondition = driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            WebDriverWait wait = new WebDriverWait(driver,  Duration.ofSeconds(120));
            wait.until(pageLoadCondition);
        } catch (Exception e) {
            LogCapture.info("Page NotLoaded Properly" + e);
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String ClickByJavaScript(String object) {
        try {
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            WebElement element = Constants.driver.findElement(By.xpath(object));
            executor.executeScript("arguments[0].click();", element);
        } catch (Exception e) {
            LogCapture.info("Page NotLoaded Properly" + e);
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    /******************************* Affiliate and AE *************************/


    public String verifycolumn(String object, String data) throws Exception {
        try {
            String expected[] = data.split(",");
            LogCapture.info("List of coulmns: " + data);
            List<WebElement> ele = Constants.driver.findElements(By.xpath(object));
            LogCapture.info("ColumnNo is: " + ele.size());
            // LogCapture.info("ele is: "+ele);
            int flag = 0;
            if (data.split(",").length != ele.size()) {
                Assert.fail("Portal size = " + ele.size() + " and expected count = " + data.split(",").length);
            }
            for (int i = 0; i < ele.size(); i++) {
                String actual = ele.get(i).getText().trim();
                LogCapture.info("Actual columnnames: " + actual);
                LogCapture.info("Expected column names: " + expected[i]);
                if (actual.equalsIgnoreCase(expected[i])) {
                    takeSnapShot();
                    LogCapture.info("column " + actual + " is verified");

                } else {
                    takeSnapShot();

                    LogCapture.info("column " + actual + " is not verified");
                    flag = 1;
                    break;
                }
            }
            if (flag == 0) {
                return Constants.KEYWORD_PASS;
            } else if (flag == 1) {
                return Constants.KEYWORD_FAIL + "...text not verified " + actual + "  ";
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Object not found...." + e.getMessage();

        }
        return Constants.KEYWORD_PASS;
    }


    public String Alert() throws Exception {
        try {
            Constants.driver.switchTo().alert().dismiss();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_PASS;
        }
        return Constants.KEYWORD_FAIL;

    }


    public String verifyrowCount(String object, String data) throws Exception {
        try {
            List<WebElement> ele = Constants.driver.findElements(By.xpath(object));
            int actual = ele.size();
            LogCapture.info("size is" + actual);
            int expected = 1;
            if (actual == expected && data.equalsIgnoreCase("single")) {
                takeSnapShot();
                LogCapture.info("Single row verified.Row Count " + ele.size());
                return Constants.KEYWORD_PASS;
            } else if (actual > expected && data.equalsIgnoreCase("multiple")) {
                takeSnapShot();
                LogCapture.info("Multiple row verified.Row Count " + ele.size());
                return Constants.KEYWORD_PASS;
            } else {

                return Constants.KEYWORD_FAIL + "Single row.Not verified " + ele.size();
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
    }


    public String implicitwait(String object, String data) throws Exception {
        try {
            int time = Integer.parseInt(data);
            Constants.driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
            takeSnapShot();
            return Constants.KEYWORD_PASS;

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }

    }

    public int getXpathIndex(String object, String data) throws Exception {
        int Index = 0;
        try {
            List<WebElement> ele = driver.findElements(By.xpath(object));
            for (WebElement e : ele) {
                Index++;
                String colName = e.getText().trim();
                if (data.equalsIgnoreCase(colName)) {
                    break;
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return 0;
        }
        return Index;
    }

    public String sendkeyboardStroke(String object, String data) throws Exception {
        //valid values for data = space,enter,up,tab,down,left,right
        try {
            Robot robot = new Robot();
            if (!object.equals("")) {
                WebElement browseBtn = Constants.driver.findElement(By.xpath(object));
                browseBtn.click();
                Thread.sleep(1000);
            }
            if (data.equals("space")) {
                robot.keyPress(KeyEvent.VK_SPACE);
                robot.keyRelease(KeyEvent.VK_SPACE);
            } else if (data.equals("enter")) {
                robot.keyPress(KeyEvent.VK_ENTER);
                robot.keyRelease(KeyEvent.VK_ENTER);
            } else if (data.equals("tab")) {
                robot.keyPress(KeyEvent.VK_TAB);
                robot.keyRelease(KeyEvent.VK_TAB);
            } else if (data.equals("down")) {
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Thread.sleep(1000);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "....unable to find element...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    public String UniqueEmail_ID(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            String emailID = "xyz" + userName + "@mailinator.com";
            //System.out.println("Result......" + emailID);
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(1000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(emailID);
            Thread.sleep(1000);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return Constants.KEYWORD_PASS;
    }

    public String VerifyAllDropDownValues1(String sheetName, String colName, String object) throws Exception {
        System.out.println("start");
        String fileName = System.getProperty("user.dir") + "/TestData.xlsx";
        File file = new File(fileName);
        FileInputStream inputStream = new FileInputStream(file);
        String fileExtensionName = fileName.substring(fileName.indexOf("."));
        System.out.println("end");
        if (fileExtensionName.equals(".xlsx")) {
            System.out.println("if");
            Workbook DropDownworkbook = null;
            DropDownworkbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = (XSSFSheet) DropDownworkbook.getSheet(sheetName);
            XSSFRow row;
            XSSFCell cell;
            String CellValue = null;
            ArrayList<String> ActualDropDownValues = new ArrayList<String>();
            ArrayList<String> ExpectedDropDownValues = new ArrayList<String>();
            driver.findElement(By.xpath("//button[@title='" + colName + "']")).click();
            Thread.sleep(3000);
            List<WebElement> contentOfRowsInColumn0 = driver.findElements(By.xpath("//button[@title='" + colName + "']//following-sibling::div//li"));
            int pp = 1;
            for (WebElement temp : contentOfRowsInColumn0) {

                String textvalue = temp.getText();
                ActualDropDownValues.add(textvalue);
                System.out.println(pp + ":" + textvalue);
                pp++;
            }
            try {
                int col_Num = -1;
                row = sheet.getRow(0);
                System.out.println("Ronumber" + row);
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    if (row.getCell(j).getStringCellValue().trim().equals(colName.trim())) {
                        col_Num = j;
                        System.out.println("ColNum" + col_Num);
                        //row= sheet.getRow(j);
                        //driver.findElement(By.xpath("//button[@title='" + colName + "']")).click();
                        List<WebElement> contentOfRowsInColumn = driver.findElements(By.xpath("//button[@title='" + colName + "']//following-sibling::div//li"));

                        int lengthOfColumn = contentOfRowsInColumn.size();
                        for (int i = 1; i <= lengthOfColumn; i++) {
                            row = sheet.getRow(i);
                            cell = row.getCell(col_Num);
                            if (cell.getStringCellValue().equalsIgnoreCase("")) {
                                System.out.println("Empty Value");
                            } else {
                                if (cell.getCellTypeEnum() == CellType.STRING) {
                                    CellValue = cell.getStringCellValue();
                                    System.out.println("Value" + CellValue);
                                    ExpectedDropDownValues.add(CellValue);
                                    // return CellValue;
                                } else if (cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA) {
                                    CellValue = valueOf(cell.getNumericCellValue());
                                    if (HSSFDateUtil.isCellDateFormatted(cell)) {
                                        DateFormat df = new SimpleDateFormat("dd/MM/yy");
                                        Date date = cell.getDateCellValue();
                                        CellValue = df.format(date);
                                    }
                                    // return CellValue;
                                } else if (cell.getCellTypeEnum() == CellType.BLANK) {
                                    CellValue = "";
                                    //return CellValue;
                                } else if (cell.getBooleanCellValue()) {
                                    CellValue = valueOf(cell.getBooleanCellValue());
                                    //return CellValue;
                                } else if (!cell.getBooleanCellValue()) {
                                    CellValue = valueOf(cell.getBooleanCellValue());
                                    //return CellValue;
                                }
                            }

                            // return CellValue;

                            // return "row " + rowNum + " or column " + colName + " does not exist  in Excel";
                        }
                        Assert.assertEquals(ExpectedDropDownValues, ActualDropDownValues);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "data not found";
            }
        }
        return "row " + " or column " + colName + " does not exist  in Excel";
    }

    public String selectValueFromDropDown(String object, String object1, String data) throws Exception {
        Actions act = new Actions(driver);
        act.moveToElement(driver.findElement(By.xpath(object))).click().build().perform();
        List<WebElement> allCategories = driver.findElements(By.xpath(object1));
        for (WebElement element : allCategories) {
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait("temp", ""));
            Thread.sleep(100);
            String elementtext = element.getText();
            //Thread.sleep(1000);
            if (elementtext.equalsIgnoreCase(data)) {
                act.moveToElement(element).click().build().perform();
                System.out.println(elementtext);
                break;
            }
        }
        return Constants.KEYWORD_PASS;
    }

    public String clearText(String object, String Data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).clear();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String clicks(String object, String data) throws Exception {
        try {
            WebElement ele = Constants.driver.findElement(By.xpath(object));
            //WebElement ele = driver.findElement(By.xpath("element_xpath"));
            JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("arguments[0].click();", ele);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;

    }

    public String getAttributeText(String object, String data) throws Exception {
        try {
            WebElement targetElement = Constants.driver.findElement(By.xpath(object));
            actual = targetElement.getAttribute("value");
            System.out.println("Actual Length:->"+actual.length());
            System.out.println("actual value->>>>" + actual + '\n' + "data value->>>>" + data);
            if (actual.equals(data)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + data;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String closeBrowser(String object, String data)throws Exception
    {
        try
        {
            Constants.driver.quit();
        }
        catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found..." + ex);

            takeSnapShot();
            return KEYWORD_FAIL ;
        }
        return KEYWORD_PASS;
    }

    public String notVisible(String object, String data) throws Exception{
        try {
            if(data.contains("notDisplayed")){
                if (!Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                }
                else{
                    takeSnapShot();
                    return KEYWORD_FAIL + " -  Displayed";
                }
            }
        }
        catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + " -  Could not find element";

        }
        return KEYWORD_PASS;
    }

    public static JsonPath rawToJason(String response) {
        JsonPath js1 = null;
        try {
            LogCapture.info("-------------Converting to JSON, response => " + response + "--------");

            js1 = new JsonPath(response);

            return (js1);
        } catch (Exception e) {
            LogCapture.info("Error occurred in rawToJason method. The error is: " + e);
            e.printStackTrace();
        }
        return js1;
    }

//    public static void modifyAmount(String filePath)
//    {
//        File fileToBeModified = new File(filePath);
//        String oldContent = "16,195,";
//        BufferedReader reader = null;
//        FileWriter writer = null;
//        String oldAmount="";
//        String newAmount="";
//        String RandomNumber = RandomStringUtils.randomNumeric(5);
//        RandomNumber = RandomNumber.startsWith("0") ? RandomNumber.substring(1) : RandomNumber;
//        // double newAmount = Double.parseDouble(RandomNumber);
//        LogCapture.info("New Trade Amount : " + RandomNumber);
//        Constants.Amount = RandomNumber;
//        try
//        {
//            reader = new BufferedReader(new FileReader(fileToBeModified));
//            String line = reader.readLine();
//            if(line.contains(oldContent)) {
//                    oldAmount = oldAmount + line + System.lineSeparator();
//                    line = reader.readLine();
//                }
//            String newContent = oldAmount.replaceAll(oldAmount, newAmount);
//            writer = new FileWriter(fileToBeModified);
//            writer.write(newContent);
//            Amount=Amount+100;
//
//        }
//        catch (IOException e)
//        {
//            e.printStackTrace();
//        }
//        finally
//        {
//            try
//            {
//                reader.close();
//                writer.close();
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//        }
//    }
    public static void modifyFile(String filePath, String oldString, String newString)
    {
        File fileToBeModified = new File(filePath);
        String oldContent = "";
        BufferedReader reader = null;
        FileWriter writer = null;
        try
        {
            reader = new BufferedReader(new FileReader(fileToBeModified));
            String line = reader.readLine();
            while (line != null)
            {
                oldContent = oldContent + line + System.lineSeparator();
                line = reader.readLine();
            }
            String newContent = oldContent.replaceAll(oldString, newString);
            if(filePath.contains("MT")){
                Constants.messageInQuery=newContent;
            }
            writer = new FileWriter(fileToBeModified);
            writer.write(newContent);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                reader.close();
                writer.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
    public static Map<String, String> executeQuery(String connectionUrl,String DB_USER,String DB_PASSWORD,String query) {
        Map<String, String> result = new HashMap<>();
        try (Connection connection = getConnection(connectionUrl, DB_USER, DB_PASSWORD)) {
            if (connection != null) {
                LogCapture.info("Connected to DB");
            }
            PreparedStatement ps = connection.prepareStatement(query);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData rsMD = rs.getMetaData();
                while (rs.next()) {
                        for (int i = 1; i <= rsMD.getColumnCount(); i++) {
                            result.put(rsMD.getColumnName(i), rs.getString(rsMD.getColumnName(i)));
                        }
                }

            } catch (Exception e) {
                LogCapture.error("Exception occurred while fetching the result set: " + e.getLocalizedMessage());
            }
        } catch (SQLException e) {
            LogCapture.error("Exception occurred while querying the database: " + e.getLocalizedMessage());
        }
        return result;
    }

    public static List<Map<String, String>> executeQueryForMultiRows(String connectionUrl,String DB_USER,String DB_PASSWORD, String query) {
        List<Map<String, String>> records = new ArrayList<>();
        try (Connection connection = getConnection(connectionUrl, DB_USER, DB_PASSWORD)) {
            PreparedStatement ps = connection.prepareStatement(query);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData rsMD = rs.getMetaData();
                while (rs.next()) {
                    Map<String, String> record = new HashMap<>();
                    for (int i = 1; i <= rsMD.getColumnCount(); i++) {
                        record.put(rsMD.getColumnName(i), rs.getString(rsMD.getColumnName(i)));
                    }
                    records.add(record);
                }

            } catch (Exception e) {
                System.out.println("Exception occurred while fetching the result set: " + e.getLocalizedMessage());
            }
        } catch (SQLException e) {
            System.out.println("Exception occurred while querying the database: " + e.getLocalizedMessage());
        }
        return records;
    }

    public static Map<String, String> getSqlQueryResult(String sqlQueryProperty, String... values) {
        String query ="";
        if(sqlQueryProperty.equalsIgnoreCase("QueryForInsert")){
            query= messageInQuery;
            LogCapture.info("Query is "+query);

        }else {
             query = SQL_Queries.getProperty(sqlQueryProperty);
             query = format(query, (Object[]) values);
             LogCapture.info("Query is "+query);
        }
        return executeQuery(Constants.connectionUrl,Constants.dBUsername,Constants.dbPassword,query);
    }

    public static List<Map<String, String>> getSqlQueryResultForMultiRows(String sqlQueryProperty, String... values) {
        String query ="";
        if(sqlQueryProperty.equalsIgnoreCase("QueryForInsert")){
            query= messageInQuery;
            LogCapture.info("Query is "+query);

        }else {
            query = SQL_Queries.getProperty(sqlQueryProperty);
            query = format(query, (Object[]) values);
            LogCapture.info("Query is "+query);
        }
        return executeQueryForMultiRows(Constants.connectionUrl,Constants.dBUsername,Constants.dbPassword,query);
    }

    public static Map<String, String> getSqlQueryResultDB(String sqlQueryProperty, String... values) {
        String queryInfo = Constants.SQL_Queries.getProperty(sqlQueryProperty);
        String db = queryInfo.split("\\|")[0];
        String query = queryInfo.split("\\|")[1];
        if(Objects.nonNull(values)) {
            query = String.format(query, (Object[]) values);
            query = query.replaceAll("\\{ENV}", Constants.JenkinsEnvironment);
        }
        System.out.println(query);
        return ReusableMethod.executeQuery(db + Constants.JenkinsEnvironment, query);
    }

    public static Map<String, String> executeQuery(String databaseName, String query) {
        Map<String, String> trnDetails = new HashMap<>();
        try (Connection connection = getConnection(databaseName)) {
            PreparedStatement ps = connection.prepareStatement(query);
            boolean retry = true;
            int retryCount = 5;
            while (retry && retryCount-- > 0) {
                try (ResultSet rs = ps.executeQuery()) {
                    ResultSetMetaData rsMD = rs.getMetaData();
                    while (rs.next()) {
                        retry = false;
                        for (int i = 1; i <= rsMD.getColumnCount(); i++) {
                            trnDetails.put(rsMD.getColumnName(i), rs.getString(rsMD.getColumnName(i)));
                        }
                        break;
                    }
                    pause(1);
                } catch (Exception e) {
                    LogCapture.error("Exception occurred while fetching the result set: " + e.getLocalizedMessage());
                }
            }
        } catch (SQLException e) {
            LogCapture.error("Exception occurred while querying the " + databaseName + " database: " + e.getLocalizedMessage());
        }
        return trnDetails;
    }

    public static void pause(int seconds) {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            LogCapture.error("Could not pause the execution: " + e.getLocalizedMessage());
        }
    }

    public static void updateXmlFile(String Tag, String NewValue){

        NodeList NodeList = doc1.getElementsByTagName(Tag); // Document object to find the tag that needs to be updated
        for (int i = 0; i < NodeList.getLength(); i++) {
            Node node = NodeList.item(i);
            node.setTextContent(NewValue);   //  Update the tag with the new value
            LogCapture.info("New value at Tag :"+Tag+" is "+NewValue);
        }

    }
    public static void updateXmlParentChild(String ParentTag, String ChildTag, String NewValue){

        NodeList parentTags = doc1.getElementsByTagName(ParentTag);

        // Iterate through parent tags
        for (int i = 0; i < parentTags.getLength(); i++) {
            Node parentTag = parentTags.item(i);

            if (parentTag.getNodeType() == Node.ELEMENT_NODE) {
                Element parentElement = (Element) parentTag;

                // Find the child tags by tag name within the parent tag
                NodeList childTags = parentElement.getElementsByTagName(ChildTag);

                // Iterate through child tags
                for (int j = 0; j < childTags.getLength(); j++) {
                    Element childTag = (Element) childTags.item(j);

                    // Update the child tag's value
                    childTag.setTextContent(NewValue);
                    break;
                }
            }
        }

    }

    public static void updateCurrencyXmlFile(String Tag, String NewValue){

        NodeList NodeList = doc1.getElementsByTagName(Tag); // Document object to find the tag that needs to be updated
        for (int i = 0; i < NodeList.getLength(); i++) {
            Node node = NodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                element.setAttribute("Ccy", NewValue);
//                    element.setTextContent(NewValue);
            }
        }

    }
    public static File RenameCAMTFile(String FileType, String Bank,String AccountNumber) throws Exception {
        DateTimeFormatter date=DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime now=LocalDateTime.now();
        Constants.nameDate=date.format(now);

        String RandomNumber=RandomStringUtils.randomNumeric(5);
        String number=RandomNumber;

        File camtFile=null;
        File Rename =null;
                File directoryPath=new File("Files/"+Bank+"/");

        String contents[]=directoryPath.list(); //List of all files and directories
        // key.pause("2","");
        LogCapture.info("List of files and directories in the specified directory:"+directoryPath);
        for(int i=0; i<contents.length;i++) {
            if(contents[i].contains(FileType)){
                camtFile=new File("Files/"+Bank+"/"+contents[i]);
                LogCapture.info("old file name "+camtFile.getName());
                break;
            }
        }
        if (FileType.contains("camt.")) {
             Rename = new File("Files/" + Bank + "/" + FileType + "001.02.stm_D" + nameDate + "_R667" + number + ".F020002");
        }else if(FileType.contains("pain.002")){
            Rename = new File("Files/" + Bank + "/" + FileType + "001.03.D" + nameDate + "_R667" + number + ".F020002.SNL35343D23678530057799989S");
        }
        else {
                LogCapture.info("old Amount is "+oldAmountStarting);

            Constants.oldAmountStarting=camtFile.getName().split("%")[1];

            LogCapture.info("Old Amount was starts with "+oldAmountStarting);
            RandomNumber= valueOf(RandomNumber(1000));
            if(Amount!=null) {
                Constants.newAmount=Amount;
            }if(newAmount==null) {
                Constants.newAmount=RandomNumber;
            }

            LogCapture.info("New Amount starts with"+newAmount);
            Constants.dateReplace=camtFile.getName().split("%")[2];
            LogCapture.info("Old date was "+dateReplace);
            Constants.OldAccountNumber=camtFile.getName().split("%")[3];
            LogCapture.info("Old Account Number was "+OldAccountNumber);
            if (FileType.contains("MT940")||FileType.contains("MT942")) {
                Constants.Olddate = camtFile.getName().split("%")[4];
                LogCapture.info("Old date in yyddmm for MT940" + Olddate);
            }

            if (FileType.contains("BMO")) {
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyMMdd");
                Constants.currentDate=dtf.format(now);
                Rename = new File("Files/" + Bank + "/" + FileType + "%" + newAmount + "%" + currentDate + "%%58gcnn00ingulkar7k002dar.txt");
            }if (FileType.contains("JPMGTM")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
                Constants.currentDate=dtf.format(now);
                LogCapture.info("old Transaction Reference is "+old_Transaction_Reference_MessageOut);
                Constants.old_Transaction_Reference_MessageOut=camtFile.getName().split("%")[4];
                LogCapture.info("Old Transaction Reference was starts with "+old_Transaction_Reference_MessageOut);
                Rename=new File("Files/" + Bank + "/" + FileType + "%" + newAmount +"%"+currentDate+"%"+AccountNumber+"%"+Transaction_Reference_MessageOut+"%436.json");
            }if (FileType.contains("JPMGACH")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
                Constants.currentDate=dtf.format(now);
                LogCapture.info("old old_hyperion_reference_id is "+old_hyperion_reference_id);
                Constants.old_hyperion_reference_id=camtFile.getName().split("%")[4];
                LogCapture.info("Old hyperion_reference_id was starts with "+old_hyperion_reference_id);
                if(hyperion_reference_id==null){
                    hyperion_reference_id="3TESTDD29112023";
                }
                Rename=new File("Files/" + Bank + "/" + FileType + "%" + newAmount +"%"+currentDate+"%"+AccountNumber+"%"+hyperion_reference_id+"%436.json");
            }else if (FileType.contains("JPM")||FileType.contains("JPMGDeposit")||FileType.contains("JPMGVBANnoRef") ||FileType.contains("VBANFundsIn")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
                Constants.currentDate=dtf.format(now);
                Rename=new File("Files/" + Bank + "/" + FileType + "%" + newAmount +"%"+currentDate+"%"+AccountNumber+"%%45_132_00_01_436.json");
            }else if (FileType.contains("MT940")||FileType.contains("MT942")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyMMddMMdd");
                Constants.currentDate=dtf.format(now);
                DateTimeFormatter dtf1=DateTimeFormatter.ofPattern("yyMMdd");
                Constants.currentDate1=dtf1.format(now);
                Rename=new File("Files/" + Bank + "/" + FileType + "%" + newAmount +"%"+currentDate+"%"+AccountNumber+"%"+currentDate1+"%45_132_00_01_436.text");
            }else if (FileType.contains("MT103") || FileType.contains("MT103ROF")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyMMdd");
                Constants.currentDate=dtf.format(now);
                Rename=new File("Files/" + Bank + "/" + FileType + "%" + newAmount +"%"+currentDate+"%%45_132_00_01_436.text");
            }else if (FileType.contains("ManualPayment")) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                Constants.currentDate = dtf.format(now);
                Rename = new File("Files/" + Bank + "/" + FileType + "_" + currentDate + ".xlsx");
            }
        }

        camtFile.renameTo(Rename);
        return Rename;
    }
    public static void pauseforSchedular() throws InterruptedException {
        LocalDateTime now = LocalDateTime.now();
        int seconds = now.getSecond();
        int Actualpause = 77 - seconds;
        if (Actualpause<20){
            key.pause("27","");
        }else {
            key.pause(valueOf(Actualpause),"");
        }
//        key.pause(String.valueOf(Actualpause),"");
    }

    public static String readDataFromExcel(int rowcount,int columncount,String filepath,String Sheetname )
    {
        String data=null;
        try
        {
            FileInputStream input= new FileInputStream(filepath);
            XSSFWorkbook wb=new XSSFWorkbook(input);
            XSSFSheet sh=wb.getSheet(Sheetname);
            XSSFRow row=sh.getRow(rowcount);
            row.getCell(columncount).toString();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return data;
    }

    public boolean isElementDisplayed(String object, int waitInSeconds) {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(waitInSeconds));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            return true;
        } catch (Exception e) {
        }
        return false;
    }

    public static void loginToKafkaUI() throws Exception {
        LogCapture.info("----------------User enters UserName and Password-------------------");
        String environment = CONFIG.getProperty("Environment");
        String username = Constants.CONFIG.getProperty("KafkaUsername" + environment);
        String password = Constants.CONFIG.getProperty("KafkaPassword" + environment);
        String vObjUser = Constants.KafkaUI.getProperty("Username");
        String vObjPass = Constants.KafkaUI.getProperty("Password");

        Assert.assertTrue(Constants.key.isElementDisplayed(vObjUser, 20), "Kafka Login page is not displayed");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, username));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, password));
        String vObjLoginButton = Constants.KafkaUI.getProperty("SignIn");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    public static JsonPath waitForKafkaMessage(String uniqueIdentifier) throws Exception {

        LogCapture.info("Waiting for Kafka message to populate on UI.....");
        LocalDateTime localDateTime = LocalDateTime.now();
        String kafkaJsonMessage;
        boolean isMessageLineDisplayed = false;

        String messageFieldXpath = Constants.KafkaUI.getProperty("MessageField");
        messageFieldXpath = messageFieldXpath.replace("{uniqueMessageId}", uniqueIdentifier);

        while(!isMessageLineDisplayed && ReusableMethod.getTimeLapsedInSeconds(localDateTime) < 200) {
            isMessageLineDisplayed = Constants.key.isElementDisplayed(messageFieldXpath, 10);
        }

        kafkaJsonMessage = Constants.key.getText(messageFieldXpath,"");
        System.out.println(kafkaJsonMessage);
        Assert.assertTrue(isMessageLineDisplayed, "Message is not found within 3 minutes");
        JsonPath jsonPath = JsonPath.from(kafkaJsonMessage);
        return jsonPath;
    }

    private static Map<String, String> getAuditMappings(String mappingFilePath) {
        Properties mappings = ReusableMethod.getProperties(mappingFilePath);
        List<String> actualFieldName = new ArrayList<>(mappings.stringPropertyNames());
        Map<String, String> resultPaths = new HashMap<>();
        for(String path : actualFieldName) {
            String[] splitedPath = path.split("\\.");
            String pathPrefix = splitedPath[0];
            String auditColName = splitedPath[1].toLowerCase();
            if(pathPrefix.equalsIgnoreCase("MessageHeader")) {
                auditColName = "h" + auditColName;
            }
            resultPaths.put(auditColName, mappings.getProperty(path));
        }
        return resultPaths;
    }

    private static Map<String, String> getKafkaMappings(String mappingFilePath) {
        Properties mappings = ReusableMethod.getProperties(mappingFilePath);
        List<String> actualFieldName = new ArrayList<>(mappings.stringPropertyNames());
        Map<String, String> resultPaths = new HashMap<>();
        for(String path : actualFieldName) {
            resultPaths.put(path, mappings.getProperty(path));
        }
        return resultPaths;
    }

    public static void validateKafkaMessage(JsonPath ExpectedJsonPath, JsonPath jsonPathObj, String mappingFilePath, boolean isAudit) {
        Map<String, String> fieldMappings;
        if(isAudit) {
            fieldMappings = getAuditMappings(mappingFilePath);
        } else {
            fieldMappings = getKafkaMappings(mappingFilePath);
        }
        String expectedValue; boolean isCompareDouble = false;
        for (String jsonPathStr : fieldMappings.keySet()) {
            String actualValue = jsonPathObj.getString(jsonPathStr);
            actualValue = Reusables.cleanJsonPathValue(actualValue);
            //Assert.assertNotNull(actualValue, "Could not parse JsonPath value from the actual Json Message");
            String expectedMappingPropertyValue = fieldMappings.get(jsonPathStr);
            if (expectedMappingPropertyValue.equalsIgnoreCase("skip")) {
                continue;
            }

            if (expectedMappingPropertyValue.contains("value=")) {
                expectedValue = expectedMappingPropertyValue.split("=")[1];

            } else if (expectedMappingPropertyValue.contains("compareDouble")) {
                String expectedMappingPropertyVal = expectedMappingPropertyValue.split("=")[1];

                expectedValue = ExpectedJsonPath.getString(expectedMappingPropertyVal);//ReusableMethod.getXpathValue(JsonMessageActual, "//" + expectedMappingPropertyVal);
                // If no value in XML, then nothing to check //TODO put this as common to all conditions
                if (ReusableMethod.isNotNullOrEmpty(expectedValue)) {
                    if (expectedMappingPropertyValue.contains("compareDoubleIgnoreSign")) {
                        ReusableMethod.softAssert.assertEquals(Math.abs(Double.parseDouble(actualValue.trim())), Math.abs(Double.parseDouble(expectedValue)), "Assertion for " + jsonPathStr + " failed");
                    } else {
                        ReusableMethod.softAssert.assertEquals(Double.parseDouble(actualValue.trim()), Double.parseDouble(expectedValue), "Assertion for " + jsonPathStr + " failed");
                    }

                } else {
                    ReusableMethod.softAssert.assertTrue(actualValue.isEmpty(), "No value found in XML for " + expectedMappingPropertyVal);
                }
                continue;
            } else if (expectedMappingPropertyValue.contains("concatenateXpathValues=")) {
                String allXpaths = expectedMappingPropertyValue.split("=")[1];
                String valueFromXML = "";
                // multiple Xpath values
                String[] jsonPaths = allXpaths.split(" ");
                for (String jsonPath : jsonPaths) {
                    valueFromXML = join(" ", valueFromXML, ExpectedJsonPath.getString(jsonPath));//ReusableMethod.getXpathValue(JsonMessageActual, "//" + jsonPath));
                }
                expectedValue = valueFromXML;

            } else if (expectedMappingPropertyValue.contains("method=")) {
                String methodDetails = expectedMappingPropertyValue.split("=")[1];
                String methodName = methodDetails.split("\\|")[0];
                String methodArg = methodDetails.split("\\|")[1];
                String valueFromXML = ExpectedJsonPath.getString(methodArg);//ReusableMethod.getXpathValue(JsonMessageActual, "//" + methodArg);

                if (ReusableMethod.isNotNullOrEmpty(valueFromXML)) {
                    try {
                        Class<Reusables> classObj = Reusables.class;
                        Method method = classObj.getDeclaredMethod(methodName, String.class);
                        expectedValue = (String) method.invoke(null, valueFromXML);
                    } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }

                } else {
                    ReusableMethod.softAssert.assertTrue(actualValue.isEmpty(), "No value found in XML for " + methodDetails);
                    continue; // If no value in XML, then nothing to check
                }

            } else if (expectedMappingPropertyValue.contains("checkValueContainsKey")) {
                expectedMappingPropertyValue = expectedMappingPropertyValue.split("=")[1];
                expectedValue = ExpectedJsonPath.getString(expectedMappingPropertyValue);//ReusableMethod.getXpathValue(JsonMessageActual, "//" + expectedMappingPropertyValue);
                ReusableMethod.softAssert.assertTrue(expectedValue.trim().contains(actualValue.trim()), "Assertion for " + jsonPathStr + " failed");
                continue;

            } else if (expectedMappingPropertyValue.contains("ignoreSpaces")) {
                expectedMappingPropertyValue = expectedMappingPropertyValue.split("=")[1];
                expectedValue =ExpectedJsonPath.getString(expectedMappingPropertyValue).replaceAll(" ", ""); //ReusableMethod.getXpathValue(JsonMessageActual, "//" + expectedMappingPropertyValue).replaceAll(" ", "");
                actualValue = actualValue.replaceAll(" ", "");
            } else {
                expectedValue = ExpectedJsonPath.getString(expectedMappingPropertyValue);//ReusableMethod.getXpathValue(JsonMessageActual, "//" + expectedMappingPropertyValue);
            }

            actualValue = Objects.isNull(actualValue) ? "" : actualValue; //make json field value empty if null
            expectedValue = Objects.isNull(expectedValue) ? "" : expectedValue;
            ReusableMethod.softAssert.assertEquals(actualValue, expectedValue.trim(), "Assertion for " + jsonPathStr + " failed");
        }
    }

    public static String cleanJsonPathValue(String jsonPathValue) {
        try {
            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("(\\[string|double|boolean|int):(.*)(\\])");
            Matcher matcher = pattern.matcher(jsonPathValue);
            if(matcher.find()) {
                return matcher.group(2);
            } else {
                return jsonPathValue;
            }
        } catch (Exception ex) {
            LogCapture.error("Exception occurred cleaning Kafka Message JsonPath " + jsonPathValue);
        }
        return  null;
    }

    public static JsonPath mapToJsonPath(Map<String, String> map) {
        ObjectMapper objectMapper = new ObjectMapper();
        String json;
        JsonPath jsonPath = null;
        try {
            json = objectMapper.writeValueAsString(map);
            jsonPath = JsonPath.from(json);
        } catch (JsonProcessingException e) {
            LogCapture.error("Failed converting Map to Json string.");
        }
        return jsonPath;
    }


    public static Map<String,String> verifyDBDetailsEnhanced(String environment, String data, String operationType) throws Exception {
        Connection connection = null;
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        Map<String, String> result = new HashMap<>();
        List<String> list = new ArrayList<String>();
        HashMap<String, List<String>> ActualRemitter = new HashMap<>();
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("SITDB_URL") + ":" + Constants.DBCONFIG.getProperty("SITDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("SITDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
        } else if (environment.equalsIgnoreCase("Titan_UAT")) {
            DB_URL = "jdbc:sqlserver://" + DBCONFIG.getProperty("TitanUATDB_URL") + ":" + DBCONFIG.getProperty("TitanUATDB_PORT");
            DB_USER = DBCONFIG.getProperty("TitanUATDB_User");
            DB_PASSWORD = DBCONFIG.getProperty("TitanUATDB_Password");
        }
//        else if (environment.equalsIgnoreCase("UAT")) {
//            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
//            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
//            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
//        }
        Constants.connectionUrl = DB_URL;
        Constants.dBUsername = DB_USER;
        Constants.dbPassword = DB_PASSWORD;

//        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//        Class.forName(dbClass).newInstance();

        LogCapture.info("Get connection to DB");

        if (operationType.equalsIgnoreCase("PaymentIn")) {
            result = Reusables.getSqlQueryResult("PaymentIn.Kafka", Kafka_ID);
        }if (operationType.equalsIgnoreCase("TIPaymentInstruction")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.TIPaymentInstructions", Kafka_ID);
        }if (operationType.equalsIgnoreCase("TIPaymentInstructionDetails")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.TIPaymentInstructiondetail", ID);
        }if (operationType.equalsIgnoreCase("PaymentID")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.Payment", Transaction_Reference);
        }if (operationType.equalsIgnoreCase("MessageOut")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.Messageout", Kafka_ID);
        }if (operationType.equalsIgnoreCase("AuditTrail")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.AuditTrail",Kafka_ID);
//            Map<String, String> AuditTrailID = result.get("ID");
//            LogCapture.info("Value of AuditTrailID is: " + AuditTrailID);
        }if (operationType.equalsIgnoreCase("Kafka.Audit.PaymentLifeCycleId")) {
            result = Reusables.getSqlQueryResult("Kafka.Audit.PaymentLifeCycleId",Kafka_ID);
        }if (operationType.equalsIgnoreCase("RemitterName")) {
            result = Reusables.getSqlQueryResult("RemitterDetails",data);
        }if (operationType.equalsIgnoreCase("DuplicateTransaction1")) {
            result = Reusables.getSqlQueryResult("DuplicateTransaction1",data);
        }if (operationType.equalsIgnoreCase("DuplicateTransaction2")) {
            result = Reusables.getSqlQueryResult("DuplicateTransaction2",data);
        }
        if (operationType.equalsIgnoreCase("banking_manually_approved_by")) {
            result = Reusables.getSqlQueryResult("SQLbanking_manually_approved_by",data);
        }

        return result;
    }
    public static String intToBoolean(String str) {
        if(str.equals("0")){
            return "false";
        } else {
            return "true";
        }
    }

    public static void writeDataFromExcel(int rowcount,int columncount,File filepath,String Sheetname,String value)
    {
        try
        {
            FileInputStream input=new FileInputStream(filepath);
            XSSFWorkbook wb=new XSSFWorkbook(input);
            XSSFSheet sh=wb.getSheet(Sheetname);
            XSSFRow row=sh.getRow(rowcount);
            FileOutputStream webdata=new FileOutputStream(filepath);
            row.createCell(columncount).setCellValue(value);
            wb.write(webdata);

        }
        catch(Exception e)
        {

        }
    }

    public static void writeAmountFromExcel(int rowcount,int columncount,File filepath,String Sheetname,Double value)
    {
        try
        {
            FileInputStream input=new FileInputStream(filepath);
            XSSFWorkbook wb=new XSSFWorkbook(input);
            XSSFSheet sh=wb.getSheet(Sheetname);
            XSSFRow row=sh.getRow(rowcount);
            FileOutputStream webdata=new FileOutputStream(filepath);
            row.createCell(columncount).setCellValue(value);
            wb.write(webdata);

        }
        catch(Exception e)
        {

        }
    }
    public static void writeDateFromExcel(int rowcount,int columncount,File filepath,String Sheetname,LocalDateTime value)
    {
        try
        {
            FileInputStream input=new FileInputStream(filepath);
            XSSFWorkbook wb=new XSSFWorkbook(input);
            XSSFSheet sh=wb.getSheet(Sheetname);
            XSSFRow row=sh.getRow(rowcount);
            FileOutputStream webdata=new FileOutputStream(filepath);
            row.createCell(columncount).setCellValue(value);
            wb.write(webdata);

        }
        catch(Exception e)
        {

        }
    }

    // Mailinator Methods Start
    public static String getEmail(String emailAddress, String EmailTask) throws IOException, InterruptedException {

        parseEmailAddress(emailAddress);

        JsonPath emailContent = getFirstEmail(MAILINATOR_API_URL);
        assert emailContent != null;

        switch (EmailTask.toLowerCase()) {
            case "subject":
                return getEmailSubject(emailContent);

            case "links":
                return getEmailLinks();

            case "downloadattachment":
                return processAttachments();

            case "body":
                return getEmailBody(emailContent);

            case "from":
                return getEmailFrom(emailContent);

            case "date":
                return getEmailDate(emailContent);

            case "ReplyTo":
                return getEmailReplyTo(emailContent);

            case "Time":
                return getEmailTime(emailContent);

            case "attachmentsname":
                return processAttachmentsName();

            default:
                return "Data type not recognized.";
        }
    }

    public static String getEmailUsingSubject(String emailAddress, String EmailTask, String Subject) throws IOException, InterruptedException {

        parseEmailAddress(emailAddress);

        JsonPath emailContent = getEmailUsingSubject(MAILINATOR_API_URL,Subject);
        assert emailContent != null;

        switch (EmailTask.toLowerCase()) {
            case "subject":
                return getEmailSubject(emailContent);

            case "links":
                return getEmailLinks();

            case "downloadattachment":
                return processAttachments();

            case "body":
                return getEmailBody(emailContent);

            case "from":
                return getEmailFrom(emailContent);

            case "date":
                return getEmailDate(emailContent);

            case "ReplyTo":
                return getEmailReplyTo(emailContent);

            case "Time":
                return getEmailTime(emailContent);

            case "attachmentsname":
                return processAttachmentsName();

            default:
                return "Data type not recognized.";
        }
    }

    private static void parseEmailAddress(String emailAddress) {
        int atIndex = emailAddress.indexOf('@');
        if (atIndex != -1) {
            EMAIL_NAME = emailAddress.substring(0, atIndex).trim();
            DOMAIN_NAME = emailAddress.substring(atIndex + 1).trim();
            MAILINATOR_API_URL = "https://api.mailinator.com/api/v2/domains/" + DOMAIN_NAME + "/inboxes/" + EMAIL_NAME;
        } else {
            LogCapture.info("Invalid email format. No @ character found.");
        }
    }

    private static String getEmailSubject(JsonPath emailContent) {
        return emailContent.getString("subject");
    }

    private static String getEmailDate(JsonPath emailContent) {
        String vDate = emailContent.getString("headers.date");
        LogCapture.info("Email received on date ===== " + vDate);
        return vDate;
    }

    private static String getEmailReplyTo(JsonPath emailContent) {
        String vReplyTo = emailContent.getString("headers.reply-to");
        LogCapture.info("Reply In Email ===== " + vReplyTo);
        return vReplyTo;
    }

    private static String getEmailTime(JsonPath emailContent) {
        String vTime = emailContent.getString("time");
        LogCapture.info("Email received Time ===== " + vTime);
        return vTime;
    }

    private static String getEmailLinks() throws IOException {
        String reqLink = MAILINATOR_API_URL + "/messages/" + MSG_ID + "/links";
        JsonPath jp = makeApiRequest(reqLink);
        String links = jp.getString("links");
        LogCapture.info("Links available in email are ===== " + links);
        return links;
    }

    private static String processAttachments() throws IOException, InterruptedException {
        String attachmentDetails = MAILINATOR_API_URL + "/messages/" + MSG_ID + "/attachments";
        JsonPath jp = makeApiRequest(attachmentDetails);
        int j = jp.getInt("attachments.size()");
        if (j == 0) {
            return "No Attachment Found in Email";
        }

        for (int i = 0; i < j; i++) {
            String attachmentName = jp.getString("attachments.filename[" + i + "]").replaceAll("\\[", "").replaceAll("]", "");
            String attachment = MAILINATOR_API_URL + "/messages/" + MSG_ID + "/attachments/" + attachmentName;
            downloadAttachment(attachment, attachmentName);
        }
        return "File Downloaded Successfully";
    }

    private static String processAttachmentsName() throws IOException, InterruptedException {
        String[] attachmentNames = new String[0];
        String attachmentDetails = MAILINATOR_API_URL + "/messages/" + MSG_ID + "/attachments";
        JsonPath jp = makeApiRequest(attachmentDetails);
        int j = jp.getInt("attachments.size()");
        if (j == 0) {
            return "No Attachment Found in Email";
        }
        for (int i = 0; i < j; i++) {
            String vattachmentName = jp.getString("attachments.filename[" + i + "]").replaceAll("\\[", "").replaceAll("]", "");
            attachmentNames = Arrays.copyOf(attachmentNames, attachmentNames.length + 1);
            attachmentNames[attachmentNames.length - 1] = vattachmentName;
        }
        //LogCapture.info("Attachment Name is  ----------> " + Arrays.toString(attachmentNames));
        return Arrays.toString(attachmentNames);
    }

    private static String getEmailBody(JsonPath emailContent) {
        String body = emailContent.getString("parts.body");
        Document document = Jsoup.parse(body);
        String bodyContent = document.text();
        LogCapture.info("Email Body Content ----------> " + bodyContent);
        return bodyContent;
    }

    private static String getEmailFrom(JsonPath emailContent) {
        String vFrom = emailContent.getString("fromfull");
        LogCapture.info("Email received from Email ID ----------> " + vFrom);
        return vFrom;
    }

    private static JsonPath getFirstEmail(String urlString) throws IOException {
        JsonPath jsonPath = makeApiRequest(urlString);
        MSG_ID = jsonPath.getString("msgs[0].id");
        if (Objects.nonNull(MSG_ID) && !MSG_ID.isEmpty()) {
            String firstEmail = MAILINATOR_API_URL + "/messages/" + MSG_ID;
            JsonPath res = makeApiRequest(firstEmail);
            LogCapture.info("Fetched Email is ===== " + res.getString("subject"));
            return res;
        } else {
            LogCapture.info("Error fetching MSG_ID. Ensure you have at least one email in your inbox | Please check your Email ID : 002 " + MSG_ID);
            return null;
        }
    }

    private static JsonPath getEmailUsingSubject(String urlString, String vSubject) throws IOException, InterruptedException {
        LogCapture.info("Looking for latest email with subject as \" "+vSubject+ " \" "+"........................");
        for (int i=0; i<=12;i++) {
            Constants.key.pause("5","");
            JsonPath jsonPath = makeApiRequest(urlString);
            int j = jsonPath.getInt("msgs.size()");
            for (int k = 0; k < j; k++) {
                String subject = jsonPath.getString("msgs[" + k + "].subject");
                int vTime = jsonPath.getInt("msgs[" + k + "].seconds_ago");
                if ((subject.contains(vSubject)) && vTime<=360) {
                    MSG_ID = jsonPath.getString("msgs["+k+"].id");
                    break;
                }
            }
            if (Objects.nonNull(MSG_ID) && !MSG_ID.isEmpty()) {
                String firstEmail = MAILINATOR_API_URL + "/messages/" + MSG_ID;
                JsonPath res = makeApiRequest(firstEmail);
                //LogCapture.info("Fetched Email is ----------> " + res.getString("subject"));
                return res;
            }else {
                LogCapture.info("Trying for "+i+"/18 time in a interval of 5 secs");
            }
        }
        LogCapture.info("No Latest Email Fetched with Subject as "+vSubject+ " Tried waiting for 60 Secs.");
        return null;
    }

    private static JsonPath makeApiRequest(String urlString) throws IOException {
        String responseBody = null;
        try {
            Response response = RestAssured.given().relaxedHTTPSValidation()
                    .header("Authorization", MAILINATOR_API_TOKEN)
                    .header("Accept-Encoding", "gzip, deflate, br")
                    .header("Accept", "*/*")
                    .get(urlString);

            if (response.getStatusCode() != 200) {
                LogCapture.info("Something Went Wrong While Fetching Email Error in makeApiRequest 001 : " + response.getBody().asString());
            }
            responseBody = response.getBody().asString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new JsonPath(responseBody);
    }

    private static void downloadAttachment(String urlString, String attachmentName) throws IOException, InterruptedException {
        Path emailDownloadDirectoryPath = Paths.get(EMAIL_DOWNLOAD_DIRECTORY);

        if (!Files.exists(emailDownloadDirectoryPath)) {
            Files.createDirectories(emailDownloadDirectoryPath);
        } else {
            FileUtils.cleanDirectory(emailDownloadDirectoryPath.toFile());
        }

        String saveFilePath = EMAIL_DOWNLOAD_DIRECTORY + File.separator + attachmentName;

        Response response = RestAssured.given().relaxedHTTPSValidation()
                .urlEncodingEnabled(false)
                .header("Authorization", MAILINATOR_API_TOKEN)
                .header("Content-Type", "application/octet-stream")
                .get(urlString);

        if (response.getStatusCode() != 200) {
            LogCapture.info("Something Went Wrong While Fetching Email Error in makeApiRequest 001 : " + response.getBody().asString());
        }

        try (InputStream inputStream = response.getBody().asInputStream();
             FileOutputStream outputStream = new FileOutputStream(saveFilePath)) {

            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }

        try {
            File[] listOfFiles = emailDownloadDirectoryPath.toFile().listFiles();
            if (Objects.nonNull(listOfFiles) && listOfFiles.length > 0) {
                String downloadedFileName = listOfFiles[0].getName();
                LogCapture.info(downloadedFileName + " File Downloaded Successfully in directory " + EMAIL_DOWNLOAD_DIRECTORY);
            } else {
                LogCapture.info("No File Detected in Email");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isElementPresent(String data) {
        try {
            Constants.driver.findElement(By.xpath(data));
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public static String updateDateToPreviousDay(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(dateString);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, -1); // Subtract 1 day
            return sdf.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

}

