package com.selenium.utillity;

import com.selenium.utillity.drivers.ChromeDriverManager;
import com.selenium.utillity.drivers.EdgeDriverManager;
import com.selenium.utillity.drivers.SafariDriverManager;
import org.openqa.selenium.WebDriver;

public class DriverFactory {
    private static WebDriver driver;
    public static WebDriverManagerCustom getManager(DriverType type, OSType os) {
        WebDriverManagerCustom driverManager;

        switch (type) {
            case CHROME:
                driverManager = new ChromeDriverManager(os);
                break;
                case EDGE:
                driverManager = new EdgeDriverManager(os);
                break;
            case SAFARI:
                driverManager = new SafariDriverManager(os);
                break;
            default:
                throw new IllegalArgumentException("Invalid browser type: " + type);
        }

        return driverManager;
    }
}
