package com.selenium.utillity;

import com.utility.LogCapture;
import org.apache.commons.lang.RandomStringUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import static com.selenium.utillity.Constants.NewFileName;

public class FileRename {
//
//    public static void main(String[] args) {
//        File NewFilename = renameFileInFolder();
//        System.out.println(NewFilename);
//
//        File originalName = renameToOriginal(NewFilename);
//        System.out.println(originalName);
//
//    }


    public static File renameFileInFolder() {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String dateString = format.format(new Date());

        File oldName = new File(System.getProperty("user.dir") + "/Files/ManualEnteriesUpload.xlsx");
        File Newname = new File(System.getProperty("user.dir") + "/Files/ManualEnteriesUpload_" + dateString + ".xlsx");
        Constants.latestFile = Newname;
        if (oldName.renameTo(Newname)) {
            System.out.println("File renamed successfully");
        } else {
            System.out.println("Operation failed");
        }
        return Newname;
    }

    public static File renameToOriginal(File latestname) {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String dateString = format.format(new Date());

        File originalName = new File(System.getProperty("user.dir") + "/Files/ManualEnteriesUpload.xlsx");
        if (latestname.renameTo(originalName)) {
            System.out.println("File renamed successfully");
        } else {
            System.out.println("Operation failed");
        }
        return originalName;
    }




}