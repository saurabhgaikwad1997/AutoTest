import com.cucumber.listener.Reporter;
import com.restAssured.utillity.TestNGCucumberExecutable;
import cucumber.api.CucumberOptions;
import org.junit.internal.AssumptionViolatedException;
import org.junit.internal.runners.model.EachTestNotifier;
import org.junit.runner.notification.RunNotifier;
import org.junit.runner.notification.StoppedByUserException;
import org.junit.runners.model.Statement;

@CucumberOptions(features = {"src/Feature"},
        glue = {"com.cucumber.stepdefinition"}
        /*      format = {"pretty",
                      "html:target/site/cucumber-pretty","json:target/cucumber-reports/cucumber.json"*/
        ,

        tags = {"@GateWay_Access_UAT"},

        plugin = {"pretty", "html:target/site/cucumber-pretty", "json:target/cucumber-reports/cucumber.json", "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/ExtentReport.html"},
        //plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/Extentreport.html", "json:target/cucumber-reports/cucumber.json"},
        monochrome = true)
//AbstractTestNGCucumberTests
public class TestNGRunnerCL extends TestNGCucumberExecutable {

}