package com.service.utillity;

import com.restAssured.utillity.Constants;
import com.utility.LogCapture;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Pattern;

import static io.restassured.RestAssured.given;

public class ReusableMethod {

    static String fileName = Constants.CONFIG.getProperty("excelName");

    public static Map<String, String> getStringStringMap(String parameter) {
        Map<String, String> headerMap = null;
        try {
            headerMap = new HashMap<String, String>();
            String[] array = parameter.split("\\|");
            System.out.println(array.length);

            if (!parameter.equalsIgnoreCase("") && !parameter.equalsIgnoreCase("NA")) {
                for (int i = 0; i < array.length; i++) {
                    String[] headersList = array[i].split("\",\"");
                    String key = headersList[0].replaceAll("\"", "").trim();
                    String value = headersList[1].replaceAll("\"", "").trim();
                    if (key.equalsIgnoreCase("Authorization")) {
                        headerMap.put(key, value + " " + Constants.ACCESS_TOKEN);
                    } else {
                        headerMap.put(key, value);
                    }
                }
            } else {
                LogCapture.info("----------Parameter is empty for getStringStringMap method---------------");
            }
            return headerMap;
        } catch (Exception e) {
            LogCapture.info("Error occurred in getStringStringMap method. The error is: " + e);
            e.printStackTrace();
        }
        return headerMap;
    }


    public static JsonPath rawToJason(String response) {
        JsonPath js1 = null;
        try {
            LogCapture.info("-------------Converting to JSON, response => " + response + "--------");
            js1 = new JsonPath(response);
            return (js1);
        } catch (Exception e) {
            LogCapture.info("Error occurred in rawToJason method. The error is: " + e);
            e.printStackTrace();
        }
        return js1;
    }

    public static String readExcel(String testCaseID, String parameterName) throws IOException {
        try {
            LogCapture.info("--------------Started to Fetch value for testCase ID " + testCaseID + " for parameter " + parameterName + " from excel-----------------");
            //Create an object of File class to open xlsx file
            File file = new File(System.getProperty("user.dir") + "/src/main/resources/" + fileName);
            //File file = new File(filePath + "\\" + fileName);
            //Create an object of FileInputStream class to read excel file
            FileInputStream inputStream = new FileInputStream(file);
            Workbook APIWorkbook = null;
            //Find the file extension by splitting file name in substring  and getting only extension name
            String fileExtensionName = fileName.substring(fileName.indexOf("."));
            //Check condition if the file is xlsx file
            if (fileExtensionName.equals(".xlsx")) {
                //If it is xlsx file then create object of XSSFWorkbook class
                APIWorkbook = new XSSFWorkbook(inputStream);
            }
            //Check condition if the file is xls file
            else if (fileExtensionName.equals(".xls")) {
                //If it is xls file then create object of HSSFWorkbook class
                APIWorkbook = new HSSFWorkbook(inputStream);

            }
            //Read sheet inside the workbook by its name

            Sheet excelSheet = APIWorkbook.getSheet(Constants.SHEET_NAME);

            //Find number of rows in excel file
            int rowCount = excelSheet.getLastRowNum() - excelSheet.getFirstRowNum();
            //Create a loop over all the rows of excel file to read it
            Row rw = excelSheet.getRow(0);
            int cellNum = rw.getPhysicalNumberOfCells();
            Iterator<Cell> c = rw.cellIterator();

            int inc = -1;
            while (c.hasNext()) {
                Cell cl = c.next();
                String cellHeaderName = "";
                inc++;
                int rowSize = rw.getPhysicalNumberOfCells() - 1;
                String cellType = cl.getCellType().toString();
                if (cellType.equalsIgnoreCase("NUMERIC")) {
                    cellHeaderName = Double.toString(cl.getNumericCellValue()).trim();
                } else if (cellType.equalsIgnoreCase("STRING")) {
                    cellHeaderName = cl.getStringCellValue().trim();
                }
                if (cellHeaderName.equalsIgnoreCase(parameterName.trim())) {
                    break;
                }
                if (rowSize == inc) {
                    inc = -1;
                }
            }
            if (inc != -1) {
                for (int i = 1; i < rowCount + 1; i++) {
                    //Create a loop to print cell values in a row
                    Row row = excelSheet.getRow(i);
                    if (row != null) {
                        if (row.getCell(2).getStringCellValue().equalsIgnoreCase(testCaseID)) {
                            String cllTyp = "";
                            if (row.getCell(inc).equals(null) || row.getCell(inc).getCellType() == CellType.BLANK) {
                                cllTyp = "STRING";
                            } else {
                                cllTyp = row.getCell(inc).getCellType().toString();
                            }
                            String cellDate = "";
                            if (cllTyp.equalsIgnoreCase("NUMERIC")) {
                                cellDate = Double.toString(row.getCell(inc).getNumericCellValue());
                            } else if (cllTyp.equalsIgnoreCase("STRING")) {
                                cellDate = row.getCell(inc).getStringCellValue();
                            }
                            LogCapture.info("--------------Value fetched from excel for: " + parameterName + " => " + cellDate + "-----------------");
                            return cellDate;
                        }
                    }
                }
            }

            return null;
        } catch (Exception e) {
            LogCapture.info("Error occurred in readExcel method for testcaseID = " + testCaseID + " while fetching parameter = " + parameterName + ", while reading excel. The error is: " + e);
            LogCapture.info("The Sheet name is not present in the excel");
            e.printStackTrace();
        }
        return null;
    }

    public static String getDynamic(String testCaseID, String statusCode, HashMap<String, String> ParamBody) throws IOException {
        try {
            try {
                String response = "";
                String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
                if (Execution.equalsIgnoreCase("Y")) {
                    String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                    String url = Constants.APIkey.readExcel(testCaseID, "URL");
                    String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                    if (queryParams != null) {
                        for (int i = 0; i < ParamBody.size(); i++) {
                            for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                                if (queryParams.contains(entry.getKey())) {
                                    queryParams = queryParams.replace(entry.getKey(), entry.getValue());
                                }
                            }
                        }
                    }
                    Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                    RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                    if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                        response = given().relaxedHTTPSValidation().log().all()
                                .when().get(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                    } else if (!queryParams.equalsIgnoreCase("")) {
                        response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap)
                                .when().get(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                    }
                } else if (Execution.equalsIgnoreCase("N")) {
                    response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                    LogCapture.info(response);
                }
                return response;
            } catch (IOException e) {
                LogCapture.info("Error occurred during a GET call. The error is: " + e);
                e.printStackTrace();
            }
            return "Error occurred during a GET call";
        } catch (Exception e) {
            LogCapture.info("Error occurred during a GET call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a GET call";
    }


    /*public static void ReplaceDynamicInExcel(String key, String value){
        Constants.parambody = new HashMap<>();
        Constants.parambody.put(key,value);
    }*/


    public static String readFullExcel(String excelName) throws IOException {
        try {

            File file = new File(System.getProperty("user.dir") + "/src/main/resources/" + Constants.CONFIG.getProperty("excelName"));
            FileInputStream inputStream = new FileInputStream(file);
            Workbook APIWorkbook = null;
            String fileExtensionName = fileName.substring(fileName.indexOf("."));
            if (fileExtensionName.equals(".xlsx")) {
                //If it is xlsx file then create object of XSSFWorkbook class
                APIWorkbook = new XSSFWorkbook(inputStream);
            }
            //Check condition if the file is xls file
            else if (fileExtensionName.equals(".xls")) {
                //If it is xls file then create object of HSSFWorkbook class
                APIWorkbook = new HSSFWorkbook(inputStream);

            }

            int sheetNumber = APIWorkbook.getNumberOfSheets();
            //Iterating through the sheet
            for (int i = 0; i < sheetNumber; i++) {
                Sheet excelSheet = APIWorkbook.getSheetAt(i);
                Constants.SHEET_NAME = excelSheet.getSheetName();
                LogCapture.info("===================================Running Sheet => " + Constants.SHEET_NAME + "============================================================================================");
                int rowCount = excelSheet.getLastRowNum() - excelSheet.getFirstRowNum();
                //Iterating through the rows
                for (int j = 1; j < rowCount + 1; j++) {
                    Row row = excelSheet.getRow(j);
                    if (row.getPhysicalNumberOfCells() != 0) {
                        String testCaseName = row.getCell(2).getStringCellValue();
                        if (testCaseName.equalsIgnoreCase("")) {
                            String d = "";
                        }
                        String statusCode = row.getCell(11).getStringCellValue();//200 , 201
                        String Execution = row.getCell(1).getStringCellValue();//Y or N
                        String httpMethod = row.getCell(7).getStringCellValue();//POST or GET
                        if (Execution.equalsIgnoreCase("Y")) {
                            LogCapture.info("--------------------------------------Test case number: " + testCaseName + "--------------------------------------------------------------------------------------------------------");
                            if (httpMethod.equalsIgnoreCase("Post")) {
                                Constants.RESPONSE = ServiceMethod.postAdvance(testCaseName, statusCode, Constants.ParamBody);
                                LogCapture.info("==============================================================================================================");
                                LogCapture.info("Response captured from POST---> " + Constants.RESPONSE);
                                LogCapture.info("==============================================================================================================");
                                if (Constants.RESPONSE.contains("access_token")) {
                                    JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
                                    Constants.ACCESS_TOKEN = jp.get("access_token");
                                }
                                if (Constants.RESPONSE.contains("reference_code")) {
                                    JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
                                    Constants.REFERENCE_CODE = jp.get("reference_code");
                                    if (Constants.REFERENCE_CODE != null) {
                                        ReusableMethod.PutInHashMap("<Dyanamic_refCode>", Constants.REFERENCE_CODE);
                                    }

                                }
                                if (Constants.RESPONSE.contains("place_id")) {
                                    JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
                                    Constants.RESPONSE_PLACEID = jp.get("place_id");
                                }
                            } else if (httpMethod.equalsIgnoreCase("Get")) {
                                Constants.RESPONSE = ServiceMethod.get(testCaseName, statusCode);
                                LogCapture.info("==============================================================================================================");
                                LogCapture.info("Response captured from GET---> " + Constants.RESPONSE);
                                LogCapture.info("==============================================================================================================");
                            } else if (httpMethod.equalsIgnoreCase("Delete")) {

                            } else if (httpMethod.equalsIgnoreCase("Put")) {

                            }
                            LogCapture.info("************************************************Response Verification***********************************************************");
                            verifyResponse(testCaseName);
                            LogCapture.info("********************************************************************************************************************************");
                        } else {
                            LogCapture.info("---This testcase " + testCaseName + " has been skipped---");
                        }
                    }
                }
            }
        } catch (Exception e) {
            LogCapture.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
            LogCapture.info("---The Sheet is not on a valid format---");
            e.printStackTrace();
        }
        return null;
    }

    public static void verifyResponse(String testCaseName) {
        try {
            Map<String, String> hm = new HashMap<>();
            String rawVerifyContent = readExcel(testCaseName, "ContentToVerify");
            hm = getStringStringMap(rawVerifyContent);//Verify tags
            JsonPath jp = rawToJason(Constants.RESPONSE);//Response API
            for (Map.Entry<String, String> e : hm.entrySet()) {
                //Check for the key present in response
                try {
                    String toVerifyResponseValue = jp.get(e.getKey()).toString();
                    if (toVerifyResponseValue == null) {
                        LogCapture.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                        throw new RuntimeException("---The tag '" + e.getKey() + "' is not present in the response for test case " + testCaseName + "---");
                    } else {
                        if (!toVerifyResponseValue.equals(e.getValue())) {
                            if (e.getValue().contains("<dynamic>")) {
                                LogCapture.info("---The value for '" + e.getKey() + "' changes dynamically with each request and cannot be verified. Value is :" + e.getValue() + "---");
                            } else {
                                LogCapture.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                                LogCapture.info("---Value for '" + e.getKey() + "' is present WRONGLY as mentioned in excel---");
                                LogCapture.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                            }
                        } else if (e.getValue().equals(toVerifyResponseValue)) {
                            LogCapture.info("---Value for '" + e.getKey() + "' is present CORRECTLY as mentioned in excel---");
                        } else {
                            LogCapture.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                            LogCapture.info("---Some error occurred while validating the response---");
                            Assert.assertEquals(e.getValue(), toVerifyResponseValue);
                        }
                    }
                } catch (RuntimeException runtimeException) {
                    runtimeException.printStackTrace();
                }
            }
        } catch (IOException e) {
            LogCapture.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
            LogCapture.info("---Some error occurred in verifyResponse method---");
            e.printStackTrace();
        }
    }

    public static void PutInHashMap(String key, String Value) {
        {
            Constants.ParamBody.put(key, Value);
        }
    }
}
