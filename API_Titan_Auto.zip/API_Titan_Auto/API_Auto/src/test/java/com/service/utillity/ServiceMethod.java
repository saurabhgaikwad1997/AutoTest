package com.service.utillity;

import com.restAssured.utillity.Constants;
import com.utility.LogCapture;
import io.restassured.RestAssured;
//import jdk.nashorn.internal.runtime.Context;
import net.bytebuddy.implementation.bytecode.Throw;
import org.apache.groovy.json.internal.Exceptions;
import org.apache.http.ExceptionLogger;
import org.codehaus.groovy.control.messages.ExceptionMessage;
import org.junit.Assume;
import org.testng.Assert;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ServiceMethod {

    public static String post(String testCaseID, String statusCode) {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (Exception e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a POST call";
    }

    public static String postAdvance(String testCaseID, String statusCode, HashMap<String, String> ParamBody) {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                if (body != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (body.contains(entry.getKey())) {
                                body = body.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                if (queryParams != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryParams.contains(entry.getKey())) {
                                queryParams = queryParams.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");

                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (Exception e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a POST call";
    }


    public static String get(String testCaseID, String statusCode) {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            if (Execution.equalsIgnoreCase("Y")) {
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String url = Constants.APIkey.readExcel(testCaseID, "URL");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().headers(headerMap)
                            .when().get(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().headers(headerMap).queryParams(queryParameterMap)
                            .when().get(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;
        } catch (Exception e) {
            LogCapture.info("Error occurred during a GET call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a GET call";
    }

    public static String put(String testCaseID, String statusCode) throws IOException {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().put(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().put(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (IOException e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a POST call";
    }


    public static String deleteAdvance(String testCaseID, String statusCode, HashMap<String, String> ParamBody) throws IOException {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                if (body != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (body.contains(entry.getKey())) {
                                body = body.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                if (queryParams != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryParams.contains(entry.getKey())) {
                                queryParams = queryParams.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().delete(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().delete(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (IOException e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a POST call";
    }

    public static String putAdvance(String testCaseID, String statusCode, HashMap<String, String> ParamBody) throws IOException {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                if (body != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (body.contains(entry.getKey())) {
                                body = body.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                if (queryParams != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryParams.contains(entry.getKey())) {
                                queryParams = queryParams.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().put(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().put(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (IOException e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a POST call";
    }


}
