package com.cucumber.stepdefinition;

import com.google.gson.Gson;
import com.restAssured.utillity.Constants;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;
import com.utility.LogCapture;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.hu.Ha;
import io.restassured.path.json.JsonPath;
import org.junit.Assume;
import org.junit.runner.Result;
import org.testng.Assert;

import javax.swing.*;
import java.util.HashMap;

public class CommHubAPIValidations {

    //public HashMap<String, String> ParamBody = new HashMap<>();

    @Given("^User Generate Token for API Validation from \"([^\"]*)\" for (CD-PFX|CD-CFX) Application$")
    public void userGenerateAPITokenForAPIValidationFromTestId(String tcID, String app) throws Throwable {
            LogCapture.info("--------------Token Generation started for testcase ID " + tcID + "---------------");
            Constants.RESPONSE = ServiceMethod.post(tcID, "200");
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            Constants.ACCESS_TOKEN = jp.get("access_token");
            LogCapture.info("--------------Token Generation ended--------------");
            LogCapture.info("--------------Token Generation ended for testcase ID " + tcID + "--------------");
    }

    @Then("^User Validate Response Code \"([^\"]*)\" and Response Description as \"([^\"]*)\"$")
    public void userValidateResponseCodeAndResponseDescriptionAs(String responseCode, String responsedesc) throws Throwable {
        //Constants.APIkey.checkNotEnabled(Constants.TCCaseID);
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        org.junit.Assert.assertEquals(responseCode,jp.get("response_code"));
        if(!responsedesc.equalsIgnoreCase("<bypass validation>")) {
            org.junit.Assert.assertEquals(responsedesc, jp.get("response_description"));
        }
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for (CD-PFX Application|CD-CFX Application|API Gateway Check)$")
    public void forACallUserCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String enviroment, String App) throws Throwable {
        //Constants.APIkey.checkNotEnabled(testCaseID);
            Constants.TCCaseID = testCaseID;
            LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
            if (methodType.equalsIgnoreCase("Post")) {
                LogCapture.info("---------------POST call started----------------");
                Constants.RESPONSE = ServiceMethod.post(testCaseID, statCode);
                JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
                Constants.RESPONSE_CODE = jp.get("response_code");
                Constants.REFERENCE_CODE = jp.get("reference_code");
                Constants.RESPONSE_DESCRIPTION = jp.get("response_description");
                LogCapture.info("---------------POST call ended----------------");

            } else if (methodType.equalsIgnoreCase("Get")) {
                LogCapture.info("---------------GET call started----------------");
                Constants.RESPONSE = ServiceMethod.get(testCaseID, statCode);
                JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
                Constants.RESPONSE_CODE = jp.get("code");
                Constants.RESPONSE_DESCRIPTION = jp.get("description");
                LogCapture.info("---------------GET call started----------------");
            }
            LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @When("^User gets the added place id sending \"([^\"]*)\" call present at \"([^\"]*)\"$")
    public void userGetsTheAddedPlaceIdSendingCallPresentAt(String arg0, String tcid) throws Throwable {
        LogCapture.info("---------------GET call started----------------");

        //ParamBody.put("<Dynamic_placeid>",Constants.RESPONSE_PLACEID);
        ReusableMethod.PutInHashMap("<Dynamic_PlaceID>", Constants.RESPONSE_PLACEID);
        Constants.RESPONSE = Constants.APIkey.getDynamic(tcid, "200",Constants.ParamBody);
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        LogCapture.info("---------------GET call started----------------");
    }

    @Then("^User tries to \"([^\"]*)\" the added place using api present at \"([^\"]*)\"$")
    public void userTriesToTheAddedPlaceUsingApiPresentAt(String arg0, String TCid) throws Throwable {
        LogCapture.info("---------------DELETE call started----------------");
        //Constants.APIkey.ReplaceDynamicInExcel("<Dynamic_placeid>",Constants.RESPONSE_PLACEID);
        Constants.RESPONSE = ServiceMethod.deleteAdvance(TCid, "200", Constants.ParamBody);
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        org.junit.Assert.assertEquals(jp.get("status"), "OK");
        LogCapture.info("---------------DELETE call ended----------------");

    }

    @And("^User gets the added place id sending \"([^\"]*)\" call present at \"([^\"]*)\" and get error \"([^\"]*)\"$")
    public void userGetsTheAddedPlaceIdSendingCallPresentAtAndGetError(String arg0, String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Given("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" and capture the place id$")
    public void forACallUserCheckStatusCodeAsForOnAndCaptureThePlaceId(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Constants.TCCaseID = testCaseID;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.post(testCaseID, statCode);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            Constants.RESPONSE_PLACEID = jp.get("place_id");
            //JOptionPane.showMessageDialog(null,Constants.RESPONSE_PLACEID);
            LogCapture.info("---------------POST call ended----------------");

        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.get(testCaseID, statCode);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @And("^User gets the added place id sending \"([^\"]*)\" call present at \"([^\"]*)\" and should get \"([^\"]*)\" error$")
    public void userGetsTheAddedPlaceIdSendingCallPresentAtAndShouldGetError(String arg0, String tcid, String statcode) throws Throwable {
        LogCapture.info("---------------GET call started----------------");
        Constants.RESPONSE = Constants.APIkey.getDynamic(tcid, statcode,Constants.ParamBody);
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        Assert.assertEquals("Get operation failed, looks like place_id  doesn't exists",jp.get("msg"));
        LogCapture.info("---------------GET call started----------------");
    }

    @And("^User tries modifying the address to \"([^\"]*)\" using the place id, making a \"([^\"]*)\" call present at \"([^\"]*)\"$")
    public void userTriesModifyingTheUsingThePlaceIdMakingACallPresentAt(String address, String arg1, String TCid) throws Throwable {

        ReusableMethod.PutInHashMap("<Dynamic_address>", address);
        Constants.RESPONSE = ServiceMethod.putAdvance(TCid, "200",Constants.ParamBody);
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        org.junit.Assert.assertEquals(jp.get("msg"), "Address successfully updated");
    }

    @Given("^User runs entire excel named \"([^\"]*)\" sheet for regression$")
    public void userRunsEntireExcelNamedSheetForRegression(String excelName) throws Throwable {

        Constants.APIkey.readFullExcel(excelName);

    }

    @When("^For a advance \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for CD-PFX Application$")
    public void forAAdvanceCallUserCheckStatusCodeAsForOnEnvironmentForCDPFXApplication(String method, String statcode, String tcid, String env) throws Throwable {
        ReusableMethod.PutInHashMap("<Dyanamic_refCode>", Constants.REFERENCE_CODE);
        Constants.RESPONSE = ServiceMethod.postAdvance(tcid,statcode,Constants.ParamBody);
    }

    @Then("^User Validate Response Code \"([^\"]*)\" and Response Description as \"([^\"]*)\" for gateway$")
    public void userValidateResponseCodeAndResponseDescriptionAsForGateway(String Code, String Description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        org.junit.Assert.assertEquals(Code,jp.get("code"));
        if(!Description.equalsIgnoreCase("<bypass validation>")) {
            org.junit.Assert.assertEquals(Description, jp.get("description"));
        }
        LogCapture.info("----------------Response Validations Ended-------------------");
    }
}
