package com.cucumber.stepdefinition;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.cucumber.listener.Reporter;
import com.restAssured.utillity.Constants;
import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.junit.Assume;
import org.junit.BeforeClass;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.ITestResult;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.xml.XmlSuite;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
//import static com.selenium.utillity.Reusables.takeSnapShot;
//import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
//import com.utilities.Log;
/*import io.cucumber.java.After;
import io.cucumber.java.Before;*/


public class BaseStep{
    static ExtentTest logger;
    static ExtentReports extent;

    public static String scenarioName;
    //@BeforeClass


    @Before
    public void intialization(Scenario scenario) throws IOException {

        FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//config.properties");
        Constants.CONFIG = new Properties();
        Constants.CONFIG.load(fs);

        Reporter.loadXMLConfig(new File(System.getProperty("user.dir")+"/extent-config.xml"));
        String testCaseID = scenario.getName().split("-")[0].trim();
        Constants.SHEET_NAME = scenario.getName().split("-")[1].trim();
        LogCapture.info("==========================API Validation Started for testcase "+testCaseID+"======================");
        if (!testCaseID.equalsIgnoreCase("Regression All")) {
            String isEnabled = Constants.APIkey.readExcel(testCaseID, "Execution");
            if (isEnabled.equalsIgnoreCase("N") || isEnabled.equalsIgnoreCase("")) {
                LogCapture.info("--------------------------------Test Case "+testCaseID+" is disabled in datasheet------------------");
                Reporter.addScenarioLog("<b style=\"color:Red;\">*THIS TEST CASE HAS BEEN MARKED AS 'N' in APIData.xls present at "+System.getProperty("user.dir")+"\\src\\main\\resources</b>");
                Assume.assumeTrue(testCaseID + " is skipped", false);
            }
        }
    }



    @After
    public void finish(Scenario scenario) throws Exception {

        LogCapture.info("============================API Validation Ended====================================");
    }

    public static void writeExtentReport() throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();


    }
}