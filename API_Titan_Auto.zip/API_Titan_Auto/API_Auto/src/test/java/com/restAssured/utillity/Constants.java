package com.restAssured.utillity;

import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import io.restassured.response.Response;
import org.openqa.selenium.WebDriver;

import java.util.HashMap;
import java.util.Properties;

public class Constants {
    public static HashMap<String, String> ParamBody = new HashMap<>();
    public static ReusableMethod APIkey;
    public static Properties CONFIG;
    public static String TCCaseID = "";
    public static String RESPONSE_PLACEID = "";
    public static String APP_NAME = "";
    public static String SHEET_NAME = "";
    public static String isEnabled = "";
    public static String RESPONSE = "";
    public static String ACCESS_TOKEN = "";
    public static String RESPONSE_CODE = "";
    public static String RESPONSE_DESCRIPTION = "";
    public static String REFERENCE_CODE = "";
}