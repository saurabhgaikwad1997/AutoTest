package com.cucumber.stepdefinition;

import com.cucumber.listener.Reporter;
import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.utility.LogCapture;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.apache.commons.io.FileUtils;
import org.junit.Assume;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
//import static com.selenium.utillity.Reusables.takeSnapShot;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
//import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
//import com.utilities.Log;
/*import io.cucumber.java.After;
import io.cucumber.java.Before;*/


public class BaseStep {

    public static String scenarioName;
    //@BeforeClass


    @Before
    public void intialization(Scenario scenario) throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();
        scenarioName = scenario.getName();
        Constants.key = new Reusables();
        FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//config.properties");
        Constants.CONFIG = new Properties();
        Constants.CONFIG.load(fs);
        //Atlas Login OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Atlas//AtlasloginOR.properties");
        Constants.AtlasloginOR = new Properties();
        Constants.AtlasloginOR.load(fs);
        //Atlas dashboard OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Atlas//AtlasDashboardOR.properties");
        Constants.AtlasDashboardOR = new Properties();
        Constants.AtlasDashboardOR.load(fs);
        //Atlas AtlasPaymentInQueueOR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Atlas//AtlasPaymentInOR.properties");
        Constants.AtlasPaymentInOR = new Properties();
        Constants.AtlasPaymentInOR.load(fs);
        //Atlas_AtlasPaymentOutQueueOR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Atlas//AtlasPaymentOutOR.properties");
        Constants.AtlasPaymentOutOR = new Properties();
        Constants.AtlasPaymentOutOR.load(fs);
        //RegistrationOR.properties
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Atlas//AtlasRegistrationOR.properties");
        Constants.AtlasRegistrationOR = new Properties();
        Constants.AtlasRegistrationOR.load(fs);

        //dbconfig.properties
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//dbconfig.properties");
        Constants.DBCONFIG = new Properties();
        Constants.DBCONFIG.load(fs);

        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");

    }

    @After
    //@AfterClass
    public void finish(Scenario scenario) throws Exception {
        if (Constants.CONFIG.getProperty("ScreenshotCaptureOnFailure").equalsIgnoreCase("True")) {
            if (scenario.isFailed()) {
                takeSnapShotOnFailure();
            }
        }
        Constants.driver.quit();
        LogCapture.endLog("-------------------------Test Case Validation Ended--------------------");
    }

    public static void writeExtentReport() throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();
        Reporter.loadXMLConfig(new File(Constants.key.getReportConfigPath()));

    }


}
