package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
//import com.utilities.Log;
import com.utility.LogCapture;
//import com.utilities.Log;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.selenium.utillity.Constants.*;
import static io.restassured.RestAssured.given;
import static org.apache.commons.lang3.StringUtils.split;

/*import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.testng.Assert;*/

public class AltasStepDefination {
    public static String ClientNumber;
    public static String ReportName;
    public static String Comments;

    public static String CopiedTAN;

    @And("^User navigate to (Atlas|Saleforce) Application \"([^\"]*)\"$")
    public void userNavigateToAtlasApplication(String page, String vUrl) throws Exception {
        if (page.equals("Atlas")) {
            LogCapture.info("Atlas Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (page.equals("Salesforce")) {
            //Line of code
        }
    }

        /*else if(page.equals("Titan")){
            LogCapture.info("Titan Applicatiion is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));

        }*/


    @When("^User enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click log In button on Altas Application$")
    public void userEnterUserNamePasswordAndClickLogInButtonOnAltasApplication(String userName, String password) throws Exception {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.AtlasloginOR.getProperty("Atlas_Username");
        String vObjPass = Constants.AtlasloginOR.getProperty("Atlas_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, vPassword));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.AtlasloginOR.getProperty("Atlas_LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));

    }

    @Then("^User successfully landed on Atlas Dashboard page$")
    public void userSuccessfullyLandedOnAtlasDashboardPage() throws Exception {
        LogCapture.info("Dashboard loading ......");
        Constants.key.pause("5", "");
        String vobjectDashboard = Constants.AtlasDashboardOR.getProperty("Atlas_Dashboard");
        String vobjectPFXBox = Constants.AtlasDashboardOR.getProperty("AtlasPFXBox");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectPFXBox, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "ATLAS"));

    }

    @Given("^User launched application through \"([^\"]*)\" browser$")
    public void userLaunchedApplicationThrough(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        String vBrowserName = Constants.CONFIG.getProperty("browser");
        try {
            if (Objects.equals(Constants.JenkinsBrowser, null)) {
                Constants.JenkinsBrowser = "";
            } else if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                vBrowserName = Constants.JenkinsBrowser;
                LogCapture.info("Browser is :" + Constants.JenkinsBrowser);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));
    }


    @And("^User navigates to (Payment In Report|Registration Queue|Registration Report|Payment In Queue|Payment Out Queue|Payment Out Report) from Dashboard$")
    public void userNavigatesToRespectivePageFromDashboard(String Menu) throws Exception {
        if (Menu.equalsIgnoreCase("Payment In Report")) {
            LogCapture.info("User is selecting Payment In hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("Atlas_PaymentInReportTab");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
        } else if (Menu.equalsIgnoreCase("Registration Queue")) {
            LogCapture.info("User is selecting Registration Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasRegistrationQueue = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationQueue");
            String vObjAtlasRegistrationQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasRegistrationQueue, ""));
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAtlasRegistrationQueueText, ""));
            if (Constants.driver.findElement(By.xpath(vObjAtlasRegistrationQueueText)).getText().contains("Registration queue")) {
                LogCapture.info("User Successfully redirecting to Registration Queue ");
            } else {
                LogCapture.info("User is not Successfully redirecting to Registration Queue ");
                Assert.fail();
            }

        } else if (Menu.equalsIgnoreCase("Registration Report")) {
            LogCapture.info("User is selecting Registration Report hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasRegistrationReport = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReport");
            String vObjAtlasRegistrationReportText = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReportText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasRegistrationReport, ""));
            if (Constants.driver.findElement(By.xpath(vObjAtlasRegistrationReportText)).getText().contains("Registration report")) {
                LogCapture.info("User Successfully redirecting to Registration Report ");
            } else {
                LogCapture.info("User is not Successfully redirecting to Registration Report ");
                Assert.fail();
            }

        } else if (Menu.equalsIgnoreCase("Payment In Queue")) {
            LogCapture.info("User is selecting Payment In Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("AtlasPaymentInTabQueue");
            String vObjAtlasPaymentInQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasPaymentInQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAtlasPaymentInQueueText, ""));
//            if (Constants.driver.findElement(By.xpath(vObjAtlasPaymentInQueueText)).getText().contains("Payment In queue")) {
//                LogCapture.info("User Successfully redirecting to Payment In Queue ");
//            } else {
//                LogCapture.info("User is not Successfully redirecting to Payment In Queue ");
//                Assert.fail();
//            }
        } else if (Menu.equalsIgnoreCase("Payment Out Queue")) {
            LogCapture.info("User is selecting Payment Out Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasPaymentOutTabQueue = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutTabQueue");
            String vObjAtlasPaymentOutQueueText = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAtlasPaymentOutTabQueue, ""));

        } else if (Menu.equalsIgnoreCase("Payment Out Report")) {
            LogCapture.info("User is selecting Payment Out Report hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vPaymentOutTab = Constants.AtlasDashboardOR.getProperty("Atlas_PaymentOutReportTab");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vPaymentOutTab, ""));

        }
    }

    @When("^User click on filter criteria$")
    public void userClickOnFilterCriteria() throws Exception {
        String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
    }

    @And("^User enters valid (Customer Number|Email Address|Customer ID|Client Id) \"([^\"]*)\" in keyword section$")
    public void userEntersValidCustomerNumberInKeywordSection(String Value, String InputValue) throws Throwable {
        if (Value.equalsIgnoreCase("Customer Number") || Value.equalsIgnoreCase("Email Address") || Value.equalsIgnoreCase("Client Id")) {
            String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, InputValue));

        } else if (Value.equalsIgnoreCase("Customer ID")) {
            String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, AltasStepDefination.ClientNumber));

        }
    }

    @And("^User Click on  a record for which Payment  is in HOLD status to navigate to details page$")
    public void userClickOnARecordForWhichPaymentIsInHOLDStatusToNavigateToDetailsPage() throws Exception {
        String vclickFirst = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecord");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vclickFirst, ""));
    }

    @Then("^User (Lock|UnLock) the Record$")
    public void userLockTheRecord(String Lock) throws Exception {
        if (Lock.equalsIgnoreCase("Lock")) {
            String vLockObj = Constants.AtlasPaymentInOR.getProperty("Atlas_LockToggle");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vLockObj, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vLockObj, ""));
        }
        if (Lock.equalsIgnoreCase("UnLock")) {
            String vLockObj = Constants.AtlasPaymentInOR.getProperty("Atlas_UnLockToggle");
            Assert.assertEquals("PASS", Constants.key.click(vLockObj, ""));
        }
    }

    @And("^Mark the (Registration|Payment In CFX|Payment Out CFX|Payment In PFX|Payment Out PFX|Payment Out CFX-Etailer|Payment In CFX-Etailer|) Status as (CLEAR|ACTIVE|INACTIVE|REJECT|SEIZE|HOLD) with comments$")
    public void markThePaymentInStatusAsCLEARWithComments(String Value, String Action) throws Exception {
        Comments = RandomStringUtils.randomAlphabetic(10);
        System.out.println(Comments);
        if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("ACTIVE")) {
            String vObjActive = Constants.AtlasRegistrationOR.getProperty("Active");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjActive, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("INACTIVE")) {
            String vObjActive = Constants.AtlasRegistrationOR.getProperty("InActive");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjActive, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("REJECT")) {
            String vObjReject = Constants.AtlasRegistrationOR.getProperty("Reject");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjReject, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vClearButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButton = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButton, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out CFX-Etailer") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButton = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButton, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButtonpfx = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButtonpfx, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButtonCfx = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButtonCfx, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeiz");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButtonCfxE = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButtonCfxE, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        }
    }

    @When("^User Click on (Apply|Apply&Unlock) button on (Registration Queue|Payment In Queue|Payment In Report|Registration Queues|Payment Out Queue|Registration Queue CFX|Payment In Queue CFX|Payment Out Queue CFX|Payment Out Queue PFX|Registration Queue PFX|Payment Out CFX-Etailer|Payment In CFX-Etailer|)$")
    public void userClickOnApplyApplyUnlock(String Lock, String Queue) throws Exception {
        if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue")) {
            String vApplyButton = Constants.AtlasRegistrationOR.getProperty("Apply");
            String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasRegistrationOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasRegistrationOR.getProperty("SanctionsTable");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe")) {
                JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
                je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='regDetails_profile_update']")));
                JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
                executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vApplyButton)));
                Constants.key.pause("6", "");
            } else {
                int count = 0;
                do {
                    count = count + 1;
                    do {
                        count = count + 1;
                    } while (!Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled());
                    Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
                } while (!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe"));
                System.out.println("Count" + count);
                Constants.key.pause("2", "");
                JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
                je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='regDetails_profile_update']")));
                Constants.key.pause("2", "");
                // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
                String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("Apply");
                JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
                executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
                Constants.key.pause("6", "");
            }
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queues")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='regDetails_profile_update']")));
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In Queue")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentIn']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasPaymentInOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment Out Queue")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentOut']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApply = Constants.AtlasPaymentOutOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApply)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue CFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='regDetails_profile_update']")));
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In Queue CFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentIn']")));
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasPaymentInOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment Out Queue CFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentOut']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApply = Constants.AtlasPaymentOutOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApply)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment Out Queue PFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentOut']")));
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApply = Constants.AtlasPaymentOutOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApply)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue PFX")) {
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");


        } else if (Lock.equalsIgnoreCase("Apply&Unlock") && Queue.equalsIgnoreCase("Payment Out Queue PFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//input[@id='updatePaymentOutAndUnlock']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyandunlk = Constants.AtlasPaymentOutOR.getProperty("Apply&Unlock");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            LogCapture.info("user click on apply & unlock button....");
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyandunlk)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply&Unlock") && Queue.equalsIgnoreCase("Payment Out Queue CFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//input[@id='updatePaymentOutAndUnlock']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyandunlk = Constants.AtlasPaymentOutOR.getProperty("Apply&Unlock");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            LogCapture.info("user click on apply & unlock button....");
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyandunlk)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply&Unlock") && Queue.equalsIgnoreCase("Payment Out CFX-Etailer")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//input[@id='updatePaymentOutAndUnlock']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyandunlk = Constants.AtlasPaymentOutOR.getProperty("Apply&Unlock");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            LogCapture.info("user click on apply & unlock button....");
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyandunlk)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In Report")) {
            Constants.key.pause("3", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasPaymentInOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In CFX-Etailer")) {
            Constants.key.pause("3", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasPaymentInOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");
        }
    }


    //Assert.assertEquals("PASS", Constants.key.isAlertPresent());
//                Alert alert = Constants.driver.switchTo().alert();
//                System.out.println("Alert Message"+alert.getText());
//                alert.accept();
//                String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("Sanctions");
//                String vObjRepeatCheck = Constants.AtlasRegistrationOR.getProperty("RepeatCheck");
//                String vObjSanctionStatus = Constants.AtlasRegistrationOR.getProperty("SanctionStatus");
//                Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
//                int count = 0;
//                do {
//                    count = count + 1;
//                    Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
//                } while ((!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).isDisplayed()));
//                if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue")) {
//                    String vApplyButton = Constants.AtlasRegistrationOR.getProperty("Apply");
//                    Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));
//                }
    //           }
    //      }
//       else if (Lock.equalsIgnoreCase("Apply")&& Queue.equalsIgnoreCase("Payment In Queue")) {
//            String vApplyButton = Constants.AtlasPaymentInOR.getProperty("Atlas_ApplyButton");
//            Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));
//        }


    @Then("^(Payment In|Registration|Payment Out|Registration CFX|Payment In CFX|Payment Out CFX|Payment In PFX|Payment Out PFX|Payment Out CFX-Etailer|Payment In CFX-Etailer|) Status to be Observed as (CLEAR|ACTIVE|INACTIVE|REJECT|SEIZE|HOLD) with success message$")
    public void paymentInStatusToBeObservedAsCLEARWthSuccessMessage(String Value, String Action) throws Exception {
        if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("ACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("INACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("REJECT")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "REJECTED"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In") && Action.equalsIgnoreCase("HOLD")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            // String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            // Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "HOLD"));
            // Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        }
        else if (Value.equalsIgnoreCase("Registration CFX") && Action.equalsIgnoreCase("ACTIVE")) {
            String vSuccessMessage = Constants.AtlasRegistrationOR.getProperty("SuccessMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[contains(text(),'Sanction Repeat Check Successfully done for contact') or contains(text(),'Updated successfully')]")));
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");


            String actual = Constants.driver.findElement(By.xpath(vSuccessMessage)).getText();

            if (actual.contains("Updated successfully") || actual.contains("Sanction Repeat Check Successfully done for contact")) {
                LogCapture.info("Sanction Repeat Check Successfully done for contact::" + actual);
            } else {
                LogCapture.info("Not updated Successfully" + actual);
                Assert.fail();
            }

            //Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));

            String vObjStatus1 = Constants.AtlasRegistrationOR.getProperty("Status1");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus1, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus1, "ACTIVE"));

        } else if (Value.equalsIgnoreCase("Registration CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status1");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "REJECTED"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration CFX") && Action.equalsIgnoreCase("INACTIVE")) {
            String vSuccessMessage = Constants.AtlasRegistrationOR.getProperty("SuccessMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[contains(text(),'Sanction Repeat Check Successfully done for contact') or contains(text(),'Updated successfully')]")));
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");

            String actual = Constants.driver.findElement(By.xpath(vSuccessMessage)).getText();

            if (actual.contains("Updated successfully") || actual.contains("Sanction Repeat Check Successfully done for contact")) {
                LogCapture.info("Sanction Repeat Check Successfully done for contact::" + actual);
            } else {
                LogCapture.info("Not updated Successfully" + actual);
                Assert.fail();
            }

            //Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));

            String vObjStatus1 = Constants.AtlasRegistrationOR.getProperty("Status1");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus1, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus1, "INACTIVE"));

        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user shows update msg....");
            String vPaymenthold = AtlasPaymentOutOR.getProperty("Atlas_hold");
            String vSuccessMessage = AtlasPaymentOutOR.getProperty("Atlas_success_msg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymenthold, "HOLD"));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
            Constants.key.pause("4", "");

        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user shows update msg....");
            String vPaymentholdcfx = AtlasPaymentOutOR.getProperty("Atlas_hold");
            String vSuccessMessage = AtlasPaymentOutOR.getProperty("Atlas_success_msg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentholdcfx, "HOLD"));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
            Constants.key.pause("4", "");
        } else if (Value.equalsIgnoreCase("Payment Out CFX-Etailer") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user shows update msg....");
            String vPaymentholdcfx = AtlasPaymentOutOR.getProperty("Atlas_hold");
            String vSuccessMessage = AtlasPaymentOutOR.getProperty("Atlas_success_msg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentholdcfx, "HOLD"));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
            Constants.key.pause("4", "");
        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user shows update msg....");
            String vPaymentholdincfx = AtlasPaymentOutOR.getProperty("Atlas_hold");
            String vSuccessMessage = AtlasPaymentOutOR.getProperty("Atlas_success_msg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentholdincfx, "HOLD"));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
            Constants.key.pause("4", "");
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentrejectStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("HOLD")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentholdStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "HOLD"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        }
    }

    @And("^User navigates to Payment_Out Report from Dashboard$")
    public void userNavigatesToPayment_OutReportFromDashboard() throws Exception {
        LogCapture.info("User is selecting Payment Out hyperlink from dashboard..");
        String vtabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
        String vPaymentOutTab = Constants.AtlasDashboardOR.getProperty("Atlas_PaymentOutTab");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vtabView, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vPaymentOutTab, ""));
    }

    @And("^User select the SANCTION STATUS as PASS$")
    public void userSelectTheSANCTIONSTATUSAsPASS() throws Exception {
        LogCapture.info("Selecting Santion as PASS....");
        String vSanctionStatusPass = Constants.AtlasPaymentOutOR.getProperty("Atlas_SanctionPass");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSanctionStatusPass, ""));
    }

    @And("^user hits Enter on Keyboard$")
    public void userHitsEnterOnKeyboard() throws Exception {
        System.out.println("user hits Enter on Keyboard");
        //Assert.assertEquals("PASS", Constants.key.sendkeyboardStroke("","enter"));
        String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        //String vKeyword=Constants.AtlasRegistrationOR.getProperty("ShowingResults");
        // Assert.assertEquals("PAS//S", Constants.key.VisibleConditionWait(vKeyword,""));
        // Assert.assertEquals("PASS", Constants.key.exist(vKeyword,""));
    }

    @When("^User Click on Apply/Apply & Unlock on Payment Out$")
    public void userClickOnApplyApplyUnlockOnPaymentOut() throws Exception {
        String vApplyButtonPayOut = Constants.AtlasPaymentOutOR.getProperty("Atlas_ApplyPayOutButton");
        Assert.assertEquals("PASS", Constants.key.click(vApplyButtonPayOut, ""));
    }
//    @And("^Mark the Payment In Status as REJECT with comments$")
//    public void markThePaymentInStatusAsREJECTWithComments() throws Exception {
//        String vRejectButton = Constants.AtlasPaymentInOR.getProperty("Atlas_RejectStatus");
//        String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
//        Assert.assertEquals("PASS", Constants.key.click(vRejectButton, ""));
//        Constants.key.pause("1", "");
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, "Payment In Test flow for reject-POC2"));
//    }

    @And("^User selects reason \"([^\"]*)\" from drop down$")
    public void userSelectsReasonFromDropDown(String reason) throws Throwable {
        LogCapture.info("user select reason from dropdown....");
        String vArrowDDClick = Constants.AtlasPaymentOutOR.getProperty("Atlas_ReasonArrowDropDown");
        String vReason = Constants.AtlasPaymentOutOR.getProperty("Atlas_reason");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        Assert.assertEquals("PASS", Constants.key.click(vReason, ""));
    }

    @Then("^Payment In Status to be Observed as REJECT wth success message$")
    public void paymentInStatusToBeObservedAsREJECTWthSuccessMessage() throws Exception {
        String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
        String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
    }

    @And("^User clicks on Logout button to logoff application$")
    public void userClicksOnLogoutButtonToLogoffApplication() throws Exception {
        String vLogOut = Constants.AtlasDashboardOR.getProperty("Atlas_LogOut");
        //String vLogOut = Constants.AtlasDashboardOR.getProperty("");
        Assert.assertEquals("PASS", Constants.key.click(vLogOut, ""));

    }

    @Then("^Payment Out Status to be Observed as REJECT wth success message$")
    public void paymentOutStatusToBeObservedAsREJECTWthSuccessMessage() throws Exception {
        String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
        String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
    }

    @Then("^Payment Out Status to be Observed as ClEAR wth success message$")
    public void paymentOutStatusToBeObservedAsClEARWthSuccessMessage() throws Exception {
        String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
        String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
    }

    @And("^User Click on (Client Number|Client Name) Hyper Link$")
    public void userClickOnHyperLink(String Column) throws Exception {
        String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
        LogCapture.info("Total number of elements present: " + listOfElements.size());
        if (Column.equalsIgnoreCase("Client Number")) {
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[2]";
                ClientNumber = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(ClientNumber);
                if (ClientNumber.length() > 0) {
                    WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + ClientNumber + "']"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", ele);
                    break;
                }
            }
        } else if (Column.equalsIgnoreCase("Client Name")) {
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[4]";
                String Value = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(Value);
                if (Value.length() > 0) {
                    WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", ele);
                    break;
                }
            }
        }
        String vObjClientText = Constants.AtlasRegistrationOR.getProperty("ClientText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientText, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjClientText, ""));
    }


    @And("^User Observe the Status as (ACTIVE|INACTIVE|REJECT) and all the other contact details ContactName \"([^\"]*)\" And EmailAddress \"([^\"]*)\"$")
    public void userObserveTheStatusAndAllTheOtherContactDetailsContactNameAndEmailAddress(String status, String ContactName, String EmailAddress) throws Throwable {
        if (status.equalsIgnoreCase("INACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));
        } else if (status.equalsIgnoreCase("ACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));
        }
        String vObjContactName = Constants.AtlasRegistrationOR.getProperty("ContactName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContactName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjContactName, ContactName));
        String vObjEmailAddress = Constants.AtlasRegistrationOR.getProperty("EmailID");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjEmailAddress, EmailAddress));
    }

    @And("^User select (Reject|Seize) Reason$")
    public void userSelectRejectReason(String Reason) throws Exception {
        if (Reason.equalsIgnoreCase("Reject")) {
            Constants.key.pause("3", "");
            String vObjSelectReason = Constants.AtlasRegistrationOR.getProperty("SelectReason");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectReason, ""));
            Constants.key.pause("3", "");
            String vObjSelectAnyReason = Constants.AtlasRegistrationOR.getProperty("SelectAnyReason");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectAnyReason, ""));
        } else if (Reason.equalsIgnoreCase("Seize")) {
            Constants.key.pause("3", "");
            String vObjSelectReason = Constants.AtlasRegistrationOR.getProperty("SelectReason");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectReason, ""));
            Constants.key.pause("3", "");
            String vObjSelectAnyReason = Constants.AtlasPaymentInOR.getProperty("SelectAnyReason");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectAnyReason, ""));
        }
    }

    @And("^User Perform the Repeat check for Sanctions$")
    public void userPerformTheRepeatCheckForSanctions() throws Exception {
        String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("Sanctions");
        String vObjRepeatCheck = Constants.AtlasRegistrationOR.getProperty("RepeatCheck");
        String vObjSanctionStatus = Constants.AtlasRegistrationOR.getProperty("SanctionsTable");
        Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
        if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("check")) {
            LogCapture.info("Sanction check status is safe/PASS already and repeat check is performed");
        } else {
            Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled();
            Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            LogCapture.info("Sanction check status is Fail and repeat check is performed");
            //int count = 0;
            // do {
            //  count = count + 1;
            // do {
            //    count = count + 1;
            // } while (!Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled());
            // Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
            //  Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            //  } while (!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("check"));
            //  System.out.println("Count" + count);
        }
    }

    @Then("^(Registration|Payment In|Registration CFX|Payment Out) Status to be Observed as (INACTIVE|ACTIVE|HOLD)$")
    public void registrationStatusToBeObservedAsINACTIVE(String action, String status) throws Exception {
        if (status.equalsIgnoreCase("INACTIVE") && action.equalsIgnoreCase("Registration")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));

        } else if (status.equalsIgnoreCase("ACTIVE") && action.equalsIgnoreCase("Registration")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));

        } else if (status.equalsIgnoreCase("HOLD") && action.equalsIgnoreCase("Payment In")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "HOLD"));

        } else if (status.equalsIgnoreCase("ACTIVE") && action.equalsIgnoreCase("Registration CFX")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));

        } else if (status.equalsIgnoreCase("INACTIVE") && action.equalsIgnoreCase("Registration CFX")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));

        } else if (status.equalsIgnoreCase("HOLD") && action.equalsIgnoreCase("Payment Out")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "HOLD"));

        }
    }

    @And("^User Click on Hyper Link with (INACTIVE|ACTIVE WITH ALL CHECK PASS|REJECTED|BLACKLIST|ACTIVE|ACTIVE WITH ALL CHECK PASS CFX|BLACKLIST CFX|ACTIVE CFX|INACTIVE CFX) Record$")
    public void userClickOnHyperLinkOnDashboard(String status) throws Exception {
        if (status.equalsIgnoreCase("INACTIVE") || status.equalsIgnoreCase("ACTIVE") || status.equalsIgnoreCase("BLACKLIST") || status.equalsIgnoreCase("ACTIVE WITH ALL CHECK PASS") || status.equalsIgnoreCase("BLACKLIST CFX") || status.equalsIgnoreCase("ACTIVE WITH ALL CHECK PASS CFX") || status.equalsIgnoreCase("ACTIVE CFX") || status.equalsIgnoreCase("INACTIVE CFX")) {
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String Status = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[11]";
                String ClientNumber = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String EID = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[13]";
                String FraudPredict = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[14]";
                String Sanction = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[15]";
                String Blacklist = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[16]";
                //String BlacklistCFX = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[18]";
                String CustomCheck = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[17]";
                String Value = Constants.driver.findElement(By.xpath(Status)).getText();
                String Value1 = Constants.driver.findElement(By.xpath(ClientNumber)).getText();
                if (status.equalsIgnoreCase("INACTIVE")) {
                    //System.out.println(i);
                    if (Value.equalsIgnoreCase("INACTIVE")) {
                        System.out.println(i + "INACTIVE");
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
                if (status.equalsIgnoreCase("INACTIVE CFX")) {
                    //System.out.println(i);
                    if (Value.equalsIgnoreCase("INACTIVE")) {
                        System.out.println(i + "INACTIVE");
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                } else if (status.equalsIgnoreCase("ACTIVE WITH ALL CHECK PASS CFX")) {
                    if (Value.equalsIgnoreCase("ACTIVE")) {
                        System.out.println("ACTIVE CFX Record");
//                        Assert.assertEquals("PASS", Constants.key.verifyText(EID, "not_interested"));
//                        Assert.assertEquals("PASS", Constants.key.verifyText(FraudPredict, "not_interested"));
//                        Assert.assertEquals("PASS", Constants.key.verifyText(Sanction, "check"));
//                        Assert.assertEquals("PASS", Constants.key.verifyText(Blacklist, "check"));
//                        Assert.assertEquals("PASS", Constants.key.verifyText(CustomCheck, "not_interested"));
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                } else if (status.equalsIgnoreCase("ACTIVE WITH ALL CHECK PASS")) {
                    if (Value.equalsIgnoreCase("ACTIVE")) {
                        System.out.println("ACTIVE");
                        Assert.assertEquals("PASS", Constants.key.verifyText(EID, "check"));
                        Assert.assertEquals("PASS", Constants.key.verifyText(FraudPredict, "check"));
                        Assert.assertEquals("PASS", Constants.key.verifyText(Sanction, "check"));
                        Assert.assertEquals("PASS", Constants.key.verifyText(Blacklist, "check"));
                        Assert.assertEquals("PASS", Constants.key.verifyText(CustomCheck, "check"));
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }

                } else if (status.equalsIgnoreCase("BLACKLIST")) {
                    System.out.println("BLACKLIST");
                    Assert.assertEquals("PASS", Constants.key.verifyText(EID, "not_interested"));
                    Assert.assertEquals("PASS", Constants.key.verifyText(FraudPredict, "check"));
                    Assert.assertEquals("PASS", Constants.key.verifyText(Sanction, "not_interested"));
                    Assert.assertEquals("PASS", Constants.key.verifyText(Blacklist, "clear"));
                    Assert.assertEquals("PASS", Constants.key.verifyText(CustomCheck, "check"));
                    WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", ele);
                    break;
                } else if (status.equalsIgnoreCase("BLACKLIST CFX")) {
                    System.out.println("BLACKLIST CFX::" + Value1);
//                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(Blacklist, ""));
//                    Assert.assertEquals("PASS", Constants.key.verifyText(Blacklist, "clear"));
                    WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", ele);
                    break;
                } else if (status.equalsIgnoreCase("ACTIVE")) {
                    if (Value.equalsIgnoreCase("ACTIVE")) {
                        System.out.println("ACTIVE");
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }

                } else if (status.equalsIgnoreCase("ACTIVE CFX")) {
                    if (Value.equalsIgnoreCase("ACTIVE")) {
                        System.out.println("ACTIVE CFX");
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
                String vObjClientText = Constants.AtlasRegistrationOR.getProperty("ClientText");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientText, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjClientText, ""));
            }
        }
    }

    @And("^User (scroll down|scroll up) the page$")
    public void userScrollDownThePage(String Value) throws InterruptedException {
        if (Value.equalsIgnoreCase("scroll up")) {
            Constants.key.pause("2", "");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(0,1000)");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(0,1000)");

        }
        if (Value.equalsIgnoreCase("scroll down")) {
            Constants.key.pause("2", "");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
        }
    }


    @And("^User Validates the tooltip message and Bold Text on the (Registration|Payment In|Payment Out) dashboard$")
    public void userValidatesTheTooltipMessageOnTheDashboard(String Values) throws Exception {
        if (Values.equalsIgnoreCase("Registration")) {
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String Value = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(Value);
                if (Value.length() > 0) {
                    //  Actions actions = new Actions(Constants.driver);
                    Constants.key.pause("2", "");
                    WebElement element = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                    String strJavaScript = "var element = arguments[0]; var mouseEventObj = document.createEvent('MouseEvents'); mouseEventObj.initEvent( 'mouseover', true, true ); element.dispatchEvent(mouseEventObj);";
                    ((JavascriptExecutor) driver).executeScript(strJavaScript, element);
                    // actions.moveToElement(element).perform();
                    Constants.key.pause("2", "");
                    String vObjToolTip = Constants.AtlasRegistrationOR.getProperty("TooTipMsg");
                    String ActualText = (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML;", driver.findElement(By.xpath("//*[contains(text(),'You own(s) this record')]")));
                    System.out.println("--------" + ActualText);
                    LogCapture.info(ActualText);

                    Assert.assertEquals("PASS", Constants.key.verifyText(vObjToolTip, ActualText));
                    String Bold1 = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']")).getCssValue("font-weight");
                    int BoldNumber = Integer.parseInt(Bold1);
                    System.out.println("Letter:>>>" + Value + "Font Weight:::->" + Bold1);
                    if (BoldNumber >= 700) {
                        LogCapture.info(" User will be able to view the Client Number in Bold letter");
                    } else {
                        LogCapture.info(" User will not be able to view the Client Number in Bold letter" + BoldNumber + "" + Value);
                        Assert.fail();
                    }
                    break;
                }
            }

        } else if (Values.equalsIgnoreCase("Payment In")) {
            String vObjPaymentInQueueTable = AtlasPaymentInOR.getProperty("PaymentInQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='payInQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String Value = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(Value);
                if (Value.length() > 0) {
                    Actions actions = new Actions(Constants.driver);
                    Constants.key.pause("2", "");
                    WebElement element = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                    //actions.moveToElement(element).perform();
                    String strJavaScript = "var element = arguments[0]; var mouseEventObj = document.createEvent('MouseEvents'); mouseEventObj.initEvent( 'mouseover', true, true ); element.dispatchEvent(mouseEventObj);";
                    ((JavascriptExecutor) driver).executeScript(strJavaScript, element);
                    Constants.key.pause("2", "");
                    String vObjToolTip = Constants.AtlasRegistrationOR.getProperty("TooTipMsg");
                    String ActualText = (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML;", driver.findElement(By.xpath("//*[contains(text(),'You own(s) this record')]")));
                    System.out.println("--------" + ActualText);
                    LogCapture.info(ActualText);
                    Assert.assertEquals("PASS", Constants.key.verifyText(vObjToolTip, ActualText));
                    String Bold1 = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']")).getCssValue("font-weight");
                    int BoldNumber = Integer.parseInt(Bold1);
                    System.out.println("Letter:>>>" + Value + "Font Weight:::->" + Bold1);
                    if (BoldNumber >= 700) {
                        LogCapture.info(" User will be able to view the Client Number in Bold letter");
                    } else {
                        LogCapture.info(" User will not be able to view the Client Number in Bold letter" + BoldNumber + "" + Value);
                        Assert.fail();
                    }
                    break;
                }
            }
        } else if (Values.equalsIgnoreCase("Payment Out")) {
            String vObjPaymentOutQueueTable = Constants.AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentOutQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='payOutQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String Value = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(Value);
                if (Value.length() > 0) {
                    Actions actions = new Actions(Constants.driver);
                    Constants.key.pause("2", "");
                    WebElement element = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                    //actions.moveToElement(element).perform();
                    String strJavaScript = "var element = arguments[0]; var mouseEventObj = document.createEvent('MouseEvents'); mouseEventObj.initEvent( 'mouseover', true, true ); element.dispatchEvent(mouseEventObj);";
                    ((JavascriptExecutor) driver).executeScript(strJavaScript, element);
                    Constants.key.pause("2", "");
                    String vObjToolTip = Constants.AtlasRegistrationOR.getProperty("TooTipMsg");
                    String ActualText = (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML;", driver.findElement(By.xpath("//*[contains(text(),'You own(s) this record')]")));
                    System.out.println("--------" + ActualText);
                    LogCapture.info(ActualText);
                    Assert.assertEquals("PASS", Constants.key.verifyText(vObjToolTip, ActualText));
                    String Bold1 = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']")).getCssValue("font-weight");
                    int BoldNumber = Integer.parseInt(Bold1);
                    System.out.println("Letter:>>>" + Value + "Font Weight:::->" + Bold1);
                    if (BoldNumber >= 700) {
                        LogCapture.info(" User will be able to view the Client Number in Bold letter");
                    } else {
                        LogCapture.info(" User will not be able to view the Client Number in Bold letter" + BoldNumber + "" + Value);
                        Assert.fail();
                    }
                    break;
                }
            }
        }
    }

    @And("^User click on (Generate|Save|Delete) button$")
    public void userClickOnGenerateButton(String button) throws Exception {
        if (button.equalsIgnoreCase("Generate")) {
            String vObjGenerateButton = Constants.AtlasRegistrationOR.getProperty("GenerateButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateButton, ""));
        } else if (button.equalsIgnoreCase("Save")) {
            String vObjSaveButton = Constants.AtlasRegistrationOR.getProperty("SaveButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
//            new WebDriverWait(getWebDriver(), 10).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='save_search_button']"))).click();
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveButton, ""));
        } else if (button.equalsIgnoreCase("Delete")) {
            String vObjDeleteButton = Constants.AtlasRegistrationOR.getProperty("DeleteButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjDeleteButton, ""));
        }
    }

    @And("^User enter the SearchName$")
    public void userEnterTheSearchName() throws Exception {
        String vObjSaveSearchName = Constants.AtlasRegistrationOR.getProperty("SaveSearchName");
        String vObjSaveSearchNameOK = Constants.AtlasRegistrationOR.getProperty("SaveSearchNameOK");
        String Report = RandomStringUtils.randomAlphabetic(5);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSaveSearchName, Report + "_AutoTest"));
        Constants.key.pause("2", "");
        ReportName = Constants.driver.findElement(By.xpath(vObjSaveSearchName)).getAttribute("value");
        System.out.println("ReportName" + ReportName);
        Assert.assertEquals("PASS", Constants.key.click(vObjSaveSearchNameOK, ""));
        Constants.key.pause("10", "");
    }

    @And("^User verify the saved Report on the Filter with (Registration Report|Payment In|Payment Out) screen$")
    public void userVerifyTheSavedReportOnTheFilter(String Page) throws Exception {
        if (Page.equalsIgnoreCase("Registration Report")) {
            String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
            String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            Constants.key.pause("3", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            System.out.println(ReportName);
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                if (vdata.equalsIgnoreCase(ReportName)) {
                    System.out.println(vdata);
                    Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                    break;
                }
            }
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (listOfElements.size() > 1) {
                LogCapture.info("Successfullly Added Report");
            } else {
                Assert.fail();
            }
        } else if (Page.equalsIgnoreCase("Payment In")) {
            String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
            String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            Constants.key.pause("3", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            System.out.println(ReportName);
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                if (vdata.equalsIgnoreCase(ReportName)) {
                    System.out.println(vdata);
                    Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                    break;
                }
            }
            String vObjPaymentInQueueTable = AtlasPaymentInOR.getProperty("PaymentInQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (listOfElements.size() > 1) {
                LogCapture.info("Successfullly Added Report");
            } else {
                Assert.fail();
            }
        } else if (Page.equalsIgnoreCase("Payment Out")) {
            String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
            String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            Constants.key.pause("3", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            System.out.println(ReportName);
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                if (vdata.equalsIgnoreCase(ReportName)) {
                    System.out.println(vdata);
                    Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                    break;
                }
            }
            String vObjPaymentInQueueTable = AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (listOfElements.size() > 1) {
                LogCapture.info("Successfullly Added Report");
            } else {
                Assert.fail();
            }
        }
    }

    @And("^User verify the saved Report Deleted successfully$")
    public void userVerifyTheSavedReportDeletedSuccessfully() throws Exception {
        String vObjConfirmDeleteTextMsg = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteTextMsg");
        String vObjConfirmDeleteOK = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteOK");
        String SearchName = Constants.driver.findElement(By.xpath(vObjConfirmDeleteTextMsg)).getText();
        if (SearchName.equalsIgnoreCase(Comments)) {
            Assert.assertEquals("PASS", Constants.key.click(vObjConfirmDeleteOK, ""));
            Constants.key.pause("3", "");
        }
    }

    @And("^User verify the record has been cleared manually and it is not visible in the (Registration Queue)$")
    public void userVerifyTheRecordsHasBeenClearedManuallyAndItIsNotVisibleInTheRegistrationQueue(String Queue) throws Exception {
        if (Queue.equalsIgnoreCase("Registration Queue")) {
            String vObjRegistrationQueueTableRecord = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueMinRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTableRecord, ""));
            String vObjRegistrationQueueMinRecord = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueMinRecord");
            String vObjRegistrationQueueMaxRecord = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueMaxRecord");
            String vObjRegistrationQueueTotalRecord = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTotalRecord");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRegistrationQueueMinRecord, "0"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRegistrationQueueMaxRecord, "0"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRegistrationQueueTotalRecord, "0"));
            LogCapture.info("User verify the record has been cleared manually and it is not visible in the Queue");

        }
    }

    @And("^Multiple Contact should be observed for the same (PFX|CFX) account$")
    public void multipleContactShouldBeObservedForTheSameWhenSearched(String app) throws Exception {
        if (app.equalsIgnoreCase("PFX")) {
            String vObjMorePersonOnThisAccount = Constants.AtlasRegistrationOR.getProperty("MorePersonOnThisAccount");
            String vObjJointAccount = Constants.AtlasRegistrationOR.getProperty("JointAccount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMorePersonOnThisAccount, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMorePersonOnThisAccount, "1 more person on this account"));
            Assert.assertEquals("PASS", Constants.key.click(vObjMorePersonOnThisAccount, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjJointAccount, ""));

        }
        if (app.equalsIgnoreCase("CFX")) {
            String vObjMoreContactCFX = Constants.AtlasRegistrationOR.getProperty("MoreContactCFX");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMoreContactCFX, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMoreContactCFX, "2 contacts at this company"));
            Assert.assertEquals("PASS", Constants.key.click(vObjMoreContactCFX, ""));


        }
    }

    @And("^User click on Other people on this account name$")
    public void userClickOnOtherPeopleOnThisAccountName() {
        String vObjJointAccount = Constants.AtlasRegistrationOR.getProperty("JointAccount");
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjJointAccount));
        LogCapture.info("Total number of elements present: " + listOfElements.size());
        for (int i = 0; i <= listOfElements.size(); i++) {
            String DynamicValue = "//*[@id='regDetails_OtherPeople']//tr[" + (i + 1) + "]//td[3]";
            String ClientName = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
            System.out.println(ClientName);
            if (ClientName.length() > 0) {
                WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + ClientName + "']"));
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                executor.executeScript("arguments[0].click();", ele);
                break;
            }
        }

    }

    @Then("^User validates the country as \"([^\"]*)\"$")
    public void userValidatesTheCountryAs(String Country) throws Throwable {
        if (Country.equalsIgnoreCase("United Kingdom")) {
            String vObjCountryOfResidence = Constants.AtlasRegistrationOR.getProperty("CountryOfResidence");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryOfResidence, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCountryOfResidence, "United Kingdom (GBR)"));

        }
        if (Country.equalsIgnoreCase("Austria")) {
            String vObjCountryOfResidence = Constants.AtlasRegistrationOR.getProperty("CountryOfResidence");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryOfResidence, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCountryOfResidence, "Austria (AUT)"));

        }
        if (Country.equalsIgnoreCase("UK")) {
            String vObjCFXContactList = Constants.AtlasRegistrationOR.getProperty("CFXContactList");
            String vObjCFXContactList_Browser = Constants.AtlasRegistrationOR.getProperty("CFXContactList_Browser");
            String vObjCFXBody = Constants.AtlasRegistrationOR.getProperty("CFXBody");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXContactList, ""));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCFXBody, "end"));
            if (Constants.CONFIG.getProperty("browser").equalsIgnoreCase("FireFox")) {
                Assert.assertEquals("PASS", Constants.key.click(vObjCFXContactList, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.click(vObjCFXContactList_Browser, ""));
            }
            String vObjUKOrg = Constants.AtlasRegistrationOR.getProperty("UKOrg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUKOrg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjUKOrg, "United Kingdom (GBR)"));


        }
        if (Country.equalsIgnoreCase("Aus")) {
            String vObjCFXContactList = Constants.AtlasRegistrationOR.getProperty("CFXContactList");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXContactList, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCFXContactList, ""));

            String vObjAUSOrg = Constants.AtlasRegistrationOR.getProperty("AUSOrg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAUSOrg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjAUSOrg, "Australia (AUS)"));


        }
    }

    @Then("^User validates the Fraud Ring Graph under FRAUDPREDICT for (PFX|CFX)$")
    public void userValidatesTheFraudRingGraphUnderFRAUDPREDICT(String Val) throws Exception {
        if (Val.equalsIgnoreCase("PFX")) {
            String vObjFraudPredict = Constants.AtlasRegistrationOR.getProperty("FraudPredict");
            String vObjFraugsterChart = Constants.AtlasRegistrationOR.getProperty("FraugsterChart");
            // String vObjAmChartsText = Constants.AtlasRegistrationOR.getProperty("AmChartsText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFraudPredict, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFraudPredict, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFraugsterChart, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjFraugsterChart, ""));
            // Assert.assertEquals("PASS", Constants.key.verifyText(vObjAmChartsText, "JS chart by amCharts"));

        }
        if (Val.equalsIgnoreCase("CFX")) {
            String vObjCFXContactList = Constants.AtlasRegistrationOR.getProperty("CFXContactList");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXContactList, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCFXContactList, ""));
            String vObjCFXFraudPredict = Constants.AtlasRegistrationOR.getProperty("CFXFraudPredict");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXFraudPredict, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCFXFraudPredict, ""));

            String vObjFraugsterChart = Constants.AtlasRegistrationOR.getProperty("FraugsterChartCFX");
            //String vObjAmChartsText = Constants.AtlasRegistrationOR.getProperty("AmChartsText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFraugsterChart, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjFraugsterChart, ""));
            //Assert.assertEquals("PASS", Constants.key.verifyText(vObjAmChartsText, "JS chart by amCharts"));

        }
    }

    @And("^User Click on (Transaction Id|Client Name) Hyper Link on (Payment In|Payment Out)$")
    public void userClickHyperLink(String Column, String Action) throws Exception {
        if (Action.equalsIgnoreCase("Payment In")) {
            String vObjPaymentInQueueTable = Constants.AtlasPaymentInOR.getProperty("PaymentInQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (Column.equalsIgnoreCase("Transaction Id")) {
                for (int i = 0; i <= listOfElements.size(); i++) {
                    String DynamicValue = "//*[@id='payInQueueBody']//tr[" + (i + 1) + "]//td[2]";
                    String TranasctionId = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                    System.out.println(TranasctionId);
                    if (TranasctionId.length() > 0) {
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + TranasctionId + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
            } else if (Column.equalsIgnoreCase("Client Id")) {
                for (int i = 0; i <= listOfElements.size(); i++) {
                    String ClientId = "//*[@id='payInQueueBody']//tr[" + (i + 1) + "]//td[4]";
                    String Value = Constants.driver.findElement(By.xpath(ClientId)).getText();
                    System.out.println(Value);
                    if (Value.length() > 0) {
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
            }
            String vObjTransactionText = Constants.AtlasPaymentInOR.getProperty("TransactionText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionText, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjTransactionText, ""));

        } else if (Action.equalsIgnoreCase("Payment Out")) {
            String vObjPaymentOutQueueTable = Constants.AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentOutQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (Column.equalsIgnoreCase("Transaction Id")) {
                for (int i = 0; i <= listOfElements.size(); i++) {
                    String DynamicValue = "//*[@id='payOutQueueBody']//tr[" + (i + 1) + "]//td[2]";
                    String TranasctionId = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                    System.out.println(TranasctionId);
                    if (TranasctionId.length() > 0) {
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + TranasctionId + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
            } else if (Column.equalsIgnoreCase("Client Id")) {
                for (int i = 0; i <= listOfElements.size(); i++) {
                    String ClientId = "//*[@id='payOutQueueBody']//tr[" + (i + 1) + "]//td[4]";
                    String Value = Constants.driver.findElement(By.xpath(ClientId)).getText();
                    System.out.println(Value);
                    if (Value.length() > 0) {
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
            }
            String vObjTransactionText = Constants.AtlasPaymentInOR.getProperty("TransactionText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionText, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjTransactionText, ""));

        }
    }

    @And("^User Observe the Status as (HOLD|SEIZE|REJECT|CLEAR) and all the other contact details ContactName \"([^\"]*)\" And EmailAddress \"([^\"]*)\"$")
    public void userObserveTheStatusAllTheOtherContactDetailsContactNameAndEmailAddress(String status, String ContactName, String EmailAddress) throws Throwable {
        if (status.equalsIgnoreCase("SEIZE")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "SEIZE"));
        } else if (status.equalsIgnoreCase("HOLD")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "HOLD"));
        }
        String vObjContactName = Constants.AtlasPaymentInOR.getProperty("ContactName");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjContactName, ContactName));
        Assert.assertEquals("PASS", Constants.key.click(vObjContactName, ContactName));
        Constants.key.pause("3", "");
        String vObjEmailAddress = Constants.AtlasRegistrationOR.getProperty("EmailID");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjEmailAddress, EmailAddress));
    }


    @And("^User select the record as (INACTIVE|ACTIVE)$")
    public void userSelectTheRecordAsINACTIVE(String status) throws Exception {
        if (status.equalsIgnoreCase("INACTIVE")) {
            String vObjInactiveRecord = Constants.AtlasRegistrationOR.getProperty("InactiveRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInactiveRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjInactiveRecord, ""));
//            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
//            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//           Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            String vObjGenerateReportButton = Constants.AtlasRegistrationOR.getProperty("GenerateReportButton");
//            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateReportButton, ""));
//            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateReportButton, ""));

//            String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//
//            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
//            Assert.assertEquals("PASS", Constants.key.exist(vObjRegistrationQueueTable, ""));
        } else if (status.equalsIgnoreCase("ACTIVE")) {
            String vObjActiveRecord = Constants.AtlasRegistrationOR.getProperty("ActiveRecord");
            Assert.assertEquals("PASS", Constants.key.click(vObjActiveRecord, ""));
//            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
//            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            String vObjGenerateReportButton = Constants.AtlasRegistrationOR.getProperty("GenerateReportButton");
//            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateReportButton, ""));
//            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateReportButton, ""));

//            String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//
//            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
//            Assert.assertEquals("PASS", Constants.key.exist(vObjRegistrationQueueTable, ""));
        }

    }

    @And("^User select the (PFX) record with (Sanction Failed|Payment Out)$")
    public void userSelectThePFXRecordWithSanctionFailed(String Org, String Check) throws Exception {
        if (Org.equalsIgnoreCase("PFX") && Check.equalsIgnoreCase("Sanction Failed")) {
            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
            String vObjSanctionFailed = Constants.AtlasPaymentInOR.getProperty("SanctionFailed");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionFailed, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionFailed, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            String vObjGenerateReportButton = Constants.AtlasPaymentInOR.getProperty("GeneratePayInButton");
//            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateReportButton, ""));
//            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateReportButton, ""));
            String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));

            String vObjRegistrationQueueTable = Constants.AtlasPaymentInOR.getProperty("PaymentInQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjRegistrationQueueTable, ""));
        } else if (Org.equalsIgnoreCase("Payment Out") && Check.equalsIgnoreCase("Payment Out")) {
            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
            String vObjSanctionFailed = Constants.AtlasPaymentInOR.getProperty("SanctionFailed");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionFailed, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionFailed, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            String vObjGenerateReportButton = Constants.AtlasPaymentOutOR.getProperty("GeneratePayInButton");
//            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateReportButton, ""));
//            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateReportButton, ""));

            String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));

            String vObjRegistrationQueueTable = Constants.AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjRegistrationQueueTable, ""));
        }

    }

    @And("^User Perform the Repeat check for Sanctions for (PaymentIn)$")
    public void userPerformTheRepeatCheckSanctions(String Pay) throws Exception {
        if (Pay.equalsIgnoreCase("PaymentIn")) {
            String vObjSanctions = Constants.AtlasPaymentInOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasPaymentInOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentInOR.getProperty("SanctionsTable");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe")) {
                LogCapture.info("Sanction check status is safe/PASS already");
            } else {
                int count = 0;
                do {
                    count = count + 1;
                    do {
                        count = count + 1;
                    } while (!Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled());
                    Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));

                } while (!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe"));
                System.out.println("Count" + count);
            }
        }
    }

    @And("^User verify (Further Payment details|Wallets|FX Detail) section$")
    public void userVerifyFurtherPaymentDetailsSection(String Value) throws Exception {
        if (Value.equalsIgnoreCase("Further Payment details")) {
            String vObjFurtherPaymentDetails = Constants.AtlasPaymentInOR.getProperty("FurtherPaymentDetails");
            Assert.assertEquals("PASS", Constants.key.click(vObjFurtherPaymentDetails, ""));
            String vObjFurtherPaymentDetailsText = Constants.AtlasPaymentInOR.getProperty("FurtherPaymentDetailsText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFurtherPaymentDetailsText, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjFurtherPaymentDetailsText, ""));
            String vObjFurtherPaymentDetailsTable = Constants.AtlasPaymentInOR.getProperty("FurtherPaymentDetailsTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFurtherPaymentDetailsTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjFurtherPaymentDetailsTable, ""));
        } else if (Value.equalsIgnoreCase("Wallets")) {
            String vObjClientWallets = Constants.AtlasPaymentInOR.getProperty("ClientWallets");
            Assert.assertEquals("PASS", Constants.key.click(vObjClientWallets, ""));
            String vObjClientWalletsTable = Constants.AtlasPaymentInOR.getProperty("ClientWalletsTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientWalletsTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjClientWalletsTable, ""));


        } else if (Value.equalsIgnoreCase("FX Detail")) {
            String vObjFxTickets = Constants.AtlasPaymentInOR.getProperty("FxTickets");
            Assert.assertEquals("PASS", Constants.key.click(vObjFxTickets, ""));
            String vObjFxTicketsTable = Constants.AtlasPaymentInOR.getProperty("FxTicketsTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFxTicketsTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjFxTicketsTable, ""));


        }
    }

    @And("^User is (not be able|able) to Perform the Repeat check for (Third Party Check False|Debitor Name Absent|Third Party Check True|Payment Out Queue)$")
    public void userIsNotAbleToPerformTheRepeatCheckForThirdPartyCheckFalse(String RepeatCheck, String Checks) throws Exception {
        if (RepeatCheck.equalsIgnoreCase("not be able") && Checks.equalsIgnoreCase("Third Party Check False")) {
            Constants.key.pause("5", "");
            String vObjSanctions = Constants.AtlasPaymentInOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasPaymentInOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentInOR.getProperty("SanctionsTableStatus");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionStatus, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled() == false) {
                LogCapture.info("Repeat Check button is disabled");
            } else {
                LogCapture.info("Repeat Check button is Enabled");
                Assert.fail();
            }
            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Not Required")) {
                LogCapture.info("Status Should be displayed as Not Required");
            } else {
                LogCapture.info("Status is not displayed as 'Not Required'");
                Assert.fail();
            }

        } else if (RepeatCheck.equalsIgnoreCase("able") && Checks.equalsIgnoreCase("Third Party Check True")) {
            String vObjSanctions = Constants.AtlasPaymentInOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasPaymentInOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentInOR.getProperty("SanctionsTableStatus");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctions, ""));
            Assert.assertEquals("PASS", Constants.key.Scroll(vObjSanctions, "-300"));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSanctions, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionStatus, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled() == true) {
                LogCapture.info("Repeat Check button is Enabled");
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjRepeatCheck, ""));
            } else {
                LogCapture.info("Repeat Check button is Disabled");
                Assert.fail();
            }

        } else if (RepeatCheck.equalsIgnoreCase("not be able") && Checks.equalsIgnoreCase("Debitor Name Absent")) {
            String vObjSanctions = Constants.AtlasPaymentInOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasPaymentInOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentInOR.getProperty("SanctionsTableStatus");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionStatus, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled() == false) {
                LogCapture.info("Repeat Check button is disabled");
            } else {
                LogCapture.info("Repeat Check button is Enabled");
                Assert.fail();
            }
//            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Not Required")) {
//                LogCapture.info("Status Should be displayed as Not Required");
//            } else {
//                LogCapture.info("Status is not displayed as 'Not Required'");
//                Assert.fail();
//            }
        } else if (RepeatCheck.equalsIgnoreCase("able") && Checks.equalsIgnoreCase("Payment Out Queue")) {
            String vObjSanctions = Constants.AtlasPaymentOutOR.getProperty("SanctionBeneficiary");
            String vObjRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentOutOR.getProperty("SanctionTableStatus");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctions, ""));
            Assert.assertEquals("PASS", Constants.key.Scroll(vObjSanctions, "-400"));
            for (int i = 1; i <= 7; i++) {
                Constants.driver.findElement(By.xpath("//body")).sendKeys(Keys.ARROW_UP);
            }
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionStatus, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled() == true) {
                LogCapture.info("Repeat Check button is Enabled");
                Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
                Constants.key.pause("3", "");
            } else {
                LogCapture.info("Repeat Check button is Disabled");
                Assert.fail();
            }

        }

    }

    @And("^User verify the WatchList and (PaymentMethod|PaymentMethod Other)$")
    public void userVerifyTheWatchListAndPaymentMethod(String arg) throws Exception {
        if (arg.equalsIgnoreCase("PaymentMethod")) {
            String vObjPaymentMethod = Constants.AtlasPaymentInOR.getProperty("PaymentMethod");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjPaymentMethod, "WALLET"));
            String vObjWatchList = Constants.AtlasPaymentInOR.getProperty("WatchList");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjWatchList, "Fraudpredict high risk of fraud\n" +
                    "High Risk Country"));

        } else if (arg.equalsIgnoreCase("PaymentMethod Other")) {
            String vObjWatchList1 = Constants.AtlasPaymentInOR.getProperty("WatchList");
            if (Constants.driver.findElement(By.xpath(vObjWatchList1)).getText().isEmpty()) {
                LogCapture.info("Watch List is not added to the List");
            } else {
                String vObjWatchListUI = Constants.AtlasPaymentInOR.getProperty("WatchListUI");
                String WatchListUI = Constants.driver.findElement(By.xpath(vObjWatchListUI)).getText();
                // Assert.assertEquals("PASS", Constants.key.verifyText(vObjWatchListUI, "WALLET"));
                String vObjWatchList = Constants.AtlasPaymentInOR.getProperty("WatchList");
                String WatchListUI1 = Constants.driver.findElement(By.xpath(vObjWatchList)).getText();
                if (WatchListUI.contains(WatchListUI1)) {
                    LogCapture.info("WatchList is added" + vObjWatchList + "::" + WatchListUI1);
                } else {
                    LogCapture.info("WatchList is not added" + vObjWatchList + "::" + WatchListUI1);
                    Assert.fail();
                }

            }
        }
    }

    @And("^User verify the PaymentMethod and WatchList$")
    public void userVerifyWatchListAndPaymentMethod() throws Exception {
//        String vObjPaymentMethod = Constants.AtlasPaymentInOR.getProperty("PaymentMethod");
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjPaymentMethod, "WALLET"));
        String vObjWatchList = Constants.AtlasPaymentInOR.getProperty("WatchList");
        if (Constants.driver.findElement(By.xpath(vObjWatchList)).getText().isEmpty()) {
            LogCapture.info("WatchList is blank");
        } else {
            LogCapture.info("WatchList is not blank");
        }
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjWatchList, "null"));
    }

    @And("^User selects reason for (Reject|Seize|Inactive) \"([^\"]*)\"$")
    public void userSelectsRejectReason(String Reason, String ReasonValue) throws Throwable {
        if (Reason.equalsIgnoreCase("Reject")) {
            String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReasonDropDown");
            String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReasonValues");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            LogCapture.info("User clicks on dropdown for selecting reason");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i < dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@id='regDetails_contactStatusReasons']//li[" + i + "]//label")).getText();
                if (vdata.equals(ReasonValue)) {
                    Constants.driver.findElement(By.xpath("//*[@id='regDetails_contactStatusReasons']//li[" + i + "]//label")).click();
                    LogCapture.info("User selected reason " + ReasonValue);
                    break;
                }
            }
        } else if (Reason.equalsIgnoreCase("Inactive")) {
            String vObjSelectedReason = Constants.AtlasRegistrationOR.getProperty("SelectedReason");
            List<WebElement> dropdown_list1 = Constants.driver.findElements(By.xpath(vObjSelectedReason));
            System.out.println("The Options in the Dropdown are: " + dropdown_list1.size());
            if (dropdown_list1.size() >= 1) {
                LogCapture.info("Data is Present");
            } else {
                String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReasonDropDown");
                String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReasonValues");
                Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
                Constants.key.pause("2", "");
                List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
                System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
                for (int i = 1; i < dropdown_list.size(); i++) {
                    String vdata = Constants.driver.findElement(By.xpath("//*[@id='regDetails_contactStatusReasons']//li[" + i + "]//label[1]")).getText();
                    if (vdata.equals(ReasonValue)) {
                        Constants.driver.findElement(By.xpath("//*[@id='regDetails_contactStatusReasons']//li[" + i + "]//label[1]")).click();
                        break;
                    }
                }
            }
        }
    }

    @And("^User verify the WatchList \"([^\"]*)\"$")
    public void userVerifyTheWatchList(String WatchList) throws Throwable {
        String vObjWatchList = Constants.AtlasPaymentInOR.getProperty("WatchList");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjWatchList, WatchList));
    }

    @And("^User verify the (Blacklist Check|Country Check Fail|Blacklist Check for CFX)$")
    public void userVerifyTheBlacklistCheck(String status) throws Exception {
        if (status.equalsIgnoreCase("Blacklist Check")) {
            String vObjBlackListCheck = Constants.AtlasPaymentOutOR.getProperty("BlackListCheck");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlackListCheck, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlackListCheck, "clear"));

        } else if (status.equalsIgnoreCase("Country Check Fail")) {
            String vObjCountryCheck = Constants.AtlasPaymentOutOR.getProperty("CountryCheck");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryCheck, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCountryCheck, ""));
            String vObjStatusCheck = Constants.AtlasPaymentOutOR.getProperty("StatusCheck");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatusCheck, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatusCheck, "Fail (Sanctioned Country)"));

        } else if (status.equalsIgnoreCase("Blacklist Check for CFX")) {
            String vObjBlackListCheck1 = Constants.AtlasPaymentOutOR.getProperty("BlackListCheck1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlackListCheck1, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlackListCheck1, "clear"));

        }
    }

    @Then("^Verify the Activity Log has been updated for (Payment Out Queue|Payment In Queue|Registration Queue) for (Reject|Clear|Sanction|Seize)$")
    public void verifyTheActivityLogIsUpdatedForPaymentOutQueue(String Log, String Log1) throws Exception {
        Constants.key.pause("5", "");
        if (Log.equalsIgnoreCase("Payment Out Queue") && Log1.equalsIgnoreCase("Reject")) {
            String vObjActivityLog = Constants.AtlasPaymentOutOR.getProperty("ActivityLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjActivityLog, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjActivityLog, ""));
            String vObjActivityLogTable = Constants.AtlasPaymentOutOR.getProperty("ActivityLogTable");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vObjActivityLogTable));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String Activity = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[4]")).getText();
                String ActivityType = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[5]")).getText();
                String Comment = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[6]")).getText();
                if (Activity.equalsIgnoreCase("Payment out status modified from HOLD to REJECT") && ActivityType.equalsIgnoreCase("Paymentout status update") && Comment.equalsIgnoreCase(Comments)) {
                    LogCapture.info("Activity Log has been updated Successfully" + Activity + "::" + ActivityType + "::" + Comment);
                    break;
                } else {
                    LogCapture.info("Activity Log is not updated Successfully" + Activity + "::" + ActivityType + "::" + Comment);
                    Assert.fail();
                }
            }

        } else if (Log.equalsIgnoreCase("Payment Out Queue") && Log1.equalsIgnoreCase("Clear")) {
            String vObjActivityLog = Constants.AtlasPaymentOutOR.getProperty("ActivityLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjActivityLog, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjActivityLog, ""));
            String vObjActivityLogTable = Constants.AtlasPaymentOutOR.getProperty("ActivityLogTable");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vObjActivityLogTable));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String Activity = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[4]")).getText();
                String ActivityType = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[5]")).getText();
                String Comment = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[6]")).getText();
                if (Activity.equalsIgnoreCase("Payment out status modified from HOLD to CLEAR") && ActivityType.equalsIgnoreCase("Paymentout status update") && Comment.equalsIgnoreCase(Comments)) {
                    LogCapture.info("Activity Log has been updated Successfully" + Activity + "::" + ActivityType + "::" + Comment);
                    break;
                } else {
                    LogCapture.info("Activity Log has been updated Successfully" + Activity + "::" + ActivityType + "::" + Comment);
                    Assert.fail();
                }
            }

        } else if (Log.equalsIgnoreCase("Payment Out Queue") && Log1.equalsIgnoreCase("Sanction")) {
            String vObjActivityLog = Constants.AtlasPaymentOutOR.getProperty("ActivityLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjActivityLog, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjActivityLog, ""));
            String vObjActivityLogTable = Constants.AtlasPaymentOutOR.getProperty("ActivityLogTable");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vObjActivityLogTable));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i <= dropdown_list.size(); i++) {
                // String Activity = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[4]")).getText();
                String ActivityTypes = "//*[@id='activityLog']//tr[" + i + "]//td[5]";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ActivityTypes, ""));
                Constants.key.pause("4", "");
                String ActivityType = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[5]")).getText();
                String Comment = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[6]")).getText();
                if (ActivityType.equalsIgnoreCase("Paymentout sanction repeat") && Comment.equalsIgnoreCase("-")) {
                    LogCapture.info("Activity Log has been updated Successfully" + "::" + ActivityType + "::" + Comment);
                    break;
                } else {
                    LogCapture.info("Activity Log has been updated Successfully" + "::" + ActivityType + "::" + Comment);
                    Assert.fail();
                }
            }

        }
    }

    @And("^User delete any one of the report if the report has more than 5 for (Payment Out Queue|Payment In Queue|Registration Report|Payment In Reports|Payment Out Reports|)$")
    public void userDeleteTheReportIfTheReportHasMoreThan(String Report) throws Exception {
        String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
        String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vArrowDDClick, ""));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vArrowDDClick)));
        //Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
        Constants.key.pause("3", "");
        List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
        System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
        if (dropdown_list.size() == 5) {
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                Constants.key.pause("3", "");
                String vObjDeleteButton = Constants.AtlasRegistrationOR.getProperty("DeleteButton");
                ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteButton, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjDeleteButton, ""));
                Constants.key.pause("2", "");
                String vObjConfirmDeleteTextMsg = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteTextMsg");
                String vObjConfirmDeleteOK = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteOK");
                String SearchName = Constants.driver.findElement(By.xpath(vObjConfirmDeleteTextMsg)).getText();
                System.out.println("Search Name::" + SearchName);
                Assert.assertEquals("PASS", Constants.key.click(vObjConfirmDeleteOK, ""));
                Constants.key.pause("5", "");
                if (Report.equalsIgnoreCase("Payment Out Queue")) {
                    LogCapture.info("User is selecting Payment Out Queue hyperlink from dashboard..");
                    String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                    String vObjAtlasPaymentOutTabQueue = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutTabQueue");
                    String vObjAtlasPaymentOutQueueText = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutQueueText");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasPaymentOutTabQueue, ""));
                    String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
                } else if (Report.equalsIgnoreCase("Payment In Queue")) {
                    LogCapture.info("User is selecting Payment In Queue hyperlink from dashboard..");
                    String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                    String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("AtlasPaymentInTabQueue");
                    String vObjAtlasPaymentInQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasPaymentInQueueText");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
                    String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
                } else if (Report.equalsIgnoreCase("Registration Report")) {
                    LogCapture.info("User is selecting Registration Report hyperlink from dashboard..");
                    String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                    String vObjAtlasRegistrationReport = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReport");
                    String vObjAtlasRegistrationReportText = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReportText");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasRegistrationReport, ""));
                    Constants.key.pause("3", "");
                } else if (Report.equalsIgnoreCase("Payment In Reports")) {
                    LogCapture.info("User is selecting Payment In Queue hyperlink from dashboard..");
                    String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                    String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("AtlasPaymentInTabQueue");
                    String vObjAtlasPaymentInQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasPaymentInQueueText");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
                    String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
                } else if (Report.equalsIgnoreCase("Payment Out Reports")) {
                    LogCapture.info("User is selecting Payment Out Queue hyperlink from dashboard..");
                    String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                    String vObjAtlasPaymentOutTabQueue = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutTabQueue");
                    String vObjAtlasPaymentOutQueueText = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutQueueText");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasPaymentOutTabQueue, ""));
                    String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
                }


                String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, "goerge123@mailinator.com"));
                String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
                Assert.assertEquals("PASS", Constants.key.pause("3", ""));
                break;

            }

        } else {
            LogCapture.info("Saved Report has Less than 5");
        }

    }

    @And("^User select (Record|Client Type) as \"([^\"]*)\"$")
    public void userSelectRecordAs(String Value, String NewOrUpdate) throws Throwable {
        if (NewOrUpdate.equalsIgnoreCase("New") && Value.equalsIgnoreCase("Record")) {
            String vObjNewRecord = AtlasRegistrationOR.getProperty("NewRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNewRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjNewRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("Updated") && Value.equalsIgnoreCase("Record")) {
            String vObjUpdateRecord = AtlasRegistrationOR.getProperty("UpdateRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUpdateRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjUpdateRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("Inactive") && Value.equalsIgnoreCase("Record")) {
            String vObjInactiveRecord = Constants.AtlasRegistrationOR.getProperty("InactiveRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInactiveRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjInactiveRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("Active") && Value.equalsIgnoreCase("Record")) {
            String vObjActiveRecord = Constants.AtlasRegistrationOR.getProperty("ActiveRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjActiveRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjActiveRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("CFX") && Value.equalsIgnoreCase("Client Type")) {
            String vObjCFXRecord = Constants.AtlasRegistrationOR.getProperty("CFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCFXRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("PFX") && Value.equalsIgnoreCase("Client Type")) {
            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("CFX-Etailer") && Value.equalsIgnoreCase("Client Type")) {
            String vObjCFXERecord = Constants.AtlasRegistrationOR.getProperty("CFXERecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXERecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCFXERecord, ""));

        }
    }

    @And("^User Perform the Repeat check for Contacts Sanctions$")
    public void userPerformTheRepeatCheckForContactsSanctions() throws Exception {
        String vObjCFXContactList = Constants.AtlasRegistrationOR.getProperty("PrimaryContact");// CFXContactList
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXContactList, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCFXContactList, ""));
        String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("PrimaryContactList");//CFXContactListSanctions
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctions, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
        String vObjRepeatCheck = Constants.AtlasRegistrationOR.getProperty("PrimaryContactListRepeatCheck");//CFXSanactionRepeatCheck
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRepeatCheck, ""));
        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
        String vObjCFXSanctionTable = Constants.AtlasRegistrationOR.getProperty("PrimaryContactListRepeatCheckTable");//CFXSanctionTable
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXSanctionTable, ""));

        if (Constants.driver.findElement(By.xpath(vObjCFXSanctionTable)).getText().equalsIgnoreCase("Safe")) {
            LogCapture.info("Sanction check status is safe/PASS already");
        } else {
            int count = 0;
            do {
                count = count + 1;

                do {
                    count = count + 1;
                } while (!Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled());
                Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));

            } while (!Constants.driver.findElement(By.xpath(vObjCFXSanctionTable)).getText().equalsIgnoreCase("Safe"));
            System.out.println("Count" + count);
        }
    }

    @And("^User select (Blacklist|Sanction|WatchList|Custom Check) (failed|passed)$")
    public void userSelectBlacklistFailed(String Action, String Check) throws Exception {
        if (Action.equalsIgnoreCase("Blacklist") && Check.equalsIgnoreCase("failed")) {
            System.out.println("Blacklist Failed");
            String vObjBlackListFail = Constants.AtlasRegistrationOR.getProperty("BlackListFail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlackListFail, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBlackListFail, ""));
        } else if (Action.equalsIgnoreCase("Sanction") && Check.equalsIgnoreCase("failed")) {
            System.out.println("SanctionFail Failed");
            String vObjSanctionFail = Constants.AtlasRegistrationOR.getProperty("SanctionFail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionFail, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionFail, ""));
        } else if (Action.equalsIgnoreCase("WatchList") && Check.equalsIgnoreCase("passed")) {
            System.out.println("WatchList Passed");
            String vObjWatchList = Constants.AtlasRegistrationOR.getProperty("WatchListPass");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWatchList, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjWatchList, ""));
        } else if (Action.equalsIgnoreCase("Sanction") && Check.equalsIgnoreCase("passed")) {
            System.out.println("SanctionFail Passed");
            String vObjSanctionPass = Constants.AtlasRegistrationOR.getProperty("SanctionPass");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionPass, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionPass, ""));
        } else if (Action.equalsIgnoreCase("Custom Check") && Check.equalsIgnoreCase("failed")) {
            System.out.println("Customcheck Failed");
            String vObjCustomCheckPass = Constants.AtlasRegistrationOR.getProperty("CustomCheckFail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomCheckPass, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomCheckPass, ""));
        } else if (Action.equalsIgnoreCase("Custom Check") && Check.equalsIgnoreCase("passed")) {
            System.out.println("Customcheck Passed");
            String vObjCustomCheckPass = Constants.AtlasRegistrationOR.getProperty("CustomCheckPass");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomCheckPass, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomCheckPass, ""));
        } else if (Action.equalsIgnoreCase("Blacklist") && Check.equalsIgnoreCase("passed")) {
            System.out.println("Blacklist Passed");
            String vObjBlacklistPass = Constants.AtlasRegistrationOR.getProperty("BlacklistPass");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlacklistPass, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistPass, ""));
        }
    }

    @And("^User validate the more contact for (CFX)$")
    public void userClickOnOtherPeopleOnThisAccountName(String app) {
        if (app.equalsIgnoreCase("CFX")) {
            String vObjMoreContactValidation = Constants.AtlasRegistrationOR.getProperty("MoreContactValidation");
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjMoreContactValidation));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (listOfElements.size() == 2) {
                LogCapture.info("User validate the more contact for CFX");
            } else {
                LogCapture.info("User validate the more contact for (CFX" + listOfElements.size());
                Assert.fail();
            }

        }
    }

    @And("^User select (Country) \"([^\"]*)\" from (Payment Out Queue) page$")
    public void userSelectOrganizationFromBlotterReportPage(String Value, String Opt, String Menu) throws Throwable {
        if (Value.equalsIgnoreCase("Country1") && Menu.equalsIgnoreCase("Payment Out Queue1")) {
            LogCapture.info("User select Country ......");
            Constants.key.pause("3", "");
            String vObjCountryValues = Constants.AtlasPaymentOutOR.getProperty("CountryValues");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryValues, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vObjCountryValues, Opt));
        } else if (Value.equalsIgnoreCase("Country") && Menu.equalsIgnoreCase("Payment Out Queue")) {
            LogCapture.info("User select Country ......");
            Constants.key.pause("3", "");
            String vObjCountryValues = Constants.AtlasPaymentOutOR.getProperty("CountryEdit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryValues, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountryValues, Opt));
//            Constants.key.pause("1", "");
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountryValues, "downArrow"));
//            Constants.key.pause("2", "");
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountryValues, "enter"));

        }


    }

    @And("^User click on (Country|High Risk Country) from (Payment Out Queue CFX|Payment Out Queue PFX|Payment Out Queue) page$")
    public void userClickOnGetBlotterFromBlotterReportPage(String Value, String Menu) throws Throwable {
        if (Value.equalsIgnoreCase("Country") && Menu.equalsIgnoreCase("Payment Out Queue")) {
            LogCapture.info("User Click on Country ......");
            Constants.key.pause("4", "");
            String vObjCountryField = Constants.AtlasPaymentOutOR.getProperty("CountryField");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCountryField, ""));

        } else if (Value.equalsIgnoreCase("High Risk Country") && Menu.equalsIgnoreCase("Payment Out Queue CFX")) {
            LogCapture.info("User Click on Country ......");
            Constants.key.pause("4", "");//input[@name='countryOfBeneficiary[]' and @value='Pakistan']
            String vObjCountryField1 = Constants.AtlasPaymentOutOR.getProperty("CountryField1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryField1, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCountryField1, ""));

        } else if (Value.equalsIgnoreCase("High Risk Country") && Menu.equalsIgnoreCase("Payment Out Queue PFX")) {
            LogCapture.info("User Click on Country ......");
            Constants.key.pause("4", "");//input[@name='countryOfBeneficiary[]' and @value='Pakistan']
            String vObjCountryField2 = Constants.AtlasPaymentOutOR.getProperty("CountryField2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryField2, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCountryField2, ""));

        }
    }

    @And("^User verify the success message on UI$")
    public void userVerifyTheSuccessMessageOnUI() throws Exception {
        String vSuccessMessage = Constants.AtlasRegistrationOR.getProperty("SuccessMsgPFX");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
        JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
        je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[contains(text(),'Sanction Repeat Check Successfully done') or contains(text(),'Updated successfully')]")));
        //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");

        String actual = Constants.driver.findElement(By.xpath(vSuccessMessage)).getText();

        if (actual.contains("Updated successfully") || actual.contains("Sanction Repeat Check Successfully done")) {
            LogCapture.info("Sanction Repeat Check Successfully done for contact::" + actual);
        } else {
            LogCapture.info("Not updated Successfully" + actual);
            Assert.fail();
        }
    }

    @And("^User select a record with (CFX) (INACTIVE) from (Registration Report)$")
    public void userSelectARecordWithINACTIVECFXFromRegistrationReport(String app, String status, String page) throws Exception {
        if (app.equalsIgnoreCase("CFX") && status.equalsIgnoreCase("INACTIVE") && page.equalsIgnoreCase("Registration Report")) {
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String Application = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[5]";
                String Status = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[11]";
                String ClientNumber = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String EID = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[13]";
                String FraudPredict = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[14]";
                String Sanction = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[15]";
                String Blacklist = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[16]";
                //String BlacklistCFX = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[18]";
                String CustomCheck = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[17]";
                String Value = Constants.driver.findElement(By.xpath(Status)).getText();
                String Value1 = Constants.driver.findElement(By.xpath(ClientNumber)).getText();
                String App = Constants.driver.findElement(By.xpath(Application)).getText();

                if (Value.equalsIgnoreCase("INACTIVE") && App.equalsIgnoreCase("CFX")) {
                    System.out.println(i + "INACTIVE");
                    WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", ele);
                    break;
                }
                System.out.println("Selected Row Number:-" + i);
            }
        }
    }

    @Then("^User validates that Initial Status does not exist on Registration Details page$")
    public void userValidatesThatInitialStatusDoesNotExistOnRegistrationDetailsPage() throws Exception {

        String vObjInitialStatusText = Constants.AtlasRegistrationOR.getProperty("InitialStatusValue");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjInitialStatusText, ""));
        LogCapture.info("User observes that Initial status does not exist on registartion details page");

    }

    @And("^User clicks on status dropdown and selects the status as (CLEAR|REJECT|SIEZE|HOLD|RESERVED)$")
    public void userClicksOnStatusDropdownAndSelectsTheStatusAsCLEAR(String status) throws Exception {

        String vObjStatusDropDown = Constants.AtlasRegistrationOR.getProperty("FilterStatusDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vObjStatusDropDown, ""));
        if (status.equalsIgnoreCase("CLEAR")) {
            String vObjClearStatus = Constants.AtlasRegistrationOR.getProperty("StatusValueClear");
            Assert.assertEquals("PASS", Constants.key.click(vObjClearStatus, ""));
        }
        LogCapture.info(status + " is selected as status from dropdown");

    }

    @Then("^User validates that Initial Status as \"([^\"]*)\" on (Registration|PaymentIn|PaymentOut) Details page$")
    public void userValidatesThatInitialStatusAsOnRegistrationDetailsPage(String Status, String page) throws Throwable {

        String vObjStatusValue = Constants.AtlasRegistrationOR.getProperty("InitialStatusValue");
        if (page.equalsIgnoreCase("PaymentIn") || page.equalsIgnoreCase("PaymentOut") || page.equalsIgnoreCase("Registration"))
            Assert.assertEquals("PASS", Constants.key.exist(vObjStatusValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatusValue, Status));
        LogCapture.info("Initial Status on page observed and validated is" + Status);
    }

    @Then("^Check that the Initial Status (is not|) wiped out after clearing the PaymentIn Transaction$")
    public void checkThatTheInitialStatusIsNotWipedOutAfterClearingThePaymentInTransaction(String option) throws Exception {

        String vObjStatusValue = Constants.AtlasRegistrationOR.getProperty("InitialStatusValue");
        if (option.equalsIgnoreCase("is not")) {
            Assert.assertEquals("PASS", Constants.key.exist(vObjStatusValue, ""));
            LogCapture.info("Initial Status on page observed and is not wiped out after clearing the PaymentIn Transaction");
        }
    }

    @And("^User clicks on Organization dropdown and selects the organization as \"([^\"]*)\"$")
    public void userClicksOnOrganizationDropdownAndSelectsTheOrganizationAs(String Org) throws Throwable {
        String vObjOrgDropDown = Constants.AtlasPaymentOutOR.getProperty("OrganizationDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vObjOrgDropDown, ""));
        String vObjOrgValue = "";

        if (Org.equalsIgnoreCase("CD")) {
            vObjOrgValue = Constants.AtlasPaymentOutOR.getProperty("CD_OrgValue");
        } else if (Org.equalsIgnoreCase("FCG")) {
            vObjOrgValue = Constants.AtlasPaymentOutOR.getProperty("FCG_OrgValue");
        } else if (Org.equalsIgnoreCase("TORFX")) {
            vObjOrgValue = Constants.AtlasPaymentOutOR.getProperty("TorFX_OrgValue");
        } else if (Org.equalsIgnoreCase("TORAU")) {
            vObjOrgValue = Constants.AtlasPaymentOutOR.getProperty("TorAU_OrgValue");
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjOrgValue, ""));
        LogCapture.info(Org + " is selected as oragnization from dropdown");
    }

    @Then("^User validates that Reference Check Option exists on the Payment Out Page$")
    public void userValidatesThatReferenceCheckOptionExistsOnThePaymentOutPage() throws Exception {
        LogCapture.info("Validating if the reference check option exists on the page");
        String vObjReferenceCheck = Constants.AtlasPaymentOutOR.getProperty("ReferenceCheck");
        Assert.assertEquals("PASS", Constants.key.exist(vObjReferenceCheck, ""));
    }

    @Then("^User clicks on Reference Check Option and validates if Repeat Check button is enabled$")
    public void userClicksOnReferenceCheckOptionAndValidatesIfRepeatCheckButtonIsEnabled() throws Exception {
        LogCapture.info("Validating if the repeat check button is enabled");
        String vObjReferenceCheck = Constants.AtlasPaymentOutOR.getProperty("ReferenceCheck");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReferenceCheck, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjReferenceCheck, ""));
        Constants.key.pause("2", "");
        String vObjRepeatCheckBtn = Constants.AtlasPaymentOutOR.getProperty("RepeatcheckBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjRepeatCheckBtn, "enabled"));

    }

    @Then("^User clicks on Reference Check Option and validates the Reference Check status is (Failed|Passed)$")
    public void userClicksOnReferenceCheckOptionAndValidatesTheReferenceCheckStatusIsFailed(String status) throws Exception {
        LogCapture.info("Validating the Reference Check status");
        String vObjReferenceCheck = Constants.AtlasPaymentOutOR.getProperty("ReferenceCheck");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReferenceCheck, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjReferenceCheck, ""));
        Constants.key.pause("2", "");
        if (status.equalsIgnoreCase("Failed")) {
            String vObjReferenceCheckFail = Constants.AtlasPaymentOutOR.getProperty("ReferenceStatusFail");
            Assert.assertEquals("PASS", Constants.key.exist(vObjReferenceCheckFail, ""));
        } else if (status.equalsIgnoreCase("Passed")) {
            String vObjReferenceCheckPass = Constants.AtlasPaymentOutOR.getProperty("ReferenceStatusPass");
            Assert.assertEquals("PASS", Constants.key.exist(vObjReferenceCheckPass, ""));
        }

    }

    @And("^User validates successful message for Repeat Check for Reference Check on Payment Out$")
    public void userValidatesSuccessfulMessageForRepeatCheckForReferenceCheckOnPaymentOut() throws Exception {

        String vReferenceRepeatCheckSuccess = Constants.AtlasPaymentOutOR.getProperty("ReferenceRepeatCheckSuccess");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vReferenceRepeatCheckSuccess, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vReferenceRepeatCheckSuccess, "Payment Reference Repeat Check Successfully done"));

    }

    @And("^User clicks on Repeat Check for Reference Check on Payment Out$")
    public void userClicksOnRepeatCheckForReferenceCheckOnPaymentOut() throws Exception {

        String vReferenceRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("RepeatcheckBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vReferenceRepeatCheck, ""));

        if (Constants.driver.findElement(By.xpath(vReferenceRepeatCheck)).isEnabled()) {
            LogCapture.info("Repeat Check button is Enabled");
            Assert.assertEquals("PASS", Constants.key.click(vReferenceRepeatCheck, ""));
            Constants.key.pause("3", "");
        } else {
            LogCapture.info("Repeat Check button is Disabled");
            Assert.fail();
        }
    }

    @And("^User observes Repeat Check for Reference Check on Payment Out is enabled$")
    public void userObservesRepeatCheckForReferenceCheckOnPaymentOutIsEnabled() throws Exception {

        String vReferenceCheck = Constants.AtlasPaymentOutOR.getProperty("ReferenceCheck");
        String vReferenceRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("RepeatcheckBtn");

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vReferenceCheck, ""));
        Assert.assertEquals("PASS", Constants.key.click(vReferenceCheck, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vReferenceRepeatCheck, ""));
        //System.out.println(Constants.driver.findElement(By.xpath(vReferenceRepeatCheck)).getText());
        if (Constants.driver.findElement(By.xpath(vReferenceRepeatCheck)).isEnabled()) {
            LogCapture.info("Repeat Check button is Enabled");
        } else {
            LogCapture.info("Repeat Check button is Disabled");
            Assert.fail();
        }
    }

    @Then("^User clicks on Reference Check Option and validates if it is visible$")
    public void userClicksOnReferenceCheckOptionAndValidatesIfItIsVisible() throws Exception {
        LogCapture.info("Validating if Reference Check is visible");
        String vObjReferenceCheck = Constants.AtlasPaymentOutOR.getProperty("ReferenceCheck");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReferenceCheck, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjReferenceCheck, ""));
        Constants.key.pause("2", "");
    }


    @And("^User clicks on the Dropdown option for selecting Watchlists$")
    public void userClicksOnTheDropdownOptionForSelectingWatchlists() throws Exception {
        LogCapture.info("User is clicking on the Dropdown for Watchlists...");
        String vClickDropdownWatclists = Constants.AtlasRegistrationOR.getProperty("clickDropdownWatchlists");
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.click(vClickDropdownWatclists, ""));
    }

    @And("^User clicks on the search box and adds the Watchlist \"([^\"]*)\" that needs to be added$")
    public void userClicksOnTheSearchBoxAndAddsTheWatchlistThatNeedsToBeAdded(String addWatchlists) throws Throwable {
        LogCapture.info("User is clicking on the search box for Watchlists...");
        String vSearchBoxWatclists = Constants.AtlasRegistrationOR.getProperty("searchBoxWatchlists");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vSearchBoxWatclists, ""));
        LogCapture.info("User is adding the Watchlist that needs to be added in the search box...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSearchBoxWatclists, addWatchlists));
    }

    @And("^User clicks on the result generated for Watchlists$")
    public void userClicksOnTheResultGeneratedForWatchlists() throws Exception {
        LogCapture.info("User clicks on the result generated...");
        String vResult = Constants.AtlasRegistrationOR.getProperty("result");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vResult, ""));
    }

    @And("^User add Comments \"([^\"]*)\" and apply the changes$")
    public void userAddCommentsAndApplyTheChanges(String comments) throws Throwable {
        LogCapture.info("User is adding comments...");
        String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, comments));
        LogCapture.info("User is clicking on Apply...");
        String vApplyButton = Constants.AtlasRegistrationOR.getProperty("Apply");
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));
    }

    @And("^User validates the Success Message after adding Watchlists$")
    public void userValidatesTheSuccessMessageAfterAddingWatchlists() throws Exception {
        LogCapture.info("User is validating the Update...");
        String vUpdateResult = Constants.AtlasRegistrationOR.getProperty("updateResult");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vUpdateResult, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vUpdateResult, "Updated successfully"));
        Constants.key.pause("2", "");
    }

    @And("^User validates a successful call is given to Intuition for this update$")
    public void userValidatesASuccessfulCallIsGivenToIntuitionForThisUpdate() throws Exception {
        LogCapture.info("User is validating that a successful call to Intuition has been made after the update...");
        String vIntuitionTab = Constants.AtlasRegistrationOR.getProperty("intuitionTab");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vIntuitionTab, ""));
        String vIntuitionStatus = Constants.AtlasRegistrationOR.getProperty("intuitionStatus");
        Assert.assertEquals("PASS", Constants.key.verifyText(vIntuitionStatus, "check"));
        Constants.key.pause("4", "");
        LogCapture.info("User validated a successful call to Intuition has been made after the update...");

    }

    @Then("^User clicks on Intuition check$")
    public void userClicksOnIntuitionCheck() throws Exception {
        LogCapture.info("Validating if Intuition check is getting clicked ");
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vobjIntutiontab = Constants.AtlasRegistrationOR.getProperty("Intutiontab");
        Assert.assertEquals("PASS", Constants.key.click(vobjIntutiontab, ""));
        Constants.key.pause("2", "");
    }

    @And("^check if successful call to Intuition from atlas is been made$")
    public void checkIfSuccessfulCallToIntuitionFromAtlasIsBeenMade() throws Exception {
        LogCapture.info("Validating if Intuition call is been made for Registration");
        String vObjIntuitionStatusCall = Constants.AtlasRegistrationOR.getProperty("IntuitionStatusCall");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIntuitionStatusCall, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjIntuitionStatusCall, ""));
        Constants.key.pause("2", "");
    }

    @Then("^Registration \"([^\"]*)\" to be Observed as INACTIVE or ACTIVE$")
    public void registrationToBeObservedAsINACTIVEOrACTIVE(String Status) throws Throwable {
        String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
        if (Status.equalsIgnoreCase("INACTIVE")) {
            LogCapture.info("Validating user is INACTIVE");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));

        } else if (Status.equalsIgnoreCase("ACTIVE")) {
            LogCapture.info("Validating user is ACTIVE");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));
        }
    }

    @And("^User apply blacklist failed filter$")
    public void userApplyBlacklistFailedFilter() throws Exception {
        LogCapture.info("Validating if Intuition call is been made for Registration");
        String vObjBlacklistCheckFail = Constants.AtlasRegistrationOR.getProperty("BlacklistCheckFail");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlacklistCheckFail, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistCheckFail, ""));
        Constants.key.pause("2", "");

    }


    @And("^User clicks on the Dropdown option for selecting paymentmethod$")
    public void userClicksOnTheDropdownOptionForSelectingPaymentmethod() throws Exception {
        String vMain = Constants.AtlasPaymentInOR.getProperty("Atlas_main_drop");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vMain, " "));
        Constants.key.pause("2", "");
    }

    @And("^User clicks on the search box and adds the paymentmethod\"([^\"]*)\"$")
    public void userClicksOnTheSearchBoxAndAddsThePaymentmethod(String payment_method) throws Throwable {
        String vSearch = Constants.AtlasPaymentInOR.getProperty("Atlas_searchbox");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSearch, payment_method));
        Constants.key.pause("3", "");


    }

    @And("^User clicks on the result generated for Payment method (Wallet|Card|Bank|RETURN_OF_FUNDS|)$")
    public void userClicksOnTheResultGeneratedForPaymentMethod(String resultgeneration) throws Exception {
        if (resultgeneration.equalsIgnoreCase("Wallet")) {
            String Vwalletgen = Constants.AtlasPaymentInOR.getProperty("Atlas_drop_wallet");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(Vwalletgen, " "));
            Constants.key.pause("2", "");
            LogCapture.info("click on result generated is wallet.... ");
        } else if (resultgeneration.equalsIgnoreCase("Card")) {
            String vcardgen = Constants.AtlasPaymentInOR.getProperty("Atlas_drop_card");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vcardgen, " "));
            Constants.key.pause("5", "");
            LogCapture.info("click on result generated is card.... ");
        } else if (resultgeneration.equalsIgnoreCase("Bank")) {
            String Vbankgen = Constants.AtlasPaymentInOR.getProperty("Atlas_drop_Bank");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(Vbankgen, " "));
            Constants.key.pause("5", "");
            LogCapture.info("click on result generated is bank... ");
        } else if (resultgeneration.equalsIgnoreCase("RETURN_OF_FUNDS")) {
            String vrofgen = Constants.AtlasPaymentInOR.getProperty("Atlas_drop_ROF");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vrofgen, " "));
            Constants.key.pause("5", "");
            LogCapture.info("click on result generated is RETURN_OF_FUNDS .... ");
        }

    }

    @And("^User clicks on the Dropdown option for selecting paymentmethods$")
    public void userClicksOnTheDropdownOptionForSelectingPaymentmethods() throws Exception {
        String vDrop_close = Constants.AtlasPaymentInOR.getProperty("Atlas_main_drop");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vDrop_close, " "));
        Constants.key.pause("2", "");
    }

    @Then("^User validates Org Wallet Funding Reason for Payment Method (Wallet|Card|Bank|RETURN_OF_FUNDS|)$")
    public void userValidatesOrgWalletFundingReasonForPaymentMethodWallet(String paymentMethod) throws Exception {

        if (paymentMethod.equalsIgnoreCase("Wallet")) {
            String paymentmeth = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentmethod");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(paymentmeth, "WALLET"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            String vAtlas_reg = AtlasPaymentInOR.getProperty("Atlas_Funding_reson");
            if (Constants.driver.findElement(By.xpath(vAtlas_reg)).getText().contains("RETURN_OF_FUNDS")) {
                LogCapture.info("ORG wallet funding reasons is RETURN_OF_FUNDS for payment method wallet....");

            } else if (Constants.driver.findElement(By.xpath(vAtlas_reg)).getText().contains("DIRECT_DEBIT_REJECTION")) {
                LogCapture.info("ORG wallet funding reasons is DIRECT_DEBIT_REJECTION for payment method wallet....");
            } else if (Constants.driver.findElement(By.xpath(vAtlas_reg)).getText().contains("COMPENSATION")) {
                LogCapture.info("ORG wallet funding reasons is COMPENSATION for payment method wallet....");
            } else if (Constants.driver.findElement(By.xpath(vAtlas_reg)).getText().contains("CHARGE_BACK")) {
                LogCapture.info("ORG wallet funding reasons is CHARGE_BACK for payment method wallet.");
            } else if (Constants.driver.findElement(By.xpath(vAtlas_reg)).getText().contains("WRITE_OFF")) {
                LogCapture.info("ORG wallet funding reasons is WRITE_OFF for payment method wallet.");
            } else if (Constants.driver.findElement(By.xpath(vAtlas_reg)).getText().contains("OTHER_ADJUSTMENT")) {
                LogCapture.info("ORG wallet funding reasons is OTHER_ADJUSTMENT for payment method wallet.");

            }
        } else if (paymentMethod.equalsIgnoreCase("Card")) {
            String Vcard = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentmethodcard");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(Vcard, "SWITCH/DEBIT"));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String Vpaymtrson = AtlasPaymentInOR.getProperty("Atlas_Funding_card");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(Vpaymtrson, "------"));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("ORG wallet funding reasons is blank for payment method card...");
        } else if (paymentMethod.equalsIgnoreCase("Bank")) {
            String Vbank = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentmethodbank");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(Vbank, "BACS/CHAPS/TT"));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String Vbanktrson = AtlasPaymentInOR.getProperty("Atlas_Funding_bank");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(Vbanktrson, "------"));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("ORG wallet funding reasons is blank for payment method bank....");
        } else if (paymentMethod.equalsIgnoreCase("RETURN_OF_FUNDS")) {
            String VROF = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentmethodROF");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(VROF, "RETURN_OF_FUNDS"));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String VROFrson = AtlasPaymentInOR.getProperty("Atlas_paymentmethodROFreson");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(VROFrson, "------"));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("ORG wallet funding reasons is blank for payment method RETURN_OF_FUNDS ....");
        }
    }

    @And("^User apply Sanctioned failed filter$")
    public void userApplySanctionedFailedFilter() throws Exception {
        LogCapture.info("Validating Sanctioned check is failed");
        String vObjSanctionedCheckFail = Constants.AtlasRegistrationOR.getProperty("SanctionedCheckFail");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionedCheckFail, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSanctionedCheckFail, ""));
        Constants.key.pause("2", "");

    }

    @And("^User checks no entry is been made for Intuition$")
    public void userChecksNoEntryIsBeenMadeForIntuition() throws Exception {
        LogCapture.info("Validating No entry of intuition is been made");
        String vObjNoEntryINIntuition = Constants.AtlasRegistrationOR.getProperty("NoEntryINIntuition");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNoEntryINIntuition, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNoEntryINIntuition, ""));
        Constants.key.pause("2", "");

    }


    @And("^User manually update Sanction check$")
    public void userManuallyUpdateSanctionCheck() throws Exception {
        LogCapture.info("User is clicking on the Sanction check Tab...");
        String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("Sanctions");
        Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));

        String vObjSanctionsOFAC = Constants.AtlasRegistrationOR.getProperty("SanctionsOFAC");
        String vObjSanctionsWorldCheck = Constants.AtlasRegistrationOR.getProperty("SanctionsWorldCheck");

        if (Constants.driver.findElement(By.xpath(vObjSanctionsOFAC)).getText().contains("Safe") && Constants.driver.findElement(By.xpath(vObjSanctionsWorldCheck)).getText().contains("Safe")) {
            LogCapture.info("User validated OFAC Check for Sanctions is Passed...");
            LogCapture.info("User is manually updating the OFAC check for Sanctions");

            String vSanctionField = Constants.AtlasRegistrationOR.getProperty("SanctionField");
            String vOFACField = Constants.AtlasRegistrationOR.getProperty("OFACField");
            String vApply = Constants.AtlasRegistrationOR.getProperty("SanctionsApply");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSanctionField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSanctionField, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vOFACField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vOFACField, ""));

            String vSetField = Constants.AtlasRegistrationOR.getProperty("SetField");
            String vConfirmedHitField = Constants.AtlasRegistrationOR.getProperty("ConfirmedHitField");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSetField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSetField, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vConfirmedHitField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vConfirmedHitField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vApply, ""));
            LogCapture.info("User has manually updated the OFAC check for Sanctions to Confirmed Hit");
        } else if (Constants.driver.findElement(By.xpath(vObjSanctionsOFAC)).getText().contains("Confirmed hit") || Constants.driver.findElement(By.xpath(vObjSanctionsOFAC)).getText().contains("Not Available")) {
            LogCapture.info("User validated OFAC Check for Sanctions has failed...");
            LogCapture.info("User is manually updating the OFAC check for Sanctions");

            String vSanctionField = Constants.AtlasRegistrationOR.getProperty("SanctionField");
            String vOFACField = Constants.AtlasRegistrationOR.getProperty("OFACField");
            String vApply = Constants.AtlasRegistrationOR.getProperty("SanctionsApply");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSanctionField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSanctionField, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vOFACField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vOFACField, ""));

            String vSetField = Constants.AtlasRegistrationOR.getProperty("SetField");
            String vSafeField = Constants.AtlasRegistrationOR.getProperty("SafeField");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSetField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSetField, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSafeField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSafeField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vApply, ""));
            LogCapture.info("User has manually updated the OFAC check for Sanctions to Safe");
        }
        if (Constants.driver.findElement(By.xpath(vObjSanctionsWorldCheck)).getText().contains("Confirmed hit") || Constants.driver.findElement(By.xpath(vObjSanctionsWorldCheck)).getText().contains("Not Available")) {
            LogCapture.info("User validated World Check for Sanctions has failed...");
            LogCapture.info("User is manually updating the World check for Sanctions");

            String vSanctionField = Constants.AtlasRegistrationOR.getProperty("SanctionField");
            String vWorldCheckField = Constants.AtlasRegistrationOR.getProperty("WorldCheckField");
            String vApply = Constants.AtlasRegistrationOR.getProperty("SanctionsApply");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSanctionField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSanctionField, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vWorldCheckField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vWorldCheckField, ""));

            String vSetField = Constants.AtlasRegistrationOR.getProperty("SetField");
            String vConfirmdHitField = Constants.AtlasRegistrationOR.getProperty("SafeField");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSetField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSetField, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vConfirmdHitField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vConfirmdHitField, ""));
            Assert.assertEquals("PASS", Constants.key.click(vApply, ""));
            LogCapture.info("User has manually updated the World check for Sanctions to Safe");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        }
    }


    @And("^Verify profile score and rule score in Intuition check for (PFX|CFX|CFX-Etailer)$")
    public void verifyProfileScoreAndRuleScoreInIntuitionCheck(String value) throws Exception {
        if (value.equalsIgnoreCase("PFX")) {
            LogCapture.info("User validated a profile score in intuition check ...");
            String vProfilescor = Constants.AtlasRegistrationOR.getProperty("Atlas_profilescore");
            Assert.assertEquals("PASS", Constants.key.verifyText(vProfilescor, "42"));
            LogCapture.info("User validated a rule score in intuition check ...");
            String vRulescor = Constants.AtlasRegistrationOR.getProperty("Atlas_rulescore");
            Assert.assertEquals("PASS", Constants.key.verifyText(vRulescor, "5"));

        } else if (value.equalsIgnoreCase("CFX")) {
            LogCapture.info("User validated a profile score in intuition check is blank ...");
            String vProfilesccfx = Constants.AtlasRegistrationOR.getProperty("Atlas_profilescfx");
            Assert.assertEquals("PASS", Constants.key.verifyText(vProfilesccfx, "-"));
            LogCapture.info("User validated a rule score in intuition check is value ...");
            String vRulescorcfx = Constants.AtlasRegistrationOR.getProperty("Atlas_rulescfx");
            Assert.assertEquals("PASS", Constants.key.verifyText(vRulescorcfx, "0"));

        } else if (value.equalsIgnoreCase("CFX-Etailer")) {
            LogCapture.info("User validated a profile score in intuition check is blank ...");
            String vProfilesccfxE = Constants.AtlasRegistrationOR.getProperty("Atlas_profilescfx");
            Assert.assertEquals("PASS", Constants.key.verifyText(vProfilesccfxE, "-"));
            LogCapture.info("User validated a rule score in intuition check is value ...");
            String vRulescorcfxE = Constants.AtlasRegistrationOR.getProperty("Atlas_rulescfx");
            Assert.assertEquals("PASS", Constants.key.verifyText(vRulescorcfxE, "25"));

        }
    }

    @Then("^User validates the Intuition Risk Level is blank(Registration|Payment In|Payment Out)$")
    public void userValidatesTheIntuitionRiskLevelIsBlank(String level) {
        if (level.equalsIgnoreCase("Registration")) {
            String vObjBlankRiskField = Constants.AtlasRegistrationOR.getProperty("BlankRiskField");
            Constants.driver.findElement(By.xpath(vObjBlankRiskField)).getText().contains("----");
            LogCapture.info("Validating intuition risk level is blank");
        } else if (level.equalsIgnoreCase("Payment In")) {
            String vObjBlankRiskField = Constants.AtlasRegistrationOR.getProperty("Blankfldpymtin");
            Constants.driver.findElement(By.xpath(vObjBlankRiskField)).getText().contains("----");
            LogCapture.info("Validating intuition risk level is blank");
        } else if (level.equalsIgnoreCase("Payment Out")) {
            String vObjBlankRiskField = Constants.AtlasRegistrationOR.getProperty("Blankfldpymtin");
            Constants.driver.findElement(By.xpath(vObjBlankRiskField)).getText().contains("----");
            LogCapture.info("Validating intuition risk level is blank");

        }
    }

    @Then("^User validates the Intuition Risk (Low|Medium|High|Extreme)$")
    public void userValidatesTheIntuitionRisk(String Value) throws Exception {
        String vObjRiskLevel = Constants.AtlasRegistrationOR.getProperty("RiskLevel");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRiskLevel, ""));
        Constants.key.pause("5", "");
        String E = Constants.driver.findElement(By.xpath(vObjRiskLevel)).getCssValue("background-color");
        String hexBackcolor = Color.fromString(E).asHex();
        if (Value.equalsIgnoreCase("Low")) {
            if (Constants.driver.findElement(By.xpath(vObjRiskLevel)).getText().contains("LOW")) {
                LogCapture.info("Validating Intuition Risk Level is Low");
                if (hexBackcolor.equals("#29873c")) {
                    LogCapture.info("User validated Intuition Risk Level background color is Green");
                } else LogCapture.info("User couldn't validate Intuition Risk Level background color is Green");
            }
        } else if (Value.equalsIgnoreCase("Medium")) {
            if (Constants.driver.findElement(By.xpath(vObjRiskLevel)).getText().contains("MEDIUM")) {
                LogCapture.info("Validating Intuition Risk Level is Medium");
                if (hexBackcolor.equals("#f39414")) {
                    LogCapture.info("User validated Intuition Risk Level background color is Yellow");
                } else LogCapture.info("User couldn't validate Intuition Risk Level background color is Yellow");
            }
        } else if (Value.equalsIgnoreCase("High")) {
            if (Constants.driver.findElement(By.xpath(vObjRiskLevel)).getText().contains("HIGH")) {
                LogCapture.info("Validating Intuition Risk Level is High");
                if (hexBackcolor.equals("#d55b5b")) {
                    LogCapture.info("User validated Intuition Risk Level background color is Red");
                } else LogCapture.info("User couldn't validate Intuition Risk Level background color is Red");
            }
        } else if (Value.equalsIgnoreCase("Extreme")) {
            if (Constants.driver.findElement(By.xpath(vObjRiskLevel)).getText().contains("EXTREME")) {
                LogCapture.info("Validating Intuition Risk Level is Extreme");

                if (hexBackcolor.equals("#000000")) {
                    LogCapture.info("User validated Intuition Risk Level background color is Black");
                } else LogCapture.info("User couldn't validate Intuition Risk Level background color is Black");
            }
        }
    }


    @Then("^User validates AVS Result for Payment method (Wallet|Card|)$")
    public void userValidatesAVSResultForPaymentMethodCard(String PaymentMethods) throws Exception {
        if (PaymentMethods.equalsIgnoreCase("Card")) {
            String paymentmeth = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentmethod");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(paymentmeth, "SWITCH/DEBIT"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            String Vpaymtcard = AtlasPaymentInOR.getProperty("AtlasAVS_Result");
            if (Constants.driver.findElement(By.xpath(Vpaymtcard)).getText().contains("UNKNOWN")) {
                LogCapture.info("ORG wallet funding reasons is UNKNOWN for payment method wallet....");
            } else if (Constants.driver.findElement(By.xpath(Vpaymtcard)).getText().contains("PARTIAL APPROVED (Postcode matched; address not matched)")) {
                LogCapture.info("AVS result  is shows PARTIAL APPROVED (Postcode matched; address not matched) with discription ....");
            } else if (Constants.driver.findElement(By.xpath(Vpaymtcard)).getText().contains("APPROVED (Postcode and address matched)")) {
                LogCapture.info("AVS result  is shows APPROVED (Postcode and address matched) with discription ....");
            }

        } else if (PaymentMethods.equalsIgnoreCase("Wallet")) {
            String Vcard = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentmethod");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(Vcard, "WALLET"));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String Vpaymtrso = AtlasPaymentInOR.getProperty("AtlasAVSblank_result");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(Vpaymtrso, "------"));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("AVS result is Blank for payment method card ....");
        }
    }

    @Then("^User Observes the CVC/CVV Result field$")
    public void userObservesTheCVCCVVResultField() throws Exception {
        String vObjCVCCVVField = Constants.AtlasPaymentInOR.getProperty("CVC/CVV");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCVCCVVField, "NOT SUPPLIED (NOT SUPPLIED BY SHOPPER)"));
        LogCapture.info("Validating CVC/CVV results is displaying:'NOT SUPPLIED (NOT SUPPLIED BY SHOPPER)'");

    }

    @Then("^User Observes the CVC/CVV Result field is blank$")
    public void userObservesTheCVCCVVResultFieldIsBlank() throws Exception {
        String vObjCVCCVVField = Constants.AtlasPaymentInOR.getProperty("CVC/CVV");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCVCCVVField, "------"));
        LogCapture.info("Validating CVC/CVV results is blank");

    }

    @Then("^User clicks on (blacklist|Custom|Sanctions|BlacklistBeneficiary|Reference|CustomCheck|SanContact|SanBeneficiary|SanBank|FraudPredict) checks tab and perform Repeat check$")

    public void userClicksOnBlacklistChecksTabAndPerformRepeatCheck(String Checks) throws Exception {
        if (Checks.equalsIgnoreCase("Blacklist")) {
            String vObjBlacklistTab = AtlasPaymentInOR.getProperty("BlacklistTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistTab, ""));
            LogCapture.info("User is clicking on Blacklist check");

            String vObjBlacklistRepeatCheckButton = AtlasPaymentInOR.getProperty("BlacklistRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vBlackistRepeatcheck = AtlasPaymentInOR.getProperty("BlacklistRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlackistRepeatcheck, "Blacklist Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("Custom")) {
            String vObjCustomTab = AtlasPaymentInOR.getProperty("CustomTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomTab, ""));
            LogCapture.info("User is clicking on Custom check");

            String vObjCustomRepeatCheckButton = AtlasPaymentInOR.getProperty("CustomRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vCustomRepeatcheck = AtlasPaymentInOR.getProperty("CustomRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCustomRepeatcheck, "Custom Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("Sanctions")) {
            String vObjSanctionsTab = AtlasPaymentInOR.getProperty("SanctionsTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsTab, ""));
            LogCapture.info("User is clicking on Sanction check");

            String vObjSanctionRepeatCheckButton = AtlasPaymentInOR.getProperty("SanctionRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("7", ""));
            String vSanctionRepeatcheck = AtlasPaymentInOR.getProperty("SanctionRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionRepeatcheck, "Sanction Repeat Check Successfully done"));

        } else if (Checks.equalsIgnoreCase("BlacklistBeneficiary")) {
            String vObjBlackChecklistTab = AtlasPaymentOutOR.getProperty("BlacklistBeneficiary");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlackChecklistTab, ""));
            LogCapture.info("User is clicking on Blacklist check");

            String vObjBlacklistCheckRepeatCheckButton = AtlasPaymentOutOR.getProperty("BlacklistBeneficiaryRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistCheckRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vBlacklistBeneficiaryMSG = AtlasPaymentOutOR.getProperty("BlacklistBeneficiaryRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlacklistBeneficiaryMSG, "Blacklist Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("SanContact")) {
            String vObjSanBeneficiaryTab = AtlasPaymentOutOR.getProperty("SanContactTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBeneficiaryTab, ""));
            LogCapture.info("User is clicking on SanContact check");

            String vObjSanContactRepeatCheckButton = AtlasPaymentOutOR.getProperty("SanContactRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanContactRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vSanContactCheckRepeatcheck = AtlasPaymentOutOR.getProperty("SanContactRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanContactCheckRepeatcheck, "Sanction Repeat Check Successfully done for contact"));
        } else if (Checks.equalsIgnoreCase("SanBeneficiary")) {
            String vObjSanBeneficiaryTab = AtlasPaymentOutOR.getProperty("SanBeneficiaryTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBeneficiaryTab, ""));
            LogCapture.info("User is clicking on SanBeneficiary check");

            String vObjSanBeneficiaryRepeatCheckButton = AtlasPaymentOutOR.getProperty("SanBeneficiaryRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBeneficiaryRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vBlackistCheckRepeatcheck = AtlasPaymentOutOR.getProperty("SanBeneficiaryRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlackistCheckRepeatcheck, "Sanction Repeat Check Successfully done for beneficiary"));
        } else if (Checks.equalsIgnoreCase("SanBank")) {
            String vObjSanBankTab = AtlasPaymentOutOR.getProperty("SanBankTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBankTab, ""));
            LogCapture.info("User is clicking on SanBank check");

            String vObjSanBankRepeatCheckButton = AtlasPaymentOutOR.getProperty("SanBankRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBankRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vSanBankRepeatCheckSuccessMSG = AtlasPaymentOutOR.getProperty("SanBankRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanBankRepeatCheckSuccessMSG, "Sanction Repeat Check Successfully done for bank"));
        } else if (Checks.equalsIgnoreCase("FraudPredict")) {
            String vObjFraudPredictTab = AtlasPaymentOutOR.getProperty("FraudPredictTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjFraudPredictTab, ""));
            LogCapture.info("User is clicking on SanBank check");

            String vObjFraudPredictRepeatCheckButton = AtlasPaymentOutOR.getProperty("FraudPredictRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjFraudPredictRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vFraudPredictRepeatCheckSuccessMSG = AtlasPaymentOutOR.getProperty("FraudPredictRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFraudPredictRepeatCheckSuccessMSG, "Fraugster Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("Reference")) {
            String vObjReferenceTab = AtlasPaymentOutOR.getProperty("ReferenceTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjReferenceTab, ""));
            LogCapture.info("User is clicking on ReferenceTab check");

            String vObjReferenceRepeatCheckButton = AtlasPaymentOutOR.getProperty("ReferenceRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjReferenceRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vReferenceRepeatCheckSuccessMSG = AtlasPaymentOutOR.getProperty("ReferenceRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vReferenceRepeatCheckSuccessMSG, "Payment Reference Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("CustomCheck")) {
            String vObjCustomCheckTab = AtlasPaymentOutOR.getProperty("CustomCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomCheckTab, ""));
            LogCapture.info("User is clicking on CustomCheck");

            String vObjCustomCheckRepeatCheckButton = AtlasPaymentOutOR.getProperty("CustomCheckRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomCheckRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vCustomCheckRepeatCheckSuccessMSG = AtlasPaymentOutOR.getProperty("CustomCheckRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCustomCheckRepeatCheckSuccessMSG, "Custom repeat check Successfully done"));
        }
    }

    @Then("^User manually update Sanction check for PaymentIn$")
    public void userManuallyUpdateSanctionCheckForPaymentIn() throws Exception {

        LogCapture.info("User is clicking on the Sanction check Tab...");
        String vObjSanctions = AtlasPaymentInOR.getProperty("Sanctions");
        Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        String vObjStatus = AtlasPaymentInOR.getProperty("SanctionsStatus");
        if (Constants.driver.findElement(By.xpath(vObjStatus)).getText().contains("Not Required")) {
            LogCapture.info("Sanction Check not required");
        } else {
            String vObjSanctiondropdown1 = Constants.AtlasPaymentInOR.getProperty("Sanctiondropdown1");
            String vObjSanctiondropdown2 = Constants.AtlasPaymentInOR.getProperty("Sanctiondropdown2");
            String vObjSafe = Constants.AtlasPaymentInOR.getProperty("Safe");
            String vObjOFACStatus = AtlasPaymentInOR.getProperty("OFACStatus");
            if (Constants.driver.findElement(By.xpath(vObjOFACStatus)).getText().contains("Safe")) {
                LogCapture.info("OFAC field is already safe");
            } else {
                LogCapture.info("User is clicking on the dropdown button for selecting field");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctiondropdown1, ""));

                LogCapture.info("User is clicking on OFAC field");
                String vObjSanctionsOFAC = Constants.AtlasPaymentInOR.getProperty("SanctionsOFAC");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsOFAC, ""));

                Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                LogCapture.info("User is clicking on the dropdown button for setting field");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctiondropdown2, ""));

                Assert.assertEquals("PASS", Constants.key.click(vObjSafe, ""));
                String vObjSanctionApplyButton = Constants.AtlasPaymentInOR.getProperty("SanctionApplyButton");
                LogCapture.info("User is clicking on Apply button ");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctionApplyButton, ""));

            }

            String vObjWorldcheckstatus = AtlasPaymentInOR.getProperty("Worldcheckstatus");
            if (Constants.driver.findElement(By.xpath(vObjWorldcheckstatus)).getText().contains("Safe")) {
                LogCapture.info("Worldcheck field is already safe");
            } else {
                LogCapture.info("User is clicking on worldcheck field");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctiondropdown1, ""));
                String vObjSanctionsWorldCheck = Constants.AtlasPaymentInOR.getProperty("SanctionsWorldCheck");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsWorldCheck, ""));
                Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                LogCapture.info("User is clicking on the dropdown button for setting field");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctiondropdown2, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjSafe, ""));

                String vObjSanctionApplyButton = Constants.AtlasPaymentInOR.getProperty("SanctionApplyButton");
                LogCapture.info("User is clicking on Apply button ");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctionApplyButton, ""));

                Assert.assertEquals("PASS", Constants.key.pause("10", ""));
                String vSuccessMSG = AtlasPaymentInOR.getProperty("Sanctionupdationsuccessmsg");
                Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMSG, "Updatin sanction Successfully done"));
            }

            LogCapture.info("Sanction for this user is safe");
        }
    }

    @Then("^User clicks on the search box and adds the Watchlist \"([^\"]*)\" that needs to be added for PaymentIn$")
    public void userClicksOnTheSearchBoxAndAddsTheWatchlistThatNeedsToBeAddedForPaymentIn(String Watchlists) throws Throwable {
        LogCapture.info("User is clicking on the search box for Watchlists...");
        String Vsearchwatchlist = Constants.AtlasPaymentInOR.getProperty("searchBoxWatchlistdropdown");
        Assert.assertEquals("PASS", Constants.key.click(Vsearchwatchlist, ""));

        String Vsearchlist = Constants.AtlasPaymentInOR.getProperty("searchlist");
        LogCapture.info("User is adding the Watchlist that needs to be added in the search box...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(Vsearchlist, Watchlists));
        Assert.assertEquals("PASS", Constants.key.click(Vsearchwatchlist, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
    }

    @Then("^User validates watchlist is been successfully updated$")
    public void userValidatesWatchlistIsBeenSuccessfullyUpdated() throws Exception {
        LogCapture.info("User validating watchlist is been updated successfully updated");
        String vSuccessMSG = AtlasPaymentInOR.getProperty("WatchlistupdationMSG");
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMSG, "Updated successfully"));
    }

    @Then("^User validates for PaymentIn a successful call is given to Intuition for this update$")
    public void userValidatesForPaymentInASuccessfulCallIsGivenToIntuitionForThisUpdate(String Decision) throws Exception {
        LogCapture.info("User is validating that a successful call to Intuition has been made after the update...");
        String vIntuitionTab = Constants.AtlasPaymentInOR.getProperty("intuitionTab");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vIntuitionTab, ""));

        String vIntuitionStatus = Constants.AtlasPaymentInOR.getProperty("IntuitionDecision");
        Assert.assertEquals("PASS", Constants.key.verifyText(vIntuitionStatus, "Clean"));
        if (Decision.equalsIgnoreCase("Clean")) {
            LogCapture.info("successful call to Intuition has been made after the update...");
        } else {
            LogCapture.info("call to Intuition has been failed...");
        }

    }

    @Then("^User updates status tobe clear$")
    public void userUpdatesStatusTobeClear() throws Exception {
        LogCapture.info("User upadating status tobe clear");
        String vstatusClear = Constants.AtlasPaymentOutOR.getProperty("statusClear");
        Assert.assertEquals("PASS", Constants.key.click(vstatusClear, ""));

    }

    //
    @Then("^User manually update (Sanction Contact|Sanction Beneficiary|Sanction Bank) for PaymentOut$")
    public void userManuallyUpdateSanctionContactForPaymentOut(String Sanction) throws Exception {
        if (Sanction.equalsIgnoreCase("Sanction Contact")) {
            LogCapture.info("User is clicking on the Sanction check Tab...");
            String vObjSanctionsContact = Constants.AtlasPaymentOutOR.getProperty("SanctionsContact");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsContact, ""));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vObjSanctionContactStatus = Constants.AtlasPaymentOutOR.getProperty("SanctionContactStatus");
            if (Constants.driver.findElement(By.xpath(vObjSanctionContactStatus)).getText().contains("Not Required")) {
                LogCapture.info("Sanction Conatct Check not required");
            } else {
                String vObjSCDropdown1 = Constants.AtlasPaymentOutOR.getProperty("SCDropdown1");
                String vObjSCDropdown2 = Constants.AtlasPaymentOutOR.getProperty("SCDropdown2");
                String vObjSCSafe = Constants.AtlasPaymentOutOR.getProperty("SCSafe");
                String vObjSCOFACStatus = Constants.AtlasPaymentOutOR.getProperty("SCOFACStatus");

                if (Constants.driver.findElement(By.xpath(vObjSCOFACStatus)).getText().contains("Safe")) {
                    LogCapture.info("OFAC field is already safe");
                } else {
                    LogCapture.info("User is clicking on the dropdown button for selecting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCDropdown1, ""));

                    LogCapture.info("User is clicking on OFAC field");
                    String vObjSCOFACField = Constants.AtlasPaymentOutOR.getProperty("SCOFACField");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCOFACField, ""));

                    Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                    LogCapture.info("User is clicking on the dropdown button for setting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCDropdown2, ""));

                    Assert.assertEquals("PASS", Constants.key.click(vObjSCSafe, ""));
                    String vObjSCApply = Constants.AtlasPaymentOutOR.getProperty("SCApply");
                    LogCapture.info("User is clicking on Apply button ");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCApply, ""));

                }

                String vObjSCWCStatus = Constants.AtlasPaymentOutOR.getProperty("SCWCStatus");
                if (Constants.driver.findElement(By.xpath(vObjSCWCStatus)).getText().contains("Safe")) {
                    LogCapture.info("Worldcheck field is already safe");
                } else {
                    LogCapture.info("User is clicking on worldcheck field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCDropdown1, ""));
                    String vObjSCWorldCheckField = Constants.AtlasPaymentOutOR.getProperty("SCWorldCheckField");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCWorldCheckField, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                    LogCapture.info("User is clicking on the dropdown button for setting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCDropdown2, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCSafe, ""));

                    String vObjSCApply = Constants.AtlasPaymentOutOR.getProperty("SCApply");
                    LogCapture.info("User is clicking on Apply button ");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCApply, ""));

                    Assert.assertEquals("PASS", Constants.key.pause("10", ""));
                    String vSCsuccessMsg = AtlasPaymentOutOR.getProperty("SCsuccessMsg");
                    Assert.assertEquals("PASS", Constants.key.verifyText(vSCsuccessMsg, "Sanction update Successfully done for contact"));
                }

                LogCapture.info("Sanction for this user is safe");
            }
        } else if (Sanction.equalsIgnoreCase("Sanction Beneficiary")) {
            LogCapture.info("User is clicking on the Sanction Beneficiary Tab...");
            String vObjSanctionsBeneficiary = Constants.AtlasPaymentOutOR.getProperty("SanctionsBeneficiary");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsBeneficiary, ""));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vObjSanctionBeneficiaryStatus = Constants.AtlasPaymentOutOR.getProperty("SanctionBeneficiaryStatus");
            if (Constants.driver.findElement(By.xpath(vObjSanctionBeneficiaryStatus)).getText().contains("Not Required")) {
                LogCapture.info("Sanction Beneficiary Check not required");
            } else {
                String vObjSBDropdown1 = Constants.AtlasPaymentOutOR.getProperty("SBDropdown1");
                String vObjSBDropdown2 = Constants.AtlasPaymentOutOR.getProperty("SBDropdown2");
                String vObjSBSafe = Constants.AtlasPaymentOutOR.getProperty("SBSafe");
                String vObjSBOFACStatus = Constants.AtlasPaymentOutOR.getProperty("SBOFACStatus");

                if (Constants.driver.findElement(By.xpath(vObjSBOFACStatus)).getText().contains("Safe")) {
                    LogCapture.info("OFAC field is already safe");
                } else {
                    LogCapture.info("User is clicking on the dropdown button for selecting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBDropdown1, ""));

                    LogCapture.info("User is clicking on OFAC field");
                    String vObjSBOFACField = Constants.AtlasPaymentOutOR.getProperty("SBOFACField");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBOFACField, ""));

                    Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                    LogCapture.info("User is clicking on the dropdown button for setting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBDropdown2, ""));

                    Assert.assertEquals("PASS", Constants.key.click(vObjSBSafe, ""));
                    String vObjSCApply = Constants.AtlasPaymentOutOR.getProperty("SCApply");
                    LogCapture.info("User is clicking on Apply button ");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSCApply, ""));

                }

                String vObjSBWCStatus = Constants.AtlasPaymentOutOR.getProperty("SBWCStatus");
                if (Constants.driver.findElement(By.xpath(vObjSBWCStatus)).getText().contains("Safe")) {
                    LogCapture.info("Worldcheck field is already safe");
                } else {
                    LogCapture.info("User is clicking on worldcheck field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBDropdown1, ""));
                    String vObjSBWorldCheckField = Constants.AtlasPaymentOutOR.getProperty("SBWorldCheckField");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBWorldCheckField, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                    LogCapture.info("User is clicking on the dropdown button for setting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBDropdown2, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBSafe, ""));

                    String vObjSBApply = Constants.AtlasPaymentOutOR.getProperty("SBApply");
                    LogCapture.info("User is clicking on Apply button ");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBApply, ""));

                    Assert.assertEquals("PASS", Constants.key.pause("10", ""));
                    String vSBsuccessMsg = AtlasPaymentOutOR.getProperty("SBsuccessMsg");
                    Assert.assertEquals("PASS", Constants.key.verifyText(vSBsuccessMsg, "Sanction update Successfully done for beneficiary"));
                }

                LogCapture.info("Sanction for this user is safe");
            }
        } else if (Sanction.equalsIgnoreCase("Sanction Bank")) {
            LogCapture.info("User is clicking on the Sanction Bank check Tab...");
            String vObjSanctionsBank = Constants.AtlasPaymentOutOR.getProperty("SanctionsBank");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsBank, ""));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vObjSanctionBankStatus = Constants.AtlasPaymentOutOR.getProperty("SanctionBankStatus");
            if (Constants.driver.findElement(By.xpath(vObjSanctionBankStatus)).getText().contains("Not Required")) {
                LogCapture.info("Sanction Bank Check not required");
            } else {
                String vObjSBankDropdown1 = Constants.AtlasPaymentOutOR.getProperty("SBankDropdown1");
                String vObjSBankDropdown2 = Constants.AtlasPaymentOutOR.getProperty("SBankDropdown2");
                String vObjSBankSafe = Constants.AtlasPaymentOutOR.getProperty("SBankSafe");
                String vObjSBankOFACStatus = Constants.AtlasPaymentOutOR.getProperty("SBankOFACStatus");

                if (Constants.driver.findElement(By.xpath(vObjSBankOFACStatus)).getText().contains("Safe")) {
                    LogCapture.info("OFAC field is already safe");
                } else {
                    LogCapture.info("User is clicking on the dropdown button for selecting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankDropdown1, ""));

                    LogCapture.info("User is clicking on OFAC field");
                    String vObjSBankOFACField = Constants.AtlasPaymentOutOR.getProperty("SBankOFACField");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankOFACField, ""));

                    Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                    LogCapture.info("User is clicking on the dropdown button for setting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankDropdown2, ""));

                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankSafe, ""));
                    String vObjSBankApply = Constants.AtlasPaymentOutOR.getProperty("SBankApply");
                    LogCapture.info("User is clicking on Apply button ");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankApply, ""));

                }

                String vObjSBankWCStatus = Constants.AtlasPaymentOutOR.getProperty("SBankWCStatus");
                if (Constants.driver.findElement(By.xpath(vObjSBankWCStatus)).getText().contains("Safe")) {
                    LogCapture.info("Worldcheck field is already safe");
                } else {
                    LogCapture.info("User is clicking on worldcheck field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankDropdown1, ""));
                    String vObjSBankWorldCheckField = Constants.AtlasPaymentOutOR.getProperty("SBankWorldCheckField");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankWorldCheckField, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                    LogCapture.info("User is clicking on the dropdown button for setting field");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankDropdown2, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankSafe, ""));

                    String vObjSBankApply = Constants.AtlasPaymentOutOR.getProperty("SBankApply");
                    LogCapture.info("User is clicking on Apply button ");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSBankApply, ""));

                    Assert.assertEquals("PASS", Constants.key.pause("10", ""));
                    String vSCsuccessMsg = AtlasPaymentOutOR.getProperty("SCsuccessMsg");
                    Assert.assertEquals("PASS", Constants.key.verifyText(vSCsuccessMsg, "Sanction update Successfully done for contact"));
                }

                LogCapture.info("Sanction for this user is safe");
            }


        }
    }

    @Then("^User clicks on Administration option after clicking User Profile$")
    public void userClicksOnAdministrationOptionAfterClickingUserProfile() throws Exception {
        String vUser = Constants.AtlasRegistrationOR.getProperty("Atlas_profile");
        Assert.assertEquals("PASS", Constants.key.click(vUser, ""));
        LogCapture.info("User clicked on user profile....");
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vAdministration = Constants.AtlasRegistrationOR.getProperty("Atlas_administration");
        Assert.assertEquals("PASS", Constants.key.click(vAdministration, ""));
        LogCapture.info("User clicked on Administration....");
    }

    @And("^User clicks on Bulk Repeat Check option and selects Module as (Registration|PaymentIN|PaymentOUT)$")
    public void userClicksOnBulkRepeatCheckOptionAndSelectsModuleAsRegistration(String Value) throws Exception {
        String vRcheck = Constants.AtlasRegistrationOR.getProperty("Atlas_BulkRepeatCheck");
        Assert.assertEquals("PASS", Constants.key.click(vRcheck, ""));
        LogCapture.info("User clicked on Bulk Repeat Check Button");

        String vSelectmodule = AtlasRegistrationOR.getProperty("SelectModule");
        Assert.assertEquals("PASS", Constants.key.click(vSelectmodule, ""));
        LogCapture.info("User is selecting the Module...");

        if (Value.equalsIgnoreCase("Registration")) {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSelectmodule, "enter"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            LogCapture.info("User clicked on Registration Module");
        } else if (Value.equalsIgnoreCase("PaymentIN")) {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSelectmodule, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSelectmodule, "enter"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            LogCapture.info("User clicked on PaymentIn Module");
        } else if (Value.equalsIgnoreCase("PaymentOut")) {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSelectmodule, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSelectmodule, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSelectmodule, "enter"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            LogCapture.info("User clicked on PaymentIn Module");
        }
    }


    @And("^User selects From and To Date in the calendar and clicks on Search button$")
    public void userSelectsFromAndToDateInTheCalendarAndClicksOnSearchButton() throws Exception {
        String vTextBoxfirst = AtlasRegistrationOR.getProperty("Textbox1");
        String vTextBoxsecond = AtlasRegistrationOR.getProperty("Textbox2");
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        Calendar cal = Calendar.getInstance();
        String currentDate = dateFormat.format(cal.getTime()) + " 00:00:00";
        cal.setTime(new Date());
        cal.add(Calendar.DATE, -15);
        String newDate = dateFormat.format(cal.getTime()) + " 00:00:00";

        Assert.assertEquals("PASS", Constants.key.writeInInput(vTextBoxfirst, newDate));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User entered From date as " + newDate);

        Assert.assertEquals("PASS", Constants.key.writeInInput(vTextBoxsecond, currentDate));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User entered To date as Current Date " + currentDate);

        String vSearchBox = AtlasRegistrationOR.getProperty("SearchBox");
        Assert.assertEquals("PASS", Constants.key.click(vSearchBox, ""));
        LogCapture.info("User clicked on Search button");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));

    }

    @Then("^User clicks on the Perform Repeat Check button$")
    public void userClicksOnThePerformRepeatCheckButton() throws Exception {
        String vPerformRepeatCheck = AtlasRegistrationOR.getProperty("PerformRepeatCheck");
        if (Constants.driver.findElement(By.xpath(vPerformRepeatCheck)).isEnabled()) {
            Assert.assertEquals("PASS", Constants.key.click(vPerformRepeatCheck, ""));
            LogCapture.info("User clicked on Perform Repeat Check button");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Constants.driver.switchTo().alert().accept();
            LogCapture.info("User accepted the Alert that popped up");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        } else LogCapture.info("User is unable to click on the Perform Repeat Check button");
    }

    @And("^User validates the Result$")
    public void userValidatesTheResult() throws Exception {
        String vProgressStatus = AtlasRegistrationOR.getProperty("ProgressStatus");
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        for (int i = 0; i < 60; i++) {
            if (Constants.driver.findElement(By.xpath(vProgressStatus)).getText().contains("In Progress..")) {
                Assert.assertEquals("PASS", Constants.key.pause("10", ""));
            } else break;
        }
        LogCapture.info("User validates the Bulk Repeat Check is successfully completed");
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
    }

    @And("^User lists down all the Failed Checks$")
    public void userListsDownAllTheFailedChecks() {
        String vBlacklistCheck = AtlasRegistrationOR.getProperty("BlacklistCheck");
        String vFraugsterCheck = AtlasRegistrationOR.getProperty("FraugsterCheck");
        String vSanctionCheck = AtlasRegistrationOR.getProperty("SanctionCheck");
        String vEIDCheck = AtlasRegistrationOR.getProperty("EIDCheck");

        LogCapture.info(Constants.driver.findElement(By.xpath(vBlacklistCheck)).getText());
        LogCapture.info(Constants.driver.findElement(By.xpath(vFraugsterCheck)).getText());
        LogCapture.info(Constants.driver.findElement(By.xpath(vSanctionCheck)).getText());
        LogCapture.info(Constants.driver.findElement(By.xpath(vEIDCheck)).getText());
    }

    @Then("^User validates the intuition Risk level field Under Intuition tab and main content section are same$")
    public void userValidatesTheIntuitionRiskLevelFieldUnderIntuitionTabAndMainContentSectionAreSame() throws Exception {
        LogCapture.info("User is validating if Intuition Risk Level field under Intuition Tab and main contant are same");
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        String vRiskLevel = Constants.AtlasRegistrationOR.getProperty("RiskLevel");
        String IntutionText = Constants.driver.findElement(By.xpath(vRiskLevel)).getText();
        System.out.println(IntutionText);
        LogCapture.info("User is clicking on Intuition tab");
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        String vObjIntuitiontab = Constants.AtlasRegistrationOR.getProperty("Intutiontab");
        Assert.assertEquals("PASS", Constants.key.click(vObjIntuitiontab, ""));
        String vRiskLevelTab = Constants.AtlasRegistrationOR.getProperty("RiskLevel");
        String IntutionTabText = Constants.driver.findElement(By.xpath(vRiskLevelTab)).getText();
        System.out.println("Tab value " + IntutionTabText);
        Assert.assertTrue(IntutionText.equalsIgnoreCase(IntutionTabText));
    }

    @And("^User Perform the Repeat check for (|Black list|FraudPredict|EID|)$")
    public void userPerformTheRepeatCheckForBlackList(String Check) throws Exception {
        if (Check.equalsIgnoreCase("Black list")) {
            LogCapture.info("User is clicking on Blacklist tab under checks");
            String vObjBlacklistTab = Constants.AtlasRegistrationOR.getProperty("BlacklistTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistTab, ""));
            LogCapture.info("User is clicking on Blacklist repeat ");
            String vObjBlacklistRepeatcheck = Constants.AtlasRegistrationOR.getProperty("BlacklistRepeatcheck");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistRepeatcheck, ""));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("User is vailidating if the repeat check is been performed");
            String vObjBlacklistRepeatcheckmsg = Constants.AtlasRegistrationOR.getProperty("BlacklistRepeatcheckmsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlacklistRepeatcheckmsg, "Blacklist Repeat Check Successfully done"));
        } else if (Check.equalsIgnoreCase("FraudPredict")) {
            LogCapture.info("User is clicking on FraudPredict tab under checks");
            String vObjFraudPredictTab = Constants.AtlasRegistrationOR.getProperty("FraudPredictTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjFraudPredictTab, ""));
            LogCapture.info("User is clicking on FraudPredict repeat ");
            String vObjFraudPredictTabRepeatcheck = Constants.AtlasRegistrationOR.getProperty("FraudPredictRepeatcheck");
            Assert.assertEquals("PASS", Constants.key.click(vObjFraudPredictTabRepeatcheck, ""));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("User is validating if the repeat check is been performed for FraudPredict");
            String vObjFraudPredictmsg = Constants.AtlasRegistrationOR.getProperty("FraudPredictRepeatcheckmsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjFraudPredictmsg, "Fraugster Repeat Check Successfully done"));
        } else if (Check.equalsIgnoreCase("EID")) {
            String vObjEIDStatus = Constants.AtlasRegistrationOR.getProperty("EIDStatus");
            if (Constants.driver.findElement(By.xpath(vObjEIDStatus)).getText().contains("Not Required")) {
                LogCapture.info("EID check not required");
            } else {
                LogCapture.info("User is clicking on EID tab under checks");
                String vObjEIDTab = Constants.AtlasRegistrationOR.getProperty("EIDTab");
                Assert.assertEquals("PASS", Constants.key.click(vObjEIDTab, ""));
                LogCapture.info("User is clicking on EID repeat ");
                Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                String vObjEIDRepeatcheck = Constants.AtlasRegistrationOR.getProperty("EIDRepeatcheck");
                Assert.assertEquals("PASS", Constants.key.click(vObjEIDRepeatcheck, ""));
                Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                LogCapture.info("User is vailidating if the EID check is been performed");
                String vObjEIDRepeatcheckmsg = Constants.AtlasRegistrationOR.getProperty("EIDRepeatcheckmsg");
                Assert.assertEquals("PASS", Constants.key.verifyText(vObjEIDRepeatcheckmsg, "Kyc Repeat Check Successfully done"));
            }


        }
    }

    @And("^User Perform the Repeat check for Black list for CFX customer$")
    public void userPerformTheRepeatCheckForBlackListForCFXCustomer() throws Exception {
        LogCapture.info("User is clicking on Blacklist tab under checks");
        String vObjBlacklistTab = Constants.AtlasRegistrationOR.getProperty("BlacklistTabCFX");
        Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        LogCapture.info("User is clicking on Blacklist repeat ");
        String vObjBlacklistRepeatcheck = Constants.AtlasRegistrationOR.getProperty("BlacklistRepeatcheckCFX");
        Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistRepeatcheck, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        LogCapture.info("User is vailidating if the repeat check is been performed");
        String vObjBlacklistRepeatcheckmsg = Constants.AtlasRegistrationOR.getProperty("BlacklistRepeatcheckmsgCFX");
        String vObjUserName = Constants.AtlasRegistrationOR.getProperty("UsernameCFX");
        String CustomerName = Constants.driver.findElement(By.xpath(vObjUserName)).getText();
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlacklistRepeatcheckmsg, "Blacklist Repeat Check Successfully done for account " + CustomerName));

    }

    @Then("^User clicks on Intuition check tab for (Payment IN|Payment Out|Registration)$")
    public void userClicksOnIntuitionCheckTabForPaymentIN(String value) throws Exception {
        if (value.equalsIgnoreCase("Payment IN")) {
            LogCapture.info("User is clicking on Intuition check tab for PaymentIn");
            String vobjIntutiontab = Constants.AtlasPaymentInOR.getProperty("intuitionTab");
            Assert.assertEquals("PASS", Constants.key.click(vobjIntutiontab, ""));
            Constants.key.pause("2", "");
        } else if (value.equalsIgnoreCase("Payment Out")) {
            LogCapture.info("User is clicking on Intuition check tab for PaymentOut");
            String vobjIntutiontab = Constants.AtlasPaymentOutOR.getProperty("IntuitionTab");
            Assert.assertEquals("PASS", Constants.key.click(vobjIntutiontab, ""));
            Constants.key.pause("2", "");
        } else if (value.equalsIgnoreCase("Registration")) {
            LogCapture.info("User is clicking on Intuition check tab for Registration");
            String RegistrationIntuitionTab = AtlasRegistrationOR.getProperty("RegistrationIntuitionTab");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(RegistrationIntuitionTab, ""));
            Assert.assertEquals("PASS", Constants.key.click(RegistrationIntuitionTab, ""));
            Constants.key.pause("2", "");
        }
    }

    @And("^User vaildates if intuition calls are sent or not to Intuition Application$")
    public void userVaildatesIfIntuitionCallsAreSentOrNotToIntuitionApplication() throws Exception {
        LogCapture.info("User is validating if successful intuition calls are getting generated or not");
        String vobjCorrelationId = Constants.AtlasPaymentInOR.getProperty("CorrelationId");
        Constants.key.pause("2", "");
        if (Constants.driver.findElement(By.xpath(vobjCorrelationId)).getText().contains("-")) {
            Assert.assertEquals("PASS", Constants.key.pause("10", ""));
            String vDecision = Constants.AtlasPaymentInOR.getProperty("Decision");
            String vDecisionmsg = Constants.driver.findElement(By.xpath(vDecision)).getText();
            Assert.assertEquals(vDecisionmsg, "SERVICE_FAILURE");
            System.out.println("Call to intuition has been failed");
        } else {
            System.out.println("Successful Call to intuition has been sent");
        }
    }

    @And("^User click on (Blacklist|Custom|Sanction|FraudPredict) check failed checkbox under filter criteria$")
    public void userClickOnBlacklistCheckFailedUnderFilterCriteria(String Check) throws Exception {
        if (Check.equalsIgnoreCase("Blacklist")) {
            String vBlacklistFailed = Constants.AtlasPaymentInOR.getProperty("BlacklistFailed");
            Assert.assertEquals("PASS", Constants.key.click(vBlacklistFailed, ""));
            LogCapture.info("User selecting failed blacklist customers");
        } else if (Check.equalsIgnoreCase("Custom")) {
            String vCustomFailed = Constants.AtlasPaymentInOR.getProperty("CustomFailed");
            Assert.assertEquals("PASS", Constants.key.click(vCustomFailed, ""));
            LogCapture.info("User selecting failed Custom check customers");
        } else if (Check.equalsIgnoreCase("Sanction")) {
            String vSanctionFailed = Constants.AtlasPaymentInOR.getProperty("SanctionFailed");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionFailed, ""));
            LogCapture.info("User selecting failed Sanction customers");
        } else if (Check.equalsIgnoreCase("FraudPredict")) {
            String vFraudPredictFailed = Constants.AtlasPaymentInOR.getProperty("FraudPredictFailed");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictFailed, ""));
            LogCapture.info("User selecting failed FraudPredict customers");
        }
    }

    @And("^User clicks on (Blacklist|Custom|Sanction|FraudPredict) check under checks tab$")
    public void userClicksOnBlacklistCheckUnderChecksTab(String Check) throws Exception {
        if (Check.equalsIgnoreCase("Blacklist")) {
            String vBlacklistCheck = Constants.AtlasPaymentInOR.getProperty("BlacklistCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vBlacklistCheck, ""));
            LogCapture.info("User clicks on blacklist check");
        } else if (Check.equalsIgnoreCase("Custom")) {
            String vCustomCheck = Constants.AtlasPaymentInOR.getProperty("CustomCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vCustomCheck, ""));
            LogCapture.info("User clicks on Custom check");
        } else if (Check.equalsIgnoreCase("Sanction")) {
            String vSanctionCheck = Constants.AtlasPaymentInOR.getProperty("SanctionCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionCheck, ""));
            LogCapture.info("User clicks on Sanction check");
        } else if (Check.equalsIgnoreCase("FraudPredict")) {
            String vFraudPredictCheck = Constants.AtlasPaymentInOR.getProperty("FraudPredictCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictCheck, ""));
            LogCapture.info("User clicks on FraudPredict check");
        }

    }

    @Then("^User clicks on RepeatCheck button for (Blacklist|Custom|Sanction|FraudPredict)$")
    public void userClicksOnRepeatCheckButtonForBlacklist(String Check) throws Exception {
        if (Check.equalsIgnoreCase("Blacklist")) {
            String vBlacklistRepeatCheck = Constants.AtlasPaymentInOR.getProperty("BlacklistRepeatCheck");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vBlacklistRepeatCheck, ""));
            LogCapture.info("User performing Blacklist repeat check");
            Constants.key.pause("10", "");
            String vBlacklistSuccessMsg = Constants.AtlasPaymentInOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlacklistSuccessMsg, "Blacklist Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("Custom")) {
            String vCustomRepeatCheck = Constants.AtlasPaymentInOR.getProperty("CustomRepeatCheck");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vCustomRepeatCheck, ""));
            LogCapture.info("User performing Custom repeat check");
            Constants.key.pause("10", "");
            String vCustomSuccessMsg = Constants.AtlasPaymentInOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCustomSuccessMsg, "Custom Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("Sanction")) {
            String vSanctionRepeatCheck = Constants.AtlasPaymentInOR.getProperty("SanctionRepeatCheck");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionRepeatCheck, ""));
            LogCapture.info("User performing Sanction repeat check");
            Constants.key.pause("10", "");
            String vSanctionSuccessMsg = Constants.AtlasPaymentInOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionSuccessMsg, "Sanction Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("FraudPredict")) {
            String vFraudPredictRepeatCheck = Constants.AtlasPaymentInOR.getProperty("FraudPredictRepeatCheck");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictRepeatCheck, ""));
            LogCapture.info("User performing FraudPredict repeat check");
            Constants.key.pause("10", "");
            String vFraudPredictSuccessMsg = Constants.AtlasPaymentInOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFraudPredictSuccessMsg, "Fraugster Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        }
    }

    @And("^User clicks on (Blacklist|Custom|Sanction|FraudPredict|ReferenceCheck) check under checks tab for Payment Out$")
    public void userClicksOnBlacklistCheckUnderChecksTabForPaymentOut(String Check) throws Exception {
        if (Check.equalsIgnoreCase("Blacklist")) {
            String vBlacklistCheck = Constants.AtlasPaymentOutOR.getProperty("BlacklistCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vBlacklistCheck, ""));
            LogCapture.info("User clicks on blacklist check");
        } else if (Check.equalsIgnoreCase("Custom")) {
            String vCustomCheck = Constants.AtlasPaymentOutOR.getProperty("CustomCheckTab2");
            Assert.assertEquals("PASS", Constants.key.click(vCustomCheck, ""));
            LogCapture.info("User clicks on Custom check");
        } else if (Check.equalsIgnoreCase("SanctionContact")) {
            String vSanctionCheck = Constants.AtlasPaymentOutOR.getProperty("SanctionContactCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionCheck, ""));
            LogCapture.info("User clicks on Sanction check");
        } else if (Check.equalsIgnoreCase("SanctionBeneficiary")) {
            String vSanctionCheck = Constants.AtlasPaymentOutOR.getProperty("SanctionBeneficiaryCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionCheck, ""));
            LogCapture.info("User clicks on Sanction check");
        } else if (Check.equalsIgnoreCase("SanctionBank")) {
            String vSanctionCheck = Constants.AtlasPaymentOutOR.getProperty("SanctionBankCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionCheck, ""));
            LogCapture.info("User clicks on Sanction check");
        } else if (Check.equalsIgnoreCase("FraudPredict")) {
            String vFraudPredictCheck = Constants.AtlasPaymentOutOR.getProperty("FraudPredictCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictCheck, ""));
            LogCapture.info("User clicks on FraudPredict check");
        } else if (Check.equalsIgnoreCase("ReferenceCheck")) {
            String vFraudPredictCheck = Constants.AtlasPaymentOutOR.getProperty("ReferenceCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictCheck, ""));
            LogCapture.info("User clicks on Reference check");
        }


    }

    @Then("^User clicks on RepeatCheck button for (Blacklist|Custom|Sanction|FraudPredict|ReferenceCheck) for Payment Out$")
    public void userClicksOnRepeatCheckButtonForBlacklistForPaymentOut(String Check) throws Exception {
        if (Check.equalsIgnoreCase("Blacklist")) {
            String vBlacklistRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("BlacklistRepeatCheck");
            Assert.assertEquals("PASS", Constants.key.click(vBlacklistRepeatCheck, ""));
            LogCapture.info("User performing Blacklist repeat check");
            Constants.key.pause("5", "");
            String vBlacklistSuccessMsg = Constants.AtlasPaymentOutOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlacklistSuccessMsg, "Blacklist Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("Custom")) {
            String vCustomRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("CustomRepeatCheck");
            Assert.assertEquals("PASS", Constants.key.click(vCustomRepeatCheck, ""));
            LogCapture.info("User performing Custom repeat check");
            Constants.key.pause("5", "");
            String vCustomSuccessMsg = Constants.AtlasPaymentOutOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCustomSuccessMsg, "Custom repeat check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("SanctionContact")) {
            String vSanctionRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("SanctionContactRepeatCheck");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionRepeatCheck, ""));
            LogCapture.info("User performing Sanction repeat check");
            Constants.key.pause("5", "");
            String vSanctionSuccessMsg = Constants.AtlasPaymentOutOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionSuccessMsg, "Sanction Repeat Check Successfully done for contact"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("SanctionBeneficiary")) {
            String vSanctionRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("SanctionBeneficiaryRepeatCheck");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionRepeatCheck, ""));
            LogCapture.info("User performing Sanction repeat check");
            Constants.key.pause("5", "");
            String vSanctionSuccessMsg = Constants.AtlasPaymentOutOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionSuccessMsg, "Sanction Repeat Check Successfully done for beneficiary"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("SanctionBank")) {
            String vSanctionRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("SanctionBankRepeatCheck");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionRepeatCheck, ""));
            LogCapture.info("User performing Sanction repeat check");
            Constants.key.pause("5", "");
            String vSanctionSuccessMsg = Constants.AtlasPaymentOutOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionSuccessMsg, "Sanction Repeat Check Successfully done for bank"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("FraudPredict")) {
            String vFraudPredictRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("FraudPredictRepeatCheck");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictRepeatCheck, ""));
            LogCapture.info("User performing FraudPredict repeat check");
            Constants.key.pause("5", "");
            String vFraudPredictSuccessMsg = Constants.AtlasPaymentOutOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFraudPredictSuccessMsg, "Fraugster Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("ReferenceCheck")) {
            String vFraudPredictRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("ReferenceRepeatCheck");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictRepeatCheck, ""));
            LogCapture.info("User performing Reference repeat check");
            Constants.key.pause("5", "");
            String vFraudPredictSuccessMsg = Constants.AtlasPaymentOutOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFraudPredictSuccessMsg, "Payment Reference Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        }
    }

    @And("^User click on FraudPredict check pass checkbox under filter criteria$")
    public void userClickOnFraudPredictCheckPassCheckboxUnderFilterCriteria() throws Exception {
        String vFraudPredictFailed = Constants.AtlasPaymentOutOR.getProperty("FraudPredictPass");
        Assert.assertEquals("PASS", Constants.key.click(vFraudPredictFailed, ""));
        LogCapture.info("User selecting pass FraudPredict customers");
    }

    @Then("^User validates country for country of Beneficiary (France|United Kingdom|Spain)$")
    public void userValidatesCountryForCountryOfBeneficiary(String country) throws Exception {
        if (country.equalsIgnoreCase("France")) {
            String benFcountry = Constants.AtlasPaymentOutOR.getProperty("Atlas_beneficiary");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(benFcountry, "France (FRA)"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        } else if (country.equalsIgnoreCase("United Kingdom")) {
            String benUKcountry = Constants.AtlasPaymentOutOR.getProperty("Atlas_beneficiary");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(benUKcountry, "United Kingdom (GBR)"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        } else if (country.equalsIgnoreCase("Spain")) {
            String benSPcountry = Constants.AtlasPaymentOutOR.getProperty("Atlas_beneficiary");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(benSPcountry, "Spain (ESP)"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));

        }
    }

    @Then("^User validates country for country of fund (Australia|United Kingdom|USA|Blank)$")
    public void userValidatesCountryForCountryOfFund(String Cfund) throws Exception {
        if (Cfund.equalsIgnoreCase("Australia")) {
            String ContryA_fund = Constants.AtlasPaymentInOR.getProperty("Atlas_contry_fund");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(ContryA_fund, "Australia (AUS)"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        } else if (Cfund.equalsIgnoreCase("United Kingdom")) {
            String ContryU_fund = Constants.AtlasPaymentInOR.getProperty("Atlas_contry_fund");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(ContryU_fund, "United Kingdom (GBR)"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        } else if (Cfund.equalsIgnoreCase("USA")) {
            String ContryUsa_fund = Constants.AtlasPaymentInOR.getProperty("Atlas_contry_fund");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(ContryUsa_fund, "USA (USA)"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        } else if (Cfund.equalsIgnoreCase("Blank")) {
            String ContryB_fund = Constants.AtlasPaymentInOR.getProperty("Atlas_contry_fund");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(ContryB_fund, "------"));
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));

        }
    }

    @And("^User validates the fields received in response from Intuition for (PaymentIn|PaymentOut)$")
    public void userValidatesTheFieldsReceivedInResponseFromIntuition(String value) throws Exception {
        if (value.equalsIgnoreCase("PaymentIn")) {
            LogCapture.info("User is clicking on the CorrelationId..");
            String vobjCorrelationId = Constants.AtlasPaymentInOR.getProperty("CorrelationId");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vobjCorrelationId, ""));
            LogCapture.info("User is clicked on the CorrelationId..");

            String vIntutionJSONResponse = Constants.AtlasPaymentInOR.getProperty("IntuitionJSONResponse");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vIntutionJSONResponse, ""));
            String IntuitionResponse = Constants.driver.findElement(By.xpath(vIntutionJSONResponse)).getText();
            LogCapture.info("Intuition JSON Response is " + IntuitionResponse);

            JsonPath jp = new JsonPath(IntuitionResponse);
            String jStatus = jp.get("Status");
            String jCorrelationId = jp.get("correlationId");
            int jRS = jp.getInt("RuleScore");
            String jRuleScore = Integer.toString(jRS);
            String jRuleRiskLevel = jp.get("RuleRiskLevel");
            String jClientRiskLevel = jp.get("ClientRiskLevel");

            String vDecision = Constants.AtlasPaymentInOR.getProperty("Decision");
            String vCorrelationId = Constants.AtlasPaymentInOR.getProperty("CorrelationId");
            String vRuleScore = Constants.AtlasPaymentInOR.getProperty("RuleScore");
            String vRuleRiskLevel = Constants.AtlasPaymentInOR.getProperty("PaymentRiskLevel");
            String vClientRiskLevel = Constants.AtlasPaymentInOR.getProperty("ProfileRiskLevel");

            LogCapture.info("User is validating Decision..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDecision, jStatus));
            LogCapture.info("User validated Decision as " + jStatus);

            LogCapture.info("User is validating CorrelationId..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCorrelationId, jCorrelationId));
            LogCapture.info("User validated CorrelationId as " + jCorrelationId);

            LogCapture.info("User is validating PaymentRiskLevel..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vRuleRiskLevel, jRuleRiskLevel));
            LogCapture.info("User validated PaymentRiskLevel as " + jRuleRiskLevel);

            LogCapture.info("User is validating ProfileRiskLevel..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vClientRiskLevel, jClientRiskLevel));
            LogCapture.info("User validated Decision as " + jClientRiskLevel);

            LogCapture.info("User is validating RuleScore..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vRuleScore, jRuleScore));
            LogCapture.info("User validated RuleScore as " + jRuleScore);

        } else if (value.equalsIgnoreCase("PaymentOut")) {
            LogCapture.info("User is clicking on the CorrelationId..");
            String vobjCorrelationId = Constants.AtlasPaymentOutOR.getProperty("CorrelationId");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vobjCorrelationId, ""));
            LogCapture.info("User is clicked on the CorrelationId..");

            String vIntutionJSONResponse = Constants.AtlasPaymentOutOR.getProperty("IntuitionJSONResponse");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vIntutionJSONResponse, ""));
            String IntuitionResponse = Constants.driver.findElement(By.xpath(vIntutionJSONResponse)).getText();
            LogCapture.info("Intuition JSON Response is " + IntuitionResponse);

            JsonPath jp = new JsonPath(IntuitionResponse);
            String jStatus = jp.get("Status");
            String jCorrelationId = jp.get("correlationId");
            int jRS = jp.getInt("RuleScore");
            String jRuleScore = Integer.toString(jRS);
            String jRuleRiskLevel = jp.get("RuleRiskLevel");
            String jClientRiskLevel = jp.get("ClientRiskLevel");

            String vDecision = Constants.AtlasPaymentOutOR.getProperty("Decision");
            String vCorrelationId = Constants.AtlasPaymentOutOR.getProperty("CorrelationId");
            String vRuleScore = Constants.AtlasPaymentOutOR.getProperty("RuleScore");
            String vRuleRiskLevel = Constants.AtlasPaymentOutOR.getProperty("PaymentRiskLevel");
            String vClientRiskLevel = Constants.AtlasPaymentOutOR.getProperty("ProfileRiskLevel");

            LogCapture.info("User is validating Decision..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDecision, jStatus));
            LogCapture.info("User validated Decision as " + jStatus);

            LogCapture.info("User is validating CorrelationId..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCorrelationId, jCorrelationId));
            LogCapture.info("User validated CorrelationId as " + jCorrelationId);

            LogCapture.info("User is validating PaymentRiskLevel..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vRuleRiskLevel, jRuleRiskLevel));
            LogCapture.info("User validated PaymentRiskLevel as " + jRuleRiskLevel);

            LogCapture.info("User is validating ProfileRiskLevel..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vClientRiskLevel, jClientRiskLevel));
            LogCapture.info("User validated Decision as " + jClientRiskLevel);

            LogCapture.info("User is validating RuleScore..");
            Assert.assertEquals("PASS", Constants.key.verifyText(vRuleScore, jRuleScore));
            LogCapture.info("User validated RuleScore as " + jRuleScore);

        }
    }

    @And("^User vaildates if intuition calls are sent or not to Intuition Application for Payment Out$")
    public void userVaildatesIfIntuitionCallsAreSentOrNotToIntuitionApplicationForPaymentOut() throws InterruptedException {
        LogCapture.info("User is validating if successful intuition calls are getting generated or not");
        String vobjCorrelationId = Constants.AtlasPaymentOutOR.getProperty("CorrelationId");
        Constants.key.pause("2", "");
        if (Constants.driver.findElement(By.xpath(vobjCorrelationId)).getText().contains("-")) {
            Assert.assertEquals("PASS", Constants.key.pause("10", ""));
            String vDecision = Constants.AtlasPaymentOutOR.getProperty("Decision");
            String vDecisionmsg = Constants.driver.findElement(By.xpath(vDecision)).getText();
            Assert.assertEquals(vDecisionmsg, "SERVICE_FAILURE");
            System.out.println("Call to intuition has been failed");
        } else {
            System.out.println("Successful Call to intuition has been sent");
        }
    }

    @Given("^User connects to UAT DB and fetches the Latest TradeContractNumber \"([^\"]*)\"$")
    public void userConnectsToUATDBAndFetchesTheLatestTradeContractNumber(String tradeAccountNumber) throws Throwable {

        String vLatestTradeContractNumber = Constants.key.VerifyDBDetails("UAT", tradeAccountNumber, "Fetch Latest Payment contract_number");
        System.out.println("Latest Trade Account Number : " + vLatestTradeContractNumber);
        String vFirst = vLatestTradeContractNumber.split("-")[0].trim();
        Integer vLast = Integer.parseInt(vLatestTradeContractNumber.split("-")[1].trim()) + 1;
        String vLastest = Integer.toString(vLast);
        String rTradeContractNumber = vFirst + "-" + vLastest;
        Constants.TradeContractNumber = rTradeContractNumber;

    }

    @Then("^User Triggers API to generate token$")
    public void userTriggersAPIToGenerateToken() {
        String response = "";
        String body = "grant_type=password&client_id=auth_token_service&username=cd_api_user&password=Currenc!es@E145AA&client_secret=857f21c0-4c5d-4022-8c0-4ead1ffdb6fc";
        RestAssured.baseURI = "https://uatsso.currenciesdirect.com/auth/realms/cd-internal/protocol/openid-connect/token";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/x-www-form-urlencoded");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Accept-Language", "en-US,en;q=0.8");
        response = given().relaxedHTTPSValidation().log().all().headers(m).body(body).when().post().then().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);
        Constants.ACCESS_TOKEN = jp.get("access_token");

        RestAssured.baseURI="";
    }

    @And("^User verifies Sanction check for (CFX PaymentIn|CFX PaymentOut|PFX PaymentIn|PFX PaymentOut) is (passed|failed|Not required)$")
    public void userVerifiesSanctionCheckForPaymentInIsPassed(String paymentMethod, String value) throws Exception {

        String vSanctionCheck = Constants.AtlasPaymentInOR.getProperty("SanctionCheckTab");
        Assert.assertEquals("PASS", Constants.key.click(vSanctionCheck, ""));
        LogCapture.info("User clicks on Sanction check");
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));

        if (paymentMethod.equalsIgnoreCase("PFX PaymentIn")) {
            String vSanctionPass = AtlasPaymentInOR.getProperty("SanctionPass");
            if (value.equalsIgnoreCase("passed")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionPass, "check"));
                LogCapture.info("Sanction check is passed");
            } else if (value.equalsIgnoreCase("failed")) {
                Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionPass, "check"));
                LogCapture.info("Sanction check is failed");
            }
        } else if (paymentMethod.equalsIgnoreCase("CFX PaymentIn")) {

            if (value.equalsIgnoreCase("passed")) {
                String vSanctionPass = AtlasPaymentInOR.getProperty("CFXSanctionPass");
                Constants.key.VisibleConditionWait(vSanctionPass, "");
                Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionPass, "check"));
                LogCapture.info("Sanction check is passed for this CFX PaymentIn");
            } else if (value.equalsIgnoreCase("failed")) {
                String vSanctionFail = AtlasPaymentInOR.getProperty("CFXSanctionFail");
                Constants.key.VisibleConditionWait(vSanctionFail, "");
                Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionFail, "clear"));
                LogCapture.info("Sanction check is failed for this CFX PaymentIn");
            } else if (value.equalsIgnoreCase("Not required")) {

                String vSanctionNotRequired = AtlasPaymentInOR.getProperty("CFXSanctionNotRequired");
                Constants.key.VisibleConditionWait(vSanctionNotRequired, "");
                Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionNotRequired, "Not Required"));
                LogCapture.info("Sanction check is not required for this CFX PaymentIn");

            }
        }
    }

    @And("^User verifies Activity Log with message \"([^\"]*)\"$")
    public void userVerifiesActivityLogWithMessage(String message) throws Throwable {

        String vActivityHistory = AtlasPaymentInOR.getProperty("ActivityHistory");
        String vActivityMessage = AtlasPaymentInOR.getProperty("ActivityMessage");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vActivityHistory, ""));
        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vActivityMessage, message));
        LogCapture.info("User verified activity history " + message);
    }

    @Then("^User validates successful call to intuition has been sent$")
    public void userValidatesSuccessfulCallToIntuitionHasBeenSent(String CorrelationID) throws Exception {
        LogCapture.info("User clicking on intuition correlation id hyperlink");
        if (CorrelationID.equalsIgnoreCase("")) {
            System.out.println("Call to Intuition is unsuccessful");
        } else {
            LogCapture.info("User clicking on intuition correlation id hyperlink");
            String vIntuitionID = Constants.AtlasPaymentInOR.getProperty("IntuitionCorrelationID");
            Assert.assertEquals("PASS", Constants.key.click(vIntuitionID, ""));
        }
    }

    @Then("^User validates intuition decision as (Clear|Hold)$")
    public void userValidatesIntuitionDecisionAsClear(String Decision) throws Exception {
        String VDecision = Constants.AtlasPaymentInOR.getProperty("IntuitionDecision");
        if (Decision.equalsIgnoreCase("Clear")) {

            Assert.assertEquals("PASS", Constants.key.verifyText(VDecision, "Clean"));
            LogCapture.info("User validates the decision on Intuition check is Clear");
        } else if (Decision.equalsIgnoreCase("Hold")) {
            Assert.assertEquals("PASS", Constants.key.verifyText(VDecision, "Hold"));
            LogCapture.info("User validates the decision on Intuition check is Hold");

        } else if (Decision.equalsIgnoreCase("")) {
            LogCapture.info("User validates the no decision is been made ");

        }


    }

    @And("^User verify the saved Report on filter with (Payment In|Payment Out) Reports screen$")
    public void userVerifyTheSavedReportOnFilterWithPaymentInReportsScreen(String Page) throws Exception {
        if (Page.equalsIgnoreCase("Payment In")) {
            String vArrowDDClick = Constants.AtlasPaymentInOR.getProperty("SelectReportDropDownForReports");
            String vReasonContainer = Constants.AtlasPaymentInOR.getProperty("SelectReportValueForReports");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            Constants.key.pause("3", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            System.out.println(ReportName);
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//div[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                if (vdata.equalsIgnoreCase(ReportName)) {
                    System.out.println(vdata);
                    Constants.driver.findElement(By.xpath("//div[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                    break;
                }
            }
            String vObjPaymentInQueueTable = AtlasPaymentInOR.getProperty("PaymentInReportTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (listOfElements.size() > 1) {
                LogCapture.info("Successfullly Added Report");
            } else {
                Assert.fail();
            }
        }
    }

    @And("^User clicks on TM request (green tick|Red Cross) button$")
    public void userClicksOnTMRequestGreenTickButton(String Request) throws Exception {

        if (Request.equalsIgnoreCase("green tick")) {

            String vTMRequestTick = Constants.AtlasPaymentInOR.getProperty("TMRequestGreenTick");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vTMRequestTick, ""));
            Assert.assertEquals("PASS", Constants.key.click(vTMRequestTick, ""));
            LogCapture.info("User clicking on TM Request Green Tick button");

        } else if (Request.equalsIgnoreCase("Red Cross")) {
            String vTMRequestRedCross = Constants.AtlasPaymentInOR.getProperty("TMRequestRedCross");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vTMRequestRedCross, ""));
            Assert.assertEquals("PASS", Constants.key.click(vTMRequestRedCross, ""));
            LogCapture.info("User clicking on TM Request red Tick button");
        }
    }

    @And("^User delete any one of the report if it has more than five reports for (Payment In Reports|Payment Out Reports)$")
    public void userDeleteAnyOneOfTheReportIfItHasMoreThanFiveReportsForPaymentInReports(String Report) throws Exception {
        String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
        String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vArrowDDClick, ""));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vArrowDDClick)));
        //Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
        Constants.key.pause("3", "");
        List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
        System.out.println("The Options in the Dropdown are: " + dropdown_list.size());

        if (dropdown_list.size() == 5) {

            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                Constants.key.pause("3", "");
                String vObjDeleteButton = Constants.AtlasRegistrationOR.getProperty("DeleteButton");
                ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteButton, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjDeleteButton, ""));
                Constants.key.pause("2", "");
                String vObjConfirmDeleteTextMsg = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteTextMsg");
                String vObjConfirmDeleteOK = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteOK");
                String SearchName = Constants.driver.findElement(By.xpath(vObjConfirmDeleteTextMsg)).getText();
                System.out.println("Search Name::" + SearchName);
                Assert.assertEquals("PASS", Constants.key.click(vObjConfirmDeleteOK, ""));
                Constants.key.pause("5", "");
                break;
            }
            String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vFilterButton, ""));

            if (Report.equalsIgnoreCase("Payment In Reports")) {
                LogCapture.info("User is selecting Payment In Queue hyperlink from dashboard..");
                String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("Atlas_PaymentInReportTab");
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
                vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
                Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
            } else if (Report.equalsIgnoreCase("Payment Out Reports")) {
                LogCapture.info("User is selecting Payment Out Queue hyperlink from dashboard..");
                String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                String vObjAtlasPaymentOutTabQueue = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutTabQueue");
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjAtlasPaymentOutTabQueue, ""));
                vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
                Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
            }
        } else {
            LogCapture.info("Saved Report has Less than 5");
        }
    }

    @And("^User clicks on Intuition check in (payment In|payment Out) module$")
    public void userClicksOnIntuitionCheckInPaymentInModule(String Intuition) throws Exception {
        if (Intuition.equalsIgnoreCase("Payment In")) {
            LogCapture.info("Validating if Intuition check is getting clicked ");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            String vPaymentInIntuitionTab = AtlasPaymentInOR.getProperty("PaymentInIntuitionTab");
            Assert.assertEquals("PASS", Constants.key.click(vPaymentInIntuitionTab, ""));
            Constants.key.pause("2", "");
        } else if (Intuition.equalsIgnoreCase("payment Out")) {
            LogCapture.info("Validating if Intuition check is getting clicked ");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            String vPaymentInIntuitionTab = AtlasPaymentInOR.getProperty("PaymentOutIntuitionTab");
            Assert.assertEquals("PASS", Constants.key.click(vPaymentInIntuitionTab, ""));
            Constants.key.pause("2", "");
        }
    }

    @Then("^User validates call to intuition is not required$")
    public void userValidatesCallToIntuitionIsNotRequired() throws Exception {
        String vNOTRequired = AtlasPaymentInOR.getProperty("NOTRequired");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vNOTRequired, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Validating call to intuition is not required been made");
    }

    @Then("^User validates call to intuition is been made for (Payment In|Payment Out)$")
    public void userValidatesCallToIntuitionIsBeenMadeForPaymentIn(String correlation) throws Exception {
        if (correlation.equalsIgnoreCase("Payment In")) {
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            String vIntuitionCorrelationId = AtlasPaymentInOR.getProperty("PaymentInIntuitionCorrelationId");
            Assert.assertEquals("PASS", Constants.key.click(vIntuitionCorrelationId, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Validating successful call to intuition is been made");
        } else if (correlation.equalsIgnoreCase("payment Out")) {
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            String vIntuitionCorrelationId = AtlasPaymentInOR.getProperty("PaymentOutIntuitionCorrelationId");
            Assert.assertEquals("PASS", Constants.key.click(vIntuitionCorrelationId, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Validating successful call to intuition is been made");
        }
    }

    @Then("^User Triggers request for FundsIN for TradeContractNumber \"([^\"]*)\" having Customer type \"([^\"]*)\" and Debitor name \"([^\"]*)\" and Third-party payment \"([^\"]*)\"$")
    public void userTriggersRequestForFundsINForTradeContractNumberHavingCustomerTypeAndDebitorNameAndThirdPartyPayment(String tradeAccountNumber, String customerType, String debitorName, String thirdPartyPayment) throws Throwable {
        Constants.TradeContactID = Constants.key.VerifyDBDetails("UAT", tradeAccountNumber, "Fetch TradeContactID");
        String response = "";

        Random rand = new Random();
        int upperbound = 9999999;
        //generate random values from 0-24
        int int_random = rand.nextInt(upperbound);
        System.out.println("The random integer is :" + int_random);

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);

        String body = "{\n" +
                "   \"org_code\":\"Currencies Direct\",\n" +
                "   \"source_application\":\"Currencies Direct Titan \",\n" +
                "   \"trade\":{\n" +
                "      \"trade_account_number\":\"" + tradeAccountNumber + "\",\n" +
                "       \"trade_contact_id\": " + TradeContactID + ",\n" +
                "      \"cust_type\":\"" + customerType + "\",\n" +
                "      \"purpose_of_trade\":\"Others\",\n" +
                "      \"payment_fundsIN_Id\":" + int_random + ",\n" +
                "      \"selling_amount\":50,\n" +
                "      \"selling_amount_GBP_Value\":500000000000,\n" +
                "      \"transaction_currency\":\"GBP\",\n" +
                "      \"contract_number\":\"" + TradeContractNumber + "\",\n" +
                "      \"payment_Method\":\"BACS / CHAPS / TT\",\n" +
                "      \"av_trade_value\":\"0\",\n" +
                "      \"av_trade_frequency\":\"0\",\n" +
                "      \"third_party_payment\":" + thirdPartyPayment + ",\n" +
                "      \"turnover\":7000,\n" +
                "      \"transaction_reference\":\"2308320\",\n" +
                "      \"payment_time\":\"" + currentDate + "\",\n" +
                "      \"debtor_name\":\"" + debitorName + "\",\n" +
                "      \"debtor_account_number\":\"40478102671338\",\n" +
                "      \"ordering_institution\":\"Currencies Direct\",\n" +
                "      \"customer_legal_entity\":\"CDLGB\"\n" +
                "   },\n" +
                "   \"device_info\":{\n" +
                "      \"browser_user_agent\":\"eyJ0aW1lIjoiMjAxOC0wOC0yM1QxMDo1NToxNCswMTowMCIsInRpbWV6b25lIjotNjAsImxhbmd1YWdlcyI6WyJlbi1HQiJdLCJ1c2VyQWdlbnQiOiJNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvNjQuMC4zMjgyLjE0MCBTYWZhcmkvNTM3LjM2IEVkZ2UvMTcuMTcxMzQiLCJwbHVnaW5zIjp7IjAiOnsibmFtZSI6IkVkZ2UgUERGIFZpZXdlciIsInZlcnNpb24iOiIifX0sImh0bWw1Ijp7ImFwcGxpY2F0aW9uY2FjaGUiOnRydWUsImNhbnZhcyI6dHJ1ZSwiY2FudmFzdGV4dCI6dHJ1ZSwiaGFzaGNoYW5nZSI6dHJ1ZSwiaGlzdG9yeSI6dHJ1ZSwiYXVkaW8iOnRydWUsInZpZGVvIjp0cnVlLCJpbmRleGVkZGIiOnRydWUsImlucHV0Ijp7ImF1dG9jb21wbGV0ZSI6dHJ1ZSwiYXV0b2ZvY3VzIjp0cnVlLCJsaXN0Ijp0cnVlLCJwbGFjZWhvbGRlciI6dHJ1ZSwibWF4Ijp0cnVlLCJtaW4iOnRydWUsIm11bHRpcGxlIjp0cnVlLCJwYXR0ZXJuIjp0cnVlLCJyZXF1aXJlZCI6dHJ1ZSwic3RlcCI6dHJ1ZX0sImlucHV0dHlwZXMiOnsic2VhcmNoIjp0cnVlLCJ0ZWwiOnRydWUsInVybCI6dHJ1ZSwiZW1haWwiOnRydWUsImRhdGV0aW1lIjpmYWxzZSwiZGF0ZSI6dHJ1ZSwibW9udGgiOnRydWUsIndlZWsiOnRydWUsInRpbWUiOnRydWUsImRhdGV0aW1lLWxvY2FsIjp0cnVlLCJudW1iZXIiOmZhbHNlLCJyYW5nZSI6dHJ1ZSwiY29sb3IiOnRydWV9LCJsb2NhbHN0b3JhZ2UiOnRydWUsInNlc3Npb25zdG9yYWdlIjp0cnVlLCJwb3N0bWVzc2FnZSI6dHJ1ZSwid2Vic29ja2V0cyI6dHJ1ZSwid2Vid29ya2VycyI6dHJ1ZX0sImNzcyI6eyJiYWNrZ3JvdW5kc2l6ZSI6dHJ1ZSwiYm9yZGVyaW1hZ2UiOnRydWUsImJvcmRlcnJhZGl1cyI6dHJ1ZSwiYm94c2hhZG93Ijp0cnVlLCJmbGV4Ym94Ijp0cnVlLCJmbGV4Ym94bGVnYWN5Ijp0cnVlLCJoc2xhIjp0cnVlLCJyZ2JhIjp0cnVlLCJtdWx0aXBsZWJncyI6dHJ1ZSwib3BhY2l0eSI6dHJ1ZSwidGV4dHNoYWRvdyI6dHJ1ZSwiY3NzYW5pbWF0aW9ucyI6dHJ1ZSwiY3NzY29sdW1ucyI6dHJ1ZSwiZ2VuZXJhdGVkY29udGVudCI6dHJ1ZSwiY3NzZ3JhZGllbnRzIjp0cnVlLCJjc3NyZWZsZWN0aW9ucyI6ZmFsc2UsImNzc3RyYW5zZm9ybXMiOnRydWUsImNzc3RyYW5zZm9ybXMzZCI6dHJ1ZSwiY3NzdHJhbnNpdGlvbnMiOnRydWV9LCJmbGFzaCI6ZmFsc2UsInN2ZyI6dHJ1ZSwiY29va2llcyI6dHJ1ZSwic2NyZWVuUmVzb2x1dGlvbiI6IjEyODAgeCA3MjAiLCJwaXhlbFJhdGlvIjoxLjUsInNjcmVlblJlc29sdXRpb25OYXRpdmUiOiIxOTIwIHggMTA4MCIsImJyb3dzZXIiOiJDaHJvbWUiLCJicm93c2VyVmVyc2lvbiI6IjY0LjAuMzI4Mi4xNDAiLCJicm93c2VyTWFqb3JWZXJzaW9uIjo2NCwib3MiOiJXaW5kb3dzIiwib3NWZXJzaW9uIjoiMTAifQ==\",\n" +
                "      \"screen_resolution\":\"1280x720 24\",\n" +
                "      \"brwsr_type\":\"Edge\",\n" +
                "      \"brwsr_version\":\"17.17134\",\n" +
                "      \"device_type\":\"Desktop\",\n" +
                "      \"device_name\":\"\",\n" +
                "      \"device_version\":\"\",\n" +
                "      \"device_id\":\"\",\n" +
                "      \"device_manufacturer\":\"\",\n" +
                "      \"os_type\":\"Windows 10\",\n" +
                "      \"brwsr_lang\":\"en-GB\",\n" +
                "      \"browser_online\":\"true\",\n" +
                "      \"os_ts\":\"2018-08-23T09:55:14Z\"\n" +
                "   },\n" +
                "   \"risk_score\":{\n" +
                "      \n" +
                "   },\n" +
                "   \"debtorAccountNumber\":\"40478102671338\"\n" +
                "}";
        RestAssured.baseURI = "https://uatatlas.currenciesdirect.com/compliance-service/rest-services/fundsin";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Accept-Language", "en-US,en;q=0.8");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");
        response = given().relaxedHTTPSValidation().log().all().headers(m).body(body).when().post().then().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);
    }

    @Then("^User clicks (Yes|No) for the Intuition PopUp$")
    public void userClicksYesForTheIntuitionPopUp(String value) throws Exception {
        String vIntuiionButtonYes = AtlasPaymentInOR.getProperty("IntuitionYesButton");
        String vIntuiionButtonNo = AtlasPaymentInOR.getProperty("IntuitionNoButton");
        String vIntuitionMessage = AtlasPaymentInOR.getProperty("IntuitionConfirmationMessage");
        if (driver.findElement(By.xpath(vIntuitionMessage)).isDisplayed()) {
            Assert.assertEquals("PASS", Constants.key.verifyText(vIntuitionMessage, "Manual action on Intuition is pending, do you want to continue clearing?"));
            if (value.equalsIgnoreCase("Yes")) {
                Assert.assertEquals("PASS", Constants.key.click(vIntuiionButtonYes, ""));
                LogCapture.info("User clicked on Yes for Clearing the Payment");
            } else if (value.equalsIgnoreCase("No")) {
                Assert.assertEquals("PASS", Constants.key.click(vIntuiionButtonNo, ""));
                LogCapture.info("User clicked on No for Clearing the Payment");
            }
        }
    }

    @And("^User clicks on Intuition status (green tick|Red Cross) button$")
    public void userClicksOnIntuitionStatusGreenTickButton(String status) throws Exception {
        if (status.equalsIgnoreCase("green tick")) {
            String vIntuitonstas = Constants.AtlasPaymentInOR.getProperty("Intuitionstatuspas");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vIntuitonstas, ""));
            Assert.assertEquals("PASS", Constants.key.click(vIntuitonstas, ""));
            LogCapture.info("User clicking on Intuition status Green Tick button");

        } else if (status.equalsIgnoreCase("Red Cross")) {
            String vIntuitionstatfl = Constants.AtlasPaymentInOR.getProperty("Intuitionstatusfail");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vIntuitionstatfl, ""));
            Assert.assertEquals("PASS", Constants.key.click(vIntuitionstatfl, ""));
            LogCapture.info("User clicking on Intuition status red cross button");
        }
    }

    @And("^user click on intuition tab (PaymentIn|PaymentOut)$")
    public void userClickOnIntuitionTab(String tab) throws Exception {
        if (tab.equalsIgnoreCase("PaymentIn")) {
            String vSanctiontab = Constants.AtlasPaymentInOR.getProperty("PaymentInIntutiontab");
            Assert.assertEquals("PASS", Constants.key.click(vSanctiontab, ""));
            LogCapture.info("User click on intuition tab Payment in ");
        } else if (tab.equalsIgnoreCase("PaymentOut")) {
            String vIntuitionstatfl = Constants.AtlasPaymentOutOR.getProperty("PaymentOutIntuitionTab");
            Assert.assertEquals("PASS", Constants.key.click(vIntuitionstatfl, ""));
            LogCapture.info("User click on Intuition tab payment out ");
        }
    }

    @Then("^validate intuition decision Payment in as (Clean|Hold)$")
    public void validateIntuitionDecisionPaymentInAsClean(String Decision) throws Exception {
        if (Decision.equalsIgnoreCase("Clean")) {
            String VDecision = Constants.AtlasPaymentInOR.getProperty("IntuitionDecision");
            Assert.assertEquals("PASS", Constants.key.verifyText(VDecision, "Clean"));
            LogCapture.info("User validates the decision on Intuition check is Clean");

        } else if (Decision.equalsIgnoreCase("Hold")) {
            String VDecision = Constants.AtlasPaymentInOR.getProperty("IntuitionDecisionh");
            Assert.assertEquals("PASS", Constants.key.verifyText(VDecision, "Hold"));
            LogCapture.info("User validates the decision on Intuition check is Hold");

        } else if (Decision.equalsIgnoreCase("")) {
            LogCapture.info("User validates the no decision is been made ");

        }
    }

    @Then("^validate intuition decision Payment Out as (Clean|Hold)$")
    public void validateIntuitionDecisionPaymentOutAsClean(String DecisionOut) throws Exception {
        if (DecisionOut.equalsIgnoreCase("Clean")) {
            String VDecision = Constants.AtlasPaymentOutOR.getProperty("Pymentoutc");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VDecision, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(VDecision, "Clean"));
            LogCapture.info("User validates the decision on Intuition check is Clean");

        } else if (DecisionOut.equalsIgnoreCase("Hold")) {
            String VDecision = Constants.AtlasPaymentOutOR.getProperty("Pymentouth");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VDecision, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(VDecision, "Hold"));
            LogCapture.info("User validates the decision on Intuition check is Hold");

        } else if (DecisionOut.equalsIgnoreCase("")) {
            LogCapture.info("User validates the no decision is been made ");

        }
    }

    @Then("^User validate Initial status for Payment Out transaction is STP$")
    public void userValidateInitialStatusForPaymentOutTransactionIsSTP() throws Exception {
        String vInitialStatus = AtlasPaymentOutOR.getProperty("InitialStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vInitialStatus, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vInitialStatus, "STP"));
        LogCapture.info("Validating Initial Status is STP");
    }

    @And("^User vaildates if intuition calls are sent or not to Intuition Application for PaymentIN$")
    public void userVaildatesIfIntuitionCallsAreSentOrNotToIntuitionApplicationForPaymentIN() throws InterruptedException {
        LogCapture.info("User is validating if successful intuition calls are getting generated or not");
        String vobjCorrelationId = Constants.AtlasPaymentInOR.getProperty("CorrelationIdI");
        Constants.key.pause("2", "");
        if (Constants.driver.findElement(By.xpath(vobjCorrelationId)).getText().contains("-")) {
            Assert.assertEquals("PASS", Constants.key.pause("10", ""));
            String vDecision = Constants.AtlasPaymentInOR.getProperty("DecisionI");
            String vDecisionmsg = Constants.driver.findElement(By.xpath(vDecision)).getText();
            Assert.assertEquals(vDecisionmsg, "SERVICE_FAILURE");
            System.out.println("Call to intuition has been failed");
        } else {
            System.out.println("Successful Call to intuition has been sent");
        }
    }

    @And("^User vaildates if intuition calls are sent or not to Intuition forPaymentOut$")
    public void userVaildatesIfIntuitionCallsAreSentOrNotToIntuitionForPaymentOut() throws InterruptedException {
        LogCapture.info("User is validating if successful intuition calls are getting generated or not");
        String vobjCorrelationId = Constants.AtlasPaymentOutOR.getProperty("CorrelationId");
        Constants.key.pause("2", "");
        if (Constants.driver.findElement(By.xpath(vobjCorrelationId)).getText().contains("-")) {
            Assert.assertEquals("PASS", Constants.key.pause("10", ""));
            String vDecision = Constants.AtlasPaymentOutOR.getProperty("Decision");
            String vDecisionmsg = Constants.driver.findElement(By.xpath(vDecision)).getText();
            Assert.assertEquals(vDecisionmsg, "SERVICE_FAILURE");
            System.out.println("Call to intuition has been failed");
        } else {
            System.out.println("Successful Call to intuition has been sent");

        }
    }

    @Then("^User copy the TAN number$")
    public void userCopyTheTANNumber() throws Exception {
        String vTAN = Constants.AtlasRegistrationOR.getProperty("TAN");
        CopiedTAN = Constants.key.getText(vTAN, "");
        System.out.println("Copied TAN is" + CopiedTAN);
    }

    @Then("^User insert TAN number which just has been activated$")
    public void userInsertTANNumberWhichJustHasBeenActivated() throws Exception {
        System.out.println("Copied TAN is" + CopiedTAN);
        Assert.assertEquals("PASS", Constants.key.writeInInput(CopiedTAN, ""));
        LogCapture.info("Copied TAN has been inserted");
    }

    @Then("^User verifies if applied filter customer is present or not$")
    public void userVerifiesIfAppliedFilterCustomerIsPresentOrNot() throws Exception {
        String ClintDetails = Constants.AtlasRegistrationOR.getProperty("ClintDetails");
        String showing = Constants.driver.findElement(By.xpath(ClintDetails)).getText();
        System.out.println(showing);
    }


    @Then("^User click on Yes to continue clearing when Manual action on Intuition is pending$")
    public void userClickOnYesToContinueClearingWhenManualActionOnIntuitionIsPending() throws Exception {
        String vConfirm = Constants.AtlasPaymentOutOR.getProperty("ConfirmButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vConfirm, ""));
        String confirm = Constants.driver.findElement(By.xpath(vConfirm)).getText();

        LogCapture.info("User is on pop up window####################################################################" + confirm);

        String vManualActionButton = Constants.AtlasPaymentOutOR.getProperty("ManualActionButton");

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vManualActionButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vManualActionButton, ""));
        LogCapture.info("User click on manual action button yes");
    }

    @Then("^Payment Out Status Observed as Hold,Seize,Clear rather then reversed$")
    public void paymentOutStatusObservedAsHOLDRatherThenReversed() throws Exception {
        for (int i = 1; i <= 50; i++) {
            String vObjPayOutStatus = "//table[@class=\"micro table-fix space-after\"]//tr[" + i + "]//td[13]";
            String PaymentOutStatus = Constants.key.getText(vObjPayOutStatus, "");
            if (PaymentOutStatus.equals("HOLD") || PaymentOutStatus.equals("SEIZE") || PaymentOutStatus.equals("CLEAR")) {
                Assert.assertEquals("PASS", Constants.key.click(vObjPayOutStatus, ""));
                break;
            }
        }

    }


    @When("^User click on pop up button Paymentin (Yes|No)$")
    public void userClickOnButton(String button) throws Exception {
        if (button.equalsIgnoreCase("Yes")) {
            String vpoptaby = Constants.AtlasPaymentInOR.getProperty("popbuttony");
            Assert.assertEquals("PASS", Constants.key.click(vpoptaby, ""));
            LogCapture.info("User click on Pop tab Yes ");
        } else if (button.equalsIgnoreCase("No")) {
            String vpoptabn = Constants.AtlasPaymentInOR.getProperty("popbuttonn");
            Assert.assertEquals("PASS", Constants.key.click(vpoptabn, ""));
            LogCapture.info("User click on Pop tab No ");
        }
    }

    @Then("^User Clicks on Sync reg with intuition button$")
    public void userClicksOnSyncRegWithIntuitionButton() throws Exception {
        String Syncregs = Constants.AtlasRegistrationOR.getProperty("Syncreg");
        Assert.assertEquals("PASS", Constants.key.click(Syncregs, ""));
        LogCapture.info("User Clicks on Sync reg with intuition button");
    }

    @And("^User enter comma separated Customer number\"([^\"]*)\" & click on process button$")
    public void userEnterCommaSeparatedCustomerNumberClickOnProcessButton(String Value ) throws Throwable {
        String vValuebox = Constants.AtlasRegistrationOR.getProperty("Separated");
        String Process = Constants.AtlasRegistrationOR.getProperty("Processbtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vValuebox, ""));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vValuebox, Value));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(Process, ""));
        LogCapture.info("User enter comma separated Customer number & click on process button sycn data to intuition ");
    }
    @Then("^User triggers Card Eligibility API$")
    public void userTriggersCardEligibilityAPI() throws Exception {
        String response = "";
        String body = "{\n" +
                "    \"titanAccountNumber\":\""+TradeAccountNumber+"\",\n" +
                "    \"tradeContactID\": \""+TradeContactID +"\",\n" +
                "    \"passwordChangeDate\": \"2023-02-17\",\n" +
                "    \"applicationInstallDate\": \"2023-02-17\",\n" +
                "    \"applicationDeviceId\": \"device-id test\",\n" +
                "    \"requestIPAddress\": \"90.12.203.220\",\n" +
                "    \"orgCode\": \"Currencies Direct\",\n" +
                "    \"accountId\": \""+ AccountID +"\",\n" +
                "    \"cardDeliveryToSecondaryAddress\": false\n" +
                "}";
        RestAssured.baseURI = "https://uatatlas.currenciesdirect.com/compliance-service/rest-services/card-services/cardEligibilityCheck";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("User-Agent", "PostmanRuntime/7.30.0");
        m.put("Accept", "*/*");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");
        response = given().relaxedHTTPSValidation().log().all().headers(m).body(body).when().put().then().assertThat().statusCode(Integer.parseInt("200")).extract().asString();

        JsonPath jp = Constants.key.rawToJason(response);

    }

    @Then("^User clicks on Holistic View page$")
    public void userClicksOnHolisticViewPage() throws Exception {
        String vHolistic = CardApply.getProperty("Holistic");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vHolistic, ""));
        Assert.assertEquals("PASS", Constants.key.click(vHolistic, ""));
        LogCapture.info("User click on holistic view page");
    }

    @Then("^User put TAN in keyword section to generate report$")
    public void userPutTANInKeywordSectionToGenerateReport(String Value) throws Exception {
        if (Value.equalsIgnoreCase("Customer Number") || Value.equalsIgnoreCase("Email Address") || Value.equalsIgnoreCase("Client Id") || Value.equalsIgnoreCase("Customer ID")) {
            String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, ""));
            String keyword = CardApply.getProperty("keyword");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(keyword, ""));
            Assert.assertEquals("PASS", Constants.key.click(keyword, ""));
            LogCapture.info("User click on holistic view page");
        }
    }

    @Then("^User enters (Customer Number| Email Address|Client Id|Customer ID)in keyword section to generate reports$")
    public void userEntersCustomerNumberInKeywordSectionToGenerateReports(String Value) throws Exception {
        if (Value.equalsIgnoreCase("Customer Number") || Value.equalsIgnoreCase("Email Address") || Value.equalsIgnoreCase("Client Id") || Value.equalsIgnoreCase("Customer ID")) {
            String vKeyword = Constants.CardApply.getProperty("Atlas_enterSearchCriteriaKeyword");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, ""));

        }
    }

    @And("^User validates if intuition calls are sent or not to Intuition Application under Registraion reports$")
    public void userValidatesIfIntuitionCallsAreSentOrNotToIntuitionApplicationUnderRegistraionReports() throws InterruptedException {
        LogCapture.info("User is validating if successful call to intuition is there");
        String vCorrelationId = Constants.AtlasRegistrationOR.getProperty("CorrelationId");
        Constants.key.pause("2", "");
        if (Constants.driver.findElement(By.xpath(vCorrelationId)).getText().contains("-")) {
            Assert.assertEquals("PASS", Constants.key.pause("10", ""));
            String vIntuitionStatus = Constants.AtlasRegistrationOR.getProperty("IntuitionStatus");
            String IntuitionStatusMsg = Constants.driver.findElement(By.xpath(vIntuitionStatus)).getText();
            Assert.assertEquals(IntuitionStatusMsg, "check");
            System.out.println("Call to intuition has been made");
        } else {
            System.out.println("Successful Call to intuition has been failed");
        }
    }

    @Then("^User clicks on Intuition correlation Id$")
    public void userClicksOnIntuitionCorrelationId() throws Exception {
        String IntuitionCorrelationId = Constants.AtlasRegistrationOR.getProperty("IntuitionCorrelationId");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(IntuitionCorrelationId, ""));
        Constants.key.click(IntuitionCorrelationId, "");
        LogCapture.info("User click on Intuition Correlation Id");
    }

    @Given("^User connects to UAT DB and fetches the Latest TradeAccountNumber$")
    public void userConnectsToUATDBAndFetchesTheLatestTradeAccountNumber() throws Exception {
        TradeAccountNumber= Constants.key.VerifyDBDetails("UAT", "", "Fetch TradeAccountNumber");
        System.out.println("Latest Trade Account Number : " + TradeAccountNumber);
        AccountID=Constants.key.VerifyDBDetails("UAT", "", "Fetch AccountID");
        System.out.println("Latest AccountID : " + AccountID);
        TradeContactID=Constants.key.VerifyDBDetails("UAT", TradeAccountNumber, "Fetch TradeContactID");
        System.out.println("Latest TradeContactID : " + TradeContactID);
    }

    @Then("^User verify card Decision status from Intuition$")
    public void userVerifyCardDecisionStatusFromIntuition() throws Exception {
        String IntuitionJsonResponse = Constants.AtlasRegistrationOR.getProperty("IntuitionJsonResponse");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(IntuitionJsonResponse, ""));
        String cardDecision = null;
        if (cardDecision =="Approve") {
            Assert.assertEquals("PASS", Constants.key.verifyText(IntuitionJsonResponse, "\"cardDecision\": \"Approved\""));
            System.out.println("Card is approved for this user");
        }
        else if(cardDecision =="Decline"){
            System.out.println("Card is decline for this user");
        }
    }


    @When("^User enter customer number for which card was applied$")
    public void userEnterCustomerNumberForWhichCardWasApplied() throws Exception {
        String vKeyword = Constants.AtlasRegistrationOR.getProperty("Atlas_enterSearchCriteriaKeyword");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, TradeAccountNumber));
    }
}


