package com.selenium.utillity;

import com.utility.LogCapture;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

import java.util.HashMap;
import java.util.Properties;

public class Constants {
    public static Reusables key;
    public static WebDriver driver;
    public static String KEYWORD_PASS = "PASS";
    public static String KEYWORD_FAIL = "FAIL";
    public static Properties CONFIG;
    public static Properties loginPageOR;
    public static Properties DashboardOR;
    public static Properties NewRateAlertOR;
    public static String RANDOM_VALUE = "";
    public static LogCapture logs;
    public static Properties TopupWalletOR;
    public static Properties MakeTransferOR;
    public static Properties TitanLoginOR;
    public static Properties CreateFxTicketOR;
    public static Properties AtlasloginOR;
    public static Properties AtlasDashboardOR;
    public static Properties AtlasPaymentInOR;
    public static Properties AtlasPaymentOutOR;
    public static Properties SFLoginOR;
    public static Properties LeadGenerationOR;
    public static Properties ProfileManagementOR;
    public static Properties SignUp;
    public static Properties HelpOR;
    public static Properties PaymentTrackingOR;
    public static String PTData;
    public static Properties CalypsologinPageOR;
    public static Properties FrenchDashboardOR;
    public static Properties OccupationGenericOR;
    public static Properties AtlasRegistrationOR;
    public static String JenkinsBrowser = System.getProperty("jenkinsBrowser");

    public static Properties DBCONFIG;

    public static XSSFWorkbook workbookRead=null;
    public static XSSFSheet sheetRead=null;
    public static Integer counter=0;
    public static String PASS = "PASSED";
    public static String FAIL = "FAILED";
    public static String SHEET_NAME = "";
    public static String ApplicationName = "Atlas";
    public static String UserStory = "";
    public static String ScenarioOutline="";
    public static String status="";

    public static String TradeContractNumber="";
    public static String TradeContactID="";
    public static String ACCESS_TOKEN="";
    public static String RESPONSE="";
    public static Properties CardApply;

    public static String TradeAccountNumber ="";
    public static String AccountID="";

}


