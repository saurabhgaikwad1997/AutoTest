
/*ClassName: Resuables.java
Date: 17/April/2020
Author: Saurabh Gadgil
Purpose of class: To implement generic methods, all resuable using Xpath and selenium for robust framework.*/

package com.selenium.utillity;

//import com.sun.org.apache.bcel.internal.Const;

import com.utility.LogCapture;
import gherkin.formatter.model.Range;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.path.json.JsonPath;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.DateTime;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.*;
//import java.security.Key;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.*;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
//import java.util.regex.Pattern;

import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.Constants.status;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
//import com.sun.org.apache.bcel.internal.Const;
//import com.sun.org.apache.bcel.internal.Const;

import org.sikuli.script.Key;
import org.sikuli.script.*;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;

public class Reusables {
    public String actual;
    public static String Email;
    public String ScreenshotFlag;
    String downloadFilesPath = System.getProperty("user.dir") + "\\Downloads\\";
    public String emailID;

    public boolean openBrowser(String object, String data) throws Exception {
        try {
            String oSName = System.getProperty("os.name");
            if (data.equalsIgnoreCase("Chrome")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/windows/Chrome/chromedriver.exe");
                    WebDriverManager.chromedriver().setup();
                    //System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver_old.exe");
                    Constants.driver = new ChromeDriver();
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((ChromeDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                } else {
                    //System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/linux/Chrome/chromedriver");
                    //System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
                    WebDriverManager.chromedriver().setup();
                    ChromeOptions options = new ChromeOptions();
                    options.setHeadless(true);
                    if (object.equalsIgnoreCase("SalesForce")) {
                        options.addArguments("--window-size=1536,753");
                    } else {
                        options.addArguments("--window-size=1920,1080");
                    }
                    options.addArguments("--disable-gpu");
                    options.addArguments("--disable-extensions");
                    options.setExperimentalOption("useAutomationExtension", false);
                    options.addArguments("--proxy-server='direct://'");
                    options.addArguments("--proxy-bypass-list=*");
                    options.addArguments("--start-maximized");
                    options.addArguments("--headless");
                    options.addArguments("--whitelisted-ips");
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    Constants.driver = new ChromeDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                    //options.addArguments("--no-sandbox");
                }
            } else if (data.equalsIgnoreCase("Firefox")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/windows/Firefox/geckodriver.exe");
                    WebDriverManager.firefoxdriver().setup();
                    File pathBinary = new File(System.getProperty("user.home") + "/AppData/Local/Mozilla Firefox/firefox.exe");
                    FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
                    //DesiredCapabilities desired = DesiredCapabilities.firefox();
                    FirefoxOptions options = new FirefoxOptions();
                    options.setBinary(firefoxBinary);
                    //desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
                    WebDriverManager.firefoxdriver().setup();
                    Constants.driver = new FirefoxDriver(options);
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((FirefoxDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                } else {
                    FirefoxBinary firefoxBinary = new FirefoxBinary();
                    firefoxBinary.addCommandLineOptions("--headless");
                    WebDriverManager.firefoxdriver().setup();
                    //System.setProperty("webdriver.gecko.driver", "/usr/local/bin/geckodriver");
                    FirefoxOptions options = new FirefoxOptions();
                    options.addArguments("--no-sandbox");
                    options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
                    options.setBinary(firefoxBinary);
                    Constants.driver = new FirefoxDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                }
            } else if (data.equalsIgnoreCase("Edge")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/windows/Edge/msedgedriver.exe");
                    WebDriverManager.edgedriver().setup();
                    Constants.driver = new EdgeDriver();
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((EdgeDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                    //takeSnapShot();
                    takeSnapShot();
                } else {
//                    System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/linux/Edge/msedgedriver");
                    System.setProperty("webdriver.edge.driver", "/usr/bin/edgedriver");
                    //WebDriverManager.edgedriver().setup();
                    EdgeOptions options = new EdgeOptions();
                    options.setHeadless(true);
                    if (object.equalsIgnoreCase("SalesForce")) {
                        options.addArguments("--window-size=1536,753");
                    } else {
                        options.addArguments("--window-size=1920,1080");
                    }
                    options.addArguments("--disable-gpu");
                    options.addArguments("--disable-extensions");
                    options.setExperimentalOption("useAutomationExtension", false);
                    options.addArguments("--proxy-server='direct://'");
                    options.addArguments("--proxy-bypass-list=*");
                    options.addArguments("--start-maximized");
                    options.addArguments("--headless");
                    options.addArguments("--whitelisted-ips");
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    Constants.driver = new EdgeDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                    //options.addArguments("--no-sandbox");
                }

            }
            takeSnapShot();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found...");
            takeSnapShot();
            return false;
        }
    }


    public String navigate(String object, String data) throws Exception {
        try {
            Constants.driver.navigate().to(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";

        }
        return KEYWORD_PASS;
    }

    public String writeInInput(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).sendKeys(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String click(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("actual value->>>>" + actual);
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String pause(String object, String data) throws NumberFormatException, InterruptedException {
        long time = (long) Double.parseDouble(object);
        Thread.sleep(time * 1000L);
        return KEYWORD_PASS;

    }


    public String getReportConfigPath() {
        String reportConfigPath = Constants.CONFIG.getProperty("reportConfigPath");
        if (reportConfigPath != null) return reportConfigPath;
        else
            throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
    }

    public String exist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String navigateSubMenu(String object, String data) throws Exception {
        try {
            WebElement ele = Constants.driver.findElement(By.xpath(object));
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", ele);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String isAlertPresent() {
        try {
            Alert alert = Constants.driver.switchTo().alert();
            System.out.println("Alert Message" + alert.getText());
            alert.accept();
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String clearText(String object) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).clear();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String VerifyTitle(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.getTitle();
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String VisibleConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, 120);
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String KeyboardAction(String object, String data) throws Exception {
        try {
            if (data.equalsIgnoreCase("enter")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("tab")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.TAB);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("space")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.SPACE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("downArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("selectall")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.chord(Keys.CONTROL, "a"));
                takeSnapShot();
            } else if (data.equalsIgnoreCase("delete")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.DELETE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("upArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_UP);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("esc")) {
                System.out.println("esc");
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ESCAPE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("backSpace")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.BACK_SPACE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("ctrl-a")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.chord(Keys.CONTROL, "a"));
                takeSnapShot();
            } else if (data.equalsIgnoreCase("page-down")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.PAGE_DOWN);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("end")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.END);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("Home")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.HOME);
                takeSnapShot();
            }


        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;

        }
        return Constants.KEYWORD_PASS;
    }


    public String verifyElementProperties(String object, String data) throws Exception {
        try {
            if (data.contains("disabled")) {
                String buttonDisabled = Constants.driver.findElement(By.xpath(object)).getAttribute("disabled");
                if (buttonDisabled != null) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " - Not Disabled";
                }
            } else if (data.contains("enabled")) {
                String buttonEnabled = Constants.driver.findElement(By.xpath(object)).getAttribute("enabled");
                if (buttonEnabled == null) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " - Not Enabled";
                }

            } else if (data.contains("visible")) {
                if (Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    //takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    //takeSnapShot();
                    return Constants.KEYWORD_FAIL + " -Not Displayed";
                }
            } else if (data.contains("unselected")) {
                if (!Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("selected")) {
                if (Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("Invisible")) {
                if (!Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " -Not Displayed";
                }
            } else if (data.contains("readonly")) {
                String readonly = Constants.driver.findElement(By.xpath(object)).getAttribute("readonly");
                if (readonly != null) {
                    takeSnapShot();
                    return Constants.KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return Constants.KEYWORD_FAIL + " - Not readonly";
                }

            } else if (data.contains("not present")) {
                int readonly = driver.findElements(By.xpath(object)).size();
                //takeSnapShot();
                if (readonly >= 1) {
                    return Constants.KEYWORD_FAIL + " - Not readonly";
                } else {
                    return Constants.KEYWORD_PASS;
                }

            } else if (data.contains("present")) {
                int readonly = driver.findElements(By.xpath(object)).size();
                //takeSnapShot();
                if (readonly < 1) {
                    return Constants.KEYWORD_FAIL + " - Not readonly";
                } else {
                    return Constants.KEYWORD_PASS;
                }

            }


        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + " -  Could not find element";

        }
        return Constants.KEYWORD_PASS;
    }

    public String notexist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_PASS;
        }
        return KEYWORD_FAIL + "object exist ";
    }

    public String randomWordGenerator(String object, int numberOfWords) throws Exception {
        try {
            String[] randomStrings = new String[numberOfWords];
            Random random = new Random();
            for (int i = 0; i < numberOfWords; i++) {
                char[] word = new char[random.nextInt(1) + 1]; // words of length 3 through 10. (1 and 2 letter words are boring.)
                for (int j = 0; j < word.length; j++) {
                    word[j] = (char) ('a' + random.nextInt(26));
                }
                randomStrings[i] = new String(word);

            }
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(2000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(randomStrings);

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String getText(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("Actual Length:->" + actual.length());
            }
            LogCapture.info("Actual:->" + actual);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return actual;

    }

    public String SelectDropDownValue(String object, String data) throws Exception {
        try {
            System.out.println("Object:->" + object);
            System.out.println("Data:->" + data);
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            objSelect.selectByVisibleText(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    public String MouseFunctions(String object, String data) throws Exception {
        try {
            WebElement Element = driver.findElement(By.xpath(object));
            Actions action = new Actions(Constants.driver);
            if (data.equalsIgnoreCase("clickAndHold")) {
                action.moveToElement(Element).build().perform();
                action.clickAndHold(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("ReleaseMouseClick")) {
                action.moveToElement(Element).build().perform();
                action.release(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("DoubleClick")) {
                action.doubleClick(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("MoveToElement")) {
                action.moveToElement(Element);
                action.perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("RightClick")) {
                action.contextClick(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("MoveToElementClick")) {
                action.moveToElement(Element).click();
                action.perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("click")) {
                action.click(Element).build().perform();
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to clickAndHold...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    /**
     * to get the text
     *
     * @return text from an element
     * @author Avleen
     * @since 2021-05-13
     */
    public String getText(String object) throws Exception {
        String actual = Constants.driver.findElement(By.xpath(object)).getText();
        return actual;
    }

    /**
     * to check if file is present in the directory
     *
     * @return true if file is present
     * @author Avleen
     * @since 2021-05-13
     */
    public boolean isFileDownloaded(String downloadPath, String fileName) throws Throwable {
        boolean flag = false;
        File dir = new File(downloadPath);
        File[] dir_contents = dir.listFiles();
        for (int i = 0; i < dir_contents.length; i++) {
            if (dir_contents[i].getName().equals(fileName)) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    /**
     * click on submit button and alert popup
     *
     * @return PASS if user click and handle alert successfully
     * @author Avleen
     * @since 2021-05-19
     */
    public String clickAndHandleAlert(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("5", "");
        } catch (UnhandledAlertException f) {
            try {
                Alert alert = driver.switchTo().alert();
                alert.accept();
                return KEYWORD_FAIL;
            } catch (NoAlertPresentException e) {
                e.printStackTrace();
            }
        }
        return KEYWORD_PASS;
    }

    /**
     * Wait for element to be clickable
     *
     * @param object the locator
     * @return PASS when element is clickable
     * @author Avleen
     * @since 2021-05-19
     */
    public String ClickableConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, 120);
            w.until(ExpectedConditions.elementToBeClickable(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    /**
     * Handle alert and return alert text
     *
     * @return Alert text when alert is present
     * @author Avleen
     * @since 2021-05-19
     */
    public String getAlertText() {
        String alertText = "";
        try {
            Alert alert = Constants.driver.switchTo().alert();
            alertText = alert.getText();
            alert.accept();
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return alertText;
    }

    /**
     * Remove spaces from a string
     *
     * @return String with no space
     * @author Avleen
     * @since 2021-05-20
     */
    public String removeSpaces(String data) {
        String noSpaceStr = data.replaceAll("\\s", "");
        return noSpaceStr;
    }

    /**
     * switch to child window
     *
     * @return true when successfully switched the window
     * @author Avleen
     * @since 2021-05-19
     */
    public String switchToWindow(String data) throws Throwable {
        String title;
        try {
            String mainWindowHandle = Constants.driver.getWindowHandle();
            Set<String> allWindowHandles = Constants.driver.getWindowHandles();
            Iterator<String> iterator = allWindowHandles.iterator();
            while (iterator.hasNext()) {
                String ChildWindow = iterator.next();
                if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
                    Constants.driver.switchTo().window(ChildWindow);
                    title = Constants.driver.switchTo().window(ChildWindow).getTitle();
                    System.out.println("Window title " + title);
                    if (title.equalsIgnoreCase(data)) {
                        LogCapture.info("User successfully verify window title" + title);
                        break;
                    }

                }
            }
            //Constants.driver.findElement(By.xpath(data)).click();
            return KEYWORD_PASS;

        } catch (Exception ex) {
            System.out.println(".....Switch window is not working...  " + ex);
            return KEYWORD_FAIL;
        }
    }


    /**
     * wait for element to be invisible
     *
     * @return PASS when element disappear from the page
     * @author Avleen
     * @since 2021-06-01
     */
    public String invisibleConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, 300);
            w.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }
    /**
     * upload file function
     *
     * @return PASS when file is uploaded successfully
     * @author Bhagyashri
     */

    /**
     * wait for Alert to be visible
     *
     * @return PASS when Alert is appeared on page
     * @author Shailendra
     * @since 2021-06-08
     */
    public String waitForAlert(int timeOutInSeconds) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, timeOutInSeconds);
            w.until(ExpectedConditions.alertIsPresent());
        } catch (UnhandledAlertException f) {
            try {
                WebDriverWait w = new WebDriverWait(Constants.driver, timeOutInSeconds);
                w.until(ExpectedConditions.alertIsPresent());
                return Constants.KEYWORD_FAIL;
            } catch (Exception e) {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "Alert not visible...." + e.getMessage();
            }
        }
        return Constants.KEYWORD_PASS;
    }

    /**
     * wait for Window to be visible
     *
     * @return true when new window is appeared on page
     * @author Shailendra
     * @since 2021-06-09
     */
    public boolean waitForNewWindow(int timeout) {
        boolean flag = false;
        int counter = 0;
        while (!flag) {
            try {
                Set<String> winId = driver.getWindowHandles();
                if (winId.size() > 1) {
                    flag = true;
                    return flag;
                }
                Thread.sleep(1000);
                counter++;
                if (counter > timeout) {
                    return flag;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return false;
            }
        }
        return flag;
    }

    /**
     * Return String of Specified Index at DropDown
     *
     * @return String
     * @author Shailendra
     * @since 2021-06-10
     */
    public String ValueOfIndexAt(String object, String data) throws Exception {
        try {
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            List<WebElement> list = objSelect.getOptions();
            String IndexValue = list.get(Integer.parseInt(data)).getText();
            System.out.println("Index Value At " + data + ":->" + IndexValue);
            takeSnapShot();
            return IndexValue;
        } catch (Exception e) {
            takeSnapShot();
            String IndexValue = "Drop Down Index Not Present....";
            return IndexValue + e.getMessage();
        }
    }

    public Integer RandomNumber(Integer data) throws Exception {
        Random rand = new Random();
        int value = rand.nextInt(data);
        return value;
    }

    /**
     * Verify Alert for Multiple PopUp in Page
     *
     * @return String
     * @author Shailendra
     * @since 2021-06-17
     */
    public String verifyAlertInLine(String Object, String ExpectedAlert) throws Exception {
        try {
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(Object, ""));
            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + ExpectedAlert);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(ExpectedAlert));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Alert Not Present...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    /**
     * Return PASS when file successfully uploaded
     *
     * @return String
     * @author Avleen
     * @since 2021-06-18
     */
    public String UploadFile(String object, String pahtToUpload) throws Exception {
        try {
            WebElement uploadElement = Constants.driver.findElement(By.xpath(object));
            uploadElement.sendKeys(pahtToUpload);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Drop Down Index Not Present...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;

    }

    public String getPageURL(String object, String data) throws Exception {
        String URL = "";
        try {
            Constants.key.pause("3", "");
            URL = driver.getCurrentUrl();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Unable to get URL...." + e.getMessage();
        }
        return URL;
    }

    public String VerifySubstring(String data, String data1) throws Exception {
        String match = "";
        try {
            if (data.contains(data1)) {
                match = Constants.KEYWORD_PASS;
            } else {
                match = Constants.KEYWORD_FAIL;
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + " " + data1 + " String is not in " + data + " String..." + e.getMessage();
        }
        return match;
    }

    /**
     * to delete downloaded file in the directory
     *
     * @return true if file is deleted
     * @author Avleen
     * @since 2021-07-07
     */
    public boolean FileDelete(String downloadPath, String fileName) throws Throwable {
        boolean flag = false;
        File dir = new File(downloadPath);
        File[] dir_contents = dir.listFiles();
        for (int i = 0; i < dir_contents.length; i++) {
            if (dir_contents[i].getName().equals(fileName)) {
                dir_contents[i].delete();
                flag = true;
                break;
            }
        }
        return flag;
    }


    public String SelectByValue(String object, String data) throws Exception {
        try {
            System.out.println("Object:->" + object);
            System.out.println("Data:->" + data);
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            objSelect.selectByValue(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }


    public String OpenDuplicateTab(String Path) throws Throwable {
        try {
            key.pause("3", "");
            String CopyURL = Constants.driver.getCurrentUrl();
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("window.open()");
            ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(tabs2.get(1));
            Constants.driver.get(CopyURL);
        } catch (Exception e) {
            e.printStackTrace();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String javascrpiptScroll(String object, String data) throws Exception {
        try {
            WebElement elem = Constants.driver.findElement(By.xpath(object));
            String js = "arguments[0].scrollIntoView();";
            ((JavascriptExecutor) Constants.driver).executeScript(js, elem);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String javascrpiptEnterText(String object, String data) throws Exception {
        try {
            WebElement element = driver.findElement(By.xpath(object));
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].value='" + data + "';", element);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String renameFileBnkManualUpload(String object, String data) throws Exception {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
            String dateString = format.format(new Date());
            String FolderPath = System.getProperty("user.dir") + "/Files/";
            //String FilePath = FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx";
            File f1 = new File(FolderPath + "ManualEntriesUpload.xlsx");
            File rename = new File(FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx");
            //File f2 = new File(rename);
            boolean b = f1.renameTo(rename);
            if (b == true) {
                System.out.println("File renamed successfully");
            } else {
                System.out.println("Operation failed");
            }
            //LogCapture.info("File Path is....." + FilePath);
            // LogCapture.info("Renamed file is....." + f2.getName());
            Constants.key.pause("8", "");
            WebElement uploadElement = Constants.driver.findElement(By.xpath(object));
            uploadElement.sendKeys(FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx");
            //driver.findElement(By.xpath("//input[@id='file']")).sendKeys((CharSequence) f2);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "File not uploaded or renamed " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String renameFileInFolder(String object, String data) throws Exception {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
            String dateString = format.format(new Date());
            String FolderPath = System.getProperty("user.dir") + "/Files/";
            //String FilePath = FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx";
            File f1 = new File(FolderPath + "ManualEntriesUpload.xlsx");
            File f2 = new File(FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx");
            //File f2 = new File(rename);
            boolean b = f1.renameTo(f2);
            if (b == true) {
                System.out.println("File renamed successfully");
            } else {
                System.out.println("Operation failed");
            }
            //LogCapture.info("File Path is....." + FilePath);
            // LogCapture.info("Renamed file is....." + f2.getName());
           /* Constants.key.pause("8", "");
            WebElement uploadElement = Constants.driver.findElement(By.xpath(object));
            uploadElement.sendKeys(FolderPath + "ManualEntriesUpload_" + dateString + ".xlsx");
            //driver.findElement(By.xpath("//input[@id='file']")).sendKeys((CharSequence) f2);*/
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "File not uploaded or renamed " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    /**
     * to delete downloaded file in the directory
     *
     * @return read Value from DB
     * @author Avleen
     * @since 2021-010-13
     */
    public String VerifyDBDetails(String environment, String data, String operationType) throws Exception {
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String Dealid = null;
        String vTradeContractNumber=null;
        String vTradeContactID=null;
        String query = null;
        String value = null;
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" +Constants.DBCONFIG.getProperty("SITDB_URL")+ ":" +Constants.DBCONFIG.getProperty("SITDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("SITDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" +Constants.DBCONFIG.getProperty("UATDB_URL")+ ":" +Constants.DBCONFIG.getProperty("UATDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
        }

//        try
//        {
        //LogCapture.info("try");
        //LogCapture.info("DB_URL->"+DB_URL);
        //LogCapture.info("DB_USER->"+DB_USER);
        //LogCapture.info("DB_PASSWORD->"+DB_PASSWORD);
        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        //String dbClass = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
        Class.forName(dbClass).newInstance();

        // Get connection to DB
        LogCapture.info("Get connection to DB");

        try (Connection connection = java.sql.DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)){
        if (connection != null) {
            LogCapture.info("Connected to DB");
        }

        if (operationType.equalsIgnoreCase("Verify Deal Details")) {
            query = "SELECT TOP 1 * FROM [Banking].dbo.MESSAGE_IN mi order by 1 desc";
            Statement stmt = connection.createStatement();
            ps = connection.prepareStatement(query);
            //ps.setNString(1, data);
            ResultSet res = stmt.executeQuery(query);

            while (res.next()) {
                Dealid = res.getString("ID");
                break;
                // System.out.println("OTP :" + OTP);
            }
            value = Dealid;
            System.out.println("deal id is" + value);
        } else if (operationType.equalsIgnoreCase("Fetch Latest Payment contract_number")) {

            query = "select top 1* from [Compliance].[Comp].PaymentIn where TradeContractNumber like '%" +data+ "%' order by CreatedOn desc";
            Statement stmt = connection.createStatement();
//            ps = connection.prepareStatement(query);
//            //ps.setNString(1, data);
            ResultSet res = stmt.executeQuery(query);
            // Get the contents of TradeContractNumber table from DB
            while (res.next()) {
                vTradeContractNumber = res.getString("TradeContractNumber");
                break;
                // System.out.println("OTP :" + OTP);
            }
            value = vTradeContractNumber;
            System.out.println("TradeContractNumber fetched is" + value);

        }
        else if(operationType.equalsIgnoreCase("Fetch TradeContactID")){
            query = "select TradeContactID from  [Compliance].[Comp].Contact where AccountID in (select ID from [Compliance].[Comp].Account where TradeAccountNumber='"+data+"')";
            Statement stmt = connection.createStatement();
//            ps = connection.prepareStatement(query);
//            //ps.setNString(1, data);
            ResultSet res = stmt.executeQuery(query);
            // Get the contents of TradeContractNumber table from DB
            while (res.next()) {
                vTradeContactID = res.getString("TradeContactID");
                break;
                // System.out.println("OTP :" + OTP);
            }
            value = vTradeContactID;
            System.out.println("TradeContactID fetched is" + value);}
        
          else if(operationType.equalsIgnoreCase("Fetch TradeAccountNumber")){
                query = "select top 1* from [Compliance].[Comp].[Account] where LegalEntity='CDLGB' and type=2 and AccountStatus='ACTIVE' order by CreatedOn desc";
                Statement stmt = connection.createStatement();
                ResultSet res = stmt.executeQuery(query);  // Get the contents of TradeAccountNumber table from DB         
            String vTradeAccountNumber = null;
            while (res.next()) {
                    vTradeAccountNumber = res.getString("TradeAccountNumber");
                    break;
                }
                value = vTradeAccountNumber;
                System.out.println("TradeAccountNumber fetched is" + value);
            }
            else if(operationType.equalsIgnoreCase("Fetch AccountID")){
                query = "select top 1* from [Compliance].[Comp].[Account] where LegalEntity='CDLGB' and type=2 and AccountStatus='ACTIVE' order by CreatedOn desc";
                Statement stmt = connection.createStatement();
                ResultSet res = stmt.executeQuery(query); // Get the contents of TradeContractNumber table from DB   
            String vTradeAccountID = null;
            while (res.next()) {
                    vTradeAccountID = res.getString("TradeAccountID");
                    break;
                }
                value = vTradeAccountID;
                System.out.println("TradeAccountID fetched is" + value);
            }
        } 
catch (Exception e) {

                LogCapture.error("Unable to connect to Database");
        }
        return value;

       /* } catch (Exception e) {
            System.out.println("Unable to do operation"+operationType+ "--"+ e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        } finally {
            // Close DB connection
            if (connection != null) {
                connection.close();
            }*/
        //}

    }

    // Pricing Enginee Reusables
    public String Mouse_Hover(String Object, String data) throws Exception {
        try {
            Actions action = new Actions(Constants.driver);
            WebElement we = Constants.driver.findElement(By.xpath(Object));
            action.moveToElement(we).build().perform();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public static void writeFullExcel(Object[][] bookData, Integer rowNum) throws IOException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String dateString = format.format(new Date());
        for (Object[] aBook : bookData) {
            Row row = Constants.sheetRead.createRow(++rowNum - 1);
            String statusObject = (String) bookData[0][3];
            CellStyle cs;
            int columnCount = -1;
            for (Object field : aBook) {
                Cell cell = row.createCell(++columnCount);
                if (field instanceof String) {
                    cs = Constants.workbookRead.createCellStyle();
                    if (status.equalsIgnoreCase("PASSED")) {
                        cs.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
                    } else if (status.equalsIgnoreCase("SKIPPED")) {
                        cs.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
                    } else if (status.equalsIgnoreCase("FAILED")) {
                        cs.setFillForegroundColor(IndexedColors.RED.getIndex());
                    } else if (status.equalsIgnoreCase("Status")) {
                        cs.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
                    } else {
                        System.out.println("Report Status doesn't match");
                        LogCapture.info("Report status doesn't match");
                    }
                    cs.setFillPattern(FillPatternType.FINE_DOTS);
                    cell.setCellValue((String) field);
                    cell.setCellStyle(cs);

                } else if (field instanceof Integer) {
                    cell.setCellValue((Integer) field);
                }
            }
        }

        try (FileOutputStream outputStream = new FileOutputStream(new File(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "Execution_Reports" + File.separator + "Execution_StatusReport.xlsx"))) {
            Constants.workbookRead.write(outputStream);
        }
    }

    /********************* ATLAS ****************************/
    public String Scroll(String object, String data) throws Exception {
        try {
            WebElement elem = Constants.driver.findElement(By.xpath(object));
            String js = "arguments[0].scrollIntoView();";
            String js1 = "window.scrollBy(0," + data + ")";
            ((JavascriptExecutor) Constants.driver).executeScript(js, elem);
            ((JavascriptExecutor) Constants.driver).executeScript(js1, elem);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String AltasRejectDropDown(String object, String data) throws Exception {
        try {
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            //System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 0; i < dropdown_list.size(); i++) {
                //System.out.println(dropdown_list.get(i).getText());
                if (dropdown_list.get(i).getText().contains(data)) {
                    for (int j = 1; j < 10000; j++) {
                        String vdata = Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).getText();
                        if (vdata.equals(data)) {
                            Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).click();
                            break;
                        }
                    }
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }

    /**************** Titan **********************/

    public String ClickIfEnable(String object, String data) throws Exception {
        try {
            int attempts = 0;
            int maxAttempts = 10;
            Constants.key.VisibleConditionWait(object, "");
            //        boolean buttonDisabled = false;
            while (attempts++ <= maxAttempts) {
                if (Constants.driver.findElement(By.xpath(object)).isEnabled()) {
                    Constants.driver.findElement(By.xpath(object)).click();
                    break;
                } else {
                    Thread.sleep(500);
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }


    public String selectOrganisationBussinessPartner(String object, String data) throws Exception {
        WebElement element = null;
        String vObjOrganisationBussinessPartner = "";
        try {
            for (int i = 0; i <= 100; i++) {

                if (object.equals("Organisation")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisations-" + i + "']";
                } else if (object.equals("Business Partner")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisation-business-partner-" + i + "']";
                }
                //LogCapture.info(vObjOrganisation);

                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisationBussinessPartner, ""));
                String abc = Constants.key.getText(vObjOrganisationBussinessPartner, "");
                //LogCapture.info(abc);

                if (abc.equalsIgnoreCase(data)) {
                    // LogCapture.info("inside");
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "MoveToElement"));
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "click"));
                    //element.findElement(By.xpath(vObjOrganisation)).click();
                    takeSnapShot();
                    break;
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable select" + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyOrganisationIntableCustomer(String object, String data, String column) throws Exception {
        int a = 0, b = 0;
        try {
            List<WebElement> itemsfiler = driver.findElements(By.xpath("//tbody[@id='accountSummaryTableBody']/tr"));
            int trnofilter = itemsfiler.size() + 1;
            //LogCapture.info("Total rows" +trnofilter);
            for (int s = 2; s < trnofilter; s++) {
                String organization = "//tbody[@id='accountSummaryTableBody']/tr[" + s + "]/td[" + column + "]/a[1]";
                String rowdata = Constants.driver.findElement(By.xpath(organization)).getText();
                //LogCapture.info("organization" +rowdata);
                if (rowdata.equals(data)) {
                    a = a + 1;
                } else {
                    b = b + 1;
                }
            }
            //LogCapture.info("Number of match rows->" +a);
            //LogCapture.info("Number of unmatch rows->" +b);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "something went wrong while fetching data " + e.getMessage();
        }
        if (b > 0) {
            return KEYWORD_FAIL;
        } else {
            return KEYWORD_PASS;
        }
    }

    public String scrollIntoViewElement(String object, String data) throws Exception {
        try {
            WebElement vObject = Constants.driver.findElement(By.xpath(object));
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView", vObject);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String defaultDownloadFilesOperations(String object, String data) {
        try {
            if (object.equalsIgnoreCase("deleteAllFiles")) {
                try {
                    LogCapture.info("All files deleted present in directory: " + downloadFilesPath);
                    FileUtils.cleanDirectory(new File(downloadFilesPath));
                } catch (IOException e) {
                }
            } else if (object.equalsIgnoreCase("deleteSelectedFile")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        dir_contents[i].delete();
                        LogCapture.info(data + " file deleted..");
                        LogCapture.info("Number of files got deleted: " + i);
                    }
                }
            } else if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        LogCapture.info(data + " file downloaded..");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String fileDownload(String object, String data) throws Exception {
        try {
            Screen src = new Screen();
            Pattern fileInputTextBox = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "FileTextBox.png");
            LogCapture.info(String.valueOf(fileInputTextBox));
            src.type(Key.BACKSPACE);
            src.type(fileInputTextBox,System.getProperty("user.dir") +File.separator+ "Exceldownload"+File.separator+data);
//            src.type(fileInputTextBox, data);
            Pattern saveButton = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "SaveButton.png");
            LogCapture.info(String.valueOf(saveButton));
            src.click(saveButton);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    //
    public String fileDownloadOperations(String object, String data) {
        File file = new File(System.getProperty("user.dir") + File.separator + "DownloadedFiles" + File.separator + data);
        try {
            if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                if (file.exists())
                    System.out.println("File Exists on given path : " + data);
                else
                    System.out.println("File Does not Exists on given path");
            } else if (object.equalsIgnoreCase("deleteDownloadedFile")) {
                if (file.delete())
                    System.out.println("File deleted : " + data);
                else
                    System.out.println("File was not deleted");
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    /******************** Affiliates **************************/


    public String generateRandomString(String object, String data) throws Exception {
        String randomString = "";
        try {
            int leftLimit = 97; // letter 'a'
            int rightLimit = 122; // letter 'z'
            int targetStringLength = 10;
            Random random = new Random();
            StringBuilder buffer = new StringBuilder(targetStringLength);
            for (int i = 0; i < targetStringLength; i++) {
                int randomLimitedInt = leftLimit + (int)
                        (random.nextFloat() * (rightLimit - leftLimit + 1));
                buffer.append((char) randomLimitedInt);
            }
            String generatedString = buffer.toString();
            System.out.println(generatedString);
            randomString = generatedString;
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return randomString;
    }

    //1. DatePicker is a function
    //2. Parameter will be three
    //a. Random date(Between min and max)
    //b. MinDate
    //c.maximum date
    public String datePicker(String object, String data) throws Exception {
        try {
            //Create a Calendar Object
            Date date = new Date();
            Calendar calendar = Calendar.getInstance();
            // SimpleDateFormat CurrentMonth= new SimpleDateFormat()
            calendar.setTime(date);
            //Get Current Day as a number
            int todayDayInt = calendar.get(Calendar.DAY_OF_MONTH);
            System.out.println("Today Int: " + todayDayInt + "\n");
            //Integer to String Conversion
            String todayDayStr = Integer.toString(todayDayInt);
            System.out.println("Today Str: " + todayDayStr + "\n");
            //Getting current month
            LocalDate today = LocalDate.now();
            int todayMonthInt = today.getMonthValue();
            String monthName = DateTime.now().withMonthOfYear(todayMonthInt).toString("MMMMMMMMMMMM");
            System.out.println(monthName);
            //Get Current Day as a number
            System.out.println("Current Month Int: " + todayMonthInt + "\n");
            //Integer to String Conversion
            String todayMonthStr = Integer.toString(todayMonthInt);
            System.out.println("Current Month Str: " + todayMonthStr + "\n");
            //Getting Current year
            int todayYearInt = calendar.get(Calendar.YEAR);
            System.out.println("Current Year Int: " + todayYearInt + "\n");
            //Click on calendar
            //Constants.key.MouseFunctions(object, "DoubleClick");
            //Constants.key.navigateSubMenu(object, "");
            Constants.key.click(object, "");
            //Click on year and navigate to particular year
            // String vDefaultYear = Constants.Affiliates_RegisterACustomerOR.getProperty("DefaultYear");
            int MaxYear = todayYearInt - 100; //Maximum Visible year
            int AboveMaxYear = todayYearInt - 101;
            int BelowMaxYear = todayYearInt - 99;
            int MinYear = todayYearInt - 18; //Minimum age limit for DOB is 18 years
            int BelowMinYear = todayYearInt - 17;
            int AboveMinYear = todayYearInt - 19;
            int RandomYearSelection = 0;
            if (data.equalsIgnoreCase("Random")) {
                RandomYearSelection = MinYear + (int) (Math.random() * (MaxYear - MinYear + 1));
            } else if (data.equalsIgnoreCase("MaxYear")) {
                RandomYearSelection = MaxYear;
            }
     /*else if(data.equalsIgnoreCase("BelowMaxYear")){
     RandomYearSelection=BelowMaxYear;
     }*/
            else if (data.equalsIgnoreCase("MinYear")) {
                RandomYearSelection = MinYear;
            }
        /*else if(data.equalsIgnoreCase("AboveMinYear")){
            RandomYearSelection=AboveMinYear;
        }*/
            System.out.println("Random year: " + RandomYearSelection);
            String vDefaultYear = "//button//parent::span//child::h6";
            Constants.key.pause("2", "");
            //Constants.key.navigateSubMenu(vDefaultYear, "");
            // Constants.driver.findElement(By.xpath(vDefaultYear)).click();
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDefaultYear, ""));
            Assert.assertEquals("PASS", Constants.key.click(vDefaultYear, ""));
            // int DOBYearInt = Constants.key.YearSelectionValidation();
            String DOB_YearStr = Integer.toString(RandomYearSelection);
            String YearSelection = "//div[text()='" + DOB_YearStr + "']";
            WebElement DOB_Year = Constants.driver.findElement(By.xpath(YearSelection));
            //Constants.key.navigateSubMenu(YearSelection, "");
            JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
            js.executeScript("arguments[0].scrollIntoView(true);", DOB_Year);
            DOB_Year.click();
            Constants.key.pause("1", "");
            //Constants.driver.findElement(By.xpath("//div[starts-with(@class,'MuiPickersCalendarHeader-switchHeader')]//child::p"));
            //     Constants.Affiliates_RegisterACustomerOR.getProperty("DefaultDate");
            String DefaultDate = "//div[starts-with(@class,'MuiPickersCalendarHeader-switchHeader')]//child::p";
            String DefaultMonthDateText = Constants.driver.findElement(By.xpath(DefaultDate)).getText();
            //PreviousMonthNavigation
            String PreviousMonthNavigation = "//div[starts-with(@class,'MuiPickersCalendarHeader-switchHeader')]//child::button[1]";
            //NextMonthNavigation
            String NextMonthNavigation = "//div[starts-with(@class,'MuiPickersCalendarHeader-switchHeader')]//child::button[2]";
        /*
if(DefaultMonthDateText.equalsIgnoreCase(monthName+" "+DOB_YearStr)){

    if (data.equalsIgnoreCase("MaxYear")) {

        int MaxYearInvalidDate = todayDayInt - 1;
        System.out.println("USer is not MAx year loop...and invalid date: "+MaxYearInvalidDate);
        String DOB_MaxYearInvalidDate = Integer.toString(MaxYearInvalidDate);
        if (DOB_MaxYearInvalidDate.equalsIgnoreCase("0")) {
            String DOB_InvalidDate = "1";
            String DOB_MaxYearInvalidDatePath = "//p[text()='" + DOB_InvalidDate + "']/parent::span//parent::button[@tabindex='0']";
            Assert.assertEquals("PASS", Constants.key.notexist(DOB_MaxYearInvalidDatePath, ""));
            System.out.println("Invalid Greyout date: "+DOB_InvalidDate+"verified.....");
        } else {
            String DOB_MaxYearInvalidDatePath = "//p[text()='" + DOB_MaxYearInvalidDate + "']/parent::span//parent::button[@tabindex='0']";
            Assert.assertEquals("PASS", Constants.key.notexist(DOB_MaxYearInvalidDatePath, ""));
            System.out.println("Invalid Greyout date: "+DOB_MaxYearInvalidDate+" verified.....");
        }
    }
         if (data.equalsIgnoreCase("MinYear")) {
             int MinYearInvalidDate = todayDayInt + 1;
             String DOB_MinYearInvalidDate = Integer.toString(MinYearInvalidDate);
             if ((calendar.DAY_OF_YEAR) > 365) {
                 if (monthName.equalsIgnoreCase("February")) {
                     if (DOB_MinYearInvalidDate.equalsIgnoreCase("30")) {
                         String DOB_InvalidDate = "1";
                         String DOB_MinYearInvalidDatePath = "//p[text()='" + DOB_InvalidDate + "']/parent::span//parent::button[@tabindex='-1']";
                         List<WebElement> AllDates = driver.findElements(By.xpath(DOB_MinYearInvalidDatePath));
                         for (int i = 0; i < AllDates.size(); i++) {
                             WebElement AllDateStrng = AllDates.get(i);

                           Constants.driver.findElement(By.xpath(AllDateStrng), "");
                         }
                         Assert.assertEquals("PASS", Constants.key.notexist(DOB_MinYearInvalidDatePath, ""));
                     } else {
                         String DOB_MinYearInvalidDatePath = "//p[text()='" + DOB_MinYearInvalidDate + "']/parent::span//parent::button[@tabindex='0']";
                         Assert.assertEquals("PASS", Constants.key.notexist(DOB_MinYearInvalidDatePath, ""));
                     }
                 }

             }
             if ((calendar.DAY_OF_YEAR) <= 365) {
                 if (monthName.equalsIgnoreCase("February")) {
                     if (DOB_MinYearInvalidDate.equalsIgnoreCase("29")) {
                         String DOB_InvalidDate = "1";
                         String DOB_MinYearInvalidDatePath = "//p[text()='" + DOB_InvalidDate + "']/parent::span//parent::button[@tabindex='-1']";
                         Constants.driver.findElements(By.xpath(DOB_MinYearInvalidDatePath));
                     }
                 }
                 else{
                     if((todayMonthInt % 2)==0){

                     }
                     if (DOB_MinYearInvalidDate.equalsIgnoreCase("32")) {
                         String DOB_InvalidDate = "31";
                         String DOB_MinYearInvalidDatePath = "//p[text()='" + DOB_InvalidDate + "']/parent::span//parent::button[@tabindex='0']";
                         Assert.assertEquals("PASS", Constants.key.notexist(DOB_MinYearInvalidDatePath, ""));
                     } else {
                         String DOB_MaxYearInvalidDatePath = "//p[text()='" + DOB_MinYearInvalidDate + "']/parent::span//parent::button[@tabindex='0']";
                         Assert.assertEquals("PASS", Constants.key.notexist(DOB_MaxYearInvalidDatePath, ""));
                     }
                 }

             }


         }
}*/
            if (DefaultMonthDateText.equalsIgnoreCase("January " + DOB_YearStr)) {
                //String DOB_Month = Constants.key.getCurrentMonth();
                System.out.println("Month need to select: " + todayMonthStr);
                switch (todayMonthStr) {
                    case "1":
                        String SelectedMonthJan = "January " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthJan));
                        LogCapture.info("Selected January month");
                        break;
                    case "2":
                        for (int i = 1; i < 2; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthFeb = "February " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthFeb));
                        LogCapture.info("Selected February Month");
                        break;
                    case "3":
                        for (int i = 1; i < 3; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthMarch = "March " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthMarch));
                        LogCapture.info("Selected March Month");
                        break;
                    case "4":
                        for (int i = 1; i < 4; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthApr = "April " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthApr));
                        LogCapture.info("Selected April Month");
                        break;
                    case "5":
                        for (int i = 1; i < 5; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthMay = "May " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthMay));
                        LogCapture.info("Selected May Month");
                        break;
                    case "6":
                        for (int i = 1; i < 6; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthJune = "June " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthJune));
                        LogCapture.info("Selected June Month");
                        break;
                    case "7":
                        for (int i = 1; i < 7; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthJuly = "July " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthJuly));
                        LogCapture.info("Selected July Month");
                        break;
                    case "8":
                        for (int i = 1; i < 8; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthAug = "August " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthAug));
                        LogCapture.info("Selected August Month");
                        break;
                    case "9":
                        for (int i = 1; i < 9; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthSep = "September " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthSep));
                        LogCapture.info("Selected September Month");
                        break;
                    case "10":
                        for (int i = 1; i < 10; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthOct = "October " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthOct));
                        LogCapture.info("Selected October Month");
                        break;
                    case "11":
                        for (int i = 1; i < 11; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthNov = "November " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthNov));
                        LogCapture.info("Selected November Month");
                        break;
                    case "12":
                        for (int i = 1; i < 12; i++) {
                            Constants.key.click(NextMonthNavigation, "");
                            Constants.key.pause("1", "");
                        }
                        Constants.key.pause("1", "");
                        String SelectedMonthDec = "December " + DOB_YearStr;
                        Assert.assertEquals("PASS", Constants.key.verifyText(DefaultDate, SelectedMonthDec));
                        LogCapture.info("Selected December Month");
                        break;
                }

            }

            //Click on particular date
            // String SelectDate = Constants.key.getCurrentDay();
            String DOB_Date = "//p[text()='" + todayDayStr + "']/parent::span//parent::button[@tabindex='0']";
            Constants.driver.findElement(By.xpath(DOB_Date)).

                    click();
            Constants.key.pause("2", "");
            System.out.println("Date selected: " + todayDayStr);

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to Click on Date...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }


    public String VerifyAllDropDownValues(String sheetName, String colName, String object) throws Exception {
        System.out.println("start");
        String fileName = System.getProperty("user.dir") + "/TestData.xlsx";
        File file = new File(fileName);
        FileInputStream inputStream = new FileInputStream(file);
        String fileExtensionName = fileName.substring(fileName.indexOf("."));
        System.out.println("end");
        if (fileExtensionName.equals(".xlsx")) {
            System.out.println("if");
            Workbook DropDownworkbook = null;
            DropDownworkbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = (XSSFSheet) DropDownworkbook.getSheet(sheetName);
            XSSFRow row;
            XSSFCell cell;
            String CellValue = null;
            try {
                int col_Num = -1;
                row = sheet.getRow(0);
                System.out.println("Ronumber" + row);
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    if (row.getCell(j).getStringCellValue().trim().equals(colName.trim())) {
                        col_Num = j;
                        System.out.println("ColNum" + col_Num);
                        //row= sheet.getRow(j);
                        for (int i = 1; i < sheet.getLastRowNum(); i++) {
                            row = sheet.getRow(i);
                            cell = row.getCell(col_Num);
                            if (cell.getStringCellValue().equalsIgnoreCase("")) {
                                System.out.println("Empty Value");
                            } else {
                                if (cell.getCellTypeEnum() == CellType.STRING) {
                                    CellValue = cell.getStringCellValue();
                                    System.out.println("Value" + CellValue);
                                    // return CellValue;
                                } else if (cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA) {
                                    CellValue = String.valueOf(cell.getNumericCellValue());
                                    if (HSSFDateUtil.isCellDateFormatted(cell)) {
                                        DateFormat df = new SimpleDateFormat("dd/MM/yy");
                                        Date date = cell.getDateCellValue();
                                        CellValue = df.format(date);
                                    }
                                    // return CellValue;
                                } else if (cell.getCellTypeEnum() == CellType.BLANK) {
                                    CellValue = "";
                                    //return CellValue;
                                } else if (cell.getBooleanCellValue()) {
                                    CellValue = String.valueOf(cell.getBooleanCellValue());
                                    //return CellValue;
                                } else if (!cell.getBooleanCellValue()) {
                                    CellValue = String.valueOf(cell.getBooleanCellValue());
                                    //return CellValue;
                                }
                            }
                            // return CellValue;
                            System.out.println("Value is: " + CellValue);
                            Constants.driver.findElement(By.xpath(object)).clear();
                            Constants.driver.findElement(By.xpath(object)).click();
                            //Constants.driver.findElement(By.xpath(object)).clear();
                            Constants.driver.findElement(By.xpath(object)).sendKeys(CellValue);
                            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                            takeSnapShot();
                            Constants.key.pause("2", "");
                            //String vCD_PhoneNumber = Constants.Refer_a_Client.getProperty("CD_PhoneNumber");
                            //Constants.key.click(vCD_PhoneNumber, "");
                            String fotter = object + "//following::p[contains(@class,'MuiTypography-body1')][1]";
                            //System.out.println(fotter);
                            Constants.driver.findElement(By.xpath(fotter)).click();
                            Constants.key.pause("2", "");
                            String ActualDropDownValuetrim = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                            String ActualDropDownValue = ActualDropDownValuetrim.trim();
                            // System.out.println("Actual DropDown Value is: " + ActualDropDownValue);
                            //Is assert correct or need to put it into try catch block???
                            if (ActualDropDownValue.equals(CellValue)) {
                                System.out.println("ActualValue: " + ActualDropDownValue + " Matched ExpectedValue: " + CellValue);

                            } else {
                                System.out.println("ActualValue: " + ActualDropDownValue + " NOT Matched ExpectedValue: " + CellValue);
                                break;
                            }
                            // return "row " + rowNum + " or column " + colName + " does not exist  in Excel";
                        }


                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                return "data not found";
            }

        } else {
            Workbook DropDownworkbook = null;
            DropDownworkbook = new HSSFWorkbook(inputStream);
            HSSFSheet sheet = (HSSFSheet) DropDownworkbook.getSheet(sheetName);
            HSSFRow row = null;
            HSSFCell cell = null;
            String CellValue = null;
            try {
                int col_Num = -1;
                row = sheet.getRow(0);
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    if (row.getCell(j).getStringCellValue().trim().equals(colName.trim())) {
                        col_Num = j;
                        row = sheet.getRow(j);
                        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                            row = sheet.getRow(i);
                            cell = row.getCell(col_Num);
                            if (cell.getCellTypeEnum() == CellType.STRING) {
                                CellValue = cell.getStringCellValue();
                                System.out.println("Value" + CellValue);
                                // return CellValue;
                            } else if (cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA) {
                                CellValue = String.valueOf(cell.getNumericCellValue());
                                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                                    DateFormat df = new SimpleDateFormat("dd/MM/yy");
                                    Date date = cell.getDateCellValue();
                                    CellValue = df.format(date);
                                }
                                // return CellValue;
                            } else if (cell.getCellTypeEnum() == CellType.BLANK) {
                                CellValue = "";
                                //return CellValue;
                            } else if (cell.getBooleanCellValue()) {
                                CellValue = String.valueOf(cell.getBooleanCellValue());
                                //return CellValue;
                            } else if (!cell.getBooleanCellValue()) {
                                CellValue = String.valueOf(cell.getBooleanCellValue());
                                //return CellValue;
                            }
                            System.out.println("Value is: " + CellValue);
                            Constants.driver.findElement(By.xpath(object)).click();
                            //Constants.driver.findElement(By.xpath(object)).clear();
                            Constants.driver.findElement(By.xpath(object)).sendKeys(CellValue);
                            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                            takeSnapShot();
                            String vCD_PhoneNumber = "//p[text()='+44 (0) 20 7847 9400']";
                            Constants.driver.findElement(By.xpath(vCD_PhoneNumber)).click();
                            //Constants.Refer_a_Client.getProperty("CD_PhoneNumber");
                            // Constants.key.click(vCD_PhoneNumber, "");
                            String ActualDropDownValue = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                            // System.out.println("Actual DropDown Value is: " + ActualDropDownValue);
                            //Is assert correct or need to put it into try catch block???
                            if (CellValue.equals(ActualDropDownValue)) {
                                Assert.assertEquals("PASS", Constants.key.verifyText(object, CellValue));
                                System.out.println("ActualValue: " + ActualDropDownValue + " Matched ExpectedValue: " + CellValue);

                            } else {
                                System.out.println("ActualValue: " + ActualDropDownValue + " NOT Matched ExpectedValue: " + CellValue);

                            }

                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Data not found...";
            }
        }
        return "row " + " or column " + colName + " does not exist  in Excel";
    }


    public String verifyInnerText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getAttribute("innerText");
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return Constants.KEYWORD_PASS;
            } else {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }


    public String WaitElementToBeVisible(String object, String data) throws Exception {
        WebDriverWait wait = new WebDriverWait(driver, 60);
        if (data.equalsIgnoreCase("VisibilityOf")) {
            try {
                WebElement element = wait.until(ExpectedConditions.visibilityOf(Constants.driver.findElement(By.xpath(object))));
                System.out.println("object exist" + element.isDisplayed());
                takeSnapShot();
            } catch (Exception e) {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "object does not exist " + e.getMessage();
            }

        }
        return Constants.KEYWORD_PASS;

    }


    public String verifyLinkText(String object, String data) throws Exception {
        try {
            String LinkObjectText = Constants.driver.findElement(By.xpath(object)).getText();
            String actual = Constants.driver.findElement(By.linkText(LinkObjectText)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.linkText(LinkObjectText)).getAttribute("value");
            }
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(data)) {
                takeSnapShot();
                return Constants.KEYWORD_PASS;
            } else {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "...Link text not verified " + actual + "  " + data;
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Link not found...." + e.getMessage();
        }

    }


    public String EnterOtp(String object, String data) throws Exception {
        try {
            int i = 0;
            List<WebElement> ele = driver.findElements(By.xpath(object));
            for (WebElement e : ele) {
                e.sendKeys(data.charAt(i) + "");
                i++;
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return Constants.KEYWORD_PASS;
    }


    public String InVisibleConditionWaitWithText(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, 10);
            w.until(ExpectedConditions.invisibilityOfElementWithText(By.xpath(object), data));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_PASS;
        }
        return Constants.KEYWORD_FAIL;
    }


    public String RefreshPage(String object, String data) throws Exception {
        try {
            Constants.driver.navigate().refresh();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }


    public String SelectDropDownAllValues(String object, String data) throws Exception {
        try {
            Constants.key.pause("2", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i <= dropdown_list.size(); i++) {
                System.out.println(dropdown_list.get(i).getText());
                Constants.driver.findElement(By.xpath("//*[contains(@class,'is-active')]//ul//li[" + i + "]")).click();
                if (i == dropdown_list.size() - 1) {
                    System.out.println(i);
                    break;
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return Constants.KEYWORD_PASS;
    }

    public int getCurrentYear() {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int todayYearInt = calendar.get(Calendar.YEAR);
        return todayYearInt;
    }

    public int getPreviousYear() {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int todayYearInt = calendar.get(Calendar.YEAR);
        return (todayYearInt - 1);
    }

    public Month getCurrentMonth() {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        LocalDate today = LocalDate.now();
        Month todayMonthStr = today.getMonth();
        Month month = todayMonthStr.of(calendar.get(Calendar.MONTH));
        System.out.println("Current Month Str: " + month + "\n");
        return month;
    }

    public String verifyFontProperties(String object, String properties, String data) throws Exception {
        try {
            WebElement TextElement = driver.findElement(By.xpath(object));
            String fontProperties = null;
            fontProperties = TextElement.getCssValue(properties);
            if (fontProperties.equals(data)) {
                LogCapture.info("Font Properties Verified: " + properties + " = " + data);
                takeSnapShot();
            } else {
                LogCapture.info("Font Properties NOT Verified: " + properties + " = " + data);
                takeSnapShot();
                return Constants.KEYWORD_FAIL;
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + " -  Could not find element";

        }
        return Constants.KEYWORD_PASS;
    }


    public String ValidateWebtablePagination(String object, String data) throws Exception {
        try {
            List<WebElement> rowsCounts = driver.findElements(By.xpath(object));
            //int pagecounts=pagecount.size();
            System.out.println("Row Size" + rowsCounts.size());
            List<String> details = new ArrayList<String>();
            for (WebElement rowsCount : rowsCounts) {
                details.add(rowsCount.getText());
            }
            String nextButton = driver.findElement(By.xpath("//*[@aria-label='Go to next page']")).getAttribute("class");
            while (!nextButton.contains("Mui-disabled")) {
                int totalentries = details.size();
                System.out.println("Total Entries" + totalentries);
                int No_Of_Pages = totalentries / 10;
                driver.findElement(By.xpath("//*[@aria-label='Go to next page']")).click();
                rowsCounts = driver.findElements(By.xpath("//*[@class='MuiTableBody-root']/tr"));
                for (WebElement rowsCount : rowsCounts) {
                    details.add(rowsCount.getText());
                    // int noRows=Integer.parseInt(rowsCount.getText());
                    if ((rowsCounts.size() / 10 <= No_Of_Pages) && (rowsCounts.size() % 10 == 0)) {
                        System.out.println("TenRecord Present on Page");
                        for (String detail : details) {
                            // System.out.println(detail);
                        }
                    } else
                        System.out.println("Record Present on Last Page" + rowsCounts.size() % 10);
                }
                nextButton = driver.findElement(By.xpath("//*[@aria-label='Go to next page']")).getAttribute("class");
            }
            for (String detail : details) {
                // System.out.println(detail);
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }


    public String verifyHrefText(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getAttribute("href");
            if (actual.length() < 1) {
                String actual = Constants.driver.findElement(By.xpath(object)).getText();
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data   value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return Constants.KEYWORD_PASS;
            } else {
                takeSnapShot();
                return Constants.KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String navigateWithSpecialCharacterCookies(String object, String data) throws Exception {
        try {
            //takeSnapShotOnFailure();
            Constants.driver.navigate().to(data);
            Cookie name = new Cookie("MyCookie!@#$%&", "123456");
            Constants.driver.manage().addCookie(name);
            // After adding the cookie we will check that by displaying all the cookies.
            Set<Cookie> cookiesList = Constants.driver.manage().getCookies();
            for (Cookie getcookies : cookiesList) {
                System.out.println(getcookies);
            }
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "...not able to navigate";

        }
        return Constants.KEYWORD_PASS;
    }

    public String splitAndCompare(String object, String data) throws Exception {
        try {

            String rowValues[] = data.split(",");
            List<WebElement> ele = driver.findElements(By.xpath(object));
            int cnt = 0;
            for (WebElement e : ele) {
                String portalColumnValue = e.getText().replaceAll(",", "").trim();
                String expectedColumnValue = rowValues[cnt].trim();
                cnt++;
                Assert.assertEquals(portalColumnValue, expectedColumnValue);
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return Constants.KEYWORD_PASS;
    }

    /*************************  PFX CFX   ***************************************/

    public String javascriptWriteInInput(String object, String data) throws Exception {
        try {
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].value='" + data + "'", Constants.driver.findElement(By.xpath(object)));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String selectList(String object, String data) throws Exception {
        try {
            int attempt = 0;
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            if (!data.equals(Constants.RANDOM_VALUE)) {
                objSelect.selectByVisibleText(data);
                takeSnapShot();
            } else {
                WebElement droplist = Constants.driver.findElement(By.xpath(object));
                List<WebElement> droplist_contents = droplist.findElements(By.tagName("option"));
                Random num = new Random();
                int index = num.nextInt(droplist_contents.size());
                String selectedVal = droplist_contents.get(index).getText();
                objSelect.selectByVisibleText(selectedVal);
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "---Could not select from the List---" + e.getMessage();

        }
        return KEYWORD_PASS;
    }

    public String SelectRecipient(String object, String data) throws Exception {
        try {
            LogCapture.info("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'Select')]");
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'Select')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String RecipientTransfer(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Transfer')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String RecipientPay(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Pay')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String uniqueEmailID(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            String emailID = "AutoTestUser" + userName + "@gmail.com";

            LogCapture.info("emailID start with xyz is " + ": " + emailID);

            //System.out.println("Result......" + emailID);
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(1000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(emailID);
            // Constants.driver.findElement(By.xpath(object)).sendKeys("autotestuser213440261@gmail.com");
            Email = Constants.driver.findElement(By.xpath(object)).getText();
            System.out.println("AutoTestUser Email ID" + Email);
            Thread.sleep(1000);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String uniqueEmailAddress(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            emailID = "xyz" + userName + "@gmail.com";

            LogCapture.info("emailID is " + ": " + emailID);


        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return emailID;
    }

    public String ClickEachElementOfFrame(String object, String data) throws Exception {
        try {
            //    List<WebElement> Elements = driver.findElements(By.cssSelector(object));
            List<WebElement> Elements = Constants.driver.findElements(By.xpath(object));
            ListIterator<WebElement> ListOfElements = Elements.listIterator();
            while (ListOfElements.hasNext()) {
                WebElement elem = ListOfElements.next();
                // do something with elem
                elem.click();
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String Mouse_Events(String Object, String data) throws Exception {

        try {
            Actions build = new Actions(Constants.driver);
            build.moveToElement(Constants.driver.findElement(By.xpath(Object))).moveByOffset(11, 11).click().build().perform();
        } catch (Exception e) {
            takeSnapShot();
            return
                    KEYWORD_FAIL;
        }
        return
                KEYWORD_PASS;
    }

    public String Enter_OTP(String object, String data) throws Exception {
        try {
            List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
            for (WebElement input : inputs) {
                input.clear();
                input.sendKeys(data);
                break;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String writeInInputObO(String object, String data) throws Exception {
        try {
            String val = data;
            WebElement element = Constants.driver.findElement(By.xpath(object));
            element.clear();
            for (int i = 0; i < val.length(); i++) {
                char c = val.charAt(i);
                String s = new StringBuilder().append(c).toString();
                element.sendKeys(s);
                Thread.sleep(2000);
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write one by one " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public static String[] generateRandomWords(int numberOfWords) {
        String[] randomStrings = new String[numberOfWords];
        Random random = new Random();
        for (int i = 0; i < numberOfWords; i++) {
            char[] word = new char[random.nextInt(8) + 3]; // words of length 3 through 10. (1 and 2 letter words are boring.)
            for (int j = 0; j < word.length; j++) {
                word[j] = (char) ('a' + random.nextInt(26));
            }
            randomStrings[i] = new String(word);
        }
        return randomStrings;
    }


    public String DeleteRecipient(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'x')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String selectPTRecord(String object, String innerObject, String data) throws Exception {
        try {
            List<WebElement> listElements = Constants.driver.findElements(By.xpath(object));
            for (int i = 0; i < listElements.size(); i++) {
                if (i % 5 == 0) {
                    click(Constants.PaymentTrackingOR.getProperty("ShowMoreButton"), "");
                }
                WebElement element = listElements.get(i);
                element.click();
                Thread.sleep(2000);
                try {
                    WebElement referenceElement = element.findElement(By.xpath(innerObject));
                    if (referenceElement != null) {
                        referenceElement.click();
                        LogCapture.info("Record displayed on PT dashboard =" + referenceElement.getText());
                        takeSnapShot();
                        return KEYWORD_PASS;
                    }
                } catch (Exception e) {
                    LogCapture.info(e.getMessage());
                }
            }
            return KEYWORD_FAIL + "Record is not displayed on PT dashboard";

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
    }

    public String LanguageDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("3", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String ConvertStringToCase(String word, String strcase) throws Exception {
        try {

            if (strcase.equalsIgnoreCase("lower")) {
                word = word.toLowerCase();
            } else if (strcase.equalsIgnoreCase("upper")) {
                word = word.toUpperCase();
            }
        } catch (Exception e) {
            LogCapture.info(e.getMessage());
        }
        return word;
    }

    public String ChatFileOperation(String operation, String data) throws IOException {
        try {
            String path = System.getProperty("user.home");

            path = path + "/Downloads";
            LogCapture.info(path);
            File file = new File(path);
            File files[] = file.listFiles();
            String filename, filename1;
            for (File f : files) {
                if (f.getName().contains(data)) {
                    filename = f.getName();
                    System.out.println(f.getName());
                    if (operation.equalsIgnoreCase("delete")) {
                        f.delete();
                        LogCapture.info(f.getName() + " file got deleted successfully");
                    } else if (operation.equalsIgnoreCase("exist")) {
                        if (filename.equalsIgnoreCase(data + ".txt")) {
                            LogCapture.info(f.getName() + " file downloaded successfully");
                        }
                    } else if (operation.equalsIgnoreCase("verifycontent")) {
                        FileInputStream fstream1 = new FileInputStream(path + "/" + data + ".txt");

                        DataInputStream in1 = new DataInputStream(fstream1);
                        //DataInputStream in2= new DataInputStream(fstream2);

                        BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
                        //BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));

                        String strLine1;
                        String strLine2 = "How can I help you?";


                        while ((strLine1 = br1.readLine()) != null) {
                            if (strLine1.contains(strLine2)) {
                                LogCapture.info(f.getName() + " file downloaded has chat conversation");
                                LogCapture.info(strLine1 + " file downloaded has content");
                                LogCapture.info(f.getName() + " file downloaded content has been compare with " + strLine2);

                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return KEYWORD_FAIL;

        }
        return KEYWORD_PASS;
    }

    public String navigateNewTab(String object, String data) throws Exception {
        try {
            String currentHandle = Constants.driver.getWindowHandle();

            ((JavascriptExecutor) Constants.driver).executeScript("window.open()");


            Set<String> handles = Constants.driver.getWindowHandles();
            for (String actual : handles) {

                if (!actual.equalsIgnoreCase(currentHandle)) {
                    //switching to the opened tab
                    Constants.driver.switchTo().window(actual);

                    //opening the URL saved.
                    Constants.driver.navigate().to(data);
                }
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";
        }
        return KEYWORD_PASS;
    }

    public String navigateTab(String Object, int data) throws Exception {
        try {
            ArrayList<String> tabs = new ArrayList<String>(Constants.driver.getWindowHandles());
            Constants.driver.switchTo().window(tabs.get(data));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyElementTitle(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getAttribute("title");
            if (actual.length() < 1) {
                System.out.println("Actual Length:->" + actual.length());
            }
            LogCapture.info("Actual:->" + actual);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return actual;
    }

    //For PFX
    public String updateDB(String environment, String data, String operationType) throws Exception {
        //For connection
        Connection connection = null;
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String OTP = null;
        String query = null;
        String value = null;
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("SITDB_URL") + ":" + Constants.DBCONFIG.getProperty("SITDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("SITDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
        }

        try {
            //LogCapture.info("try");
            //LogCapture.info("DB_URL->"+DB_URL);
            //LogCapture.info("DB_USER->"+DB_USER);
            //LogCapture.info("DB_PASSWORD->"+DB_PASSWORD);
            String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            Class.forName(dbClass).newInstance();

            // Get connection to DB
            LogCapture.info("Get connection to DB");

            connection = java.sql.DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            if (connection != null) {
                LogCapture.info("Connected to DB");
            }
            // Statement object to send the SQL statement to the Database
            //String query = "SELECT TOP  1 Pin FROM [NGOP-UAT].dbo.CustomerPin  where Email =? ORDER by CreatedOn  DESC";
            if (operationType.equalsIgnoreCase("Reset Prefer Phone")) {
                LogCapture.info("In->" + operationType);
                query = "UPDATE [NGOP].[dbo].[Customer]  SET PreferredPhoneNo = NULL , LastPinVerifiedOn = NULL , verificationPreferences = NULL where Email=?";
                ps = connection.prepareStatement(query);
                LogCapture.info("query after connection");
                ps.setNString(1, data);
                LogCapture.info("set first query parameter");
                int recordnumber = ps.executeUpdate();
                LogCapture.info(+recordnumber + " records updated for user " + data);
                value = Constants.KEYWORD_PASS;

            } else if (operationType.equalsIgnoreCase("Set Prefer Phone")) {
                query = "UPDATE [NGOP].[dbo].[Customer] SET PreferredPhoneNo='+91-9000000004' where Email =?";
                ps = connection.prepareStatement(query);
                ps.setNString(1, data);
                int recordnumber = ps.executeUpdate();
                LogCapture.info(+recordnumber + " records updated for user " + data);
                value = Constants.KEYWORD_PASS;

            } else if (operationType.equalsIgnoreCase("OTP")) {
                query = "SELECT TOP  1 Pin FROM [NGOP-UAT].dbo.CustomerPin  where Email =? ORDER by CreatedOn  DESC";

                ps = connection.prepareStatement(query);
                ps.setNString(1, data);
                ResultSet res = ps.executeQuery();
                // Get the contents of CustomerPin table from DB
                while (res.next()) {
                    OTP = res.getString("Pin");
                    break;
                    // System.out.println("OTP :" + OTP);
                }
                value = OTP;
            }
            return value;

        } catch (Exception e) {
            System.out.println("Unable to do operation" + operationType + "--" + e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        } finally {
            // Close DB connection
            if (connection != null) {
                connection.close();
            }
        }
    }

    //For CFX
    public String getOTP(String object, String data) throws Exception {
        //For connection
        Connection connection = null;
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String OTP = null;
        String query = null;
        if (object.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("SITDB_URL") + ":" + Constants.DBCONFIG.getProperty("SITDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("SITDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("SITDB_Password");
            query = "SELECT TOP  1 Pin FROM [NGOP-SIT].dbo.CustomerPin  where Email =? ORDER by CreatedOn  DESC";
            //"jdbc:sqlserver://172.31.4.93:1433
        } else if (object.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
            query = "SELECT TOP  1 Pin FROM ngop.dbo.CustomerPin where Email =? ORDER by CreatedOn  DESC";
        }
        try {
            String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            Class.forName(dbClass).newInstance();
            // Get connection to DB
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            // Statement object to send the SQL statement to the Database
            //String query = "SELECT TOP  1 Pin FROM [NGOP-UAT].dbo.CustomerPin  where Email =? ORDER by CreatedOn  DESC";

            ps = connection.prepareStatement(query);
            ps.setNString(1, data);
            ResultSet res = ps.executeQuery();
            // Get the contents of CustomerPin table from DB
            while (res.next()) {
                OTP = res.getString("Pin");
                break;
                // System.out.println("OTP :" + OTP);
            }
            return OTP;
        } catch (Exception e) {
            System.out.println("Unable to fetch OTP from Database : " + e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        } finally {
            // Close DB connection
            if (connection != null) {
                connection.close();
            }
        }
    }

    //This mehod used for creating new batch file for Reject batch scenario as same file cannot reject multiple time
    public String getNewDataFile(String srcFileName) {
        String fileName = "B" + System.currentTimeMillis();
        //String fileName = "A"+ TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis());
        File sourceFile = new File(System.getProperty("user.dir") + "/src/main/resources/" + srcFileName);
        File newFile = new File(System.getProperty("user.dir") + "/src/main/resources/" + fileName + ".csv");
        try {
            newFile.createNewFile();
            FileUtils.copyFile(sourceFile, newFile);
            return newFile.getAbsolutePath();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    //After uploading new created file it will be deleted instead storing in resources
    public void deletefile(String fileName) {
        File file = new File(fileName);
        try {
            if (file.delete()) {
                System.out.println("File deleted successfully");
            } else {
                System.out.println("Failed to delete the file");
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public String selectDateFromDatePicker(String object, String data) throws Exception {

        try {
            WebElement dateWidget = Constants.driver.findElement(By.xpath(object));

            List<WebElement> columns = dateWidget.findElements(By.tagName("td"));

            for (WebElement cell : columns) {
                if (cell.getText().equals(data)) {
                    cell.click();
                    return KEYWORD_PASS;
                }
            }

            return Constants.KEYWORD_FAIL;
        } catch (Exception e) {
            System.out.println(" Invalid date : " + e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
    }

    public String elementNotClickable(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_PASS;
        }
        return KEYWORD_FAIL + "element is clickable";
    }


    public String RecipientEdit(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Edit')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String WaitByTime(String object, Integer time) throws Exception {
        try {

            WebDriverWait w = new WebDriverWait(Constants.driver, time);
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to find...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String SelectValueFromDropDown(String object, String data) {
        try {
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            for (int i = 1; i <= 15; i++) {
                //System.out.println(dropdown_list.get(i).getText());
                //ul[@id="select2-txnValue_id-results"]//li[1]
                String vPath = "//ul[@id='select2-txnValue_id-results']//li[" + i + "]";
                String vdata = key.getText(vPath, "");
                if (vdata.equalsIgnoreCase(data)) {
                    Constants.driver.findElement(By.xpath(vPath)).click();
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String dropdown(String object, String data) {
        try {
            Select option = new Select(Constants.driver.findElement(By.xpath(object)));
            option.selectByVisibleText(data);

        } catch (Exception e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String DeleteRelevantRecipient(String object, String data) {
        try {
            List<WebElement> RecipientSize = Constants.driver.findElements(By.xpath("//*[@id=\"payees\"]/tbody/tr/td[1]/span"));
            for (int i = 1; i < RecipientSize.size(); i++) {
                String Element = "//*[@id=\"payees\"]/tbody/tr[" + i + "]/td[1]/span";
                String ActualName = key.getText(Element, "");
                if (ActualName.equalsIgnoreCase(data)) {
                    String vClose = "//*[@id=\"payees\"]/tbody/tr[" + i + "]/td[5]/div/a[3]/span";
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vClose, ""));
                    String vConfirm = Constants.loginPageOR.getProperty("ConfirmDelete");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vConfirm, ""));
                }
            }
        } catch (Exception e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String AcceptCookies() {
        try {
            //If Cookies window exist then accept the cookies and proceed or else skip
            // Waiting for cookies to load hence 10 sec pause is implemented
            String vCookies_Accept = Constants.SignUp.getProperty("Cookies_Accept");
            if (Constants.key.dynamicVisibleConditionWait(vCookies_Accept, 20).equalsIgnoreCase("Pass")) {
                Assert.assertEquals("PASS", Constants.key.click(vCookies_Accept, ""));
                Constants.key.pause("1", "");
                LogCapture.info("Cookies Accepted");
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogCapture.info("Cookies Not Accepted");
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String ClickConfirm(String object, String actual, Range re) {
        try {

            String status = "";
            do {
                if (re.isInclude(Integer.parseInt(actual))) {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(object, ""));
                    status = Constants.key.click(object, "");
                    LogCapture.info("Confirm button clicked...");

                    Constants.key.pause("5", "");
                }
            } while (status.equalsIgnoreCase("pass"));
        } catch (Exception e) {
            e.printStackTrace();
            LogCapture.info("Failed to click conirf");
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String dynamicVisibleConditionWait(String object, int TimeoutSec) throws Exception {
        try {

            WebDriverWait w = new WebDriverWait(Constants.driver, TimeoutSec);
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to find...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String RemoveSpace(String object) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.CONTROL, Keys.chord("a"));
            Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.BACK_SPACE);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    /****************************** SF **********************************/


    public String SfLeadDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("2", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String CurrentDay(String Format) throws Exception {
        Date date = new Date();
        SimpleDateFormat formatter;
        if (Format.equalsIgnoreCase("dd/MM/yyyy")) {
            formatter = new SimpleDateFormat("dd/MM/yyyy");
            return formatter.format(date);
        } else if (Format.equalsIgnoreCase("MM/dd/yyyy")) {
            formatter = new SimpleDateFormat("MM/dd/yyyy");
            return formatter.format(date);
        } else if (Format.equalsIgnoreCase("dd MMMM yyyy")) {
            formatter = new SimpleDateFormat("dd MMMM yyyy");
            return formatter.format(date);
        }
        return "NoDate";
    }


    public String waitForPageLoad() {
        try {
            ExpectedCondition<Boolean> pageLoadCondition = driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            WebDriverWait wait = new WebDriverWait(driver, 120);
            wait.until(pageLoadCondition);
        } catch (Exception e) {
            LogCapture.info("Page NotLoaded Properly" + e);
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String ClickByJavaScript(String object) {
        try {
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            WebElement element = Constants.driver.findElement(By.xpath(object));
            executor.executeScript("arguments[0].click();", element);
        } catch (Exception e) {
            LogCapture.info("Page NotLoaded Properly" + e);
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    /******************************* Affiliate and AE *************************/


    public String verifycolumn(String object, String data) throws Exception {
        try {
            String expected[] = data.split(",");
            LogCapture.info("List of coulmns: " + data);
            List<WebElement> ele = Constants.driver.findElements(By.xpath(object));
            LogCapture.info("ColumnNo is: " + ele.size());
            // LogCapture.info("ele is: "+ele);
            int flag = 0;
            if (data.split(",").length != ele.size()) {
                Assert.fail("Portal size = " + ele.size() + " and expected count = " + data.split(",").length);
            }
            for (int i = 0; i < ele.size(); i++) {
                String actual = ele.get(i).getText().trim();
                LogCapture.info("Actual columnnames: " + actual);
                LogCapture.info("Expected column names: " + expected[i]);
                if (actual.equalsIgnoreCase(expected[i])) {
                    takeSnapShot();
                    LogCapture.info("column " + actual + " is verified");

                } else {
                    takeSnapShot();

                    LogCapture.info("column " + actual + " is not verified");
                    flag = 1;
                    break;
                }
            }
            if (flag == 0) {
                return Constants.KEYWORD_PASS;
            } else if (flag == 1) {
                return Constants.KEYWORD_FAIL + "...text not verified " + actual + "  ";
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Object not found...." + e.getMessage();

        }
        return Constants.KEYWORD_PASS;
    }


    public String Alert() throws Exception {
        try {
            Constants.driver.switchTo().alert().dismiss();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_PASS;
        }
        return Constants.KEYWORD_FAIL;

    }


    public String verifyrowCount(String object, String data) throws Exception {
        try {
            List<WebElement> ele = Constants.driver.findElements(By.xpath(object));
            int actual = ele.size();
            LogCapture.info("size is" + actual);
            int expected = 1;
            if (actual == expected && data.equalsIgnoreCase("single")) {
                takeSnapShot();
                LogCapture.info("Single row verified.Row Count " + ele.size());
                return Constants.KEYWORD_PASS;
            } else if (actual > expected && data.equalsIgnoreCase("multiple")) {
                takeSnapShot();
                LogCapture.info("Multiple row verified.Row Count " + ele.size());
                return Constants.KEYWORD_PASS;
            } else {

                return Constants.KEYWORD_FAIL + "Single row.Not verified " + ele.size();
            }
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
    }


    public String implicitwait(String object, String data) throws Exception {
        try {
            int time = Integer.parseInt(data);
            Constants.driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
            takeSnapShot();
            return Constants.KEYWORD_PASS;

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }

    }

    public int getXpathIndex(String object, String data) throws Exception {
        int Index = 0;
        try {
            List<WebElement> ele = driver.findElements(By.xpath(object));
            for (WebElement e : ele) {
                Index++;
                String colName = e.getText().trim();
                if (data.equalsIgnoreCase(colName)) {
                    break;
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return 0;
        }
        return Index;
    }

    public String sendkeyboardStroke(String object, String data) throws Exception {
        //valid values for data = space,enter,up,tab,down,left,right
        try {
            Robot robot = new Robot();
            if (!object.equals("")) {
                WebElement browseBtn = Constants.driver.findElement(By.xpath(object));
                browseBtn.click();
                Thread.sleep(1000);
            }
            if (data.equals("space")) {
                robot.keyPress(KeyEvent.VK_SPACE);
                robot.keyRelease(KeyEvent.VK_SPACE);
            } else if (data.equals("enter")) {
                robot.keyPress(KeyEvent.VK_ENTER);
                robot.keyRelease(KeyEvent.VK_ENTER);
            } else if (data.equals("tab")) {
                robot.keyPress(KeyEvent.VK_TAB);
                robot.keyRelease(KeyEvent.VK_TAB);
            } else if (data.equals("down")) {
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Thread.sleep(1000);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "....unable to find element...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    public String UniqueEmail_ID(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            String emailID = "xyz" + userName + "@mailinator.com";
            //System.out.println("Result......" + emailID);
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(1000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(emailID);
            Thread.sleep(1000);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return Constants.KEYWORD_PASS;
    }

    public String VerifyAllDropDownValues1(String sheetName, String colName, String object) throws Exception {
        System.out.println("start");
        String fileName = System.getProperty("user.dir") + "/TestData.xlsx";
        File file = new File(fileName);
        FileInputStream inputStream = new FileInputStream(file);
        String fileExtensionName = fileName.substring(fileName.indexOf("."));
        System.out.println("end");
        if (fileExtensionName.equals(".xlsx")) {
            System.out.println("if");
            Workbook DropDownworkbook = null;
            DropDownworkbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = (XSSFSheet) DropDownworkbook.getSheet(sheetName);
            XSSFRow row;
            XSSFCell cell;
            String CellValue = null;
            ArrayList<String> ActualDropDownValues = new ArrayList<String>();
            ArrayList<String> ExpectedDropDownValues = new ArrayList<String>();
            driver.findElement(By.xpath("//button[@title='" + colName + "']")).click();
            Thread.sleep(3000);
            List<WebElement> contentOfRowsInColumn0 = driver.findElements(By.xpath("//button[@title='" + colName + "']//following-sibling::div//li"));
            int pp = 1;
            for (WebElement temp : contentOfRowsInColumn0) {

                String textvalue = temp.getText();
                ActualDropDownValues.add(textvalue);
                System.out.println(pp + ":" + textvalue);
                pp++;
            }
            try {
                int col_Num = -1;
                row = sheet.getRow(0);
                System.out.println("Ronumber" + row);
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    if (row.getCell(j).getStringCellValue().trim().equals(colName.trim())) {
                        col_Num = j;
                        System.out.println("ColNum" + col_Num);
                        //row= sheet.getRow(j);
                        //driver.findElement(By.xpath("//button[@title='" + colName + "']")).click();
                        List<WebElement> contentOfRowsInColumn = driver.findElements(By.xpath("//button[@title='" + colName + "']//following-sibling::div//li"));

                        int lengthOfColumn = contentOfRowsInColumn.size();
                        for (int i = 1; i <= lengthOfColumn; i++) {
                            row = sheet.getRow(i);
                            cell = row.getCell(col_Num);
                            if (cell.getStringCellValue().equalsIgnoreCase("")) {
                                System.out.println("Empty Value");
                            } else {
                                if (cell.getCellTypeEnum() == CellType.STRING) {
                                    CellValue = cell.getStringCellValue();
                                    System.out.println("Value" + CellValue);
                                    ExpectedDropDownValues.add(CellValue);
                                    // return CellValue;
                                } else if (cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA) {
                                    CellValue = String.valueOf(cell.getNumericCellValue());
                                    if (HSSFDateUtil.isCellDateFormatted(cell)) {
                                        DateFormat df = new SimpleDateFormat("dd/MM/yy");
                                        Date date = cell.getDateCellValue();
                                        CellValue = df.format(date);
                                    }
                                    // return CellValue;
                                } else if (cell.getCellTypeEnum() == CellType.BLANK) {
                                    CellValue = "";
                                    //return CellValue;
                                } else if (cell.getBooleanCellValue()) {
                                    CellValue = String.valueOf(cell.getBooleanCellValue());
                                    //return CellValue;
                                } else if (!cell.getBooleanCellValue()) {
                                    CellValue = String.valueOf(cell.getBooleanCellValue());
                                    //return CellValue;
                                }
                            }

                            // return CellValue;

                            // return "row " + rowNum + " or column " + colName + " does not exist  in Excel";
                        }
                        Assert.assertEquals(ExpectedDropDownValues, ActualDropDownValues);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "data not found";
            }
        }
        return "row " + " or column " + colName + " does not exist  in Excel";
    }

    public String selectValueFromDropDown(String object, String object1, String data) throws Exception {
        Actions act = new Actions(driver);
        act.moveToElement(driver.findElement(By.xpath(object))).click().build().perform();
        List<WebElement> allCategories = driver.findElements(By.xpath(object1));
        for (WebElement element : allCategories) {
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait("temp", ""));
            Thread.sleep(100);
            String elementtext = element.getText();
            //Thread.sleep(1000);
            if (elementtext.equalsIgnoreCase(data)) {
                act.moveToElement(element).click().build().perform();
                System.out.println(elementtext);
                break;
            }
        }
        return Constants.KEYWORD_PASS;
    }

    public String clearText(String object, String Data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).clear();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String clicks(String object, String data) throws Exception {
        try {
            WebElement ele = Constants.driver.findElement(By.xpath(object));
            //WebElement ele = driver.findElement(By.xpath("element_xpath"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", ele);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;

    }

    public String getAttributeText(String object, String data) throws Exception {
        try {
            WebElement targetElement = Constants.driver.findElement(By.xpath(object));
            actual = targetElement.getAttribute("value");
            System.out.println("Actual Length:->" + actual.length());
            System.out.println("actual value->>>>" + actual + '\n' + "data value->>>>" + data);
            if (actual.equals(data)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + data;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String closeBrowser(String object, String data) throws Exception {
        try {
            Constants.driver.quit();
        } catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found..." + ex);

            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String notVisible(String object, String data) throws Exception {
        try {
            if (data.contains("notDisplayed")) {
                if (!Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -  Displayed";
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + " -  Could not find element";

        }
        return KEYWORD_PASS;
    }

    public static JsonPath rawToJason(String response) {
        JsonPath js1 = null;
        try {
            LogCapture.info("-------------Converting to JSON, response => " + response + "--------");
            js1 = new JsonPath(response);
            return (js1);
        } catch (Exception e) {
            LogCapture.info("Error occurred in rawToJason method. The error is: " + e);
            e.printStackTrace();
        }
        return js1;
    }
}
