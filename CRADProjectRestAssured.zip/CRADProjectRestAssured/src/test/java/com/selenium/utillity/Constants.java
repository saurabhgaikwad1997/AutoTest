package com.selenium.utillity;

import com.utility.LogCapture;
import org.openqa.selenium.WebDriver;

import java.util.Properties;

public class Constants {
    public static Reusables key;
    public static WebDriver driver;
    public static String KEYWORD_PASS = "PASS";
    public static String KEYWORD_FAIL = "FAIL";
    public static Properties CONFIG;
    public static String JenkinsBrowser = System.getProperty("jenkinsBrowser");
    public static Properties loginPageOR;
    public static Properties DashboardOR;
    public static Properties NewRateAlertOR;
    public static String RANDOM_VALUE = "";
    public static LogCapture logs;
    public static Properties TopupWalletOR;
    public static Properties MakeTransferOR;
    public static Properties TitanLoginOR;
    public static Properties CreateFxTicketOR;
    public static Properties AtlasloginOR;
    public static Properties AtlasDashboardOR;
    public static Properties AtlasPaymentInOR;
    public static Properties AtlasPaymentOutOR;
    public static Properties SFLoginOR;
    public static Properties LeadGenerationOR;
    public static Properties ProfileManagementOR;
    public static Properties SignUp;
    public static Properties HelpOR;
    public static Properties PaymentTrackingOR;
    public static String PTData;
    public static Properties CalypsologinPageOR;
    public static Properties FrenchDashboardOR;
    public static Properties OccupationGenericOR;
    public static Properties AtlasRegistrationOR;

    public static String ACCESS_TOKEN="";

    public static Properties TitanDashboardOR;
    public static Properties TitanCustomersOR;
    public static Properties TitanConflictsOR;
    public static Properties TitanQueuesOR;
    public static Properties TitanPaymentInOR;
    public static Properties TitanPaymentOutOR;
    public static Properties TitanPayeeOR;
    public static Properties TitanFXTicketsOR;
    public static Properties TitanInstructionsOR;
    public static Properties TitanTreasuryOR;
    public static Properties TitanReportsOR;
    public static Properties TitanCDSAPhase1OR;


}
