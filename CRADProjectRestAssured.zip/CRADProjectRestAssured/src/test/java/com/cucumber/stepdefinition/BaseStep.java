package com.cucumber.stepdefinition;

import com.cucumber.listener.Reporter;
import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.utility.LogCapture;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
//import static com.selenium.utillity.Reusables.takeSnapShot;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
//import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
//import com.utilities.Log;
/*import io.cucumber.java.After;
import io.cucumber.java.Before;*/


public class BaseStep {

    public static String scenarioName;
    //@BeforeClass


    @Before
    public void intialization(Scenario scenario) throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();
        scenarioName = scenario.getName();
        Constants.key = new Reusables();
        FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//config.properties");
        Constants.CONFIG = new Properties();
        Constants.CONFIG.load(fs);


        //Titan Login OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanLoginOR.properties");
        Constants.TitanLoginOR = new Properties();
        Constants.TitanLoginOR.load(fs);

        //Titan Dashboard OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanDashboardOR.properties");
        Constants.TitanDashboardOR = new Properties();
        Constants.TitanDashboardOR.load(fs);

        //Titan Customers OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanCustomersOR.properties");
        Constants.TitanCustomersOR = new Properties();
        Constants.TitanCustomersOR.load(fs);

        //Titan Conflicts OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanConflictsOR.properties");
        Constants.TitanConflictsOR = new Properties();
        Constants.TitanConflictsOR.load(fs);

        //Titan TitanQueuesOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanQueuesOR.properties");
        Constants.TitanQueuesOR = new Properties();
        Constants.TitanQueuesOR.load(fs);

        //Titan TitanPaymentInOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanPaymentInOR.properties");
        Constants.TitanPaymentInOR = new Properties();
        Constants.TitanPaymentInOR.load(fs);

        //Titan TitanPayeeOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanPayeeOR.properties");
        Constants.TitanPayeeOR = new Properties();
        Constants.TitanPayeeOR.load(fs);

        //Titan TitanPayeeOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanFXTicketsOR.properties");
        Constants.TitanFXTicketsOR = new Properties();
        Constants.TitanFXTicketsOR.load(fs);

        //Titan TitanPaymentOutOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanPaymentOutOR.properties");
        Constants.TitanPaymentOutOR = new Properties();
        Constants.TitanPaymentOutOR.load(fs);

        //Titan TitanInstructionsOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanInstructionsOR.properties");
        Constants.TitanInstructionsOR = new Properties();
        Constants.TitanInstructionsOR.load(fs);

        //Titan TitanTreasuryOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanTreasuryOR.properties");
        Constants.TitanTreasuryOR = new Properties();
        Constants.TitanTreasuryOR.load(fs);

        //Titan TitanReportsOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanReportsOR.properties");
        Constants.TitanReportsOR = new Properties();
        Constants.TitanReportsOR.load(fs);


        //Titan_Create FX Ticket
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//CreateFxTicketOR.properties");
        Constants.CreateFxTicketOR = new Properties();
        Constants.CreateFxTicketOR.load(fs);

        //TitanCDSAPhase1OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java/com//Pages//Titan//TitanCDSAPhase1OR.properties");
        Constants.TitanCDSAPhase1OR = new Properties();
        Constants.TitanCDSAPhase1OR.load(fs);

        //TitanCDSA
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java/com//Pages//Titan//TitanCDSAPhase1OR.properties");
        Constants.TitanCDSAPhase1OR = new Properties();
        Constants.TitanCDSAPhase1OR.load(fs);

        LogCapture.startLog("-------------------------Test Case Validation Started--------------------");

    }

    @After
    //@AfterClass
    public void finish(Scenario scenario) throws Exception {
        if (!(Constants.driver == null)) {
            if (Constants.CONFIG.getProperty("ScreenshotCaptureOnFailure").equalsIgnoreCase("True")) {
                if (scenario.isFailed()) {
                    takeSnapShotOnFailure();
                }
            }
            Constants.driver.quit();
        }

        LogCapture.endLog("-------------------------Test Case Validation Ended--------------------");
    }

    public static void writeExtentReport() throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();
        Reporter.loadXMLConfig(new File(Constants.key.getReportConfigPath()));

    }


}