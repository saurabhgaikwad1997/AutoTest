package com.cucumber.stepdefinition;

import com.fasterxml.jackson.databind.cfg.ContextAttributes;
import com.selenium.utillity.Constants;


import com.utility.LogCapture;
/*import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;*/
import cucumber.api.PendingException;
import cucumber.api.java.en.*;
import gherkin.lexer.De;
import gherkin.lexer.Th;
import net.bytebuddy.implementation.bytecode.Throw;
//import okhttp3.MultipartBody;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.logging.Log;
import org.apache.poi.xssf.usermodel.TextHorizontalOverflow;
import org.junit.internal.runners.statements.Fail;
import org.openqa.selenium.*;
import com.selenium.utillity.Constants;
//import com.utilities.Log;
import com.utility.LogCapture;
import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;


import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.TestRunner;

import java.awt.*;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class TitanStepDefinition {
    String WalletBalanceOnTab;
    String winHandleBefore;
    String PayeeFirstName;
    String PayeeLastName;
    String PayeeCompanyName;
    String InstructionNumber;
    String CurrentBrowser = Constants.CONFIG.getProperty("browser");


    @Given("^User navigate to Titan Application \"(.*?)\"$")
    public void user_navigate_to_Titan_Application(String vUrl) throws Throwable {
        LogCapture.info("Titan Applicatiion is loading....");
        String url = Constants.CONFIG.getProperty(vUrl);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
    }

    @When("^User enter UserName \"(.*?)\" password \"(.*?)\" and click log In button$")
    public void user_enter_UserName_password_and_click_log_In_button(String userName, String password) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.TitanLoginOR.getProperty("Titan_Username");
        String vObjPass = Constants.TitanLoginOR.getProperty("Titan_Password");
        LogCapture.info("User Name " + vUserName + ", Password is validated ....");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.TitanLoginOR.getProperty("LogInButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @When("^User enter UserName \"(.*?)\" Incorrect password \"(.*?)\" and click log In button$")
    public void user_enter_UserName_Incorrect_password_and_click_log_In_button(String usernName, String inPassword) throws Throwable {
        LogCapture.info("Validating incorrect credentials.......");
        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.TitanLoginOR.getProperty("Titan_Username");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        String vObjPass = Constants.TitanLoginOR.getProperty("Titan_Password");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));
        String vObjLoginButton = Constants.TitanLoginOR.getProperty("LogInButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @Then("^User successfully landed on Titan Dashboard page$")
    public void user_successfully_landed_on_Titan_Dashboard_page() throws Throwable {
        LogCapture.info("Dashboard loading ......");
        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vobjectDashboard = Constants.TitanLoginOR.getProperty("DashboardPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Dashboard"));
        LogCapture.info("Dasehboard loaded successfully");
    }

    @Then("^User clicks on Logout button and successfully logout from application$")
    public void user_clicks_on_Logout_button_and_successfully_logout_from_application() throws Throwable {
        String vObjLogOutLink = Constants.TitanLoginOR.getProperty("LogOutLink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLogOutLink, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjLogOutLink, ""));
        LogCapture.info("User clicks on Logout button..");
        Constants.key.pause("2", "");
    }

    @Then("^User should get error and should not be able to login in to Titan$")
    public void user_should_get_error_and_should_not_be_able_to_login_in_to_Titan() throws Throwable {
        String vObjInvalidLoginError = Constants.TitanLoginOR.getProperty("InvalidLoginError");
        LogCapture.info("Validating error message...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjInvalidLoginError, "Invalid username or password."));
    }

    @Then("^User clicks on Customers option under Titan$")
    public void user_clicks_on_Customers_option_under_Titan() throws Throwable {
        String vObjTitanMenu = Constants.CreateFxTicketOR.getProperty("TitanMenu");
        Assert.assertEquals("PASS", Constants.key.click(vObjTitanMenu, ""));
        String vObjCustomers = Constants.CreateFxTicketOR.getProperty("Customers");
        LogCapture.info("Opening Customer detail page");
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomers, ""));
    }

    @Then("^User clicks on Filter option$")
    public void user_clicks_on_Filter_option() throws Throwable {
        String vObjFilter = Constants.CreateFxTicketOR.getProperty("Filter");
        LogCapture.info("Opening Filter section");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilter, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User search for client number \"(.*?)\" and hits Enter key$")
    public void user_enters_client_number_and_hits_Enter_key(String clientNumber) throws Throwable {
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, clientNumber));
        LogCapture.info("Searching for Client number" + clientNumber);
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");
    }

    @Then("^User clicks on client number link to navigate to customer detail page$")
    public void user_clicks_on_client_number_link_to_navigate_to_customer_detail_page() throws Throwable {
        String vObjClientDetailLink = Constants.CreateFxTicketOR.getProperty("ClientDetailLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjClientDetailLink, ""));
        Constants.key.pause("2", "");

    }

    @And("^User clicks on (FX|Payment In|Payment Out|Payee|Instructions|RT) button$")
    public void user_clicks_on_fx_button(String Button) throws Throwable {
        String vObjButton = null;
        if (Button.equalsIgnoreCase("FX")) {
            vObjButton = Constants.CreateFxTicketOR.getProperty("Fxbutton");
        }
        if (Button.equalsIgnoreCase("Payment In")) {
            vObjButton = Constants.TitanPaymentInOR.getProperty("PaymentInButton");
        }
        if (Button.equalsIgnoreCase("Payment Out")) {
            vObjButton = Constants.TitanPaymentOutOR.getProperty("PaymentOutButton");
        }

        if (Button.equalsIgnoreCase("Payee")) {
            vObjButton = Constants.TitanPayeeOR.getProperty("PayeeButton");
        }
        if (Button.equalsIgnoreCase("Instructions")) {
            vObjButton = Constants.TitanInstructionsOR.getProperty("InstructionButton");
        }
        if (Button.equalsIgnoreCase("RT")) {
            vObjButton = Constants.TitanCustomersOR.getProperty("RegularTransferBtn");
            WebElement RegularTransferBtn = Constants.driver.findElement(By.xpath(vObjButton));
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView();", RegularTransferBtn);

        }


        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjButton, ""));
        LogCapture.info("User clicks on " + Button + " button..");
        Constants.key.pause("2", "");
    }

    @Then("^User selects Instructed by \"(.*?)\" Deal type\"(.*?)\" purpose of payment \"(.*?)\"(| with Option flag ticked| with Option flag unticked) and clicks Next$")
    public void user_selects_Instructed_by_Deal_type_purpose_of_payment_and_clicks_Next(String instructedBy, String DealType, String purposeOfPayment, String OptionFlag) throws Throwable {
        String vObjInstructedBy = Constants.CreateFxTicketOR.getProperty("InstructedBy");
        //Assert.assertEquals("PASS", Constants.key.click(vObjInstructedBy, ""));

        String vObjInstructedBySearch = Constants.CreateFxTicketOR.getProperty("InstructedBySearch");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructedBySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructedBySearch, instructedBy));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearch, "enter"));
        LogCapture.info("Instructed By: " + instructedBy + " is selected..");
        String vObjDealType = null;
        if (DealType.equalsIgnoreCase("Spot")) {
            vObjDealType = Constants.CreateFxTicketOR.getProperty("SpotDealType");
        }
        if (DealType.equalsIgnoreCase("Forward")) {
            vObjDealType = Constants.CreateFxTicketOR.getProperty("ForwardDealType");
        }
        if (DealType.equalsIgnoreCase("Limit")) {
            vObjDealType = Constants.CreateFxTicketOR.getProperty("LimitDealType");
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealType, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjDealType, ""));
        LogCapture.info("Deal type: " + DealType + " is selected...");

        if (OptionFlag.equalsIgnoreCase(" with Option flag ticked")) {
            String vObjOptionFlagCheckBox = Constants.CreateFxTicketOR.getProperty("OptionFlagCheckBox");
            Assert.assertEquals("PASS", Constants.key.click(vObjOptionFlagCheckBox, ""));
            LogCapture.info("User Ticks Option flag as true..");
            Constants.key.pause("2", "");
            if (DealType.equalsIgnoreCase("Spot")) {
                String vObjB2BFlagDisabled = Constants.CreateFxTicketOR.getProperty("B2BFlagDisabled");
                Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjB2BFlagDisabled, "visible"));
                LogCapture.info("B2B deal is disabled..");
            } else if (DealType.equalsIgnoreCase("Forward")) {
                String vObjB2BFlagDisabled = Constants.CreateFxTicketOR.getProperty("B2BFlagDisabled");
                Assert.assertEquals("PASS", Constants.key.notexist(vObjB2BFlagDisabled, ""));
                LogCapture.info("B2B deal is enable..");
            }
        }

        String vObjPurposeOfPayment = Constants.CreateFxTicketOR.getProperty("PurposeOfPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPurposeOfPayment, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPayment, ""));

        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vPurposeOfPaymentSearch_FireFox = Constants.CreateFxTicketOR.getProperty("PurposeOfPaymentSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vPurposeOfPaymentSearch_FireFox, ""));
            LogCapture.info("Purpose Of Payment: " + purposeOfPayment + " is selected...");
        } else {
            String vObjPurposeOfPaymentSearch = Constants.CreateFxTicketOR.getProperty("PurposeOfPaymentSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
            LogCapture.info("Purpose Of Payment: " + purposeOfPayment + " is selected...");
        }
        Constants.key.pause("2", "");
        String vObjSourceOfFundDownArrow = Constants.CreateFxTicketOR.getProperty("SourceOfFundDownArrow");
        boolean vSourceOfFund = Constants.driver.findElement(By.xpath(vObjSourceOfFundDownArrow)).isDisplayed();
        if (vSourceOfFund) {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSourceOfFundDownArrow, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSourceOfFundDownArrow, ""));
            //    Assert.assertEquals("PASS", Constants.key.click(vObjSourceOfFundDownArrow, ""));
            String vObjSourceOfFundSearch = Constants.CreateFxTicketOR.getProperty("SourceOfFundSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSourceOfFundSearch, "SAVINGS"));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSourceOfFundSearch_FireFox = Constants.CreateFxTicketOR.getProperty("SourceOfFundSearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSourceOfFundSearch_FireFox, ""));
                LogCapture.info("Source of funds: SAVINGS is selected...");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundSearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundSearch, "enter"));
                LogCapture.info("Source of funds: SAVINGS is selected...");
            }
        }
        Constants.key.pause("3", "");
        String vObjNext1Button = Constants.CreateFxTicketOR.getProperty("Next1Button");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjNext1Button, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @Then("^User selects Selling Currency \"(.*?)\" Buying currency \"(.*?)\" Selling amount \"(.*?)\"and clicks on Fetch rates button$")
    public void user_selects_Selling_Currency_Buying_currency_Selling_amount_and_clicks_on_Fetch_rates_button(String SellCurrency, String BuyCurrency, String sellingAmount) throws Throwable {
        String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
        //Assert.assertEquals("PASS", Constants.key.click(vObjCurrenciesAndAmounts, ""));
        LogCapture.info("User is on FX details page..");
        Constants.key.pause("7", "");
        //String vObjSellingCurrency = Constants.CreateFxTicketOR.getProperty("SellingCurrency");
        //Assert.assertEquals("PASS", Constants.key.click(vObjSellingCurrency, ""));
        String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
        //Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjSellingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");

        Constants.key.pause("2", "");
        String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

        String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
        LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

        String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
        LogCapture.info("Amount: " + sellingAmount + " is entered..");

        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
        Assert.assertEquals("PASS", Constants.key.click(vObjFetchRates, ""));
        Constants.key.pause("4", "");

    }

    @Then("^User clicks on Next button$")
    public void user_clicks_on_Next_button() throws Throwable {
        String vObjNext2Button = Constants.CreateFxTicketOR.getProperty("Next2Button");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNext2Button, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjNext2Button, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Clicked on Next button..");

    }

    @Then("^User selects method Bank$")
    public void user_selects_method_bank() throws Throwable {
        String vObjPaymentMethodBank = Constants.CreateFxTicketOR.getProperty("PaymentMethodBank");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodBank, ""));
    }

    @Then("^User clicks on Add Credit button$")
    public void user_clicks_on_add_credit_button() throws Throwable {
        String vObjAddCreditButton = Constants.CreateFxTicketOR.getProperty("AddCreditButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCreditButton, ""));
        Constants.key.pause("4", "");

    }

    @Then("^User clicks on Skip button$")
    public void user_clicks_on_Skip_button() throws Throwable {
        String vObjSkipButton = Constants.CreateFxTicketOR.getProperty("SkipButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSkipButton, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User clicks on Yes button for popup$")
    public void user_clicks_on_Yes_button_for_popup() throws Throwable {
        String vObjYesSkipButton = Constants.CreateFxTicketOR.getProperty("YesSkipButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjYesSkipButton, ""));
        LogCapture.info("Clicked on Yes button on pop-up..");
        Constants.key.pause("2", "");
    }

    @Then("^user clicks on Submit button$")
    public void user_clicks_on_Submit_button() throws Throwable {
        String vObjSubmitButton = Constants.CreateFxTicketOR.getProperty("SubmitButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitButton, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSubmitButton, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User clicked on Submit button..");
    }

    @Then("^User clicks on Close Slip button for (FX|Payee|RT|Payment in|Payment out)$")
    public void UserClicksOnCloseSlipButton(String TargetPage) throws Throwable {
        String vObjCloseSlipButton = null;
        if (TargetPage.equalsIgnoreCase("FX")) {
            vObjCloseSlipButton = Constants.CreateFxTicketOR.getProperty("CloseFxSlipButton");
        }
        if (TargetPage.equalsIgnoreCase("Payee")) {
            vObjCloseSlipButton = Constants.TitanPayeeOR.getProperty("ClosePayeeSlipButton");
        }
        if (TargetPage.equalsIgnoreCase("RT")) {
            vObjCloseSlipButton = Constants.TitanCustomersOR.getProperty("CloseRegularTransferSlipBtn");
        }
        if (TargetPage.equalsIgnoreCase("Payment in")) {
            vObjCloseSlipButton = Constants.TitanPaymentOutOR.getProperty("PaymentInCloseSlipButton");
        }
        if (TargetPage.equalsIgnoreCase("Payment out")) {
            vObjCloseSlipButton = Constants.TitanPaymentOutOR.getProperty("PaymentOutCloseSlipButton");
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCloseSlipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCloseSlipButton, ""));
        LogCapture.info("User clicked on Close Slip button...");
        Constants.key.pause("2", "");
    }

    @Then("^User clicks on customer number link to navigate to customer detail page$")
    public void user_clicks_on_customer_number_link_to_navigate_to_customer_detail_page() throws Throwable {
        Constants.key.pause("2", "");
        String vObjCustomerDetailLink = Constants.CreateFxTicketOR.getProperty("CustomerDetailLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerDetailLink, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User selects method Card selects card \"(.*?)\" enters CVV \"(.*?)\" for FX(| and No Warning Msg for EU customers)$")
    public void user_selects_method_Card_selects_card_enters_CVV(String selectCard, String cvv, String WarningMsg) throws Throwable {
        String vObjPaymentMethodCard = Constants.CreateFxTicketOR.getProperty("PaymentMethodCard");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodCard, ""));
        Constants.key.pause("2", "");
        LogCapture.info("clicking om Card tab...");
        if (WarningMsg.equalsIgnoreCase(" and No Warning Msg for EU customers")) {
            Constants.key.pause("2", "");
            String vObjFXSPOTWarningMsgEU = Constants.CreateFxTicketOR.getProperty("FXSPOTWarningMsgEU");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjFXSPOTWarningMsgEU, ""));
            LogCapture.info("Warning for EU customer is NOT visible while payment...");
        }
        String vObjSelectCard = Constants.CreateFxTicketOR.getProperty("SelectCard");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectCard, ""));
        Constants.key.pause("3", "");

        String vObjSelectCardSearch = Constants.CreateFxTicketOR.getProperty("SelectCardSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSelectCardSearch, selectCard));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectCardSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectCardSearch, "enter"));
        Constants.key.pause("3", "");
        LogCapture.info("Card searched and selected...");
        String vObjCardCvv = Constants.CreateFxTicketOR.getProperty("CardCvv");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardCvv, cvv));
        LogCapture.info("Card CVV entered: " + cvv);
    }


    @Then("^User clicks on client number\"([^\"]*)\" link to navigate to customer detail page$")
    public void userClicksOnClientNumberLinkToNavigateToCustomerDetailPage(String clientNumber) throws Throwable {

        String vclientNumberXpath = "//*[contains(text(),'" + clientNumber + "')]";
        //String vclientNumberXpath= Constants.TitanCustomersOR.getProperty("CustomerFirstLine");

        //String vObjCustomerDetailLink = Constants.CreateFxTicketOR.getProperty("CustomerDetailLink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
    }

    @And("^User clicks on Titan organization on Dashboard page$")
    public void userClicksOnTitanOrganisationOnDashboardPage() throws Throwable {
        Constants.key.pause("2", "");
        String vObjTitanOrgLink = Constants.TitanLoginOR.getProperty("TitanOrgLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjTitanOrgLink, ""));
        Constants.key.pause("2", "");
    }

    @And("^User successfully landed on Dashboard In Titan page$")
    public void userSuccessfullyLandedOnDashboardInTitanPage() throws Throwable {
        String vObjDashboardInTitan = Constants.TitanLoginOR.getProperty("DashboardInTitan");
        Assert.assertEquals("PASS", Constants.key.click(vObjDashboardInTitan, ""));
        Constants.key.pause("2", "");
    }

    @And("^User Select \"([^\"]*)\" on Titan Dashboard$")
    public void userSelectOnTitanDashboard(String Organisation) throws Throwable {
        String vObjSelectOrganisationDropdown = Constants.TitanLoginOR.getProperty("SelectOrganisationDropdown");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectOrganisationDropdown, ""));
        Constants.key.pause("2", "");
        String OrganisationToBeSelected = "//input[@name='rad-org' and @value='" + Organisation + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(OrganisationToBeSelected, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(OrganisationToBeSelected, ""));
        LogCapture.info(Organisation + " is selected...");
        Constants.key.pause("2", "");
    }

    @And("^User Select \"([^\"]*)\" for respective Organisation$")
    public void userSelectForRespectiveOrganisation(String Section) throws Throwable {
        Constants.key.pause("2", "");
        String SectionToBeSelected = "//a[text()='" + Section + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SectionToBeSelected, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(SectionToBeSelected, ""));
        LogCapture.info("Clicked on " + Section + " section...");
        Constants.key.pause("2", "");
    }

    @And("^Verify that Wallet page is displayed with Alphabetical order$")
    public void verifyThatWalletPageIsDisplayedWithAlphabeticalOrder() throws Throwable {
        String vObjWalletPageMsg = Constants.TitanDashboardOR.getProperty("WalletPageMsg");
        String ExpectWalletPageMsg = "Select what you want to see above.";
        // Assert.assertEquals("PASS", Constants.key.verifyText(vObjWalletPageMsg, ExpectWalletPageMsg));
        LogCapture.info("User is on Wallet page...");
        Constants.key.pause("2", "");
        String WalletTypes = "//ul[@id='walletTypeId']/li";
        List<WebElement> WalletListTypes = Constants.driver.findElements(By.xpath(WalletTypes));
        char start = 'A';
        int j = 2;
        for (int i = 0; i < WalletListTypes.size(); i++) {
            String CurrentWalletListType = WalletListTypes.get(i).getAttribute("data-wallet-initial");
            LogCapture.info(CurrentWalletListType);
            if (CurrentWalletListType.equals("TOP")) {
                if (i == 0) {
                    LogCapture.info("TOP is displayed at Position " + i);
                } else {
                    LogCapture.info("TOP is NOT displayed at Position " + i);
                    Assert.fail();
                }
            } else if (CurrentWalletListType.equals("ALL")) {
                if (i == 1) {
                    LogCapture.info("ALL is displayed at Position " + i);
                } else {
                    LogCapture.info("ALL is NOT displayed at Position " + i);
                    Assert.fail();
                }
            } else if (CurrentWalletListType.matches("[A-Z]")) {

                if (i == j) {
                    LogCapture.info(start + " is displayed at Position " + i);
                    start++;
                    j++;
                } else {
                    LogCapture.info(start + " is NOT displayed at Position " + i);
                    Assert.fail();
                }
            }
        }
    }

    @And("^User selects Titan wallet as \"([^\"]*)\" and Wallet Currency as \"([^\"]*)\"$")
    public void userSelectsTitanWalletAsAndWalletCurrencyAs(String WalletSelection, String WalletCurrency) throws Throwable {
        String WalletSelected = "//ul[@id='walletTypeId']/li[@data-wallet-initial='" + WalletSelection + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelected, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(WalletSelected, ""));
        LogCapture.info("Wallet " + WalletCurrency + " is clicked...");
        Constants.key.pause("2", "");
        String WalletCurrencySelected;

        if (WalletSelection.equalsIgnoreCase("TOP")) {
            WalletCurrencySelected = "//div[@id='wallet-detail-top']//a[@data-wallet-currency='" + WalletCurrency + "']";
        } else {
            WalletCurrencySelected = "//div[@id='wallet-detail-" + WalletSelection.toUpperCase() + "']//a[@data-wallet-currency='" + WalletCurrency + "']";
        }
        LogCapture.info(WalletCurrencySelected);

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletCurrencySelected, ""));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(WalletCurrencySelected, ""));
        LogCapture.info("Wallet Currency " + WalletCurrency + " is clicked...");
        Constants.key.pause("2", "");
    }

    @Then("^User is able to view Wallet \"([^\"]*)\" details$")
    public void userIsAbleToViewWalletDetails(String WalletCurrency) throws Throwable {
        String WalletSelected = "//h3[@id='modal-currency' and text()='" + WalletCurrency + "']";
        String WalletSelectedFlag = "//img[@class='droplist__flag' and @alt='" + WalletCurrency + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelected, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(WalletSelected, "visible"));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelectedFlag, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(WalletSelectedFlag, "visible"));
        LogCapture.info("Wallet details with flag for " + WalletCurrency + " are displayed...");

        String vObjWalletBalanceHeader = Constants.TitanDashboardOR.getProperty("WalletBalanceHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletBalanceHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletBalanceHeader, "visible"));
        LogCapture.info("Wallet Balance header is visible...");

        String vObjReferenceColumn = Constants.TitanDashboardOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReferenceColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible...");

        String vObjDateTimeColumn = Constants.TitanDashboardOR.getProperty("DateTimeColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDateTimeColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateTimeColumn, "visible"));
        LogCapture.info("Date/Time Column is visible...");

        String vObjTypeColumn = Constants.TitanDashboardOR.getProperty("TypeColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTypeColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTypeColumn, "visible"));
        LogCapture.info("Type Column is visible...");

        String vObjAmountColumn = Constants.TitanDashboardOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountColumn, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible...");

        String vObjTransferToClientBtn = Constants.TitanDashboardOR.getProperty("TransferToClientBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransferToClientBtn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTransferToClientBtn, "enabled"));
        LogCapture.info("Transfer To Client button is enabled...");

        String vObjWalletBalanceOnPage = Constants.TitanDashboardOR.getProperty("WalletBalanceOnPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletBalanceOnPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletBalanceOnPage, "visible"));
        LogCapture.info("Wallet balance is visible...");

        LogCapture.info("Wallet details for " + WalletCurrency + " are Verified...");

    }

    @And("^User navigate to (Customers|Conflicts|Incoming Funds|Payments in|Payments out|FX tickets|Payees|Invoices|Profit Adjustment|B2B Queue|Deal Report|Add Deal) section under (Titan|Queues|Reports|Treasury)$")
    public void userNavigateToCustomerSectionUnderTitan(String Section, String Header) throws Throwable {
        String vObjTreasuryIcon = Constants.TitanDashboardOR.getProperty("TreasuryIcon");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjTreasuryIcon, "MoveToElement"));
        Constants.key.pause("2", "");
        if (Section.equalsIgnoreCase("Customers") && Header.equalsIgnoreCase("Titan")) {
            String vObjCustomersSection = Constants.TitanDashboardOR.getProperty("CustomersSection");
            String vObjProfilesInTitanHeader = Constants.TitanCustomersOR.getProperty("ProfilesInTitanHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomersSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomersSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomersSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProfilesInTitanHeader, ""));
            LogCapture.info("User is on Profiles in Titan page..");
        }
        if (Section.equalsIgnoreCase("Conflicts") && Header.equalsIgnoreCase("Titan")) {
            String vObjConflictsSection = Constants.TitanDashboardOR.getProperty("ConflictsSection");
            String vObjConflictsInTitanHeader = Constants.TitanConflictsOR.getProperty("ConflictsInTitanHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjConflictsSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictsSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjConflictsSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjConflictsInTitanHeader, ""));
            LogCapture.info("User is on Conflicts in Titan page..");
        }
        if (Section.equalsIgnoreCase("Incoming Funds") && Header.equalsIgnoreCase("Queues")) {
            String vObjIncomingFundsSection = Constants.TitanDashboardOR.getProperty("IncomingFundsSection");
            String vObjIncomingFundsHeader = Constants.TitanQueuesOR.getProperty("IncomingFundsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIncomingFundsSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjIncomingFundsSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjIncomingFundsSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIncomingFundsHeader, ""));
            LogCapture.info("User is on Incoming Funds in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments in") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuesPaymentInSection = Constants.TitanDashboardOR.getProperty("QueuesPaymentInSection");
            String vObjPaymentsInHeader = Constants.TitanQueuesOR.getProperty("PaymentsInHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuesPaymentInSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuesPaymentInSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuesPaymentInSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsInHeader, ""));
            LogCapture.info("User is on PaymentsIn in Titan page..");
        }
        if (Section.equalsIgnoreCase("FX tickets") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuefxTicketSection = Constants.TitanDashboardOR.getProperty("QueuefxTicketSection");
            String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuefxTicketSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuefxTicketSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuefxTicketSection, ""));
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
            LogCapture.info("User is on FX tickets in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payees") && Header.equalsIgnoreCase("Reports")) {
            String vObjPayeeReportSection = Constants.TitanDashboardOR.getProperty("PayeeReportSection");
            String vObjPayeeReportHeader = Constants.TitanPayeeOR.getProperty("PayeeReportHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeReportHeader, ""));
            LogCapture.info("User is on Payees report in Titan page..");
        }
        if (Section.equalsIgnoreCase("Add Deal") && Header.equalsIgnoreCase("Treasury")) {
            String vObjAddDealSection = Constants.TitanDashboardOR.getProperty("AddDealSection");
            String vObjAddDealPageHeader = Constants.TitanTreasuryOR.getProperty("AddDealPageHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddDealSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddDealSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddDealSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddDealPageHeader, ""));
            LogCapture.info("User is on Add booking in Titan page..");
        }
        if (Section.equalsIgnoreCase("B2B Queue") && Header.equalsIgnoreCase("Treasury")) {
            String vObjB2BSection = Constants.TitanDashboardOR.getProperty("B2BSection");
            String vObjUpdateB2BPage = Constants.TitanTreasuryOR.getProperty("UpdateB2BPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjB2BSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjB2BSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUpdateB2BPage, ""));
            LogCapture.info("User is on Update B2B in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments out") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuesPaymentOutSection = Constants.TitanDashboardOR.getProperty("QueuesPaymentOutSection");
            String vObjPaymentsOutHeader = Constants.TitanQueuesOR.getProperty("PaymentsOutHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuesPaymentOutSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuesPaymentOutSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuesPaymentOutSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsOutHeader, ""));
            LogCapture.info("User is on PaymentsOut in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments in") && Header.equalsIgnoreCase("Reports")) {
            String vObjPaymentInReportSection = Constants.TitanDashboardOR.getProperty("PaymentInReportSection");
            String vObjPaymentInReportPage = Constants.TitanReportsOR.getProperty("PaymentInReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentInReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInReportPage, "visible"));
            LogCapture.info("User is on Payments In Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments out") && Header.equalsIgnoreCase("Reports")) {
            String vObjPaymentOutReporSection = Constants.TitanDashboardOR.getProperty("PaymentOutReporSection");
            String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReporSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentOutReporSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutReporSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
            LogCapture.info("User is on Payments Out Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("FX tickets") && Header.equalsIgnoreCase("Reports")) {
            String vObjfxTicketReportSection = Constants.TitanDashboardOR.getProperty("fxTicketReportSection");
            String vObjFXTicketsHeader = Constants.TitanReportsOR.getProperty("FXticketsReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjfxTicketReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjfxTicketReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjfxTicketReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
            LogCapture.info("User is on FX tickets Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("Invoices") && Header.equalsIgnoreCase("Reports")) {
            String vObjInvoicesReportSection = Constants.TitanDashboardOR.getProperty("DeferredInvoiceSection");
            String vObjInvoicesReportPage = Constants.TitanReportsOR.getProperty("InvoicesReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvoicesReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInvoicesReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjInvoicesReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvoicesReportPage, ""));
            LogCapture.info("User is on Invoices in Titan page under Reports..");
        }
        if (Section.equalsIgnoreCase("Deal Report") && Header.equalsIgnoreCase("Treasury")) {
            String vObjDealReportSection = Constants.TitanDashboardOR.getProperty("DealReport");
            String vObjDealQueueHeader = Constants.TitanTreasuryOR.getProperty("DealQueueHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealQueueHeader, ""));
            LogCapture.info("User is on Deal queue in Titan page..");
        }

    }

    @Then("^User is able to view Customers page details in Titan and Not error message$")
    public void userIsAbleToViewCustomersDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjProfilesInTitanHeader = Constants.TitanCustomersOR.getProperty("ProfilesInTitanHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjProfilesInTitanHeader, "visible"));
        LogCapture.info("Profiles in Titan header is visible..");

        String vObjDownloadBtn = Constants.TitanCustomersOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download button visible..");

        String vObjOrganisationsColumn = Constants.TitanCustomersOR.getProperty("OrganisationsColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationsColumn, "visible"));
        LogCapture.info("Org Column is visible..");

        String vObjLegalEntityColumn = Constants.TitanCustomersOR.getProperty("LegalEntityColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLegalEntityColumn, "visible"));
        LogCapture.info("Legal Entity Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanCustomersOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjDateTimeCreatedColumn = Constants.TitanCustomersOR.getProperty("DateTimeCreatedColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateTimeCreatedColumn, "visible"));
        LogCapture.info("Date/Time Created Column is visible..");

        String vObjAccountColumn = Constants.TitanCustomersOR.getProperty("AccountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAccountColumn, "visible"));
        LogCapture.info("Account Column is visible..");

        String vObjClientNumberCoulmn = Constants.TitanCustomersOR.getProperty("ClientNumberCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberCoulmn, "visible"));
        LogCapture.info("Client Number Column is visible..");

        String vObjLegacyAccountCoulmn = Constants.TitanCustomersOR.getProperty("LegacyAccountCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLegacyAccountCoulmn, "visible"));
        LogCapture.info("Legacy Account Column is visible..");

        String vObjCountryCoulmn = Constants.TitanCustomersOR.getProperty("CountryCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCountryCoulmn, "visible"));
        LogCapture.info("Country Column is visible..");

        String vObjTypeColumn = Constants.TitanCustomersOR.getProperty("TypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTypeColumn, "visible"));
        LogCapture.info("Type Column is visible..");

        String vObjStatusColumn = Constants.TitanCustomersOR.getProperty("StatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatusColumn, "visible"));
        LogCapture.info("Status Column is visible..");

        String vObjAffiliateNumberColumn = Constants.TitanCustomersOR.getProperty("AffiliateNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAffiliateNumberColumn, "visible"));
        LogCapture.info("Affiliate Number Column is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        LogCapture.info("Customers page - All details are visible and Not error message..");

    }

    @Then("^User is able to view Conflicts page details in Titan and Not error message$")
    public void userIsAbleToViewConflictsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjConflictsInTitanHeader = Constants.TitanConflictsOR.getProperty("ConflictsInTitanHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictsInTitanHeader, "visible"));
        LogCapture.info("Conflicts page Header is visible..");

        String vObjConflictsPageLandingMsg = Constants.TitanConflictsOR.getProperty("ConflictsPageLandingMsg");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictsPageLandingMsg, "visible"));
        LogCapture.info("Conflicts Page Landing message is visible..");

        String vObjCustomerNumberHeader = Constants.TitanConflictsOR.getProperty("CustomerNumberHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerNumberHeader, "visible"));
        LogCapture.info("Customer Number header is visible..");

        String vObjCustomerNumberSearch = Constants.TitanConflictsOR.getProperty("CustomerNumberSearch");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerNumberSearch, "visible"));
        LogCapture.info("Customer Number Search field is visible..");

        String vObjSearchButton = Constants.TitanConflictsOR.getProperty("SearchButton");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSearchButton, "visible"));
        LogCapture.info("Search button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanConflictsOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Search Another customer is visible..");

        LogCapture.info("Conflicts page - All details are visible..");

    }

    @Then("^User is able to view Queues Incoming Funds page details in Titan and Not error message$")
    public void userIsAbleToViewQueuesIncomingFundsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjIncomingFundsHeader = Constants.TitanQueuesOR.getProperty("IncomingFundsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjIncomingFundsHeader, "visible"));
        LogCapture.info("Incoming Funds header is visible..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanQueuesOR.getProperty("DateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjOrganisationColumn = Constants.TitanQueuesOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanQueuesOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientNoColumn = Constants.TitanQueuesOR.getProperty("ClientNoColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNoColumn, "visible"));
        LogCapture.info("Client Number Column is visible..");

        String vObjClientNameColumn = Constants.TitanQueuesOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjDebtorColumn = Constants.TitanQueuesOR.getProperty("DebtorColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebtorColumn, "visible"));
        LogCapture.info("Debtor Column is visible..");

        String vObjCategoryColumn = Constants.TitanQueuesOR.getProperty("CategoryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCategoryColumn, "visible"));
        LogCapture.info("Category Column is visible..");

        String vObjSellCurrencyColumn = Constants.TitanQueuesOR.getProperty("SellCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellCurrencyColumn, "visible"));
        LogCapture.info("Sell Currency Column is visible..");

        String vObjAmountColumn = Constants.TitanQueuesOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible..");

        String vObjReferenceColumn = Constants.TitanQueuesOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible..");

        String vObjPaymentMethodColumn = Constants.TitanQueuesOR.getProperty("PaymentMethodColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentMethodColumn, "visible"));
        LogCapture.info("Payment Method Column is visible..");

        String vObjTitanStatusColumn = Constants.TitanQueuesOR.getProperty("TitanStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTitanStatusColumn, "visible"));
        LogCapture.info("Titan Status Column is visible..");

        String vObjAtlasStatusColumn = Constants.TitanQueuesOR.getProperty("AtlasStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAtlasStatusColumn, "visible"));
        LogCapture.info("Atlas Status Column is visible..");

        String vObjErrorReasonColumn = Constants.TitanQueuesOR.getProperty("ErrorReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjErrorReasonColumn, "visible"));
        LogCapture.info("Error Reason Column is visible..");


        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        LogCapture.info("Conflicts page - All details are visible..");

    }


    @Then("^User is able to view Queues Payment In page details in Titan and Not error message$")
    public void userIsAbleToViewQueuesPaymentInPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentsInHeader = Constants.TitanQueuesOR.getProperty("PaymentsInHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentsInHeader, "visible"));
        LogCapture.info("Payments In header is visible..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjSplitColumn = Constants.TitanQueuesOR.getProperty("SplitColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSplitColumn, "visible"));
        LogCapture.info("Split Column is visible..");

        String vObjOrganisationColumn = Constants.TitanQueuesOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjDateColumn = Constants.TitanQueuesOR.getProperty("DateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjStatementDateColumn = Constants.TitanQueuesOR.getProperty("StatementDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatementDateColumn, "visible"));
        LogCapture.info("Statement Date Column is visible..");

        String vObjValueDateColumn = Constants.TitanQueuesOR.getProperty("ValueDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjValueDateColumn, "visible"));
        LogCapture.info("Value Date Column is visible..");

        String vObjDebtorNameColumn = Constants.TitanQueuesOR.getProperty("DebtorNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebtorNameColumn, "visible"));
        LogCapture.info("Debtor Name Column is visible..");

        String vObjDebtorAccNoColumn = Constants.TitanQueuesOR.getProperty("DebtorAccNoColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebtorAccNoColumn, "visible"));
        LogCapture.info("Debtor Acc No Column is visible..");

        String vObjDebitEntryReasonColumn = Constants.TitanQueuesOR.getProperty("DebitEntryReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebitEntryReasonColumn, "visible"));
        LogCapture.info("Debit Entry Reason Column is visible..");

        String vObjSenderToReceiverInfoColumn = Constants.TitanQueuesOR.getProperty("SenderToReceiverInfoColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSenderToReceiverInfoColumn, "visible"));
        LogCapture.info("Sender To Receiver Info Column is visible..");

        String vObjCreditorReferenceColumn = Constants.TitanQueuesOR.getProperty("CreditorReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCreditorReferenceColumn, "visible"));
        LogCapture.info("Creditor Reference Column is visible..");

        String vObjRemitterReferenceColumn = Constants.TitanQueuesOR.getProperty("RemitterReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjRemitterReferenceColumn, "visible"));
        LogCapture.info("Remitter Reference Column is visible..");

        String vObjCCYCoulmn = Constants.TitanQueuesOR.getProperty("CCYCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYCoulmn, "visible"));
        LogCapture.info("CCY Coulmn is visible..");

        String vObjEntryTypeColumn = Constants.TitanQueuesOR.getProperty("EntryTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjEntryTypeColumn, "visible"));
        LogCapture.info("Entry Type Column is visible..");

        String vObjPaymentInAmountColumn = Constants.TitanQueuesOR.getProperty("PaymentInAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible..");

        String vObjFundTypeColumn = Constants.TitanQueuesOR.getProperty("FundTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFundTypeColumn, "visible"));
        LogCapture.info("Fund Type Column is visible..");

        String vObjFPTPColumn = Constants.TitanQueuesOR.getProperty("FPTPColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFPTPColumn, "visible"));
        LogCapture.info("FPTP Column is visible..");

        //Navigating on top of page
        JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        js.executeScript("window.scrollTo(0, 0)");
        Constants.key.pause("2", "");

        //Slid slider to right
        String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        Constants.key.pause("2", "");
        WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        int width = slider.getSize().getWidth();
        Actions move = new Actions(Constants.driver);
        move.moveToElement(slider, ((width * 10) / 100), 0).click();
        move.build().perform();
        LogCapture.info("Slider dragged to right...");
        Constants.key.pause("2", "");

        String vObjMethodColumn = Constants.TitanQueuesOR.getProperty("MethodColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjMethodColumn, "visible"));
        LogCapture.info("Method Column is visible..");

        String vObjClientNumberColumn = Constants.TitanQueuesOR.getProperty("ClientNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client Number (View all rules) column is visible..");

        String vObjPaymentInErrorReasonColumn = Constants.TitanQueuesOR.getProperty("PaymentInErrorReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInErrorReasonColumn, "visible"));
        LogCapture.info("Error Reason Column is visible..");

        String vObjStatusColumn = Constants.TitanQueuesOR.getProperty("StatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatusColumn, "visible"));
        LogCapture.info("Status Column is visible..");

        LogCapture.info("Payment In page - All details are visible..");


    }

    @Then("^User is able to view details such as CustomerName\"([^\"]*)\" CustomerNumber\"([^\"]*)\" Status\"([^\"]*)\" Brand\"([^\"]*)\" ClientType\"([^\"]*)\" Contact\"([^\"]*)\" CountryOfResidence\"([^\"]*)\" and Not error message$")
    public void userIsAbleToViewDetailsSuchAsCustomerNameCustomerNumberStatusBrandClientTypeContactCountryOfResidenceAndNotErrorMessage(String CustomerName, String CustomerNumber, String Status, String Brand, String ClientType, String Contact, String CountryOfResidence) throws Throwable {
        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String ExpectedCustomerName = "//h1[contains(text(),'" + CustomerName + " ')]";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedCustomerName, "visible"));
        LogCapture.info("Customer name: " + CustomerName + " is visible as expected..");

        String ExpectedCustomerNumber = "//h1[contains(text(),'#" + CustomerNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedCustomerNumber, "visible"));
        LogCapture.info("Customer Number: #" + CustomerNumber + " is visible as expected..");

        if (Status.equalsIgnoreCase("Active")) {
            String vObjActiveStatusIndicator = Constants.TitanCustomersOR.getProperty("ActiveStatusIndicator");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjActiveStatusIndicator, "visible"));
            LogCapture.info("Customer is Active...");
        }
        if (Status.equalsIgnoreCase("Inactive")) {
            String vObjInactiveStatusIndicator = Constants.TitanCustomersOR.getProperty("InactiveStatusIndicator");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInactiveStatusIndicator, "visible"));
            LogCapture.info("Customer is Inactive...");
        }

        String ExpectedBrand = "//dt[text()='Brand']//following-sibling::dd[text()='" + Brand + "']";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedBrand, "visible"));
        LogCapture.info("Brand: " + Brand + " is visible as expected..");

        String ExpectedClientType = "//dt[text()='Client Type']//following-sibling::dd[text()='" + ClientType + "']";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedClientType, "visible"));
        LogCapture.info("ClientType: " + ClientType + " is visible as expected..");

        String ExpectedContact = "//h2[text()='Contacts']//following::div[@class='tabs space-after']//a[text()='" + Contact + " ']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedContact, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedContact, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(ExpectedContact, ""));
        Constants.key.pause("2", "");
        String vObjContactPlusBtn = Constants.TitanCustomersOR.getProperty("ContactPlusBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjContactPlusBtn, ""));
        String ExpectedCountryOfResidence = "//dt[text()='Country of residence']//following-sibling::dd[text()='" + CountryOfResidence + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedCountryOfResidence, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedCountryOfResidence, "visible"));
        LogCapture.info("Country Of Residence: " + CountryOfResidence + " is visible as expected..");

    }

    @And("^User selects Payee\"([^\"]*)\" and clicks on Finished Adding Payment button and Yes button$")
    public void userSelectsPayeeAndClicksOnAddPaymentButton(String Payee) throws Throwable {
        String vObjAddAPaymentPage = Constants.CreateFxTicketOR.getProperty("AddAPaymentPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddAPaymentPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddAPaymentPage, "visible"));
        LogCapture.info("User is on 4 of 4: Add a Payment page...");

        String vObjSelectPayeeDownArrow = Constants.CreateFxTicketOR.getProperty("SelectPayeeDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjSearchPayee = Constants.CreateFxTicketOR.getProperty("SearchPayee");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchPayee, ""));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSearchPayee_FireFox = Constants.CreateFxTicketOR.getProperty("SearchPayee_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSearchPayee_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
            LogCapture.info("Payee: " + Payee + " is selected..");
        }

        String vObjFXFinishedAddPaymentBtn = Constants.CreateFxTicketOR.getProperty("FXFinishedAddPaymentBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXFinishedAddPaymentBtn, ""));
        LogCapture.info("Clicking on Finished Adding Payment button...");

        String vObjAddPaymentYesButton = Constants.CreateFxTicketOR.getProperty("AddPaymentYesButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentYesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjAddPaymentYesButton, ""));
        LogCapture.info("Clicking on YES button for pop-up...");

    }

    @And("^User is on (Credit page|Add Payment page) and clicks on Skip button$")
    public void userIsOnCreditPageAndClicksOnSkipButton(String page) throws Throwable {

        if (page.equalsIgnoreCase("Credit page")) {

            String vObjFXCreditPage = Constants.CreateFxTicketOR.getProperty("FXCreditPage");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXCreditPage, "visible"));
            LogCapture.info("User is on 3 of 4: Credit page...");

            String vObjFXCreditPageSkipBtn = Constants.CreateFxTicketOR.getProperty("FXCreditPageSkipBtn");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXCreditPageSkipBtn, ""));
            //    Assert.assertEquals("PASS", Constants.key.click(vObjFXCreditPageSkipBtn, ""));
            LogCapture.info("User clicks on SKIP button...");
        } else if (page.equalsIgnoreCase("Add Payment page")) {
            String vObjFXAddPaymentPage = Constants.CreateFxTicketOR.getProperty("ConfirmSkipBtn");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentPage, ""));
            LogCapture.info("User clicks on SKIP button...");
        }
    }


    @And("^User clicks on Yes button for FX (Credit|Add Payment) popup$")
    public void userClicksOnYesButtonForFXCreditSkipPopup(String value) throws Throwable {
        if (value.equalsIgnoreCase("Credit")) {
            String vObjFXCreditSkipYesBtn = Constants.CreateFxTicketOR.getProperty("FXCreditSkipYesBtn");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXCreditSkipYesBtn, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFXCreditSkipYesBtn, ""));
            LogCapture.info("Clicking on Yes button for FX credit skip pop-up....");
            Constants.key.pause("2", "");
        } else if (value.equalsIgnoreCase("Add Payment")) {
            String vObjFXAddPaymentSkipYesBtn = Constants.CreateFxTicketOR.getProperty("FXAddpaymentSkipButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXAddPaymentSkipYesBtn, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentSkipYesBtn, ""));
            LogCapture.info("Clicking on Yes button for FX Add Payment page pop-up....");
            Constants.key.pause("2", "");

        }


    }

    @And("^User clicks on CARDS tab under Linked to client(| for second time)$")
    public void clickOnCARDSTabUnderLinkedToClient(String Occurance) throws Throwable {
        if (Occurance.equalsIgnoreCase("")) {
            String vObjCARDSTab = Constants.CreateFxTicketOR.getProperty("CARDSTab");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCARDSTab, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCARDSTab, ""));
            LogCapture.info("Clicking on Cards tab...");
        }
        if (Occurance.equalsIgnoreCase(" for second time")) {
            String vObjCARDSTab = Constants.CreateFxTicketOR.getProperty("CARDSTab");
            String vObjWalletsTab = Constants.CreateFxTicketOR.getProperty("WalletsTab");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletsTab, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjWalletsTab, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjCARDSTab, ""));
            LogCapture.info("Clicking on Cards tab...");
        }
    }

    @And("^User clicks on Add Card button$")
    public void userClicksOnAddCardButton() throws Throwable {
        winHandleBefore = Constants.driver.getWindowHandle();
        String vObjAddCardBtn = Constants.CreateFxTicketOR.getProperty("AddCardBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCardBtn, ""));
        Constants.key.pause("4", "");
        LogCapture.info("Clicking on Add Card button...");

    }

    @And("^User enter only mandatory card details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userEnterCardDetailsSuchAs(String CardType, String CardNumber, String CVV, String ExpireDate, String CardholderName, String Country, String Postcode, String Address, String City, String State) throws Throwable {
        Constants.key.pause("5", "");

        //Switch to child window
        for (String winHandle : Constants.driver.getWindowHandles()) {
            Constants.driver.switchTo().window(winHandle);
            Constants.driver.manage().window().maximize();
            LogCapture.info("Switched to Child window...");
        }

        //Perform operation on child window

        //String vObjAddNewCardPage = "//h1[contains(text(),'Add a new card')]";
        String vObjAddNewCardPage = Constants.CreateFxTicketOR.getProperty("AddNewCardPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddNewCardPage, ""));
        LogCapture.info("Add new card page is visible on child window...");

        Constants.key.pause("3", "");

        String vObjCardType = Constants.CreateFxTicketOR.getProperty("CardType");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardType, ""));
        LogCapture.info("Clicking Card type dropdown...");

        String vObjSelectCardType = "//input[@data-name='" + CardType + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCardType, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectCardType, ""));
        LogCapture.info("Card type: " + CardType + " is selected...");

        String vObjCardNumber = Constants.CreateFxTicketOR.getProperty("CardNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardNumber, CardNumber));
        LogCapture.info("Card number entered is: " + CardNumber);

        String vObjCVVnumber = Constants.CreateFxTicketOR.getProperty("CVVnumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjCVVnumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVVnumber, CVV));
        LogCapture.info("CVV entered is: " + CVV);

        String vObjCardExpireDate = Constants.CreateFxTicketOR.getProperty("CardExpireDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardExpireDate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardExpireDate, ExpireDate));
        LogCapture.info("Expire date entered is: " + ExpireDate);

        String vObjCardHolderName = Constants.CreateFxTicketOR.getProperty("CardHolderName");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardHolderName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardHolderName, CardholderName));
        LogCapture.info("Card holder name entered is: " + CardholderName);


        String vObjCountryDropdown = Constants.CreateFxTicketOR.getProperty("CountryDropdown");
        String vObjSearchCountry = Constants.CreateFxTicketOR.getProperty("SearchCountry");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountryDropdown, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchCountry, Country));
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSearchCountry_FireFox = Constants.CreateFxTicketOR.getProperty("SearchCountry_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSearchCountry_FireFox, ""));
            LogCapture.info("Country: " + Country + " is selected..");
        } else {
            if (Country.equalsIgnoreCase("UK")) {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "upArrow"));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "enter"));
                LogCapture.info("Country: " + Country + " is selected..");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "downArrow"));
                Constants.key.pause("2", "");
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "enter"));
                LogCapture.info("Country: " + Country + " is selected..");
            }
            LogCapture.info("Country: " + Country + " is selected..");
            //            if(Country.equalsIgnoreCase("UK")){
//                if(Constants.driver.findElement(By.xpath("//ul[@class='singlelist__options--scrollable']//li/label[@for='rad-card-country-114']")).isDisplayed())
//                {
//                    String vUKField = Constants.CreateFxTicketOR.getProperty("UKField1");
//                    Assert.assertEquals("PASS" , Constants.key.VisibleConditionWait(vUKField, ""));
//                    Assert.assertEquals("PASS" , Constants.key.MouseFunctions(vUKField , "DoubleClick"));
//                }
//                else if(Constants.driver.findElement(By.xpath("//ul[@class='singlelist__options--scrollable']//li/label[@for='rad-card-country-119']")).isDisplayed()) {
//                    String vUKField = Constants.CreateFxTicketOR.getProperty("UKField2");
//                    Assert.assertEquals("PASS" , Constants.key.VisibleConditionWait(vUKField, ""));
//                    Assert.assertEquals("PASS" , Constants.key.MouseFunctions(vUKField , "DoubleClick"));
//                }
//                else{
//                    String vUKField = Constants.CreateFxTicketOR.getProperty("UKField3");
//                    Assert.assertEquals("PASS" , Constants.key.VisibleConditionWait(vUKField, ""));
//                    Assert.assertEquals("PASS" , Constants.key.MouseFunctions(vUKField , "DoubleClick"));
//                }
//            }
//            else {
//                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "downArrow"));
//            }
//            LogCapture.info("Country: " + Country + " is selected..");
        }

        String vObjPostcode = Constants.CreateFxTicketOR.getProperty("Postcode");
        Assert.assertEquals("PASS", Constants.key.click(vObjPostcode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPostcode, Postcode));
        LogCapture.info("Postcode entered is: " + Postcode);

        String vObjCardAddress = Constants.CreateFxTicketOR.getProperty("CardAddress");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardAddress, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardAddress, Address));
        LogCapture.info("Address entered is: " + Address);

        String vObjAddressTown = Constants.CreateFxTicketOR.getProperty("AddressTown");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressTown, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressTown, City));
        LogCapture.info("City entered is: " + City);

        String vObjAddressState = Constants.CreateFxTicketOR.getProperty("AddressState");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressState, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressState, State));
        LogCapture.info("State entered is: " + State);
        String vObjAddCardBtn = Constants.CreateFxTicketOR.getProperty("AddCardBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCardBtn, ""));
        LogCapture.info("Clicking on Add Card button...");
        //Constants.key.pause("5", "");
        //Constants.driver.close();

        String vObjCardAddedSuccessfulMsg = Constants.CreateFxTicketOR.getProperty("CardAddedSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCardAddedSuccessfulMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCardAddedSuccessfulMsg, "visible"));
        String ActualMsg = Constants.driver.findElement(By.xpath(vObjCardAddedSuccessfulMsg)).getText();
        if (ActualMsg.contains("added")) {
            LogCapture.info(ActualMsg);
        } else {
            LogCapture.info("Unable to add card... Error occured " + ActualMsg);
            Assert.fail();
        }
        Constants.key.pause("2", "");
        LogCapture.info("Card Added successfully message is visible...");

        // Switch back to the original browser (first window)
        Constants.driver.switchTo().window(winHandleBefore);
        String vObjBrand = "//dt[text()='Brand']";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBrand, "visible"));
    }

    @And("^User clicks on newly added card \"([^\"]*)\"$")
    public void userClicksOnNewlyAddedCard(String CardholderName) throws Throwable {

        String vObjSelectCard = "//tr[@id='customerCardDetail']//a[text()='" + CardholderName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCard, ""));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectCard, ""));
        LogCapture.info("user clicks on Card with name: " + CardholderName);
    }

    @And("^User is navigated to card details page$")
    public void userIsNavigatedToCardDetailsPage() throws Throwable {
        String vObjCardDetailsPage = Constants.CreateFxTicketOR.getProperty("CardDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCardDetailsPage, ""));
        LogCapture.info("User is on Card details page...");
    }

    @And("^User click on Delete card button$")
    public void userClickOnDeleteCardButton() throws Throwable {
        String vObjDeleteCardBtn = Constants.CreateFxTicketOR.getProperty("DeleteCardBtn");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjDeleteCardBtn, ""));
        LogCapture.info("Üser clisk on Delete card button..");
        String vObjDeleteCardYesBtn = Constants.CreateFxTicketOR.getProperty("DeleteCardYesBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteCardYesBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjDeleteCardYesBtn, ""));
        LogCapture.info("User clicks on Yes button..");
    }

    @And("^User is able to view Card deleted successful message$")
    public void userIsAbleToViewCardDeletedSuccessfulMessage() throws Throwable {
        String vObjCardDeleteSuccessfulMsg = Constants.CreateFxTicketOR.getProperty("CardDeleteSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCardDeleteSuccessfulMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCardDeleteSuccessfulMsg, "visible"));
        LogCapture.info("Card deleted successful message is visible...");
    }

    @And("^User selects Instructed by \"([^\"]*)\" Amount\"([^\"]*)\" Currency\"([^\"]*)\" and Click on Next button$")
    public void userSelectsInstructedByAmountCurrencyAndClickOnNextButton(String instructedBy, String Amount, String Currency) throws Throwable {

        String vObjBasicDetailsPage = Constants.TitanPaymentInOR.getProperty("BasicDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPage, ""));
        LogCapture.info("1 of 2: Basic details page is visible..");

        String vObjInstructedBySearch = Constants.TitanPaymentInOR.getProperty("InstructedBySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructedBySearch, instructedBy));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearch, "enter"));
        LogCapture.info("Instructed By: " + instructedBy + " is selected..");

        String vObjAmount = Constants.TitanPaymentInOR.getProperty("Amount");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Amount));
        LogCapture.info("User enters amount: " + Amount);

        String vObjCurrencyDropdownArrow = Constants.TitanPaymentInOR.getProperty("CurrencyDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyDropdownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCurrencyDropdownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencySearch = Constants.TitanPaymentInOR.getProperty("CurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencySearch, Currency));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vCurrencySearch_FireFox = Constants.TitanPaymentInOR.getProperty("CurrencySearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vCurrencySearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "enter"));
            LogCapture.info("Currency selected is: " + Currency);
        }
        Constants.key.pause("2", "");

        String vObjSourceOfFundsDropArrow = Constants.TitanPaymentInOR.getProperty("SourceOfFundsDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjSourceOfFundsDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjSourceOfFundsSearch = Constants.TitanPaymentInOR.getProperty("SourceOfFundsSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSourceOfFundsSearch, "SAVINGS"));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSourceOfFundsSearch_FireFox = Constants.TitanPaymentInOR.getProperty("SourceOfFundsSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSourceOfFundsSearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundsSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundsSearch, "enter"));
            LogCapture.info("Source of funds is: SAVINGS");
        }
        Constants.key.pause("2", "");
        String vObjBasicDetailsPageNextButton = Constants.TitanPaymentInOR.getProperty("BasicDetailsPageNextButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPageNextButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBasicDetailsPageNextButton, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User selects Payment method\"([^\"]*)\" for Titan Payment In$")
    public void userEntersPaymentMethodForTitanPaymentIn(String Method) throws Throwable {
        String vObjMethodDetailsPage = Constants.TitanPaymentInOR.getProperty("MethodDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMethodDetailsPage, ""));
        LogCapture.info("2 of 2: Method page is visible..");
        String vObjSelectMethod = null;
        if (Method.equalsIgnoreCase("Card")) {
            vObjSelectMethod = Constants.TitanPaymentInOR.getProperty("PaymentMethodCardTab");
        }
        if (Method.equalsIgnoreCase("Bank")) {
            vObjSelectMethod = Constants.TitanPaymentInOR.getProperty("PaymentMethodBankTab");
        }
        if (Method.equalsIgnoreCase("DD")) {
            vObjSelectMethod = Constants.TitanPaymentInOR.getProperty("PaymentMethodDDTab");
        }


        LogCapture.info(vObjSelectMethod);
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectMethod, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectMethod, ""));
        LogCapture.info("Method selected is: " + Method);

    }


    @And("^User selects Card \"([^\"]*)\" enters CVV \"([^\"]*)\" for Payment In$")
    public void userSelectsMethodCardSelectsCardEntersCVVForPaymentIn(String CardNumberFirst, String CVV) throws Throwable {
        String vObjSelectCardDownArrow = Constants.TitanPaymentInOR.getProperty("SelectCardDownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCardDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectCardDownArrow, ""));
        Constants.key.pause("2", "");

        String vObjSearchCard = Constants.TitanPaymentInOR.getProperty("SearchCard");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchCard, CardNumberFirst));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSearchCard_FireFox = Constants.TitanPaymentInOR.getProperty("SearchCard_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSearchCard_FireFox, ""));
            LogCapture.info("Card selected..");
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCard, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCard, "enter"));
            LogCapture.info("Card selected..");
        }

        String vObjCVVfield = Constants.TitanPaymentInOR.getProperty("CVVfield");
        Assert.assertEquals("PASS", Constants.key.click(vObjCVVfield, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVVfield, CVV));
        Constants.key.pause("2", "");
        LogCapture.info("CVV entered is: " + CVV);

    }

    @And("^User select Bank details for Titan Payment In$")
    public void userSelectBankDetailsForTitanPaymentIn() throws Throwable {

        String vObjSelectBankDownArrow = Constants.TitanPaymentInOR.getProperty("SelectBankDownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBankDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectBankDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjSelectBank = Constants.TitanPaymentInOR.getProperty("SelectBank");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectBank, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Bank selected: I am not sure");
    }

    @And("^User clicks on Finish button for Payment In$")
    public void userClicksOnFinishButtonForPaymentIn() throws Throwable {
        String vObjFinshBtn = Constants.TitanPaymentInOR.getProperty("FinshBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFinshBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFinshBtn, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User clicks on Finish button...");
    }

    @Then("^User is able to view Payment In successful message with (Bank|DD) payment for client number\"([^\"]*)\"$")
    public void userIsAbleToViewPaymentInSuccessfulMessageWithBankPaymentForClientNumber(String PaymentType, String clientNumber) throws Throwable {
        String ExpectedPaymentInBankMethodSuccessMsg = "//*[@class='message--positive' and contains(text(),' It is expected that it will be processed. Your Instruction Number is " + clientNumber + "-')]/*[text()='Your payment in instruction has been submitted.']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedPaymentInBankMethodSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedPaymentInBankMethodSuccessMsg, "visible"));
        LogCapture.info("Payment In Success message for " + PaymentType + " method is displayed for client number: " + clientNumber);
    }

    @And("^User is able to view Payment (in|out) message before submitting$")
    public void userIsAbleToViewPaymentInMessageBeforeSubmitting(String PaymentType) throws Throwable {
        String vObjPaymentInBeforeSubmitMsg = "//p[text()='Your payment " + PaymentType + " instruction is complete and ready to submit. Please check the summary before submitting.']";
        LogCapture.info(vObjPaymentInBeforeSubmitMsg);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInBeforeSubmitMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInBeforeSubmitMsg, "visible"));
        LogCapture.info("Before submission message is visible...");
    }


    @Then("^User is able to view Payment In successful with Card payment for client number\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userIsAbleToViewPaymentInSuccessfulWithCardPaymentForClientNumber(String clientNumber, String CardType, String CardNumber) throws Throwable {
        String CardNumberFirst = CardNumber.substring(0, 4);
        LogCapture.info(CardNumber);
        LogCapture.info(CardNumberFirst);
        String CardNumberLast = CardNumber.substring(12, 16);
        LogCapture.info(CardNumberLast);
        String ExpectedPaymentInBankMethodSuccessMsg = "//*[@class='message--positive' and contains(text(),' It is expected that it will be processed. Your Instruction Number is " + clientNumber + "-') and contains(text(),'AUTHCODE FOR " + CardType + "-" + CardNumberFirst + "********" + CardNumberLast + " is')]/*[text()='Your payment in instruction has been submitted.']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedPaymentInBankMethodSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedPaymentInBankMethodSuccessMsg, "visible"));
        LogCapture.info("Payment In Success message for bank method is displayed for client number: " + clientNumber);

    }

    @And("^User selects Instructed by \"([^\"]*)\" Currency\"([^\"]*)\" and Click on Next button for Payment Out$")
    public void userSelectsInstructedByCurrencyAndClickOnNextButtonForPaymentOut(String instructedBy, String Currency) throws Throwable {
        String vObjPaymentOutBasicDetailsPage = Constants.TitanPaymentOutOR.getProperty("PaymentOutBasicDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutBasicDetailsPage, ""));
        LogCapture.info("1 of 2: Basic details page is visible..");

        String vObjInstructionBySearch = Constants.TitanPaymentOutOR.getProperty("InstructionBySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionBySearch, instructedBy));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionBySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionBySearch, "enter"));
        LogCapture.info("Instructed By: " + instructedBy + " is selected..");

        String vObjCurrencyDropdownArrow = Constants.TitanPaymentOutOR.getProperty("CurrencyDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyDropdownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCurrencyDropdownArrow, ""));
        Constants.key.pause("3", "");
        String vObjCurrencySearch = Constants.TitanPaymentOutOR.getProperty("CurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencySearch, Currency));
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "enter"));
        LogCapture.info("Currency selected is: " + Currency);

        Constants.key.pause("3", "");
        String vObjBasicDetailsPageNextButton = Constants.TitanPaymentOutOR.getProperty("BasicDetailPageNextBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPageNextButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBasicDetailsPageNextButton, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User selects Payee\"([^\"]*)\" PaymentDate Amount\"([^\"]*)\" PurposeOfPayment\"([^\"]*)\"and clicks on Add Payment button and Yes button for Payment Out$")
    public void userSelectsPayeePaymentDateAmountPurposeOfPaymentAndClicksOnAddPaymentButtonAndYesButtonForPaymentOut(String Payee, String Amount, String purposeOfPayment) throws Throwable {
        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");

        String vObjPaymentDate = Constants.TitanPaymentOutOR.getProperty("PaymentDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDate, ""));
        Constants.key.pause("2", "");
        String vObjTodaysDate = Constants.TitanPaymentOutOR.getProperty("TodaysDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjTodaysDate, ""));
        LogCapture.info("Selecting Todays date...");

        String vObjAmount = Constants.TitanPaymentOutOR.getProperty("Amount");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Amount));
        LogCapture.info("Amount entred is: " + Amount);


        String vObjPurposeOfPaymentDropdownArrow = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPurposeOfPaymentDropdownArrow, ""));
        String vObjPurposeOfPaymentSearch = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPaymentSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
        LogCapture.info("Purpose of Payment: " + purposeOfPayment + " is selected..");

        String vObjAddPaymentBtn = Constants.TitanPaymentOutOR.getProperty("AddPaymentBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddPaymentBtn, ""));
        LogCapture.info("Clicked on Add Payment button...");
        String vObjPaymentOutYesBtn = Constants.TitanPaymentOutOR.getProperty("PaymentOutYesBtn");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjPaymentOutYesBtn, ""));
        LogCapture.info("Clicking on YES button for pop-up...");
    }

    @And("^User clicks on Finish Adding Payment button for Payment Out$")
    public void userClicksOnFinishAddingPaymentButtonForPaymentOut() throws Throwable {
        String vObjPayOutPayeeFinishAddingPayment = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeFinishAddingPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayOutPayeeFinishAddingPayment, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayOutPayeeFinishAddingPayment, ""));
        LogCapture.info("Clicked on Finish Adding Payment button...");
    }

    @Then("^User is able to view Payment Out successful message for client number\"([^\"]*)\"$")
    public void userIsAbleToViewPaymentOutSuccessfulMessageForClientNumber(String clientNumber) throws Throwable {
        String ExpectedPaymentOutBankMethodSuccessMsg = "//*[contains(text(),'Your payment Out instruction has been submitted. It is expected that it will be processed.Your Instruction Number is " + clientNumber + "-')]";
        LogCapture.info(ExpectedPaymentOutBankMethodSuccessMsg);
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedPaymentOutBankMethodSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedPaymentOutBankMethodSuccessMsg, "visible"));
        String PaymentOutSuccessMsg = Constants.driver.findElement(By.xpath(ExpectedPaymentOutBankMethodSuccessMsg)).getText();
        String[] vInstructionNumber = PaymentOutSuccessMsg.split("Your Instruction Number is ");
        InstructionNumber = vInstructionNumber[1].replace(".", "");
        LogCapture.info("Payment Out Success message for bank method is displayed for client number: " + clientNumber);
    }

    @And("^User selects Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\" according to DealType\"([^\"]*)\" UpperRatePercentage\"([^\"]*)\" and clicks on Fetch rates button(| for forward fixed type deal)$")
    public void userSelectsSellingCurrencyBuyingCurrencySellingAmountAccordingToDealTypeUpperRateAndClicksOnFetchRatesButton(String SellCurrency, String BuyCurrency, String sellingAmount, String DealType, String UpperRatePercentage, String ForwardSubType) throws Throwable {
        if (DealType.equalsIgnoreCase("Spot")) {
            String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSellingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSellingCurrencySearch_FireFox, ""));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            }

            Constants.key.pause("2", "");
            String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

            String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vBuyingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vBuyingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
                LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");
            }

            String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
            LogCapture.info("Amount: " + sellingAmount + " is entered..");

            String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
            LogCapture.info("User clicks on Fetch Rates button..");
            Constants.key.pause("4", "");
            String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
            String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
            if (LiveRate == null) {
                Assert.fail();
                LogCapture.info("Fetching rates.. Live Rate is Null...");
            } else {
                LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
            }
            LogCapture.info("Rates fetched..");

        }


        if (DealType.equalsIgnoreCase("Limit")) {
            String vObjLimitOrderCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("LimitOrderCurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLimitOrderCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("LimitOrderSellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
            LogCapture.info("Sell currency: " + SellCurrency + " is selected..");

            Constants.key.pause("2", "");
            String vObjLimitOrderBuyingCurrency = Constants.CreateFxTicketOR.getProperty("LimitOrderBuyingCurrencyDropArrow");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrency, ""));

            String vObjLimitOrderBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("LimitOrderBuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderBuyingCurrencySearch, BuyCurrency));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "enter"));
            LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

            String vObjLimitOrderSellingAmount = Constants.CreateFxTicketOR.getProperty("LimitOrderSellingAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderSellingAmount, sellingAmount));
            LogCapture.info("Amount: " + sellingAmount + " is entered..");

            String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
            LogCapture.info("User clicks on Fetch Rates button..");
            Constants.key.pause("4", "");
            String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
            String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
            if (LiveRate == null) {
                Assert.fail();
                LogCapture.info("Fetching rates.. Live Rate is Null...");
            } else {
                LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
            }
            LogCapture.info("Rates fetched..");

            String vObjSuggestedRate = Constants.CreateFxTicketOR.getProperty("SuggestedRate");
            String vSuggestedRateValNum = Constants.driver.findElement(By.xpath(vObjSuggestedRate)).getText();
            Constants.key.pause("2", "");
            int UpperRate = Integer.parseInt(UpperRatePercentage);
            double d = Double.parseDouble(vSuggestedRateValNum);
            double vDoubleCurrRate = ((UpperRate * d / 100) + d);
            String vTargetValueCalculated = Double.toString(vDoubleCurrRate);

            String vObjLimitLimitOrderUpperRate = Constants.CreateFxTicketOR.getProperty("LimitOrderUpperRate");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitLimitOrderUpperRate, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitLimitOrderUpperRate, vTargetValueCalculated));
            LogCapture.info("Upper rate entered is: " + vTargetValueCalculated);

            String vObjLimitOrderEndDateNoneCheckbox = Constants.CreateFxTicketOR.getProperty("LimitOrderEndDateNoneCheckbox");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderEndDateNoneCheckbox, ""));
            LogCapture.info("End date-good until cancelled selected...");
            Constants.key.pause("2", "");
        }

        if (DealType.equalsIgnoreCase("Forward")) {
            String vObjLimitOrderCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("ForwardOrderCurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLimitOrderCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vForwardOrderSellingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vForwardOrderSellingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            }

            Constants.key.pause("2", "");
            String vObjLimitOrderBuyingCurrency = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencyDropArrow");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrency, ""));

            String vObjLimitOrderBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderBuyingCurrencySearch, BuyCurrency));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vForwardOrderBuyingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vForwardOrderBuyingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "enter"));
                LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");
            }

            String vObjLimitOrderSellingAmount = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderSellingAmount, sellingAmount));
            LogCapture.info("Amount: " + sellingAmount + " is entered..");

            String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
            LogCapture.info("User clicks on Fetch Rates button..");
            Constants.key.pause("4", "");
            String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
            String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
            if (LiveRate == null) {
                Assert.fail();
                LogCapture.info("Fetching rates.. Live Rate is Null...");
            } else {
                LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
            }
            LogCapture.info("Rates fetched..");

            String vObjForwardOrderClientRatePercentage = Constants.CreateFxTicketOR.getProperty("ForwardOrderClientRatePercentage");
            Assert.assertEquals("PASS", Constants.key.click(vObjForwardOrderClientRatePercentage, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardOrderClientRatePercentage, UpperRatePercentage));
            LogCapture.info("Client rate % entered is: " + UpperRatePercentage);

            if (ForwardSubType.equalsIgnoreCase(" for forward fixed type deal")) {
                String vObjFixedForwardType = Constants.CreateFxTicketOR.getProperty("FixedForwardType");
                Assert.assertEquals("PASS", Constants.key.click(vObjFixedForwardType, ""));
                Constants.key.pause("2", "");
                LogCapture.info("Fixed forward selected..");
                String vObjSelectDate = Constants.CreateFxTicketOR.getProperty("SelectDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjSelectDate, ""));
                Constants.key.pause("2", "");
                String vObjDateMonthChangeNextBtn = Constants.CreateFxTicketOR.getProperty("DateMonthChangeNextBtn");
                Assert.assertEquals("PASS", Constants.key.click(vObjDateMonthChangeNextBtn, ""));
                Constants.key.pause("2", "");
                String vObjToDate = Constants.CreateFxTicketOR.getProperty("ToDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
                Constants.key.pause("2", "");
                LogCapture.info("Date selected...");
            } else {
                String vObjForwardOrderFromDate = Constants.CreateFxTicketOR.getProperty("ForwardOrderFromDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjForwardOrderFromDate, ""));
                Constants.key.pause("3", "");
                String vObjTodaysFromDate = Constants.CreateFxTicketOR.getProperty("TodaysFromDate");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTodaysFromDate, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjTodaysFromDate, ""));
                LogCapture.info("From Date selected...");
                String vObjForwardOrderToDate = Constants.CreateFxTicketOR.getProperty("ForwardOrderToDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjForwardOrderToDate, ""));
                Constants.key.pause("2", "");
                String vObjDateMonthChangeNextBtn = Constants.CreateFxTicketOR.getProperty("DateMonthChangeNextBtn");
                Assert.assertEquals("PASS", Constants.key.click(vObjDateMonthChangeNextBtn, ""));
                Constants.key.pause("2", "");
                String vObjToDate = Constants.CreateFxTicketOR.getProperty("ToDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
                Constants.key.pause("2", "");
                LogCapture.info("To Date selected...");
            }
        }

    }

    @Then("^User is able to view FX creation (successful message|decline message) for DealType\"([^\"]*)\" client number\"([^\"]*)\"$")
    public void userIsAbleToViewFXCreationSuccessfulMessageForDealTypeClientNumber(String message, String DealType, String clientNumber) throws Throwable {
        if (message.equalsIgnoreCase("successful message")) {
            String ExpectedFXSuccessfulMsgPart1 = null;
            String ExpectedFXSuccessfulMsgPart2 = null;
            if (DealType.equalsIgnoreCase("spot") || DealType.equalsIgnoreCase("Forward")) {
                ExpectedFXSuccessfulMsgPart1 = "//*[@id='fx-done-message' and contains(text(),'Thank you. Your FX instruction(" + clientNumber + "-')]";
                ExpectedFXSuccessfulMsgPart2 = "//*[@id='fx-done-message' and contains(text(),') has been created.')]";
            }
            if (DealType.equalsIgnoreCase("Limit")) {
                ExpectedFXSuccessfulMsgPart1 = "//*[@id='fx-done-message' and contains(text(),'Thank you. Your limit order(" + clientNumber + "-')]";
                ExpectedFXSuccessfulMsgPart2 = "//*[@id='fx-done-message' and contains(text(),') has been created.')]";
            }
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedFXSuccessfulMsgPart1, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedFXSuccessfulMsgPart1, "visible"));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedFXSuccessfulMsgPart2, "visible"));
            String vObjActualFXSuccessfulMsg = Constants.CreateFxTicketOR.getProperty("FXSuccessMsg");
            String ActualFXSuccessMsg = Constants.driver.findElement(By.xpath(vObjActualFXSuccessfulMsg)).getText();

            String[] vInstructionNumber = ActualFXSuccessMsg.split("-");
            String InstructionNumberOnly1 = vInstructionNumber[0].replaceAll("[^0-9]", "");
            String InstructionNumberOnly2 = vInstructionNumber[1].replaceAll("[^0-9]", "");
            InstructionNumber = InstructionNumberOnly1 + "-" + InstructionNumberOnly2;
            LogCapture.info("Instruction Number is: " + InstructionNumber);
            LogCapture.info("Actual FX creation Success message: " + ActualFXSuccessMsg);
            LogCapture.info("FX creation Success message is displayed for client number: " + clientNumber);
        } else if (message.equalsIgnoreCase("decline message")) {
            String ForwardDeclineText = Constants.CONFIG.getProperty("FXForwardDeclineText");
            String vObjDeclineMsg = Constants.CreateFxTicketOR.getProperty("FXForwardDeclineMsgText");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeclineMsg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjDeclineMsg, ForwardDeclineText));
            LogCapture.info("Decline text is visible on the page for the deal type " + DealType + " , " + clientNumber);
        }
    }

    @And("^User enters Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" and Clicks on Next button$")
    public void userEntersPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAndClicksOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country) throws Throwable {
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName + RandomStringUtils.randomAlphabetic(5);
            String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName + RandomStringUtils.randomAlphabetic(5);
            String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCompanyPayeeType, "selected"));
            LogCapture.info("Company Payee type is selected..");

            String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");
            PayeeCompanyName = CompanyName + RandomStringUtils.randomAlphabetic(5);
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vCurrencyReceiveSearch_FireFox = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vCurrencyReceiveSearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
            LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");
        }

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vCountrySearch_FireFox = Constants.TitanPayeeOR.getProperty("CountrySearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vCountrySearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        }
        LogCapture.info("Country selected is: " + Country);

        Constants.key.pause("3", "");


        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, "400066"));
        Constants.key.pause("2", "");

        String vObjGetAddressButton = Constants.TitanCustomersOR.getProperty("GetAddressButton");
        // Assert.assertEquals("PASS", Constants.key.click(vObjGetAddressButton, ""));
        Constants.key.pause("2", "");

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, "Avenue"));
        Constants.key.pause("2", "");

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, "New York"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeTownField, "tab"));
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" BankCodeType\"([^\"]*)\" BankCode\"([^\"]*)\" and click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberBankCodeTypeABANumberSWIFTCodeAndClickOnNextButton(String AccountNumber, String BankCodeType, String BankCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        if (AccountNumber.equalsIgnoreCase("")) {
            LogCapture.info("Account number NOT required but IBAN number for EUR required..");
            String vObjIBANNumber = Constants.TitanPayeeOR.getProperty("IBANNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjIBANNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIBANNumber, "ES9121000418450200051332"));
            LogCapture.info("IBAN number is entered..");


        } else {
            String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
            LogCapture.info("Account number is entered..");
        }
        if (BankCodeType.equalsIgnoreCase("ABA")) {
            String vObjABANumber = Constants.TitanPayeeOR.getProperty("ABANumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjABANumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjABANumber, BankCode));
            LogCapture.info("ABA number is entered..");

        }
        if (BankCodeType.equalsIgnoreCase("SWIFT")) {
            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number is entered..");
        }

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");
        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");

    }

    @And("^User is on Additional details page and clicks on Skip button$")
    public void userIsOnAdditionalDetailsPageAndClicksOnSkipButton() throws Throwable {
        String vObjAdditionalDetailsPage = Constants.TitanPayeeOR.getProperty("AdditionalDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAdditionalDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAdditionalDetailsPage, "visible"));
        LogCapture.info("User is on 3 of 3: Additional details page...");

        String vObjAdditionalDetailsSkipBtn = Constants.TitanPayeeOR.getProperty("AdditionalDetailsSkipBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAdditionalDetailsSkipBtn, ""));
        LogCapture.info("User clicks on SKIP button...");
    }

    @And("^Before submission message is displayed for (Payee|RT|FX)$")
    public void beforeSubmissionMessageIsDisplayedForPayee(String Type) throws Throwable {
        String vObjBeforeSubmitMsg = null;
        if (Type.equalsIgnoreCase("Payee")) {
            vObjBeforeSubmitMsg = Constants.TitanPayeeOR.getProperty("PayeeBeforeSubmitMsg");
        }
        if (Type.equalsIgnoreCase("RT")) {
            vObjBeforeSubmitMsg = Constants.TitanCustomersOR.getProperty("RTBeforeSuccessMsg");
        }
        if (Type.equalsIgnoreCase("FX")) {
            vObjBeforeSubmitMsg = Constants.CreateFxTicketOR.getProperty("FXBeforeSubmitMsg");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBeforeSubmitMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBeforeSubmitMsg, "visible"));
        LogCapture.info("Before submission message is visible...");
    }

    @And("^User is able to view Payee (created|updated) successful message$")
    public void userIsAbleToViewPayeeCreatedSuccessfulMessage(String TargetMsg) throws Throwable {
        if (TargetMsg.equalsIgnoreCase("created")) {
            String vObjPayeeSuccessMsg = Constants.TitanPayeeOR.getProperty("PayeeSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeSuccessMsg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeSuccessMsg, "visible"));
            LogCapture.info("Payee created successfully message is displayed.....");
        }
        if (TargetMsg.equalsIgnoreCase("updated")) {
            String vObjPayeeUpdatedMsg = Constants.TitanPayeeOR.getProperty("PayeeUpdatedMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeUpdatedMsg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeUpdatedMsg, "visible"));
            LogCapture.info("Payee updated successfully message is displayed.....");
        }
    }

    @And("^User search for Organisations\"([^\"]*)\" Currency\"([^\"]*)\" and EntryType\"([^\"]*)\" and hits Enter key$")
    public void userSearchForOrganisationsCurrencyAndEntryTypeAndHitsEnterKey(String Organisations, String Currency, String EntryType) throws Throwable {

        String vObjFilterSearchOrganisationDropdownArrow = Constants.TitanQueuesOR.getProperty("FilterSearchOrganisationDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilterSearchOrganisationDropdownArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisationList = Constants.TitanQueuesOR.getProperty("OrganisationOptionsList");
        List<WebElement> allElements = Constants.driver.findElements(By.xpath(vObjOrganisationList));
        for (WebElement ele : allElements) {
            String Currentelement = ele.getText();
            ele.click();
            Constants.key.pause("1", "");
            LogCapture.info("User deselected: " + Currentelement);
        }

        String vObjOrganisation = "//ul[@class='multilist__options']//input[@value='" + Organisations + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisations);

        String vObjCurrenciesDropArrow = Constants.TitanQueuesOR.getProperty("CurrenciesDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrenciesDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrenciesSearch = Constants.TitanQueuesOR.getProperty("CurrenciesSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrenciesSearch, Currency));
        Constants.key.pause("2", "");
        String vObjCurrencyMousehover = "//*[@value='" + Currency + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyMousehover, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjCurrencyMousehover, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCurrencyMousehover, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrenciesDropArrow, ""));
        LogCapture.info("Currency: " + Currency + " is selected..");

        String vObjEntryTypeDownArrow = Constants.TitanQueuesOR.getProperty("EntryTypeDownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEntryTypeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjEntryTypeDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjEntryType = "//*[@value='" + EntryType + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEntryType, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjEntryType, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjEntryTypeDownArrow, ""));
        LogCapture.info("Entry Type selected: " + EntryType);

        String vObjAmountHeader = Constants.TitanQueuesOR.getProperty("AmountHeader");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmountHeader, ""));

        String vObjApplyBtn = Constants.TitanQueuesOR.getProperty("ApplyBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjApplyBtn, ""));
        Constants.key.pause("2", "");
        LogCapture.info("USer clicks on Apply button..");
    }

    @And("^User is on clicks on any FX from the list$")
    public void userIsOnClicksOnAnyFXFromTheList() throws Throwable {
        String vObjPageNavigation = Constants.TitanFXTicketsOR.getProperty("PageNavigation");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPageNavigation, ""));
        Constants.key.pause("2", "");
        String vObjRandomFX = "//*[@id='fxTicketQueueTableBody']/tr[1]/td[7]/a";
        //String ReferenceNumber=Constants.driver.findElement(By.xpath(vObjRandomFX)).getText();
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRandomFX, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjRandomFX, ""));
        LogCapture.info("User selected FX with Reference number: ");
    }

    @And("^User navigates to FX ticket details page and clicks on Cancel FX button and Yes button$")
    public void userNavigatesToFXTicketDetailsPageAndClicksOnCancelFXButton() throws Throwable {
        String vObjFXTicketQueueHeader = Constants.TitanFXTicketsOR.getProperty("FXTicketQueueHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketQueueHeader, ""));
        LogCapture.info("User is on FX ticket for client page...");
        String vObjCancelFXBtn = Constants.TitanFXTicketsOR.getProperty("CancelFXBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjCancelFXBtn, ""));
        LogCapture.info("User clicks on Cancel FX button..");
        Constants.key.pause("2", "");

        String vObjCancelReasonDownArrow = Constants.TitanFXTicketsOR.getProperty("CancelReasonDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCancelReasonDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCancelReason1 = Constants.TitanFXTicketsOR.getProperty("CancelReason1");
        Assert.assertEquals("PASS", Constants.key.click(vObjCancelReason1, ""));
        LogCapture.info("User selects Cancel reason..");
        String vObjApplyBtn = Constants.TitanFXTicketsOR.getProperty("ApplyBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjApplyBtn, ""));
        LogCapture.info("User clicks on Apply button..");
        Constants.key.pause("2", "");

        String vObjPopUpYesBtn = Constants.TitanFXTicketsOR.getProperty("PopUpYesBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjPopUpYesBtn, ""));
        LogCapture.info("User clicks on Yes button..");

    }

    @And("^User navigates to FX ticket details page and clicks on Amend FX button and enters details \"([^\"]*)\" \"([^\"]*)\" and Yes button$")
    public void userNavigatesToFXTicketDetailsPageAndClicksOnAmendFXButtonAndEntersDetailsAndYesButton(String DealRate, String NewSellAmount) throws Throwable {
        String vObjFXTicketQueueHeader = Constants.TitanFXTicketsOR.getProperty("FXTicketQueueHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketQueueHeader, ""));
        LogCapture.info("User is on FX ticket for client page...");

        String vObjAmendFX = Constants.TitanFXTicketsOR.getProperty("AmendFX");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmendFX, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjAmendFX, ""));
        LogCapture.info("User clicks on Amend FX button..");
        Constants.key.pause("3", "");

        String vObjDateCalender = Constants.TitanFXTicketsOR.getProperty("CalenderDateTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDateCalender, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjDateCalender, ""));
        Constants.key.pause("7", "");

        String vFirstAvailableDate = Constants.TitanFXTicketsOR.getProperty("FirstAvailableDate");
        boolean FirstAvailableDate = Constants.driver.findElement(By.xpath(vFirstAvailableDate)).isDisplayed();
        String vLastAvailableDate = Constants.TitanFXTicketsOR.getProperty("LastAvailableDate");
        boolean LastAvailableDate = Constants.driver.findElement(By.xpath(vLastAvailableDate)).isDisplayed();
        LogCapture.info("First: " + FirstAvailableDate + " Last: " + LastAvailableDate);
        if (FirstAvailableDate) {
            Assert.assertEquals("PASS", Constants.key.click(vFirstAvailableDate, ""));
            Constants.key.pause("2", "");
            LogCapture.info("User selects Maturity date..");
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vLastAvailableDate, ""));
            Constants.key.pause("2", "");
            LogCapture.info("User selects Maturity date..");
        }
        //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDefaultDate, "MoveToElement"));
        //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDefaultDate, "click"));


        String vObjSellAmount = Constants.TitanFXTicketsOR.getProperty("SellAmount");
        Assert.assertEquals("PASS", Constants.key.click(vObjSellAmount, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellAmount, "selectall"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellAmount, "delete"));
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellAmount, NewSellAmount));
        LogCapture.info("New Sell Amount entered is: " + NewSellAmount);

        String vObjFetchRatesBtn = Constants.TitanFXTicketsOR.getProperty("FetchRatesBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjFetchRatesBtn, ""));
        Constants.key.pause("2", "");
        String vObjDealRateHeader = Constants.TitanFXTicketsOR.getProperty("DealRateHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealRateHeader, ""));
        LogCapture.info("Rates fetched successfully...");

        String vObjSuggestedRates = Constants.TitanFXTicketsOR.getProperty("SuggestedRates");
        String SuggestedRates = Constants.driver.findElement(By.xpath(vObjSuggestedRates)).getText();

        int DealRateInt = Integer.parseInt(DealRate);
        double d = Double.parseDouble(SuggestedRates);
        double vDoubleCurrRate = ((DealRateInt * d / 100) + d);
        String vTargetValueCalculated = Double.toString(vDoubleCurrRate);


        String vObjDealerRateInput = Constants.TitanFXTicketsOR.getProperty("DealerRateInput");
        Assert.assertEquals("PASS", Constants.key.click(vObjDealerRateInput, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjDealerRateInput, vTargetValueCalculated));
        LogCapture.info("Deal Rate entered: " + vTargetValueCalculated);

        String vObjAmendReasonDropArrow = Constants.TitanFXTicketsOR.getProperty("AmendReasonDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmendReasonDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjAmendReason = Constants.TitanFXTicketsOR.getProperty("AmendReason");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmendReason, ""));
        LogCapture.info("User selects Amend reason..");

        String vObjApplyBtn = Constants.TitanFXTicketsOR.getProperty("ApplyBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjApplyBtn, ""));
        LogCapture.info("User clicks on Apply button..");
        Constants.key.pause("2", "");

        // String vObjPopUpYesBtn= Constants.TitanFXTicketsOR.getProperty("PopUpYesBtn");
        //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPopUpYesBtn, ""));
        //Assert.assertEquals("PASS", Constants.key.click(vObjPopUpYesBtn, ""));
        //LogCapture.info("User clicks on Yes button..");

    }


    @And("^User is able to view successful message for FX cancelled$")
    public void userIsAbleToViewSuccessfulMessageForFXCancelled() throws Throwable {
        String vObjFXCancelledSuccessfulMsg = Constants.TitanFXTicketsOR.getProperty("FXCancelledSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXCancelledSuccessfulMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXCancelledSuccessfulMsg, "visible"));
        LogCapture.info("FX cancelled successful message visible...");

    }

    @Then("^User is able to view FX Amend successful message for clientNumber\"([^\"]*)\"$")
    public void userIsAbleToViewSuccessfulMessageForFXAmended(String clientNumber) throws Throwable {
        String vObjAmendSuccessfulMsg = Constants.TitanFXTicketsOR.getProperty("AmendSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmendSuccessfulMsg, ""));
        //String vObjInstructionNumberGenerated = Constants.TitanFXTicketsOR.getProperty("InstructionNumberGenerated");
        String vObjInstructionNumberGenerated = "//*[contains(text(),'Instruction Number : " + clientNumber + "-')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumberGenerated, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInstructionNumberGenerated, "visible"));
        String InstructionNumner = Constants.driver.findElement(By.xpath(vObjInstructionNumberGenerated)).getText();
        LogCapture.info("FX Amended successful message visible...");
        LogCapture.info("Instruction number message: " + InstructionNumner);
    }

    @And("^User selects FundType\"([^\"]*)\" Party\"([^\"]*)\" ClientNumber\"([^\"]*)\" clicks on Accept button and Yes button on Popup$")
    public void userSelectsFundTypePartyClientNumberClicksOnAcceptButtonAndYesButtonOnPopup(String FundType, String Party, String ClientNumber) throws Throwable {

        String vObjFirstRecord = "//*[@id='pillchoice-category-0']//*[@value='CP']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirstRecord, ""));
        Constants.key.pause("2", "");

        //Slid slider to right
        String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        Constants.key.pause("2", "");
        WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        int width = slider.getSize().getWidth();
        Actions move = new Actions(Constants.driver);
        move.moveToElement(slider, ((width * 10) / 100), 0).click();
        move.build().perform();
        LogCapture.info("Slider dragged to right...");
        Constants.key.pause("2", "");
        String TargetedCPEnable = null;
        for (int i = 0; i < 100; i++) {
            String vObjCP = "//*[@id='pillchoice-category-" + i + "']//*[@value='CP']";
            boolean vCPEnable = Constants.driver.findElement(By.xpath(vObjCP)).isEnabled();
            if (vCPEnable) {
                TargetedCPEnable = String.valueOf(i);
                LogCapture.info("target CP record: " + TargetedCPEnable);
                break;
            }
        }

        String vObjFundTypeFocused = "//*[@id='pillchoice-category-" + TargetedCPEnable + "']//*[@value='" + FundType + "']//parent::label";
        String vObjPartyFocused = "//*[@id='pillchoice-payment-type-" + TargetedCPEnable + "']//*[@value='" + Party + "']//parent::label";

        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFundTypeFocused, "visible"));
        String vObjFundType = Constants.driver.findElement(By.xpath(vObjFundTypeFocused)).getAttribute("class");
        LogCapture.info(vObjFundType);
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPartyFocused, "visible"));
        String vObjParty = Constants.driver.findElement(By.xpath(vObjPartyFocused)).getAttribute("class");
        LogCapture.info(vObjParty);
        if (vObjFundType.contains("focussed")) {
            LogCapture.info("Fund type already selected: " + FundType);
        } else {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFundTypeFocused, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFundTypeFocused, ""));
            LogCapture.info("Fund type clicked: " + FundType);
        }
        if (vObjParty.contains("focussed")) {
            LogCapture.info("Party already selected: " + Party);
        } else {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPartyFocused, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPartyFocused, ""));
            LogCapture.info("Party type clicked: " + Party);
        }
        Constants.key.pause("2", "");
        //String vObjClientNumber = Constants.TitanQueuesOR.getProperty("ClientNumber");
        String vObjClientNumber = "//*[@id='txt-accept-learn-" + TargetedCPEnable + "']";
        Assert.assertEquals("PASS", Constants.key.click(vObjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjClientNumber, ClientNumber));
        LogCapture.info("USer enters Client number: " + ClientNumber);

        //String vObjAcceptBtn = Constants.TitanQueuesOR.getProperty("AcceptBtn");
        String vObjAcceptBtn = "//*[@id='btn-accept-learn-accept-" + TargetedCPEnable + "']";
        Assert.assertEquals("PASS", Constants.key.click(vObjAcceptBtn, ""));
        LogCapture.info("User clicks on Accept button..");

        String vObjYesButton = Constants.TitanQueuesOR.getProperty("YesButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesButton, ""));
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
        LogCapture.info("User clicks on Yes button..");
        Constants.key.pause("3", "");
        try {
            String vObjErrorMsg = Constants.TitanQueuesOR.getProperty("LegalEntiyNotSupportedMsg");
            boolean vErrorMsg = Constants.driver.findElement(By.xpath(vObjErrorMsg)).isDisplayed();
            assert TargetedCPEnable != null;
            int j = Integer.parseInt(TargetedCPEnable);
            j++;
            while (Constants.driver.findElement(By.xpath(vObjErrorMsg)).isDisplayed()) {
                LogCapture.info("Error: Legal entity is not supported..");
                LogCapture.info("Trying for another record..");

                String UpdatedTargetedCPEnable = null;

                String vObjUpdatedCP = "//*[@id='pillchoice-category-" + j + "']//*[@value='CP']";
                boolean vUpdatedCPEnable = Constants.driver.findElement(By.xpath(vObjUpdatedCP)).isEnabled();
                if (vUpdatedCPEnable) {
                    UpdatedTargetedCPEnable = String.valueOf(j);
                    LogCapture.info("Updated target CP record: " + UpdatedTargetedCPEnable);
                    //break;
                }

                vObjFundTypeFocused = "//*[@id='pillchoice-category-" + UpdatedTargetedCPEnable + "']//*[@value='" + FundType + "']//parent::label";
                vObjPartyFocused = "//*[@id='pillchoice-payment-type-" + UpdatedTargetedCPEnable + "']//*[@value='" + Party + "']//parent::label";

                Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFundTypeFocused, "visible"));
                vObjFundType = Constants.driver.findElement(By.xpath(vObjFundTypeFocused)).getAttribute("class");
                LogCapture.info(vObjFundType);
                Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPartyFocused, "visible"));
                vObjParty = Constants.driver.findElement(By.xpath(vObjPartyFocused)).getAttribute("class");
                LogCapture.info(vObjParty);
                if (vObjFundType.contains("focussed")) {
                    LogCapture.info("Fund type already selected: " + FundType);
                } else {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFundTypeFocused, ""));
                    Constants.key.pause("2", "");
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFundTypeFocused, ""));
                    LogCapture.info("Fund type clicked: " + FundType);
                }
                if (vObjParty.contains("focussed")) {
                    LogCapture.info("Party already selected: " + Party);
                } else {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPartyFocused, ""));
                    Constants.key.pause("2", "");
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPartyFocused, ""));
                    LogCapture.info("Party type clicked: " + Party);
                }
                Constants.key.pause("2", "");
                //String vObjClientNumber = Constants.TitanQueuesOR.getProperty("ClientNumber");
                vObjClientNumber = "//*[@id='txt-accept-learn-" + UpdatedTargetedCPEnable + "']";
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClientNumber, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjClientNumber, ClientNumber));
                LogCapture.info("USer enters Client number: " + ClientNumber);

                //String vObjAcceptBtn = Constants.TitanQueuesOR.getProperty("AcceptBtn");
                vObjAcceptBtn = "//*[@id='btn-accept-learn-accept-" + UpdatedTargetedCPEnable + "']";
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAcceptBtn, ""));
                LogCapture.info("User clicks on Accept button..");

                vObjYesButton = Constants.TitanQueuesOR.getProperty("YesButton");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesButton, ""));
                Constants.key.pause("2", "");
                Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
                Constants.key.pause("2", "");
                if (Constants.driver.findElement(By.xpath(vObjYesButton)).isDisplayed()) {
                    Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
                    LogCapture.info("User clicks on Yes button..");
                }
                LogCapture.info("User clicks on Yes button..");
                Constants.key.pause("3", "");
                String vObjErrorMsgNew = Constants.TitanQueuesOR.getProperty("LegalEntiyNotSupportedMsg");
                boolean vErrorMsgNew = Constants.driver.findElement(By.xpath(vObjErrorMsgNew)).isDisplayed();
                if (!vErrorMsgNew) {
                    LogCapture.info("No error msg visible..");
                    break;
                }
                j++;

            }
        } catch (Exception e) {
            LogCapture.info("No Error...");
        }
    }

    @Then("^User is able to view successful message for allocation of funds via Payment In Queue$")
    public void userIsAbleToViewSuccessfulMessageForAllocationOfFundsViaPaymentInQueue() throws Throwable {

        String vObjPaymentInSuccessMsg = Constants.TitanQueuesOR.getProperty("PaymentInSuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInSuccessMsg, "visible"));
        LogCapture.info("Payment allocated successful message is visible..");

    }


    @And("^User search for Payee ClientName Organisation\"([^\"]*)\" and hits Enter key$")
    public void userSearchForPayeeClientNameOrganisationAndHitsEnterKey(String Organisation) throws Throwable {

        String vObjFilterSearchOrganisationDropdownArrow = Constants.TitanQueuesOR.getProperty("FilterSearchOrganisationDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilterSearchOrganisationDropdownArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisation = "//ul[@class='multilist__options']//input[@value='" + Organisation + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisation);
        Constants.key.pause("2", "");
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        String ClientName = PayeeFirstName + " " + PayeeLastName;
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, ClientName));
        LogCapture.info("Searching for Client name: " + ClientName);
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");
    }

    @And("^User clicks on newly added Payee from the list$")
    public void userClicksOnNewlyAddedPayeeFromTheList() throws Throwable {
        String ClientName = PayeeFirstName + " " + PayeeLastName;
        String vObjClientName = "//*[text()='" + ClientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClientName, ""));
        LogCapture.info("User clicks on client name: " + ClientName);
    }

    @And("^User is on Payee details page and clicks on Delete Payee button$")
    public void userIsOnPayeeDetailsPageAndClicksOnDeletePayeeButton() throws Throwable {
        String vObjPayeeDetailsHeader = Constants.TitanPayeeOR.getProperty("PayeeDetailsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailsHeader, ""));
        LogCapture.info("User is on Payee details page...");
        String vObjDeletePayeeBtn = Constants.TitanPayeeOR.getProperty("DeletePayeeBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjDeletePayeeBtn, ""));
        LogCapture.info("Clicks on Delete Payee button...");
        String vObjDeletePayeeYesBtn = Constants.TitanPayeeOR.getProperty("DeletePayeeYesBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeletePayeeYesBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjDeletePayeeYesBtn, ""));
        LogCapture.info("Clicks on YES button for Delete Payee..");
    }

    @Then("^User is able to view success message for Payee deleted$")
    public void userIsAbleToViewSuccessMessageForPayeeDeleted() throws Throwable {
        String vObjPayeeDeleteMsg = Constants.TitanPayeeOR.getProperty("PayeeDeleteMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDeleteMsg, ""));
        LogCapture.info("Payee deleted success message is visible..");
    }

    @And("^User checks the status of Payee is (Active|Inactive)$")
    public void userChecksTheStatusOfPayeeIsActive(String Status) throws Throwable {
        String ClientName = PayeeFirstName + " " + PayeeLastName;
        String vObjClientName = "//*[text()='" + ClientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));

        if (Status.equalsIgnoreCase("Active")) {
            String vObjCurrentStatus = "//*[text()='" + ClientName + "']//parent::td//following-sibling::td//*[text()='ACTIVE']";
            String ExpectedStatus = Constants.driver.findElement(By.xpath(vObjCurrentStatus)).getText();
            if (ExpectedStatus.equalsIgnoreCase("Active")) {
                LogCapture.info("Status is ACTIVE..");
            } else {
                LogCapture.info("Customer Status is INACTIVE but should be ACTIVE..");
                Assert.fail();
            }
        }
        if (Status.equalsIgnoreCase("Inactive")) {
            String vObjCurrentStatus = "//*[text()='" + ClientName + "']//parent::td//following-sibling::td//*[text()='INACTIVE']";
            String ExpectedStatus = Constants.driver.findElement(By.xpath(vObjCurrentStatus)).getText();
            if (ExpectedStatus.equalsIgnoreCase("Inactive")) {
                LogCapture.info("Status is INACTIVE..");
            } else {
                LogCapture.info("Customer Status is ACTIVE but should be INACTIVE..");
                Assert.fail();
            }

        }
    }

    @Then("^User is on Instructions page$")
    public void userIsOnInstructionsPageAndUserClicksOnDownloadPDFButton() throws Throwable {
        String vObjInstructionPageHeader = Constants.TitanInstructionsOR.getProperty("InstructionPageHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionPageHeader, ""));
        LogCapture.info("Instructions page is visible..");

    }

    @And("^User is on Regular Transfer page$")
    public void userIsOnRegularTransferPage() throws Throwable {
        String vObjRegularTransferHeader = Constants.TitanCustomersOR.getProperty("RegularTransferHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegularTransferHeader, ""));
        LogCapture.info("Regular transfer page is visible..");
    }


    @And("^User is Add new Transfer button$")
    public void userIsAddNewTransferButton() throws Throwable {
        String vObjAddNewTransferBtn = Constants.TitanCustomersOR.getProperty("AddNewTransferBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddNewTransferBtn, ""));
        LogCapture.info("Add new transfer button..");

    }

    @And("^User enters Basic details InstructedBy\"([^\"]*)\" SellCurrency\"([^\"]*)\" BuyCurrency\"([^\"]*)\" Amount\"([^\"]*)\" TransferType\"([^\"]*)\" and clicks on Next button$")
    public void userEntersBasicDetailsInstructedBySellCurrencyBuyCurrencyAmountTransferTypeAndClicksOnNextButton(String InstructedBy, String SellCurrency, String BuyCurrency, String Amount, String TransferType) throws Throwable {
        String vObjBasicDetailsPage = Constants.TitanCustomersOR.getProperty("BasicDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPage, ""));
        LogCapture.info("1 of 2: Basic details page visible..");

        String vObjRTInstructedByDropdownArrow = Constants.TitanCustomersOR.getProperty("RTInstructedByDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRTInstructedByDropdownArrow, ""));

        String vObjRTInstructedBySearch = Constants.TitanCustomersOR.getProperty("RTInstructedBySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRTInstructedBySearch, InstructedBy));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTInstructedBySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTInstructedBySearch, "enter"));
        LogCapture.info("Instructed By: " + InstructedBy + " is selected..");

        String vObjRTSellCurrencyDropArrow = Constants.TitanCustomersOR.getProperty("RTSellCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRTSellCurrencyDropArrow, ""));
        String vObjRTSellCurrencySearch = Constants.TitanCustomersOR.getProperty("RTSellCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRTSellCurrencySearch, SellCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTSellCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTSellCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");

        String vObjRTBuyCurrencyDropArrow = Constants.TitanCustomersOR.getProperty("RTBuyCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRTBuyCurrencyDropArrow, ""));
        String vObjRTBuyCurrencySearch = Constants.TitanCustomersOR.getProperty("RTBuyCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRTBuyCurrencySearch, BuyCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTBuyCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTBuyCurrencySearch, "enter"));
        LogCapture.info("Buy Currency: " + BuyCurrency + " is selected..");

        String vObjRTAmount = Constants.TitanCustomersOR.getProperty("RTAmount");
        Assert.assertEquals("PASS", Constants.key.click(vObjRTAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRTAmount, Amount));
        Constants.key.pause("2", "");
        LogCapture.info("Amount entered is: " + Amount);


        String vObjTransferType = null;
        if (TransferType.equalsIgnoreCase("Sell")) {
            vObjTransferType = Constants.TitanCustomersOR.getProperty("RTSellTransfer");
        }
        if (TransferType.equalsIgnoreCase("Buy")) {
            vObjTransferType = Constants.TitanCustomersOR.getProperty("RTBuyTransfer");
        }
        Assert.assertEquals("PASS", Constants.key.click(vObjTransferType, ""));
        LogCapture.info("Transfer type: " + TransferType + " is selected...");
        Constants.key.pause("2", "");
        String vObjBasicDetailsNextBtn = Constants.TitanCustomersOR.getProperty("BasicDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBasicDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }


    @And("^User enters Payment details Payee\"([^\"]*)\" PaymentMethod\"([^\"]*)\" CardholderName\"([^\"]*)\" EndDate RecurrenceType\"([^\"]*)\" RecurrenceMonth\"([^\"]*)\" DatePreference\"([^\"]*)\" PurposeOfPayment\"([^\"]*)\" and click on Finish button$")
    public void userEntersPaymentDetailsPayeePaymentMethodCardholderNameEndDateRecurrenceTypeRecurrenceDatePreferencePurposeOfPaymentAndClickOnFinishButton(String Payee, String PaymentMethod, String CardholderName, String RecurrenceType, String RecurrenceMonth, String DatePreference, String PurposeOfPayment) throws Throwable {

        String vObjPaymentDetailsPage = Constants.TitanCustomersOR.getProperty("PaymentDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentDetailsPage, ""));
        LogCapture.info("2 of 2: Payment details page visible..");

        String vObjPayeeSelectDropArrow = Constants.TitanCustomersOR.getProperty("PayeeSelectDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeSelectDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjPayeeSelectSearch = Constants.TitanCustomersOR.getProperty("PayeeSelectSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeSelectSearch, Payee));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeSelectSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeSelectSearch, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");


        if (PaymentMethod.equalsIgnoreCase("Card")) {
            String vObjPaymentMethod = Constants.TitanCustomersOR.getProperty("SelectMethodCard");
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
            LogCapture.info("Payment method: " + PaymentMethod + " is selected...");

            String vObjSelectCardDropArrow = Constants.TitanCustomersOR.getProperty("SelectCardDropArrow");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCardDropArrow, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectCardDropArrow, ""));
            Constants.key.pause("2", "");
            String vObjSelectCardSearch = Constants.TitanCustomersOR.getProperty("SelectCardSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSelectCardSearch, CardholderName));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectCardSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectCardSearch, "enter"));
            LogCapture.info("Card: " + CardholderName + " is selected..");
        }
        if (PaymentMethod.equalsIgnoreCase("DD")) {
            String vObjPaymentMethod = Constants.TitanCustomersOR.getProperty("SelectMethodDD");
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
            LogCapture.info("Payment method: " + PaymentMethod + " is selected...");
            String vObjSelectDirectDebitDropArrow = Constants.TitanCustomersOR.getProperty("SelectDirectDebitArrow");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectDirectDebitDropArrow, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectDirectDebitDropArrow, ""));
            Constants.key.pause("2", "");
            String vObjSelectDirectDebitSearch = Constants.TitanCustomersOR.getProperty("SelectDirectDebitSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSelectDirectDebitSearch, CardholderName));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectDirectDebitSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectDirectDebitSearch, "enter"));
            LogCapture.info("DD: " + CardholderName + " is selected..");
        }


        String vObjRecurrenceTypeDropArrow = Constants.TitanCustomersOR.getProperty("RecurrenceTypeDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRecurrenceTypeDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjRecurrenceTypeSearch = Constants.TitanCustomersOR.getProperty("RecurrenceTypeSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRecurrenceTypeSearch, RecurrenceType));
        Constants.key.pause("2", "");
        String vObjRecurrenceValue = "//*[@value='" + RecurrenceType + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjRecurrenceValue, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjRecurrenceValue, "click"));
        LogCapture.info("Recurrence Type: " + RecurrenceType + " is selected..");
        Constants.key.pause("4", "");

        String vObjPurposeOfPaymentDropArrow = Constants.TitanCustomersOR.getProperty("PurposeOfPaymentDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPaymentDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjPurposeOfPaymentSearch = Constants.TitanCustomersOR.getProperty("PurposeOfPaymentSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, PurposeOfPayment));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
        LogCapture.info("Purpose of Payment: " + PurposeOfPayment + " is selected..");


        String Recurrance = "//*[text()='Recurrence ']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(Recurrance, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(Recurrance, ""));
        Constants.key.pause("2", "");

        String numberOnly = DatePreference.replaceAll("[^0-9]", "");
        String vObjDateOnly = "//*[@value='" + numberOnly + "']//parent::label";
        String vObjRecurrenceDayDropArrow = Constants.TitanCustomersOR.getProperty("RecurrenceDayDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRecurrenceDayDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjRecurrenceDaySearch = Constants.TitanCustomersOR.getProperty("RecurrenceDaySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRecurrenceDaySearch, DatePreference));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDateOnly, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDateOnly, "click"));
        LogCapture.info("Date: " + DatePreference + " is selected..");
        Assert.assertEquals("PASS", Constants.key.click(Recurrance, ""));
        Constants.key.pause("10", "");


        if (RecurrenceType.equalsIgnoreCase("Monthly")) {

        } else if (RecurrenceType.equalsIgnoreCase("Quarterly") || RecurrenceType.equalsIgnoreCase("Yearly")) {
            String vObjRecurrenceMonthDropArrow = Constants.TitanCustomersOR.getProperty("RecurrenceMonthDropArrow");
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjRecurrenceMonthDropArrow, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjRecurrenceMonthDropArrow, "click"));
            //Assert.assertEquals("PASS", Constants.key.click(vObjRecurrenceMonthDropArrow, ""));
            Constants.key.pause("2", "");
            String vObjRecurrenceMonthSearch = Constants.TitanCustomersOR.getProperty("RecurrenceMonthSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRecurrenceMonthSearch, RecurrenceMonth));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRecurrenceMonthSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRecurrenceMonthSearch, "enter"));
            LogCapture.info("Recurrence Month: " + RecurrenceMonth + " is selected..");
        }
        Constants.key.pause("2", "");
        String vObjFinishBtn = Constants.TitanCustomersOR.getProperty("FinishBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFinishBtn, ""));
        LogCapture.info("clicked on Finish button....");

    }

    @Then("^User is able view RT created successfully$")
    public void userIsAbleViewRTCreatedSuccessfully() throws Throwable {
        String vObjSuccessMsgPartOne = Constants.TitanCustomersOR.getProperty("SuccessMsgPartOne");
        String vObjSuccessMsgPartTwo = Constants.TitanCustomersOR.getProperty("SuccessMsgPartTwo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSuccessMsgPartOne, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSuccessMsgPartOne, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSuccessMsgPartTwo, "visible"));
        LogCapture.info("RT created successful message is visible..");

    }

    @And("^user clicks on Submit button for RT$")
    public void userClicksOnSubmitButtonForRT() throws Throwable {
        String vObjSubmitRTBtn = Constants.TitanCustomersOR.getProperty("SubmitRTBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSubmitRTBtn, ""));
        LogCapture.info("clicked on Finish button....");

    }

    @And("^User search for Instruction number generated$")
    public void userSearchForInstructionNumberGenerated() throws Throwable {
        String vObjInstructionNumberSearch = Constants.TitanInstructionsOR.getProperty("InstructionNumberSearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionNumberSearch, InstructionNumber));


        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionNumberSearch, "enter"));
        LogCapture.info("Searching Instruction number: " + InstructionNumber);
        Constants.key.pause("4", "");
    }

    @And("^Download PDF button is (Disable|Enable)$")
    public void downlaodPDFButtonIsDisable(String ButtonStatus) throws Throwable {
        if (ButtonStatus.equalsIgnoreCase("Disable")) {
            String vObjDisableDownloadPDFbtn = Constants.TitanInstructionsOR.getProperty("DisableDownloadPDFbtn");
            String vObjInstructionNumber = "//*[text()='" + InstructionNumber + "']";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumber, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDisableDownloadPDFbtn, "visible"));
            LogCapture.info("PDF download button is disable..");
        }
        if (ButtonStatus.equalsIgnoreCase("Enable")) {
            String vObjEnableDownloadPDFbtn = Constants.TitanInstructionsOR.getProperty("EnableDownloadPDFbtn");
            String vObjInstructionNumber = "//*[text()='" + InstructionNumber + "']";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumber, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjEnableDownloadPDFbtn, "visible"));
            LogCapture.info("PDF download button is Enable..");
        }


    }

    @Then("^User enters basic details Organisation\"([^\"]*)\" Date Counterparty\"([^\"]*)\" B2BDeal\"([^\"]*)\" SellCurrency\"([^\"]*)\" BuyCurrency\"([^\"]*)\" EnterAmount\"([^\"]*)\" Amount\"([^\"]*)\" EnterRate\"([^\"]*)\" Rate\"([^\"]*)\" Blotter\"([^\"]*)\" and click on Book button for Treasury deal$")
    public void userEntersBasicDetailsOrganisationDateCounterpartyBBDealSellCurrencyBuyCurrencyEnterAmountAmountEnterRateRateBlotterAndClickOnBookButtonForTreasuryDeal(String Organisation, String Counterparty, String B2BDeal, String SellCurrency, String BuyCurrency, String EnterAmount, String Amount, String EnterRate, String Rate, String Blotter) throws Throwable {

        String vObjOrganisationDropArrow = Constants.TitanTreasuryOR.getProperty("OrganisationDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjOrganisationDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisation = "//ul[@class='singlelist__options org-list']//input[@value='" + Organisation + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisation);

        String vObjDateField = Constants.TitanTreasuryOR.getProperty("DateField");
        Assert.assertEquals("PASS", Constants.key.click(vObjDateField, ""));
        Constants.key.pause("2", "");
        String vObjTodaysHighlightedDate = Constants.TitanTreasuryOR.getProperty("TodaysHighlightedDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjTodaysHighlightedDate, ""));
        LogCapture.info("Today's Date selected..");


        String vObjCounterPartiesDropArrow = Constants.TitanTreasuryOR.getProperty("CounterPartiesDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCounterPartiesDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCounterPartiesSearch = Constants.TitanTreasuryOR.getProperty("CounterPartiesSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCounterPartiesSearch, Counterparty));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCounterPartiesSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCounterPartiesSearch, "enter"));
        LogCapture.info("Counterparty: " + Counterparty + " is selected..");

        if (B2BDeal.equalsIgnoreCase("Yes")) {
            String vObjB2BCheckBox = Constants.TitanTreasuryOR.getProperty("B2BCheckBox");
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BCheckBox, ""));
            Constants.key.pause("2", "");
            LogCapture.info("B2B deal checkbox is selected..");
        } else if (B2BDeal.equalsIgnoreCase("No")) {
            LogCapture.info("B2B deal checkbox is NOT selected..");
        }
        String vObjSellCurrencyDropArrow = Constants.TitanTreasuryOR.getProperty("SellCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjSellCurrencyDropArrow, ""));
        Constants.key.pause("4", "");
        String vObjSellCurrencySearch = Constants.TitanTreasuryOR.getProperty("SellCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellCurrencySearch, SellCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellCurrencySearch, "enter"));
        LogCapture.info("SellCurrency: " + SellCurrency + " is selected..");

        String vObjBuyCurrencyDropArrow = Constants.TitanTreasuryOR.getProperty("BuyCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyCurrencyDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjBuyCurrencySearch = Constants.TitanTreasuryOR.getProperty("BuyCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyCurrencySearch, BuyCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyCurrencySearch, "enter"));
        LogCapture.info("BuyCurrency: " + BuyCurrency + " is selected..");


        if (EnterAmount.equalsIgnoreCase("Sell")) {
            String vObjSellAmount = Constants.TitanTreasuryOR.getProperty("SellAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjSellAmount, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellAmount, Amount));
            LogCapture.info("Sell Amount entered is " + Amount);
        } else if (EnterAmount.equalsIgnoreCase("Buy")) {
            String vObjBuyAmount = Constants.TitanTreasuryOR.getProperty("BuyAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyAmount, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyAmount, Amount));
            LogCapture.info("Buy Amount entered is " + Amount);
        }

        if (EnterRate.equalsIgnoreCase("Rate")) {
            String vObjRateText = Constants.TitanTreasuryOR.getProperty("RateText");
            Assert.assertEquals("PASS", Constants.key.click(vObjRateText, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRateText, Rate));
            LogCapture.info("Rate entered is " + Rate);
        } else if (EnterRate.equalsIgnoreCase("Inverse")) {
            String vObjInverseRate = Constants.TitanTreasuryOR.getProperty("InverseRate");
            Assert.assertEquals("PASS", Constants.key.click(vObjInverseRate, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInverseRate, Rate));
            LogCapture.info("Inverse rate entered is " + Rate);
        }

        String vObjBlotterDropArrow = Constants.TitanTreasuryOR.getProperty("BlotterDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBlotterDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjBlotterSearch = Constants.TitanTreasuryOR.getProperty("BlotterSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBlotterSearch, Blotter));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBlotterSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBlotterSearch, "enter"));
        LogCapture.info("Blotter: " + Blotter + " is selected..");

        String vObjBookBtn = Constants.TitanTreasuryOR.getProperty("BookBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBookBtn, ""));
        LogCapture.info("User clicks on Book button..");


    }

    @Then("^User is able to view Treasury booked successful message$")
    public void userIsAbleToViewTreasuryBookedSuccessfulMessage() throws Throwable {
        String vObjTreasurySuccessMsg = Constants.TitanTreasuryOR.getProperty("TreasurySuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTreasurySuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTreasurySuccessMsg, "visible"));
        LogCapture.info("Treasury successfully created message is visible..");

    }


    @And("^User search for newly added deal details such as Organisation\"([^\"]*)\" TreasuryTicket\"([^\"]*)\" B2BDeal\"([^\"]*)\" FromCurrency\"([^\"]*)\" ToCurrency\"([^\"]*)\" DealType\"([^\"]*)\" Blotter\"([^\"]*)\"$")
    public void userSearchForNewlyAddedDealDetailsSuchAsOrganisationTreasuryTicketBBDealSellCurrencyBuyCurrencyDealTypeBlotter(String Organisation, String TreasuryTicket, String B2BDeal, String FromCurrency, String ToCurrency, String DealType, String Blotter) throws Throwable {
        String vObjB2BOrganisationDropArrow = Constants.TitanTreasuryOR.getProperty("B2BOrganisationDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjB2BOrganisationDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisation = "//ul[@class='multilist__options']//input[@value='" + Organisation + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisation);

        if (TreasuryTicket.equalsIgnoreCase("Yes")) {
            String vObjTreasuryTicketCheckbox = Constants.TitanTreasuryOR.getProperty("TreasuryTicketCheckbox");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjTreasuryTicketCheckbox, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Treasury ticket checkbox checked..");
        }
        if (TreasuryTicket.equalsIgnoreCase("No")) {
            LogCapture.info("Treasury ticket checkbox NOT checked..");
        }

        if (B2BDeal.equalsIgnoreCase("Yes")) {
            String vObjB2BFilterCheckBox = Constants.TitanTreasuryOR.getProperty("B2BFilterCheckBox");
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BFilterCheckBox, ""));
            Constants.key.pause("2", "");
            LogCapture.info("B2B deal checkbox is checked..");
        } else if (B2BDeal.equalsIgnoreCase("No")) {
            LogCapture.info("B2B deal checkbox is NOT checked..");
        }

        String vObjFromCurrencyDropArrow = Constants.TitanTreasuryOR.getProperty("FromCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjFromCurrencyDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjFromCurrencySearch = Constants.TitanTreasuryOR.getProperty("FromCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromCurrencySearch, FromCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromCurrencySearch, "enter"));
        LogCapture.info("From Currency: " + FromCurrency + " is selected..");

        String vObjToCurrencyDropArrow = Constants.TitanTreasuryOR.getProperty("ToCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjToCurrencyDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjToCurrencySearch = Constants.TitanTreasuryOR.getProperty("ToCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjToCurrencySearch, ToCurrency));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjToCurrencySearch, ToCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToCurrencySearch, "enter"));
        LogCapture.info("SellCurrency: " + ToCurrency + " is selected..");

        String vObjB2BBlotterDropArrow = Constants.TitanTreasuryOR.getProperty("B2BBlotterDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjB2BBlotterDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjBlotter = "//ul[@class='multilist__options']//input[@value='" + Blotter + "']/parent::label[contains(@for,'blotter')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlotter, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBlotter, ""));
        LogCapture.info("Blotter selected: " + Blotter);
        String vObjB2BBlotterHeader = Constants.TitanTreasuryOR.getProperty("B2BBlotterHeader");
        Assert.assertEquals("PASS", Constants.key.click(vObjB2BBlotterHeader, ""));


        String vObjDealTypeDropArrow = Constants.TitanTreasuryOR.getProperty("DealTypeDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealTypeDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjDealType = "//ul[@class='multilist__options']//input[@value='" + DealType + "']/parent::label[contains(@for,'dealtype')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealType, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealType, ""));
        LogCapture.info("Deal type selected: " + DealType);

        Assert.assertEquals("PASS", Constants.key.click(vObjB2BBlotterHeader, ""));

        String vObjApplyButton = Constants.TitanTreasuryOR.getProperty("ApplyButton");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjApplyButton, ""));
        LogCapture.info("User clicks on Apply button..");
        Constants.key.pause("5", "");
    }

    @And("^User selects the required ticket from records displayed and clicked on Update B2B button and Yes button$")
    public void userSelectsTheRequiredTicketFromRecordsDisplayed() throws Throwable {
        Constants.key.pause("2", "");
        String vObjFirstRecordSelect = Constants.TitanTreasuryOR.getProperty("FirstRecordSelect");
        Assert.assertEquals("PASS", Constants.key.click(vObjFirstRecordSelect, ""));
        LogCapture.info("User checked the checkbox for the record..");
        Constants.key.pause("2", "");
        String vObjUpdateB2BBtn = Constants.TitanTreasuryOR.getProperty("UpdateB2BBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjUpdateB2BBtn, ""));
        LogCapture.info("User clicked on Update B2B button..");
        Constants.key.pause("2", "");
        String vObjYesButton = Constants.TitanTreasuryOR.getProperty("YesButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
        LogCapture.info("User clicked on Yes button..");
    }

    @Then("^User is able to view successful message for Update$")
    public void userIsAbleToViewSuccessfulMessageForUpdate() throws Throwable {
        String vObjUpdateSuccessMsg = Constants.TitanTreasuryOR.getProperty("UpdateSuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUpdateSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdateSuccessMsg, "visible"));
        LogCapture.info("Success message is visible..");
    }

    @Then("^Slid the Slider button$")
    public void SlidTheSliderButton() throws Throwable {

        String vObjSliderButton = Constants.TitanTreasuryOR.getProperty("SliderButton");
        WebElement Element = Constants.driver.findElement(By.xpath(vObjSliderButton));
        Actions build = new Actions(Constants.driver);
        build.dragAndDropBy(Element, 50, 0).build().perform();
        LogCapture.info("Slider dragged to right...");
        Constants.key.pause("2", "");

    }

    @And("^User clicks on download PDF button$")
    public void userClicksOnDownloadPDFButton() throws Throwable {
        winHandleBefore = Constants.driver.getWindowHandle();
        WebElement link = Constants.driver.findElement(By.cssSelector(".downloadPDF"));
        link.click();
        Constants.key.pause("10", "");

    }

    @Then("^User is able to view horizontal slider$")
    public void userIsAbleToViewHorizontalSliderOnQueuesIncomingFundsPageInTitan() throws Throwable {

        String vObjIncomingFundsHeader = Constants.TitanCustomersOR.getProperty("InTitanPage");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjIncomingFundsHeader, "visible"));
        LogCapture.info("Incoming Funds header is visible..");

//        String vObjHorizontalTableSlider = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjHorizontalTableSlider, ""));
//        Assert.assertEquals("PASS", Constants.key.exist(vObjHorizontalTableSlider, "visible"));
//        LogCapture.info("Table slider is visible..");

    }

    @And("^User is able to view Queues Payment Out page details in Titan and Not error message$")
    public void userIsAbleToViewQueuesPaymentOutPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentsOutHeader = Constants.TitanQueuesOR.getProperty("PaymentsOutHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsOutHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentsOutHeader, "visible"));
        LogCapture.info("Payments Out header is visible..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjDateTimeColumn = Constants.TitanQueuesOR.getProperty("DateTimeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateTimeColumn, "visible"));
        LogCapture.info("Date/Time Column is visible..");

        String vObjOrganisationColumn = Constants.TitanQueuesOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanQueuesOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientColumn = Constants.TitanQueuesOR.getProperty("ClientColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientColumn, "visible"));
        LogCapture.info("Client # Column is visible..");

        String vObjPayeeNameColumn = Constants.TitanQueuesOR.getProperty("PayeeNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeNameColumn, "visible"));
        LogCapture.info("Payee Name Column is visible..");

        String vObjAmountColumn = Constants.TitanQueuesOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible..");

        String vObjCCYCoulmn = Constants.TitanQueuesOR.getProperty("CCYCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYCoulmn, "visible"));
        LogCapture.info("CCY Column is visible..");

        String vObjPayeeAccountNumberColumn = Constants.TitanQueuesOR.getProperty("PayeeAccountNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeAccountNumberColumn, "visible"));
        LogCapture.info("Payee Account Number Column is visible..");

        String vObjPayeeCountryColumn = Constants.TitanQueuesOR.getProperty("PayeeCountryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeCountryColumn, "visible"));
        LogCapture.info("Payee Country Column is visible..");

        String vObjTitanStatusColumn = Constants.TitanQueuesOR.getProperty("TitanStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTitanStatusColumn, "visible"));
        LogCapture.info("Titan Status Column is visible..");

        String vObjReferenceColumn = Constants.TitanQueuesOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible..");

        String vObjInstructionNumberColumn = Constants.TitanQueuesOR.getProperty("InstructionNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInstructionNumberColumn, "visible"));
        LogCapture.info("Instruction Number Column is visible..");

        String vObjReasonColumn = Constants.TitanQueuesOR.getProperty("ReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReasonColumn, "visible"));
        LogCapture.info("Reason Column is visible..");

        //Navigating on top of page
        JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        js.executeScript("window.scrollTo(0, 0)");
        Constants.key.pause("2", "");

        //Slid slider to right
//        String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
//        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
//        Constants.key.pause("2", "");
//        WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
//        int width = slider.getSize().getWidth();
//        Actions move = new Actions(Constants.driver);
//        move.moveToElement(slider, ((width * 10) / 100), 0).click();
//        move.build().perform();
//        LogCapture.info("Slider dragged to right...");
//        Constants.key.pause("2", "");

        String vObjErrorReasonColumn = Constants.TitanQueuesOR.getProperty("ErrorReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjErrorReasonColumn, "visible"));
        LogCapture.info("Error Reason Column is visible..");

        String vObjConflictStatusColumn = Constants.TitanQueuesOR.getProperty("ConflictStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictStatusColumn, "visible"));
        LogCapture.info("Conflict Status Column is visible..");

        String vObjPayOutAtlasStatusColumn = Constants.TitanQueuesOR.getProperty("PaymentOutAtlasStatus");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayOutAtlasStatusColumn, "visible"));
        LogCapture.info("Atlas Status Column is visible..");

        String vObjBankingStatusColumn = Constants.TitanQueuesOR.getProperty("BankingStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBankingStatusColumn, "visible"));
        LogCapture.info("Banking Status Column is visible..");

        String vObjClientTypeColumn = Constants.TitanQueuesOR.getProperty("ClientTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTypeColumn, "visible"));
        LogCapture.info("Client Type Column is visible..");

        String vObjDealerNameColumn = Constants.TitanQueuesOR.getProperty("DealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        String vObjUpdatedByColumn = Constants.TitanQueuesOR.getProperty("UpdatedByColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdatedByColumn, "visible"));
        LogCapture.info("UpdatedBy Column is visible..");

        LogCapture.info("Payment Out page - All details are visible..");
    }

    @And("^User is able to view Queues FX Ticket page details in Titan and Not error message$")
    public void userIsAbleToViewQueuesFXTicketPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
        LogCapture.info("User is on FX tickets in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanQueuesOR.getProperty("DateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjOrganisationColumn = Constants.TitanQueuesOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanQueuesOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientColumn = Constants.TitanQueuesOR.getProperty("ClientColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientColumn, "visible"));
        LogCapture.info("Client # Column is visible..");

        String vObjClientNameColumn = Constants.TitanQueuesOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjReferenceColumn = Constants.TitanQueuesOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible...");

        String vObjSellCurrencyColumn = Constants.TitanQueuesOR.getProperty("SellCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellCurrencyColumn, "visible"));
        LogCapture.info("Sell Currency Column is visible..");

        String vObjSellAmountColumn = Constants.TitanQueuesOR.getProperty("SellAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellAmountColumn, "visible"));
        LogCapture.info("Sell Amount Column is visible..");

        String vObjBuyCurrencyColumn = Constants.TitanQueuesOR.getProperty("BuyCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyCurrencyColumn, "visible"));
        LogCapture.info("Buy Currency Column is visible..");

        String vObjBuyAmountColumn = Constants.TitanQueuesOR.getProperty("BuyAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyAmountColumn, "visible"));
        LogCapture.info("Buy Amount Column is visible..");

        String vObjRateColumn = Constants.TitanQueuesOR.getProperty("RateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjRateColumn, "visible"));
        LogCapture.info("Rate Column is visible..");

        String vObjFXTypeColumn = Constants.TitanQueuesOR.getProperty("FXTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXTypeColumn, "visible"));
        LogCapture.info("FX Type Column is visible..");

//        Navigating on top of page
//
//        WebElement element = Constants.driver.findElement(By.xpath(vObjFXTypeColumn));
//        JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
//        js.executeScript("window.scrollTo(0, 0)");
//        Constants.key.pause("2", "");


        //Slid slider to right
//        String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
//       if (Constants.driver.findElement(By.xpath(vObjSliderButton)).isDisplayed()) {
//           Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
//         Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
//        Constants.key.pause("2", "");
//            WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
//           int width = slider.getSize().getWidth();
//           Actions move = new Actions(Constants.driver);
//           move.moveToElement(slider, ((width * 10) / 100), 0).click();
//           move.build().perform();
//           LogCapture.info("Slider dragged to right...");
//           Constants.key.pause("2", "");
//        } else {
//          String vObjFXTableScrollbarVisible = Constants.TitanCustomersOR.getProperty("FXTableScrollbarVisible");
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXTableScrollbarVisible, "visible"));
//            LogCapture.info("Table scroll is visible..");
//        }
        String vObjStatusColumn = Constants.TitanQueuesOR.getProperty("StatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatusColumn, "visible"));
        LogCapture.info("Status Column is visible..");

        String vObjConflictStatusColumn = Constants.TitanQueuesOR.getProperty("ConflictStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictStatusColumn, "visible"));
        LogCapture.info("Conflict Status Column is visible..");

        String vObjReasonColumn = Constants.TitanQueuesOR.getProperty("ReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReasonColumn, "visible"));
        LogCapture.info("Reason Column is visible..");

        String vObjErrorReasonColumn = Constants.TitanQueuesOR.getProperty("FXErrorReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjErrorReasonColumn, "visible"));
        LogCapture.info("Error Reason Column is visible..");

        String vObjDealerNameColumn = Constants.TitanQueuesOR.getProperty("DealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        String vObjClientTypeColumn = Constants.TitanQueuesOR.getProperty("ClientTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTypeColumn, "visible"));
        LogCapture.info("Client Type Column is visible..");

        LogCapture.info("FX Tickets page - All details are visible..");
    }

    @And("^User is able to view Payment In Reports page details in Titan and Not error message$")
    public void userIsAbleToViewPaymentInReportsPageDetailsInTitanAndNotErrorMessage() throws Throwable {
        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");
        String vObjPaymentInReportPage = Constants.TitanReportsOR.getProperty("PaymentInReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportPage, ""));
        LogCapture.info("User is on Payments In Reports in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanReportsOR.getProperty("DateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date column is visible..");

        String vObjOrganisationColumn = Constants.TitanReportsOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanReportsOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner column is visible..");

        String vObjLegalEntityColumn = Constants.TitanReportsOR.getProperty("LegalEntityColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLegalEntityColumn, "visible"));
        LogCapture.info("Legal Entity column is visible..");

        String vObjDebtorAccCardNoColumn = Constants.TitanReportsOR.getProperty("DebtorAccCardNoColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebtorAccCardNoColumn, "visible"));
        LogCapture.info("Debtor Acc No/Card No column is visible..");

        String vObjCCYColumn = Constants.TitanReportsOR.getProperty("CCYColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYColumn, "visible"));
        LogCapture.info("CCY column is visible..");

        String vObjAmountColumn = Constants.TitanReportsOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount column is visible..");

        String vObjReferenceColumn = Constants.TitanReportsOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference column is visible..");

        String vObjFTTPColumn = Constants.TitanReportsOR.getProperty("FTTPColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFTTPColumn, "visible"));
        LogCapture.info("FT/TP column is visible..");

        String vObjClientNumberColumn = Constants.TitanReportsOR.getProperty("ClientNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client Number column is visible..");

        String vObjClientNameColumn = Constants.TitanReportsOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name column is visible..");

        String vObjStatusColumn = Constants.TitanReportsOR.getProperty("StatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatusColumn, "visible"));
        LogCapture.info("Status column is visible..");

        String vObjModeOfPaymentColumn = Constants.TitanReportsOR.getProperty("ModeOfPaymentColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjModeOfPaymentColumn, "visible"));
        LogCapture.info("Mode Of Payment column is visible..");

        String vObjSourceApplicationColumn = Constants.TitanReportsOR.getProperty("SourceApplicationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSourceApplicationColumn, "visible"));
        LogCapture.info("Source Application column is visible..");

        String vObjFICountryColumn = Constants.TitanReportsOR.getProperty("FICountryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFICountryColumn, "visible"));
        LogCapture.info("FI Country column is visible..");

        //Navigating on top of page
        // JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        // js.executeScript("window.scrollTo(0, 0)");
        // Constants.key.pause("2", "");

        //Slid slider to right
        //String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        //Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        //Constants.key.pause("2", "");
        //WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        //int width = slider.getSize().getWidth();
        //Actions move = new Actions(Constants.driver);
        //move.moveToElement(slider, ((width * 10) / 100), 0).click();
        //move.build().perform();
        //LogCapture.info("Slider dragged to right...");
        //Constants.key.pause("2", "");

        String vObjUpdatedByDateTimeColumn = Constants.TitanReportsOR.getProperty("UpdatedByDateTimeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdatedByDateTimeColumn, "visible"));
        LogCapture.info("Updated by-Date & Time column is visible..");

        String vObjUpdatedByColumn = Constants.TitanReportsOR.getProperty("UpdatedByColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdatedByColumn, "visible"));
        LogCapture.info("Updated by column is visible..");

        String vObjAllocatedTypeColumn = Constants.TitanReportsOR.getProperty("AllocatedTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAllocatedTypeColumn, "visible"));
        LogCapture.info("Allocated Type column is visible..");

        String vObjDebitReasonColumn = Constants.TitanReportsOR.getProperty("DebitReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebitReasonColumn, "visible"));
        LogCapture.info("Debit Reason column is visible..");

        LogCapture.info("Payment In Reports page - All details are visible..");

    }

    @Then("^User is able to view Payment Out Reports page details in Titan and Not error message$")
    public void userIsAbleToViewPaymentOutReportsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
        LogCapture.info("User is on Payments Out Reports in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanReportsOR.getProperty("PayOutDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanReportsOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientNumberColumn = Constants.TitanReportsOR.getProperty("ClientNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client Number column is visible..");

        String vObjClientNameColumn = Constants.TitanReportsOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjCCYColumn = Constants.TitanReportsOR.getProperty("CCYColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYColumn, "visible"));
        LogCapture.info("CCY column is visible..");

        String vObjAmountColumn = Constants.TitanReportsOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible...");

        String vObjPayeeAccountNumberColumn = Constants.TitanReportsOR.getProperty("PayeeAccountNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeAccountNumberColumn, "visible"));
        LogCapture.info("Payee Account Number Column is visible..");

        String vObjPayeeNameColumn = Constants.TitanReportsOR.getProperty("PayeeNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeNameColumn, "visible"));
        LogCapture.info("Payee Name Column is visible..");

        String vObjPayeeCountryColumn = Constants.TitanReportsOR.getProperty("PayeeCountryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeCountryColumn, "visible"));
        LogCapture.info("Payee Country Column is visible..");

        String vObjTitanStatusColumn = Constants.TitanReportsOR.getProperty("TitanStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTitanStatusColumn, "visible"));
        LogCapture.info("Titan Status Column is visible..");

        String vObjReferenceColumn = Constants.TitanReportsOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible..");

        String vObjInstructionNumberColumn = Constants.TitanReportsOR.getProperty("InstructionNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInstructionNumberColumn, "visible"));
        LogCapture.info("Instruction Number Column is visible..");

        //Navigating on top of page

        // JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        //js.executeScript("window.scrollTo(0, 0)");
        // Constants.key.pause("2", "");

        //Slid slider to right
        //String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        //Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        //Constants.key.pause("2", "");
        //WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        //int width = slider.getSize().getWidth();
        //Actions move = new Actions(Constants.driver);
        //move.moveToElement(slider, ((width * 10) / 100), 0).click();
        //move.build().perform();
        //LogCapture.info("Slider dragged to right...");
        //Constants.key.pause("2", "");

        String vObjAtlasStatusColumn = Constants.TitanReportsOR.getProperty("AtlasStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAtlasStatusColumn, "visible"));
        LogCapture.info("Atlas Status Column is visible..");

        String vObjBankingStatusColumn = Constants.TitanReportsOR.getProperty("BankingStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBankingStatusColumn, "visible"));
        LogCapture.info("Banking Status Column is visible..");

        String vObjClientTypeColumn = Constants.TitanReportsOR.getProperty("ClientTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTypeColumn, "visible"));
        LogCapture.info("Client Type Column is visible..");

        String vObjDealerNameColumn = Constants.TitanReportsOR.getProperty("DealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        LogCapture.info("Payment Out Reports page - All details are visible..");

    }

    @And("^User is able to view FX tickets Reports page details in Titan and Not error message$")
    public void userIsAbleToViewFXTicketsReportsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXticketsReportPage = Constants.TitanReportsOR.getProperty("FXticketsReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXticketsReportPage, ""));
        LogCapture.info("User is on FX tickets Reports in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanReportsOR.getProperty("FXDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjOrganisationColumn = Constants.TitanReportsOR.getProperty("FXOrgColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanReportsOR.getProperty("FXBusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientNumberColumn = Constants.TitanReportsOR.getProperty("FXClientNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client Number column is visible..");

        String vObjClientNameColumn = Constants.TitanReportsOR.getProperty("FXClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjReferenceColumn = Constants.TitanReportsOR.getProperty("FXReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible..");

        String vObjSellCurrencyColumn = Constants.TitanReportsOR.getProperty("FXSellCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellCurrencyColumn, "visible"));
        LogCapture.info("Sell Currency Column is visible..");

        String vObjSellAmountColumn = Constants.TitanReportsOR.getProperty("FXSellAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellAmountColumn, "visible"));
        LogCapture.info("Sell Amount Column is visible..");

        String vObjBuyCurrencyColumn = Constants.TitanReportsOR.getProperty("FXBuyCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyCurrencyColumn, "visible"));
        LogCapture.info("Buy Currency Column is visible..");

        String vObjBuyAmountColumn = Constants.TitanReportsOR.getProperty("FXBuyAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyAmountColumn, "visible"));
        LogCapture.info("Buy Amount Column is visible..");

        String vObjRateColumn = Constants.TitanReportsOR.getProperty("FXRateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjRateColumn, "visible"));
        LogCapture.info("Rate Column is visible..");

        String vObjFXTypeColumn = Constants.TitanReportsOR.getProperty("FXTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXTypeColumn, "visible"));
        LogCapture.info("FX Type Column is visible..");

        String vObjFXStatusColumn = Constants.TitanReportsOR.getProperty("FXStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXStatusColumn, "visible"));
        LogCapture.info("Status Column is visible..");

        String vObjFXProfitColumn = Constants.TitanReportsOR.getProperty("FXProfitColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXProfitColumn, "visible"));
        LogCapture.info("Profit Column is visible..");

        String vObjDealerNameColumn = Constants.TitanReportsOR.getProperty("FXDealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        //Navigating on top of page
        //JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        //js.executeScript("window.scrollTo(0, 0)");
        //Constants.key.pause("10", "");

        //Slid slider to right
        //String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        //Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        //Constants.key.pause("2", "");
        //WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        //int width = slider.getSize().getWidth();
        //Actions move = new Actions(Constants.driver);
        //move.moveToElement(slider, ((width * 10) / 100), 0).click();
        //move.build().perform();
        //LogCapture.info("Slider dragged to right...");
        //Constants.key.pause("2", "");


        String vObjClientTypeColumn = Constants.TitanReportsOR.getProperty("FXClientTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTypeColumn, "visible"));
        LogCapture.info("Client Type Column is visible..");

        String vObjFXDueToColumn = Constants.TitanReportsOR.getProperty("FXDueToColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXDueToColumn, "visible"));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXDueToColumn, ""));
        LogCapture.info("FX ticket report page - All details are visible..");
    }


    @And("^User clicks on (Filter icon|Incoming funds Queue|Payment out Queue|FX tickets queue)$")
    public void userClicksOnFilterIcon(String option) throws Throwable {
        if (option.equals("Filter icon")) {
            String vObjFilter = Constants.TitanPaymentInOR.getProperty("FilterIcon");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFilter, ""));
            LogCapture.info("User clicks on Filter icon.");
        } else if (option.equals("Incoming funds Queue")) {
            String vObjIncomingFundsQueue = Constants.TitanPaymentInOR.getProperty("IncomingFundsQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIncomingFundsQueue, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjIncomingFundsQueue, ""));
            // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjIncomingFundsQueue, "MoveToElement"));
            // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjIncomingFundsQueue, "click"));
            LogCapture.info("User clicks on Incoming funds Queue");

        } else if (option.equals("Payment out Queue")) {
            String vObjPaymentOutDetailpagelink = Constants.TitanPaymentOutOR.getProperty("PaymentOutDetailpagelink");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutDetailpagelink, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPaymentOutDetailpagelink, ""));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutDetailpagelink, "MoveToElement"));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutDetailpagelink, "click"));
            LogCapture.info("User clicks on Payment out Queue");

        } else if (option.equals("FX tickets queue")) {
            String vObjFXTicketDetailLink = Constants.TitanFXTicketsOR.getProperty("FXTicketDetailLink");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketDetailLink, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXTicketDetailLink, ""));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFXTicketDetailLink, "MoveToElement"));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFXTicketDetailLink, "click"));
            LogCapture.info("User clicks on FX tickets queue");

        }

    }

    @And("^User search by (keyword|fxkeyword|CustomerKeyword) \"([^\"]*)\"$")
    public void userSearchByKeyword(String filter, String searchstring) throws Throwable {
        if (filter.equals("keyword")) {
            String vObjKeywordFilterText = Constants.TitanPaymentInOR.getProperty("KeywordFilterText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeywordFilterText, "enter"));
            LogCapture.info("User search by " + filter + "->" + searchstring);
            Constants.key.pause("2", "");

        } else if (filter.equals("fxkeyword")) {
            String vObjKeywordFilterText = Constants.TitanFXTicketsOR.getProperty("KeySearchText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeywordFilterText, "enter"));
            LogCapture.info("User search by " + filter + "->" + searchstring);
            Constants.key.pause("2", "");

        } else if (filter.equals("CustomerKeyword")) {
            String vObjKeywordFilterText = Constants.TitanCustomersOR.getProperty("KeyWorkFilterText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeywordFilterText, "enter"));
            LogCapture.info("User search by " + filter + "->" + searchstring);
            Constants.key.pause("2", "");

        }

    }

    @Then("^User navigate to search result and click on (ClientID|Result) \"([^\"]*)\" record$")
    public void userNavigateToSearchResultAndClickOnRecord(String column, String data) throws Throwable {
        if (column.equals("Result")) {
            int a = Integer.parseInt(data) - 1;
            String vObjDateDateColumn = "//tbody/tr[@id='row-" + a + "']/td[7]/a[1]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDateDateColumn, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDateDateColumn, ""));
            // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDateDateColumn, "MoveToElement"));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDateDateColumn, "click"));
            LogCapture.info("User navigate to search result and click on " + column + "'" + data + "' record");
        } else if (column.equals("ClientID")) {
            String vObjClientID = "//a[contains(text(),'" + data + "')]";
            // LogCapture.info(vObjClientID);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientID, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClientID, ""));
            // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjClientID, "MoveToElement"));
            //  Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjClientID, "click"));
            LogCapture.info("User navigate to search result and click on " + column + "'" + data + "' record");

        }
    }


    @And("^User navigate to (Debitor Number|Payment out|Customer|FX ticket) \"([^\"]*)\" Detail$")
    public void userNavigateToDebitorNumberDetail(String page, String data) throws Throwable {
        if (page.equals("Debitor Number")) {
            String de = data.substring(4);
            String vObjKeywordFilterText = "//h1[contains(text(),'Debitor Number #" + de + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            LogCapture.info("User navigate to " + page + " #" + de + " Detail");
        } else if (page.equals("Payment out")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'Payment out #" + data + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
        } else if (page.equals("Customer")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'" + data + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

            String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
            String vObjCustomerStatus = Constants.TitanPaymentOutOR.getProperty("CustomerStatus");
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerStatus, "visible"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCustomerStatus, "ACTIVE"));
            LogCapture.info("Customer status is Active verified..");

        } else if (page.equals("FX ticket")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'" + data + "')]";
            String vObjKeywordFilterText1 = "//h1[contains(text(),'Debitor Number #" + data + "')]";

            LogCapture.info(vObjKeywordFilterText);

            //String vObjKeywordFilterText = "//h1[contains(text(),'FX ticket for client #')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

            //String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
        }
    }

    @And("^User navigate to Payment In Titan page$")
    public void userNavigateToPaymentInTitanPage() throws Exception {
        String vObjPaymentInH1 = Constants.TitanPaymentInOR.getProperty("PaymentInH1");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInH1, ""));
        LogCapture.info("User navigate to Payment In Titan page");

    }

    @And("^Select (Organisation|Business Partner) as \"([^\"]*)\"$")
    public void selectOrganisationAs(String dropdown, String organization) throws Throwable {

        if (dropdown.equals("Organisation")) {
            String vObjFilterOrganisation = Constants.TitanPaymentOutOR.getProperty("FilterOrganisation");
            //LogCapture.info(vObjFilterOrganisation);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFilterOrganisation, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFilterOrganisation, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFilterOrganisation, "click"));
            Assert.assertEquals("PASS", Constants.key.selectOrganisationBussinessPartner(dropdown, organization));
            LogCapture.info("User Selected " + dropdown + "as " + organization);
        } else if (dropdown.equals("Business Partner")) {
            String vObjFilterOrganisation = Constants.TitanPaymentOutOR.getProperty("FilterBusinessPartner");
            //LogCapture.info(vObjFilterOrganisation);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFilterOrganisation, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFilterOrganisation, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFilterOrganisation, "click"));
            Assert.assertEquals("PASS", Constants.key.selectOrganisationBussinessPartner(dropdown, organization));
            LogCapture.info("User Selected " + dropdown + "as " + organization);
            Constants.key.pause("8", "");
        }

    }


    @And("^User navigate to (Payment Out Queue|Payment In Queue|FX tickets queue) page$")
    public void userNavigateToPaymentOutQueuePage(String page) throws Throwable {
        if (page.equals("Payment Out Queue")) {
            String vObjPaymentOutHeading = Constants.TitanPaymentOutOR.getProperty("PaymentOutHeading");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutHeading, ""));
            String HeadingPaymentOut = Constants.key.getText(vObjPaymentOutHeading, "");
            LogCapture.info(HeadingPaymentOut);

            LogCapture.info("User navigate to" + page + "page");
        } else if (page.equals("Payment In Queue")) {
            String vObjPaymentInHeading = Constants.TitanPaymentInOR.getProperty("PaymentInH1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInHeading, ""));
            String HeadingPaymentIn = Constants.key.getText(vObjPaymentInHeading, "");
            LogCapture.info(HeadingPaymentIn);

            LogCapture.info("User navigate to" + page + "page");
        } else if (page.equals("FX tickets queue")) {
            String vObjFXTicketQueueHeaderg = Constants.TitanFXTicketsOR.getProperty("FXQueueH1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketQueueHeaderg, ""));
            String HeadingPaymentIn = Constants.key.getText(vObjFXTicketQueueHeaderg, "");
            LogCapture.info(HeadingPaymentIn);

            LogCapture.info("User navigate to" + page + "page");
        }
    }

    @And("^Select Viewing payments type as (Future|Current)$")
    public void selectViewingPaymentsTypeAsFuture(String type) throws Throwable {
        if (type.equals("Future")) {
            String vObjPaymentOutTypeFuture = Constants.TitanPaymentOutOR.getProperty("PaymentOutTypeFuture");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutTypeFuture, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutTypeFuture, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutTypeFuture, "click"));
            LogCapture.info("User Select Viewing payments type as " + type);


        } else if (type.equals("Current")) {
            String vObjPaymentOutTypeCurrent = Constants.TitanPaymentOutOR.getProperty("PaymentOutTypeCurrent");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutTypeCurrent, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutTypeCurrent, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutTypeCurrent, "click"));
            LogCapture.info("User Select Viewing payments type as " + type);
        }
    }

    @Then("^User Search from Right Hand Side top search with searchkey \"([^\"]*)\"$")
    public void userSearchFromRightHandSideTopSearchWithSearchkey(String seachkey) throws Throwable {
        String vObjPaymentOutRightHandTopSearch = Constants.TitanPaymentOutOR.getProperty("PaymentOutRightHandTopSearch");

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutRightHandTopSearch, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPaymentOutRightHandTopSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPaymentOutRightHandTopSearch, seachkey));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPaymentOutRightHandTopSearch, "enter"));
        LogCapture.info("User Search from Right Hand Side top search with searchkey " + seachkey);
    }

    @And("^Click on Apply filter button$")
    public void clickOnApplyFilterButton() throws Throwable {
        String vObjApplyFilterbutton = Constants.TitanCustomersOR.getProperty("ApplyFilterbutton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyFilterbutton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjApplyFilterbutton, ""));

        // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjApplyFilterbutton, "MoveToElement"));
        //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjApplyFilterbutton, "click"));
        Constants.key.pause("5", "");
        LogCapture.info("User click on Apply filter button");

    }


    @And("^User should get all \"([^\"]*)\" records in search result$")
    public void userShouldGetAllRecordsInSearchResult(String org) throws Throwable {
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.verifyOrganisationIntableCustomer("", org, "1"));
        LogCapture.info("Search result content is validated for Organisation " + org);

    }

    @And("^User should get all \"([^\"]*)\" records in column \"([^\"]*)\"$")
    public void userShouldGetAllRecordsInColumn(String org, String column) throws Throwable {

        String vObjPageNavigation = Constants.TitanFXTicketsOR.getProperty("PageNavigation");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPageNavigation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyOrganisationIntableCustomer("", org, column));
        LogCapture.info("Search result content is validated for Organisation " + org + " in table column " + column);

    }

    @And("^User clicks on required \"([^\"]*)\" ticket from records displayed$")
    public void userClicksOnRequiredTicketFromRecordsDisplayed(String clientNumber) throws Throwable {
        String vObjFirstRecord = "//*[contains(@id,'Table')]//tr[1]//*[text()='" + clientNumber + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirstRecord, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFirstRecord, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirstRecord, ""));
        LogCapture.info("User clicks on first available record for clientNumber " + clientNumber);

    }

    @And("^User is able to view FX record details for clientNumber\"([^\"]*)\" clientName\"([^\"]*)\"$")
    public void userIsAbleToViewFXRecordDetailsForClientNumber(String clientNumber, String clientName) throws Throwable {

        String vObjClientName = "//*[text()='Client name']//following::*[@href='#other-info'][text()='" + clientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientName, "visible"));
        LogCapture.info("Client name :" + clientName + " is visible...");

        String vObjFXTicketRecordHeader = Constants.TitanQueuesOR.getProperty("FXTicketRecordHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketRecordHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXTicketRecordHeader, "visible"));
        String FXTicketRecordHeaderStr = Constants.driver.findElement(By.xpath(vObjFXTicketRecordHeader)).getText();
        if (FXTicketRecordHeaderStr.contains(clientNumber)) {
            LogCapture.info("Required Header visible: " + FXTicketRecordHeaderStr);
        } else {
            LogCapture.info("Required Header NOT visible: " + FXTicketRecordHeaderStr);
            Assert.fail();
        }
    }

    @And("^User clicks on (FX Tickets Queue|Payee Report) hyperlink$")
    public void userClicksOnFXTicketsQueueHyperlink(String TargetPage) throws Throwable {
        String vObjHyperLink = null;
        if (TargetPage.equalsIgnoreCase("FX Tickets Queue")) {
            vObjHyperLink = Constants.TitanQueuesOR.getProperty("FXTicketsQueueHyperLink");
        } else if (TargetPage.equalsIgnoreCase("Payee Report")) {
            vObjHyperLink = Constants.TitanReportsOR.getProperty("PayeeReportHyperLink");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjHyperLink, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjHyperLink, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjHyperLink, ""));
        LogCapture.info("User clicks on hyperlink: " + TargetPage);

    }

    @And("^User search for Email \"([^\"]*)\" in search box and hits Enter key$")
    public void userSearchForEmailInSearchboxAndHitsEnterKey(String EmailAdd) throws Throwable {

        String vObjFXSearchAnother = Constants.TitanQueuesOR.getProperty("FXSearchAnother");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXSearchAnother, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXSearchAnother, "visible"));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXSearchAnother, ""));
        String EmailAddress = CONFIG.getProperty(EmailAdd);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFXSearchAnother, EmailAddress));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFXSearchAnother, "enter"));
        Constants.key.pause("5", "");
        LogCapture.info("User search client details with EmailAddress: " + EmailAddress);

    }

    @And("^User is able to view customer details EmailAddress\"([^\"]*)\" Contact\"([^\"]*)\" CountryOfResidence\"([^\"]*)\" for clientNumber\"([^\"]*)\" and clientName\"([^\"]*)\"$")
    public void userIsAbleToViewCustomerDetailsEmailAddressContactForClientNumberAndClientName(String EmailAdd, String Contacts, String CountryResidence, String clientTAN, String CustomerName) throws Throwable {

        Constants.key.pause("4", "");
        String vObjCustomersHyperlink = Constants.TitanCustomersOR.getProperty("CustomersHyperlink");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomersHyperlink, "visible"));
        LogCapture.info("Customer detail page is visible...");

        String EmailAddress = CONFIG.getProperty(EmailAdd);
        String Contact = CONFIG.getProperty(Contacts);
        String CountryOfResidence = CONFIG.getProperty(CountryResidence);
        String clientNumber = CONFIG.getProperty(clientTAN);
        String clientName = CONFIG.getProperty(CustomerName);


        String vObjClientName = "//*[contains(text(),'" + clientName + " ')]";
        LogCapture.info(vObjClientName);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientName, "visible"));
        LogCapture.info("Client name :" + clientName + " is visible...");

        String vObjClientNumber = "//*[contains(text(),'#" + clientNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumber, "visible"));
        LogCapture.info("Client Number :" + clientNumber + " is visible...");

        String vObjContactName = "//*[text()='Contacts']//following::a[@href='#'][text()='" + Contact + " ']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContactName, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContactName, ""));
        Constants.key.pause("3", "");
        String vObjCustomerPrimaryContact = Constants.TitanCustomersOR.getProperty("CustomerPrimaryContact");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerPrimaryContact, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerPrimaryContact, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCustomerPrimaryContact, ""));
        LogCapture.info("User clicks on particular customer primary contact button..");

        String vObjContactEmailHeader = Constants.TitanCustomersOR.getProperty("ContactEmailHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContactEmailHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjContactEmailHeader, "visible"));
        LogCapture.info("Email header is visible..");

        String vObjEmailValue = Constants.TitanCustomersOR.getProperty("EmailAddressValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjEmailValue, EmailAddress));
        LogCapture.info("Email Value: " + EmailAddress + " is visible..");

        String vObjCountryOfResidence = "//*[text()='Country of residence']//following::*[contains(text(),'" + CountryOfResidence + "')]";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCountryOfResidence, "visible"));
        LogCapture.info("Country Of Residence: " + CountryOfResidence + " is visible..");

    }

    @And("^User is able to view Payees Reports page details in Titan and Not error message$")
    public void userIsAbleToViewPayeesReportsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPayeeReportHeader = Constants.TitanPayeeOR.getProperty("PayeeReportHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeReportHeader, ""));
        LogCapture.info("User is on Payee Reports in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjAddedDateColumn = Constants.TitanReportsOR.getProperty("PayeeAddedDate");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddedDateColumn, "visible"));
        LogCapture.info("Added Date Column is visible..");

        String vObjOrganisationColumn = Constants.TitanReportsOR.getProperty("PayeeOrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanReportsOR.getProperty("PayeeBusinessPartner");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientNumberColumn = Constants.TitanReportsOR.getProperty("PayeeClientNumber");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client# is visible..");

        String vObjPayeeNameColumn = Constants.TitanReportsOR.getProperty("PayeeName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeNameColumn, "visible"));
        LogCapture.info("Payee Name Column is visible..");

        String vObjPayeeAccountIBANColumn = Constants.TitanReportsOR.getProperty("PayeeAccountIBAN");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeAccountIBANColumn, "visible"));
        LogCapture.info("Payee Account/IBAN Column is visible..");

        String vObjPayeeCountryColumn = Constants.TitanReportsOR.getProperty("PayeeCountry");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeCountryColumn, "visible"));
        LogCapture.info("Payee Country Column is visible..");

        String vObjPayeeCurrencyColumn = Constants.TitanReportsOR.getProperty("PayeeCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeCurrencyColumn, "visible"));
        LogCapture.info("Payee Currency Column is visible..");

        String vObjPayeeStatusColumn = Constants.TitanReportsOR.getProperty("PayeeStatus");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeStatusColumn, "visible"));
        LogCapture.info("Payee Status Column is visible..");

        String vObjPayeeDeletedColumn = Constants.TitanReportsOR.getProperty("PayeeDeleted");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDeletedColumn, "visible"));
        LogCapture.info("Deleted Column is visible..");

        LogCapture.info("Payee Report page - All details are visible..");

    }

    @And("^User is able to view Payees details for clientNumber\"([^\"]*)\"$")
    public void userIsAbleToViewPayeesDetailsForClientNumberClientName(String clientNumber) throws Throwable {

        String vObjPayeeRecordHeader = "//span[@class='breadcrumbs']//parent::h1[contains(text(),'Client #" + clientNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeRecordHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeRecordHeader, "visible"));
        LogCapture.info("Client #" + clientNumber + " Header is visible");

        String vObjPayeeDetailsPage = Constants.TitanReportsOR.getProperty("PayeeDetailsPage");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsPage, "visible"));
        LogCapture.info("Payee Details page is visible..");

    }

    @And("^User is on Invoices in Titan page and message is displayed and No error Message$")
    public void userIsOnInvoicesInTitanPageAndMessageIsDisplayedAndNoErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjInvoicesReportPage = Constants.TitanReportsOR.getProperty("InvoicesReportPage");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInvoicesReportPage, "visible"));

        String vObjInvoicesPageMessage = Constants.TitanReportsOR.getProperty("InvoicesPageMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvoicesPageMessage, ""));
        LogCapture.info("Invoices page message visisble..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

    }


    @Then("^User is able to view Update B2B page details in Titan and Not error message$")
    public void userIsAbleToViewUpdateB2BPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjUpdateB2BPage = Constants.TitanTreasuryOR.getProperty("UpdateB2BPage");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdateB2BPage, "visible"));
        LogCapture.info("Update B2B in Titan header is visible..");

        String vObjSelectAllCheckbox = Constants.TitanTreasuryOR.getProperty("SelectAllCheckbox");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSelectAllCheckbox, "visible"));
        LogCapture.info("Select All at once checkbox is visible..");

        String vObjOrganisationColumn = Constants.TitanTreasuryOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjDealNumberColumn = Constants.TitanTreasuryOR.getProperty("DealNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealNumberColumn, "visible"));
        LogCapture.info("Dealer number Column is visible..");

        String vObjDealerNameColumn = Constants.TitanTreasuryOR.getProperty("B2BDealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer name Column is visible..");

        String vObjCCYCoulmn = Constants.TitanTreasuryOR.getProperty("CCYPairColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYCoulmn, "visible"));
        LogCapture.info("CCY Pair Coulmn is visible..");

        String vObjSellingAmountColumn = Constants.TitanTreasuryOR.getProperty("SellingAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellingAmountColumn, "visible"));
        LogCapture.info("Selling Amount Column is visible..");

        String vObjBuyingAmountColumn = Constants.TitanTreasuryOR.getProperty("BuyingAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyingAmountColumn, "visible"));
        LogCapture.info("Buying Amount Column is visible..");

        String vObjDealTypeColumn = Constants.TitanTreasuryOR.getProperty("DealTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealTypeColumn, "visible"));
        LogCapture.info("Deal Type Column is visible..");

        String vObjClientNameColumn = Constants.TitanTreasuryOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjClientTreasuryDealColumn = Constants.TitanTreasuryOR.getProperty("ClientTreasuryDealColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTreasuryDealColumn, "visible"));
        LogCapture.info("Client/Treasury Deal Column is visible..");

        LogCapture.info("Update B2B page - All details are visible..;");
    }


    @Then("^User is able to view Deal Report page details in Titan and Not error message$")
    public void userIsAbleToViewDealReportPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjDealQueueHeader = Constants.TitanTreasuryOR.getProperty("DealQueueHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealQueueHeader, "visible"));
        LogCapture.info("Deal queue in Titan header is visible..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjOrganisationColumn = Constants.TitanTreasuryOR.getProperty("DealReportOrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBankColumn = Constants.TitanTreasuryOR.getProperty("BankColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBankColumn, "visible"));
        LogCapture.info("Bank Column is visible..");

        String vObjExternalReferenceColumn = Constants.TitanTreasuryOR.getProperty("ExternalReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjExternalReferenceColumn, "visible"));
        LogCapture.info("External Reference Column is visible..");

        String vObjBlotterCategoryColumn = Constants.TitanTreasuryOR.getProperty("BlotterCategoryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBlotterCategoryColumn, "visible"));
        LogCapture.info("Blotter Category Column is visible..");

        String vObjTradeDateColumn = Constants.TitanTreasuryOR.getProperty("TradeDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTradeDateColumn, "visible"));
        LogCapture.info("Trade Date Column is visible..");

        String vObjValueDateColumn = Constants.TitanTreasuryOR.getProperty("ValueDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjValueDateColumn, "visible"));
        LogCapture.info("Value Date Column is visible..");

        String vObjExchangeRateColumn = Constants.TitanTreasuryOR.getProperty("ExchangeRateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjExchangeRateColumn, "visible"));
        LogCapture.info("Exchange Rate Column is visible..");

        String vObjSellCCYColumn = Constants.TitanTreasuryOR.getProperty("SellCCYColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellCCYColumn, "visible"));
        LogCapture.info("Sell CCY Column is visible..");

        String vObjDealReportSellingAmountColumn = Constants.TitanTreasuryOR.getProperty("DealReportSellingAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportSellingAmountColumn, "visible"));
        LogCapture.info("Selling Amount Column is visible..");

        String vObjBuyCCYColumn = Constants.TitanTreasuryOR.getProperty("BuyCCYColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyCCYColumn, "visible"));
        LogCapture.info("Buy CCY Column is visible..");

        String vObjDealReportBuyingAmountColumn = Constants.TitanTreasuryOR.getProperty("DealReportBuyingAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportBuyingAmountColumn, "visible"));
        LogCapture.info("Buying Amount Column is visible..");

        String vObjDealReportDealTypeColumn = Constants.TitanTreasuryOR.getProperty("DealReportDealTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportDealTypeColumn, "visible"));
        LogCapture.info("Deal Type Column is visible..");

        ((JavascriptExecutor) Constants.driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Constants.key.pause("2", "");
        String vObjScrollbar = Constants.TitanTreasuryOR.getProperty("Scrollbar");
        Assert.assertEquals("PASS", Constants.key.click(vObjScrollbar, ""));
        LogCapture.info("Clicked on scrollbar..");

        WebElement scrollArea = Constants.driver.findElement(By.xpath(vObjScrollbar));
        ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
        Constants.key.pause("2", "");
        ((JavascriptExecutor) Constants.driver).executeScript("window.scrollTo(0, 0)");
        Constants.key.pause("2", "");

        String vObjDealerNameColumn = Constants.TitanTreasuryOR.getProperty("DealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        String vObjUpdatedByColumn = Constants.TitanTreasuryOR.getProperty("UpdatedByColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdatedByColumn, "visible"));
        LogCapture.info("Updated By Column is visible..");

        String vObjSourceNameColumn = Constants.TitanTreasuryOR.getProperty("SourceNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSourceNameColumn, "visible"));
        LogCapture.info("Source Name Column is visible..");

        String vObjActionColumn = Constants.TitanTreasuryOR.getProperty("ActionColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjActionColumn, "visible"));
        LogCapture.info("Action Column is visible..");

        LogCapture.info("Deal Report page - All details are visible..;");
    }

    @Then("^User is able to view Logout page message with Log In hyperlink$")
    public void userIsAbleToViewLogoutPageMessageWithLogInHyperlink() throws Throwable {

        String vObjLogoutPageMsg = Constants.TitanCustomersOR.getProperty("LogoutPageMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLogoutPageMsg, ""));
        LogCapture.info("User successfully logout..");

        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLogoutPageMsg, "visible"));
        LogCapture.info("Logout page message is visible..");

        String vObjLogInHyperlink = Constants.TitanCustomersOR.getProperty("LogInHyperlink");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLogInHyperlink, "visible"));
        LogCapture.info("Log In hyperlink is visible..");

    }

    @And("^User is able to view new tab where PDF file is opened$")
    public void userIsAbleToViewNewTabWherePDFFileIsOpened() throws Throwable {

        //Switch to child window
        for (String winHandle : Constants.driver.getWindowHandles()) {
            //Constants.driver.switchTo().window(winHandle);
            // Constants.key.pause("10","");
            // Constants.driver.manage().window().maximize();
            LogCapture.info("Switched to Child window...");
            Constants.key.pause("2", "");
            // Switch back to the original browser (first window)
            Constants.driver.switchTo().window(winHandleBefore);
            LogCapture.info("Switched to Parent window...");
            //String vObjBrand = "//dt[text()='Brand']";
            //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBrand, "visible"));
            Constants.key.pause("2", "");

        }
    }

    @And("^User enters Add Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" and Clicks on Next button$")
    public void userEntersPayeeDetailsPayeeTypeFirshghtNameLastNameCompanyNameCurrencyReceiveCountryAndClicksOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country) throws Throwable {
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName;
            String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName;
            String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCompanyPayeeType, "selected"));
            LogCapture.info("Company Payee type is selected..");

            String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");
            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);
        Constants.key.pause("3", "");


        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, "400066"));
        Constants.key.pause("2", "");

        String vObjGetAddressButton = Constants.TitanCustomersOR.getProperty("GetAddressButton");
        // Assert.assertEquals("PASS", Constants.key.click(vObjGetAddressButton, ""));
        Constants.key.pause("2", "");

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, "Avenue"));
        Constants.key.pause("2", "");

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, "New York"));
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeTownField, "tab"));

        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User click on first record from Payment in Reports page to navigate to Incoming Funds Reports page$")
    public void userClickOnFirstRecordFromPaymentInReportsPageToNavigateToIncomingFundsReportsPage() throws Throwable {
        String vobjFirstRecordPaymentsInReport = Constants.TitanPaymentInOR.getProperty("FirstRecordPaymentsInReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsInReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsInReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");
        String vobjIncomingFundsReports = Constants.TitanPaymentInOR.getProperty("IncomingFundsReports");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIncomingFundsReports, ""));
        LogCapture.info("Incoming Funds Report page is visible..");
    }


    @Then("^User clicks on Incoming Funds Reports hyperlink for client\"([^\"]*)\" and navigate back to Payment in reports page$")
    public void userClicksOnIncomingFundsReportsHyperlinkToNavigateBackToPaymentInReportsPage(String clientNumber) throws Throwable {
        String vobjPaymentInHeader = "//h1[contains(text(),'Payment In #" + clientNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentInHeader, ""));
        String vobjIncomingFundsReports = Constants.TitanPaymentInOR.getProperty("IncomingFundsReports");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIncomingFundsReports, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjIncomingFundsReports, ""));
        LogCapture.info("User clicks on Incoming Funds hyperlink...");
        String vobjPaymentInReportPageHeader = Constants.TitanPaymentInOR.getProperty("PaymentInReportPageHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentInReportPageHeader, ""));
        LogCapture.info("Payment in report page is visible...");
    }

    @Then("^User should be navigate to Customer details page$")
    public void userShouldBeNavigateToCustomerDetailsPage() throws Throwable {
        String vobjPaymentInCustomerDetails = Constants.TitanPaymentInOR.getProperty("PaymentInCustomerDetails");
        String vobjBrookClongNum = Constants.driver.findElement(By.xpath(vobjPaymentInCustomerDetails)).getText();
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vobjPaymentInCustomerDetails, ""));
        LogCapture.info("User is able to view the customer details of" + vobjBrookClongNum);

    }


    @And("^User clicks on Payment out reports hyperlink to navigate back to Payments out report page$")
    public void userClicksOnPaymentOutReportsHyperlinkToNavigateBackToPaymentsOutReportPage() throws Throwable {
        String vobjPaymentOutReports = Constants.TitanPaymentOutOR.getProperty("PaymentOutReports");
        //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentOutReports, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjPaymentOutReports, ""));
        LogCapture.info("User clicks on Payment out report hyperlink..");
        String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
        LogCapture.info("User is on Payments Out Reports in Titan page..");
    }

    @And("^User click on first record from Payment out Reports page and navigates to Payment out details page for client\"([^\"]*)\"$")
    public void userClickOnFirstRecordFromPaymentOutReportsPageAndNavigatesToPaymentOutDetailsPage(String clientNumber) throws Throwable {
        String vobjFirstRecordPaymentsOutReport = Constants.TitanPaymentInOR.getProperty("FirstRecordPaymentsOutReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsOutReport, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjFirstRecordPaymentsOutReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");
        String vobjIncomingFundsReports = "//h1[contains(text(),'Payment out #" + clientNumber + "-')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIncomingFundsReports, ""));
        LogCapture.info("Incoming Funds Report page is visible..");
    }

    @And("^User selects payment method as DD and selects Select Direct Debit$")
    public void userSelectsPaymentMethodAsDDAndSelectsSelectDirectDebit() throws Throwable {

        String vObjFXCreditPage = Constants.CreateFxTicketOR.getProperty("FXCreditPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXCreditPage, ""));
        LogCapture.info("User is on 3 of 4: Credit page...");

        String vObjPaymentMethodDD = Constants.CreateFxTicketOR.getProperty("PaymentMethodDD");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodDD, ""));
        LogCapture.info("user selects DD as payment method...");

        String vObjSelectDirectDebitHeader = Constants.CreateFxTicketOR.getProperty("SelectDirectDebitHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectDirectDebitHeader, ""));
        LogCapture.info("Select Direct Debit header is visible...");
        Constants.key.pause("2", "");

        String vObjSelectDirectDebitDropArrow = Constants.CreateFxTicketOR.getProperty("SelectDirectDebitDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectDirectDebitDropArrow, ""));
        Constants.key.pause("3", "");
        String vObjDirectDebitFirstOption = Constants.CreateFxTicketOR.getProperty("DirectDebitFirstOption");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDirectDebitFirstOption, ""));
        Constants.key.pause("3", "");
        LogCapture.info("Direct Debiter selected...");

    }

    @And("^User selects Direct Debit for Payment In$")
    public void userSelectsDirectDebitForPaymentIn() throws Throwable {

        String vObjSelectDirectDebitHeaderPayIn = Constants.TitanPaymentInOR.getProperty("SelectDirectDebitHeaderPayIn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectDirectDebitHeaderPayIn, ""));
        LogCapture.info("Select Direct Debit header is visible...");
        Constants.key.pause("2", "");

        String vObjSelectDirectDebitDropArrowPayIn = Constants.TitanPaymentInOR.getProperty("SelectDirectDebitDropArrowPayIn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectDirectDebitDropArrowPayIn, ""));
        Constants.key.pause("3", "");
        String vObjDirectDebitFirstOptionPayIn = Constants.TitanPaymentInOR.getProperty("DirectDebitFirstOptionPayIn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDirectDebitFirstOptionPayIn, ""));
        Constants.key.pause("3", "");
        LogCapture.info("Direct Debit selected...");

    }


    @And("^User search for Client Number \"([^\"]*)\" in search box and hits Enter key$")
    public void userSearchForclientIDInSearchboxAndHitsEnterKey(String clientTAN) throws Throwable {

        String vObjFXSearchAnother = Constants.TitanQueuesOR.getProperty("FXSearchAnother");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXSearchAnother, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXSearchAnother, "visible"));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXSearchAnother, ""));
        String ClientNumber = CONFIG.getProperty(clientTAN);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFXSearchAnother, ClientNumber));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFXSearchAnother, "enter"));
        Constants.key.pause("5", "");
        LogCapture.info("User search client details with client number: " + ClientNumber);

    }

    @And("^User is able to view Queues FX Ticket page details in Titan$")
    public void userIsAbleToViewQueuesFXTicketPageDetailsInTitan() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
        LogCapture.info("User is on FX tickets in Titan page..");


    }

    @And("^User is able to view FX tickets Reports page details in Titan$")
    public void userIsAbleToViewFXTicketsReportsPageDetailsInTitan() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXticketsReportPage = Constants.TitanReportsOR.getProperty("FXticketsReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXticketsReportPage, ""));
        LogCapture.info("User is on FX tickets Reports in Titan page..");

    }

    @And("^User is able to view Payment In Reports page details in Titan$")
    public void userIsAbleToViewPaymentInReportsPageDetailsInTitan() throws Throwable {
        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");
        String vObjPaymentInReportPage = Constants.TitanReportsOR.getProperty("PaymentInReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportPage, ""));
        LogCapture.info("User is on Payments In Reports in Titan page..");


    }

    @Then("^User is able to view Payment Out Reports page details in Titan$")
    public void userIsAbleToViewPaymentOutReportsPageDetailsInTitan() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
        LogCapture.info("User is on Payments Out Reports in Titan page..");


    }

    @And("^User is able to view newly added Payee with PayeeName\"([^\"]*)\" PayeeType\"([^\"]*)\"$")
    public void userIsAbleToViewNewlyAddedPayeeWithPayeeNamePayeeType(String PayeeName, String PayeeType) throws Throwable {

        String vPayeeNameText = "//*[@id='profilePayeeBody']/tr[1]//*[text()='" + PayeeName + "']";
        String vPayeeTypeText = "//*[@id='profilePayeeBody']/tr[1]//*[text()='" + PayeeType + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPayeeNameText, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vPayeeNameText, "visible"));
        LogCapture.info("Payee name is visible...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vPayeeTypeText, "visible"));
        LogCapture.info("Payee type is visible...");

    }

    @And("^User clicks on Payee button under Activity$")
    public void userClicksOnPayeeButtonUnderActivity() throws Throwable {
        String vObjActivityPayees = Constants.TitanPayeeOR.getProperty("ActivityPayees");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjActivityPayees, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjActivityPayees, ""));
        Constants.key.pause("3", "");
        LogCapture.info("User clicks on PAYEES tab under Activity...");
    }

    @And("^User clicks on newly added PayeeName\"([^\"]*)\" and view payee details$")
    public void userClicksOnNewlyAddedPayeeNameAndViewPayeeDetails(String PayeeName) throws Throwable {
        String vPayeeNameText = "//*[@id='profilePayeeBody']/tr[1]//*[text()='" + PayeeName + "']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vPayeeNameText, ""));
        LogCapture.info("user clicks on Payee name...");
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
    }

    @And("^User verify Address Details Address\"([^\"]*)\" Town\"([^\"]*)\" Postcode\"([^\"]*)\"$")
    public void userVerifyAddressDetailsAddressTownPostcode(String Address, String Town, String Postcode) throws Throwable {
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");

        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        String ActualPostcode = Constants.driver.findElement(By.xpath(vObjAddressPostCodeField)).getText();
        LogCapture.info(ActualPostcode);
        if (ActualPostcode.contains(Postcode)) {
            LogCapture.info("Postcode Verified- " + ActualPostcode);
        } else {
            LogCapture.info("Postcode NOT Verified- " + ActualPostcode);
            Assert.fail();
        }
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjAddressPostCodeField, Postcode));
        Constants.key.pause("2", "");
        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjPayeeAddressField, Address));
        String ActualAddress = Constants.driver.findElement(By.xpath(vObjPayeeAddressField)).getText();
        LogCapture.info(ActualAddress);
        if (ActualAddress.contains(Address)) {
            LogCapture.info("Address Verified- " + ActualAddress);
        } else {
            LogCapture.info("Address NOT Verified- " + ActualPostcode);
            Assert.fail();
        }
        Constants.key.pause("2", "");
        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjPayeeTownField, Town));
        String ActualTown = Constants.driver.findElement(By.xpath(vObjPayeeTownField)).getText();
        LogCapture.info(ActualTown);
        if (ActualTown.contains(Town)) {
            LogCapture.info("Town Verified- " + ActualTown);
        } else {
            LogCapture.info("Town NOT Verified- " + ActualTown);
            Assert.fail();
        }
        Constants.key.pause("2", "");

    }

    @And("^User enters Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" Address\"([^\"]*)\" Town\"([^\"]*)\" Postcode\"([^\"]*)\"(| for Canada Regulatory)$")
    public void userEntersPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAddressTownPostcodeForCanadaRegulatory(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country, String Address, String Town, String Postcode, String Target) throws Throwable {
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, FirstName));
            LogCapture.info("First name entered is: " + FirstName);

            String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, LastName));
            LogCapture.info("Last name entered is: " + LastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCompanyPayeeType, "selected"));
            LogCapture.info("Company Payee type is selected..");

            String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, CompanyName));
            LogCapture.info("Company name entered is: " + CompanyName);
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);

        Constants.key.pause("3", "");

        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disable...");
        }
        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
        Constants.key.pause("2", "");

        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disable...");
        }

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
        Constants.key.pause("2", "");

        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disable...");
        }

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
        Constants.key.pause("2", "");

        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled...");
        }
        if (Target.equalsIgnoreCase("")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeDetailsNextBtnEnable, ""));
            LogCapture.info("Click on Next button...");
        }


        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeTownField));
            LogCapture.info("Clear town field..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled...");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled...");
            LogCapture.info("Verified: Town field mandatory..");

            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeAddressField));
            LogCapture.info("Clear Address field..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled...");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled...");
            LogCapture.info("Verified: Address field mandatory..");

            Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjAddressPostCodeField));
            LogCapture.info("Clear Address field..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled...");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled...");
            LogCapture.info("Verified: Postcode field mandatory..");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtnEnable, ""));
            LogCapture.info("Click on Next button...");

        }
    }

    @And("^User updates the NewAddress\"([^\"]*)\" NewTown\"([^\"]*)\" NewPostcode\"([^\"]*)\" for Canada Regulatory$")
    public void userUpdatesTheNewAddressNewTownNewPostcodeForCanadaRegulatory(String NewAddress, String NewTown, String NewPostcode) throws Throwable {

        String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeTownField));
        LogCapture.info("Clear town field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled...");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, NewTown));
        Constants.key.pause("2", "");
        LogCapture.info("Updated town field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled...");
        LogCapture.info("Verified: Town field mandatory..");

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeAddressField));
        LogCapture.info("Clear Address field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled...");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, NewAddress));
        Constants.key.pause("2", "");
        LogCapture.info("Updated Address field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled...");
        LogCapture.info("Verified: Address field mandatory..");

        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAddressPostCodeField));
        LogCapture.info("Clear Address field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled...");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, NewPostcode));
        Constants.key.pause("2", "");
        LogCapture.info("Updated Address field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled...");
        LogCapture.info("Verified: Postcode field mandatory..");

        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtnEnable, ""));
        LogCapture.info("Click on Next button...");
    }

    @And("^User is on Payee Bank details and clicks on Next button$")
    public void userIsOnPayeeBankDetailsAndClicksOnNextButton() throws Throwable {

        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");
        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^User search for Payee ClientNumber\"([^\"]*)\" Organisation\"([^\"]*)\" and hits Enter key$")
    public void userSearchForPayeeClientNumberOrganisationAndHitsEnterKey(String ClientNumber, String Organisation) throws Throwable {
        String vObjFilterSearchOrganisationDropdownArrow = Constants.TitanQueuesOR.getProperty("FilterSearchOrganisationDropdownArrow");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilterSearchOrganisationDropdownArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisation = "//ul[@class='multilist__options']//input[@value='" + Organisation + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisation);
        Constants.key.pause("2", "");
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, ClientNumber));
        LogCapture.info("Searching for Client number: " + ClientNumber);
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");
    }

    @And("^User checks the status of Payee\"([^\"]*)\" is (Active|Inactive)$")
    public void userChecksTheStatusOfPayeeIsActiveOrNot(String ClientName, String Status) throws Throwable {

        String vObjClientName = "//tr[@id='payee-row-0']//*[text()='" + ClientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));

        if (Status.equalsIgnoreCase("Active")) {
            String vObjCurrentStatus = "//tr[@id='payee-row-0']//*[text()='" + ClientName + "']//parent::td//following-sibling::td//*[text()='ACTIVE']";
            String ExpectedStatus = Constants.driver.findElement(By.xpath(vObjCurrentStatus)).getText();
            if (ExpectedStatus.equalsIgnoreCase("Active")) {
                LogCapture.info("Status is ACTIVE..");
            } else {
                LogCapture.info("Customer Status is INACTIVE but should be ACTIVE..");
                Assert.fail();
            }
        }
        if (Status.equalsIgnoreCase("Inactive")) {
            String vObjCurrentStatus = "//tr[@id='payee-row-0']//*[text()='" + ClientName + "']//parent::td//following-sibling::td//*[text()='INACTIVE']";
            String ExpectedStatus = Constants.driver.findElement(By.xpath(vObjCurrentStatus)).getText();
            if (ExpectedStatus.equalsIgnoreCase("Inactive")) {
                LogCapture.info("Status is INACTIVE..");
            } else {
                LogCapture.info("Customer Status is ACTIVE but should be INACTIVE..");
                Assert.fail();
            }

        }
    }

    @And("^User clicks on newly added Payee\"([^\"]*)\" from the list$")
    public void userClicksOnNewlyAddedPayeeNameFromTheList(String ClientName) throws Throwable {
        String vObjClientName = "//tr[@id='payee-row-0']//*[text()='" + ClientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClientName, ""));
        LogCapture.info("User clicks on client name: " + ClientName);
    }

    @And("^User clicks(| again) on newly generated Instruction number$")
    public void userClicksOnNewlyGeneratedInstructionNumber(String clicks) throws Throwable {
        String vObjInstructionNumberSearch = "//*[text()='" + InstructionNumber + "']";

        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Constants.key.pause("2", "");
        if (clicks.equals("")) {
            String vObjDealTypeHeader = Constants.CreateFxTicketOR.getProperty("DealTypeHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealTypeHeader, ""));
        }
        LogCapture.info("User successfully clicked on Instruction number..");
    }

    @And("^User is able to view Option flag as (Yes|No) under deal details$")
    public void userIsAbleToViewOptionFlagAsYes(String OptionFlagStatus) throws Throwable {
        String vObjOptionFlagStatus = null;
        if (OptionFlagStatus.equalsIgnoreCase("Yes")) {
            vObjOptionFlagStatus = Constants.CreateFxTicketOR.getProperty("OptionFlagStatusYes");
        } else if (OptionFlagStatus.equalsIgnoreCase("No")) {
            vObjOptionFlagStatus = Constants.CreateFxTicketOR.getProperty("OptionFlagStatusNo");
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOptionFlagStatus, ""));
        LogCapture.info("User able to view Option flag- " + OptionFlagStatus);
    }

    @Then("^User is able to view Queues Payment Out page details in Titan and Not error message for SIT$")
    public void userIsAbleToViewQueuesPaymentOutPageDetailsInTitanAndNotErrorMessageForSIT() throws Throwable {
        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentsOutHeader = Constants.TitanQueuesOR.getProperty("PaymentsOutHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsOutHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentsOutHeader, "visible"));
        LogCapture.info("Payments Out header is visible..");
    }


    @And("^User verify PDF file\"([^\"]*)\" downloaded successfully$")
    public void userVerifyPDFFileDownloadedSuccessfully(String fileName) throws Throwable {
        //Assert.assertEquals("PASS",Constants.key.renameDownloadedFile("",fileName));
        Assert.assertEquals("PASS", Constants.key.defaultDownloadFilesOperations("isFileDownloaded", fileName));
        LogCapture.info("PDF file downloaded successfully..");
        Assert.assertEquals("PASS", Constants.key.defaultDownloadFilesOperations("deleteAllFiles", fileName));
        LogCapture.info("Deleted All downloaded files..");
    }


    @And("^User able to view (|Add new card Window with )Warning message for EU Customers$")
    public void userAbleToViewAddNewCardWindowWithWarningMessageForEUCustomers(String TargetScreen) throws Throwable {

        if (TargetScreen.equalsIgnoreCase("Add new card Window with ")) {
            Constants.key.pause("5", "");
            for (String winHandle : Constants.driver.getWindowHandles()) {
                Constants.driver.switchTo().window(winHandle);
                Constants.driver.manage().window().maximize();
                LogCapture.info("Switched to Child window...");
            }
            String vObjAddNewCardPage = Constants.CreateFxTicketOR.getProperty("AddNewCardPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddNewCardPage, ""));
            LogCapture.info("Add new card page is visible on child window...");
            Constants.key.pause("3", "");
        }
        String WarningMsgEU = Constants.CONFIG.getProperty("WarningMsgEU");
        String vObjWarningMsgEU = Constants.CreateFxTicketOR.getProperty("WarningMsgEU");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjWarningMsgEU, WarningMsgEU));
        LogCapture.info("Warning for EU customer is visible on Add new card child window...");

        if (TargetScreen.equalsIgnoreCase("Add new card Window with ")) {
            Constants.driver.switchTo().window(winHandleBefore);
        }

    }

    @And("^User selects payment method as (Card|Bank)(| for FX)$")
    public void userSelectsPaymentMethodAsCard(String PaymentType, String Scenario) throws Throwable {
        Constants.key.pause("2", "");
        if (PaymentType.equalsIgnoreCase("Card")) {
            String vObjPaymentMethodCard = null;
            if (Scenario.equalsIgnoreCase("")) {
                vObjPaymentMethodCard = Constants.CreateFxTicketOR.getProperty("CardPaymentMethods");
            }
            if (Scenario.equalsIgnoreCase(" for FX")) {
                vObjPaymentMethodCard = Constants.CreateFxTicketOR.getProperty("PaymentMethodCard");
            }
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodCard, ""));
            LogCapture.info("clicking on Card tab...");
        }

        if (PaymentType.equalsIgnoreCase("Bank")) {
            String vObjPaymentMethodBanks = null;
            if (Scenario.equalsIgnoreCase("")) {
                vObjPaymentMethodBanks = Constants.CreateFxTicketOR.getProperty("BankPaymentMethods");
            }
            if (Scenario.equalsIgnoreCase(" for FX")) {
                vObjPaymentMethodBanks = Constants.CreateFxTicketOR.getProperty("PaymentMethodBank");
            }
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodBanks, ""));
            LogCapture.info("clicking on Bank tab...");
        }

    }

    @And("^User (|does not )observe Warning message for Card Payments$")
    public void userObserveWarningMessageForCardPayments(String WarningVisible) throws Throwable {
        if (WarningVisible.equalsIgnoreCase("")) {
            String WarningMsgEU = Constants.CONFIG.getProperty("WarningMsgEU");
            String vObjFXSPOTWarningMsgEU = Constants.CreateFxTicketOR.getProperty("FXSPOTWarningMsgEU");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXSPOTWarningMsgEU, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjFXSPOTWarningMsgEU, WarningMsgEU));
            LogCapture.info("Warning for EU customer is visible while 1st payment using Card...");
        }
        if (WarningVisible.equalsIgnoreCase("does not ")) {
            Constants.key.pause("2", "");
            String vObjFXSPOTWarningMsgEU = Constants.CreateFxTicketOR.getProperty("FXSPOTWarningMsgEU");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjFXSPOTWarningMsgEU, ""));
            LogCapture.info("Warning for EU customer is NOT visible while payment...");
        }
    }

    @And("^User clicks on X to close the FX Deal$")
    public void userClicksOnXToCloseTheFXDeal() throws Throwable {
        String vObjCloseSlip = Constants.CreateFxTicketOR.getProperty("CloseSlip");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCloseSlip, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Closing the slip for ongoing payment...");
    }

    @And("^User clicks on (FX TICKETS|) tab$")
    public void userClicksOnFXTICKETSTab(String TargetTab) throws Throwable {
        if (TargetTab.equalsIgnoreCase("FX TICKETS")) {
            String vObjFXTicketTab = Constants.CreateFxTicketOR.getProperty("FXTicketTab");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXTicketTab, ""));
            Constants.key.pause("2", "");
            String vObjFXPagination = Constants.CreateFxTicketOR.getProperty("FXPagination");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXPagination, ""));
        }
        LogCapture.info("Clicked on " + TargetTab + " tab...");
    }

    @And("^User is able to view and click on FX Deal\"([^\"]*)\"$")
    public void userIsAbleToViewAndClickOnFXDeal(String DealNumber) throws Throwable {
        String vObjDealReference = "//tbody[@id='profileFxTicketBody']//*[contains(text(),'" + DealNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealReference, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealReference, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Clicked on " + DealNumber + " deal reference...");
    }

    @And("^User clicks on Add a Drawdown button on FX ticket for client$")
    public void userClicksOnAddADrawdownButtonOnFXTicketForClient() throws Throwable {
        String vObjAddDrawdownBtn = Constants.CreateFxTicketOR.getProperty("AddDrawdownBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddDrawdownBtn, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddDrawdownBtn, ""));
        LogCapture.info("Clicking on Add a Drawdown button...");
    }

    @And("^User enters InstructedBy\"([^\"]*)\" and clicks on Next button on Drawdown details page$")
    public void userEntersInstructedByAndClicksOnNextButtonOnDrawdownDetailsPage(String instructedBy) throws Throwable {

        String vObjDrawdownDetailsPage = Constants.CreateFxTicketOR.getProperty("DrawdownDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDrawdownDetailsPage, ""));

        String vObjInstructedByDrawdown = Constants.CreateFxTicketOR.getProperty("InstructedByDrawdown");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructedByDrawdown, ""));
        Constants.key.pause("2", "");
        String vObjInstructedBySearchDrawdown = Constants.CreateFxTicketOR.getProperty("InstructedBySearchDrawdown");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructedBySearchDrawdown, instructedBy));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearchDrawdown, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearchDrawdown, "enter"));
        LogCapture.info("Instructed By: " + instructedBy + " is selected..");

        Constants.key.pause("2", "");
        String vObjNextBtnDrawdown = Constants.CreateFxTicketOR.getProperty("NextBtnDrawdown");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNextBtnDrawdown, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjNextBtnDrawdown, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User is on Credit page of Drawdown$")
    public void userIsOnCreditPageOfDrawdown() throws Throwable {
        String vObjCreditPageDrawdown = Constants.CreateFxTicketOR.getProperty("CreditPageDrawdown");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCreditPageDrawdown, ""));
        LogCapture.info("User is on 2 of 3: Credit page..");
    }

    @And("^User is on Credit page and selects Card for Credit using the First four digits of card \"([^\"]*)\" and CVV \"([^\"]*)\" and clicks on add credit button$")
    public void userIsOnCreditPageAndSelectsCardForCreditUsingTheFirstFourDigitsOfCardAndCVVAndClicksOnAddCreditButton(String CardNumFirst, String CVV) throws Throwable {
        String vCreditMethodCard = Constants.CreateFxTicketOR.getProperty("CreditMethodCard");
        Assert.assertEquals("PASS", Constants.key.click(vCreditMethodCard, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vSelectCard = Constants.CreateFxTicketOR.getProperty("SelectCard");
        Assert.assertEquals("PASS", Constants.key.click(vSelectCard, ""));
        String vWriteCardNumber = Constants.CreateFxTicketOR.getProperty("SelectCardSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vWriteCardNumber, CardNumFirst));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vWriteCardNumber, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vWriteCardNumber, "enter"));

        String vObjCVVfield = Constants.CreateFxTicketOR.getProperty("CardCvv");
        Assert.assertEquals("PASS", Constants.key.click(vObjCVVfield, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVVfield, CVV));
        Constants.key.pause("2", "");
        LogCapture.info("CVV entered is: " + CVV);

        String vAddCreditBtn = Constants.CreateFxTicketOR.getProperty("AddCreditButton");
        Assert.assertEquals("PASS", Constants.key.click(vAddCreditBtn, ""));
    }

    @And("^User clicks on Client type as \"([^\"]*)\"$")
    public void userClicksOnClientTypeAs(String value) throws Throwable {
        if (value.equalsIgnoreCase("PFX")) {
            String vPFXFilter = Constants.TitanCustomersOR.getProperty("PFX_Filter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPFXFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPFXFilter, ""));
            Assert.assertEquals("PASS", Constants.key.pause("4", ""));
        } else if (value.equalsIgnoreCase("CFX")) {
            String vCFXFilter = Constants.TitanCustomersOR.getProperty("ClientCFX");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCFXFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vCFXFilter, ""));
            Assert.assertEquals("PASS", Constants.key.pause("4", ""));
        }
    }

    @And("^User clicks on the First Hyperlink generated$")
    public void userClicksOnTheFirstHyperlinkGenerated() throws Exception {

        String vHyperlink = Constants.TitanCustomersOR.getProperty("Hyperlink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vHyperlink, ""));
        Assert.assertEquals("PASS", Constants.key.click(vHyperlink, ""));
        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
    }


    @And("^User is on Add Payment Page and clicks on Skip Button$")
    public void userIsOnAddPaymentPageAndClicksOnSkipButton() throws Exception {

        String vSkipButton = TitanCustomersOR.getProperty("ConfirmSkipBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
    }

    @And("^User is on Credit page and selects Card for Credit using the First four digits of card \"([^\"]*)\" and CVV \"([^\"]*)\"$")
    public void userIsOnCreditPageAndSelectsCardForCredit(String value, String CVV) throws Exception {


        String vCreditMethodCard = Constants.CreateFxTicketOR.getProperty("CreditMethodCard");
        String vSelectCard = Constants.CreateFxTicketOR.getProperty("SelectCard");
        String vWriteCardNumber = Constants.CreateFxTicketOR.getProperty("SelectCardSearch");
        Assert.assertEquals("PASS", Constants.key.click(vCreditMethodCard, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCard, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vWriteCardNumber, value));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vWriteCardNumber, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vWriteCardNumber, "enter"));

        String vObjCVVfield = Constants.CreateFxTicketOR.getProperty("CardCvv");
        Assert.assertEquals("PASS", Constants.key.click(vObjCVVfield, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVVfield, CVV));
        Constants.key.pause("2", "");
        LogCapture.info("CVV entered is: " + CVV);

        String vAddCreditBtn = Constants.CreateFxTicketOR.getProperty("AddCreditButton");
        Assert.assertEquals("PASS", Constants.key.click(vAddCreditBtn, ""));


    }

    @And("^User is on Add a Payment page and clicks on Skip button$")
    public void userIsOnAddAPaymentPageAndClicksOnSkipButton() throws Exception {

        String vObjFXAddPaymentPageSkipBtn = Constants.CreateFxTicketOR.getProperty("FXAddPaymentPageSkipBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXAddPaymentPageSkipBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentPageSkipBtn, ""));
        LogCapture.info("User clicks on SKIP button...");

    }

    @And("^User clicks in Instructions button and is navigated to the instructions page$")
    public void userClicksInInstructionsButtonAndIsNavigatedToTheInstructionsPage() throws Exception {

        String vObjInstructionsBtn = CreateFxTicketOR.getProperty("InstructionsBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionsBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionsBtn, ""));
        LogCapture.info("Clicking on instructions button...");
        Constants.key.pause("2", "");
    }

    @And("^User searches for the new instruction number$")
    public void userSearchesForTheNewInstructionNumber() throws Exception {

        String vOjbInstHeader = CreateFxTicketOR.getProperty("InstHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vOjbInstHeader, ""));
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, InstructionNumber));
        LogCapture.info("Searching for Client number" + InstructionNumber);
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");

        String vclientNumberXpath = "//*[contains(text(),'" + InstructionNumber + "')]";
        //String vclientNumberXpath= Constants.TitanCustomersOR.getProperty("CustomerFirstLine");
        //String vObjCustomerDetailLink = Constants.CreateFxTicketOR.getProperty("CustomerDetailLink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vclientNumberXpath, ""));


    }

    @And("^User clicks on Yes button for FX credit skip popup$")
    public void userClicksOnYesButtonForCreditSkipPopup() throws Throwable {
        Constants.key.pause("3", "");
        String vObjFXCreditSkipYesBtn = Constants.CreateFxTicketOR.getProperty("FXCreditSkipYesBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXCreditSkipYesBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXCreditSkipYesBtn, ""));
        LogCapture.info("Clicking on Yes button for FX credit skip pop-up....");
        Constants.key.pause("3", "");

    }

    @Then("^User validates Delete Payment Button is disabled$")
    public void userValidatesDeletePaymentButtonIsDisabled() throws Exception {
        LogCapture.info("Validating the delete payment button is disabled....");
        Constants.key.pause("2", "");
        String vObjDisabledPaymentDeleteBtn = Constants.TitanPaymentOutOR.getProperty("DisabledPaymentDeleteBtn");
        Assert.assertEquals("PASS", Constants.key.exist(vObjDisabledPaymentDeleteBtn, ""));

    }


    @And("^User Click on Apply button$")
    public void userClickOnApplyButton() throws Exception {
        LogCapture.info("User is now click on the Appply button after applying filter");
        String vObjApply = Constants.TitanCDSAPhase1OR.getProperty("ApplyButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjApply, ""));
        Constants.key.pause("5", "");

    }

    @And("^User Successfully landed on blank page on Titan$")
    public void userSuccessfullyLandedOnBlankPageOnTitan() throws Exception {
        LogCapture.info("Blank Page loading ......");
        Constants.key.pause("3", "");
        String vobjectDashboard = Constants.TitanCDSAPhase1OR.getProperty("ClientNumber");
        Assert.assertEquals("PASS", Constants.key.notexist(vobjectDashboard, ""));
        LogCapture.info("BlankPage loaded successfully");
    }

    @When("^User select file to upload and click on upload button$")
    public void userSelectFileToUploadAndClickOnUploadButton() throws Exception {
        LogCapture.info("User is selecting file to upload");
        Constants.key.pause("2", "");
        String vObjChooseFile = Constants.TitanCDSAPhase1OR.getProperty("chooseFile");
        String vUploadButton = Constants.TitanCDSAPhase1OR.getProperty("uploadButton");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjChooseFile, System.getProperty("user.dir") + "//src//File//Sample Aadhar.pdf"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vUploadButton, ""));
        LogCapture.info("User clicked on upload button");

    }

    @Then("^User should get error message as Please select Document Type$")
    public void userShouldGetErrorMessageAsPleaseSelectDocumentType() throws Exception {

        Constants.key.pause("2", "");
        String vErrorMessage = TitanCDSAPhase1OR.getProperty("uploadDocumentError");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vErrorMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vErrorMessage, "Please select Document Type"));
        LogCapture.info("User gets error message : Please select Document Type");

    }

    @When("^User select file to upload and document type$")
    public void userSelectFileToUploadAndDocumentType() throws Exception {
        LogCapture.info("User is selecting file to upload and document type");
        Constants.key.pause("2", "");
        String vObjChooseFile = Constants.TitanCDSAPhase1OR.getProperty("chooseFile");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjChooseFile, System.getProperty("user.dir") + "//src//File//Sample Aadhar.pdf"));
        String vObjdocumentDD = Constants.TitanCDSAPhase1OR.getProperty("documentTypeDD");
        Assert.assertEquals("PASS", Constants.key.click(vObjdocumentDD, ""));
        String vObjaddressProof = Constants.TitanCDSAPhase1OR.getProperty("proofOfAddress");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjaddressProof, ""));
        Constants.key.pause("1", "");

    }

    @And("^User click on upload button$")
    public void userClickOnUploadButton() throws Exception {
        LogCapture.info("User click on upload button");
        String vUploadButton = Constants.TitanCDSAPhase1OR.getProperty("uploadButton");
        Assert.assertEquals("PASS", Constants.key.click(vUploadButton, ""));
        Constants.key.pause("2", "");

    }

    @Then("^user uploads document successfully with success message$")
    public void userUploadsDocumentSuccessfullyWithSuccessMessage() throws Exception {

        String vObjsuccessMsg = TitanCDSAPhase1OR.getProperty("uploadDocSuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjsuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjsuccessMsg, "Success"));
        LogCapture.info("Document uploaded successfully");

    }

    @And("^click on clear all filter$")
    public void clickOnClearAllFilter() throws Exception {
        LogCapture.info("clearing all filters");
        String vclearall = Constants.TitanCDSAPhase1OR.getProperty("clearallbutton");
        Constants.key.click(vclearall, "");

    }

    @And("^user clicks on download button$")
    public void userClicksOnDownloadButton() throws Throwable {
        String vdownload = Constants.TitanCDSAPhase1OR.getProperty("vdownload");
        Assert.assertEquals("PASS", Constants.key.click(vdownload, ""));
        String vCSV = Constants.TitanCDSAPhase1OR.getProperty("vCSV");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vCSV, ""));
        Constants.key.fileDownload("", "CSV file.csv");
        Constants.key.pause("3", "");
    }

    @Then("^delete downloaded file$")
    public void deleteDownloadedFile() throws Throwable {
        Assert.assertEquals("PASS", Constants.key.fileDownloadOperations("isFileAvailable", "CSV file.csv"));
        Assert.assertEquals("PASS", Constants.key.fileDownloadOperations("deleteDownloadedFile", "CSV file.csv"));
    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" SORTCode\"([^\"]*)\" and click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberSORTCodeAndClickOnNextButton(String AccountNumber, String SORTCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        LogCapture.info("Account number is entered..");

        String vObjSORTCode = Constants.TitanCDSAPhase1OR.getProperty("SORTCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSORTCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSORTCode, SORTCode));
        LogCapture.info("SORT Code is entered..");

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");

        Constants.key.pause("3", "");
        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" SWIFTCode\"([^\"]*)\" and click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberSWIFTCodeAndClickOnNextButton(String AccountNumber, String SWIFTCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        LogCapture.info("Account number is entered..");

        String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SWIFTCode));
        LogCapture.info("SWIFT Code is entered..");

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");

        Constants.key.pause("3", "");
        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^user select bank\"([^\"]*)\"$")
    public void userSelectBank(String selectbank) throws Throwable {
        LogCapture.info("select bank option....");
        Constants.key.pause("4", "");
        String vObjSelectbank = Constants.TitanCDSAPhase1OR.getProperty("SelectBankCDSA");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjSelectbank, ""));
        Constants.key.pause("5", "");
        String vObjSelectbankdrowdown = Constants.TitanCDSAPhase1OR.getProperty("SelectBankCDSA");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectbankdrowdown, ""));
        String vObjselectbankSearch = Constants.TitanCDSAPhase1OR.getProperty("selectbanksearch");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjselectbankSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjselectbankSearch, selectbank));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjselectbankSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjselectbankSearch, "enter"));
        LogCapture.info("select bank..");
    }

    @And("^user clicks on forwards button$")
    public void userClicksOnForwardsButton() throws Exception {
        LogCapture.info("clicks on forwards button....");
        String vObjForwardButton = Constants.TitanCDSAPhase1OR.getProperty("ForwardsButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjForwardButton, ""));
    }

    @And("^user clicks on filter close button$")
    public void userClicksOnFilterCloseButton() throws Exception {
        LogCapture.info("clicks on filter close button....");
        String vObjFilterCloseButton = Constants.TitanCDSAPhase1OR.getProperty("FilterCloseButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilterCloseButton, ""));
        Constants.key.pause("4", "");
    }

    @And("^click on Fx and landed on fx window$")
    public void clickOnFxAndLandedOnFxWindow() throws Exception {
        LogCapture.info("clicks on Fx....");
        String vObjAccountsectionFX = Constants.TitanCDSAPhase1OR.getProperty("AccountsectionFX");
        Assert.assertEquals("PASS", Constants.key.click(vObjAccountsectionFX, ""));
        Constants.key.pause("4", "");
    }

    @And("^select the selling \"([^\"]*)\" and buying currencey \"([^\"]*)\" and enter selling amount \"([^\"]*)\"$")
    public void selectTheSellingAndBuyingCurrenceyAndEnterSellingAmount(String Sellingcurreny, String Buyingcurrency) throws Throwable {
        //    enter selling currencey
        LogCapture.info("Navigate selling currencey....");
        String vObjsellingcurrenceyDD = Constants.TitanCDSAPhase1OR.getProperty("sellingcurrenceyDD");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjsellingcurrenceyDD, Sellingcurreny));
        LogCapture.info("click on ZAR currencey....");
        String vObjZARcurrencey = Constants.TitanCDSAPhase1OR.getProperty("ZARcurrencey");
        Assert.assertEquals("PASS", Constants.key.click(vObjZARcurrencey, ""));
        Constants.key.pause("2", "");
        //enter buying currencey
        LogCapture.info("Navigate buying currencey....");
        String vObjbuyingcurrenceyDD = Constants.TitanCDSAPhase1OR.getProperty("buyingcurrenceyDD");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjbuyingcurrenceyDD, Buyingcurrency));
        LogCapture.info("click on USD currencey....");
        String vObjUSDcurrencey = Constants.TitanCDSAPhase1OR.getProperty("USDcurrencey");
        Assert.assertEquals("PASS", Constants.key.click(vObjUSDcurrencey, ""));
        Constants.key.pause("2", "");
    }

    @And("^select purpose of payment \"([^\"]*)\" and clicks Next$")
    public void selectPurposeOfPaymentAndClicksNext(String purposeOfPayment) throws Throwable {
        String vObjPurposeOfPayment = Constants.CreateFxTicketOR.getProperty("PurposeOfPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPurposeOfPayment, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPayment, ""));

        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vPurposeOfPaymentSearch_FireFox = Constants.CreateFxTicketOR.getProperty("PurposeOfPaymentSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vPurposeOfPaymentSearch_FireFox, ""));
            LogCapture.info("Purpose Of Payment: " + purposeOfPayment + " is selected...");
        } else {
            String vObjPurposeOfPaymentSearch = Constants.CreateFxTicketOR.getProperty("PurposeOfPaymentSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
            LogCapture.info("Purpose Of Payment: " + purposeOfPayment + " is selected...");
        }
        Constants.key.pause("2", "");
        String vObjSourceOfFundDownArrow = Constants.CreateFxTicketOR.getProperty("SourceOfFundDownArrow");
        boolean vSourceOfFund = Constants.driver.findElement(By.xpath(vObjSourceOfFundDownArrow)).isDisplayed();
        if (vSourceOfFund) {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSourceOfFundDownArrow, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSourceOfFundDownArrow, ""));
            String vObjSourceOfFundSearch = Constants.CreateFxTicketOR.getProperty("SourceOfFundSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSourceOfFundSearch, "SAVINGS"));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSourceOfFundSearch_FireFox = Constants.CreateFxTicketOR.getProperty("SourceOfFundSearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSourceOfFundSearch_FireFox, ""));
                LogCapture.info("Source of funds: SAVINGS is selected...");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundSearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundSearch, "enter"));
                LogCapture.info("Source of funds: SAVINGS is selected...");
            }
        }
        LogCapture.info("Navigate Next button....");
        String vObjNextbutton = Constants.TitanCDSAPhase1OR.getProperty("Nextbutton");
        Assert.assertEquals("PASS", Constants.key.click(vObjNextbutton, ""));
        Constants.key.pause("2", "");
        LogCapture.info("click on Next button....");
    }

    @And("^click on Instructed by option and spot \"([^\"]*)\"$")
    public void clickOnInstructedByOptionAndSpot(String DealType) throws Throwable {
        //click on Porteous1,Aubrey (P)
        LogCapture.info("Navigate Porteous1,Aubrey (P)....");
        Constants.key.pause("6", "");
        String vObjInstructedByoption = Constants.TitanCDSAPhase1OR.getProperty("InstructedByoption");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructedByoption, ""));
        LogCapture.info("click on Porteous1,Aubrey (P)....");
        Constants.key.pause("4", "");
        //click on spot
        LogCapture.info("Navigate deal type spot....");
        String vObjDealtypespot = Constants.TitanCDSAPhase1OR.getProperty("Dealtypespot");
        Assert.assertEquals("PASS", Constants.key.click(vObjDealtypespot, DealType));
        LogCapture.info("click on deal type spot....");
        Constants.key.pause("4", "");
    }

    @And("^User selects Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\"$")
    public void userSelectsSellingCurrencyBuyingCurrencySellingAmount(String BuyCurrency, String SellCurrency, String sellingAmount) throws Throwable {
        String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
        LogCapture.info("User is on FX details page..");
        Constants.key.pause("7", "");
        String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
        //Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjSellingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
        Constants.key.pause("4", "");
        String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

        String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
        LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

        String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
        LogCapture.info("Amount: " + sellingAmount + " is entered..");
    }

    @And("^user selects Bank, value date$")
    public void userSelectsBankValueDate() throws Exception {
        LogCapture.info("select bank option....");
        Constants.key.pause("4", "");
        String vObjBankname = Constants.TitanCDSAPhase1OR.getProperty("Bankname");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankname, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "enter"));
        String vObjselectbanklable = Constants.TitanCDSAPhase1OR.getProperty("selectbanklable");
        Assert.assertEquals("PASS", Constants.key.click(vObjselectbanklable, ""));
        LogCapture.info("select bank..");
        //click on value date
        LogCapture.info("select value date....");
        Constants.key.pause("7", "");
        String vObjvaluedate = Constants.TitanCDSAPhase1OR.getProperty("valuedate");
        Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjvaluedate, "enter"));

    }


    @And("^user selects value date and click on fetch rate$")
    public void userSelectsValueDateAndClickOnFetchRate() throws Exception {
        //click on value date
        LogCapture.info("select value date....");
        Constants.key.pause("7", "");
        String vObjvaluedate = Constants.TitanCDSAPhase1OR.getProperty("valuedate");
        Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjvaluedate, "enter"));
    }

    @Then("^verify fetch rate field is disabled$")
    public void verifyFetchRateFieldIsDisabled() throws Exception {
        String vObjfetchrate = Constants.TitanCDSAPhase1OR.getProperty("fetchrate");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjfetchrate, "enabled"));
        LogCapture.info(" fetch rate field is disabled....");
    }


    @Then("^User should validates the coustomer detail$")
    public void userShouldValidatesTheCoustomerDetail() throws Exception {
        LogCapture.info("verifying coustomer detail");
        String vCoustomername = Constants.TitanCDSAPhase1OR.getProperty("Coustomername");
        Assert.assertEquals("PASS", Constants.key.verifyText(vCoustomername, "Aubrey Porteous1   #0501001006788766 ACTIVE\n" +
                "CUSTOMERS"));
    }

    @Then("^User is able to view Wallet \"([^\"]*)\" detail$")
    public void userIsAbleToViewWalletDetail(String WalletCurrency) throws Throwable {

        String WalletSelected = "//h3[@id='modal-currency' and text()='" + WalletCurrency + "']";
        String WalletSelectedFlag = "//img[@class='droplist__flag' and @alt='" + WalletCurrency + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelected, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(WalletSelected, "visible"));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelectedFlag, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(WalletSelectedFlag, "visible"));
        LogCapture.info("Wallet details with flag for " + WalletCurrency + " are displayed...");

        String vObjWalletBalanceHeader = Constants.TitanDashboardOR.getProperty("WalletBalanceHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletBalanceHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletBalanceHeader, "visible"));
        LogCapture.info("Wallet Balance header is visible...");

        String vObjReferenceColumn = Constants.TitanDashboardOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReferenceColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible...");

        String vObjDateTimeColumn = Constants.TitanDashboardOR.getProperty("DateTimeColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDateTimeColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateTimeColumn, "visible"));
        LogCapture.info("Date/Time Column is visible...");

        String vObjTypeColumn = Constants.TitanDashboardOR.getProperty("TypeColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTypeColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTypeColumn, "visible"));
        LogCapture.info("Type Column is visible...");

        String vObjAmountColumn = Constants.TitanDashboardOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountColumn, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible...");

        String vObjWalletBalanceOnPage = Constants.TitanDashboardOR.getProperty("WalletBalanceOnPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletBalanceOnPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletBalanceOnPage, "visible"));
        LogCapture.info("Wallet balance is visible...");

        LogCapture.info("Wallet details for " + WalletCurrency + " are Verified...");

    }


    @And("^User navigate to (Debitor Number|Payment out|Customer|FX ticket) \"([^\"]*)\" Details$")
    public void userNavigateToDebitorNumberDetails(String page, String data) throws Throwable {
        if (page.equals("Debitor Number")) {
            String de = data.substring(4);
            String vObjKeywordFilterText = "//h1[contains(text(),'Debitor Number #" + de + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            LogCapture.info("User navigate to " + page + " #" + de + " Detail");
        } else if (page.equals("Payment out")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'Payment out #" + data + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
        } else if (page.equals("Customer")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'" + data + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

            String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
            String vObjCustomerStatus = Constants.TitanPaymentOutOR.getProperty("CustomerStatus");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCustomerStatus, "ACTIVE"));
            LogCapture.info("Customer status is Active verified..");

            String vObjLegalEntity = Constants.TitanCustomersOR.getProperty("LegalEntity");
            String LegalEntity = Constants.key.getText(vObjLegalEntity, "");
            LogCapture.info("Legal Entity " + LegalEntity + " is Verified");

            String vObjContacts = Constants.TitanCustomersOR.getProperty("ContactsTab");
            String vObjContactPlus = Constants.TitanCustomersOR.getProperty("ContactPlusBtn");
            String vObjContactMobileNo = Constants.TitanCustomersOR.getProperty("ContactMobileNo");

            Assert.assertEquals("PASS", Constants.key.click(vObjContacts, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjContactPlus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjContactMobileNo, "visible"));
            LogCapture.info("Customer Contacts Tab Verified");

            String vObjCreditLimit = Constants.TitanCustomersOR.getProperty("CreditLimitTab");
            String vObjCreditSpotTrading = Constants.TitanCustomersOR.getProperty("CreditSpotTradingLine");
            Assert.assertEquals("PASS", Constants.key.click(vObjCreditLimit, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCreditSpotTrading, "visible"));
            LogCapture.info("Credit Limit Tab Verified");

            String vObjDocument = Constants.TitanCustomersOR.getProperty("DocumentsTab");
            String vObjDocumentName = Constants.TitanCustomersOR.getProperty("DocumentName");
            Assert.assertEquals("PASS", Constants.key.click(vObjDocument, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDocumentName, "visible"));
            LogCapture.info("Document Tab Verified");

            String vObjActivity = Constants.TitanCustomersOR.getProperty("ActivityLogs");
            String vObjActivityMemo = Constants.TitanCustomersOR.getProperty("ActivityMemo");
            Assert.assertEquals("PASS", Constants.key.click(vObjActivity, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjActivityMemo, "visible"));
            LogCapture.info("Activity Log Tab Verified");


        } else if (page.equals("FX ticket")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'" + data + "')]";
            String vObjKeywordFilterText1 = "//h1[contains(text(),'Debitor Number #" + data + "')]";

            LogCapture.info(vObjKeywordFilterText);

            //String vObjKeywordFilterText = "//h1[contains(text(),'FX ticket for client #')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

            //String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

            LogCapture.info("User navigate to " + page + " # " + data + " Detail=========");
        }

    }

    @Then("^User click on first record from Payment in Queue page to verify debitor details$")
    public void userClickOnFirstRecordFromPaymentInQueuePageToVerifyDebitorDetails() throws Exception {

        String vobjFirstRecordPaymentsInQueue = Constants.TitanPaymentInOR.getProperty("FirstRecordPaymentsInQueue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsInQueue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsInQueue, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayInQueueDebitorAcctNo = Constants.TitanPaymentInOR.getProperty("PayInQueueDebitorAcctNo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInQueueDebitorAcctNo, "visible"));
        LogCapture.info("User able to view Debitor Account number on Debitor details page");

        String vobjPayInQueueAmount = Constants.TitanPaymentInOR.getProperty("PayInQueueAmount");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInQueueAmount, "visible"));
        LogCapture.info("User able to view Amount on Debitor details page");

        String vobjPayInQueueCurrency = Constants.TitanPaymentInOR.getProperty("PayInQueueCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInQueueCurrency, "visible"));
        LogCapture.info("User able to view Currency on Debitor details page");

    }

    @Then("^User click on first record from Payment Out Queue page to verify payee details$")
    public void userClickOnFirstRecordFromPaymentOutQueuePageToVerifyPayeeDetails() throws Exception {

        String vobjFirstRecordPaymentsOutQueue = TitanPaymentOutOR.getProperty("FirstRecordPaymentsOutQueue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsOutQueue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsOutQueue, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayOutCurrencyAmount = Constants.TitanPaymentOutOR.getProperty("PayOutCurrencyAmount");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutCurrencyAmount, "visible"));
        LogCapture.info("User able to View Currency and Amount on PaymentOut Customers details page");

        String vobjPayOutPayeeName = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutPayeeName, "visible"));
        LogCapture.info("User able to View Payee Name on PaymentOut Customers details page");

        String vobjPayOutPayeeCurrency = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutPayeeCurrency, "visible"));
        LogCapture.info("User able to View Payee-Currency on PaymentOut Customers details page");

        String vobjPayOutPayeeDetails = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeDetails");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutPayeeDetails, "visible"));
        LogCapture.info("User able to View Payee Details on PaymentOut details page");


    }

    @Then("^User click on first record from FX tickets Queue page to verify FX details$")
    public void userClickOnFirstRecordFromFXTicketsQueuePageToVerifyFXDetails() throws Exception {

        String vobjFirstRecordFXticketsQueue = TitanFXTicketsOR.getProperty("FirstRecordFXticketsQueue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordFXticketsQueue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordFXticketsQueue, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjFXQueueDetailsClientName = Constants.TitanFXTicketsOR.getProperty("FXQueueDetailsClientName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFXQueueDetailsClientName, "visible"));
        LogCapture.info("User able to View Client Name on FX Ticket details page");

        String vobjFXQueueDetailsDealType = Constants.TitanFXTicketsOR.getProperty("FXQueueDetailsDealType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFXQueueDetailsDealType, "visible"));
        LogCapture.info("User able to View Deal type on FX Ticket details page");

        String vobjFurtherClientDetails = Constants.TitanFXTicketsOR.getProperty("FurtherClientDetails");
        Assert.assertEquals("PASS", Constants.key.click(vobjFurtherClientDetails, ""));
        LogCapture.info("User Clicked on Further client details tab");

        String vobjFurtherdetailsClientName = Constants.TitanFXTicketsOR.getProperty("FurtherdetailsClientName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFurtherdetailsClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFurtherdetailsClientName, "visible"));
        LogCapture.info("User able to View Client name under further client Details Tab");

    }

    @Then("^User click on first record from Payment in Report page to verify debitor details$")
    public void userClickOnFirstRecordFromPaymentInReportPageToVerifyDebitorDetails() throws Exception {

        String vobjFirstRecordPaymentsInReport = Constants.TitanPaymentInOR.getProperty("FirstRecordPaymentsInReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsInReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsInReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayInReportsDebitorName = Constants.TitanPaymentInOR.getProperty("PayInReportsDebitorName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInReportsDebitorName, "visible"));
        LogCapture.info("User able to view Debitor Name on Debitor details page");

        String vobjPayInReportsAmount = Constants.TitanPaymentInOR.getProperty("PayInReportsAmount");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInReportsAmount, "visible"));
        LogCapture.info("User able to view Amount on Debitor details page");

        String vobjPayInReportCurrency = Constants.TitanPaymentInOR.getProperty("PayInReportCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInReportCurrency, "visible"));
        LogCapture.info("User able to view Currency on Debitor details page");
    }

    @Then("^User click on first record from Payment Out Report page to verify Payment Out Details$")
    public void userClickOnFirstRecordFromPaymentOutReportPageToVerifyPaymentOutDetails() throws Exception {

        String vobjFirstRecordPaymentsOutReport = TitanPaymentOutOR.getProperty("FirstRecordPaymentsOutReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsOutReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsOutReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayOutReportCurrencyAmount = Constants.TitanPaymentOutOR.getProperty("PayOutReportCurrencyAmount");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutReportCurrencyAmount, "visible"));
        LogCapture.info("User able to view Currency/Amount on PaymentOut details page");

        String vobjPayoutReportPayeeDetails = Constants.TitanPaymentOutOR.getProperty("PayoutReportPayeeDetails");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayoutReportPayeeDetails, "visible"));
        LogCapture.info("User able to view Payee Details on PaymentOut details page");

        String vobjPayOutReportPayeeName = Constants.TitanPaymentOutOR.getProperty("PayOutReportPayeeName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutReportPayeeName, "visible"));
        LogCapture.info("User able to view Payee Name under Payee detail Section");

        String vobjPayoutReportPayeeCurrency = Constants.TitanPaymentOutOR.getProperty("PayoutReportPayeeCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayoutReportPayeeCurrency, "visible"));
        LogCapture.info("User able to view Payee Currency under Payee detail Section");

    }

    @Then("^User click on first record from FX details Report page to verify Payment Out Details$")
    public void userClickOnFirstRecordFromFXDetailsReportPageToVerifyPaymentOutDetails() throws Exception {

        String vobjFirstRecordFXticketReports = TitanFXTicketsOR.getProperty("FirstRecordFXticketReports");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordFXticketReports, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordFXticketReports, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPFXReportDetailsClientName = Constants.TitanFXTicketsOR.getProperty("FXReportDetailsClientName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPFXReportDetailsClientName, "visible"));
        LogCapture.info("User able to view Client Name on FX details page under Report");

        String vobjFXReportDetailsDealType = Constants.TitanFXTicketsOR.getProperty("FXReportDetailsDealType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFXReportDetailsDealType, "visible"));
        LogCapture.info("User able to view Deal Type on FX details page under Report");

        String vobjFurtherClientDetails = Constants.TitanFXTicketsOR.getProperty("FurtherClientDetails");
        Assert.assertEquals("PASS", Constants.key.click(vobjFurtherClientDetails, ""));
        LogCapture.info("User Clicked on Further client details tab");

        String vobjFurtherdetailsClientName = Constants.TitanFXTicketsOR.getProperty("FurtherdetailsClientName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFurtherdetailsClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFurtherdetailsClientName, "visible"));
        LogCapture.info("User able to View Client name under further client Details Tab");
    }

    @Then("^User click on first record from Payee Report page to verify Payment Out Details$")
    public void userClickOnFirstRecordFromPayeeReportPageToVerifyPaymentOutDetails() throws Exception {

        String vobjFirstRecordPayeeReport = TitanPayeeOR.getProperty("FirstRecordPayeeReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPayeeReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPayeeReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayeeDetailsName = Constants.TitanPayeeOR.getProperty("PayeeDetailsName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsName, "visible"));
        LogCapture.info("User able to view Payee Name on Payee details page");

        String vobjPayeeDetailsAdress = Constants.TitanPayeeOR.getProperty("PayeeDetailsAdress");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsAdress, "visible"));
        LogCapture.info("User able to view Payee Address on Payee details page");

        String vobjPayeeDetailsAccountNo = Constants.TitanPayeeOR.getProperty("PayeeDetailsAccountNo");
        Assert.assertEquals("PASS", Constants.key.click(vobjPayeeDetailsAccountNo, ""));
        LogCapture.info("User able to view Bank Account Number on Payee details page");

        String vobjPayeeDetailsBankName = Constants.TitanPayeeOR.getProperty("PayeeDetailsBankName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsBankName, "visible"));
        LogCapture.info("User able to View Bank Name on Payee details page");
    }


    @Then("^verify FX Amend button is disabled$")
    public void verifyFXAmendButtonIsDisabled() throws Exception {
        String vObjAmend = Constants.TitanFXTicketsOR.getProperty("AmendFX");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmend, "enabled"));
        LogCapture.info(" Amend button is disabled....");
    }


    @Then("^User Successfully landed on blank page on Titan Customer$")
    public void userSuccessfullyLandedOnBlankPageOnTitanCustomer() throws Exception {

        LogCapture.info("Titan Customer Blank Page loading ......");
        Constants.key.pause("3", "");
        String vobjectDashboard = Constants.TitanCDSAPhase1OR.getProperty("OrgRecord");
        Assert.assertEquals("PASS", Constants.key.notexist(vobjectDashboard, ""));
        LogCapture.info("Titan Customer BlankPage loaded successfully");
    }

    @When("^user clicks on click on clear all filter$")
    public void userClicksOnClickOnClearAllFilter() throws Exception {
        LogCapture.info("clicks on clear all filter....");
        String vObjClearFilter = TitanCustomersOR.getProperty("ClearFilter");
        Assert.assertEquals("PASS", Constants.key.click(vObjClearFilter, ""));
        Constants.key.pause("4", "");
    }

    @Then("^User landed on default Customers Page$")
    public void userLandedOnDefaultCustomersPage() throws Exception {

        String vObjCustRecord1 = TitanCustomersOR.getProperty("CustRecord1");
        String organization1 = Constants.driver.findElement(By.xpath(vObjCustRecord1)).getText();
        String vObjCustRecord2 = TitanCustomersOR.getProperty("CustRecord2");
        String organization2 = Constants.driver.findElement(By.xpath(vObjCustRecord2)).getText();
        String vObjCustRecord3 = TitanCustomersOR.getProperty("CustRecord3");
        String organization3 = Constants.driver.findElement(By.xpath(vObjCustRecord3)).getText();

        LogCapture.info(organization1 + " > " + organization2 + " > " + organization3);
        if (organization1.equals(organization2) && organization1.equals(organization3)) {
            LogCapture.info("Not landed on default Customers Page...");
            Assert.assertEquals("PASS", Constants.KEYWORD_FAIL);
        } else {
            Assert.assertEquals("PASS", KEYWORD_PASS);
            LogCapture.info("Successfully landed on default Customers Page...");
        }
    }

    @And("^User selects Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\" select Bank$")
    public void userSelectsSellingCurrencyBuyingCurrencySellingAmountSelectBank(String SellCurrency, String BuyCurrency, String sellingAmount) throws Throwable {

        String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
        LogCapture.info("User is on FX details page..");
        Constants.key.pause("7", "");
        String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
        //Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjSellingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
        Constants.key.pause("4", "");
        String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

        String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
        LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

        String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
        LogCapture.info("Amount: " + sellingAmount + " is entered..");

        Constants.key.pause("4", "");
        String vObjSelectBank = Constants.CreateFxTicketOR.getProperty("SelectMBank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectBank, ""));
        String vObjMercantileBank1 = Constants.CreateFxTicketOR.getProperty("MercantileBank1");
        Assert.assertEquals("PASS", Constants.key.click(vObjMercantileBank1, ""));

        LogCapture.info("Bank is selected..");
    }

    @And("^user selects value date \"([^\"]*)\" and click on fetch rate$")
    public void userSelectsValueDateAndClickOnFetchRate(String VDate) throws Throwable {

        if (VDate.equals("T1")) {
            LogCapture.info("select value date " + VDate + " ....");
            Constants.key.pause("7", "");
            String vObjvaluedate = CreateFxTicketOR.getProperty("valuedate");
            Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
            String vObjt1ValueDate = Constants.CreateFxTicketOR.getProperty("t1ValueDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjt1ValueDate, ""));
            LogCapture.info("Value date " + VDate + " Selected....");

        } else if (VDate.equals("T2")) {
            LogCapture.info("select value date " + VDate + " ....");
            Constants.key.pause("7", "");
            String vObjvaluedate = Constants.CreateFxTicketOR.getProperty("valuedate");
            Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
            String vObjt1ValueDate = Constants.CreateFxTicketOR.getProperty("t2ValueDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjt1ValueDate, ""));
            LogCapture.info("Value date " + VDate + " Selected....");

        } else if (VDate.equals("T")) {
            LogCapture.info("select value date " + VDate + " ....");
            Constants.key.pause("7", "");
            String vObjvaluedate = Constants.CreateFxTicketOR.getProperty("valuedate");
            Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
            String vObjt2ValueDate = Constants.CreateFxTicketOR.getProperty("t2ValueDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjt2ValueDate, ""));

            String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
            Assert.assertEquals("PASS", Constants.key.click(vObjFetchRates, ""));

            Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
            String vObjtValueDate = Constants.CreateFxTicketOR.getProperty("tValueDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjtValueDate, ""));
            LogCapture.info("Value date " + VDate + " Selected....");
        }

    }

    @And("^User is on Credit page and select Bank option and click on add payment$")
    public void userIsOnCreditPageAndSelectBankOptionAndClickOnAddPayment() throws Exception {

        LogCapture.info("select Bank Method and click on Add Payment....");
        Constants.key.pause("5", "");
        String vObjPaymentMethodBank = CreateFxTicketOR.getProperty("PaymentMethodBank");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentMethodBank, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodBank, ""));

        String vObjAddCreditButton = CreateFxTicketOR.getProperty("AddCreditButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddCreditButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCreditButton, ""));
    }

    @Then("^User click on first record from FX details Report page to verify FX Details$")
    public void userClickOnFirstRecordFromFXDetailsReportPageToVerifyFXDetails() throws Exception {
        String vobjFirstRecordFXticketReports = TitanFXTicketsOR.getProperty("FirstRecordFXticketReports");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordFXticketReports, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordFXticketReports, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPFXReportDetailsClientName = Constants.TitanFXTicketsOR.getProperty("FXReportDetailsClientName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPFXReportDetailsClientName, "visible"));
        LogCapture.info("User able to view Client Name on FX details page under Report");

        String vobjFXReportDetailsDealType = Constants.TitanFXTicketsOR.getProperty("FXReportDetailsDealType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFXReportDetailsDealType, "visible"));
        LogCapture.info("User able to view Deal Type on FX details page under Report");

        String vobjFurtherClientDetails = Constants.TitanFXTicketsOR.getProperty("FurtherClientDetails");
        Assert.assertEquals("PASS", Constants.key.click(vobjFurtherClientDetails, ""));
        LogCapture.info("User Clicked on Further client details tab");

        String vobjFurtherdetailsClientName = Constants.TitanFXTicketsOR.getProperty("FurtherdetailsClientName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFurtherdetailsClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFurtherdetailsClientName, "visible"));
        LogCapture.info("User able to View Client name under further client Details Tab");
    }

    @And("^User clicks on FX reports hyperlink to navigate back to FX report page$")
    public void userClicksOnFXReportsHyperlinkToNavigateBackToFXReportPage() throws Exception {

        String vobjFXTicketsReport = Constants.TitanFXTicketsOR.getProperty("FXTicketsReportlink");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vobjFXTicketsReport, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vobjFXTicketsReport, "click"));
        //      Assert.assertEquals("PASS", Constants.key.click(vobjFXTicketsReport, ""));
        LogCapture.info("User clicks on FX Tickets report hyperlink..");
        String vObjFXTicketsReport = Constants.TitanFXTicketsOR.getProperty("FXTicketsReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsReport, ""));
        LogCapture.info("User is on FX Reports in Titan page..");
    }

    @And("^Select Organisation as \"([^\"]*)\" and apply filter$")
    public void selectOrganisationAsAndApplyFilter(String Organisation) throws Throwable {

        String vObjOrgFilterInvoices = TitanCustomersOR.getProperty("OrgFilterInvoices");
        Assert.assertEquals("PASS", Constants.key.click(vObjOrgFilterInvoices, ""));

        String SelectOrg = "//input[@value='" + Organisation + "']//parent :: label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectOrg, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(SelectOrg, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(SelectOrg, "click"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(SelectOrg, "enter"));

        LogCapture.info("User Selected organisation as " + Organisation);


    }

    @Then("^User is able to click on Pay out button$")
    public void userIsAbleToClickOnPayOutButton() throws Throwable {
        String vobjPayeeout = TitanPaymentOutOR.getProperty("PaymentOutButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPayeeout, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjPayeeout, ""));

    }


    @And("^user click on bank option$")
    public void userClickOnBankOption() throws Exception {

        String vObjCustDetailsBankTab = TitanCustomersOR.getProperty("CustDetailsBankTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustDetailsBankTab, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjCustDetailsBankTab, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjCustDetailsBankTab, "click"));

        LogCapture.info("User click on bank option");
    }

    @Then("^User click on send email option and observe the message$")
    public void userClickOnSendEmailOptionAndObserveTheMessage() throws Exception {

        String vObjSendEmailOption = TitanCustomersOR.getProperty("SendEmailOption");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjSendEmailOption, ""));

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendEmailOption, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjSendEmailOption, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjSendEmailOption, "click"));

        LogCapture.info("User click send email option");

    }

    @And("^System should open the Incoming Fund queue Page  with Zero \"([^\"]*)\" records should be seen\\.$")
    public void systemShouldOpenTheIncomingFundQueuePageWithZeroRecordsShouldBeSeen(String application) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //td//a[text()="CDLZA"]
        String vclient = "//td//a[text()='" + application + "']";
        Assert.assertEquals("PASS", Constants.key.notexist(vclient, ""));
        LogCapture.info("User validate no records of  " + application + ",should present.");
        Constants.key.pause("2", "");

    }

    @And("^click on Instructed by option and Forward \"([^\"]*)\"$")
    public void clickOnInstructedByOptionAndForward(String DealType) throws Throwable {
        LogCapture.info("Navigate Porteous1,Aubrey (P)....");
        Constants.key.pause("3", "");
        String vObjInstructedByoption = Constants.TitanCDSAPhase1OR.getProperty("InstructedByoption");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructedByoption, ""));
        LogCapture.info("click on Porteous1,Aubrey (P)....");
        Constants.key.pause("3", "");
        //click on spot
        LogCapture.info("Navigate deal type Forward....");
        String vObjDealtypeForward = Constants.TitanCDSAPhase1OR.getProperty("DealtypeForward");
        Assert.assertEquals("PASS", Constants.key.click(vObjDealtypeForward, DealType));
        LogCapture.info("click on deal type Forward....");
        Constants.key.pause("3", "");
    }

    @And("^User Select Forward type \"([^\"]*)\" and Select From date and To date$")
    public void userSelectForwardTypeAndSelectFromDateAndToDate(String data) throws Throwable {
        if (data.equalsIgnoreCase("Open")) {
            LogCapture.info("select From date....");
            Constants.key.pause("4", "");
            String vObjFromDate = Constants.TitanCDSAPhase1OR.getProperty("FromDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjFromDate, ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromDate, "enter"));
            Constants.key.pause("3", "");

            LogCapture.info("select To Date....");
            Constants.key.pause("4", "");
            String vObjToDate = Constants.TitanCDSAPhase1OR.getProperty("ToDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToDate, "enter"));
            Constants.key.pause("4", "");
        } else if (data.equalsIgnoreCase("Fixed")) {
            String vObjFixed = CreateFxTicketOR.getProperty("FixedForwardType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFixed, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFixed, ""));
            LogCapture.info("User clicked on Fixed Forward type....");

            LogCapture.info("select  Date....");
            Constants.key.pause("2", "");
            String vObjToDate = Constants.TitanCDSAPhase1OR.getProperty("Selectdate");
            Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToDate, "enter"));
            Constants.key.pause("2", "");
        }
    }

    @And("^User select Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\"$")
    public void userSelectSellingCurrencyBuyingCurrencySellingAmount(String SellCurrency, String BuyCurrency, String sellingAmount) throws Throwable {
        String vObjSellingCurrencySearch = Constants.TitanCDSAPhase1OR.getProperty("SellingCurrencySearch");
        //Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjSellingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
        Constants.key.pause("4", "");
        String vObjBuyingCurrency = Constants.TitanCDSAPhase1OR.getProperty("BuyingCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));
        LogCapture.info("User clicked on buy currency");
        Constants.key.pause("4", "");
        String vObjBuyingCurrencySearch = Constants.TitanCDSAPhase1OR.getProperty("BuyingCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
        LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

        String vObjSellingAmount = Constants.TitanCDSAPhase1OR.getProperty("SellingAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
        LogCapture.info("Amount: " + sellingAmount + " is entered..");
    }

    @And("^user selects Bank$")
    public void userSelectsBank() throws Exception {
        LogCapture.info("selecting bank....");
        Constants.key.pause("4", "");
        String vObjSelectBank = Constants.TitanCDSAPhase1OR.getProperty("SelectBank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectBank, ""));
        LogCapture.info("user clicked on dropdown option to select bank....");
        Constants.key.pause("4", "");
        String vObjBankName = Constants.TitanCDSAPhase1OR.getProperty("BankName");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjBankName, "click"));
        LogCapture.info("User successfully selected bank of his choice...");
    }

    @Then("^verify fetch rate field is enabled$")
    public void verifyFetchRateFieldIsEnabled() throws Exception {
        String vObjfetchrate = Constants.TitanCDSAPhase1OR.getProperty("fetchrate");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjfetchrate, "enabled"));
        LogCapture.info(" fetch rate field is enabled....");

    }

    @And("^User selects Payee\"([^\"]*)\" PaymentDate Amount\"([^\"]*)\" PurposeOfPayment\"([^\"]*)\"and select bank \"([^\"]*)\" clicks on Add Payment button and Yes button for Payment Out$")
    public void userSelectsPayeePaymentDateAmountPurposeOfPaymentAndSelectBankClicksOnAddPaymentButtonAndYesButtonForPaymentOut
            (String Payee, String Amount, String purposeOfPayment, String bank) throws Throwable {
        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");

        String vObjPaymentDate = Constants.TitanPaymentOutOR.getProperty("PaymentDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDate, ""));
        Constants.key.pause("2", "");
        String vObjTodaysDate = Constants.TitanPaymentOutOR.getProperty("TodaysDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjTodaysDate, ""));
        LogCapture.info("Selecting Todays date...");

        String vObjAmount = Constants.TitanPaymentOutOR.getProperty("Amount");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Amount));
        LogCapture.info("Amount entred is: " + Amount);

        String vObjPurposeOfPaymentDropdownArrow = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPurposeOfPaymentDropdownArrow, ""));
        String vObjPurposeOfPaymentSearch = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPaymentSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
        LogCapture.info("Purpose of Payment: " + purposeOfPayment + " is selected..");
        Constants.key.pause("2", "");
        String vObjSelectbank = TitanPaymentOutOR.getProperty("Selectbank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectbank, ""));
        Constants.key.pause("2", "");
        String vObjSearchbox2 = TitanPaymentOutOR.getProperty("Searchbox2");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchbox2, bank));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchbox2, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchbox2, ""));
        LogCapture.info("Select Bank is selected..");
        Constants.key.pause("1", "");
        String vObjAddPaymentBtn = Constants.TitanPaymentOutOR.getProperty("AddPaymentBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddPaymentBtn, ""));
        LogCapture.info("Clicked on Add Payment button...");
        String vObjPaymentOutYesBtn = Constants.TitanPaymentOutOR.getProperty("PaymentOutYesBtn");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjPaymentOutYesBtn, ""));
        LogCapture.info("Clicking on YES button for pop-up...");
    }

    @And("^User selects Bank for (PayOut|FX)$")
    public void userSelectsBank(String Value) throws Exception {
        if (Value.equalsIgnoreCase("PayOut")) {
            String vObjBankDropdownArrow = Constants.TitanCDSAPhase1OR.getProperty("BankDropdown");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDropdownArrow, ""));
            String vObjBankSearch = Constants.TitanCDSAPhase1OR.getProperty("BankSearch");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjBankSearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBankSearch, "Test"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankSearch, "enter"));
            LogCapture.info("Bank is selected by User..");
        } else if (Value.equalsIgnoreCase("FX")) {
            LogCapture.info("select bank option....");
            Constants.key.pause("4", "");
            String vObjBankname = Constants.TitanCDSAPhase1OR.getProperty("Bankname");
            Assert.assertEquals("PASS", Constants.key.click(vObjBankname, ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "enter"));
            String vObjselectbanklable = Constants.TitanCDSAPhase1OR.getProperty("selectbanklable");
            Assert.assertEquals("PASS", Constants.key.click(vObjselectbanklable, ""));
            LogCapture.info("select bank..");
        }
    }

    @And("^User selects Payee\"([^\"]*)\" PaymentDate Amount\"([^\"]*)\" PurposeOfPayment\"([^\"]*)\"$")
    public void userSelectsPayeePaymentDateAmountPurposeOfPayment(String Payee, String Amount, String purposeOfPayment) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");

        String vObjPaymentDate = Constants.TitanPaymentOutOR.getProperty("PaymentDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDate, ""));
        Constants.key.pause("2", "");
        String vObjTodaysDate = Constants.TitanPaymentOutOR.getProperty("TodaysDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjTodaysDate, ""));
        LogCapture.info("Selecting Todays date...");

        String vObjAmount = Constants.TitanPaymentOutOR.getProperty("Amount");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Amount));
        LogCapture.info("Amount entred is: " + Amount);


        String vObjPurposeOfPaymentDropdownArrow = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPurposeOfPaymentDropdownArrow, ""));
        String vObjPurposeOfPaymentSearch = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPaymentSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
        LogCapture.info("Purpose of Payment: " + purposeOfPayment + " is selected..");
    }

    @And("^User clicks on Add Payment button and Yes button for Payment Out$")
    public void userClicksOnAddPaymentButtonAndYesButtonForPaymentOut() throws Exception {

        String vObjAddPaymentBtn = Constants.TitanPaymentOutOR.getProperty("AddPaymentBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddPaymentBtn, ""));
        LogCapture.info("Clicked on Add Payment button...");
        String vObjPaymentOutYesBtn = Constants.TitanPaymentOutOR.getProperty("PaymentOutYesBtn");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjPaymentOutYesBtn, ""));
        LogCapture.info("Clicking on YES button for pop-up...");

    }

    @And("^User selects Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\" according to DealType\"([^\"]*)\"$")
    public void userSelectsSellingCurrencyBuyingCurrencySellingAmountAccordingToDealType(String SellCurrency, String BuyCurrency, String sellingAmount, String DealType) throws Throwable {

        if (DealType.equalsIgnoreCase("Spot")) {
            String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSellingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSellingCurrencySearch_FireFox, ""));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            }

            Constants.key.pause("2", "");
            String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

            String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vBuyingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vBuyingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
                LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");
            }

            String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
            LogCapture.info("Amount: " + sellingAmount + " is entered..");
        }

        if (DealType.equalsIgnoreCase("Forward")) {
            String vObjLimitOrderCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("ForwardOrderCurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLimitOrderCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vForwardOrderSellingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vForwardOrderSellingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            }

            Constants.key.pause("2", "");
            String vObjLimitOrderBuyingCurrency = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencyDropArrow");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrency, ""));

            String vObjLimitOrderBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderBuyingCurrencySearch, BuyCurrency));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vForwardOrderBuyingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vForwardOrderBuyingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "enter"));
                LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");
            }

            String vObjLimitOrderSellingAmount = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderSellingAmount, sellingAmount));
            LogCapture.info("Amount: " + sellingAmount + " is entered..");

        }
    }

    @And("^User clicks on Fetch rates button$")
    public void userClicksOnFetchRatesButton() throws Exception {

        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");
        String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
        String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
        if (LiveRate == null) {
            Assert.fail();
            LogCapture.info("Fetching rates.. Live Rate is Null...");
        } else {
            LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
        }
        LogCapture.info("Rates fetched..");
    }

    @And("^User selects Value date plus one$")
    public void userSelectsValueDatePlusOne() throws Exception {
        String Valuedate;
        String vObjCalendar = Constants.TitanCDSAPhase1OR.getProperty("Calendar");
        Assert.assertEquals("PASS", Constants.key.click(vObjCalendar, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        DateFormat dateFormat = new SimpleDateFormat("dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY)) {
            cal.add(Calendar.DATE, 3);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)) {
            cal.add(Calendar.DATE, 2);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)) {
            cal.add(Calendar.DATE, 1);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else {
            cal.add(Calendar.DATE, 1);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        }

        if (Valuedate.equals("01")) {
            Valuedate = "1";
        } else if (Valuedate.equals("02")) {
            Valuedate = "2";
        } else if (Valuedate.equals("03")) {
            Valuedate = "3";
        } else if (Valuedate.equals("04")) {
            Valuedate = "4";
        } else if (Valuedate.equals("05")) {
            Valuedate = "5";
        } else if (Valuedate.equals("06")) {
            Valuedate = "6";
        } else if (Valuedate.equals("07")) {
            Valuedate = "7";
        } else if (Valuedate.equals("08")) {
            Valuedate = "8";
        } else if (Valuedate.equals("09")) {
            Valuedate = "9";
        }

        String CDSAValueDate = "//a[@class='ui-state-default' and contains(text(),'" + Valuedate + "')]";
        Assert.assertEquals("PASS", Constants.key.click(CDSAValueDate, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User select Value Date " + Valuedate);

    }

    @And("^User selects Bank and clicks Add Credit$")
    public void userSelectsBankAndClicksAddCredit() throws Exception {
        String vObjCreditPageBank = Constants.TitanCDSAPhase1OR.getProperty("CreditPageBank");
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        //Assert.assertEquals("PASS", Constants.key.click(vObjCreditPageBank, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCreditPageBank, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjAddCredit = Constants.TitanCDSAPhase1OR.getProperty("AddCredit");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCredit, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
    }

    @And("^User clicks on Next button for credit page$")
    public void userClicksOnNextButtonForCreditPage() throws Exception {
        Constants.key.pause("5", "");
        String vObjNext2Button = Constants.CreateFxTicketOR.getProperty("Next2Button");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjNext2Button, ""));
        LogCapture.info("Clicking on Next button....");
    }

    @And("^User clicks on Fetch rates button for CDSA$")
    public void userClicksOnFetchRatesButtonForCDSA() throws Exception {
        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");
        String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValueCDSA");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
        String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
        if (LiveRate == null) {
            Assert.fail();
            LogCapture.info("Fetching rates.. Live Rate is Null...");
        } else {
            LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
        }
        LogCapture.info("Rates fetched..");

    }

    @And("^User selects Payee\"([^\"]*)\"$")
    public void userSelectsPayee(String Payee) throws Throwable {

        String vObjAddAPaymentPage = Constants.CreateFxTicketOR.getProperty("AddAPaymentPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddAPaymentPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddAPaymentPage, "visible"));
        LogCapture.info("User is on 4 of 4: Add a Payment page...");

        String vObjSelectPayeeDownArrow = Constants.CreateFxTicketOR.getProperty("SelectPayeeDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjSearchPayee = Constants.CreateFxTicketOR.getProperty("SearchPayee");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchPayee, ""));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSearchPayee_FireFox = Constants.CreateFxTicketOR.getProperty("SearchPayee_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSearchPayee_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
            LogCapture.info("Payee: " + Payee + " is selected..");

        }
    }

    @And("^User enters Fee Amount$")
    public void userEntersFeeAmount() throws Exception {
        String vObjFeeAmount = TitanCDSAPhase1OR.getProperty("FeeAmount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFeeAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFeeAmount, "2.5"));
        Constants.key.pause("2", "");
    }


    @And("^User clicks on Finished Adding Payment button$")
    public void userClicksOnFinishedAddingPaymentButton() throws Exception {
        String vObjFXFinishedAddPaymentBtn = Constants.CreateFxTicketOR.getProperty("FXFinishedAddPaymentBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXFinishedAddPaymentBtn, ""));
        LogCapture.info("Clicking on Finished Adding Payment button...");
    }

    @And("^User verifies No Payee Alert$")
    public void userVerifiesNoPayeeAlert() throws Exception {
        String vObjNoPayeeAlert = TitanCDSAPhase1OR.getProperty("NoPayeeAlert");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNoPayeeAlert, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjNoPayeeAlert, "visible"));
        LogCapture.info("Payee not visible");
    }

    @And("^User clicks on Skip button and Yes button for popup$")
    public void userClicksOnSkipButtonAndYesButtonForPopup() throws Exception {

        String vObjSkipButton = TitanCDSAPhase1OR.getProperty("SkipButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSkipButton, ""));
        Constants.key.pause("2", "");

        String vObjYesButton = TitanCDSAPhase1OR.getProperty("YesButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
        LogCapture.info("Clicking on YES button for pop-up...");
    }


    @When("^user clicks on Fetch rates buttons$")
    public void userClicksOnFetchRatesButtons() throws Exception {
        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("fetrate");
        Assert.assertEquals("PASS", Constants.key.click(vObjFetchRates, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");

    }

    @Then("^User enter UpperRatePercentage \"([^\"]*)\"$")
    public void userEnterUpperRatePercentage(String UpperRatePercentage) throws Throwable {
        String vObjupperrate = Constants.CreateFxTicketOR.getProperty("ForwardOrderClientRatePercent");
        Assert.assertEquals("PASS", Constants.key.click(vObjupperrate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjupperrate, UpperRatePercentage));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjupperrate, "enter"));
        Constants.key.pause("2", "");
        LogCapture.info("Client rate % entered is: " + UpperRatePercentage);
    }

    @When("^User click on bank method$")
    public void userClickOnBankMethod() throws Exception {
        String vObjbnkopt = Constants.CreateFxTicketOR.getProperty("Bankopt");
        Assert.assertEquals("PASS", Constants.key.click(vObjbnkopt, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");
    }

    @And("^User clicks on Skips button$")
    public void userClicksOnSkipsButton() throws Exception {
        String vObjskipopt = Constants.CreateFxTicketOR.getProperty("ConfirmSkipBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjskipopt, ""));
        LogCapture.info("User clicks on SKIP button...");
    }

    @Then("^user click on yes option$")
    public void userClickOnYesOption() throws Exception {
        String vObjyesButton = Constants.CreateFxTicketOR.getProperty("yesbtton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjyesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjyesButton, ""));
        Constants.key.pause("2", "");

    }

    @And("^User Select Forward type and Select date$")
    public void userSelectForwardTypeAndSelectDate() throws Exception {
        String vObjFixed = CreateFxTicketOR.getProperty("FixedForwardType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFixed, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFixed, ""));
        LogCapture.info("User clicked on Fixed Forward type....");

        LogCapture.info("select  Date....");
        Constants.key.pause("4", "");
        String vObjToDate = Constants.TitanCDSAPhase1OR.getProperty("Selectdate");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjToDate, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToDate, "enter"));
        Constants.key.pause("4", "");
    }

    @And("^User click on fee fetch$")
    public void userClickOnFeeFetch() throws Exception {
        String vObjfeefetch = Constants.CreateFxTicketOR.getProperty("feefetch");
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjfeefetch, ""));
        Constants.key.pause("5", "");
        LogCapture.info("User clicks on fee fetch ...");

    }


    @And("^Add \"([^\"]*)\" payment date enters \"([^\"]*)\"insert \"([^\"]*)\"$")
    public void addPaymentDateEntersInsert(String Payee, String Amount, String Fee) throws Throwable {
        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");
        Constants.key.pause("3", "");
        //entering date
        LogCapture.info("select value date....");
        Constants.key.pause("4", "");
        String vObjPaymentDate = Constants.TitanCDSAPhase1OR.getProperty("PaymentDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPaymentDate, "enter"));
        //enters amount
        Constants.key.pause("4", "");
        String vObjEnterAmount = Constants.TitanCDSAPhase1OR.getProperty("EnterAmount");
        Assert.assertEquals("PASS", Constants.key.click(vObjEnterAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEnterAmount, Amount));
        LogCapture.info("Amount entred is: " + Amount);
        //enters fee
        Constants.key.pause("4", "");
        String vObjEnterFee = Constants.TitanCDSAPhase1OR.getProperty("EnterFee");
        Assert.assertEquals("PASS", Constants.key.click(vObjEnterFee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEnterFee, Fee));
        LogCapture.info("Fee entred is: " + Fee);
    }

    @And("^select purpose of payment \"([^\"]*)\"and Select the bank\"([^\"]*)\"$")
    public void selectPurposeOfPaymentAndSelectTheBank(String purposeOfPayment, String bank) throws Throwable {
        Constants.key.pause("1", "");
        String vObjpurposeofpayment = TitanCDSAPhase1OR.getProperty("purposeofpayment");
        Assert.assertEquals("PASS", Constants.key.click(vObjpurposeofpayment, ""));
        Constants.key.pause("2", "");
        String vObjsearchbox1 = TitanCDSAPhase1OR.getProperty("Searchbox1");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjsearchbox1, purposeOfPayment));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjsearchbox1, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.click(vObjsearchbox1, ""));
        LogCapture.info("Select purpose Of Payment : is selected..");
        //select bank
        Constants.key.pause("2", "");
        String vObjSelectbank = TitanCDSAPhase1OR.getProperty("Selectbank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectbank, ""));
        Constants.key.pause("2", "");
        String vObjSearchbox2 = TitanCDSAPhase1OR.getProperty("Searchbox2");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchbox2, bank));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchbox2, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchbox2, ""));
        LogCapture.info("Select Bank is selected..");
        Constants.key.pause("1", "");
    }

    @And("^User clicks on Add payment button and finish adding payment button$")
    public void userClicksOnAddPaymentButtonAndFinishAddingPaymentButton() throws Exception {
        //clicks on add payment
        LogCapture.info("Navigate Add payment button....");
        Constants.key.pause("1", "");
        String vObjAddPaymentBtn = Constants.TitanCDSAPhase1OR.getProperty("AddPaymentBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddPaymentBtn, ""));
        LogCapture.info("click on Add payment button....");
        Constants.key.pause("4", "");
        //click on finish adding payment button
        LogCapture.info("navigate finish adding payment....");
        Constants.key.pause("1", "");
        String vObjfinishpayment = Constants.TitanCDSAPhase1OR.getProperty("finishpayment");
        Assert.assertEquals("PASS", Constants.key.click(vObjfinishpayment, ""));
        LogCapture.info("click on finish payment button....");
        Constants.key.pause("4", "");
    }

    @And("^user clicks on Submit button in payout and click on close payment out slip$")
    public void userClicksOnSubmitButtonInPayoutAndClickOnClosePaymentOutSlip() throws Exception {
        //click on submit button
        LogCapture.info("navigate payout submit button....");
        Constants.key.pause("1", "");
        String vObjSubmitButton = Constants.TitanCDSAPhase1OR.getProperty("SubmitButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjSubmitButton, ""));
        LogCapture.info("click on submit button....");
        Constants.key.pause("4", "");
        //click on closeout slip button
        LogCapture.info("navigate to closeout slip button....");
        Constants.key.pause("1", "");
        String vObjCloseSlipButton = Constants.TitanCDSAPhase1OR.getProperty("CloseSlipButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjCloseSlipButton, ""));
        LogCapture.info("click on to closeout slip button....");
        Constants.key.pause("4", "");
    }


    @Then("^verify \"([^\"]*)\" field is disabled$")
    public void verifyFieldIsDisabled(String data) throws Throwable {
        if (data.equalsIgnoreCase("card")) {
            String vObjCardOption = TitanCDSAPhase1OR.getProperty("CardOption");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCardOption, "enabled"));
            Constants.key.pause("2", "");
            LogCapture.info(" card field is disabled....");
        }
        if (data.equalsIgnoreCase("DD")) {
            String vObjDDOption = TitanCDSAPhase1OR.getProperty("DDOption");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDDOption, "enabled"));
            Constants.key.pause("2", "");
            LogCapture.info(" DD field is disabled....");
        }
        if (data.equalsIgnoreCase("DD")) {
            String vObjchequeOption = TitanCDSAPhase1OR.getProperty("chequeOption");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjchequeOption, "enabled"));
            Constants.key.pause("2", "");
            LogCapture.info("cheque field is disabled....");
        }
    }

    @And("^User selects Value date plus two$")
    public void userSelectsValueDatePlusTwo() throws Exception {
        String Valuedate;
        String vObjCalendar = Constants.TitanCDSAPhase1OR.getProperty("Calendar");
        Assert.assertEquals("PASS", Constants.key.click(vObjCalendar, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        DateFormat dateFormat = new SimpleDateFormat("dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY)) {
            cal.add(Calendar.DATE, 4);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY)) {
            cal.add(Calendar.DATE, 3);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if (Calendar.DAY_OF_WEEK == Calendar.SATURDAY) {
            cal.add(Calendar.DATE, 2);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if (Calendar.DAY_OF_WEEK == Calendar.SUNDAY) {
            cal.add(Calendar.DATE, 1);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else {
            cal.add(Calendar.DATE, 1);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        }
        if (Valuedate.equals("01")) {
            Valuedate = "1";
        } else if (Valuedate.equals("02")) {
            Valuedate = "2";
        } else if (Valuedate.equals("03")) {
            Valuedate = "3";
        } else if (Valuedate.equals("04")) {
            Valuedate = "4";
        } else if (Valuedate.equals("05")) {
            Valuedate = "5";
        } else if (Valuedate.equals("06")) {
            Valuedate = "6";
        } else if (Valuedate.equals("07")) {
            Valuedate = "7";
        } else if (Valuedate.equals("08")) {
            Valuedate = "8";
        } else if (Valuedate.equals("09")) {
            Valuedate = "9";
        }


        String CDSAValueDate = "//a[@class='ui-state-default' and contains(text(),'" + Valuedate + "')]";
        Assert.assertEquals("PASS", Constants.key.click(CDSAValueDate, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User select value date as " + Valuedate);


    }

    @And("^user selects value date$")
    public void userSelectsValueDate() throws Exception {
        LogCapture.info("select value date....");
        Constants.key.pause("7", "");
        String vObjvaluedate = Constants.TitanCDSAPhase1OR.getProperty("valuedate");
        Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjvaluedate, "enter"));
        LogCapture.info("User select value date");

    }

    @And("^user able to selects Bank$")
    public void userabletoSelectsBank() throws Exception {
        LogCapture.info("select bank option....");
        Constants.key.pause("4", "");
        String vObjBankname = Constants.TitanCDSAPhase1OR.getProperty("Bankname");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankname, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "enter"));
        String vObjselectbanklable = Constants.TitanCDSAPhase1OR.getProperty("selectbanklable");
        Assert.assertEquals("PASS", Constants.key.click(vObjselectbanklable, ""));
        LogCapture.info("select bank..");
    }


    @Then("^User click on first record from Payee Report page to verify Payee Details$")
    public void userClickOnFirstRecordFromPayeeReportPageToVerifyPayeeDetails() throws Exception {
        String vobjFirstRecordPayeeReport = TitanPayeeOR.getProperty("FirstRecordPayeeReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPayeeReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPayeeReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayeeDetailsName = Constants.TitanPayeeOR.getProperty("PayeeDetailsName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsName, "visible"));
        LogCapture.info("User able to view Payee Name on Payee details page");

        String vobjPayeeDetailsAdress = Constants.TitanPayeeOR.getProperty("PayeeDetailsAdress");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsAdress, "visible"));
        LogCapture.info("User able to view Payee Address on Payee details page");

        String vobjPayeeDetailsAccountNo = Constants.TitanPayeeOR.getProperty("PayeeDetailsAccountNo");
        Assert.assertEquals("PASS", Constants.key.click(vobjPayeeDetailsAccountNo, ""));
        LogCapture.info("User able to view Bank Account Number on Payee details page");

        String vobjPayeeDetailsBankName = Constants.TitanPayeeOR.getProperty("PayeeDetailsBankName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsBankName, "visible"));
        LogCapture.info("User able to View Bank Name on Payee details page");
    }

    @And("^User selects bank for FX$")
    public void userSelectsBankForFX() throws Exception {
        LogCapture.info("select bank option....");
        Constants.key.pause("4", "");
        String vObjBan_kname = Constants.TitanCDSAPhase1OR.getProperty("Bank_name");
        Assert.assertEquals("PASS", Constants.key.click(vObjBan_kname, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBan_kname, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBan_kname, "enter"));
        String vObjfirstBank = TitanCDSAPhase1OR.getProperty("firstBank");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjfirstBank, ""));
        LogCapture.info("select bank..");
    }

    @And("^User clicks on BANKS tab under Linked to client$")
    public void userClicksOnBANKSTabUnderLinkedToClient() throws Exception {
        String vObjBANKSTab = Constants.TitanCDSAPhase1OR.getProperty("BANKSTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBANKSTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjBANKSTab, ""));
        LogCapture.info("Clicking on BANKS tab...");
    }

    @And("^User clicks on SEND EMAIL$")
    public void userClicksOnSENDEMAIL() throws Exception {
        Constants.key.pause("4", "");
        String vObjSendEmailButton = Constants.TitanCDSAPhase1OR.getProperty("SendEmailButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendEmailButton, ""));
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjSendEmailButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSendEmailButton, ""));
        LogCapture.info("Clicking on Send Email Button...");

    }

    @Then("^User is able to view Email Sent Successfully message$")
    public void userIsAbleToViewEmailSentSuccessfullyMessage() throws Exception {
        Constants.key.pause("4", "");
        String vobjEmailMessage = Constants.TitanCDSAPhase1OR.getProperty("EmailMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjEmailMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjEmailMessage, "visible"));
        LogCapture.info("Email Sent Successfully message is visible...");
    }

    @And("^User clicks on Fetch rates button for forward$")
    public void userClicksOnFetchRatesButtonForForward() throws Exception {
        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");
        String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValueCDSA");
        String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
        if (LiveRate == null) {
            LogCapture.info("Fetching rates.. Live Rate is Null...");
            Assert.fail();
        } else {
            LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
        }
        LogCapture.info("Rates fetched..");


    }


    @And("^User click on first record from FX tickets Queue page$")
    public void userClickOnFirstRecordFromFXTicketsQueuePage() throws Exception {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
        LogCapture.info("User is on FX tickets in Titan page..");

        String vobjFirstRecordFXticketsQueue = TitanFXTicketsOR.getProperty("FirstRecordFXticketsQueue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordFXticketsQueue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordFXticketsQueue, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

    }

    @Then("^User verify Actual profit and Tax amount field present on FX details page$")
    public void userVerifyActualProfitAndTaxAmountFieldPresentOnFXDetailsPage() throws Exception {

        Constants.key.pause("4", "");
        String vobjActualProfit = Constants.TitanFXTicketsOR.getProperty("FXActualProfit");
        String vobjActualProfitValue = Constants.TitanFXTicketsOR.getProperty("FXActualProfitValue");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjActualProfit, "visible"));
        String ActualProfitValue = Constants.driver.findElement(By.xpath(vobjActualProfitValue)).getText();
        LogCapture.info("User able to View Actual Profit = " + ActualProfitValue + " on FX Ticket details page");

        String vobjTaxAmount = Constants.TitanFXTicketsOR.getProperty("FXTaxAmount");
        String vobjTaxAmountValue = Constants.TitanFXTicketsOR.getProperty("FXTaxAmountValue");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjTaxAmount, "visible"));
        String TaxAmountValue = Constants.driver.findElement(By.xpath(vobjTaxAmountValue)).getText();
        LogCapture.info("User able to View Tax Amount =" + TaxAmountValue + " on FX Ticket details page");
    }

    @And("^User enter Client rate \"([^\"]*)\"$")
    public void userEnterClientRate(String ClientRate) throws Throwable {
        String vObjClientRate = Constants.CreateFxTicketOR.getProperty("ClientRate");
        Assert.assertEquals("PASS", Constants.key.click(vObjClientRate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjClientRate, ClientRate));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjClientRate, "enter"));
        Constants.key.pause("2", "");
        LogCapture.info("Client rate decimal entered is: " + ClientRate);

    }

    @And("^User enter Forward Client rate \"([^\"]*)\"$")
    public void userEnterForwardClientRate(String ClientRate) throws Throwable {
        String vObjForwardClientRate = Constants.CreateFxTicketOR.getProperty("ForwardClientRate");
        Assert.assertEquals("PASS", Constants.key.click(vObjForwardClientRate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardClientRate, ClientRate));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjForwardClientRate, "enter"));
        Constants.key.pause("2", "");
        LogCapture.info("Client rate decimal entered is: " + ClientRate);
    }


    @And("^User enters Add Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" and verify mandatory fields then click on Next button$")
    public void userEntersAddPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAndVerifyMandatoryFieldsThenClickOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country) throws Throwable {

        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
        String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
        String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
        String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Company Payee type is selected..");

            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);
        Constants.key.pause("3", "");

        String vObjLegalEntity = Constants.TitanPayeeOR.getProperty("LegalEntity");
        String LegalEntity = Constants.driver.findElement(By.xpath(vObjLegalEntity)).getText();

        if (LegalEntity.equals("TORAU") || LegalEntity.equals("CDINC")) {
            String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, "123456"));
            LogCapture.info("Payee Address Post Code: 200333 entered..");

            String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, "18dong"));
            LogCapture.info("Payee Address: 18dong entered..");

            String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, "Shanghai"));
            LogCapture.info("Payee Address: Shanghai entered..");
        }

        String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjFirstName));
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjLastName));
            LogCapture.info("Payee FirstName and Last Name Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified: Payee FirstName and Lastname field mandatory.");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName + " CNY"));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("4", "");
            LogCapture.info("User enters all mandatory fields on Payee details page...");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled: Verified all mandatory fields on 1/3 Payee details page...");
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjCompanyName));
            LogCapture.info("Company Name Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified: Payee Company Name field mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            LogCapture.info("User enters all mandatory fields on Payee details page...");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled: Verified all mandatory fields on 1/3 Payee details page...");
        }

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");
    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" BankCodeType\"([^\"]*)\" BankCode\"([^\"]*)\" and verify mandatory fields then click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberBankCodeTypeBankCodeAndVerifyMandatoryFieldsThenClickOnNextButton(String AccountNumber, String BankCodeType, String BankCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");
        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        String vObjIBANNumber = Constants.TitanPayeeOR.getProperty("IBANNumber");
        String vObjABANumber = Constants.TitanPayeeOR.getProperty("ABANumber");
        String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
        String vObjBankNameHeader = Constants.TitanPayeeOR.getProperty("BankNameHeader");
        String vObjPayeeBankDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnEnable");
        String vObjPayeeBankDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnDisable");


        if (AccountNumber.equalsIgnoreCase("IBAN")) {
            LogCapture.info("Account number NOT required but IBAN number for EUR required..");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIBANNumber, "ES9121000418450200051332"));
            LogCapture.info("IBAN number is entered..");

        } else {
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
            LogCapture.info("Account number is entered..");
        }
        if (BankCodeType.equalsIgnoreCase("ABA")) {
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjABANumber, BankCode));
            LogCapture.info("ABA number is entered..");
        }
        if (BankCodeType.equalsIgnoreCase("SWIFT")) {
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number is entered..");
        }

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");

        if (AccountNumber.equalsIgnoreCase("IBAN")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjIBANNumber, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjIBANNumber));
            LogCapture.info("Payee IBAN Number Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified IBAN number is mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIBANNumber, "ES9121000418450200051332"));
            Constants.key.pause("1", "");
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjAccountNumber));
            LogCapture.info("Payee Account Number Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified Account number fields is mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
            Constants.key.pause("1", "");
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjSWIFTCode));
        LogCapture.info("Payee Swift Code Cleared ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified Swift code field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");

        LogCapture.info("User enters all mandatory fields on 2/3 Payee Bank details page... ");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified: Payee Account Number and Swift code field is mandatory...");

        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^User enters Add Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" and verify mandatory fields for Etailer then click on Next button$")
    public void userEntersAddPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAndVerifyMandatoryFieldsForEtailerThenClickOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country) throws Throwable {

        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
        String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
        String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
        String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Company Payee type is selected..");

            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }

        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);
        Constants.key.pause("3", "");

        String vObjCountryCode = Constants.TitanPayeeOR.getProperty("PayeeCountryCode");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountryCode, "+86"));
        LogCapture.info("Payee Country Code: +86 is entered");
        String vObjPhoneNumber = Constants.TitanPayeeOR.getProperty("PayeePhoneNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPhoneNumber, "13910998888"));
        LogCapture.info("Payee Phone Numner: 13910998888 is entered");

        String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjFirstName));
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjLastName));
            LogCapture.info("Payee FirstName and Last Name Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified Payee FirstName and Lastname field mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName + " CNY"));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjCompanyName));
            LogCapture.info("Company Name Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified: Payee Company Name field mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("1", "");
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjCountryCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjCountryCode));
        Assert.assertEquals("PASS", Constants.key.click(vObjPhoneNumber, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPhoneNumber));
        LogCapture.info("Payee CountryCode and Phone Number Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee CountryCode and Phone Number field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountryCode, "+84"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPhoneNumber, "13910998888"));
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User enters all mandatory fields on payee details page...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified all mandatory field on payee details page 1/3...");

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");
    }


    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" ResidentialID\"([^\"]*)\" Name In Local LanguageCode\"([^\"]*)\" CNAP code \"([^\"]*)\" Swift Code \"([^\"]*)\" and verify mandatory fields then click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberResidentialIDNameInLocalLanguageCodeCNAPCodeSwiftCodeAndVerifyMandatoryFieldsThenClickOnNextButton(String AccountNumber, String FFCDetails, String NameInLocalLang, String CNAP, String SwiftCode) throws Throwable {

        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        LogCapture.info("Account number is entered..");

        String vObjFFCDetails = Constants.TitanPayeeOR.getProperty("FFCDetails");
        Assert.assertEquals("PASS", Constants.key.click(vObjFFCDetails, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFFCDetails, FFCDetails));
        LogCapture.info("FFC details(Residential ID) is entered..");

        String vObjNameinLocalLanguage = Constants.TitanPayeeOR.getProperty("NameinLocalLanguage");
        Assert.assertEquals("PASS", Constants.key.click(vObjNameinLocalLanguage, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameinLocalLanguage, NameInLocalLang));
        LogCapture.info("Name in local language is entered..");

        String vObjCNAPCode = Constants.TitanPayeeOR.getProperty("CNAPCode");
        Assert.assertEquals("PASS", Constants.key.click(vObjCNAPCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCNAPCode, CNAP));
        LogCapture.info("CNAP Code is entered..");

        String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SwiftCode));
        LogCapture.info("SWIFT number is entered..");

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");

        String vObjBankNameHeader = Constants.TitanPayeeOR.getProperty("BankNameHeader");
        String vObjPayeeBankDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnEnable");
        String vObjPayeeBankDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnDisable");

        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAccountNumber));
        LogCapture.info("Payee Account Number Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee Account Number field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjFFCDetails, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjFFCDetails));
        LogCapture.info("FFC (Residential ID) Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee FFC (Residential ID) field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFFCDetails, FFCDetails));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjNameinLocalLanguage, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjNameinLocalLanguage));
        LogCapture.info("Name in local language is Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee Name in local language field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameinLocalLanguage, NameInLocalLang));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjCNAPCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjCNAPCode));
        LogCapture.info("CNAP Code is Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee CNAP Code field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCNAPCode, CNAP));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjSWIFTCode));
        LogCapture.info("Payee Swift Code Cleared ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Swift Code  field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SwiftCode));
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("1", "");

        LogCapture.info("User enters all mandatory fields on Bank details Page");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified: all mandatory fields on Bank details page...");

        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^User enters Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" Address\"([^\"]*)\" Town\"([^\"]*)\" Postcode\"([^\"]*)\" and verify mandatory fields for NonEtailer then click on Next button$")
    public void userEntersPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAddressTownPostcodeAndVerifyMandatoryFieldsForNonEtailerThenClickOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country, String Address, String Town, String Postcode) throws Throwable {

        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
        String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
        String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
        String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("Payee First Name: " + FirstName + " entered..");

            PayeeLastName = LastName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Payee Last Name: " + LastName + " entered..");
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Company Payee type is selected..");

            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Payee Company Name entered..");
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);
        Constants.key.pause("2", "");

        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
        LogCapture.info("Payee Address Post Code: " + Postcode + " entered..");

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
        LogCapture.info("Payee Address: " + Address + " entered..");

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
        LogCapture.info("Payee Town: " + Town + " entered..");

        String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjFirstName));
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjLastName));
            LogCapture.info("Payee FirstName and Last Name Removed ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified: Payee FirstName and Lastname field mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName + " CNY"));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("1", "");
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjCompanyName));
            LogCapture.info("Company Name Removed ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("1", "");
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAddressPostCodeField));
        LogCapture.info("Payee Post Code field removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee PostCode Field mandatory.....");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeAddressField));
        LogCapture.info("Payee Address field removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee Address Field mandatory....");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeTownField));
        LogCapture.info("Payee Town field removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button disabled: Verified: Payee Town Field mandatory.....");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        LogCapture.info("User enters all mandatory fields on Payee details page...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified all mandatory fields...");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" Purpose code \"([^\"]*)\" Swift Code \"([^\"]*)\" and verify mandatory fields then click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberPurposeCodeSwiftCodeAndVerifyMandatoryFieldsThenClickOnNextButton(String AccountNumber, String PurposeCode, String SwiftCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        LogCapture.info("Account number is entered..");

        String vObjPurposeCode = Constants.TitanPayeeOR.getProperty("PurposeCode");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeCode, PurposeCode));
        LogCapture.info("Purpose Code is entered..");

        String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SwiftCode));
        LogCapture.info("SWIFT number is entered..");

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");

        String vObjBankNameHeader = Constants.TitanPayeeOR.getProperty("BankNameHeader");
        String vObjPayeeBankDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnEnable");
        String vObjPayeeBankDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnDisable");

        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAccountNumber));
        LogCapture.info("Payee Account Number Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified Payee Account Number field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));

        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPurposeCode));
        LogCapture.info("Purpose Code is Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified Payee Purpose Code field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeCode, PurposeCode));

        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjSWIFTCode));
        LogCapture.info("Payee Swift Code Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified Swift Code  field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SwiftCode));
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));

        LogCapture.info("User enters all mandatory fields on Bank details page...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified: all mandatory fields on 2/3 Bank details page...");

        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }


    @And("^User navigate to search result and click on (INPROCESS|AWAITINGBANKAPPROVAL|APPROVED|PARTIALLYAPPROVED|CANCELLED) Payment out record$")
    public void userNavigateToSearchResultAndClickOnINPROCESSPaymentOutRecord(String PayOutStatus) throws Exception {

        Thread.sleep(2000);
            for (int i = 1; i <= 50; i++) {
                String vObjPayOutStatus = "//table[@id='tbl-funds-out']//tbody//tr[" + i + "]//td[10]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayOutStatus, ""));
                String PaymentOutStatus = Constants.key.getText(vObjPayOutStatus, "");

                if (PaymentOutStatus.equals(PayOutStatus)) {
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayOutStatus, ""));
                    LogCapture.info("User navigate to " + PaymentOutStatus + " Payment Out Record");
                    break;
                }
            }
    }

    @Then("^User navigate to Payment out details page$")
    public void userNavigateToPaymentOutDetailsPage() throws Exception {

        String vobjPaymentOutHeader = Constants.TitanPaymentOutOR.getProperty("PaymentOutHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentOutHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPaymentOutHeader, "visible"));

        String vObjPaymentOutStatus = TitanPaymentOutOR.getProperty("PaymentOutStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutStatus, ""));
 //       Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentOutStatus, "visible"));
        String ActualPayOutStatus = Constants.key.getText(vObjPaymentOutStatus, "");
        LogCapture.info("Payment Out Status " + ActualPayOutStatus + " Verified");

        String vobjPayOutPayeeName = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutPayeeName, "visible"));
        String PayeeName = Constants.key.getText(vobjPayOutPayeeName, "");
        LogCapture.info("User able to View Payee Name = " + PayeeName + " on PaymentOut Customers details page");

    }

    @Then("^User click on Add Memo and verify Delete Payment button is (Enable|Disable)$")
    public void userClickOnAddMemoAndVerifyDeletePaymentButtonIsEnable(String Button) throws Exception {

        String vobjAddMemoLink= TitanPaymentOutOR.getProperty("AddMemoLink");
        Assert.assertEquals("PASS", key.navigateSubMenu(vobjAddMemoLink, ""));
        String vobjMemoHeader= TitanPaymentOutOR.getProperty("MemoHeader");
        LogCapture.info("Clicking on Add Memo Link.....");

        if(Button.equals("Enable"))
        {
            Assert.assertEquals("PASS", key.VisibleConditionWait(vobjMemoHeader, ""));
            Assert.assertEquals("PASS", key.verifyElementProperties(vobjMemoHeader, "visible"));
            LogCapture.info("Memo PopUp Header is visible");

            String vobjAddMemoTextArea= TitanPaymentOutOR.getProperty("AddMemoTextArea");
            String vobjAddMemoButton= TitanPaymentOutOR.getProperty("AddMemoButton");
            Assert.assertEquals("PASS", key.writeInInput(vobjAddMemoTextArea, "Wrong Payment Out Allocation"));
            Assert.assertEquals("PASS", key.click(vobjAddMemoButton, ""));
            LogCapture.info("User Add Memo note and Click on Add Memo Button");

            String vobjDeletePaymentEnable= TitanPaymentOutOR.getProperty("DeletePaymentEnable");
            Assert.assertEquals("PASS", key.verifyElementProperties(vobjDeletePaymentEnable, "enabled"));
            Assert.assertEquals("PASS", key.click(vobjDeletePaymentEnable, ""));
            LogCapture.info("User Verify Delete Payment Button is Enable and Click on Delete Payment...");

            String vobjDeletePaymentYes= TitanPaymentOutOR.getProperty("DeletePaymentYes");
            Assert.assertEquals("PASS", key.navigateSubMenu(vobjDeletePaymentYes, ""));
            LogCapture.info("User Click on delete Payment => Yes .....");

            String vobjPaymentDeletedSuccessfully= TitanPaymentOutOR.getProperty("PaymentDeletedSuccessfully");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vobjPaymentDeletedSuccessfully, ""));
            Assert.assertEquals("PASS", key.verifyElementProperties(vobjPaymentDeletedSuccessfully, "visible"));
            String PaymentDeletedSuccessfullyMSG = key.getText(vobjPaymentDeletedSuccessfully, "");
            LogCapture.info("User able to see <"+PaymentDeletedSuccessfullyMSG+ "> Message....");

        } else if(Button.equals("Disable"))
        {
            String vobjDeletePaymentDisable= TitanPaymentOutOR.getProperty("DeletePaymentDisable");
            String Dis = driver.findElement(By.xpath(vobjDeletePaymentDisable)).getAttribute("class");
            if(Dis.contains("disabled"))
            {
                LogCapture.info("User Verify Delete Payment Button is Disable and unable to delete Payment...");
                Assert.assertEquals("PASS","PASS");
            }else {
                LogCapture.info("TC Failed >> Delete Payment Button is Enabled..");
                Assert.assertEquals("PASS","FAIL");
            }
        }
    }

    @Then("^User verify if the Method is (BACS/CHAPS/TT|RETURN_OF_FUNDS|CHEQUE/DRAFT|WALLET|DEBIT_CARD) and Titan Status is Funded$")
    public void userVerifyIfTheMethodIsBACSCHAPSTTAndTitanStatusIsFunded(String Method) throws Exception {

        if(Method.equals("RETURN_OF_FUNDS"))
        {
            for(int i = 1;i<=50; i++)
            {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if(PauymentMode.equals("RETURN_OF_FUNDS") && TitanStatus.equals("FUNDED"))
                {
                    LogCapture.info("User verify ModeOfPayment As RETURN_OF_FUNDS and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        }else if (Method.equals("BACS/CHAPS/TT"))
        {
            for(int i = 1;i<=50; i++)
            {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if(PauymentMode.equals("BACS/CHAPS/TT") && TitanStatus.equals("FUNDED"))
                {
                    LogCapture.info("User verify ModeOfPayment As BACS/CHAPS/TT and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        }else if (Method.equals("WALLET"))
        {
            for(int i = 1;i<=50; i++)
            {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if(PauymentMode.equals("WALLET") && TitanStatus.equals("FUNDED"))
                {
                    LogCapture.info("User verify ModeOfPayment As WALLET and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        }else if (Method.equals("CHEQUE/DRAFT"))
        {
            for(int i = 1;i<=50; i++)
            {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if(PauymentMode.equals("CHEQUE/DRAFT") && TitanStatus.equals("FUNDED"))
                {
                    LogCapture.info("User verify ModeOfPayment As CHEQUE/DRAFT and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        }else if (Method.equals("DEBIT_CARD"))
        {
            for(int i = 1;i<=50; i++)
            {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if(PauymentMode.equals("DEBIT_CARD") && TitanStatus.equals("FUNDED"))
                {
                    LogCapture.info("User verify ModeOfPayment As DEBIT_CARD and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        }

    }

    @And("^User Click on Payment in Button$")
    public void userClickOnPaymentInButton() throws Exception {
        LogCapture.info("User clicking On Payment in Button");
        String VobjPaymentInButton = Constants.TitanCustomersOR.getProperty("PaymentInBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjPaymentInButton, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User Clicked on Payment In Button.. ");
    }

    @Then("^User verify release button (Enable|Disable)$")
    public void userVerifyReleaseButtonEnable(String Button) throws Exception {

        LogCapture.info("User is on Incoming Funds profile page... ");
        String VobjIncomingFundsProfile=Constants.TitanCustomersOR.getProperty("IncomingFundsProfile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VobjIncomingFundsProfile, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjIncomingFundsProfile, "visible"));

        LogCapture.info("User Verifying Release button is "+Button+"... ");
        String VobjReleaseButton=Constants.TitanCustomersOR.getProperty("ReleaseButton");
        if(Button.equals("Enable"))
        {
            String Dis = driver.findElement(By.xpath(VobjReleaseButton)).getAttribute("class");
            if(Dis.contains("disabled"))
            {
                LogCapture.info("TC Failed >> Release Payment Button is Disabled..");
                Assert.assertEquals("PASS","FAIL");
            }else {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjReleaseButton, ""));
                String VobjReleaseCancel=Constants.TitanCustomersOR.getProperty("ReleaseCancel");
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjReleaseCancel, ""));
                LogCapture.info("User Verify release Button is Enable and able to release Payment...");
                Assert.assertEquals("PASS","PASS");
            }
        }else if(Button.equals("Disable"))
        {
            String Dis = driver.findElement(By.xpath(VobjReleaseButton)).getAttribute("class");
            if(Dis.contains("disabled"))
            {
                LogCapture.info("User Verify release Button is Diasable and unable to release Payment...");
                Assert.assertEquals("PASS","PASS");
            }else {
                LogCapture.info("TC Failed >> Release Payment Button is Enable..");
                Assert.assertEquals("PASS","FAIL");
            }
        }
    }

    @Then("^User verify Release & Re-allocate button is button (Enable|Disable)$")
    public void userVerifyReleaseReAllocateButtonIsButtonEnable(String Button) throws Exception {

        LogCapture.info("User is on Incoming Funds profile page... ");
        String VobjIncomingFundsProfile=Constants.TitanCustomersOR.getProperty("IncomingFundsProfile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VobjIncomingFundsProfile, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjIncomingFundsProfile, "visible"));

        LogCapture.info("User Verifying Release & Reallocate button is "+Button+"... ");
        String VobjReallocateButton=Constants.TitanCustomersOR.getProperty("ReallocateButton");
        if(Button.equals("Enable"))
        {
            String Dis = driver.findElement(By.xpath(VobjReallocateButton)).getAttribute("class");
            if(Dis.contains("disabled"))
            {
                LogCapture.info("TC Failed >> Release Payment Button is Disabled..");
                Assert.assertEquals("PASS","FAIL");
            }else {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjReallocateButton, ""));
                LogCapture.info("User Verify Release & Re-allocate button is Enable and able to click on re-allocate button...");
                Assert.assertEquals("PASS","PASS");
            }
        }else if(Button.equals("Disable"))
        {
            String Dis = driver.findElement(By.xpath(VobjReallocateButton)).getAttribute("class");
            if(Dis.contains("disabled"))
            {
                LogCapture.info("User Verify release Button is Diasable and unable to release Payment...");
                Assert.assertEquals("PASS","PASS");
            }else {
                LogCapture.info("TC Failed >> Release Payment Button is Enable..");
                Assert.assertEquals("PASS","FAIL");
            }
        }
    }

    @And("^User enter Mandatory details \"([^\"]*)\" on transfer to client page$")
    public void userEnterMandatoryDetailsOnTransferToClientPage(String CreditorNumber) throws Throwable {

        String VobjTransferButtonDisable=Constants.TitanCustomersOR.getProperty("MakeTransferButtonDisable");
        String VobjTransferButtonEnable=Constants.TitanCustomersOR.getProperty("MakeTransferButtonDisable");
        String VobjTransferToClient=Constants.TitanCustomersOR.getProperty("TransferToClient");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VobjTransferToClient, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferToClient, "visible"));
        LogCapture.info("User is on Transfer to client page..");

        String VobjClientNumber=Constants.TitanCustomersOR.getProperty("ClientNumber");
        Assert.assertEquals("PASS", Constants.key.click(VobjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjClientNumber, CreditorNumber));

        String VobjTransferNote=Constants.TitanCustomersOR.getProperty("TransferNote");
        Assert.assertEquals("PASS", Constants.key.click(VobjTransferNote, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjTransferNote, "Testing Funds In"));

        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferButtonDisable, "visible"));
        LogCapture.info("Make Transfer button is disabled: Verified Transfer reason is mandatory...");

        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjTransferNote, "Testing_funds"));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(VobjTransferNote, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(VobjTransferNote, "enter"));
        LogCapture.info("Transfer reason Testing Funds is selected..");

        Assert.assertEquals("PASS", Constants.key.click(VobjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(VobjClientNumber));
        LogCapture.info("Client Number Cleared ..");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferButtonDisable, "visible"));
        LogCapture.info("Make Transfer button is disabled: Verified Client Number is mandatory...");

        Assert.assertEquals("PASS", Constants.key.click(VobjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjClientNumber, CreditorNumber));

        Assert.assertEquals("PASS", Constants.key.click(VobjTransferNote, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(VobjTransferNote));
        LogCapture.info("Transfer note Cleared ..");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferButtonDisable, "visible"));
        LogCapture.info("Make Transfer button is disabled: Verified Transfer note is mandatory...");

        Assert.assertEquals("PASS", Constants.key.click(VobjTransferNote, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjTransferNote, "Testing Funds In"));
        LogCapture.info("User enter all mandatory details...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferButtonEnable, "visible"));
        LogCapture.info("User verify : Make Transfer button is Enable and able to re-allocate...");

    }

    @Given("^User Triggers API to generate token$")
    public void userTriggersAPIToGenerateToken() {

        String response = "";
        String body = "grant_type=password&client_id=auth_token_service&username=qa.user&password=apollo13&client_secret=50de58c1-c815-474f-b737-525f95ebf2c6";
        RestAssured.baseURI = "https://uatsso.currenciesdirect.com/auth/realms/cd-internal/protocol/openid-connect/token";

        HashMap m = new HashMap();
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Content-Type", "application/x-www-form-urlencoded");
        m.put("Accept-Encoding", "gzip, deflate");
        m.put("Accept-Language", "en-US,en;q=0.8");
        m.put("Accept", "application/x-www-form-urlencoded");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();

        JsonPath jp = Constants.key.rawToJason(response);
        Constants.ACCESS_TOKEN = jp.get("access_token");
    }

    @Then("^User triggers get balance API for customer \"([^\"]*)\" and currency \"([^\"]*)\" then verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersGetBalanceAPIForCustomerAndCurrencyThenVerify(String CustReferenceTAN, String CCY, String ResponseCode, String ResponseDescription) throws Throwable {
        String response = "";

        String body = "{ \n" +
                "    \"eventId\": \"fc958869-5f34-475b-b311-eac338a0d84f\",\n" +
                "    \"cdCustomerRef\": \""+CustReferenceTAN+"\",\n" +
                "    \"baseCurrency\": \""+CCY+"\"\n" +
                "}\n";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/getBalance";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.31.3");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        String RespActBal = Float.toString(jp.get("actualBalance"));
        String RespAvailBal = Float.toString(jp.get("availableBalance"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("currency"),  CCY);
        LogCapture.info("User verified Currency as >> "+jp.get("currency"));

        LogCapture.info("Able to see Actual balance >> "+RespActBal);
        LogCapture.info("Able to see Available balance >> "+RespAvailBal);

    }


    @Then("^User triggers request to Block amount for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and amount \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersRequestToBlockAmountForCustomerWithCurrencyAndAmountAndVerify(String CustReferenceTAN, String CYY, String Amount, String ResponseCode, String ResponseDescription) throws Throwable {

        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "AUTO-29451258-SAU100997RABH";

        String body ="{\n" +
                "   \"source_application\":\"Card\",\n" +
                "   \"eventId\":\"fc958869-5f34-475b-b311-eac338a0d84f\",\n" +
                "   \"cdCustomerRef\":\""+CustReferenceTAN+"\",\n" +
                "   \"cdPaymentLifecycleId\":\""+PamentLifeCycleID+"\",\n" +
                "   \"amountToBlock\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\"GBP\"\n" +
                "   },\n" +
                "   \"transactionDetails\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\"GBP\"\n" +
                "   },\n" +
                "   \"billingDetails\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\"GBP\"\n" +
                "   },\n" +
                "   \"isAllowedPartialBlock\":true,\n" +
                "   \"baseCurrency\":\"GBP\",\n" +
                "   \"merchantName\":\"Bananarama Fan Club\",\n" +
                "   \"merchantAddress\":\"Morden, SM4 6AP, United Kingdom\",\n" +
                "   \"txnDescription\":\"Golff Harmelen HARMELEN NLD\",\n" +
                "   \"txnType\":\"spent\",\n" +
                "   \"txnCategory\":\"spent\",\n" +
                "   \"authMethod\":\"Contactless\",\n" +
                "   \"purchaseCategory\":\"Groceries\",\n" +
                "   \"txnDate\":\""+currentDate+"\",\n" +
                "   \"merchantGpsData\":{\n" +
                "      \"gpsPosData\":\"gps-pos-fc958869-5f34-475b\",\n" +
                "      \"cardToken\":\"fc958869-5f34\",\n" +
                "      \"cardPresent\":\"0\",\n" +
                "      \"cardPresentDesc\":\"master card\",\n" +
                "      \"merchCountry\":\"Japan\",\n" +
                "      \"merchPostcode\":\"JI00968958982\",\n" +
                "      \"merchRegion\":\"asia\",\n" +
                "      \"merchCity\":\"tokyo\",\n" +
                "      \"mccCode\":\"Groceries\",\n" +
                "      \"bin\":\"199709\",\n" +
                "      \"gpsTxnId \":\"gps-00018\",\n" +
                "      \"productId\":\"098158\",\n" +
                "      \"txnCountry\":\"london\",\n" +
                "      \"preAuthSeq\":\"pre-AuthSeq\",\n" +
                "      \"preAuthTotalParts\":\"preAuth-TotalParts\",\n" +
                "      \"preAuthMultiPartInd\":\"0\",\n" +
                "      \"preAuthMultiPartFinal\":\"0\",\n" +
                "      \"preAuthMatchingReference\":\"Reference-fc958869\",\n" +
                "      \"billAmountApprove\":10,\n" +
                "      \"addtnlAmountType\":\"cash-back\",\n" +
                "      \"addtnlAmountCcy\":\""+CYY+"\",\n" +
                "      \"addtnlAmount\":10,\n" +
                "      \"consolidatedWalletBalances\":10,\n" +
                "      \"merchID\":\"merch-ID-001\",\n" +
                "      \"merchantNameOther\":\"smith\",\n" +
                "      \"mccCodeDescription\":\"mccCode-Description\",\n" +
                "      \"merchantContact\":\"12947074902\",\n" +
                "      \"merchantSecondContact\":\"merchant@gmail\",\n" +
                "      \"merchantWebsite\":\"www.merchant-Website\",\n" +
                "      \"acquirerId\":\"acquirer-001\",\n" +
                "      \"acqDatestamp\":\""+currentDate+"\",\n" +
                "      \"gpsDecisionCode\":\"gps-000\",\n" +
                "      \"gpsDecisionCodeDescription\":\"gpsDecision-success\",\n" +
                "      \"gpsDeclineDescription\":\"gpsDecline-success\",\n" +
                "      \"cardStatusCode\":\"000\",\n" +
                "      \"gpsStipFlag\":\"Y\",\n" +
                "      \"avsResult\":\"avs-Result\",\n" +
                "      \"scaAuthenticationExemption\":\"scaAuthentication-Exemption\",\n" +
                "      \"authenticationMethod\":\"2\",\n" +
                "      \"authenticationMethodDesc\":\"authentication-MethodDesc\",\n" +
                "      \"cvvResults\":\"cvv-Results\",\n" +
                "      \"continent\":\"Europe\",\n" +
                "      \"longitude\":\"longitude-36.762768\",\n" +
                "      \"latitiude\":\"latitiude-30.762768\",\n" +
                "      \"region\":\"Europe\",\n" +
                "      \"city\":\"London\",\n" +
                "      \"timezone\":\"Pacific time\",\n" +
                "      \"organization\":\"G-2020\",\n" +
                "      \"carrier\":\"carrier\",\n" +
                "      \"connectionType\":\"connection-Type\",\n" +
                "      \"lineSpeed\":\"line-Speed\",\n" +
                "      \"ipRoutingType\":\"ipRouting-Type\",\n" +
                "      \"countryName\":\"UK\",\n" +
                "      \"countryCode\":\"UK-007\",\n" +
                "      \"stateName\":\"california\",\n" +
                "      \"stateCode\":\"CA-001\",\n" +
                "      \"postalCode\":\"0090912CL\",\n" +
                "      \"areaCode\":\"0090912CL\",\n" +
                "      \"anonymizerStatus\":\"anonymize-Success\",\n" +
                "      \"ipAddress\":\"20.23.04.03\",\n" +
                "      \"updateStatus\":\"update-Status\",\n" +
                "      \"dateUpdate\":\""+currentDate+"\",\n" +
                "      \"chargebackReason\":\"chargeback-Reason\",\n" +
                "      \"disputeCondition\":\"dispute-Condition\",\n" +
                "      \"posTerminal\":\"pos-Terminal\",\n" +
                "      \"posDatestamp\":\""+currentDate+"\",\n" +
                "      \"gpsPosCapability\":\"gpsPos-Capability\",\n" +
                "      \"deviceId\":\"G00DAutoDev793h\"\n" +
                "   },\n" +
                "   \"fee\":[\n" +
                "      {\n" +
                "         \"type\":\"atm\",\n" +
                "         \"amount\":0.00,\n" +
                "         \"currency\":\""+CYY+"\",\n" +
                "         \"description\":\"ATM Fee\"\n" +
                "      },\n" +
                "      {\n" +
                "         \"type\":\"crossborder\",\n" +
                "         \"amount\":0.00,\n" +
                "         \"currency\":\""+CYY+"\",\n" +
                "         \"description\":\"2% crossborder\"\n" +
                "      }\n" +
                "   ]\n" +
                "}";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/block";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("User-Agent", "PostmanRuntime/7.31.3");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        String RespDescription = jp.get("response_description");
        String Respsucceed = Boolean.toString(jp.get("succeed"));
        String RespAvailBal = Float.toString(jp.get("balance.actualBalance"));
        String Currency = jp.get("balance.currency");
        DecimalFormat def=new DecimalFormat("0.0000");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("blockedAmount.currency"),  CYY);
        LogCapture.info("User verified Currency as >> "+jp.get("blockedAmount.currency"));

        Assert.assertEquals(BlocekAmt,  Amount);
        LogCapture.info("Able to see Available balance >> "+BlocekAmt);

    }

    @Then("^User triggers request to Unblock amount for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and amount \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersRequestToUnblockAmountForCustomerWithCurrencyAndAmountAndVerify(String CustReferenceTAN, String CCY, String Amount, String ResponseCode, String ResponseDescription) throws Throwable {

        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "AUTO-29451258-SAU100997RABH";

        String body ="{\n" +
                "   \"eventId\":\"fc958869-5f34-475b-b311-eac338a0d84f\",\n" +
                "   \"cdCustomerRef\":\""+CustReferenceTAN+"\",\n" +
                "   \"cdPaymentLifecycleId\":\""+PamentLifeCycleID+"\",\n" +
                "   \"baseCurrency\":\""+CCY+"\",\n" +
                "   \"txnDescription\":\"Golff Harmelen HARMELEN NLD\",\n" +
                "   \"authMethod\":\"Contactless\",\n" +
                "   \"purchaseCategory\":\"Groceries\",\n" +
                "   \"merchantGpsData\":{\n" +
                "      \"gpsPosData\":\"gps-pos-fc958869-5f34-475b\",\n" +
                "      \"cardToken\":\"fc958869-5f34\",\n" +
                "      \"cardPresent\":\"0\",\n" +
                "      \"cardPresentDesc\":\"master card\",\n" +
                "      \"merchCountry\":\"Japan\",\n" +
                "      \"merchPostcode\":\"JI00968958982\",\n" +
                "      \"merchRegion\":\"asia\",\n" +
                "      \"merchCity\":\"tokyo\",\n" +
                "      \"mccCode\":\"Groceries\",\n" +
                "      \"bin\":\"bin\",\n" +
                "      \"gpsTxnId \":\"gps-00018\",\n" +
                "      \"productId\":\"098158\",\n" +
                "      \"txnCountry\":\"london\",\n" +
                "      \"preAuthSeq\":\"pre-AuthSeq\",\n" +
                "      \"preAuthTotalParts\":\"preAuth-TotalParts\",\n" +
                "      \"preAuthMultiPartInd\":\"0\",\n" +
                "      \"preAuthMultiPartFinal\":\"0\",\n" +
                "      \"preAuthMatchingReference\":\"Reference-fc958869\",\n" +
                "      \"billAmountApprove\":12,\n" +
                "      \"addtnlAmountType\":\"cash-back\",\n" +
                "      \"addtnlAmountCcy\":\""+CCY+"\",\n" +
                "      \"addtnlAmount\":12,\n" +
                "      \"consolidatedWalletBalances\":10,\n" +
                "      \"merchID\":\"merch-ID-001\",\n" +
                "      \"merchantNameOther\":\"smith\",\n" +
                "      \"mccCodeDescription\":\"mccCode-Description\",\n" +
                "      \"merchantContact\":\"12947074902\",\n" +
                "      \"merchantSecondContact\":\"merchant@gmail\",\n" +
                "      \"merchantWebsite\":\"www.merchant-Website\",\n" +
                "      \"acquirerId\":\"acquirer-001\",\n" +
                "      \"acqDatestamp\":\""+currentDate+"\",\n" +
                "      \"gpsDecisionCode\":\"gps-000\",\n" +
                "      \"gpsDecisionCodeDescription\":\"gpsDecision-success\",\n" +
                "      \"gpsDeclineDescription\":\"gpsDecline-success\",\n" +
                "      \"cardStatusCode\":\"000\",\n" +
                "      \"gpsStipFlag\":\"Y\",\n" +
                "      \"avsResult\":\"avs-Result\",\n" +
                "      \"scaAuthenticationExemption\":\"scaAuthentication-Exemption\",\n" +
                "      \"authenticationMethod\":\"authentication-Method\",\n" +
                "      \"authenticationMethodDesc\":\"authentication-MethodDesc\",\n" +
                "      \"cvvResults\":\"cvv-Results\",\n" +
                "      \"continent\":\"Europe\",\n" +
                "      \"longitude\":\"longitude-36.762768\",\n" +
                "      \"latitiude\":\"latitiude-30.762768\",\n" +
                "      \"region\":\"Europe\",\n" +
                "      \"city\":\"London\",\n" +
                "      \"timezone\":\"Pacific time\",\n" +
                "      \"organization\":\"G-2020\",\n" +
                "      \"carrier\":\"carrier\",\n" +
                "      \"connectionType\":\"connection-Type\",\n" +
                "      \"lineSpeed\":\"line-Speed\",\n" +
                "      \"ipRoutingType\":\"ipRouting-Type\",\n" +
                "      \"countryName\":\"UK\",\n" +
                "      \"countryCode\":\"UK-007\",\n" +
                "      \"stateName\":\"california\",\n" +
                "      \"stateCode\":\"CA-001\",\n" +
                "      \"postalCode\":\"0090912CL\",\n" +
                "      \"areaCode\":\"0090912CL\",\n" +
                "      \"anonymizerStatus\":\"anonymize-Success\",\n" +
                "      \"ipAddress\":\"13.11.30.00\",\n" +
                "      \"updateStatus\":\"update-Status\",\n" +
                "      \"dateUpdate\":\""+currentDate+"\",\n" +
                "      \"chargebackReason\":\"chargeback-Reason\",\n" +
                "      \"disputeCondition\":\"dispute-Condition\",\n" +
                "      \"posTerminal\":\"pos-Terminal\",\n" +
                "      \"posDatestamp\":\""+currentDate+"\",\n" +
                "      \"gpsPosCapability\":\"gpsPos-Capability\",\n" +
                "      \"deviceId\":\"GDU808id0de793h\"\n" +
                "   }\n" +
                "}";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/unBlock";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        String RespDescription = jp.get("response_description");
 //       String Respsucceed = Boolean.toString(jp.get("succeed"));
        String RespAvailBal = Float.toString(jp.get("balance.actualBalance"));
        String Currency = jp.get("balance.currency");
        DecimalFormat def=new DecimalFormat("0.00");
        String UnblocekAmt =def.format(jp.get("unblockedAmount.amount"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("unblockedAmount.currency"),  CCY);
        LogCapture.info("User verified Unblocked Amount Currency as >> "+jp.get("unblockedAmount.currency"));

        Assert.assertEquals(UnblocekAmt,  Amount);
        LogCapture.info("User verified Unblocked amount as >> "+UnblocekAmt);

        LogCapture.info("User verified Actual Balance as >> "+jp.get("balance.actualBalance")+CCY);
        LogCapture.info("User verified Available Balance as >> "+jp.get("balance.availableBalance")+CCY);

    }


    @Then("^User triggers request to Check And Block amount for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and amount \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersRequestToCheckAndBlockAmountForCustomerWithCurrencyAndAmountAndVerify(String CustReferenceTAN, String CCY, String Amount, String ResponseCode, String ResponseDescription) throws Throwable {

        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "AUTO-20159568-SAU091097RABH";

        String body ="{\n" +
                "\"eventId\": \"fc958869-5f34-475b-b311-eac338a0d84f\",\n" +
                "\"cdCustomerRef\": \""+CustReferenceTAN+"\",\n" +
                "\"cdPaymentLifecycleId\": \""+PamentLifeCycleID+"\",\n" +
                "\"amountToBlock\": {\n" +
                "\"amount\": \""+Amount+"\",\n" +
                "\"currency\": \""+CCY+"\"\n" +
                "},\n" +
                "\"transactionDetails\": {\n" +
                "\"amount\": \""+Amount+"\",\n" +
                "\"currency\": \""+CCY+"\"\n" +
                "},\n" +
                "\"billingDetails\": {\n" +
                "\"amount\": \""+Amount+"\",\n" +
                "\"currency\": \""+CCY+"\"\n" +
                "},\n" +
                "\"isAllowedPartialBlock\": true,\n" +
                "\"baseCurrency\": \""+CCY+"\",\n" +
                "\"merchantName\": \"Bananarama Fan Club\",\n" +
                "\"merchantAddress\": \"Morden, SM4 6AP, United Kingdom\",\n" +
                "\"txnDescription\": \"Golff Harmelen HARMELEN NLD\",\n" +
                "\"txnType\": \"spent\",\n" +
                "\"authMethod\": \"Contactless\",\n" +
                "\"purchaseCategory\": \"Groceries\",\n" +
                "\"txnDate\": \""+currentDate+"\",\n" +
                "\"fee\": [\n" +
                "{\n" +
                "\"type\": \"atm\",\n" +
                "\"amount\": 0.00,\n" +
                "\"currency\": \""+Amount+"\",\n" +
                "\"description\": \"ATM Fee\"\n" +
                "},\n" +
                "{\n" +
                "\"type\": \"crossborder\",\n" +
                "\"amount\": 0.0,\n" +
                "\"currency\": \""+Amount+"\",\n" +
                "\"description\": \"2% crossborder\"\n" +
                "}\n" +
                "]\n" +
                "}\n";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/checkAndBlock";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("User-Agent", "PostmanRuntime/7.31.3");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        String RespDescription = jp.get("response_description");
        String Respsucceed = Boolean.toString(jp.get("succeed"));
        String RespAvailBal = Float.toString(jp.get("balance.actualBalance"));
        String Currency = jp.get("balance.currency");
        DecimalFormat def=new DecimalFormat("0.0000");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("blockedAmount.currency"),  CCY);
        LogCapture.info("User verified blocked Amount Currency as >> "+jp.get("blockedAmount.currency"));

        Assert.assertEquals(BlocekAmt,  Amount);
        LogCapture.info("User verified blocked Amount as >> "+BlocekAmt);
    }

    @Then("^User triggers request to Unblock and Debit amount for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and amount \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersRequestToUnblockAndDebitAmountForCustomerWithCurrencyAndAmountAndVerify(String CustReferenceTAN, String CCY, String Amount, String ResponseCode, String ResponseDescription) throws Throwable {

        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "AUTO-20159568-SAU091097RABH";

        String body ="{\n" +
                "  \"eventId\": \"fc958869-5f34-475b-b311-eac338b2d84f\",\n" +
                "  \"cdCustomerRef\": \""+CustReferenceTAN+"\",\n" +
                "  \"cdPaymentLifecycleId\": \""+PamentLifeCycleID+"\",\n" +
                "  \"amountToDebit\": {\n" +
                "    \"amount\": \""+Amount+"\",\n" +
                "    \"currency\": \""+CCY+"\"\n" +
                "  },\n" +
                "  \"baseCurrency\": \""+CCY+"\",\n" +
                "  \"merchantName\": \"Bananarama Fan Club\",\n" +
                "  \"txnDescription\": \"Golff Harmelen HARMELEN NLD\",\n" +
                "  \"txnDate\": \""+currentDate+"\",\n" +
                "  \"deviceId\": \"GDU808id0de793h\",\n" +
                "  \"ipAddress\": \"13.11.30.00\",\n" +
                "       \"bin\": \"bin\",\n" +
                "  \"fee\": [\n" +
                "    {\n" +
                "      \"type\": \"atm\",\n" +
                "      \"amount\": 0.00,\n" +
                "      \"currency\": \""+CCY+"\",\n" +
                "      \"description\": \"ATM Fee\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"type\": \"crossborder\",\n" +
                "      \"amount\": 0.00,\n" +
                "      \"currency\": \""+CCY+"\",\n" +
                "      \"description\": \"2% crossborder\"\n" +
                "    }\n" +
                "  ]\n" +
                "}\n";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/unBlockAndDebit";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        DecimalFormat def=new DecimalFormat("0.00");
        String UnblocekAmt =def.format(jp.get("unblockedAmount.amount"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("unblockedAmount.currency"),  CCY);
        LogCapture.info("User verified Unblocked Amount Currency as >> "+jp.get("unblockedAmount.currency"));

        Assert.assertEquals(UnblocekAmt,  Amount);
        LogCapture.info("User verified Unblocked amount as >> "+UnblocekAmt);

        LogCapture.info("User verified Actual Balance as >> "+jp.get("balance.actualBalance")+CCY);
        LogCapture.info("User verified Available Balance as >> "+jp.get("balance.availableBalance")+CCY);

    }

    @Then("^User triggers request to Credit for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and amount \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersRequestToCreditForCustomerWithCurrencyAndAmountAndVerify(String CustReferenceTAN, String CCY, String Amount, String ResponseCode, String ResponseDescription) throws Throwable {
        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "AUTO-28521352-SAU971009RABH";

        String body ="{\n" +
                "   \"source_application\":\"Card\",\n" +
                "   \"eventId\":\"fc958869-5f34-475b-b311-e25338a0d84f\",\n" +
                "   \"cdCustomerRef\":\""+CustReferenceTAN+"\",\n" +
                "   \"cdPaymentLifecycleId\":\""+PamentLifeCycleID+"\",\n" +
                "   \"amountToCredit\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\""+CCY+"\"\n" +
                "   },\n" +
                "   \"transactionDetails\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\""+CCY+"\"\n" +
                "   },\n" +
                "   \"billingDetails\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\""+CCY+"\"\n" +
                "   },\n" +
                "   \"baseCurrency\":\""+CCY+"\",\n" +
                "   \"merchantName\":\"Bananarama Fan Club\",\n" +
                "   \"merchantAddress\":\"Morden, SM4 6AP, United Kingdom\",\n" +
                "   \"txnDescription\":\"Golff Harmelen HARMELEN NLD\",\n" +
                "   \"txnCategory\":\"Refund\",\n" +
                "   \"txnType\":\"spent\",\n" +
                "   \"authMethod\":\"Contactless\",\n" +
                "   \"purchaseCategory\":\"Groceries\",\n" +
                "   \"txnDate\":\""+currentDate+"\",\n" +
                "   \"merchantGpsData\":{\n" +
                "      \"gpsPosData\":\"gps-pos-fc958869-5f34-475b\",\n" +
                "      \"cardToken\":\"fc958869-5f34\",\n" +
                "      \"cardPresent\":\"0\",\n" +
                "      \"cardPresentDesc\":\"master card\",\n" +
                "      \"merchCountry\":\"Japan\",\n" +
                "      \"merchPostcode\":\"JI00968958982\",\n" +
                "      \"merchRegion\":\"asia\",\n" +
                "      \"merchCity\":\"tokyo\",\n" +
                "      \"mccCode\":\"Groceries\",\n" +
                "      \"bin\":\"bin\",\n" +
                "      \"gpsTxnId\":\"gps-00018\",\n" +
                "      \"productId\":\"098158\",\n" +
                "      \"txnCountry\":\"london\",\n" +
                "      \"preAuthSeq\":\"pre-AuthSeq\",\n" +
                "      \"preAuthTotalParts\":\"preAuth-TotalParts\",\n" +
                "      \"preAuthMultiPartInd\":\"0\",\n" +
                "      \"preAuthMultiPartFinal\":\"0\",\n" +
                "      \"preAuthMatchingReference\":\"Reference-fc958869\",\n" +
                "      \"billAmountApprove\":10,\n" +
                "      \"addtnlAmountType\":\"cash-back\",\n" +
                "      \"addtnlAmountCcy\":\"GBP\",\n" +
                "      \"addtnlAmount\":10,\n" +
                "      \"consolidatedWalletBalances\":10,\n" +
                "      \"merchID\":\"merch-ID-001\",\n" +
                "      \"merchantNameOther\":\"smith\",\n" +
                "      \"mccCodeDescription\":\"mccCode-Description\",\n" +
                "      \"merchantContact\":\"12947074902\",\n" +
                "      \"merchantSecondContact\":\"merchant@gmail\",\n" +
                "      \"merchantWebsite\":\"www.merchant-Website\",\n" +
                "      \"acquirerId\":\"acquirer-001\",\n" +
                "      \"acqDatestamp\":\""+currentDate+"\",\n" +
                "      \"gpsDecisionCode\":\"gps-000\",\n" +
                "      \"gpsDecisionCodeDescription\":\"gpsDecision-success\",\n" +
                "      \"gpsDeclineDescription\":\"gpsDecline-success\",\n" +
                "      \"cardStatusCode\":\"000\",\n" +
                "      \"gpsStipFlag\":\"Y\",\n" +
                "      \"avsResult\":\"avs-Result\",\n" +
                "      \"scaAuthenticationExemption\":\"scaAuthentication-Exemption\",\n" +
                "      \"authenticationMethod\":\"authentication-Method\",\n" +
                "      \"authenticationMethodDesc\":\"authentication-MethodDesc\",\n" +
                "      \"cvvResults\":\"cvv-Results\",\n" +
                "      \"continent\":\"Europe\",\n" +
                "      \"longitude\":\"longitude-36.762768\",\n" +
                "      \"latitiude\":\"latitiude-30.762768\",\n" +
                "      \"region\":\"Europe\",\n" +
                "      \"city\":\"London\",\n" +
                "      \"timezone\":\"Pacific time\",\n" +
                "      \"organization\":\"G-2020\",\n" +
                "      \"carrier\":\"carrier\",\n" +
                "      \"connectionType\":\"connection-Type\",\n" +
                "      \"lineSpeed\":\"line-Speed\",\n" +
                "      \"ipRoutingType\":\"ipRouting-Type\",\n" +
                "      \"countryName\":\"UK\",\n" +
                "      \"countryCode\":\"UK-007\",\n" +
                "      \"stateName\":\"california\",\n" +
                "      \"stateCode\":\"CA-001\",\n" +
                "      \"postalCode\":\"0090912CL\",\n" +
                "      \"areaCode\":\"0090912CL\",\n" +
                "      \"anonymizerStatus\":\"anonymize-Success\",\n" +
                "      \"ipAddress\":\"13.11.30.00\",\n" +
                "      \"updateStatus\":\"update-Status\",\n" +
                "      \"dateUpdate\":\""+currentDate+"\",\n" +
                "      \"chargebackReason\":\"chargeback-Reason\",\n" +
                "      \"disputeCondition\":\"dispute-Condition\",\n" +
                "      \"posTerminal\":\"pos-Terminal\",\n" +
                "      \"posDatestamp\":\""+currentDate+"\",\n" +
                "      \"gpsPosCapability\":\"gpsPos-Capability\",\n" +
                "      \"deviceId\":\"GDU808id0de793h\"\n" +
                "   },\n" +
                "   \"fee\":[\n" +
                "      {\n" +
                "         \"type\":\"atm\",\n" +
                "         \"amount\":0.00,\n" +
                "         \"currency\":\""+CCY+"\",\n" +
                "         \"description\":\"ATM Fee\"\n" +
                "      },\n" +
                "      {\n" +
                "         \"type\":\"crossborder\",\n" +
                "         \"amount\":0.00,\n" +
                "         \"currency\":\""+CCY+"\",\n" +
                "         \"description\":\"2% crossborder\"\n" +
                "      }\n" +
                "   ]\n" +
                "}";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/credit";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        DecimalFormat def=new DecimalFormat("0.0000");
        String CreditedAmt =def.format(jp.get("amountCredited.amount"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("amountCredited.currency"),  CCY);
        LogCapture.info("User verified Credited Amount Currency as >> "+jp.get("amountCredited.currency"));

        Assert.assertEquals(CreditedAmt,  Amount);
        LogCapture.info("User verified Credited amount as >> "+CreditedAmt);

        LogCapture.info("User verified Actual Balance as >> "+jp.get("balance.actualBalance")+CCY);
        LogCapture.info("User verified Available Balance as >> "+jp.get("balance.availableBalance")+CCY);
    }

    @Then("^User triggers request to Debit amount for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and amount \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersRequestToDebitAmountForCustomerWithCurrencyAndAmountAndVerify(String CustReferenceTAN, String CCY, String Amount, String ResponseCode, String ResponseDescription) throws Throwable {

        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "AUTO-27923752-SAU971009RABH";

        String body ="{\n" +
                "   \"source_application\":\"Card\",\n" +
                "   \"eventId\":\"fc958869-5f34-475b-b311-eac338a0d84f\",\n" +
                "   \"cdCustomerRef\":\""+CustReferenceTAN+"\",\n" +
                "   \"cdPaymentLifecycleId\":\""+PamentLifeCycleID+"\",\n" +
                "   \"amountToDebit\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\""+CCY+"\"\n" +
                "   },\n" +
                "   \"transactionDetails\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\""+CCY+"\"\n" +
                "   },\n" +
                "   \"billingDetails\":{\n" +
                "      \"amount\":\""+Amount+"\",\n" +
                "      \"currency\":\""+CCY+"\"\n" +
                "   },\n" +
                "   \"baseCurrency\":\""+CCY+"\",\n" +
                "   \"merchantName\":\"Bananarama Fan Club\",\n" +
                "   \"merchantAddress\":\"Morden, SM4 6AP, United Kingdom\",\n" +
                "   \"txnDescription\":\"Golff Harmelen HARMELEN NLD\",\n" +
                "   \"txnCategory\":\"spent\",\n" +
                "   \"txnType\":\"spent\",\n" +
                "   \"authMethod\":\"Contactless\",\n" +
                "   \"purchaseCategory\":\"Groceries\",\n" +
                "   \"txnDate\":\""+currentDate+"\",\n" +
                "   \"merchantGpsData\":{\n" +
                "      \"gpsPosData\":\"gps-pos-fc958869-5f34-475b\",\n" +
                "      \"cardToken\":\"fc958869-5f34\",\n" +
                "      \"cardPresent\":\"0\",\n" +
                "      \"cardPresentDesc\":\"master card\",\n" +
                "      \"merchCountry\":\"Japan\",\n" +
                "      \"merchPostcode\":\"JI00968958982\",\n" +
                "      \"merchRegion\":\"asia\",\n" +
                "      \"merchCity\":\"tokyo\",\n" +
                "      \"mccCode\":\"Groceries\",\n" +
                "      \"bin\":\"bin\",\n" +
                "      \"gpsTxnId\":\"gps-00018\",\n" +
                "      \"productId\":\"098158\",\n" +
                "      \"txnCountry\":\"london\",\n" +
                "      \"preAuthSeq\":\"pre-AuthSeq\",\n" +
                "      \"preAuthTotalParts\":\"preAuth-TotalParts\",\n" +
                "      \"preAuthMultiPartInd\":\"0\",\n" +
                "      \"preAuthMultiPartFinal\":\"0\",\n" +
                "      \"preAuthMatchingReference\":\"Reference-fc958869\",\n" +
                "      \"billAmountApprove\":10,\n" +
                "      \"addtnlAmountType\":\"cash-back\",\n" +
                "      \"addtnlAmountCcy\":\""+CCY+"\",\n" +
                "      \"addtnlAmount\":10,\n" +
                "      \"consolidatedWalletBalances\":10,\n" +
                "      \"merchID\":\"merch-ID-001\",\n" +
                "      \"merchantNameOther\":\"smith\",\n" +
                "      \"mccCodeDescription\":\"mccCode-Description\",\n" +
                "      \"merchantContact\":\"12947074902\",\n" +
                "      \"merchantSecondContact\":\"merchant@gmail\",\n" +
                "      \"merchantWebsite\":\"www.merchant-Website\",\n" +
                "      \"acquirerId\":\"acquirer-001\",\n" +
                "      \"acqDatestamp\":\""+currentDate+"\",\n" +
                "      \"gpsDecisionCode\":\"gps-000\",\n" +
                "      \"gpsDecisionCodeDescription\":\"gpsDecision-success\",\n" +
                "      \"gpsDeclineDescription\":\"gpsDecline-success\",\n" +
                "      \"cardStatusCode\":\"000\",\n" +
                "      \"gpsStipFlag\":\"Y\",\n" +
                "      \"avsResult\":\"avs-Result\",\n" +
                "      \"scaAuthenticationExemption\":\"scaAuthentication-Exemption\",\n" +
                "      \"authenticationMethod\":\"authentication-Method\",\n" +
                "      \"authenticationMethodDesc\":\"authentication-MethodDesc\",\n" +
                "      \"cvvResults\":\"cvv-Results\",\n" +
                "      \"continent\":\"Europe\",\n" +
                "      \"longitude\":\"longitude-36.762768\",\n" +
                "      \"latitiude\":\"latitiude-30.762768\",\n" +
                "      \"region\":\"Europe\",\n" +
                "      \"city\":\"London\",\n" +
                "      \"timezone\":\"Pacific time\",\n" +
                "      \"organization\":\"G-2020\",\n" +
                "      \"carrier\":\"carrier\",\n" +
                "      \"connectionType\":\"connection-Type\",\n" +
                "      \"lineSpeed\":\"line-Speed\",\n" +
                "      \"ipRoutingType\":\"ipRouting-Type\",\n" +
                "      \"countryName\":\"UK\",\n" +
                "      \"countryCode\":\"UK-007\",\n" +
                "      \"stateName\":\"california\",\n" +
                "      \"stateCode\":\"CA-001\",\n" +
                "      \"postalCode\":\"0090912CL\",\n" +
                "      \"areaCode\":\"0090912CL\",\n" +
                "      \"anonymizerStatus\":\"anonymize-Success\",\n" +
                "      \"ipAddress\":\"13.11.30.00\",\n" +
                "      \"updateStatus\":\"update-Status\",\n" +
                "      \"dateUpdate\":\""+currentDate+"\",\n" +
                "      \"chargebackReason\":\"chargeback-Reason\",\n" +
                "      \"disputeCondition\":\"dispute-Condition\",\n" +
                "      \"posTerminal\":\"pos-Terminal\",\n" +
                "      \"posDatestamp\":\""+currentDate+"\",\n" +
                "      \"gpsPosCapability\":\"gpsPos-Capability\",\n" +
                "      \"deviceId\":\"GDU808id0de793h\"\n" +
                "   },\n" +
                "   \"fee\":[\n" +
                "      {\n" +
                "         \"type\":\"atm\",\n" +
                "         \"amount\":0.00,\n" +
                "         \"currency\":\""+CCY+"\",\n" +
                "         \"description\":\"ATM Fee\"\n" +
                "      },\n" +
                "      {\n" +
                "         \"type\":\"crossborder\",\n" +
                "         \"amount\":0.00,\n" +
                "         \"currency\":\""+CCY+"\",\n" +
                "         \"description\":\"2% crossborder\"\n" +
                "      }\n" +
                "   ]\n" +
                "}";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/debit";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        DecimalFormat def=new DecimalFormat("0.0000");
        String CreditedAmt =def.format(jp.get("amountDebited.amount"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("amountDebited.currency"),  CCY);
        LogCapture.info("User verified Debited Amount Currency as >> "+jp.get("amountDebited.currency"));

        Assert.assertEquals(CreditedAmt,  Amount);
        LogCapture.info("User verified Debited amount as >> "+CreditedAmt);

        LogCapture.info("User verified Actual Balance as >> "+jp.get("balance.actualBalance")+CCY);
        LogCapture.info("User verified Available Balance as >> "+jp.get("balance.availableBalance")+CCY);
    }

    @Then("^User triggers request of Pending Credit for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and amount \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersRequestOfPendingCreditForCustomerWithCurrencyAndAmountAndVerify(String CustReferenceTAN, String CCY, String Amount, String ResponseCode, String ResponseDescription) throws Throwable {

        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "AUTO-27923752-SAU971009RABH";

        String body ="{\n" +
                "    \"source_application\": \"Card\",\n" +
                "    \"eventId\": \"fc958869-5f34-475b-b311-eac338a0d84f\",\n" +
                "    \"cdCustomerRef\": \""+CustReferenceTAN+"\",\n" +
                "    \"cdPaymentLifecycleId\": \""+PamentLifeCycleID+"\",\n" +
                "    \"amountToCredit\": {\n" +
                "        \"amount\": \""+Amount+"\",\n" +
                "        \"currency\": \""+CCY+"\"\n" +
                "    },\n" +
                "    \"transactionDetails\": {\n" +
                "        \"amount\": \""+Amount+"\",\n" +
                "        \"currency\": \"EUR\"\n" +
                "    },\n" +
                "    \"billingDetails\": {\n" +
                "        \"amount\": \""+Amount+"\",\n" +
                "        \"currency\": \""+CCY+"\"\n" +
                "    },\n" +
                "    \"baseCurrency\": \""+CCY+"\",\n" +
                "    \"merchantName\": \"Bananarama Fan Club\",\n" +
                "    \"txnDescription\": \"Golff Harmelen HARMELEN NLD\",\n" +
                "    \"txnDate\": \""+currentDate+"\",\n" +
                "    \"fee\": [\n" +
                "        {\n" +
                "            \"type\": \"atm\",\n" +
                "            \"amount\": 0.00,\n" +
                "            \"currency\": \""+CCY+"\",\n" +
                "            \"description\": \"ATM Fee\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"type\": \"crossborder\",\n" +
                "            \"amount\": 0.0,\n" +
                "            \"currency\": \""+CCY+"\",\n" +
                "            \"description\": \"2% crossborder\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/pendingCredit";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        DecimalFormat def=new DecimalFormat("0.0000");
        String CreditedAmt =def.format(jp.get("amountCredited.amount"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("amountCredited.currency"),  CCY);
        LogCapture.info("User verified Pending credit Amount Currency as >> "+jp.get("amountCredited.currency"));

        Assert.assertEquals(CreditedAmt,  Amount);
        LogCapture.info("User verified Pending credit amount as >> "+CreditedAmt);

        LogCapture.info("User verified Actual Balance as >> "+jp.get("balance.actualBalance")+CCY);
        LogCapture.info("User verified Available Balance as >> "+jp.get("balance.availableBalance")+CCY);
    }


    @Then("^User triggers request to Get Card activity History for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and organization \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\" then verify card activity history details$")
    public void userTriggersRequestToGetCardActivityHistoryForCustomerWithCurrencyAndOrganizationAndVerifyThenVerifyCardActivityHistoryDetails(String CustReferenceTAN, String CCY, String Organization, String ResponseCode, String ResponseDescription) throws Throwable {
        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "BNET-27923752-SAU971009RABH";

        String body ="{\n" +
                "  \"source_application\": \"Titan\",\n" +
                "  \"account_number\": \""+CustReferenceTAN+"\",\n" +
                "  \"org_code\": \""+Organization+"\",\n" +
                "  \"search_criteria\": {\n" +
                "    \"sort\": {\n" +
                "      \"field_name\": \"Date\",\n" +
                "      \"is_ascend\": true\n" +
                "    },\n" +
                "    \"filter\": {\n" +
                "      \"date_from\": \"2023-01-01T11:49:24Z\",\n" +
                "      \"date_to\": \""+currentDate+"\",\n" +
                "      \"organization\": [\n" +
                "        \""+Organization+"\"\n" +
                "      ],\n" +
                "      \"currency_list\": [\n" +
                "        \""+CCY+"\"\n" +
                "      ],\n" +
                "      \"status\": \"\",\n" +
                "      \"cdPaymentLifecycleId_list\": [\n" +
                "        \""+PamentLifeCycleID+"\"\n" +
                "      ]\n" +
                "    }\n" +
                "  }\n" +
                "}\n";

        RestAssured.baseURI = "https://uattitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/getCardActivityHistory";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);

        DecimalFormat def=new DecimalFormat("0.0000");
        String Amount =def.format(jp.get("card_activity_history_details[0].transactionAmount"));

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("org_code"),  Organization);
        Assert.assertEquals(jp.get("contract_note_search_criteria.filter.organization[0]"),  Organization);
        LogCapture.info("User verified Organization as >> "+jp.get("org_code"));

        Assert.assertEquals(jp.get("card_activity_history_details[0].cdPaymentLifecycleId"),  PamentLifeCycleID);

        LogCapture.info("User verified Instruction Number as >> "+jp.get("card_activity_history_details[0].instruction_number"));

        Assert.assertEquals(jp.get("card_activity_history_details[0].transactionCurrency"),  CCY);
        LogCapture.info("User verified transaction Currency as >> "+jp.get("card_activity_history_details[0].transactionCurrency"));

        LogCapture.info("User verified Amount as >> "+Amount);
        LogCapture.info("User verified transaction Date as >> "+jp.get("card_activity_history_details[0].transactionDate"));
        LogCapture.info("User verified merchant Name as >> "+jp.get("card_activity_history_details[0].merchantName"));
    }
    @Then("^User triggers request of Card Order Mapping for Customer \"([^\"]*)\" with Public Token \"([^\"]*)\" and contactId \"([^\"]*)\" base currency \"([^\"]*)\"and verify \"([^\"]*)\" \"([^\"]*)\"$")
    public void userTriggersRequestOfCardOrderMappingForCustomerWithPublicTokenAndContactIdBaseCurrencyAndVerify(String CustReferenceTAN, String PublicToken, String ContactId, String CCY, String ResponseCode, String ResponseDescription) throws Throwable {
        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);

        String body ="{\"cdCustomerRef\":\""+CustReferenceTAN+"\",\n" +
                "\"publicToken\":\""+PublicToken+"\",\n" +
                "\"contactId\":\""+ContactId+"\",\n" +
                "\"eventType\":\"CreateCard\",\n" +
                "\"eventDate\":\"2023-04-06 11:23:49\",\n" +
                "\"eventStatus\":\"SUCCESS\",\n" +
                "\"eventReason\":\"Successful\",\n" +
                "\"isCardActive\":true,\n" +
                "\"deleted\":false,\n" +
                "\"baseCurrency\":\""+CCY+"\"\n" +
                "}";

        RestAssured.baseURI = "https://sittitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/cardOrderMapping";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);


        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        String ContactID = Integer.toString(jp.get("contact_id"));
        Assert.assertEquals(ContactID,  ContactId);
        LogCapture.info("User verified Contact ID as >> "+ContactID);

    }


    @Then("^User triggers request for Decline Transaction history for Customer \"([^\"]*)\" with Currency \"([^\"]*)\" and amount \"([^\"]*)\" publicToken \"([^\"]*)\" contactId \"([^\"]*)\" for declineReason \"([^\"]*)\" declineCode \"([^\"]*)\" and verify \"([^\"]*)\" \"([^\"]*)\" then verify card activity history details$")
    public void userTriggersRequestForDeclineTransactionHistoryForCustomerWithCurrencyAndAmountPublicTokenContactIdForDeclineReasonDeclineCodeAndVerifyThenVerifyCardActivityHistoryDetails(String CustReferenceTAN, String CCY, String Amount, String PublicToken, String ContactId, String DeclineReason, String DeclineCode, String ResponseCode, String ResponseDescription) throws Throwable {

        String response = "";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String PamentLifeCycleID = "BNET-27923752-SAU971009RABH";

        String body ="{\n" +
                "    \"eventId\": \"5611eb29-9aad-414d-ad08-07149b476af8\",\n" +
                "    \"txnAmountWithFees\": {\n" +
                "        \"amount\": "+Amount+",\n" +
                "        \"currency\": \""+CCY+"\"\n" +
                "    },\n" +
                "    \"txnCurrency\": \""+CCY+"\",\n" +
                "    \"merchantName\": \"Offsite ATM\",\n" +
                "    \"merchantAddress\": \"CITY GBR\",\n" +
                "    \"declineCode\": \""+DeclineCode+"\",\n" +
                "    \"declineReason\": \""+DeclineReason+"\",\n" +
                "    \"txnDate\": \""+currentDate+"\",\n" +
                "    \"cdCustomerRef\": \""+CustReferenceTAN+"\",\n" +
                "    \"cdPaymentLifecycleId\": \""+PamentLifeCycleID+"\",\n" +
                "    \"txnCategory\": \"Spent\",\n" +
                "    \"publicToken\": \""+PublicToken+"\",\n" +
                "    \"contactId\": \""+ContactId+"\"\n" +
                "}";

        RestAssured.baseURI = "https://sittitan.currenciesdirect.com/titan-wrapper/services/CardPreAlpha/saveCardDeclineTransaction";

        HashMap m = new HashMap();
        m.put("Content-Type", "application/json");
        m.put("Accept-Encoding", "gzip, deflate, br");
        m.put("Accept", "*/*");
        m.put("User-Agent", "PostmanRuntime/7.29.2");
        m.put("Connection", "keep-alive");
        m.put("Authorization", "Bearer " + ACCESS_TOKEN + "");

        response = given().relaxedHTTPSValidation().headers(m).body(body).when().post().then().log().all().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
        JsonPath jp = Constants.key.rawToJason(response);


        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

    }
}












