package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
//import com.utilities.Log;
import com.selenium.utillity.Constants;
//import com.utilities.Log;
import com.utility.LogCapture;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.testng.Assert;

/*import com.utility.LogCapture;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.testng.Assert;*/

public class SFStepDefinition {

    @Given("^User launched SF application through \"(.*?)\"$")
    public void user_launched_SF_application_through(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        Assert.assertTrue(Constants.key.openBrowser("", data));
    }

    @Given("^User navigate to SF Application \"(.*?)\"$")
    public void user_navigate_to_SF_Application(String vUrl) throws Throwable {
        LogCapture.info("Sales Force Applicatiion is loading....");
        String url = Constants.CONFIG.getProperty(vUrl);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));

    }

    @When("^User enter SF UserName \"(.*?)\" password \"(.*?)\" and click log In button$")
    public void user_enter_SF_UserName_password_and_click_log_In_button(String userName, String password) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.SFLoginOR.getProperty("SFUserName");
        String vObjPass = Constants.SFLoginOR.getProperty("SFPassword");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.SFLoginOR.getProperty("SFLonInButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
        Constants.key.pause("5", "");

    }

    @Then("^User successfully landed on SF Home page$")
    public void user_successfully_landed_on_SF_Home_page() throws Throwable {
        LogCapture.info("Home page loading ......");
        Constants.key.pause("2", "");
        String vObjectHome = Constants.SFLoginOR.getProperty("ProfileButton");
        Assert.assertEquals("PASS", Constants.key.exist(vObjectHome, ""));
        LogCapture.info("Home page loaded successfully");

    }

    @When("^User enter SF UserName \"(.*?)\" incorrect password \"(.*?)\" and click log In button$")
    public void user_enter_SF_UserName_incorrect_password_and_click_log_In_button(String usernName, String inPassword) throws Throwable {
        LogCapture.info("Validating incorrect credentials.......");
        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.SFLoginOR.getProperty("SFUserName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        String vObjPass = Constants.SFLoginOR.getProperty("SFPassword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));
        String vObjLoginButton = Constants.SFLoginOR.getProperty("SFLonInButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @Then("^error message is displayed on SF Login page$")
    public void error_message_is_displayed_on_SF_Login_page() throws Throwable {
        String vExpected = "Please check your username and password. If you still can't log in, contact your Salesforce administrator.";
        String vErrorObj = Constants.SFLoginOR.getProperty("ErrorMessage");
        LogCapture.info("Validating error message...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vErrorObj, vExpected));
    }

    @Then("^User clicks on Logout link under profile and successfully logout from application$")
    public void user_clicks_on_Logout_link_under_profile_and_successfully_logout_from_application() throws Throwable {
        Constants.key.pause("2","");
        String vObjProfileButton = Constants.SFLoginOR.getProperty("ProfileButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjProfileButton, ""));
        String vObjSFLogOutLink = Constants.SFLoginOR.getProperty("SFLogOutLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjSFLogOutLink, ""));
    }

    @When("^User clicks on Lead Tab and then on New Lead$")
    public void user_clicks_on_Lead_Tab_and_then_on_New_Lead() throws Throwable {
        String vObjLeadTab = Constants.LeadGenerationOR.getProperty("LeadTab");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjLeadTab, ""));
        String vObjNewLead = Constants.LeadGenerationOR.getProperty("NewLead");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjNewLead, ""));
    }

    @When("^User select record type as CD and clicks on Next button$")
    public void user_select_record_type_as_CD_and_clicks_on_Next_button() throws Throwable {
        String vObjNextButton = Constants.LeadGenerationOR.getProperty("NextButton");
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjNextButton, ""));
        Constants.key.isAlertPresent();
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.isAlertPresent());
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.isAlertPresent());
        Constants.key.pause("2", "");
    }

    @When("^User enter Lead Information \"(.*?)\" \"(.*?)\" \"(.*?)\" \"(.*?)\"$")
    public void user_enter_Lead_Information(String accountname, String firstname, String lastname, String email) throws Throwable {
        String vObjAccountName = Constants.LeadGenerationOR.getProperty("AccountName");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAccountName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountName, accountname));

        String vObjFirstName = Constants.LeadGenerationOR.getProperty("FirstName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, firstname));

        String vObjLastName = Constants.LeadGenerationOR.getProperty("LastName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, lastname));

        String vObjEmail = Constants.LeadGenerationOR.getProperty("Email");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmail, email));

    }

    @When("^User enters source information \"(.*?)\" \"(.*?)\" and clicks on Save button$")
    public void user_enters_source_information_and_clicks_on_Save_button(String sourcelookup, String branchname) throws Throwable {
        String vObjSourceLookUp = Constants.LeadGenerationOR.getProperty("SourceLookUp");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSourceLookUp, sourcelookup));
       // //Assert.assertEquals("PASS", Constants.key.sendkeyboardStroke(vObjSourceLookUp, "down"));
        ////Assert.assertEquals("PASS", Constants.key.sendkeyboardStroke("", "enter"));

        //String vObjBranchName = Constants.LeadGenerationOR.getProperty("BranchName");
        String vObjBranchName = Constants.LeadGenerationOR.getProperty("BranchNameDDclick");
        //div[8]/div/ul/li[*]/a[@title='Portugal']
        //String DynamicbranchName= "//div[8]/div/ul/li[*]/a[@title='"+branchname+"']";
        //String vxpath = "//a[contains(text(),'Italy')]";
        String DynamicbranchName = "//a[contains(text(),'" + branchname + "')]";
        //a[contains(text(),'Moorgate HO')]

        Assert.assertEquals("PASS", Constants.key.SfLeadDD(vObjBranchName, DynamicbranchName));

        String vObjSaveLeadButton = Constants.LeadGenerationOR.getProperty("SaveLeadButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjSaveLeadButton, ""));
    }

    @Then("^User should be able successfully generate Lead$")
    public void user_should_be_able_successfully_generate_Lead() throws Throwable {

        Assert.assertEquals("PASS", Constants.key.VerifyTitle("", ""));
    }


    @Then("^User should be able successfully generate Lead\"([^\"]*)\"\"([^\"]*)\"$")
    public void userShouldBeAbleSuccessfullyGenerateLead(String firstname, String lastname) throws Throwable {
        Constants.key.pause("3","");
        Assert.assertEquals("PASS", Constants.key.VerifyTitle("", "Lightning Experience | Salesforce"));

    }

    @Then("^User Enters  \"([^\"]*)\" Sent on mobile and clicks verify$")
    public void userEntersSentOnMobileAndClicksVerify(String otp) throws Throwable {
        String vObjOtp = Constants.SFLoginOR.getProperty("Otp");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjOtp, otp));
        Constants.key.pause("5","");
        String vObjVerifyOtp = Constants.SFLoginOR.getProperty("VerifyButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjVerifyOtp, otp));
        Constants.key.pause("5","");

    }

    @And("^User click on (Chatter|App Launcher|View All|Omin-Channel) link$")
    public void userClickOnChatterLink(String option) throws Throwable {
        if (option.equalsIgnoreCase("Chatter")) {
            LogCapture.info("Clicking Chatter Menu .......");

            String vObjVerifyOtp = Constants.SFLoginOR.getProperty("VerifyButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjVerifyOtp, ""));
            Constants.key.pause("2", "");
            LogCapture.info("User click on Chatter Menu");

        }
        else if (option.equalsIgnoreCase("App Launcher")) {
            LogCapture.info("Clicking App Launcher Menu .......");
            String vObjAppLauncher = Constants.SFLoginOR.getProperty("AppLauncher");
            Assert.assertEquals("PASS", Constants.key.click(vObjAppLauncher, ""));
            Constants.key.pause("5", "");
            LogCapture.info("User click on App Launcher Menu");

        }
        else if (option.equalsIgnoreCase("View All")) {
            LogCapture.info("Clicking View All link .......");

            String vObjViewAll = Constants.SFLoginOR.getProperty("ViewAllLink");
            Assert.assertEquals("PASS", Constants.key.click(vObjViewAll, ""));
            Constants.key.pause("5", "");
            LogCapture.info("User click on View All link");

        }
        else if (option.equalsIgnoreCase("Omin-Channel")) {
            LogCapture.info("Clicking Omin-Channel link .......");

            Constants.key.pause("5", "");
            String vObjOminChannel = Constants.SFLoginOR.getProperty("OmniChannelLink");
            Assert.assertEquals("PASS", Constants.key.click(vObjOminChannel, ""));
            Constants.key.pause("5", "");
            LogCapture.info("User click on Omin-Channel linkss");

        }
    }

    @And("^User select (TorFXOz_Snap_In_Agent) App$")
    public void userSelectTorFXOz_Snap_In_AgentApp(String app)throws Throwable {
        if (app.equalsIgnoreCase("TorFXOz_Snap_In_Agent")) {
            LogCapture.info("Selecting TorFXOz_Snap_In_Agent App .......");

            String vObjTorFXOzSnapIAgent = Constants.SFLoginOR.getProperty("TorFXOzSnapInAgentApp");
            Assert.assertEquals("PASS", Constants.key.click(vObjTorFXOzSnapIAgent, ""));
            Constants.key.pause("5", "");
            LogCapture.info("User Selected TorFXOz_Snap_In_Agent App");

        }
    }

    @And("^Chat Agent select status as an (Online|Offline|Away)$")
    public void chatAgentBecameInAnOnlineStatus(String status)throws Throwable {
        int count = 0;
        Constants.key.pause("3", "");
        String vObjStatusDropdown = Constants.SFLoginOR.getProperty("StatusDropdown");
        do {
            count = count + 1;
        } while (!Constants.driver.findElement(By.xpath(vObjStatusDropdown)).isDisplayed());

        Assert.assertEquals("PASS", Constants.key.click(vObjStatusDropdown, ""));
        Constants.key.pause("5", "");

        if (status.equalsIgnoreCase("Online")) {
            LogCapture.info("Chat agent coming Online .......");
            String vObjStatusOnline=Constants.SFLoginOR.getProperty("AgentStatusOnline");
            do {
                count = count + 1;
            } while (!Constants.driver.findElement(By.xpath(vObjStatusOnline)).isDisplayed());
            Assert.assertEquals("PASS", Constants.key.click(vObjStatusOnline, ""));
            Constants.key.pause("5", "");
            LogCapture.info("Chat agent selected status as Online");
        }
        else if (status.equalsIgnoreCase("Offline")) {
            LogCapture.info("Chat agent coming Offline .......");
            String vObjStatusOffline=Constants.SFLoginOR.getProperty("AgentStatusOffline");
            do {
                count = count + 1;
            } while (!Constants.driver.findElement(By.xpath(vObjStatusOffline)).isDisplayed());
            Assert.assertEquals("PASS", Constants.key.click(vObjStatusOffline, ""));
            Constants.key.pause("5", "");
            LogCapture.info("Chat agent selected status as Offline");
        }
        else if (status.equalsIgnoreCase("Away")) {
            LogCapture.info("Chat agent coming Away .......");
            String vObjStatusAway=Constants.SFLoginOR.getProperty("AgentStatusAway");
            do {
                count = count + 1;
            } while (!Constants.driver.findElement(By.xpath(vObjStatusAway)).isDisplayed());
            Assert.assertEquals("PASS", Constants.key.click(vObjStatusAway, ""));
            Constants.key.pause("5", "");
            LogCapture.info("Chat agent selected status as Away");
        }
        Constants.key.pause("5", "");

    }

    @And("^Chat Agent change to an (Online|Offline|Away)$")
    public void chatAgentChangeToAnOnline(String agentStatus) throws Throwable{
            LogCapture.info("Verifing Chat agent online status  .......");
            String vObjAgentStatus = Constants.SFLoginOR.getProperty("AgentStatusMsg");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjAgentStatus, agentStatus));
            Constants.key.pause("5", "");
            LogCapture.info("Chat agent online status has been updated to "+agentStatus);
    }

    @And("^SF Chat Agent will get user chat request with timer$")
    public void sfChatAgentWillGetUserChatRequestWithTimer() throws Throwable{
        LogCapture.info("Verifing user chat request in SF.......");
        String vObjChatRequestOmniTimer = Constants.SFLoginOR.getProperty("OmniTimer");
        Assert.assertEquals("PASS", Constants.key.exist(vObjChatRequestOmniTimer, ""));
        Constants.key.pause("5", "");
        LogCapture.info("Chat request from user has been successfully submitted." );
    }

    @And("^SF Chat Agent accept user chat request from new queue$")
    public void sfChatAgentAcceptUserChatRequestFromNewQueue() throws Throwable{
        LogCapture.info("SF Agent accepting user chat request.......");
        String vObjChatRequestAcceptchecker = Constants.SFLoginOR.getProperty("ChatRequestAcceptChecker");
        Assert.assertEquals("PASS", Constants.key.click(vObjChatRequestAcceptchecker, ""));
        Constants.key.pause("10", "");
        LogCapture.info("Chat request from user has been accepcted by SF agent." );
    }


}
