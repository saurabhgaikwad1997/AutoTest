package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
//import com.utilities.Log;
import com.utility.LogCapture;
//import com.utilities.Log;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;

import static com.selenium.utillity.Constants.*;

/*import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.testng.Assert;*/

public class AltasStepDefination {
    public static String ClientNumber;
    public static String ReportName;
    public static String Comments;

    @And("^User navigate to (Atlas|Saleforce) Application \"([^\"]*)\"$")
    public void userNavigateToAtlasApplication(String page, String vUrl) throws Exception {
        if (page.equals("Atlas")) {
            LogCapture.info("Atlas Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (page.equals("Salesforce")) {
            //Line of code
        }
    }

        /*else if(page.equals("Titan")){
            LogCapture.info("Titan Applicatiion is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));

        }*/


    @When("^User enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click log In button on Altas Application$")
    public void userEnterUserNamePasswordAndClickLogInButtonOnAltasApplication(String userName, String password) throws Exception {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.AtlasloginOR.getProperty("Atlas_Username");
        String vObjPass = Constants.AtlasloginOR.getProperty("Atlas_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.AtlasloginOR.getProperty("Atlas_LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @Then("^User successfully landed on Atlas Dashboard page$")
    public void userSuccessfullyLandedOnAtlasDashboardPage() throws Exception {
        LogCapture.info("Dashboard loading ......");
        Constants.key.pause("2", "");
        String vobjectDashboard = Constants.AtlasDashboardOR.getProperty("Atlas_Dashboard");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "ATLAS"));

    }

    @Given("^User launched application through \"([^\"]*)\" browser$")
    public void userLaunchedApplicationThroughBrowser(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        //Assert.assertTrue(Constants.key.openBrowser("", data));
        Assert.assertTrue(Constants.key.openBrowser("", data));
    }

    @And("^User navigates to (Payment In Report|Registration Queue|Registration Report|Payment In Queue|Payment Out Queue) from Dashboard$")
    public void userNavigatesToRespectivePageFromDashboard(String Menu) throws Exception {
        if (Menu.equalsIgnoreCase("Payment In Report")) {
            LogCapture.info("User is selecting Payment In hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("Atlas_PaymentInTab");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
        } else if (Menu.equalsIgnoreCase("Registration Queue")) {
            LogCapture.info("User is selecting Registration Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasRegistrationQueue = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationQueue");
            String vObjAtlasRegistrationQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasRegistrationQueue, ""));
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAtlasRegistrationQueueText, ""));
            if (Constants.driver.findElement(By.xpath(vObjAtlasRegistrationQueueText)).getText().contains("Registration queue")) {
                LogCapture.info("User Successfully redirecting to Registration Queue ");
            } else {
                LogCapture.info("User is not Successfully redirecting to Registration Queue ");
                Assert.fail();
            }

        } else if (Menu.equalsIgnoreCase("Registration Report")) {
            LogCapture.info("User is selecting Registration Report hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasRegistrationReport = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReport");
            String vObjAtlasRegistrationReportText = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReportText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasRegistrationReport, ""));
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAtlasRegistrationReportText, ""));
            if (Constants.driver.findElement(By.xpath(vObjAtlasRegistrationReportText)).getText().contains("Registration report")) {
                LogCapture.info("User Successfully redirecting to Registration Report ");
            } else {
                LogCapture.info("User is not Successfully redirecting to Registration Report ");
                Assert.fail();
            }

        } else if (Menu.equalsIgnoreCase("Payment In Queue")) {
            LogCapture.info("User is selecting Payment In Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("AtlasPaymentInTabQueue");
            String vObjAtlasPaymentInQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasPaymentInQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAtlasPaymentInQueueText, ""));
//            if (Constants.driver.findElement(By.xpath(vObjAtlasPaymentInQueueText)).getText().contains("Payment In queue")) {
//                LogCapture.info("User Successfully redirecting to Payment In Queue ");
//            } else {
//                LogCapture.info("User is not Successfully redirecting to Payment In Queue ");
//                Assert.fail();
//            }
        } else if (Menu.equalsIgnoreCase("Payment Out Queue")) {
            LogCapture.info("User is selecting Payment Out Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasPaymentOutTabQueue = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutTabQueue");
            String vObjAtlasPaymentOutQueueText = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasPaymentOutTabQueue, ""));

        }

    }

    @When("^User click on filter criteria$")
    public void userClickOnFilterCriteria() throws Exception {
        String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
    }

    @And("^User enters valid (Customer Number|Email Address|Customer ID|Client Id) \"([^\"]*)\" in keyword section$")
    public void userEntersValidCustomerNumberInKeywordSection(String Value, String InputValue) throws Throwable {
        if (Value.equalsIgnoreCase("Customer Number") || Value.equalsIgnoreCase("Email Address") || Value.equalsIgnoreCase("Client Id")) {
            String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, InputValue));

        } else if (Value.equalsIgnoreCase("Customer ID")) {
            String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, AltasStepDefination.ClientNumber));

        }
    }

    @And("^User Click on  a record for which Payment  is in HOLD status to navigate to details page$")
    public void userClickOnARecordForWhichPaymentIsInHOLDStatusToNavigateToDetailsPage() throws Exception {
        String vclickFirst = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecord");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vclickFirst, ""));
    }

    @Then("^User (Lock|UnLock) the Record$")
    public void userLockTheRecord(String Lock) throws Exception {
        if (Lock.equalsIgnoreCase("Lock")) {
            String vLockObj = Constants.AtlasPaymentInOR.getProperty("Atlas_LockToggle");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vLockObj, ""));
            Assert.assertEquals("PASS", Constants.key.click(vLockObj, ""));
        }
        if (Lock.equalsIgnoreCase("UnLock")) {
            String vLockObj = Constants.AtlasPaymentInOR.getProperty("Atlas_UnLockToggle");
            Assert.assertEquals("PASS", Constants.key.click(vLockObj, ""));
        }
    }

    @And("^Mark the (Payment In|Registration|Payment Out) Status as (CLEAR|ACTIVE|INACTIVE|REJECT|SEIZE) with comments$")
    public void markThePaymentInStatusAsCLEARWithComments(String Value, String Action) throws Exception {
        Comments = RandomStringUtils.randomAlphabetic(10);
        System.out.println(Comments);
        if (Value.equalsIgnoreCase("Payment In") || Value.equalsIgnoreCase("Payment Out") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("ACTIVE")) {
            String vObjActive = Constants.AtlasRegistrationOR.getProperty("Active");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjActive, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("INACTIVE")) {
            String vObjActive = Constants.AtlasRegistrationOR.getProperty("InActive");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjActive, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("REJECT")) {
            String vObjReject = Constants.AtlasRegistrationOR.getProperty("Reject");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjReject, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In") || Value.equalsIgnoreCase("Payment Out") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In") || Value.equalsIgnoreCase("Payment Out") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        }
    }

    @When("^User Click on (Apply|Apply & Unlock) button on (Registration Queue|Payment In Queue|Registration Queues|Payment Out Queue)$")
    public void userClickOnApplyApplyUnlock(String Lock, String Queue) throws Exception {
        if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue")) {
            String vApplyButton = Constants.AtlasRegistrationOR.getProperty("Apply");
            String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasRegistrationOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasRegistrationOR.getProperty("SanctionsTable");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe")) {
                Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));
            } else {
                int count = 0;
                do {
                    count = count + 1;
                    do {
                        count = count + 1;
                    } while (!Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled());
                    Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
                } while (!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe"));
                System.out.println("Count" + count);
                Constants.key.pause("2", "");
                ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
                String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("ApplyAndLock");
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));

            }
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queues")) {
            String vApplyButton = Constants.AtlasRegistrationOR.getProperty("Apply");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vApplyButton, "enabled"));
            Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In Queue")) {
            String vApplyButton = Constants.AtlasPaymentInOR.getProperty("Apply");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vApplyButton, "enabled"));
            Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment Out Queue")) {
            String vApplyButton = Constants.AtlasPaymentOutOR.getProperty("Apply");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vApplyButton, "enabled"));
            Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));

        }
    }
    //Assert.assertEquals("PASS", Constants.key.isAlertPresent());
//                Alert alert = Constants.driver.switchTo().alert();
//                System.out.println("Alert Message"+alert.getText());
//                alert.accept();
//                String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("Sanctions");
//                String vObjRepeatCheck = Constants.AtlasRegistrationOR.getProperty("RepeatCheck");
//                String vObjSanctionStatus = Constants.AtlasRegistrationOR.getProperty("SanctionStatus");
//                Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
//                int count = 0;
//                do {
//                    count = count + 1;
//                    Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
//                } while ((!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).isDisplayed()));
//                if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue")) {
//                    String vApplyButton = Constants.AtlasRegistrationOR.getProperty("Apply");
//                    Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));
//                }
    //           }
    //      }
//       else if (Lock.equalsIgnoreCase("Apply")&& Queue.equalsIgnoreCase("Payment In Queue")) {
//            String vApplyButton = Constants.AtlasPaymentInOR.getProperty("Atlas_ApplyButton");
//            Assert.assertEquals("PASS", Constants.key.click(vApplyButton, ""));
//        }


    @Then("^(Payment In|Registration|Payment Out) Status to be Observed as (CLEAR|ACTIVE|INACTIVE|REJECT|SEIZE) with success message$")
    public void paymentInStatusToBeObservedAsCLEARWthSuccessMessage(String Value, String Action) throws Exception {
        if (Value.equalsIgnoreCase("Payment In") || Value.equalsIgnoreCase("Payment Out") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("ACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("INACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("REJECT")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "REJECTED"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In") && Action.equalsIgnoreCase("HOLD")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            // String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            // Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "HOLD"));
            // Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In") || Value.equalsIgnoreCase("Payment Out") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In") || Value.equalsIgnoreCase("Payment Out") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        }
    }

    @And("^User navigates to  Payment_Out Report from Dashboard$")
    public void userNavigatesToPayment_OutReportFromDashboard() throws Exception {
        LogCapture.info("User is selecting Payment Out hyperlink from dashboard..");
        String vtabView = Constants.AtlasDashboardOR.getProperty("Atlas_SelectTabView");
        String vPaymentOutTab = Constants.AtlasDashboardOR.getProperty("Atlas_PaymentOutTab");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vtabView, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vPaymentOutTab, ""));
    }

    @And("^User select the SANCTION STATUS as PASS$")
    public void userSelectTheSANCTIONSTATUSAsPASS() throws Exception {
        LogCapture.info("Selecting Santion as PASS....");
        String vSanctionStatusPass = Constants.AtlasPaymentOutOR.getProperty("Atlas_SanctionPass");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSanctionStatusPass, ""));
    }

    @And("^user hits Enter on Keyboard$")
    public void userHitsEnterOnKeyboard() throws Exception {
        //Assert.assertEquals("PASS", Constants.key.sendkeyboardStroke("","enter"));
        String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        //String vKeyword=Constants.AtlasRegistrationOR.getProperty("ShowingResults");
        // Assert.assertEquals("PAS//S", Constants.key.VisibleConditionWait(vKeyword,""));
        // Assert.assertEquals("PASS", Constants.key.exist(vKeyword,""));
    }

    @When("^User Click on Apply/Apply & Unlock on Payment Out$")
    public void userClickOnApplyApplyUnlockOnPaymentOut() throws Exception {
        String vApplyButtonPayOut = Constants.AtlasPaymentOutOR.getProperty("Atlas_ApplyPayOutButton");
        Assert.assertEquals("PASS", Constants.key.click(vApplyButtonPayOut, ""));
    }
//    @And("^Mark the Payment In Status as REJECT with comments$")
//    public void markThePaymentInStatusAsREJECTWithComments() throws Exception {
//        String vRejectButton = Constants.AtlasPaymentInOR.getProperty("Atlas_RejectStatus");
//        String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
//        Assert.assertEquals("PASS", Constants.key.click(vRejectButton, ""));
//        Constants.key.pause("1", "");
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, "Payment In Test flow for reject-POC2"));
//    }

    @And("^User selects reason \"([^\"]*)\" from drop down$")
    public void userSelectsReasonFromDropDown(String reason) throws Throwable {
        String vArrowDDClick = Constants.AtlasPaymentInOR.getProperty("Atlas_ReasonArrowDropDown");
        String vReasonContainer = Constants.AtlasPaymentInOR.getProperty("Atlas_AllReasonContainer");
        Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.AltasRejectDropDown(vReasonContainer, reason));
    }

    @Then("^Payment In Status to be Observed as REJECT wth success message$")
    public void paymentInStatusToBeObservedAsREJECTWthSuccessMessage() throws Exception {
        String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
        String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
    }

    @And("^User clicks on Logout button to logoff application$")
    public void userClicksOnLogoutButtonToLogoffApplication() throws Exception {
        String vLogOut = Constants.AtlasDashboardOR.getProperty("Atlas_LogOut");
        //String vLogOut = Constants.AtlasDashboardOR.getProperty("");
        Assert.assertEquals("PASS", Constants.key.click(vLogOut, ""));
    }

    @Then("^Payment Out Status to be Observed as REJECT wth success message$")
    public void paymentOutStatusToBeObservedAsREJECTWthSuccessMessage() throws Exception {
        String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
        String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
    }

    @Then("^Payment Out Status to be Observed as ClEAR wth success message$")
    public void paymentOutStatusToBeObservedAsClEARWthSuccessMessage() throws Exception {
        String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
        String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
    }

    @And("^User Click on (Client Number|Client Name) Hyper Link$")
    public void userClickOnHyperLink(String Column) throws Exception {
        String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
        LogCapture.info("Total number of elements present: " + listOfElements.size());
        if (Column.equalsIgnoreCase("Client Number")) {
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[2]";
                ClientNumber = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(ClientNumber);
                if (ClientNumber.length() > 0) {
                    WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + ClientNumber + "']"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", ele);
                    break;
                }
            }
        } else if (Column.equalsIgnoreCase("Client Name")) {
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[4]";
                String Value = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(Value);
                if (Value.length() > 0) {
                    WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", ele);
                    break;
                }
            }
        }
        String vObjClientText = Constants.AtlasRegistrationOR.getProperty("ClientText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientText, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjClientText, ""));
    }


    @And("^User Observe the Status as (ACTIVE|INACTIVE|REJECT) and all the other contact details ContactName \"([^\"]*)\" And EmailAddress \"([^\"]*)\"$")
    public void userObserveTheStatusAndAllTheOtherContactDetailsContactNameAndEmailAddress(String status, String ContactName, String EmailAddress) throws Throwable {
        if (status.equalsIgnoreCase("INACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));
        } else if (status.equalsIgnoreCase("ACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));
        }
        String vObjContactName = Constants.AtlasRegistrationOR.getProperty("ContactName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContactName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjContactName, ContactName));
        String vObjEmailAddress = Constants.AtlasRegistrationOR.getProperty("EmailID");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjEmailAddress, EmailAddress));
    }

    @And("^User select (Reject|Seize) Reason$")
    public void userSelectRejectReason(String Reason) throws Exception {
        if (Reason.equalsIgnoreCase("Reject")) {
            String vObjSelectReason = Constants.AtlasRegistrationOR.getProperty("SelectReason");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectReason, ""));
            Constants.key.pause("3", "");
            String vObjSelectAnyReason = Constants.AtlasRegistrationOR.getProperty("SelectAnyReason");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectAnyReason, ""));
        } else if (Reason.equalsIgnoreCase("Seize")) {
            String vObjSelectReason = Constants.AtlasRegistrationOR.getProperty("SelectReason");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectReason, ""));
            Constants.key.pause("3", "");
            String vObjSelectAnyReason = Constants.AtlasPaymentInOR.getProperty("SelectAnyReason");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectAnyReason, ""));
        }
    }

    @And("^User Perform the Repeat check for Sanctions$")
    public void userPerformTheRepeatCheckForSanctions() throws Exception {
        String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("Sanctions");
        String vObjRepeatCheck = Constants.AtlasRegistrationOR.getProperty("RepeatCheck");
        String vObjSanctionStatus = Constants.AtlasRegistrationOR.getProperty("SanctionsTable");
        Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
        if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe")) {
            LogCapture.info("Sanction check status is safe/PASS already");
        } else {
            int count = 0;
            do {
                count = count + 1;
                do {
                    count = count + 1;
                } while (!Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled());
                Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));

            } while (!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe"));
            System.out.println("Count" + count);
        }
    }

    @Then("^(Registration|Payment In|Registration CFX|Payment Out) Status to be Observed as (INACTIVE|ACTIVE|HOLD)$")
    public void registrationStatusToBeObservedAsINACTIVE(String action, String status) throws Exception {
        if (status.equalsIgnoreCase("INACTIVE") && action.equalsIgnoreCase("Registration")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));

        } else if (status.equalsIgnoreCase("ACTIVE") && action.equalsIgnoreCase("Registration")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));

        } else if (status.equalsIgnoreCase("HOLD") && action.equalsIgnoreCase("Payment In")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "HOLD"));

        } else if (status.equalsIgnoreCase("ACTIVE") && action.equalsIgnoreCase("Registration CFX ")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));

        } else if (status.equalsIgnoreCase("INACTIVE") && action.equalsIgnoreCase("Registration CFX")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));

        } else if (status.equalsIgnoreCase("HOLD") && action.equalsIgnoreCase("Payment Out")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "HOLD"));

        }
    }

    @And("^User Click on Hyper Link with (INACTIVE|ACTIVE WITH ALL CHECK PASS|REJECTED|BLACKLIST|ACTIVE) Record$")
    public void userClickOnHyperLinkOnDashboard(String status) throws Exception {
        if (status.equalsIgnoreCase("INACTIVE") || status.equalsIgnoreCase("ACTIVE") || status.equalsIgnoreCase("BLACKLIST") || status.equalsIgnoreCase("ACTIVE WITH ALL CHECK PASS")) {
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String Status = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[11]";
                String ClientNumber = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String EID = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[13]";
                String FraudPredict = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[14]";
                String Sanction = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[15]";
                String Blacklist = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[16]";
                String CustomCheck = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[17]";
                String Value = Constants.driver.findElement(By.xpath(Status)).getText();
                String Value1 = Constants.driver.findElement(By.xpath(ClientNumber)).getText();
                if (status.equalsIgnoreCase("INACTIVE")) {
                    //System.out.println(i);
                    if (Value.equalsIgnoreCase("INACTIVE")) {
                        System.out.println(i + "INACTIVE");
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                } else if (status.equalsIgnoreCase("ACTIVE WITH ALL CHECK PASS")) {
                    if (Value.equalsIgnoreCase("ACTIVE")) {
                        System.out.println("ACTIVE");
                        Assert.assertEquals("PASS", Constants.key.verifyText(EID, "check"));
                        Assert.assertEquals("PASS", Constants.key.verifyText(FraudPredict, "check"));
                        Assert.assertEquals("PASS", Constants.key.verifyText(Sanction, "check"));
                        Assert.assertEquals("PASS", Constants.key.verifyText(Blacklist, "check"));
                        Assert.assertEquals("PASS", Constants.key.verifyText(CustomCheck, "check"));
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                } else if (status.equalsIgnoreCase("BLACKLIST")) {
                    System.out.println("BLACKLIST");
                    Assert.assertEquals("PASS", Constants.key.verifyText(EID, "not_interested"));
                    Assert.assertEquals("PASS", Constants.key.verifyText(FraudPredict, "check"));
                    Assert.assertEquals("PASS", Constants.key.verifyText(Sanction, "not_interested"));
                    Assert.assertEquals("PASS", Constants.key.verifyText(Blacklist, "clear"));
                    Assert.assertEquals("PASS", Constants.key.verifyText(CustomCheck, "check"));
                    WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", ele);
                    break;
                } else if (status.equalsIgnoreCase("ACTIVE")) {
                    if (Value.equalsIgnoreCase("ACTIVE")) {
                        System.out.println("ACTIVE");
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value1 + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }


                }
                String vObjClientText = Constants.AtlasRegistrationOR.getProperty("ClientText");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientText, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjClientText, ""));
            }
        }
    }

    @And("^User (scroll down|scroll up) the page$")
    public void userScrollDownThePage(String Value) throws InterruptedException {
        if (Value.equalsIgnoreCase("scroll up")) {
            Constants.key.pause("2", "");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(0,1000)");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(0,1000)");

        }
        if (Value.equalsIgnoreCase("scroll down")) {
            Constants.key.pause("2", "");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
        }
    }


    @And("^User Validates the tooltip message and Bold Text on the (Registration|Payment In|Payment Out) dashboard$")
    public void userValidatesTheTooltipMessageOnTheDashboard(String Values) throws Exception {
        if (Values.equalsIgnoreCase("Registration")) {
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='regQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String Value = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(Value);
                if (Value.length() > 0) {
                    Actions actions = new Actions(Constants.driver);
                    Constants.key.pause("2", "");
                    WebElement element = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                    actions.moveToElement(element).perform();
                    Constants.key.pause("2", "");
                    String vObjToolTip = Constants.AtlasRegistrationOR.getProperty("TooTipMsg");
                    Assert.assertEquals("PASS", Constants.key.verifyText(vObjToolTip, "You own(s) this record"));
                    String Bold1 = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']")).getCssValue("font-weight");
                    int BoldNumber = Integer.parseInt(Bold1);
                    System.out.println("Letter:>>>" + Value + "Font Weight:::->" + Bold1);
                    if (BoldNumber >= 700) {
                        LogCapture.info(" User will be able to view the Client Number in Bold letter");
                    } else {
                        LogCapture.info(" User will not be able to view the Client Number in Bold letter" + BoldNumber + "" + Value);
                        Assert.fail();
                    }
                    break;
                }
            }

        } else if (Values.equalsIgnoreCase("Payment In")) {
            String vObjPaymentInQueueTable = AtlasPaymentInOR.getProperty("PaymentInQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='payInQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String Value = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(Value);
                if (Value.length() > 0) {
                    Actions actions = new Actions(Constants.driver);
                    Constants.key.pause("2", "");
                    WebElement element = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                    actions.moveToElement(element).perform();
                    Constants.key.pause("2", "");
                    String vObjToolTip = Constants.AtlasRegistrationOR.getProperty("TooTipMsg");
                    Assert.assertEquals("PASS", Constants.key.verifyText(vObjToolTip, "You own(s) this record"));
                    String Bold1 = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']")).getCssValue("font-weight");
                    int BoldNumber = Integer.parseInt(Bold1);
                    System.out.println("Letter:>>>" + Value + "Font Weight:::->" + Bold1);
                    if (BoldNumber >= 700) {
                        LogCapture.info(" User will be able to view the Client Number in Bold letter");
                    } else {
                        LogCapture.info(" User will not be able to view the Client Number in Bold letter" + BoldNumber + "" + Value);
                        Assert.fail();
                    }
                    break;
                }
            }
        } else if (Values.equalsIgnoreCase("Payment Out")) {
            String vObjPaymentOutQueueTable = Constants.AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentOutQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            for (int i = 0; i <= listOfElements.size(); i++) {
                String DynamicValue = "//*[@id='payOutQueueBody']//tr[" + (i + 1) + "]//td[2]";
                String Value = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                System.out.println(Value);
                if (Value.length() > 0) {
                    Actions actions = new Actions(Constants.driver);
                    Constants.key.pause("2", "");
                    WebElement element = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                    actions.moveToElement(element).perform();
                    Constants.key.pause("2", "");
                    String vObjToolTip = Constants.AtlasRegistrationOR.getProperty("TooTipMsg");
                    Assert.assertEquals("PASS", Constants.key.verifyText(vObjToolTip, "You own(s) this record"));
                    String Bold1 = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']")).getCssValue("font-weight");
                    int BoldNumber = Integer.parseInt(Bold1);
                    System.out.println("Letter:>>>" + Value + "Font Weight:::->" + Bold1);
                    if (BoldNumber >= 700) {
                        LogCapture.info(" User will be able to view the Client Number in Bold letter");
                    } else {
                        LogCapture.info(" User will not be able to view the Client Number in Bold letter" + BoldNumber + "" + Value);
                        Assert.fail();
                    }
                    break;
                }
            }
        }
    }

    @And("^User click on (Generate|Save|Delete) button$")
    public void userClickOnGenerateButton(String button) throws Exception {
        if (button.equalsIgnoreCase("Generate")) {
            String vObjGenerateButton = Constants.AtlasRegistrationOR.getProperty("GenerateButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateButton, ""));
        } else if (button.equalsIgnoreCase("Save")) {
            String vObjSaveButton = Constants.AtlasRegistrationOR.getProperty("SaveButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSaveButton, ""));
        } else if (button.equalsIgnoreCase("Delete")) {
            String vObjDeleteButton = Constants.AtlasRegistrationOR.getProperty("DeleteButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjDeleteButton, ""));
        }
    }

    @And("^User enter the SearchName$")
    public void userEnterTheSearchName() throws Exception {
        String vObjSaveSearchName = Constants.AtlasRegistrationOR.getProperty("SaveSearchName");
        String vObjSaveSearchNameOK = Constants.AtlasRegistrationOR.getProperty("SaveSearchNameOK");
        String Report = RandomStringUtils.randomAlphabetic(5);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSaveSearchName, Report + "_AutoTest"));
        Constants.key.pause("2", "");
        ReportName = Constants.driver.findElement(By.xpath(vObjSaveSearchName)).getAttribute("value");
        System.out.println("ReportName" + ReportName);
        Assert.assertEquals("PASS", Constants.key.click(vObjSaveSearchNameOK, ""));
        Constants.key.pause("10", "");
    }

    @And("^User verify the saved Report on the Filter with (Registration Report|Payment In|Payment Out) screen$")
    public void userVerifyTheSavedReportOnTheFilter(String Page) throws Exception {
        if (Page.equalsIgnoreCase("Registration Report")) {
            String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
            String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            Constants.key.pause("3", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            System.out.println(ReportName);
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                if (vdata.equalsIgnoreCase(ReportName)) {
                    System.out.println(vdata);
                    Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                    break;
                }
            }
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjRegistrationQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (listOfElements.size() > 1) {
                LogCapture.info("Successfullly Added Report");
            } else {
                Assert.fail();
            }
        } else if (Page.equalsIgnoreCase("Payment In")) {
            String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
            String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            Constants.key.pause("3", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            System.out.println(ReportName);
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                if (vdata.equalsIgnoreCase(ReportName)) {
                    System.out.println(vdata);
                    Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                    break;
                }
            }
            String vObjPaymentInQueueTable = AtlasPaymentInOR.getProperty("PaymentInQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (listOfElements.size() > 1) {
                LogCapture.info("Successfullly Added Report");
            } else {
                Assert.fail();
            }
        } else if (Page.equalsIgnoreCase("Payment Out")) {
            String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
            String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            Constants.key.pause("3", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            System.out.println(ReportName);
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                if (vdata.equalsIgnoreCase(ReportName)) {
                    System.out.println(vdata);
                    Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                    break;
                }
            }
            String vObjPaymentInQueueTable = AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (listOfElements.size() > 1) {
                LogCapture.info("Successfullly Added Report");
            } else {
                Assert.fail();
            }
        }
    }

    @And("^User verify the saved Report Deleted successfully$")
    public void userVerifyTheSavedReportDeletedSuccessfully() throws Exception {
        String vObjConfirmDeleteTextMsg = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteTextMsg");
        String vObjConfirmDeleteOK = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteOK");
        String SearchName = Constants.driver.findElement(By.xpath(vObjConfirmDeleteTextMsg)).getText();
        if (SearchName.equalsIgnoreCase(Comments)) {
            Assert.assertEquals("PASS", Constants.key.click(vObjConfirmDeleteOK, ""));
            Constants.key.pause("3", "");
        }
    }

    @And("^User verify the record has been cleared manually and it is not visible in the (Registration Queue)$")
    public void userVerifyTheRecordsHasBeenClearedManuallyAndItIsNotVisibleInTheRegistrationQueue(String Queue) throws Exception {
        if (Queue.equalsIgnoreCase("Registration Queue")) {
            String vObjRegistrationQueueTableRecord = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueMinRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTableRecord, ""));
            String vObjRegistrationQueueMinRecord = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueMinRecord");
            String vObjRegistrationQueueMaxRecord = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueMaxRecord");
            String vObjRegistrationQueueTotalRecord = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTotalRecord");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRegistrationQueueMinRecord, "0"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRegistrationQueueMaxRecord, "0"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjRegistrationQueueTotalRecord, "0"));
            LogCapture.info("User verify the record has been cleared manually and it is not visible in the Queue");

        }
    }

    @And("^Multiple Contact should be observed for the same account$")
    public void multipleContactShouldBeObservedForTheSameWhenSearched() throws Exception {
        String vObjMorePersonOnThisAccount = Constants.AtlasRegistrationOR.getProperty("MorePersonOnThisAccount");
        String vObjJointAccount = Constants.AtlasRegistrationOR.getProperty("JointAccount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMorePersonOnThisAccount, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjMorePersonOnThisAccount, "1 more person on this account"));
        Assert.assertEquals("PASS", Constants.key.click(vObjMorePersonOnThisAccount, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjJointAccount, ""));

    }

    @And("^User click on Other people on this account name$")
    public void userClickOnOtherPeopleOnThisAccountName() {
        String vObjJointAccount = Constants.AtlasRegistrationOR.getProperty("JointAccount");
        List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjJointAccount));
        LogCapture.info("Total number of elements present: " + listOfElements.size());
        for (int i = 0; i <= listOfElements.size(); i++) {
            String DynamicValue = "//*[@id='regDetails_OtherPeople']//tr[" + (i + 1) + "]//td[3]";
            String ClientName = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
            System.out.println(ClientName);
            if (ClientName.length() > 0) {
                WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + ClientName + "']"));
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                executor.executeScript("arguments[0].click();", ele);
                break;
            }
        }

    }

    @Then("^User validates the country as \"([^\"]*)\"$")
    public void userValidatesTheCountryAs(String Country) throws Throwable {
        if (Country.equalsIgnoreCase("United Kingdom")) {
            String vObjCountryOfResidence = Constants.AtlasRegistrationOR.getProperty("CountryOfResidence");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryOfResidence, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCountryOfResidence, "United Kingdom (GBR)"));

        }
        if (Country.equalsIgnoreCase("Austria")) {
            String vObjCountryOfResidence = Constants.AtlasRegistrationOR.getProperty("CountryOfResidence");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryOfResidence, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCountryOfResidence, "Austria (AUT)"));

        }
    }

    @Then("^User validates the Fraud Ring Graph under FRAUDPREDICT$")
    public void userValidatesTheFraudRingGraphUnderFRAUDPREDICT() throws Exception {
        String vObjFraudPredict = Constants.AtlasRegistrationOR.getProperty("FraudPredict");
        String vObjFraugsterChart = Constants.AtlasRegistrationOR.getProperty("FraugsterChart");
        String vObjAmChartsText = Constants.AtlasRegistrationOR.getProperty("AmChartsText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFraudPredict, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFraudPredict, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFraugsterChart, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjFraugsterChart, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAmChartsText, "JS chart by amCharts"));

    }

    @And("^User Click on (Transaction Id|Client Name) Hyper Link on (Payment In|Payment Out)$")
    public void userClickHyperLink(String Column, String Action) throws Exception {
        if (Action.equalsIgnoreCase("Payment In")) {
            String vObjPaymentInQueueTable = Constants.AtlasPaymentInOR.getProperty("PaymentInQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (Column.equalsIgnoreCase("Transaction Id")) {
                for (int i = 0; i <= listOfElements.size(); i++) {
                    String DynamicValue = "//*[@id='payInQueueBody']//tr[" + (i + 1) + "]//td[2]";
                    String TranasctionId = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                    System.out.println(TranasctionId);
                    if (TranasctionId.length() > 0) {
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + TranasctionId + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
            } else if (Column.equalsIgnoreCase("Client Id")) {
                for (int i = 0; i <= listOfElements.size(); i++) {
                    String ClientId = "//*[@id='payInQueueBody']//tr[" + (i + 1) + "]//td[4]";
                    String Value = Constants.driver.findElement(By.xpath(ClientId)).getText();
                    System.out.println(Value);
                    if (Value.length() > 0) {
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
            }
            String vObjTransactionText = Constants.AtlasPaymentInOR.getProperty("TransactionText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionText, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjTransactionText, ""));

        } else if (Action.equalsIgnoreCase("Payment Out")) {
            String vObjPaymentOutQueueTable = Constants.AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutQueueTable, ""));
            List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentOutQueueTable));
            LogCapture.info("Total number of elements present: " + listOfElements.size());
            if (Column.equalsIgnoreCase("Transaction Id")) {
                for (int i = 0; i <= listOfElements.size(); i++) {
                    String DynamicValue = "//*[@id='payOutQueueBody']//tr[" + (i + 1) + "]//td[2]";
                    String TranasctionId = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                    System.out.println(TranasctionId);
                    if (TranasctionId.length() > 0) {
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + TranasctionId + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
            } else if (Column.equalsIgnoreCase("Client Id")) {
                for (int i = 0; i <= listOfElements.size(); i++) {
                    String ClientId = "//*[@id='payOutQueueBody']//tr[" + (i + 1) + "]//td[4]";
                    String Value = Constants.driver.findElement(By.xpath(ClientId)).getText();
                    System.out.println(Value);
                    if (Value.length() > 0) {
                        WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        executor.executeScript("arguments[0].click();", ele);
                        break;
                    }
                }
            }
            String vObjTransactionText = Constants.AtlasPaymentInOR.getProperty("TransactionText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionText, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjTransactionText, ""));

        }
    }

    @And("^User Observe the Status as (HOLD|SEIZE|REJECT|CLEAR) and all the other contact details ContactName \"([^\"]*)\" And EmailAddress \"([^\"]*)\"$")
    public void userObserveTheStatusAllTheOtherContactDetailsContactNameAndEmailAddress(String status, String ContactName, String EmailAddress) throws Throwable {
        if (status.equalsIgnoreCase("SEIZE")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "SEIZE"));
        } else if (status.equalsIgnoreCase("HOLD")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "HOLD"));
        }
        String vObjContactName = Constants.AtlasPaymentInOR.getProperty("ContactName");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjContactName, ContactName));
        Assert.assertEquals("PASS", Constants.key.click(vObjContactName, ContactName));
        Constants.key.pause("3", "");
        String vObjEmailAddress = Constants.AtlasRegistrationOR.getProperty("EmailID");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjEmailAddress, EmailAddress));
    }


    @And("^User select the record as (INACTIVE|ACTIVE)$")
    public void userSelectTheRecordAsINACTIVE(String status) throws Exception {
        if (status.equalsIgnoreCase("INACTIVE")) {
            String vObjInactiveRecord = Constants.AtlasRegistrationOR.getProperty("InactiveRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInactiveRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjInactiveRecord, ""));
            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
            String vObjGenerateReportButton = Constants.AtlasRegistrationOR.getProperty("GenerateReportButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateReportButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateReportButton, ""));
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjRegistrationQueueTable, ""));
        } else if (status.equalsIgnoreCase("ACTIVE")) {
            String vObjActiveRecord = Constants.AtlasRegistrationOR.getProperty("ActiveRecord");
            Assert.assertEquals("PASS", Constants.key.click(vObjActiveRecord, ""));
            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
            String vObjGenerateReportButton = Constants.AtlasRegistrationOR.getProperty("GenerateReportButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateReportButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateReportButton, ""));
            String vObjRegistrationQueueTable = Constants.AtlasRegistrationOR.getProperty("RegistrationQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjRegistrationQueueTable, ""));
        }

    }

    @And("^User select the (PFX) record with (Sanction Failed|Payment Out)$")
    public void userSelectThePFXRecordWithSanctionFailed(String Org, String Check) throws Exception {
        if (Org.equalsIgnoreCase("PFX") && Check.equalsIgnoreCase("Sanction Failed")) {
            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
            String vObjSanctionFailed = Constants.AtlasPaymentInOR.getProperty("SanctionFailed");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionFailed, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionFailed, ""));
            String vObjGenerateReportButton = Constants.AtlasPaymentInOR.getProperty("GeneratePayInButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateReportButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateReportButton, ""));
            String vObjRegistrationQueueTable = Constants.AtlasPaymentInOR.getProperty("PaymentInQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjRegistrationQueueTable, ""));
        } else if (Org.equalsIgnoreCase("Payment Out") && Check.equalsIgnoreCase("Payment Out")) {
            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
            String vObjSanctionFailed = Constants.AtlasPaymentInOR.getProperty("SanctionFailed");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionFailed, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionFailed, ""));
            String vObjGenerateReportButton = Constants.AtlasPaymentOutOR.getProperty("GeneratePayInButton");
            ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(2000,0)");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjGenerateReportButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjGenerateReportButton, ""));
            String vObjRegistrationQueueTable = Constants.AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegistrationQueueTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjRegistrationQueueTable, ""));
        }

    }

    @And("^User Perform the Repeat check for Sanctions for (PaymentIn)$")
    public void userPerformTheRepeatCheckSanctions(String Pay) throws Exception {
        if (Pay.equalsIgnoreCase("PaymentIn")) {
            String vObjSanctions = Constants.AtlasPaymentInOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasPaymentInOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentInOR.getProperty("SanctionsTable");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe")) {
                LogCapture.info("Sanction check status is safe/PASS already");
            } else {
                int count = 0;
                do {
                    count = count + 1;
                    do {
                        count = count + 1;
                    } while (!Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled());
                    Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));

                } while (!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe"));
                System.out.println("Count" + count);
            }
        }
    }

    @And("^User verify (Further Payment details|Wallets|FX Detail) section$")
    public void userVerifyFurtherPaymentDetailsSection(String Value) throws Exception {
        if (Value.equalsIgnoreCase("Further Payment details")) {
            String vObjFurtherPaymentDetails = Constants.AtlasPaymentInOR.getProperty("FurtherPaymentDetails");
            Assert.assertEquals("PASS", Constants.key.click(vObjFurtherPaymentDetails, ""));
            String vObjFurtherPaymentDetailsText = Constants.AtlasPaymentInOR.getProperty("FurtherPaymentDetailsText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFurtherPaymentDetailsText, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjFurtherPaymentDetailsText, ""));
            String vObjFurtherPaymentDetailsTable = Constants.AtlasPaymentInOR.getProperty("FurtherPaymentDetailsTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFurtherPaymentDetailsTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjFurtherPaymentDetailsTable, ""));
        } else if (Value.equalsIgnoreCase("Wallets")) {
            String vObjClientWallets = Constants.AtlasPaymentInOR.getProperty("ClientWallets");
            Assert.assertEquals("PASS", Constants.key.click(vObjClientWallets, ""));
            String vObjClientWalletsTable = Constants.AtlasPaymentInOR.getProperty("ClientWalletsTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientWalletsTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjClientWalletsTable, ""));


        } else if (Value.equalsIgnoreCase("FX Detail")) {
            String vObjFxTickets = Constants.AtlasPaymentInOR.getProperty("FxTickets");
            Assert.assertEquals("PASS", Constants.key.click(vObjFxTickets, ""));
            String vObjFxTicketsTable = Constants.AtlasPaymentInOR.getProperty("FxTicketsTable");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFxTicketsTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjFxTicketsTable, ""));


        }
    }

    @And("^User is (not be able|able) to Perform the Repeat check for (Third Party Check False|Debitor Name Absent|Third Party Check True|Payment Out Queue)$")
    public void userIsNotAbleToPerformTheRepeatCheckForThirdPartyCheckFalse(String RepeatCheck, String Checks) throws Exception {
        if (RepeatCheck.equalsIgnoreCase("not be able") && Checks.equalsIgnoreCase("Third Party Check False")) {
            String vObjSanctions = Constants.AtlasPaymentInOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasPaymentInOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentInOR.getProperty("SanctionsTableStatus");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionStatus, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled() == false) {
                LogCapture.info("Repeat Check button is disabled");
            } else {
                LogCapture.info("Repeat Check button is Enabled");
                Assert.fail();
            }
            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Not Required")) {
                LogCapture.info("Status Should be displayed as Not Required");
            } else {
                LogCapture.info("Status is not displayed as 'Not Required'");
                Assert.fail();
            }

        } else if (RepeatCheck.equalsIgnoreCase("able") && Checks.equalsIgnoreCase("Third Party Check True")) {
            String vObjSanctions = Constants.AtlasPaymentInOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasPaymentInOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentInOR.getProperty("SanctionsTableStatus");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionStatus, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled() == true) {
                LogCapture.info("Repeat Check button is Enabled");
                Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
            } else {
                LogCapture.info("Repeat Check button is Disabled");
                Assert.fail();
            }

        } else if (RepeatCheck.equalsIgnoreCase("not be able") && Checks.equalsIgnoreCase("Debitor Name Absent")) {
            String vObjSanctions = Constants.AtlasPaymentInOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasPaymentInOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentInOR.getProperty("SanctionsTableStatus");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionStatus, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled() == false) {
                LogCapture.info("Repeat Check button is disabled");
            } else {
                LogCapture.info("Repeat Check button is Enabled");
                Assert.fail();
            }
//            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Not Required")) {
//                LogCapture.info("Status Should be displayed as Not Required");
//            } else {
//                LogCapture.info("Status is not displayed as 'Not Required'");
//                Assert.fail();
//            }
        } else if (RepeatCheck.equalsIgnoreCase("able") && Checks.equalsIgnoreCase("Payment Out Queue")) {
            String vObjSanctions = Constants.AtlasPaymentOutOR.getProperty("SanctionBeneficiary");
            String vObjRepeatCheck = Constants.AtlasPaymentOutOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasPaymentOutOR.getProperty("SanctionTableStatus");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSanctionStatus, ""));
            System.out.println(Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText());
            if (Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled() == true) {
                LogCapture.info("Repeat Check button is Enabled");
                Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
            } else {
                LogCapture.info("Repeat Check button is Disabled");
                Assert.fail();
            }

        }

    }

    @And("^User verify the WatchList and PaymentMethod$")
    public void userVerifyTheWatchListAndPaymentMethod() throws Exception {
        String vObjPaymentMethod = Constants.AtlasPaymentInOR.getProperty("PaymentMethod");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjPaymentMethod, "WALLET"));
        String vObjWatchList = Constants.AtlasPaymentInOR.getProperty("WatchList");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjWatchList, "Fraudpredict high risk of fraud\n" +
                "High Risk Country"));

    }

    @And("^User verify the PaymentMethod and WatchList$")
    public void userVerifyWatchListAndPaymentMethod() throws Exception {
        String vObjPaymentMethod = Constants.AtlasPaymentInOR.getProperty("PaymentMethod");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjPaymentMethod, "WALLET"));
        String vObjWatchList = Constants.AtlasPaymentInOR.getProperty("WatchList");
        if (Constants.driver.findElement(By.xpath(vObjWatchList)).getText().isEmpty()) {
            LogCapture.info("WatchList is blank");
        }
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjWatchList, "null"));
    }

    @And("^User selects reason for (Reject|Seize) \"([^\"]*)\"$")
    public void userSelectsRejectReason(String Reason, String ReasonValue) throws Throwable {
        if (Reason.equalsIgnoreCase("Reject")) {
            String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReasonDropDown");
            String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReasonValues");
            Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
            Constants.key.pause("2", "");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i < dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@id='regDetails_contactStatusReasons']//li[" + i + "]//label[1]")).getText();
                if (vdata.equals(ReasonValue)) {
                    Constants.driver.findElement(By.xpath("//*[@id='regDetails_contactStatusReasons']//li[" + i + "]//label[1]")).click();
                    break;
                }
            }
        }
    }

    @And("^User verify the WatchList \"([^\"]*)\"$")
    public void userVerifyTheWatchList(String WatchList) throws Throwable {
        String vObjWatchList = Constants.AtlasPaymentInOR.getProperty("WatchList");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjWatchList, WatchList));
    }

    @And("^User verify the (Blacklist Check|Country Check Fail)$")
    public void userVerifyTheBlacklistCheck(String status) throws Exception {
        if (status.equalsIgnoreCase("Blacklist Check")) {
            String vObjBlackListCheck = Constants.AtlasPaymentOutOR.getProperty("BlackListCheck");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlackListCheck, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlackListCheck, "clear"));

        } else if (status.equalsIgnoreCase("Country Check Fail")) {
            String vObjCountryCheck = Constants.AtlasPaymentOutOR.getProperty("CountryCheck");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCountryCheck, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCountryCheck, ""));
            String vObjStatusCheck = Constants.AtlasPaymentOutOR.getProperty("StatusCheck");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatusCheck, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatusCheck, "Fail (Sanctioned Country)"));

        }
    }

    @Then("^Verify the Activity Log has been updated for (Payment Out Queue|Payment In Queue|Registration Queue) for (Reject|Clear|Sanction|Seize)$")
    public void verifyTheActivityLogIsUpdatedForPaymentOutQueue(String Log, String Log1) throws Exception {
        if (Log.equalsIgnoreCase("Payment Out Queue") && Log1.equalsIgnoreCase("Reject")) {
            String vObjActivityLog = Constants.AtlasPaymentOutOR.getProperty("ActivityLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjActivityLog, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjActivityLog, ""));
            String vObjActivityLogTable = Constants.AtlasPaymentOutOR.getProperty("ActivityLogTable");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vObjActivityLogTable));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String Activity = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[4]")).getText();
                String ActivityType = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[5]")).getText();
                String Comment = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[6]")).getText();
                if (Activity.equalsIgnoreCase("Payment out status modified from HOLD to REJECT") && ActivityType.equalsIgnoreCase("Paymentout status update") && Comment.equalsIgnoreCase(Comments)) {
                    LogCapture.info("Activity Log has been updated Successfully" + Activity + "::" + ActivityType + "::" + Comment);
                    break;
                } else {
                    LogCapture.info("Activity Log has been updated Successfully" + Activity + "::" + ActivityType + "::" + Comment);
                    Assert.fail();
                }
            }

        } else if (Log.equalsIgnoreCase("Payment Out Queue") && Log1.equalsIgnoreCase("Clear")) {
            String vObjActivityLog = Constants.AtlasPaymentOutOR.getProperty("ActivityLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjActivityLog, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjActivityLog, ""));
            String vObjActivityLogTable = Constants.AtlasPaymentOutOR.getProperty("ActivityLogTable");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vObjActivityLogTable));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String Activity = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[4]")).getText();
                String ActivityType = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[5]")).getText();
                String Comment = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[6]")).getText();
                if (Activity.equalsIgnoreCase("Payment out status modified from HOLD to CLEAR") && ActivityType.equalsIgnoreCase("Paymentout status update") && Comment.equalsIgnoreCase(Comments)) {
                    LogCapture.info("Activity Log has been updated Successfully" + Activity + "::" + ActivityType + "::" + Comment);
                    break;
                } else {
                    LogCapture.info("Activity Log has been updated Successfully" + Activity + "::" + ActivityType + "::" + Comment);
                    Assert.fail();
                }
            }

        } else if (Log.equalsIgnoreCase("Payment Out Queue") && Log1.equalsIgnoreCase("Sanction")) {
            String vObjActivityLog = Constants.AtlasPaymentOutOR.getProperty("ActivityLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjActivityLog, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjActivityLog, ""));
            String vObjActivityLogTable = Constants.AtlasPaymentOutOR.getProperty("ActivityLogTable");
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vObjActivityLogTable));
            System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 1; i <= dropdown_list.size(); i++) {
                // String Activity = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[4]")).getText();
                String ActivityType = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[5]")).getText();
                String Comment = Constants.driver.findElement(By.xpath("//*[@id='activityLog']//tr[" + i + "]//td[6]")).getText();
                if (ActivityType.equalsIgnoreCase("Paymentout sanction repeat") && Comment.equalsIgnoreCase("-")) {
                    LogCapture.info("Activity Log has been updated Successfully" + "::" + ActivityType + "::" + Comment);
                    break;
                } else {
                    LogCapture.info("Activity Log has been updated Successfully" + "::" + ActivityType + "::" + Comment);
                    Assert.fail();
                }
            }

        }
    }

    @And("^User delete any one of the report if the report has more than 5 for (Payment Out Queue|Payment In Queue|Registration Report)$")
    public void userDeleteTheReportIfTheReportHasMoreThan(String Report) throws Exception {
        String vArrowDDClick = Constants.AtlasRegistrationOR.getProperty("SelectReportDropDown");
        String vReasonContainer = Constants.AtlasRegistrationOR.getProperty("SelectReportValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vArrowDDClick, ""));
        Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
        Constants.key.pause("3", "");
        List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(vReasonContainer));
        System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
        if (dropdown_list.size() == 5) {
            for (int i = 1; i <= dropdown_list.size(); i++) {
                String vdata = Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).getText();
                System.out.println(vdata);
                Constants.driver.findElement(By.xpath("//*[@class='clickpanel__content--visible']//li[" + i + "]//label[1]")).click();
                Constants.key.pause("3", "");
                String vObjDeleteButton = Constants.AtlasRegistrationOR.getProperty("DeleteButton");
                ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteButton, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjDeleteButton, ""));
                Constants.key.pause("2", "");
                String vObjConfirmDeleteTextMsg = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteTextMsg");
                String vObjConfirmDeleteOK = Constants.AtlasRegistrationOR.getProperty("ConfirmDeleteOK");
                String SearchName = Constants.driver.findElement(By.xpath(vObjConfirmDeleteTextMsg)).getText();
                System.out.println("Search Name::" + SearchName);
                Assert.assertEquals("PASS", Constants.key.click(vObjConfirmDeleteOK, ""));
                Constants.key.pause("5", "");
                if (Report.equalsIgnoreCase("Payment Out Queue")) {
                    LogCapture.info("User is selecting Payment Out Queue hyperlink from dashboard..");
                    String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                    String vObjAtlasPaymentOutTabQueue = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutTabQueue");
                    String vObjAtlasPaymentOutQueueText = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutQueueText");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasPaymentOutTabQueue, ""));
                    String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
                } else if (Report.equalsIgnoreCase("Payment In Queue")) {
                    LogCapture.info("User is selecting Payment In Queue hyperlink from dashboard..");
                    String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                    String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("AtlasPaymentInTabQueue");
                    String vObjAtlasPaymentInQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasPaymentInQueueText");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
                    String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
                    Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
                } else if (Report.equalsIgnoreCase("Registration Report")) {
                    LogCapture.info("User is selecting Registration Report hyperlink from dashboard..");
                    String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
                    String vObjAtlasRegistrationReport = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReport");
                    String vObjAtlasRegistrationReportText = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReportText");
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
                    Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                    Assert.assertEquals("PASS", Constants.key.click(vObjAtlasRegistrationReport, ""));
                    Constants.key.pause("3", "");
                }
                String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, "goerge123@mailinator.com"));
                String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
                Assert.assertEquals("PASS", Constants.key.pause("3", ""));
                break;

            }

        } else {
            LogCapture.info("Saved Report has Less than 5");
        }

    }
}










