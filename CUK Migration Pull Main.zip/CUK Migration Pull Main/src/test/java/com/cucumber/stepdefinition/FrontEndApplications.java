package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.utility.LogCapture;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.IOException;

import java.util.List;
import java.util.Map;
import java.util.Objects;

//import com.utilities.Log;
//import com.sun.org.apache.bcel.internal.Const;
//import com.utilities.Log;
/*import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.logging.Log;*/

public class FrontEndApplications {
    String vSignUp_EmailID;
    String vSignUp_SecondaryEmailID;

    @Given("^User launched application through \"([^\"]*)\"$")
    public void userLaunchedApplicationThrough(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        Constants.JenkinsBrowser= (Objects.equals(Constants.JenkinsBrowser, "null")) ? "" : "";
        String vBrowserName = Constants.CONFIG.getProperty("browser");

        try {
            if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                vBrowserName = Constants.JenkinsBrowser;
                LogCapture.info("Browser is :" + vBrowserName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));
        LogCapture.info("Browser is :" + vBrowserName);
    }

    @Given("^User launched application with Default Download Directory through \"([^\"]*)\"$")
    public void userLaunchedApplicationWithDefaultDownloadDirectory(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        String vBrowser = Constants.CONFIG.getProperty("browser");
        Assert.assertTrue(Constants.key.openBrowserWithDefaultDownloadDirectory("", vBrowser));
    }


    @And("^User launched application with \"([^\"]*)\"$")
    public void userLaunchedApplicationWith(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        String vBrowser = Constants.CONFIG.getProperty("browser");
        Assert.assertTrue(Constants.key.openBrowser("", vBrowser));
    }
    /*@And("^User navigate to FCG portal \"([^\"]*)\"$")
    public void userNavigateToFCGPortal(String vUrl) throws Throwable {
        LogCapture.info("FCG Portal is loading....");
        String url = Constants.CONFIG.getProperty(vUrl);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
    }*/

    @When("^I enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click login button$")
    public void iEnterUserNamePasswordAndClickLoginButton(String userName, String password) throws Throwable {

        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.loginPageOR.getProperty("FCG_Username");
        String vObjPass = Constants.loginPageOR.getProperty("FCG_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.loginPageOR.getProperty("LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @Then("^I landed on Dashboard page successfully$")
    public void iLandedOnDashboardPageSuccessfully() throws Exception {
        LogCapture.info("Dashboard loading ......");
        Constants.key.pause("2", "");
        String vobjectDashboard = Constants.DashboardOR.getProperty("DashboardORText");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Check the exchange rate"));
    }

    @Then("^error message is displayed on Login page$")
    public void errorMessageIsDisplayedOnLognPage() throws Exception {
        String vExpected = "Either your email or your password is incorrect. Please re-enter your correct credentials. If you are not registered with us already, please click here to register with us.";
        String vErrorObj = Constants.loginPageOR.getProperty("ErrorMessageLogin");
        LogCapture.info("Validating error message...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vErrorObj, vExpected));
    }

    @When("^I enter UserName \"([^\"]*)\" incorrect password \"([^\"]*)\" and click login button$")
    public void iEnterUserNameIncorrectPasswordAndClickLoginButton(String usernName, String inPassword) throws Throwable {
        LogCapture.info("Validating incorrect credentials.......");
        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.loginPageOR.getProperty("FCG_Username");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        String vObjPass = Constants.loginPageOR.getProperty("FCG_Password");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));
        String vObjLoginButton = Constants.loginPageOR.getProperty("LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));


    }

    @And("^User Select buying currency\"([^\"]*)\" from I intend to buy drop down\\.$")
    public void userSelectBuyingCurrencyFromIIntendToBuyDropDown(String buyValue) throws Throwable {
        LogCapture.info("Selecting Buying Currency..." + buyValue);
        String vIntentBuyDroDownClick = Constants.NewRateAlertOR.getProperty("IntentToBuyDDclick");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vIntentBuyDroDownClick, ""));
        String vIntentBuyDroDownaddValue = Constants.NewRateAlertOR.getProperty("IntendToBuySearchAdd");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vIntentBuyDroDownaddValue, buyValue));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vIntentBuyDroDownaddValue, "enter"));


        ////Assert.assertEquals("PASS", Constants.key.sendkeyboardStroke("", "enter"));


    }

    @Then("^User click on Create new Rate Alert option on dashboard\\.$")
    public void userClickOnCreateNewRateAlertOptionOnDashboard() throws Exception {
        LogCapture.info("Clicking New rate Alert option .......");
        String vNewRateAlert = Constants.DashboardOR.getProperty("CrNewRateButton");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vNewRateAlert, ""));
    }

    @And("^Select selling currency\"([^\"]*)\" from I intend to sell drop down\\.$")
    public void selectSellingCurrencyFromIIntendToSellDropDown(String sellValue) throws Throwable {

        LogCapture.info("Selecting selling Currency..." + sellValue);
        String vIntentSellDroDownClick = Constants.NewRateAlertOR.getProperty("vIntentSellDroDownClick");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vIntentSellDroDownClick, ""));
        String vIntentSellDroDownaddValue = Constants.NewRateAlertOR.getProperty("IntendToSellSearchAdd");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vIntentSellDroDownaddValue, sellValue));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vIntentSellDroDownaddValue, "enter"));
    }

    @When("^User enter the amount\"([^\"]*)\" to buy and click on Get Rate button$")
    public void userEnterTheAmountToyBuyAndClickOnGetRateButton(String buyAmount) throws Throwable {
        LogCapture.info("Entering the amount to buy .....");
        String vBuyInputObject = Constants.NewRateAlertOR.getProperty("BuyInputText");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vBuyInputObject, buyAmount));
        String vGetRateButtonObj = Constants.NewRateAlertOR.getProperty("GetRateButton");
        Assert.assertEquals("PASS", Constants.key.click(vGetRateButtonObj, ""));


    }

    @Then("^Current Rate is populated successfully$")
    public void currentRateIsPopulatedSuccessfully() throws Exception {
        LogCapture.info("Checking for current rate ....");
        String vCurrentRateValue = Constants.NewRateAlertOR.getProperty("CurrentRateValue");
        Constants.key.pause("4", "");

        Assert.assertEquals("PASS", Constants.key.exist(vCurrentRateValue, ""));


    }

    @Then("^User enter the Target Rate and click on (Continue|Update target rate) button$")
    public void userEnterTheTargetRateAndClickOnContinueButton(String button) throws Throwable {
        LogCapture.info("Target Rate validation.....");
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        String vTargetRate = Constants.NewRateAlertOR.getProperty("TargetRateValue");
        //Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        String vCurrentRateValue = Constants.NewRateAlertOR.getProperty("CurrentRateValue");
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));

        String vCurrentRateValNum = Constants.driver.findElement(By.xpath(vCurrentRateValue)).getAttribute("value");
        //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCurrentRateValNum, ""));
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCurrentRateValNum, ""));
        double d = Double.parseDouble(vCurrentRateValNum);
        double vDoubleCurrRate = ((10 * d / 100) + d);
        String vTargetValueCalculated = Double.toString(vDoubleCurrRate);
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vTargetRate, vTargetValueCalculated));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        if (button.equals("Continue")) {
            LogCapture.info("User clicking " + button + " button...");
            Assert.assertEquals("PASS", Constants.key.click(Constants.NewRateAlertOR.getProperty("ContinueButton"), ""));
        } else if (button.equals("Update target rate")) {
            LogCapture.info("User clicking " + button + " button...");
            Assert.assertEquals("PASS", Constants.key.click(Constants.NewRateAlertOR.getProperty("UpdateTargetRate"), ""));
        }


    }

    @And("^Pay this much less amount is displayed successfully$")
    public void payThisMuchLessAmountIsDisplayedSuccessfully() throws Exception {
        LogCapture.info("Check for Pay this much less field.......");
        String vPaylessObj = Constants.NewRateAlertOR.getProperty("PayThisMuchLessField");
        Assert.assertEquals("PASS", Constants.key.exist(vPaylessObj, ""));
    }

    @When("^User select Alert me via \"([^\"]*)\" drop down and click on Create alert button$")
    public void userSelectAlertMeViaDropDownAndClickOnCreateAlertButton(String arg0) throws Throwable {
        LogCapture.info("Setting Alert options and creating Alert Button......");
        String vAlertMeDD = Constants.NewRateAlertOR.getProperty("AlertMeViaDDclick");
        Assert.assertEquals("PASS", Constants.key.click(vAlertMeDD, ""));
        String vAlertMeVal = Constants.NewRateAlertOR.getProperty("AlertMeViaDDAdd");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vAlertMeVal, arg0));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vAlertMeVal, "enter"));


        ////Assert.assertEquals("PASS", Constants.key.sendkeyboardStroke("", "enter"));

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(Constants.NewRateAlertOR.getProperty("CreateAlertButton"), ""));

    }

    @Then("^(FCG|CD|TORFX|TMO|Ramsdens|TORAU|TORSINGAPORE|HL) success message of (adding alert|edit alert|delete alert) is displayed$")
    public void successMessageOfAddingAlertIsDisplayed(String application, String message) throws Exception {
        //LogCapture.info("Checking "+message+" success message.....");
        Constants.key.pause("2", "");
        if (application.equalsIgnoreCase("FCG")) {
            if (message.equals("adding alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateSuccessObj = Constants.NewRateAlertOR.getProperty("RateAlertSuccessfullyMsg");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateSuccessObj, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateSuccessObj, "Thanks, your rate alert has been added successfully."));
            } else if (message.equals("edit alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateAlertUpdateMessage = Constants.NewRateAlertOR.getProperty("RateAlertUpdateMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateAlertUpdateMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateAlertUpdateMessage, "Thanks, your rate alert has been updated successfully."));
            } else if (message.equals("delete alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, you have successfully deleted this Rate Alert."));
            }
        } else if (application.equalsIgnoreCase("CD")) {
            if (message.equals("adding alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateSuccessObj = Constants.NewRateAlertOR.getProperty("RateAlertSuccessfullyMsg");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateSuccessObj, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateSuccessObj, "Thanks, your rate alert has been added successfully."));
            } else if (message.equals("edit alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateAlertUpdateMessage = Constants.NewRateAlertOR.getProperty("CD_RateAlertUpdateMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateAlertUpdateMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateAlertUpdateMessage, "Thanks, Your rate alert has been updated successfully."));
            } else if (message.equals("delete alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("CD_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            }
        } else if (application.equalsIgnoreCase("TORFX")) {
            if (message.equals("adding alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateSuccessObj = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertSuccessfullyMsg");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateSuccessObj, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateSuccessObj, "Thanks, Your rate alert has been added successfully."));
            } else if (message.equals("edit alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateAlertUpdateMessage = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertUpdateMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateAlertUpdateMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateAlertUpdateMessage, "Thanks, Your rate alert has been updated successfully."));
            } else if (message.equals("delete alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            }
        } else if (application.equalsIgnoreCase("TMO")) {
            //Below code is for TMO. As the objects are same as TORFX no need to change the properties
            if (message.equals("adding alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateSuccessObj = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertSuccessfullyMsg");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateSuccessObj, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateSuccessObj, "Thanks, Your rate alert has been added successfully."));
            } else if (message.equals("edit alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateAlertUpdateMessage = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertUpdateMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateAlertUpdateMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateAlertUpdateMessage, "Thanks, Your rate alert has been updated successfully."));
            } else if (message.equals("delete alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            }
        } else if (application.equalsIgnoreCase("Ramsdens")) {
            if (message.equals("adding alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateSuccessObj = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertSuccessfullyMsg");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateSuccessObj, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateSuccessObj, "Thanks, Your rate alert has been added successfully."));
            } else if (message.equals("edit alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateAlertUpdateMessage = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertUpdateMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateAlertUpdateMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateAlertUpdateMessage, "Thanks, Your rate alert has been updated successfully."));
            } else if (message.equals("delete alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            }
        } else if (application.equalsIgnoreCase("TORAU")) {
            if (message.equals("adding alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateSuccessObj = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertSuccessfullyMsg");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateSuccessObj, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateSuccessObj, "Thanks, Your rate alert has been added successfully."));
            } else if (message.equals("edit alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateAlertUpdateMessage = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertUpdateMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateAlertUpdateMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateAlertUpdateMessage, "Thanks, Your rate alert has been updated successfully."));
            } else if (message.equals("delete alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            }
        } else if (application.equalsIgnoreCase("TORSINGAPORE")) {
            if (message.equals("adding alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateSuccessObj = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertSuccessfullyMsg");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateSuccessObj, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateSuccessObj, "Thanks, Your rate alert has been added successfully."));
            } else if (message.equals("edit alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateAlertUpdateMessage = Constants.NewRateAlertOR.getProperty("TORFX_RateAlertUpdateMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateAlertUpdateMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateAlertUpdateMessage, "Thanks, Your rate alert has been updated successfully."));
            } else if (message.equals("delete alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            }
        } else if (application.equalsIgnoreCase("HL")) {
            if (message.equals("adding alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateSuccessObj = Constants.NewRateAlertOR.getProperty("RateAlertSuccessfullyMsg");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateSuccessObj, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateSuccessObj, "Thanks, your rate alert has been added successfully."));
            } else if (message.equals("edit alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vRateAlertUpdateMessage = Constants.NewRateAlertOR.getProperty("CD_RateAlertUpdateMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRateAlertUpdateMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vRateAlertUpdateMessage, "Thanks, Your rate alert has been updated successfully."));
            } else if (message.equals("delete alert")) {
                LogCapture.info("Checking " + message + " success message.....");
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("CD_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            }
        }

    }

    @Then("^User clicks on Top up your wallet section$")
    public void user_clicks_on_Top_up_your_wallet_section() throws Throwable {
        LogCapture.info("Selecting Top Up Wallet section......");
        String vObjTopUpWalletLink = Constants.TopupWalletOR.getProperty("TopUpWalletLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjTopUpWalletLink, ""));
        Constants.key.pause("2", "");

    }

    @When("^User selects Payment currency \"(.*?)\" Select wallet \"(.*?)\"$")
    public void user_selects_Payment_currency_Select_wallet(String payCurrency, String selectWallet) throws Throwable {
        LogCapture.info("Selecting Payment Curreny and Wallet......");
        String vObjPaymentCurrency = Constants.TopupWalletOR.getProperty("PaymentCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentCurrency, ""));
        String vObjPaySearchCurrency = Constants.TopupWalletOR.getProperty("PayCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPaySearchCurrency, payCurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPaySearchCurrency, "enter"));
        String vObjSelectWallet = Constants.TopupWalletOR.getProperty("SelectWallet");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectWallet, ""));
        String vObjBuySearchCurrency = Constants.TopupWalletOR.getProperty("BuyCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuySearchCurrency, selectWallet));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuySearchCurrency, "enter"));

    }

    @When("^User enters (Payment|Wallet) currency Amount \"(.*?)\" and clicks continue button$")
    public void user_enters_Payment_currency_Amount_and_clicks_countinue_button(String Currency, String amount) throws Throwable {
        LogCapture.info("Entering Currency and clicking continue button....");
        if (Currency.equals("Payment")) {
            String vObjPayCurrencyAMT = Constants.TopupWalletOR.getProperty("PaymentCurrencyAMT");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayCurrencyAMT, amount));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayCurrencyAMT, "enter"));
        } else if (Currency.equals("Wallet")) {
            String vObjWalletCurrencyAMT = Constants.TopupWalletOR.getProperty("WalletCurrencyAMT");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjWalletCurrencyAMT, amount));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjWalletCurrencyAMT, "enter"));
        }


        String vObjButtonBuyCur1 = Constants.TopupWalletOR.getProperty("ButtonBuyCur1");
        Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur1, ""));

    }

    @When("^User selects Payment method \"(.*?)\" and clicks countinue button$")
    public void user_selects_Payment_method_and_clicks_countinue_button(String payMethod) throws Throwable {
        LogCapture.info("Select payment method and click Continue....");
        String vObjPaymentMethod = Constants.TopupWalletOR.getProperty("PaymentMethod");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
        String vObjFromBalance = Constants.TopupWalletOR.getProperty("FromBalance");
        Assert.assertEquals("PASS", Constants.key.click(vObjFromBalance, ""));
        String vObjButtonBuyCur2 = Constants.TopupWalletOR.getProperty("ButtonBuyCur2");
        Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur2, ""));
        Constants.key.pause("2", "");

    }

    @When("^User clicks on Confirm button after validating details entered$")
    public void user_clicks_on_Confirm_button_after_validating_details_entered() throws Throwable {
        LogCapture.info("Confirming validations.....");
        //String vObjConfirmYourPurchase = Constants.DashboardOR.getProperty("ConfirmYourPurchase");
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjConfirmYourPurchase,"Confirm your purchase"));
        String vObjButtonPurchaseConfirmation = Constants.TopupWalletOR.getProperty("ButtonPurchaseConfirmation");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjButtonPurchaseConfirmation, ""));
//        Assert.assertEquals("PASS", Constants.key.click(vObjButtonPurchaseConfirmation, ""));
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjButtonPurchaseConfirmation, ""));
//        Constants.key.pause("2", "");

    }

    @Then("^User should sucessfully be able to top up wallet and click on Back to dashboard link$")
    public void user_should_sucessfully_be_able_to_top_up_wallet_and_click_on_Back_to_dashboard_link() throws Throwable {
        LogCapture.info("Top Up Wallet validation...");
        String vObjSuccessfullTopUpMSG = Constants.TopupWalletOR.getProperty("SuccessfullTopUpMSG");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjSuccessfullTopUpMSG, "Top-up details"));
        String vObjLinkBackToDashboard = Constants.TopupWalletOR.getProperty("LinkBackToDashboard");
        Assert.assertEquals("PASS", Constants.key.click(vObjLinkBackToDashboard, ""));

    }

    @Then("^User click on Transfer section$")
    public void user_click_on_Transfer_section() throws Throwable {
        LogCapture.info("Transfer Section verification.......");
        String vObjTransferLink = Constants.MakeTransferOR.getProperty("TransferLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjTransferLink, ""));

    }

    @Then("^User clicks on (Select|Transfer|Pay) link for relevant (CAD|EUR|GBP) \"([^\"]*)\" recipient$")
    public void user_clicks_on_Select_link_for_relevant_CAD_recipent(String page, String type, String recipient) throws Throwable {
        LogCapture.info("Selecting Benificiary......");

        if (page.equals("Select")) {
            Assert.assertEquals("PASS", Constants.key.SelectRecipient("", recipient));
        } else if (page.equals("Transfer")) {
            Assert.assertEquals("PASS", Constants.key.RecipientTransfer("", recipient));
        } else if (page.equals("Pay")) {
            Assert.assertEquals("PASS", Constants.key.RecipientPay("", recipient));
        }

    }

    @When("^User selects you Pay \"(.*?)\" Amount \"(.*?)\"$")
    public void user_selects_you_Pay_Amount(String youPay, String amount) throws Throwable {
        LogCapture.info("Amount selection......");
        String vObjYouPay = Constants.MakeTransferOR.getProperty("YouPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYouPay, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjYouPay, ""));

        String vObjYouPaySearch = Constants.MakeTransferOR.getProperty("YouPaySearch");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYouPaySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjYouPaySearch, youPay));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjYouPaySearch, "enter"));

        String vObjSellInput = Constants.MakeTransferOR.getProperty("SellInput");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellInput, amount));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellInput, "enter"));

    }

    @When("^User selects you Pay \"(.*?)\" Send to Recipient Amount \"(.*?)\"$")
    public void user_selects_you_Pay_Send_to_RecipientAmount(String youPay, String amount) throws Throwable {
        LogCapture.info("Amount selection......");
        String vObjYouPay = Constants.MakeTransferOR.getProperty("YouPay");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjYouPay, ""));

        String vObjYouPaySearch = Constants.MakeTransferOR.getProperty("YouPaySearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjYouPaySearch, youPay));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjYouPaySearch, "enter"));

        String vObjBuyInput = Constants.MakeTransferOR.getProperty("BuyInput");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyInput, amount));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyInput, "enter"));

    }

    @When("^User selects Reason for this transfer \"(.*?)\" enters Recipient reference \"(.*?)\"$")
    public void user_selects_Reason_for_this_transfer_enters_Recipient_reference(String reason, String reference) throws Throwable {
        LogCapture.info("Reason for transfer and references.....");
        String vObjReasonForTransfer = Constants.MakeTransferOR.getProperty("ReasonForTransfer");
        Assert.assertEquals("PASS", Constants.key.click(vObjReasonForTransfer, ""));

        String vObjReasonForTransferSearch = Constants.MakeTransferOR.getProperty("ReasonForTransferSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjReasonForTransferSearch, reason));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjReasonForTransferSearch, "enter"));

        String vObjRecipientReference = Constants.MakeTransferOR.getProperty("RecipientReference");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRecipientReference, reference));

        String vObjButtonContinue = Constants.MakeTransferOR.getProperty("ButtonContinue");
        Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinue, ""));

    }

    @When("^User selects Payment method \"(.*?)\" and clicks on Continue button to (Make a transfer|Topup Wallet)$")
    public void user_selects_Payment_method_and_clicks_on_Continue_button(String method, String transaction) throws Throwable {
        LogCapture.info("Selecting Payment method.....");
        String vObjPaymentMethod = Constants.MakeTransferOR.getProperty("PaymentMethod");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentMethod, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
        if (transaction.equals("Make a transfer")) {
            if (method.equals("Balance")) {
                LogCapture.info("Payment method selected as " + method + "method for make a transfer");
                String vObjFromBalance = Constants.MakeTransferOR.getProperty("FromBalance");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromBalance, ""));
                String vObjButtonContinuetoSubmit = Constants.MakeTransferOR.getProperty("ButtonContinuetoSubmit");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinuetoSubmit, ""));
            } else if (method.equals("DebitCard")) {
                LogCapture.info("Payment method selected as " + method + "method");
                String vObjFromDebitCard = Constants.MakeTransferOR.getProperty("FromDebitCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromDebitCard, ""));
            } else if (method.equals("BankTransfer")) {
                LogCapture.info("Payment method selected as " + method + "method");
                String vObjFromBankTransfer = Constants.MakeTransferOR.getProperty("FromBankTransfer");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromBankTransfer, ""));
                //Just for SG LE's Source of funds is additional field hence it is handled with below condition
                LogCapture.info("Source of Funds selected as Salary");
                String vObjSourceOfFunds = Constants.MakeTransferOR.getProperty("SourceOfFunds");
                String vElementExist = Constants.key.verifyElementProperties(vObjSourceOfFunds, "visible");
                if (vElementExist.equals("PASS")) {
                    Assert.assertEquals("PASS", Constants.key.selectList(vObjSourceOfFunds, "Salary"));

                } else {
                }
                String vObjButtonContinuetoSubmit = Constants.MakeTransferOR.getProperty("ButtonContinuetoSubmit");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinuetoSubmit, ""));
            } else if (method.equals("Wallet")) {
                LogCapture.info("Payment method selected as " + method + "method for make a transfer");
                String vObjFromWallet = Constants.MakeTransferOR.getProperty("FromWallet");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromWallet, ""));
                String vObjButtonContinuetoSubmit = Constants.MakeTransferOR.getProperty("ButtonContinuetoSubmit");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinuetoSubmit, ""));
            }
        } else if (transaction.equals("Topup Wallet")) {
            if (method.equals("Balance")) {
                LogCapture.info("Payment method selected as " + method + "method for topup wallet");
                String vObjFromBalance = Constants.MakeTransferOR.getProperty("FromBalance");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromBalance, ""));
                String vObjButtonBuyCur2 = Constants.TopupWalletOR.getProperty("ButtonBuyCur2");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur2, ""));
            } else if (method.equals("DebitCard")) {
                LogCapture.info("Payment method selected as " + method + "method");
                String vObjFromDebitCard = Constants.MakeTransferOR.getProperty("FromDebitCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromDebitCard, ""));
            } else if (method.equals("BankTransfer")) {
                LogCapture.info("Payment method selected as " + method + "method");
                String vObjFromBankTransfer = Constants.MakeTransferOR.getProperty("FromBankTransfer");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromBankTransfer, ""));
                //Just for SG LE's Source of funds is additional field hence it is handled with below condition
                LogCapture.info("Source of Funds selected as Salary");
                String vObjSourceOfFunds = Constants.MakeTransferOR.getProperty("SourceOfFunds");
                String vElementExist = Constants.key.verifyElementProperties(vObjSourceOfFunds, "visible");
                if (vElementExist.equals("PASS")) {
                    Assert.assertEquals("PASS", Constants.key.selectList(vObjSourceOfFunds, "Salary"));

                } else {
                }
                String vObjButtonBuyCur2 = Constants.TopupWalletOR.getProperty("ButtonBuyCur2");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur2, ""));
            }

        }
        Constants.key.pause("5", "");
    }

    @When("^User clicks on Confirm button after validating details entered for transfer$")
    public void user_clicks_on_Confirm_button_after_validating_details_entered_for_transfer() throws Throwable {
        LogCapture.info("Confirming post validations.....");
        String vObjConfirmButton = Constants.MakeTransferOR.getProperty("ConfirmButton");
//        Constants.key.pause("5", "");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjConfirmButton, ""));
//        Assert.assertEquals("PASS", Constants.key.click(vObjConfirmButton, ""));
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjConfirmButton, ""));
        Constants.key.pause("10", "");

    }

    @Then("^User should successfully be able (make a transfer|top up wallet) and click on Back to dashboard link$")
    public void user_should_sucessfully_be_able_make_a_transfer_and_click_on_Back_to_dashboard_link(String page) throws Throwable {
        LogCapture.info("Transfer success Validation.....");
        String vObjLinkBackToDashboard = Constants.MakeTransferOR.getProperty("LinkBackToDashboard");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLinkBackToDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjLinkBackToDashboard, ""));


    }

    @And("^User navigate to (FCG|TORFX|TORFXOZ|Ramsdens|TMO|CD|TORAU|TORSINGAPORE|HL|NGOPAdmin) portal \"([^\"]*)\"$")
    public void user_navigate_to_TORFX_portal(String application, String vUrl) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (application.equals("TORFX")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("FCG")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("TORFXOZ")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("Ramsdens")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("TMO")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("CD")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            Constants.key.pause("4", "");
        } else if (application.equals("TORAU")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("TORSINGAPORE")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("HL")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            Constants.key.pause("4", "");
            LogCapture.info(url);
        } else if (application.equals("NGOPAdmin")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            Constants.key.pause("2", "");
        } else {
            LogCapture.info("Organization not found");
        }

    }


    @When("^User enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click login button$")
    public void userEnterUserNamePasswordAndClickLoginButton(String userName, String password) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.loginPageOR.getProperty("FCG_Username");
        String vObjPass = Constants.loginPageOR.getProperty("FCG_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.loginPageOR.getProperty("LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));

    }

    @Then("^User landed on (English|French) Dashboard page successfully$")
    public void userLandedOnEnglishDashboardPageSuccessfully(String lang) throws Exception {
        LogCapture.info(lang + " Dashboard loading ......");
        if (lang.equalsIgnoreCase("English")) {
            Constants.key.pause("4", "");
            String vobjectDashboard = Constants.DashboardOR.getProperty("DashboardORText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Check the exchange rate"));
        } else if (lang.equalsIgnoreCase("French")) {
            Constants.key.pause("4", "");

            String vobjectDashboard = Constants.FrenchDashboardOR.getProperty("DashboardORFrenchText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Vérifiez le taux de change"));
        }

    }

    @When("^User enter UserName \"([^\"]*)\" incorrect password \"([^\"]*)\" and click login button$")
    public void userEnterUserNameIncorrectPasswordAndClickLoginButton(String usernName, String inPassword) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Validating incorrect credentials.......");
        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.loginPageOR.getProperty("FCG_Username");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        String vObjPass = Constants.loginPageOR.getProperty("FCG_Password");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));
        String vObjLoginButton = Constants.loginPageOR.getProperty("LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @And("^User click on (Transfer now|Make a transfer) button on Dashboard$")
    public void userClickOnTransferNowButtonOnDashboard(String name) throws Exception {
        if (name.equals("Transfer now")) {
            LogCapture.info("User Clicking on Transfer now button on dashboard...");
            String vTransfNow = Constants.DashboardOR.getProperty("TransferNowButton");
            Assert.assertEquals("PASS", Constants.key.click(vTransfNow, ""));
        } else if (name.equals("Make a transfer")) {
            LogCapture.info("User Clicking on Transfer now button on dashboard...");
            String vTransfNow = Constants.DashboardOR.getProperty("MakeATransferButton");
            Assert.assertEquals("PASS", Constants.key.click(vTransfNow, ""));

        }

    }

    @Then("^User is navigated to (Transfer|Make a transfer) Section with recipients displayed$")
    public void userIsNavigatedToTransferSectionWithRecipientsDisplayed(String section) throws Exception {
        if (section.equals("Transfer")) {
            LogCapture.info("Navigating to Transfer section with list of receipents displayed...");
            String vTH = Constants.MakeTransferOR.getProperty("TransferPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vTH, "Transfer"));
            String vReceipentCheck = Constants.MakeTransferOR.getProperty("ReceipentListFirst");
            Assert.assertEquals("PASS", Constants.key.exist(vReceipentCheck, ""));
        } else if (section.equals("Make a transfer")) {
            LogCapture.info("Navigating to Transfer section with list of receipents displayed...");
            String vTH = Constants.MakeTransferOR.getProperty("TransferPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vTH, "Make a transfer"));
            String vReceipentCheck = Constants.MakeTransferOR.getProperty("ReceipentListFirst");
            Assert.assertEquals("PASS", Constants.key.exist(vReceipentCheck, ""));
        }


    }


    @And("^User Selects the Sell Currency \"([^\"]*)\" and Buy Currency \"([^\"]*)\"$")
    public void userSelectsTheSellCurrencyAndBuyCurrency(String vYouPayCr, String vRecipientCr) throws Throwable {
        LogCapture.info("User is selecting Sell & Buy currency.....");
        String vYouPayObj = Constants.DashboardOR.getProperty("YouPayCurrencyDD");
        Assert.assertEquals("PASS", Constants.key.click(vYouPayObj, ""));
        String vCrInputBox = Constants.DashboardOR.getProperty("CurrencyInput");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vCrInputBox, vYouPayCr));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vCrInputBox, "enter"));
        Constants.key.pause("2", "");
        String vRecipientObj = Constants.DashboardOR.getProperty("RecipientCurrencyDD");
        Assert.assertEquals("PASS", Constants.key.click(vRecipientObj, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vCrInputBox, vRecipientCr));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vCrInputBox, "enter"));
    }

    @And("^Enter the Amount\"([^\"]*)\" in YouPay Amount textbox$")
    public void enterTheAmountInYouPayAmountTextbox(String Amount) throws Throwable {
        LogCapture.info("User is Entering Amount in you pay amount textbox...");
        String vYouPayAmountObj = Constants.DashboardOR.getProperty("YouPayInputBox");

        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vYouPayAmountObj, "selectall"));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vYouPayAmountObj, Amount));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vYouPayAmountObj, "tab"));
        Constants.key.pause("3", "");


    }

    @And("^Enter the Amount\"([^\"]*)\" in RecipientGets Amount textbox$")
    public void enterTheAmountInRecipientGetsAmountTextbox(String getamount) throws Throwable {
        LogCapture.info("User is Entering Amount in Recipient gets amount textbox...");
        String vRecipientInputBoxtObj = Constants.DashboardOR.getProperty("RecipientInputBox");
        Constants.key.pause("2", "");
        //Assert.assertEquals("PASS", Constants.key.clearText(vRecipientInputBoxtObj));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vRecipientInputBoxtObj, "selectall"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vRecipientInputBoxtObj, getamount));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vRecipientInputBoxtObj, "tab"));
        Constants.key.pause("2", "");
    }

    @Then("^User checks the Exchange Rates$")
    public void userChecksTheExchangeRates() throws Exception {
        LogCapture.info("Exchange Rate is clicked...");
        Constants.key.pause("2", "");
        String vExchangeRateObj = Constants.DashboardOR.getProperty("ExchangeRate");
        Assert.assertEquals("PASS", Constants.key.click(vExchangeRateObj, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User is navigated to Transfer Page with (Add a Recipent|ADD RECIPIENT) Option$")
    public void userIsNavigatedToTransferPageWithAddARecipentOption(String page) throws Exception {
        if (page.equals("Add a Recipent")) {
            LogCapture.info("User is navigated to Transfer Page with Add a Recipent Option.....");
            String vAddRecipientButtonObj = Constants.DashboardOR.getProperty("AddRecipientButton");
            Assert.assertEquals("PASS", Constants.key.verifyText(vAddRecipientButtonObj, "Add recipient"));
        } else if (page.equals("ADD RECIPIENT")) {
            LogCapture.info("User is navigated to Transfer Page with Add a Recipent Option.....");
            String vAddRecipientButtonObj = Constants.DashboardOR.getProperty("AddRecipientButton");
            Assert.assertEquals("PASS", Constants.key.verifyText(vAddRecipientButtonObj, "ADD RECIPIENT"));
        }
    }


    @And("^User Clicks on (Create new Rate Alert|Transfer|Top up your wallet|Our Bank Details|Add recipient|Add GBP|Send GBP|Bank Details|Profile Management|Logout|Profile DropDown|save|Send EUR|Top Up Balance|Help|Live Chat|Chat Now|Close Chat|No, take me back to chat|Yes, I'm done|Chat Close|Save Chat|Nos coordonnées bancaires) Button$")
    public void userClicksOnCreateNewRateAlertButton(String button) throws Exception {
        if (button.equals("Create new Rate Alert")) {
            LogCapture.info("User clicking " + button + " button...");
            String vNewRateAlertButton = Constants.DashboardOR.getProperty("CrNewRateButton");
            Assert.assertEquals("PASS", Constants.key.click(vNewRateAlertButton, ""));
        } else if (button.equals("Transfer")) {
            LogCapture.info("User clicking " + button + " button...");
            String vTransferButton = Constants.DashboardOR.getProperty("TransferButton");
            Assert.assertEquals("PASS", Constants.key.click(vTransferButton, ""));
        } else if (button.equals("Top up your wallet")) {
            LogCapture.info("User clicking " + button + " button...");
            String vTopUpButton = Constants.DashboardOR.getProperty("TopUpButton");
            Assert.assertEquals("PASS", Constants.key.click(vTopUpButton, ""));
        } else if (button.equals("Our Bank Details")) {
            LogCapture.info("User clicking " + button + " button...");
            String vOurBankDetailButton = Constants.DashboardOR.getProperty("OurBankDetailsButton");
            Assert.assertEquals("PASS", Constants.key.click(vOurBankDetailButton, ""));
        } else if (button.equals("Add recipient")) {
            LogCapture.info("User clicking " + button + " button...");
            String vAddRecipientButton = Constants.DashboardOR.getProperty("AdRicpButton");
            Assert.assertEquals("PASS", Constants.key.click(vAddRecipientButton, ""));
        } else if (button.equals("Add GBP")) {
            LogCapture.info("User clicking " + button + " button...");
            String vAddGBPButton = Constants.DashboardOR.getProperty("AddGBP");
            Assert.assertEquals("PASS", Constants.key.click(vAddGBPButton, ""));
        } else if (button.equals("Send GBP")) {
            LogCapture.info("User clicking " + button + " button...");
            String vSendGBP = Constants.DashboardOR.getProperty("SendGBP");
            Assert.assertEquals("PASS", Constants.key.click(vSendGBP, ""));
        } else if (button.equals("Send EUR")) {
            LogCapture.info("User clicking " + button + " button...");
            String vSendEUR = Constants.DashboardOR.getProperty("SendEUR");
            Assert.assertEquals("PASS", Constants.key.click(vSendEUR, ""));
        } else if (button.equals("Bank Details")) {
            LogCapture.info("User clicking " + button + " button...");
            String vBankDetails = Constants.DashboardOR.getProperty("BankDetails");
            Assert.assertEquals("PASS", Constants.key.click(vBankDetails, ""));
        } else if (button.equals("Profile Management")) {
            LogCapture.info("User clicking " + button + " button...");
            Constants.key.pause("2", "");
            String vProfileManagementButton = Constants.DashboardOR.getProperty("ProfileManagementButton");
            Assert.assertEquals("PASS", Constants.key.click(vProfileManagementButton, ""));
        } else if (button.equals("Logout")) {
            LogCapture.info("User clicking " + button + " button...");
            String vLogoutButton = Constants.DashboardOR.getProperty("LogoutButton");
            Assert.assertEquals("PASS", Constants.key.click(vLogoutButton, ""));
        } else if (button.equals("Profile DropDown")) {
            LogCapture.info("User clicking " + button + " button...");
            String vUserDD = Constants.DashboardOR.getProperty("UserDD");
            Assert.assertEquals("PASS", Constants.key.click(vUserDD, ""));
        } else if (button.equals("save")) {
            LogCapture.info("User clicking " + button + " button...");
            String vSaveButton = Constants.ProfileManagementOR.getProperty("SaveButton");
            Assert.assertEquals("PASS", Constants.key.click(vSaveButton, ""));
        } else if (button.equals("Top Up Balance")) {
            LogCapture.info("User clicking " + button + " button...");
            String vTopUpButton = Constants.DashboardOR.getProperty("HLTopUpButton");
            Assert.assertEquals("PASS", Constants.key.click(vTopUpButton, ""));
        } else if (button.equals("Help")) {
            Constants.key.pause("10", "");
            LogCapture.info("User clicking " + button + " button...");
            String vHelpButton = Constants.loginPageOR.getProperty("HelpLink");
            Assert.assertEquals("PASS", Constants.key.click(vHelpButton, ""));
        } else if (button.equals("Live Chat")) {
            Constants.key.pause("5", "");
            LogCapture.info("User clicking " + button + " button...");
            String vObjLiveChatButton = Constants.loginPageOR.getProperty("LiveChatLink");
            Assert.assertEquals("PASS", Constants.key.click(vObjLiveChatButton, ""));
        } else if (button.equals("Chat Now")) {
            LogCapture.info("User clicking " + button + " button...");
            String vChatNowButton = Constants.loginPageOR.getProperty("ChatNowButton");
            Assert.assertEquals("PASS", Constants.key.click(vChatNowButton, ""));
            Constants.key.pause("10", "");
        } else if (button.equals("Close Chat")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjCloseChatButton = Constants.loginPageOR.getProperty("CloseChatBox");
            Assert.assertEquals("PASS", Constants.key.click(vObjCloseChatButton, ""));
            Constants.key.pause("10", "");
        } else if (button.equals("No, take me back to chat")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjNoChatCloseOption = Constants.loginPageOR.getProperty("NoChatCloseOption");
            Assert.assertEquals("PASS", Constants.key.click(vObjNoChatCloseOption, ""));
            Constants.key.pause("5", "");
        } else if (button.equals("Yes, I'm done")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjYesChatCloseOption = Constants.loginPageOR.getProperty("YesChatCloseOption");
            Assert.assertEquals("PASS", Constants.key.click(vObjYesChatCloseOption, ""));
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.ChatFileOperation("delete", "transcript"));
        } else if (button.equals("Chat Close")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjCloseChatChatCloseOption = Constants.loginPageOR.getProperty("CloseChatChatCloseOption");
            Assert.assertEquals("PASS", Constants.key.click(vObjCloseChatChatCloseOption, ""));
            Constants.key.pause("5", "");
        } else if (button.equals("Save Chat")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjSaveChatChatCloseOption = Constants.loginPageOR.getProperty("SaveChatChatCloseOption");
            Assert.assertEquals("PASS", Constants.key.click(vObjSaveChatChatCloseOption, ""));
            Constants.key.pause("5", "");
        } else if (button.equals("Nos coordonnées bancaires")) {
            LogCapture.info("User clicking " + button + " button...");
            Constants.key.pause("5", "");

            String vObjOurBankDetailsButtonFrench = Constants.DashboardOR.getProperty("OurBankDetailsButtonFrench");
            LogCapture.info("User clicking " + vObjOurBankDetailsButtonFrench + " button...");

            Assert.assertEquals("PASS", Constants.key.click(vObjOurBankDetailsButtonFrench, ""));
            Constants.key.pause("5", "");
        }
        Constants.key.pause("5", "");

    }

    @Then("^User is navigated to (New Rate Alert|Make Transfer|Top up Wallet|Our Bank Account Details|Add your recipient|Top up wallet|Transfer|Your transfer details|getPersonalDetails|Delete Pop Up|Our bank account details|Your Transfer Details|Nos coordonnées bancaires) Page$")
    public void userIsNavigatedToNewRateAlertPage(String page) throws Exception {
        if (page.equals("New Rate Alert")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vNewRateALertTitle = Constants.DashboardOR.getProperty("NewrateAlertTitle");
            Assert.assertEquals("PASS", Constants.key.verifyText(vNewRateALertTitle, "New rate alert"));
        } else if (page.equals("Make Transfer")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vMakeTransferHeader = Constants.DashboardOR.getProperty("TransferPageHeading");
            Assert.assertEquals("PASS", Constants.key.verifyText(vMakeTransferHeader, "Transfer"));
        } else if (page.equals("Top up Wallet")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vTopUpWalletPgHeader = Constants.DashboardOR.getProperty("TopUpWalletHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vTopUpWalletPgHeader, "Top up wallet"));
        } else if (page.equals("Our Bank Account Details")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vOBAD = Constants.DashboardOR.getProperty("OurBankAccountDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vOBAD, "Our Bank Account Details"));
            //Constants.key.pause("10","");
        } else if (page.equals("Nos coordonnées bancaires")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vOBADF = Constants.DashboardOR.getProperty("OurBankAccountDetailsHeaderFrench");
            Assert.assertEquals("PASS", Constants.key.verifyText(vOBADF, "Nos coordonnées bancaires"));
        } else if (page.equals("Add your recipient")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vAUR = Constants.DashboardOR.getProperty("AddYourRecipientPage");
            Assert.assertEquals("PASS", Constants.key.verifyText(vAUR, "Add your recipient"));
        } else if (page.equals("Top up wallet")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vBuyCr = Constants.DashboardOR.getProperty("TopUpWalletPage");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBuyCr, "Top up wallet"));
        } else if (page.equals("Transfer")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vTH = Constants.DashboardOR.getProperty("TransferPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vTH, "Transfer"));
        } else if (page.equals("Your transfer details")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vYTDSendNote = Constants.DashboardOR.getProperty("YTDSendNote");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vYTDSendNote, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vYTDSendNote, "How much do you need to send?"));
        } else if (page.equals("getPersonalDetails")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vProfileManagementPageHeader = Constants.DashboardOR.getProperty("ProfileManagementPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vProfileManagementPageHeader, "Your profile"));
        } else if (page.equals("Delete Pop Up")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vDeletePopUpTitle = Constants.NewRateAlertOR.getProperty("DeletePopUpTitle");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeletePopUpTitle, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vDeletePopUpTitle, "Do you want to delete this rate alert?"));
        } else if (page.equals("Your Transfer Details")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vYTDSendNote = Constants.DashboardOR.getProperty("YTDSendNote");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vYTDSendNote, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vYTDSendNote, "Tell us some information about your transfer, and how much you’re looking to send."));
        } else if (page.equals("Our bank account details")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vOBAD = Constants.DashboardOR.getProperty("CD_OurBankAccountDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vOBAD, "Our bank account details"));
        }
    }

    @And("^User clicks on (GBP|EUR) currency under user wallets section$")
    public void userClicksOnGBPCurrencyUnderUserWalletsSection(String wallet) throws Exception {
        if (wallet.equals("GBP")) {
            LogCapture.info("User clicks on GBP currency under user wallets section...");
            String GBPCrDD = Constants.DashboardOR.getProperty("GBPCurrencySDD");
            Assert.assertEquals("PASS", Constants.key.click(GBPCrDD, ""));
        } else if (wallet.equals("EUR")) {
            LogCapture.info("User clicks on EUR currency under user wallets section...");
            String EURCrDD = Constants.DashboardOR.getProperty("EURCurrencySDD");
            Assert.assertEquals("PASS", Constants.key.click(EURCrDD, ""));
        }
    }

    @Then("^User should be able to view the Customer Bank details$")
    public void userShouldBeAbleToViewTheCustomerBankDetails() throws Exception {
        LogCapture.info("Validating Customer Bank details section...");
        LogCapture.info("Validating Bank Account Details Text....");
        Constants.key.pause("2", "");
        String vBankAccountDetailText = Constants.DashboardOR.getProperty("BankAccountDetailsText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBankAccountDetailText, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vBankAccountDetailText, "GBP bank account details"));

        LogCapture.info("Validating Account Name Text and Value.....");
        String vAccountNameText = Constants.DashboardOR.getProperty("AccountNameText");
        String vAccountNameValue = Constants.DashboardOR.getProperty("AccountNameValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vAccountNameText, "Account name"));
        Assert.assertEquals("PASS", Constants.key.exist(vAccountNameValue, ""));

        LogCapture.info("Validating Bank Name Text and Value.....");
        String vBankNameText = Constants.DashboardOR.getProperty("BankNameText");
        String vBankNameValue = Constants.DashboardOR.getProperty("BankNameValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vBankNameText, "Bank name"));
        Assert.assertEquals("PASS", Constants.key.exist(vBankNameValue, ""));

        LogCapture.info("Validating Sort Code Name Text and Value.....");
        String vSortCodeName = Constants.DashboardOR.getProperty("SortCodeName");
        String vSortCodeValue = Constants.DashboardOR.getProperty("SortCodeValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vSortCodeName, "Sort code"));
        Assert.assertEquals("PASS", Constants.key.exist(vSortCodeValue, ""));

        LogCapture.info("Validating AccountIBN Number Name Text and Value.....");
        String vAccountIbnNumberText = Constants.DashboardOR.getProperty("AccountIbnNumberText");
        String vAccountIbnNumberVal = Constants.DashboardOR.getProperty("AccountIbnNumberVal");
        Assert.assertEquals("PASS", Constants.key.verifyText(vAccountIbnNumberText, "Account/IBAN no."));
        Assert.assertEquals("PASS", Constants.key.exist(vAccountIbnNumberVal, ""));

        LogCapture.info("Validating IBAN Name Text and Value.....");
        String vIBANText = Constants.DashboardOR.getProperty("IBANText");
        String vIBANValue = Constants.DashboardOR.getProperty("IBANValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vIBANText, "IBAN"));
        Assert.assertEquals("PASS", Constants.key.exist(vIBANValue, ""));

        LogCapture.info("Validating SWIFT CODE Name Text and Value.....");
        String vSWIFTCodeText = Constants.DashboardOR.getProperty("SWIFTCodeText");
        String vSWIFTCodeValue = Constants.DashboardOR.getProperty("SWIFTCodeValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vSWIFTCodeText, "SWIFT code"));
        Assert.assertEquals("PASS", Constants.key.exist(vSWIFTCodeValue, ""));

        LogCapture.info("Validating Reference Name Text and Value.....");
        String vReferenceText = Constants.DashboardOR.getProperty("ReferenceText");
        String vReferenceValue = Constants.DashboardOR.getProperty("ReferenceValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vReferenceText, "Reference"));
        Assert.assertEquals("PASS", Constants.key.exist(vReferenceValue, ""));

    }

    @And("^User Clicks on Transfer Button in Your Recipient section$")
    public void userClicksOnTransferButtonInYourRecipientSection() throws Exception {
        LogCapture.info("User clicking on Transfer Button in Your Recipient section... ");
        String vYourRecipientTransfer = Constants.DashboardOR.getProperty("YourRecipientTransfer");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vYourRecipientTransfer, ""));
        Assert.assertEquals("PASS", Constants.key.click(vYourRecipientTransfer, ""));


    }

    @Then("^User is navigated back to (FCG|CD|TORFX|TMO|Ramsdens|TORAU|HL|HL-EU) Login Page$")
    public void userIsNavigatedBackToTheLoginPage(String application) throws Exception {
        if (application.equals("FCG")) {
            String vLoginPageHeader = Constants.DashboardOR.getProperty("LoginPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vLoginPageHeader, "Welcome to Foremost Currency Group"));
        } else if (application.equals("CD")) {
            String vLoginPageHeader = Constants.DashboardOR.getProperty("LoginPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vLoginPageHeader, "Welcome to\n" +
                    "Currencies Direct"));
        } else if (application.equals("TORFX")) {
            String vLoginPageHeader = Constants.DashboardOR.getProperty("LoginPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vLoginPageHeader, "Welcome to TorFX"));
        } else if (application.equals("TMO")) {
            String vLoginPageHeader = Constants.DashboardOR.getProperty("LoginPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vLoginPageHeader, "Welcome to Travel Money Oz Transfers"));
        } else if (application.equals("Ramsdens")) {
            String vLoginPageHeader = Constants.DashboardOR.getProperty("LoginPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vLoginPageHeader, "Welcome to Ramsdens"));
        } else if (application.equals("TORAU")) {
            String vLoginPageHeader = Constants.DashboardOR.getProperty("LoginPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vLoginPageHeader, "Welcome to TorFX"));
        } else if (application.equals("HL")) {
            String vLoginPageHeader = Constants.DashboardOR.getProperty("LoginPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vLoginPageHeader, "Welcome to\n" +
                    "Hargreaves Lansdown Currency Service\n" +
                    "(provided by Currencies Direct)"));
        }
    }

    @When("^User enter UserName \"([^\"]*)\" incorrect password four times \"([^\"]*)\" and click login button$")
    public void user_enter_UserName_incorrect_password_five_times_and_click_login_button(String usernName, String inPassword) throws Throwable {
        LogCapture.info("Validating incorrect credentials.......");
        int attempts = 1;
        while (attempts < 5) {
            //  for(int i=0;i<5;i++) {
            System.out.println("Loop" + attempts);
            String vUserName = Constants.CONFIG.getProperty(usernName);
            String vObjUser = Constants.loginPageOR.getProperty("FCG_Username");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));

            String vObjPass = Constants.loginPageOR.getProperty("FCG_Password");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));

            String vObjLoginButton = Constants.loginPageOR.getProperty("LoginButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
            LogCapture.info("Loop......");
            Constants.key.pause("5", "");
            attempts++;
        }
        LogCapture.info("Validating error message...");

  /*  String vExpected = "As you've entered incorrect login details multiple times, you'll need to reset your password to continue.";
    String vErrorObj = Constants.loginPageOR.getProperty("FCG_ResetError");
    Constants.key.pause("2", "");
    Assert.assertEquals("PASS", Constants.key.verifyText(vErrorObj, vExpected));
*/
        String vCloseButton = Constants.loginPageOR.getProperty("FCG_CloseButton");
        Assert.assertEquals("PASS", Constants.key.click(vCloseButton, ""));
        LogCapture.info("Logs......");


        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.loginPageOR.getProperty("FCG_Username");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));

        String vObjPass = Constants.loginPageOR.getProperty("FCG_Password");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));

        String vObjLoginButton = Constants.loginPageOR.getProperty("LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
        LogCapture.info("Loop......");
    }

    @Then("^error message is displayed on Login page as account has been blocked$")
    public void error_message_is_displayed_on_Login_page_as_account_has_been_blocked() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Validating error message...");
        String vExpected = "Your account has been locked due to multiple unsuccessful log in attempts";
        String vErrorObj = Constants.loginPageOR.getProperty("FCG_LockedUser");
        LogCapture.info("Validating error message...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vErrorObj, vExpected));

    }

    @Then("^User should get error as We are sorry, but this currency pair is not available online$")
    public void user_should_get_error_as_We_are_sorry_but_this_currency_pair_is_not_available_online() throws Throwable {
        LogCapture.info("Validating error message");
        String vObjunmatchCurrency = Constants.MakeTransferOR.getProperty("unmatchCurrency");
        Assert.assertEquals("PASS", Constants.key.exist(vObjunmatchCurrency, ""));
    }

    @Then("^User selects Payment currency as \"([^\"]*)\"$")
    public void user_selects_Payment_currency_as(String paymentcurrency) throws Throwable {
        String vObjpaymentCurrency = Constants.MakeTransferOR.getProperty("paymentCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjpaymentCurrency, ""));
        String vObjSearchCurrency = Constants.MakeTransferOR.getProperty("SearchCurrency");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchCurrency, paymentcurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCurrency, "enter"));
    }

    @Then("^User selects wallet as \"([^\"]*)\"$")
    public void user_selects_wallet_as(String wallet) throws Throwable {
        String vObjwallet = Constants.MakeTransferOR.getProperty("wallet");
        Assert.assertEquals("PASS", Constants.key.click(vObjwallet, ""));
        String vObjSearchCurrency = Constants.MakeTransferOR.getProperty("SearchCurrency");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchCurrency, wallet));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCurrency, "enter"));
    }

    @When("^User adds (temporary|new) debit card details Card Type \"([^\"]*)\" name on the card \"([^\"]*)\" card number \"([^\"]*)\" valid from \"([^\"]*)\" Ends \"([^\"]*)\" CVV \"([^\"]*)\"$")
    public void user_adds_temporary_debit_card_details_Card_Type_name_on_the_card_card_number_valid_from_Ends_CVV(String page, String cardtype, String name, String number, String from, String ends, String cvv) throws Throwable {
        if (page.equals("new")) {
            String vObjAddNewCardLink = Constants.ProfileManagementOR.getProperty("AddNewCardLink");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCardLink, ""));

        } else if (page.equals("temporary")) {
            String vObjCardList = Constants.MakeTransferOR.getProperty("CardList");
            if (Constants.driver.findElement(By.xpath(vObjCardList)).isDisplayed()) {
                Assert.assertEquals("PASS", Constants.key.click(vObjCardList, ""));
                String vObjAddNewCard = Constants.TopupWalletOR.getProperty("AddNewCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCard, ""));
            } else {
            }
        }

        String vObjCardType = Constants.MakeTransferOR.getProperty("CardType");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardType, ""));
        String vObjSearchField = Constants.MakeTransferOR.getProperty("SearchField");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchField, cardtype));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchField, "enter"));

        String vObjNameOnCard = Constants.MakeTransferOR.getProperty("NameOnCard");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameOnCard, name));

        String vObjCardNumber = Constants.MakeTransferOR.getProperty("CardNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardNumber, number));

        String vObjStartDate = Constants.MakeTransferOR.getProperty("StartDate");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjStartDate, from));

        String vObjExpiryDate = Constants.MakeTransferOR.getProperty("ExpiryDate");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjExpiryDate, ends));

        String vObjCVV = Constants.MakeTransferOR.getProperty("CVV");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVV, cvv));
    }

    @When("^User Checks the check box for Use the same as your contact address\\? and clicks on continue button to (Make a Transfer|Top up Wallet|Add New Card)$")
    public void user_Checks_the_check_box_for_Use_the_same_as_your_contact_address_and_clicks_on_continue_button(String page) throws Throwable {
        String vObjSameBillingAddressCheckBox = Constants.MakeTransferOR.getProperty("SameBillingAddressCheckBox");
        Assert.assertEquals("PASS", Constants.key.click(vObjSameBillingAddressCheckBox, ""));

        if (page.equals("Make a Transfer")) {
            String vObjButtonContinuetoSubmit = Constants.MakeTransferOR.getProperty("ButtonContinuetoSubmit");
            Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjButtonContinuetoSubmit, ""));
        } else if (page.equals("Top up Wallet")) {
            String vObjButtonBuyCur2 = Constants.TopupWalletOR.getProperty("ButtonBuyCur2");
            Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjButtonBuyCur2, ""));
        } else if (page.equals("Add New Card")) {
            String vObjAddCardSaveButton = Constants.ProfileManagementOR.getProperty("AddCardSaveButton");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjAddCardSaveButton, ""));
        }
    }

    @Then("^User should land on Bank transfer instruction and should be able to change tab to Top-up details$")
    public void user_should_land_on_Bank_transfer_instruction_and_should_be_able_to_change_tab_to_Top_up_details() throws Throwable {
        String vObjBankTransferTab = Constants.TopupWalletOR.getProperty("BankTransferTab");
        Assert.assertEquals("PASS", Constants.key.exist(vObjBankTransferTab, ""));
        String vObjTopUpTab = Constants.TopupWalletOR.getProperty("TopUpTab");
        Assert.assertEquals("PASS", Constants.key.exist(vObjTopUpTab, ""));
    }

    @When("^User selects (Existing|New) (Visa|Maestro|Master||Visa Electron|Visa Debit|Debit Mastercard) card from the list$")
    public void user_selects_Existing_Visa_card_from_the_list(String type, String card) throws Throwable {
        String vObjExistingCardListDD = Constants.TopupWalletOR.getProperty("ExistingCardListDD");
        Assert.assertEquals("PASS", Constants.key.click(vObjExistingCardListDD, ""));

        if (type.equals("Existing")) {
            if (card.equals("Visa")) {
                String vObjExistingVisaCard = Constants.TopupWalletOR.getProperty("ExistingVisaCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingVisaCard, ""));
            } else if (card.equals("Maestro")) {
                String vObjExistingMaestroCard = Constants.TopupWalletOR.getProperty("ExistingMaestroCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingMaestroCard, ""));
            } else if (card.equals("Master")) {
                String vObjExistingMasterCard = Constants.TopupWalletOR.getProperty("ExistingMasterCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingMasterCard, ""));
            } else if (card.equals("Visa Electron")) {
                String vObjExistingVisaElectronCard = Constants.TopupWalletOR.getProperty("ExistingVisaElectronCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingVisaElectronCard, ""));
            } else if (card.equals("Visa Debit")) {
                String vObjExistingVisaDebitCard = Constants.TopupWalletOR.getProperty("ExistingVisaDebitCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingVisaDebitCard, ""));
            } else if (card.equals("Debit Mastercard")) {
                String vObjExistingDebitMasterCard = Constants.TopupWalletOR.getProperty("ExistingDebitMasterCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingDebitMasterCard, ""));
            }


        } else if (type.equals("New")) {
            String vObjAddNewCard = Constants.TopupWalletOR.getProperty("AddNewCard");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCard, ""));
        }
    }

    @When("^User enters cvv \"([^\"]*)\" and clicks Continue button to (Make a Transaction|Top up Wallet)$")
    public void user_enters_cvv_and_clicks_Continue_button(String cvv, String page) throws Throwable {
        String vObjCVV = Constants.TopupWalletOR.getProperty("CVV");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVV, cvv));

        if (page.equals("Make a Transaction")) {
            String vObjButtonContinuetoSubmit = Constants.MakeTransferOR.getProperty("ButtonContinuetoSubmit");
            Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinuetoSubmit, ""));
        } else if (page.equals("Top up Wallet")) {
            String vObjButtonBuyCur2 = Constants.TopupWalletOR.getProperty("ButtonBuyCur2");
            Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur2, ""));
        }

    }

    @When("^User is navigated to World Pay site for submitting the (\\d+)d transaction$")
    public void user_is_navigated_to_World_Pay_site_for_submitting_the_d_transaction(int arg1) throws Throwable {
        Constants.key.pause("4", "");
        String vObjWorldPaySubmitButton = Constants.TopupWalletOR.getProperty("WorldPaySubmitButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjWorldPaySubmitButton, ""));
    }


    @And("^User Click on (Account details) tab$")
    public void userClickOnAccountDetailsTab(String tab) throws Exception {
        if (tab.equals("Account details")) {
            LogCapture.info("User clicking " + tab + " tab...");
            String vAccountDetailsTab = Constants.ProfileManagementOR.getProperty("AccountDetailsTab");
            Assert.assertEquals("PASS", Constants.key.click(vAccountDetailsTab, ""));
        }

    }


    @Then("^User should be able to view the message \"([^\"]*)\" with application phone number \"([^\"]*)\" in it$")
    public void userShouldBeAbleToViewTheMessageWithApplicationPhoneNumberInIt(String message, String phone) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //String vExpectedMessage = message + " " + phone+".";
        String message1 = "If you need to update your email address please give us a call";
        String message2 = "on ";
        String vExpectedMessage = message1 + "\n" + message2 + phone + ".";
        String vLoginDetailTextMsg1 = Constants.ProfileManagementOR.getProperty("LoginDetailTextMsg1");
        Assert.assertEquals("PASS", Constants.key.verifyInnerText(vLoginDetailTextMsg1, vExpectedMessage));
    }

    @Then("^User should be able to view the message with application phone number \"([^\"]*)\" in it and email address should be grayedout$")
    public void userShouldBeAbleToViewTheMessageWithApplicationPhoneNumberInItAndEmailAddressShouldBeGrayedout(String phone) throws Throwable {
        LogCapture.info("User verifying message with " + phone);
        String message1 = "If you need to update your email address please give us a call";
        String message2 = "on ";
        String vExpectedMessage = message1 + "\n" + message2 + phone + ".";
        String vLoginDetailTextMsg1 = Constants.ProfileManagementOR.getProperty("LoginDetailTextMsg1");
        Assert.assertEquals("PASS", Constants.key.verifyInnerText(vLoginDetailTextMsg1, vExpectedMessage));
        LogCapture.info("User verifying if email address is greyed out or not...");
        String vemailAddress = Constants.ProfileManagementOR.getProperty("emailAddress");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vemailAddress, "readonly"));
    }

    @Then("^User should not be able to view Switch to Joint button$")
    public void userShouldNotBeAbleToViewSwitchToJointButton() throws Exception {
        LogCapture.info("Checking Switch to join button non existence...");
        String vswitchToJoinAccount = Constants.ProfileManagementOR.getProperty("switchToJoinAccount");
        Assert.assertEquals("PASS", Constants.key.notexist(vswitchToJoinAccount, ""));
    }

    @And("^User Updates the answer for first Security Question first answer \"([^\"]*)\" second answer \"([^\"]*)\"$")
    public void userUpdatesTheAnswerForFirstSecurityQuestionFirstAnswerSecondAnswer(String firstAns, String secoundAns) throws Throwable {
        LogCapture.info("Updating Answers to First & Second question....");
        String vSecurityQue1Ans = Constants.ProfileManagementOR.getProperty("SecurityQue1Ans");
        String vSecurityQue2Ans = Constants.ProfileManagementOR.getProperty("SecurityQue2Ans");
        Assert.assertEquals("PASS", Constants.key.clearText(vSecurityQue1Ans));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSecurityQue1Ans, firstAns));
        Assert.assertEquals("PASS", Constants.key.clearText(vSecurityQue2Ans));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSecurityQue2Ans, secoundAns));
    }

    @When("^User re-enters password \"([^\"]*)\" and clicks on submit button$")
    public void userReEntersPasswordAndClicksOnSubmitButton(String password) throws Throwable {
        LogCapture.info("User re-enters password....");
        String vPassword = Constants.CONFIG.getProperty(password);
        String vPasswordTextBox = Constants.ProfileManagementOR.getProperty("PasswordTextBox");
        LogCapture.info("Password from feature file: " + vPassword);
        LogCapture.info("Password Text Box Xpath: " + vPasswordTextBox);
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPasswordTextBox, vPassword));
        LogCapture.info("User clicking submit button....");
        String vVerifyPasswordButton = Constants.ProfileManagementOR.getProperty("VerifyPasswordButton");
        Assert.assertEquals("PASS", Constants.key.click(vVerifyPasswordButton, ""));
    }

    @Then("^User should get success message$")
    public void userShouldGetSuccessMessage() throws Exception {
        LogCapture.info("User Validating Success Message....");
        String vSuccessMessage = Constants.ProfileManagementOR.getProperty("SuccessMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Your changes have been saved."));
    }

    @And("^User Click on (Switch to joint|) hyper link$")
    public void userClickOnSwitchToJointHyperLink(String hyperlink) throws Exception {
        if (hyperlink.equals("Switch to joint")) {
            LogCapture.info("User clicking to " + hyperlink + " hyperlink...");
            String vswitchToJoinAccount = Constants.ProfileManagementOR.getProperty("switchToJoinAccount");
            Assert.assertEquals("PASS", Constants.key.click(vswitchToJoinAccount, ""));
        }

    }

    @Then("^User should navigate to  Invite someone to a joint account Window$")
    public void userShouldNavigateToInviteSomeoneToAJointAccountWindow() throws Exception {
        LogCapture.info("User verifying --Invite someone to a joint account Window-- header..");
        String vMessageInviteFormText = Constants.ProfileManagementOR.getProperty("MessageInviteFormText");
        Assert.assertEquals("PASS", Constants.key.verifyText(vMessageInviteFormText, "Invite someone to a joint account"));
    }

    @And("^User enters the first name \"([^\"]*)\" last name \"([^\"]*)\" mobile number \"([^\"]*)\" \"([^\"]*)\" dateofbirth Day\"([^\"]*)\" Month\"([^\"]*)\" year\"([^\"]*)\" emailAddress\"([^\"]*)\"$")
    public void userEntersTheFirstNameLastNameMobileNumberDateofbirthDayMonthYearEmailAddress(String fname, String lname, String countryCode, String mobileNo, String day, String month, String year, String secondaryEmailAddress) throws Throwable {
        LogCapture.info("User entering first name....");
        String vFN = Constants.ProfileManagementOR.getProperty("FN");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vFN, fname));
        LogCapture.info("User entering last name....");
        String vLN = Constants.ProfileManagementOR.getProperty("LN");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vLN, lname));

        LogCapture.info("User entering country code.....");
        String vCountryDD = Constants.ProfileManagementOR.getProperty("CountryDD");
        Assert.assertEquals("PASS", Constants.key.click(vCountryDD, ""));
        String vCountrySearchText = Constants.ProfileManagementOR.getProperty("CountrySearchText");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vCountrySearchText, countryCode));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vCountrySearchText, "enter"));

        LogCapture.info("User entering mobile number.....");
        String vNumber = Constants.ProfileManagementOR.getProperty("Number");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vNumber, mobileNo));

        LogCapture.info("User entering Day .....");
        String vDayDropDown = Constants.ProfileManagementOR.getProperty("DayDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vDayDropDown, ""));
        String vcommonSearchTextBx = Constants.ProfileManagementOR.getProperty("commonSearchTextBx");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, day));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        LogCapture.info("User entering Month .....");
        String vMonthDropDown = Constants.ProfileManagementOR.getProperty("MonthDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vMonthDropDown, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, month));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        LogCapture.info("User entering Year .....");
        String vYearDropDown = Constants.ProfileManagementOR.getProperty("YearDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vYearDropDown, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, year));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        LogCapture.info("User entering email Address....");
        String vEmailAddressTextBox = Constants.ProfileManagementOR.getProperty("EmailAddressTextBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEmailAddressTextBox, secondaryEmailAddress));


    }

    @And("^User ticks the Checkbox to use same address details of primary contact$")
    public void userTicksTheCheckboxToUseSameAddressDetailsOfPrimaryContact() throws Exception {
        LogCapture.info("User ticks the Checkbox to use same address details of primary contact..");
        String vContactDetailsCheckBox = Constants.ProfileManagementOR.getProperty("ContactDetailsCheckBox");
        Assert.assertEquals("PASS", Constants.key.click(vContactDetailsCheckBox, ""));

        Assert.assertEquals("PASS", Constants.key.pause("5", ""));

    }

    @And("^User click on save button$")
    public void userClickOnSaveButton() throws Exception {
        LogCapture.info("User Clicks on save button...");
        String vSendInviteSendButton = Constants.ProfileManagementOR.getProperty("SendInviteSendButton");
        String vVerifyPasswordButton = Constants.ProfileManagementOR.getProperty("VerifyPasswordButton");
        Assert.assertEquals("PASS", Constants.key.click(vSendInviteSendButton, ""));

        /*Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vProfileManagementIDpasswordTextBox = Constants.ProfileManagementOR.getProperty("ProfileManagementIDpasswordTextBox");

        Assert.assertEquals("PASS", Constants.key.writeInInput(vProfileManagementIDpasswordTextBox, ""));
        Assert.assertEquals("PASS", Constants.key.click(vVerifyPasswordButton, ""));*/
    }

    @Then("^User should get invite success message$")
    public void userShouldGetInviteSuccessMessage() throws Exception {
        int count = 0;
        LogCapture.info("User Validating Success Message....");
        String vInviteSuccessMessage = Constants.ProfileManagementOR.getProperty("InviteSuccessMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vInviteSuccessMessage, ""));
        //Assert.assertEquals("PASS", Constants.key.exist(vInviteSuccessMessage,""));

/*        do {
            count = count + 1;
            LogCapture.info("Repeat the Loop Untill the InviteSuccessMessage : Count:->" + count);

        } while (!Constants.driver.findElement(By.xpath(vInviteSuccessMessage)).isDisplayed());*/


        Assert.assertEquals("PASS", Constants.key.verifyText(vInviteSuccessMessage, "Thanks, your invite has been sent."));

    }

    @And("^User click on save button on invite page$")
    public void userClickOnSaveButtonOnInvitePage() throws Exception {
        LogCapture.info("User clicks on save button on invite page...");
//        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vSendInviteSendButton = Constants.ProfileManagementOR.getProperty("SendInviteSendButton");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vSendInviteSendButton, ""));


    }

    @And("^User enters the first name \"([^\"]*)\" last name \"([^\"]*)\" mobile number \"([^\"]*)\" \"([^\"]*)\" dateofbirth Day\"([^\"]*)\" Month\"([^\"]*)\" year\"([^\"]*)\" emailAddress\"$")
    public void userEntersTheFirstNameLastNameMobileNumberDateofbirthDayMonthYearEmailAddress(String fname, String lname, String countryCode, String mobileNo, String day, String month, String year) throws Throwable {

        LogCapture.info("User entering first name....");
        String vFN = Constants.ProfileManagementOR.getProperty("FN");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vFN, fname));
        LogCapture.info("User entering last name....");
        String vLN = Constants.ProfileManagementOR.getProperty("LN");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vLN, lname));

        LogCapture.info("User entering country code.....");
        String vCountryDD = Constants.ProfileManagementOR.getProperty("CountryDD");
        Assert.assertEquals("PASS", Constants.key.click(vCountryDD, ""));
        String vCountrySearchText = Constants.ProfileManagementOR.getProperty("CountrySearchText");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vCountrySearchText, countryCode));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vCountrySearchText, "enter"));

        LogCapture.info("User entering mobile number.....");
        String vNumber = Constants.ProfileManagementOR.getProperty("Number");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vNumber, mobileNo));

        LogCapture.info("User entering Day .....");
        String vDayDropDown = Constants.ProfileManagementOR.getProperty("DayDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vDayDropDown, ""));
        String vcommonSearchTextBx = Constants.ProfileManagementOR.getProperty("commonSearchTextBx");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, day));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        LogCapture.info("User entering Month .....");
        String vMonthDropDown = Constants.ProfileManagementOR.getProperty("MonthDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vMonthDropDown, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, month));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        LogCapture.info("User entering Year .....");
        String vYearDropDown = Constants.ProfileManagementOR.getProperty("YearDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vYearDropDown, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, year));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        LogCapture.info("User entering email Address....");
        String vEmailAddressTextBox = Constants.ProfileManagementOR.getProperty("EmailAddressTextBox");
        Assert.assertEquals("PASS", Constants.key.uniqueEmailID(vEmailAddressTextBox, ""));


    }

    @And("^User Clicks (edit|deleteX|Confirm) Button on Rate Alert Page$")
    public void userClicksEditButtonOnRateAlertPage(String button) throws Exception {
        if (button.equals("edit")) {
            LogCapture.info("User clicking " + button + " button...");
            String vEditRateAlert = Constants.NewRateAlertOR.getProperty("EditRateAlert");
            Assert.assertEquals("PASS", Constants.key.click(vEditRateAlert, ""));
        } else if (button.equals("deleteX")) {
            LogCapture.info("User clicking " + button + " button...");
            String vDeleteRateAlert = Constants.NewRateAlertOR.getProperty("DeleteRateAlert");
            Assert.assertEquals("PASS", Constants.key.click(vDeleteRateAlert, ""));
        } else if (button.equals("Confirm")) {
            LogCapture.info("User clicking " + button + " button...");
            String vDeleteConfirm = Constants.NewRateAlertOR.getProperty("DeleteConfirm");
            Assert.assertEquals("PASS", Constants.key.click(vDeleteConfirm, ""));
        }

    }

    @And("^User updates the amount \"([^\"]*)\" and click on update amounts button$")
    public void userUpdatesTheAmountAndClickOnUpdateAmountsButton(String updateBuyAmount) throws Throwable {
        LogCapture.info("Entering the update amount to buy .....");
        Constants.key.pause("10", "");
        String vBuyInputObject = Constants.NewRateAlertOR.getProperty("BuyInputText");
        Assert.assertEquals("PASS", Constants.key.click(vBuyInputObject, ""));
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vBuyInputObject, "selectall"));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vBuyInputObject, updateBuyAmount));
        Constants.key.pause("3", "");
        String vUpdateAmounts = Constants.NewRateAlertOR.getProperty("UpdateAmounts");
        Assert.assertEquals("PASS", Constants.key.click(vUpdateAmounts, ""));

    }

    @When("^User Clicks on Update Button$")
    public void userClicksOnUpdateButton() throws Exception {
        LogCapture.info("User clicking on update button .....");
        String vUpdateButton = Constants.NewRateAlertOR.getProperty("UpdateButton");
        Assert.assertEquals("PASS", Constants.key.click(vUpdateButton, ""));
    }

    @And("^Clicks on SignUp Button$")
    public void clicks_on_SignUp_Button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Portal is loading....");
        String vObjSignUpButton = Constants.loginPageOR.getProperty("FCG_SignUp_Button");
        Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
    }

    @And("^User Selects personal option and Click on Next$")
    public void user_Selects_personal_option_and_Click_on_Next() throws Throwable {
        LogCapture.info("Registration in Processs....");
        Constants.key.pause("2", "");
        String vPersonalRadioButton = Constants.SignUp.getProperty("PersonalRadioButton");
        Assert.assertEquals("PASS", Constants.key.click(vPersonalRadioButton, ""));
        String vNext_Button = Constants.SignUp.getProperty("Next_Button");
        Assert.assertEquals("PASS", Constants.key.click(vNext_Button, ""));
    }

    @When("^User enter UserName \"([^\"]*)\" and password of other organization user \"([^\"]*)\" and Next button$")
    public void user_enter_UserName_and_password_of_other_organization_user_and_Next_button(String userName, String password) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjSignUp_EmailID = Constants.SignUp.getProperty("SignUp_EmailID");
        String vObjSignUp_Password = Constants.SignUp.getProperty("SignUp_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSignUp_EmailID, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSignUp_Password, vPassword));
        String vVerify_Button = Constants.SignUp.getProperty("Verify_Button");
        Assert.assertEquals("PASS", Constants.key.click(vVerify_Button, ""));
        LogCapture.info("Registration in Processs....");
    }

    @Then("^User enter second contact UserName \"([^\"]*)\" and password of other organization user \"([^\"]*)\" and Next login button$")
    public void user_enter_second_contact_UserName_and_password_of_other_organization_user_and_Next_login_button(String userName, String password) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjSignUp_EmailID = Constants.SignUp.getProperty("SignUp_EmailID");
        String vObjSignUp_Password = Constants.SignUp.getProperty("SignUp_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSignUp_EmailID, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSignUp_Password, vPassword));
        String vVerify_Button = Constants.SignUp.getProperty("Verify_Button");
        Assert.assertEquals("PASS", Constants.key.click(vVerify_Button, ""));
        LogCapture.info("Registration in Processs....");
    }

    @Then("^User Should see (TMO error|TORFX error|RAMSDEN error|TORFXOZ error) message as you have been Already registered\\.$")
    public void user_Should_see_tmo_error_message_as_you_have_been_Already_registerted(String error) throws Throwable {
        // Write code here that turns the phrase above into concrete actionse
        if (error.equals("TMO error")) {
            LogCapture.info(" In Processs....");
            Constants.key.pause("2", "");
            String vDetailsPage = Constants.loginPageOR.getProperty("TMO_Error_Message_for_Whitelebel");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDetailsPage, "Thanks. As you're already registered with the TorFX currency transfer service, we're just redirecting you there"));
        } else if (error.equals("TORFX error")) {
            LogCapture.info(" In Processs....");
            Constants.key.pause("2", "");
            String vDetailsPage = Constants.loginPageOR.getProperty("Ramsden_Error_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDetailsPage, "Thanks. As you're already registered with the Ramsdens currency transfer service, we're just redirecting you there"));
        } else if (error.equals("RAMSDEN error")) {
            LogCapture.info(" In Processs....");
            Constants.key.pause("2", "");
            String vDetailsPage = Constants.loginPageOR.getProperty("TorFXError_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDetailsPage, "Thanks. As you're already registered with the TorFx currency transfer service, we're just redirecting you there"));
        } else if (error.equals("TORFXOZ error")) {
            // Write code here that turns the phrase above into concrete actions
            LogCapture.info(" In Processs....");
            Constants.key.pause("2", "");
            String vDetailsPage = Constants.loginPageOR.getProperty("TorFXOzError_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDetailsPage, "Thanks. As you're already registered with the TravelMoneyOz currency transfer service, we're just redirecting you there"));
        } else
            LogCapture.info("No Error Found");
    }

    @Then("^User Clicks on Close popup button$")
    public void user_Clicks_on_Close_popup_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Close the PopUp...................");
        String vObjPayeeButton = Constants.loginPageOR.getProperty("TMO_Close");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeButton, ""));
    }


    @Then("^User should not be able to see card used \"([^\"]*)\" during the journey under Account details tab$")
    public void user_should_not_be_able_to_see_card_used_during_the_journey_under_Account_details_tab(String usedcardno) throws Throwable {
        String vUsedCardNoXpath = "//*[contains(text(),'" + usedcardno + "')]";
        Assert.assertEquals("PASS", Constants.key.notexist(vUsedCardNoXpath, ""));
    }

    @Then("^User clicks on delete existing card added under Your Debit Card Details$")
    public void user_clicks_on_delete_existing_card_added_under_Your_Debit_Card_Details() throws Throwable {
        String vObjCardDeleteLink = Constants.ProfileManagementOR.getProperty("CardDeleteLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardDeleteLink, ""));
    }

    @Then("^User clicks on confirm button for deleting card$")
    public void user_clicks_on_confirm_button_for_deleting_card() throws Throwable {
        String vObjDeleteConfirmButton = Constants.ProfileManagementOR.getProperty("DeleteConfirmButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjDeleteConfirmButton, ""));
    }

    @Then("^User should not be able to see deleted card under Debit Card Details$")
    public void user_should_not_be_able_to_see_deleted_card_under_Debit_Card_Details() throws Throwable {
        String vObjCardDeleteLink = Constants.ProfileManagementOR.getProperty("CardDeleteLink");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjCardDeleteLink, ""));
    }


    @Then("^User should get success message for adding card$")
    public void user_should_get_success_message_for_adding_card() throws Throwable {
        String vObjAddCardSuccessMessage = Constants.ProfileManagementOR.getProperty("AddCardSuccessMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddCardSuccessMessage, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjAddCardSuccessMessage, ""));
    }

    /*
        @Then("^User Should be able to see newly added card under your debit card details$")
        public void user_Should_be_able_to_see_newly_added_card_under_your_debit_card_details() throws Throwable {
            String vObjCardDeleteLink = Constants.ProfileManagementOR.getProperty("CardDeleteLink");
            Assert.assertEquals("PASS", Constants.key.exist(vObjCardDeleteLink,""));
        }
    */
    @Then("^User should not be able to create instruction and error message should be displayed$")
    public void user_should_not_be_able_to_create_instruction_and_error_message_should_be_displayed() throws Throwable {
        String vObjFailCvvAuth = Constants.TopupWalletOR.getProperty("FailCvvAuth");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFailCvvAuth, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjFailCvvAuth, ""));
    }

    @When("^User enters Payment currency Amount \"([^\"]*)\" and waits for rate to get refresh clicks continue button$")
    public void user_enters_Payment_currency_Amount_and_waits_for_rate_to_get_refresh_clicks_continue_button(String amount) throws Throwable {
        LogCapture.info("Entering Currency and waiting before clicking continue button....");
        String vObjPayCurrencyAMT = Constants.TopupWalletOR.getProperty("PaymentCurrencyAMT");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayCurrencyAMT, amount));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayCurrencyAMT, "enter"));

        Constants.key.pause("65", "");

        String vObjButtonBuyCur1 = Constants.TopupWalletOR.getProperty("ButtonBuyCur1");
        Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur1, ""));

    }

    @And("^User should get error message for (Higher|Lower) transfer limit for (GBP|AUD|EUR|USD|CAD|SGD)$")
    public void userShouldGetErrorMessageForHigherTransferLimit(String amt, String currency) throws Exception {
        if (currency.equals("GBP")) {
            if (amt.equals("Higher")) {
                String vObjHigherLimitError = Constants.DashboardOR.getProperty("HigherLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjHigherLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjHigherLimitError, ""));
            } else if (amt.equals("Lower")) {
                String vObjLowerLimitError = Constants.DashboardOR.getProperty("LowerLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLowerLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjLowerLimitError, ""));
            }
        } else if (currency.equals("AUD")) {
            if (amt.equals("Higher")) {
                String vObjAUDHigherLimitError = Constants.DashboardOR.getProperty("AUDHigherLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAUDHigherLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjAUDHigherLimitError, ""));
            } else if (amt.equals("Lower")) {
                String AUDLowerLimitError = Constants.DashboardOR.getProperty("AUDLowerLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(AUDLowerLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(AUDLowerLimitError, ""));
            }
        } else if (currency.equals("EUR")) {
            if (amt.equals("Higher")) {
                String vObjEURHigherLimitError = Constants.DashboardOR.getProperty("EURHigherLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEURHigherLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjEURHigherLimitError, ""));
            } else if (amt.equals("Lower")) {
                String EURLowerLimitError = Constants.DashboardOR.getProperty("EURLowerLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(EURLowerLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(EURLowerLimitError, ""));
            }
        } else if (currency.equals("USD")) {
            if (amt.equals("Higher")) {
                String vObjUSDHigherLimitError = Constants.DashboardOR.getProperty("USDHigherLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUSDHigherLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjUSDHigherLimitError, ""));
            } else if (amt.equals("Lower")) {
                String USDLowerLimitError = Constants.DashboardOR.getProperty("USDLowerLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(USDLowerLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(USDLowerLimitError, ""));
            }
        } else if (currency.equals("CAD")) {
            if (amt.equals("Higher")) {
                String vObjCADHigherLimitError = Constants.DashboardOR.getProperty("CADHigherLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCADHigherLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjCADHigherLimitError, ""));
            } else if (amt.equals("Lower")) {
                String CADLowerLimitError = Constants.DashboardOR.getProperty("CADLowerLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CADLowerLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(CADLowerLimitError, ""));
                //Assert.assertEquals("PASS", Constants.key.verifyText(CADLowerLimitError, "That amount is below our minimum transaction limit of EUR 100.00. Please enter a higher amount."));
            }

        } else if (currency.equals("SGD")) {
            if (amt.equals("Higher")) {
                String vObjSGDHigherLimitError = Constants.DashboardOR.getProperty("SGDHigherLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSGDHigherLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjSGDHigherLimitError, ""));
            } else if (amt.equals("Lower")) {
                String SGDLowerLimitError = Constants.DashboardOR.getProperty("SGDLowerLimitError");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SGDLowerLimitError, ""));
                Assert.assertEquals("PASS", Constants.key.exist(SGDLowerLimitError, ""));

            }
        }


        //Assert.assertEquals("PASS", Constants.key.verifyText(CADLowerLimitError, "That amount is below our minimum transaction limit of EUR 100.00. Please enter a higher amount."));
    }


    @And("^User enters Wallet currency Amount \"([^\"]*)\"$")
    public void userEntersWalletCurrencyAmount(String amount) throws Throwable {
        String vObjWalletCurrencyAMT = Constants.TopupWalletOR.getProperty("WalletCurrencyAMT");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjWalletCurrencyAMT, amount));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjWalletCurrencyAMT, "enter"));

    }

    @Then("^User should successfully be able top up wallet and click on to Activity history link$")
    public void user_should_successfully_be_able_top_up_wallet_and_click_on_to_Activity_history_link() throws
            Throwable {
        LogCapture.info("Activity History loading ......");
        // String vActData ="Activity";
        String vobjectActivityHistoryLink = Constants.TopupWalletOR.getProperty("ActivityHistoryLink");
        String vActivityHistoryTitle = Constants.TopupWalletOR.getProperty("ActivityHistoryTitle");
        Assert.assertEquals("PASS", Constants.key.click(vobjectActivityHistoryLink, ""));
        LogCapture.info("User successfully landed on Activity page...");
        Assert.assertEquals("PASS", Constants.key.exist(vActivityHistoryTitle, ""));
    }

    @And("^User clicks on Activate your Account link$")
    public void user_clicks_on_Activate_your_Account_link() throws Throwable {
        LogCapture.info("Activation Link...................");
        String vObjActButton = Constants.loginPageOR.getProperty("ActivationLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjActButton, ""));
        Constants.key.pause("2", "");
    }

    @Then("^User will Land on Activation Page$")
    public void user_will_Land_on_Activation_Page() throws Throwable {
        String vDetailsPage = Constants.loginPageOR.getProperty("VerifyPage");
        Assert.assertEquals("PASS", Constants.key.verifyText(vDetailsPage, "Activate your account online"));

    }

    @And("^Enters the EmailID \"([^\"]*)\" and Click on Send me a Link$")
    public void enters_the_EmailID_and_Click_on_Send_me_a_Link(String userName) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vObjUser = Constants.loginPageOR.getProperty("OfflineEmail_ID");
        LogCapture.info("User Name " + vUserName + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));

        String vObjLoginButton = Constants.loginPageOR.getProperty("Send_a_Link");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
        Constants.key.pause("2", "");
    }

    @Then("^System should display (FCG|CD|TORFX|TMO|RAMSDENS|TORAU|HL|CDINC|CDLCA|HLEU) error message as we need to verify some details$")
    public void system_should_display_error_message_as_we_need_to_verify_some_details(String application) throws
            Throwable {
        if (application.equalsIgnoreCase("FCG")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("CD")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("CD_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("TORFX")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("TORFX_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("TMO")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("TMO_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("Ramsdens")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("RAMSDENS_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("TORAU")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("TORAU_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("HL")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("HL_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("CDINC")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("CDINC_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("CDLCA")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("CDLCA_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("HLEU")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("VerificationErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("HLEU_TestDataValidationMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        }
        //We need to verify some details with you. Please call us on +44 (0) 207 847 9250 to speak to customer support.


    }

    @Then("^System should display relevant (FCG|CD|TORFX|TMO|RAMSDENS|TORAU|HL) error message related to the online active user$")
    public void system_should_display_relevant_error_message_related_to_the_online_active_user(String application) throws
            Throwable {
        if (application.equalsIgnoreCase("FCG")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("OnlineUserErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("ActExistingErrorMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of s2 is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("CD")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("OnlineUserErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("CD_ActExistingErrorMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of s2 is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("TORFX")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("OnlineUserErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("TORFX_ActExistingErrorMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of s2 is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));

        } else if (application.equalsIgnoreCase("TMO")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("OnlineUserErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("TMO_ActExistingErrorMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of s2 is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));

        } else if (application.equalsIgnoreCase("RAMSDENS")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("OnlineUserErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("Ramsdens_ActExistingErrorMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of s2 is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));

        } else if (application.equalsIgnoreCase("TORAU")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("OnlineUserErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("TORFX_ActExistingErrorMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of s2 is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        } else if (application.equalsIgnoreCase("HL")) {
            String vobjErrorMessage = Constants.loginPageOR.getProperty("OnlineUserErrorMessage");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("HL_ActExistingErrorMsg");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of s2 is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        }

    }

    @Then("^User enters the UserName \"([^\"]*)\" password \"([^\"]*)\" and click login button$")
    public void user_enters_the_UserName_password_and_click_login_button(String userName, String password) throws
            Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.loginPageOR.getProperty("FCG_Username");
        String vObjPass = Constants.loginPageOR.getProperty("FCG_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.loginPageOR.getProperty("LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }


    @Then("^User Clicks on (Transfer|Top-up|Recipients|Activity|Rate alerts|Recommend us|Profile Management) Tab present on top$")
    public void user_Clicks_on_Transfer_Button_at_the_Header(String tab) throws Throwable {
        LogCapture.info("Clicking on " + tab + "Tab");
        if (tab.equals("Transfer")) {
            String vObjTransferTab = Constants.DashboardOR.getProperty("TransferTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjTransferTab, ""));

            /*String vObjTransferTitle = Constants.DashboardOR.getProperty("TransferTitle");
            Assert.assertEquals("PASS", Constants.key.exist(vObjTransferTitle, ""));*/

        } else if (tab.equals("Top-up")) {
            String vObjTopUpTab = Constants.DashboardOR.getProperty("TopUpTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjTopUpTab, ""));

            String vObjTopUpTitle = Constants.DashboardOR.getProperty("TopUpTitle");
            Assert.assertEquals("PASS", Constants.key.exist(vObjTopUpTitle, ""));

        } else if (tab.equals("Recipients")) {
            String vObjRecipientTab = Constants.DashboardOR.getProperty("RecipientTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjRecipientTab, ""));

            String vObjRecipientTitle = Constants.DashboardOR.getProperty("RecipientTitle");
            Assert.assertEquals("PASS", Constants.key.exist(vObjRecipientTitle, ""));

        } else if (tab.equals("Activity")) {
            String vObjActivityTab = Constants.DashboardOR.getProperty("ActivityTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjActivityTab, ""));

            String vObjActivityTitle = Constants.DashboardOR.getProperty("ActivityTitle");
            Assert.assertEquals("PASS", Constants.key.exist(vObjActivityTitle, ""));

        } else if (tab.equals("Rate alerts")) {
            String vObjRateAletTab = Constants.DashboardOR.getProperty("RateAletTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjRateAletTab, ""));

         /*   String vObjRateAlertTitle = Constants.DashboardOR.getProperty("RateAlertTitle");
            Assert.assertEquals("PASS", Constants.key.exist(vObjRateAlertTitle, ""));*/

        } else if (tab.equals("Recommend us")) {
            String vRecommendUsTab = Constants.DashboardOR.getProperty("RecommendUsTab");
            Assert.assertEquals("PASS", Constants.key.click(vRecommendUsTab, ""));

//            String vRecommendUsPage = Constants.DashboardOR.getProperty("RecommendUsPage");
//            Assert.assertEquals("PASS", Constants.key.verifyText(vRecommendUsPage, "Recommend your friends, earn £50 in vouchers!"));

        } else if (tab.equals("Profile Management")) {
            String vObjUserNameTab = Constants.DashboardOR.getProperty("UserNameTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjUserNameTab, ""));

            String vObjProfileManagementButton = Constants.DashboardOR.getProperty("ProfileManagementButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProfileManagementButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjProfileManagementButton, ""));

            String vObjProfileManagementPageHeader = Constants.DashboardOR.getProperty("ProfileManagementPageHeader");
            Assert.assertEquals("PASS", Constants.key.exist(vObjProfileManagementPageHeader, ""));
        }

    }

    @Then("^User Clicks on FAQ Button$")
    public void user_Clicks_on_FAQ_Button() throws Throwable {
        LogCapture.info("Check FAQ Button......");
        Constants.key.pause("2", "");
        String vObjFAQButton = Constants.HelpOR.getProperty("FAQButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjFAQButton, ""));
    }

    @Then("^Click on each list of element on Frame$")
    public void click_on_each_list_of_element_on_Frame() throws Throwable {
        LogCapture.info("Click on each list of element......");
        Constants.key.pause("2", "");
        String vObjList = Constants.HelpOR.getProperty("FAQList");
        Assert.assertEquals("PASS", Constants.key.ClickEachElementOfFrame(vObjList, ""));
    }

    @Then("^User Should be able to view all the details onto the FAQ Section$")
    public void user_Should_be_able_to_view_all_the_details_onto_the_FAQ_Section() throws Throwable {
        LogCapture.info("Check FAQ Page......");
        String vObjFAQDashboard = Constants.HelpOR.getProperty("FAQDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjFAQDashboard, "FAQ"));
    }

    @Then("^User Clicks on Close button$")
    public void user_Clicks_on_Close_button() throws Throwable {
        LogCapture.info("Close the Help Functionality......");
        String vObjCloseButton = Constants.HelpOR.getProperty("Close");
        Assert.assertEquals("PASS", Constants.key.click(vObjCloseButton, ""));
    }

    @When("^Clicks on Help Button$")
    public void clicks_on_Help_Button() throws Throwable {
        String vObjHelpButton = Constants.HelpOR.getProperty("HelpButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjHelpButton, ""));
    }

    @Then("^System will open up the (Having trouble|Need help) popup$")
    public void system_will_open_up_the_Having_trouble_popup(String option) throws Throwable {
        LogCapture.info("Loading Help Module......");
        if (option.equals("Having trouble")) {
            String vObjHavingTrouble = Constants.HelpOR.getProperty("HavingTrouble");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjHavingTrouble, "Having trouble?"));
           /* String vCloseHelp = Constants.DashboardOR.getProperty("CloseHelp");
            Assert.assertEquals("PASS", Constants.key.click(vCloseHelp,""));*/
//            Below condition will check if close option for any of tab is present, if Yes it will close to proceed
            String vCloseSection = Constants.DashboardOR.getProperty("CloseSection");
            if (Constants.driver.findElements(By.xpath(vCloseSection)).size() > 0) {
                Assert.assertEquals("PASS", Constants.key.click(vCloseSection, ""));
            } else {
            }
        } else if (option.equals("Need help")) {
            String vCDNeedhelp = Constants.HelpOR.getProperty("CDNeedhelp");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCDNeedhelp, "Need help?"));
            String vCloseHelp = Constants.DashboardOR.getProperty("CloseHelp");
            Assert.assertEquals("PASS", Constants.key.click(vCloseHelp, ""));
//            Below condition will check if close option for any of tab is present, if Yes it will close to proceed
            String vCloseSection = Constants.DashboardOR.getProperty("CloseSection");
            if (Constants.driver.findElements(By.xpath(vCloseSection)).size() > 0) {
                Assert.assertEquals("PASS", Constants.key.click(vCloseSection, ""));
            } else {
            }
        }
    }

    @When("^User enter UserName \"([^\"]*)\" and password of other organization user \"([^\"]*)\" and click login button$")
    public void user_enter_UserName_and_password_of_other_organization_user_and_click_login_button(String
                                                                                                           userName, String password) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.loginPageOR.getProperty("FCG_Username");
        String vObjPass = Constants.loginPageOR.getProperty("FCG_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.loginPageOR.getProperty("LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @Then("^User Should see error message as Sorry we don't recognise your log in details for (FCG|CD|TORFX|RAMSDENS|TORAU|TMO|HL)$")
    public void user_Should_see_error_message_as_Sorry_we_don_t_recognise_your_log_in_details(String application) throws
            Throwable {
        if (application.equals("FCG")) {
            String vObjTransferLink = Constants.loginPageOR.getProperty("Error_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferLink, "Sorry, we don't recognise your log in details."));
        } else if (application.equals("CD")) {
            String vObjTransferLink = Constants.loginPageOR.getProperty("Error_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferLink, "Sorry, we can't log you in"));
        } else if (application.equals("TORFX")) {
            String vObjTransferLink = Constants.loginPageOR.getProperty("Error_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferLink, "Sorry, we can't log you in"));
        } else if (application.equals("RAMSDENS")) {
            String vObjTransferLink = Constants.loginPageOR.getProperty("Error_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferLink, "Sorry, we can't log you in"));
        } else if (application.equals("TORAU")) {
            String vObjTransferLink = Constants.loginPageOR.getProperty("Error_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferLink, "Sorry, we can't log you in"));
        } else if (application.equals("HL")) {
            String vObjTransferLink = Constants.loginPageOR.getProperty("Error_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferLink, "Sorry, we can't log you in"));
        } else if (application.equals("TMO")) {
            String vObjTransferLink = Constants.loginPageOR.getProperty("Error_Message");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferLink, "Sorry, we can't log you in"));
        }
    }


    @And("^User navigate to (FCG|CD|TORFX|RAMSDENS|TORAU|HL|TMO|TMOs) portal \"([^\"]*)\" and Clicks on Signup button$")
    public void user_navigate_to_FCG_portal_and_Clicks_on_Signup_button(String application, String vUrl) throws Throwable {
        if (application.equalsIgnoreCase("FCG")) {
            LogCapture.info(application + " Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            String vObjSignUpButton = Constants.loginPageOR.getProperty("FCG_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
        } else if (application.equalsIgnoreCase("CD")) {
            LogCapture.info(application + " Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            String vObjSignUpButton = Constants.loginPageOR.getProperty("CD_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
        } else if (application.equalsIgnoreCase("TORFX")) {
            LogCapture.info(application + " Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            String vObjSignUpButton = Constants.loginPageOR.getProperty("TORFX_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
        } else if (application.equalsIgnoreCase("RAMSDENS")) {
            LogCapture.info(application + " Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            String vObjSignUpButton = Constants.loginPageOR.getProperty("RAMSDENS_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
        } else if (application.equalsIgnoreCase("TORAU")) {
            LogCapture.info(application + " Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            String vObjSignUpButton = Constants.loginPageOR.getProperty("TORAU_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
        } else if (application.equalsIgnoreCase("HL")) {
            LogCapture.info(application + " Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            String vObjSignUpButton = Constants.loginPageOR.getProperty("HL_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
        } else if (application.equalsIgnoreCase("TMO")) {
            LogCapture.info(application + " Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            String vObjSignUpButton = Constants.loginPageOR.getProperty("TMO_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
            String vObjSignUpButton1 = Constants.loginPageOR.getProperty("TORAU_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton1, ""));
        } else if (application.equalsIgnoreCase("TMOs")) {
            LogCapture.info(application + " Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            String vObjSignUpButton = Constants.loginPageOR.getProperty("TMO_SignUp_Button");
            LogCapture.info("User is clicking signup button for " + application);
            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton, ""));
//            String vObjSignUpButton1 = Constants.loginPageOR.getProperty("TORAU_SignUp_Button");
//            LogCapture.info("User is clicking signup button for " + application);
//            Assert.assertEquals("PASS", Constants.key.click(vObjSignUpButton1, ""));
        }
    }


    @Then("^User is Navigated to displayPrimaryInfoForm page Successfully$")
    public void user_is_Navigated_to_displayPrimaryInfoForm_page_Successfully() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Registration in Processs....");
        Constants.key.pause("2", "");
        String vRegProcess = Constants.SignUp.getProperty("Header");
        Assert.assertEquals("PASS", Constants.key.verifyText(vRegProcess, "Tell us what type of account you're looking for."));
    }

    @Then("^Selects Primary Option and Click on Next$")
    public void selects_Primary_Option_and_Click_on_Next() throws Throwable {
        LogCapture.info("Registration in Processs....");
        String vPersonalRadioButton = Constants.SignUp.getProperty("PersonalRadioButton");
        Assert.assertEquals("PASS", Constants.key.click(vPersonalRadioButton, ""));
        String vNext_Button = Constants.SignUp.getProperty("Next_Button");
        Assert.assertEquals("PASS", Constants.key.click(vNext_Button, ""));
    }

    @When("^User enters EmailAddress \"([^\"]*)\" password \"([^\"]*)\" and click on Next$")
    public void user_enters_EmailAddress_password_and_click_on_Next(String emailID, String SignUp_Password) throws
            Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Registration in Processs....");
        vSignUp_EmailID = Constants.key.uniqueEmailAddress(emailID, "");
        String vSignUp_Password = SignUp_Password;
        String vObjSignUp_EmailID = Constants.SignUp.getProperty("SignUp_EmailID");
        String vObjSignUp_Password = Constants.SignUp.getProperty("SignUp_Password");
        LogCapture.info("User entering email Address...." + vSignUp_EmailID);
        LogCapture.info("Sign Up Email ID " + emailID + ", Sign Up Password " + SignUp_Password + " is validated ....");
        //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSignUp_EmailID, ""));
        LogCapture.info("User entering email Address...." + vSignUp_EmailID);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSignUp_EmailID, vSignUp_EmailID));
        LogCapture.info("User entering Password...." + vSignUp_Password);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSignUp_Password, vSignUp_Password));
        System.out.println("Email" + emailID);
        String vVerify_Button = Constants.SignUp.getProperty("Verify_Button");
        Assert.assertEquals("PASS", Constants.key.click(vVerify_Button, ""));
        LogCapture.info("Registration in Processs....");
    }

    @Then("^User will be navigated to Details Page$")
    public void user_will_be_navigated_to_Details_Page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Registration in Processs....");
        Constants.key.pause("2", "");
        String vDetailsPage = Constants.SignUp.getProperty("Details");
        Assert.assertEquals("PASS", Constants.key.verifyText(vDetailsPage, "Your details"));
    }

    @Then("^User Enters the details firstname \"([^\"]*)\" Lastname \"([^\"]*)\"$")
    public void user_Enters_the_details_firstname_Lastname(String Sign_F_Name, String Sign_L_Name) throws
            Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vSign_F_Name = Constants.SignUp.getProperty("Sign_F_Name");
        String vSign_L_Name = Constants.SignUp.getProperty("Sign_L_Name");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSign_L_Name, ""));
        LogCapture.info("Sign Up First Name " + Sign_F_Name + ", Sign Up Last Name " + Sign_L_Name + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vSign_F_Name, 4));
        Constants.key.pause("2", "");
        //Assert.assertEquals("PASS", Constants.key.writeInInput(vSign_F_Name, Sign_F_Name));
        Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vSign_L_Name, 4));
        //Assert.assertEquals("PASS", Constants.key.writeInInput(vSign_L_Name, Sign_L_Name));
        Constants.key.pause("2", "");
    }

    @Then("^User Enters day \"([^\"]*)\" month \"([^\"]*)\" year \"([^\"]*)\"$")
    public void user_Enters_day_month_year(String day, String month, String year) throws Throwable {
        LogCapture.info("Selecting Date of birth......................");
        LogCapture.info("Select Date..............");
        String Day = Constants.SignUp.getProperty("Day");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Day, ""));
        LogCapture.info("Entering Date in Date of Birth......................");
        String DaySearchValue = Constants.SignUp.getProperty("DaySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(DaySearchValue, day));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(DaySearchValue, "enter"));
        LogCapture.info("Select Month ...........");
        String Month = Constants.SignUp.getProperty("Month");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Month, ""));
        LogCapture.info("Entering Month in Date of Birth......................");
        String MonthSearchValue = Constants.SignUp.getProperty("DaySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(MonthSearchValue, month));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(MonthSearchValue, "enter"));
        LogCapture.info("Select Year.............");
        String Year = Constants.SignUp.getProperty("Year");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Year, ""));
        LogCapture.info("Entering Date in Year of Birth......................");
        String YearSearchValue = Constants.SignUp.getProperty("DaySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(YearSearchValue, year));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(YearSearchValue, "enter"));
    }

    @And("^Selects country \"([^\"]*)\" address \"([^\"]*)\" and Select Joint Account type as Joint$")
    public void selects_country_address_and_Select_Joint_Account_type_as_Joint(String CountrySearch, String
            address) throws
            Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Select Country.............");
        String Country = Constants.SignUp.getProperty("Country");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Country, ""));
        LogCapture.info("Enter Country.....................");
        String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, CountrySearch));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));
        LogCapture.info("Enter Address.....................");
        String AddressSearchValue = Constants.SignUp.getProperty("Address_Filed");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(AddressSearchValue, address));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(AddressSearchValue, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(AddressSearchValue, "enter"));
        Constants.key.pause("2", "");
        LogCapture.info("Select Account type as Joint.....................");
        String JointAccount = Constants.SignUp.getProperty("JointAccount");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(JointAccount, ""));
        Constants.key.pause("5", "");
    }

    @And("^user Enters Secondary Contact Deatils Firstname \"([^\"]*)\" LastName \"([^\"]*)\"$")
    public void user_Enters_Secondary_Contact_Deatils_Firstname_LastName(String Sign_F_Name, String Sign_L_Name) throws
            Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vSign_F_Name = Constants.SignUp.getProperty("SignUp_Second_F_Name");
        String vSign_L_Name = Constants.SignUp.getProperty("SignUp_Second_L_Name");
        LogCapture.info("Sign Up First Name " + Sign_F_Name + ", Sign Up Last Name " + Sign_L_Name + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vSign_F_Name, 5));
        Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vSign_L_Name, 5));
        Constants.key.pause("2", "");
    }

    @Then("^User Enters the detail for second Contact day \"([^\"]*)\" month \"([^\"]*)\" year \"([^\"]*)\"$")
    public void user_Enters_the_detail_for_second_Contact_day_month_year(String day, String month, String year) throws
            Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Selecting Date of birth......................");
        LogCapture.info("Select Date..............");
        String Day = Constants.SignUp.getProperty("DaySecondary");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Day, ""));
        LogCapture.info("Entering Date in Date of Birth......................");
        String DaySearchValue = Constants.SignUp.getProperty("DaySearchSecondary");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(DaySearchValue, day));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(DaySearchValue, "enter"));
        LogCapture.info("Select Month ...........");
        String Month = Constants.SignUp.getProperty("MonthSecondary");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Month, ""));
        LogCapture.info("Entering Month in Date of Birth......................");
        String MonthSearchValue = Constants.SignUp.getProperty("DaySearchSecondary");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(MonthSearchValue, month));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(MonthSearchValue, "enter"));
        LogCapture.info("Select Year.............");
        String Year = Constants.SignUp.getProperty("YearSecondary");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Year, ""));
        LogCapture.info("Entering Date in Year of Birth......................");
        String YearSearchValue = Constants.SignUp.getProperty("DaySearchSecondary");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(YearSearchValue, year));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(YearSearchValue, "enter"));
    }

    @And("^User enters EmailAddress \"([^\"]*)\" and Click on Next$")
    public void user_enters_EmailAddress_and_Click_on_Next(String emailID) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        vSignUp_SecondaryEmailID = Constants.key.uniqueEmailAddress(emailID, "");
        String vObjSignUp_EmailID = Constants.SignUp.getProperty("SecondEmail");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSignUp_EmailID, vSignUp_SecondaryEmailID));
        System.out.println("Email" + vSignUp_SecondaryEmailID);
        LogCapture.info("Registration in Processs for secondary Email...." + vSignUp_SecondaryEmailID);
        String vNext_Button = Constants.SignUp.getProperty("NextButonJointAccount");
        Assert.assertEquals("PASS", Constants.key.click(vNext_Button, ""));
        LogCapture.info("Registration in Processs....");
    }


    @Then("^User Enters Mobile number for both the Contacts primary_CountryCode \"([^\"]*)\" Secondary_CountryCode \"([^\"]*)\" and Mobile number\"([^\"]*)\" and Click on Send Pin$")
    public void user_Enters_Mobile_number_for_both_the_Contacts_primary_CountryCode_Secondary_CountryCode_and_Mobile_number_and_Click_on_Send_Pin
            (String PrimaryCountryCodeNumber, String SecondaryCountryCodeNumber, String number) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // Primary Phone number Country Code
        String PrimaryCountryCode = Constants.SignUp.getProperty("PrimaryMobileCountryCode");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(PrimaryCountryCode, ""));
        LogCapture.info("Entering Data in country Code......................");
        String vPrimaryPhone = Constants.SignUp.getProperty("PrimaryCountryCodeSearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPrimaryPhone, PrimaryCountryCodeNumber));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPrimaryPhone, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPrimaryPhone, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPrimaryPhone, "enter"));
        // Secondary Phone number Country Code
        String SecondaryCountryCode = Constants.SignUp.getProperty("SecondaryMobileCountryCode");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(SecondaryCountryCode, ""));
        LogCapture.info("Entering Data in country Code......................");
        String vSecondaryPhone = Constants.SignUp.getProperty("SecondaryCountryCodeSearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSecondaryPhone, SecondaryCountryCodeNumber));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSecondaryPhone, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSecondaryPhone, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSecondaryPhone, "enter"));
        //Primary Phone Number
        String vPhone = Constants.SignUp.getProperty("PrimaryMobileText");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPhone, number));
        //Secondary Phone Number
        String vSecondPhone = Constants.SignUp.getProperty("SecondaryMobileText");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSecondPhone, number));
        String vSendOTP = Constants.SignUp.getProperty("SendPin");
        Assert.assertEquals("PASS", Constants.key.click(vSendOTP, ""));
        Assert.assertEquals("PASS", Constants.key.pause("10", ""));
        LogCapture.info("OTP in Processs....");
    }

    @And("^Selects the Currency \"([^\"]*)\" amount\"([^\"]*)\" click on CheckBox and Click on Continue$")
    public void selects_the_Currency_amount_click_on_CheckBox_and_Click_on_Continue(String Currency, String
            amount) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // Select Currency
        String vSelectCurrency = Constants.SignUp.getProperty("SelectCurrency");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCurrency, ""));
        //Enter Currency
        LogCapture.info("Entering Currency......................");
        String vEnterCurrency = Constants.SignUp.getProperty("EnterCurrency");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCurrency, Currency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCurrency, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCurrency, "enter"));
        //Enter Amount
        LogCapture.info("Entering Amount......................");
        String vAmount = Constants.SignUp.getProperty("EnterAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vAmount, amount));
        // Select CheckBox
        String vCheckBox = Constants.SignUp.getProperty("SelectCheckBox");
        System.out.println("Xpath..." + vCheckBox);
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vCheckBox, ""));
        //Click Continue
        String vContinueButton = Constants.SignUp.getProperty("Select_Continue");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vContinueButton, ""));
    }

    //Skip Document
    @Then("^User Clicks on Skip Document$")
    public void user_Clicks_on_Skip_Document() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vSkipButton = Constants.SignUp.getProperty("Skip");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSkipButton, ""));
    }

    @Then("^System will Show (Success|Success2|Success3) message for (TORFX|CD|FCG|RAMSDENS|TORAU|HL|TMO) as Signup is complete$")
    public void system_will_Show_Success_message_for_TORFX_as_Signup_is_complete(String successMessage, String application) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjSkipButton = Constants.CreateFxTicketOR.getProperty("SkipButton");
        String vElementExist = Constants.key.exist(vObjSkipButton, "");
        if (vElementExist.equals("PASS")) {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSkipButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSkipButton, ""));

        }
        int count = 0;
        LogCapture.info("User Validating Success Message....");
        String vSignUpComplete = Constants.SignUp.getProperty("WelcomeMessage");
        // String vSignUpComplete = Constants.SignUp.getProperty("SignUpComplete");
        do {
            count = count + 1;
        } while ((!Constants.driver.findElement(By.xpath(vSignUpComplete)).isDisplayed()));//||!Constants.driver.findElement(By.xpath(vSignUpComplete)).isDisplayed());


        LogCapture.info("Repeat the Loop Untill the Registeration : Count:->" + count);
        Constants.key.pause("1", "");
        if (application.equalsIgnoreCase("CD")) {

            if ((Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Welcome to Currencies Direct\n" +
                    "      To complete your registration please check your emails and provide your documentation within 72 hours."))) {
                LogCapture.info("Registeration is successfull with Welomce Message");
            } else if (Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Thank you for registering!\n" +
                    "We will let you know as soon as we have approved your account.")) {
                LogCapture.info("Registeration is successfull");
            } else {
                LogCapture.info("Registeration is not successfull");
                // Assert.fail();
            }
        } else if (application.equalsIgnoreCase("FCG")) {

            if ((Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Welcome to Foremost Currency!\n" +
                    "To complete your registration please check your emails and provide your documentation within 72 hours."))) {
                LogCapture.info("Registeration is successfull with Welomce Message");
            } else if (Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Thank you for registering!\n" +
                    "We will let you know as soon as we have approved your account.")) {
                LogCapture.info("Registeration is successfull");
            } else {
                LogCapture.info("Registeration is not successfull");
                //Assert.fail();
            }
        } else if (application.equalsIgnoreCase("HL")) {

            if ((Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Welcome to Hargreaves Lansdown\n" +
                    "To complete your registration please check your emails and provide your documentation within 72 hours."))) {
                LogCapture.info("Registeration is successfull with Welomce Message");
            } else if (Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Thank you for registering!\n" +
                    "We will let you know as soon as we have approved your account.")) {
                LogCapture.info("Registeration is successfull");
            } else {
                LogCapture.info("Registeration is not successfull");

            }
        } else if (application.equalsIgnoreCase("RAMSDENS")) {

            if ((Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Welcome to Ramsdens\n" +
                    "To complete your registration please check your emails and provide your documentation within 72 hours."))) {
                LogCapture.info("Registeration is successfull with Welomce Message");
            } else if (Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Thank you for registering!\n" +
                    "We will let you know as soon as we have approved your account.")) {
                LogCapture.info("Registeration is successfull");
            } else {
                LogCapture.info("Registeration is not successfull");

            }
        } else if (application.equalsIgnoreCase("TMO")) {

            if ((Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Welcome to TorFX\n" +
                    "To complete your registration please check your emails and provide your documentation within 72 hours."))) {
                LogCapture.info("Registeration is successfull with Welomce Message");
            } else if (Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Thank you for registering!\n" +
                    "We will let you know as soon as we have approved your account.")) {
                LogCapture.info("Registeration is successfull");
            } else {
                LogCapture.info("Registeration is not successfull");

            }
        } else if (application.equalsIgnoreCase("TORAU")) {

            if ((Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Welcome to TorFX\n" +
                    "To complete your registration please check your emails and provide your documentation within 72 hours."))) {
                LogCapture.info("Registeration is successfull with Welomce Message");
            } else if (Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Thank you for registering!\n" +
                    "We will let you know as soon as we have approved your account.")) {
                LogCapture.info("Registeration is successfull");
            } else {
                LogCapture.info("Registeration is not successfull");

            }
        } else if (application.equalsIgnoreCase("TORFX")) {

            if ((Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Welcome to TorFX\n" +
                    "To complete your registration please check your emails and provide your documentation within 72 hours."))) {
                LogCapture.info("Registeration is successfull with Welomce Message");
            } else if (Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Thank you for registering!\n" +
                    "We will let you know as soon as we have approved your account.")) {
                LogCapture.info("Registeration is successfull");
            } else {
                LogCapture.info("Registeration is not successfull");

            }
        }
    }

//        if (application.equalsIgnoreCase("FCG")) {
//            LogCapture.info("SignUp in progress..." + application);
//            if (successMessage.equalsIgnoreCase("Success2")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("SignUpComplete");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Thank you for registering!"));
//            } else if (successMessage.equalsIgnoreCase("Success")) {
//                Constants.key.pause("2", "");
//                String vSignUpComplete = Constants.SignUp.getProperty("WelcomeMessage");
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to Foremost Currency!"));
//
//            } else if (successMessage.equalsIgnoreCase("Success3")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("KYCFailMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to Foremost Currency!"));
//
//            }
//
//        } else if (application.equalsIgnoreCase("RAMSDENS")) {
//            LogCapture.info("SignUp in progress..." + application);
//            if (successMessage.equalsIgnoreCase("Success2")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("SignUpComplete");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Thank you for registering!"));
//            } else if (successMessage.equalsIgnoreCase("Success")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("WelcomeMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to Ramsdens"));
//
//            } else if (successMessage.equalsIgnoreCase("Success3")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("KYCFailMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to Ramsdens"));
//            }
//        } else if (application.equalsIgnoreCase("TMO")) {
//            LogCapture.info("SignUp in progress..." + application);
//            if (successMessage.equalsIgnoreCase("Success1")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("SignUpComplete");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Thank you for registering!"));
//            } else if (successMessage.equalsIgnoreCase("Success")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("WelcomeMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to TorFX"));
//            } else if (successMessage.equalsIgnoreCase("Success3")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("KYCFailMessage");
//                LogCapture.info(vSignUpComplete);
//                String message = Constants.driver.findElement(By.xpath(vSignUpComplete)).getText();
//                LogCapture.info(message);
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to Travel Money Oz Transfers"));
//
//            }
//
//
//        } else if (application.equalsIgnoreCase("TORAU")) {
//            LogCapture.info("SignUp in progress..." + application);
//            if (successMessage.equalsIgnoreCase("Success1")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("SignUpComplete");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Thank you for registering!"));
//            } else if (successMessage.equalsIgnoreCase("Success")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("WelcomeMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to TorFX"));
//
//            } else if (successMessage.equalsIgnoreCase("Success3")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("KYCFailMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to Ramsdens"));
//
//            }
//
//        } else if (application.equalsIgnoreCase("TORFX")) {
//
//            LogCapture.info("SignUp in progress..." + application);
//            if (successMessage.equalsIgnoreCase("Success1")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("SignUpComplete");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Thank you for registering!"));
//            } else if (successMessage.equalsIgnoreCase("Success")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("WelcomeMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to TorFX!"));
//
//            } else if (successMessage.equalsIgnoreCase("Success3")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("KYCFailMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to TorFX"));
//            }
//
//        } else if (application.equalsIgnoreCase("HL")) {
//            LogCapture.info("SignUp in progress..." + application);
//            if (successMessage.equalsIgnoreCase("Success2")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("SignUpComplete");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Thank you for registering!"));
//            } else if (successMessage.equalsIgnoreCase("Success")) {
//                Constants.key.pause("2", "");
//                //String vTORFX_welcomeText = Constants.SignUp.getProperty("TORFX_welcomeText");
//                String vSignUpComplete = Constants.SignUp.getProperty("WelcomeMessage");
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//
//                Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Welcome to Hargreaves Lansdown"));
//
//
//            }
//        }else if (application.equalsIgnoreCase("CD")) {
//            LogCapture.info("SignUp in progress..." + application);
//            if (successMessage.equalsIgnoreCase("Success")) {
//                int count=0;
//                LogCapture.info("User Validating Success Message....");
//                String vSignUpComplete = Constants.SignUp.getProperty("WelcomeMessage");
//               // String vSignUpComplete = Constants.SignUp.getProperty("SignUpComplete");
//                do {
//                    count=count+1;
//                }while((!Constants.driver.findElement(By.xpath(vSignUpComplete)).isDisplayed()));//||!Constants.driver.findElement(By.xpath(vSignUpComplete)).isDisplayed());
//
//                LogCapture.info("Repeat the Loop Untill the Registeration : Count:->"+count);
//
//                //Constants.key.pause("2", "");
//
////                if(Constants.driver.findElement(By.xpath(vSignUpCompleteWelcome)).getText().contains("Welcome to Currencies Direct"))//||Constants.driver.findElement(By.xpath(vSignUpComplete)).getText().contains("Thank you for registering!")){
////                    LogCapture.info("Registeration is successfull");
////                        }
////                else{
////                    LogCapture.info("Registeration is not successfull");
////                    Assert.fail();
////                }
//
//                //String actual = Constants.driver.findElement(By.xpath(object)).getText();
//
//               // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//               // Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpCompleteWelcome, "Welcome to Currencies Direct"));
//
//
//
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vTORFX_welcomeText,""));
//                //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSignUpComplete, ""));
//                //Assert.assertEquals("PASS", Constants.key.verifyText(vSignUpComplete, "Thank you for registering!"));
//
//
//            }
//
//        }


    @And("^User Clicks on Close Button and User Clicks on Confirm Button$")
    public void user_Clicks_on_Close_Button_and_User_Clicks_on_Confirm_Button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vClose = Constants.loginPageOR.getProperty("DeleteRecipent");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vClose, ""));
        String vConfirm = Constants.loginPageOR.getProperty("ConfirmDelete");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vConfirm, ""));
    }

    @Then("^System Should Lands back on Recipent Page and Payee Should be Deleted$")
    public void system_Should_Lands_back_on_Recipent_Page_and_Payee_Should_be_Deleted() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Recipent Deleted Successfully ......");
        Constants.key.pause("5", "");
        String vRecipentText = Constants.loginPageOR.getProperty("RecipentDeleteConfirmation");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vRecipentText, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vRecipentText, "Recipient deleted successfully."));
    }

    @Then("^User will be able to view the Legal Entity based Phone \"([^\"]*)\" number on UI$")
    public void user_will_be_able_to_view_the_Legal_Entity_based_Phone_number_on_UI(String number) throws
            Throwable {
        String vLegalEntity = Constants.loginPageOR.getProperty("LegalEntityPhoneNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vLegalEntity, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vLegalEntity, number));

    }


    @Then("^User navigate to Profile Management$")
    public void user_navigate_to_Profile_Management() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vLoginSpan = Constants.loginPageOR.getProperty("LoginSpan");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vLoginSpan, ""));
        String vProfile = Constants.loginPageOR.getProperty("ProfileManagement");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vProfile, ""));
    }

    @Then("^Click on Account Section$")
    public void click_on_Account_Section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vAccountSection = Constants.loginPageOR.getProperty("AccountSection");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vAccountSection, ""));
    }

    @And("^Selects country \"([^\"]*)\" address \"([^\"]*)\" and Click on Next$")
    public void selects_country_address_and_Click_on_Next(String CountrySearch, String address) throws
            Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Select Country.............");
        String Country = Constants.SignUp.getProperty("Country");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Country, ""));
        LogCapture.info("Enter Country.....................");
        String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, CountrySearch));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));
        LogCapture.info("Enter Address.....................");
        String AddressSearchValue = Constants.SignUp.getProperty("Address_Filed");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(AddressSearchValue, address));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(AddressSearchValue, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(AddressSearchValue, "enter"));
        Constants.key.pause("2", "");
        String vNext_Button = Constants.SignUp.getProperty("NextButonJointAccount");
        Assert.assertEquals("PASS", Constants.key.click(vNext_Button, ""));
        LogCapture.info("Registration in Processs....");
    }

    @Then("^User Enters Mobile number for both the Contacts primary_CountryCode \"([^\"]*)\" and Mobile number\"([^\"]*)\" and Click on Send Pin$")
    public void user_Enters_Mobile_number_for_both_the_Contacts_primary_CountryCode_and_Mobile_number_and_Click_on_Send_Pin
            (String PrimaryCountryCodeNumber, String number) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // Primary Phone number Country Code
        String PrimaryCountryCode = Constants.SignUp.getProperty("PrimaryMobileCountryCode");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(PrimaryCountryCode, ""));
        LogCapture.info("Entering Data in country Code......................");
        String vPrimaryPhone = Constants.SignUp.getProperty("PrimaryCountryCodeSearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPrimaryPhone, PrimaryCountryCodeNumber));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPrimaryPhone, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPrimaryPhone, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPrimaryPhone, "enter"));
        //Primary Phone Number
        String vPhone = Constants.SignUp.getProperty("PrimaryMobileText");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vPhone, "selectAll"));
        Assert.assertEquals("PASS", Constants.key.clearText(vPhone));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPhone, number));
        String vSendOTP = Constants.SignUp.getProperty("SendPin");
        Assert.assertEquals("PASS", Constants.key.click(vSendOTP, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        LogCapture.info("OTP in Processs....");
    }

    @Then("^User will land on Dashboard$")
    public void user_will_land_on_Dashboard() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Dashboard loading ......");
        Constants.key.pause("2", "");
        String vobjectDashboard = Constants.DashboardOR.getProperty("ExchangeRateIBAN");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Check the exchange rate"));
    }

    @And("^Enters First Name \"([^\"]*)\" Last Name \"([^\"]*)\" selects Country \"([^\"]*)\" Currency \"([^\"]*)\" (Street Name|Address) \"([^\"]*)\" City \"([^\"]*)\" Postal Code \"([^\"]*)\" and Clicks on Continue$")
    public void entersFirstNameLastNameSelectsCountryCurrencyStreetNameCityPostalCodeAndClicksOnContinue(String FName, String LName, String Country, String Currency, String type, String StreetName, String City, String PostalCode) throws Throwable {
        LogCapture.info("Enter FirstName......................");
        String vFName = Constants.DashboardOR.getProperty("PayeeFirstName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vFName, FName));
        LogCapture.info("Enter Lastname......................");
        String vLName = Constants.DashboardOR.getProperty("PayeeLastName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vLName, LName));
        // Select Country
        String vSelectCountry = Constants.DashboardOR.getProperty("SelectCountryDropDown");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCountry, ""));
        //Enter Country
        LogCapture.info("Entering Country......................");
        String vEnterCountry = Constants.DashboardOR.getProperty("SelectCountryTextBox");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCountry, Country));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "enter"));
        // Select Currency
        String vSelectCurrency = Constants.DashboardOR.getProperty("SelectCurrencyDropDown");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCurrency, ""));
        //Enter Currency
        LogCapture.info("Entering Currency......................");
        String vEnterCurrency = Constants.DashboardOR.getProperty("SelectCurrencyTextBox");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCurrency, Currency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "enter"));

        // Enter Address(for inc & lca elements are different hence have to put it under condition)
        if (type.equals("Street Name")) {
            LogCapture.info("Entering Street Name......................");
            String vStreetName = Constants.DashboardOR.getProperty("StreetName");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vStreetName, StreetName));

            String vCity = Constants.DashboardOR.getProperty("City");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vCity, City));

            String vPostalCode = Constants.DashboardOR.getProperty("PostalCode");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCode, PostalCode));

        } else if (type.equals("Address")) {
            LogCapture.info("Entering Address......................");
            String vStreetName = Constants.DashboardOR.getProperty("PrimaryStreetName");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vStreetName, StreetName));

            String vCity = Constants.DashboardOR.getProperty("PrimaryCity");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vCity, City));

            String vPostalCode = Constants.DashboardOR.getProperty("PrimaryPostalCode");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCode, PostalCode));
        }

        // Press Continue
        String vContinue = Constants.DashboardOR.getProperty("Continue");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vContinue, ""));
    }

    @Then("^Click on Add a Recipent$")
    public void click_on_Add_a_Recipent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Select Recipent ......");
        String vSelectPayee = Constants.DashboardOR.getProperty("AddPayee");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectPayee, ""));
    }


    @Then("^Enters First Name \"([^\"]*)\" Last Name \"([^\"]*)\" selects Country \"([^\"]*)\" and Currency \"([^\"]*)\" and Clicks on Continue$")
    public void enters_First_Name_Last_Name_selects_Country_and_Currency_and_Clicks_on_Continue(String
                                                                                                        FName, String LName, String Country, String Currency) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Enter FirstName......................");
        String vFName = Constants.DashboardOR.getProperty("PayeeFirstName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vFName, FName));
        LogCapture.info("Enter Lastname......................");
        String vLName = Constants.DashboardOR.getProperty("PayeeLastName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vLName, LName));
        // Select Country
        String vSelectCountry = Constants.DashboardOR.getProperty("SelectCountryDropDown");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCountry, ""));
        //Enter Country
        LogCapture.info("Entering Country......................");
        String vEnterCountry = Constants.DashboardOR.getProperty("SelectCountryTextBox");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCountry, Country));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "enter"));
        // Select Currency
        String vSelectCurrency = Constants.DashboardOR.getProperty("SelectCurrencyDropDown");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCurrency, ""));
        //Enter Currency
        LogCapture.info("Entering Currency......................");
        String vEnterCurrency = Constants.DashboardOR.getProperty("SelectCurrencyTextBox");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCurrency, Currency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCurrency, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCurrency, "enter"));
        // Press Continue
        String vContinue = Constants.DashboardOR.getProperty("Continue");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vContinue, ""));
    }

    //11
     /*@And("^Enters First Name \"([^\"]*)\" Last Name \"([^\"]*)\" selects Country \"([^\"]*)\" Currency \"([^\"]*)\" Street Name \"([^\"]*)\" City \"([^\"]*)\" Postal Code \"([^\"]*)\" and Clicks on Continue$")
     public void entersFirstNameLastNameSelectsCountryCurrencyStreetNameCityPostalCodeAndClicksOnContinue(String FName, String LName, String Country, String Currency, String StreetName, String City, String PostalCode) throws Throwable {
         LogCapture.info("Enter FirstName......................");
         String vFName = Constants.DashboardOR.getProperty("PayeeFirstName");
         Assert.assertEquals("PASS", Constants.key.writeInInput(vFName, FName));
         LogCapture.info("Enter Lastname......................");
         String vLName = Constants.DashboardOR.getProperty("PayeeLastName");
         Assert.assertEquals("PASS", Constants.key.writeInInput(vLName, LName));
         // Select Country
         String vSelectCountry = Constants.DashboardOR.getProperty("SelectCountryDropDown");
         Assert.assertEquals("PASS", Constants.key.pause("2", ""));
         Assert.assertEquals("PASS", Constants.key.click(vSelectCountry, ""));
         //Enter Country
         LogCapture.info("Entering Country......................");
         String vEnterCountry = Constants.DashboardOR.getProperty("SelectCountryTextBox");
         Assert.assertEquals("PASS", Constants.key.pause("2", ""));
         Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCountry, Country));
         Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "downArrow"));
         Assert.assertEquals("PASS", Constants.key.pause("2", ""));
         Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "enter"));
         // Select Currency
         String vSelectCurrency = Constants.DashboardOR.getProperty("SelectCurrencyDropDown");
         Assert.assertEquals("PASS", Constants.key.pause("2", ""));
         Assert.assertEquals("PASS", Constants.key.click(vSelectCurrency, ""));
         //Enter Currency
         LogCapture.info("Entering Currency......................");
         String vEnterCurrency = Constants.DashboardOR.getProperty("SelectCurrencyTextBox");
         Assert.assertEquals("PASS", Constants.key.pause("2", ""));
         Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCurrency, Currency));
         Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "downArrow"));
         Assert.assertEquals("PASS", Constants.key.pause("2", ""));
         Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "enter"));
         // Enter Address
         String vStreetName = Constants.DashboardOR.getProperty("StreetName");
         Assert.assertEquals("PASS", Constants.key.writeInInput(vStreetName, StreetName));

         String vCity = Constants.DashboardOR.getProperty("City");
         Assert.assertEquals("PASS", Constants.key.writeInInput(vCity, City));

         String vPostalCode = Constants.DashboardOR.getProperty("PostalCode");
         Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCode, PostalCode));
         // Press Continue
         String vContinue = Constants.DashboardOR.getProperty("Continue");
         Assert.assertEquals("PASS", Constants.key.pause("2", ""));
         Assert.assertEquals("PASS", Constants.key.click(vContinue, ""));
     }*/
    @Then("^System will Land on add a Recipent bank detail Page$")
    public void system_will_Land_on_add_a_Recipent_bank_detail_Page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Recipent Page ......");
        Constants.key.pause("2", "");
        String vRecipentText = Constants.DashboardOR.getProperty("ValidateAddRecipentPage");
        Assert.assertEquals("PASS", Constants.key.verifyText(vRecipentText, "Add your recipient"));
    }


    @And("^Enters First Name \"([^\"]*)\" Last Name \"([^\"]*)\" selects Country \"([^\"]*)\" Currency \"([^\"]*)\" Street Name \"([^\"]*)\" City \"([^\"]*)\" Postal Code \"([^\"]*)\" and Clicks on Continue$")
    public void entersFirstNameLastNameSelectsCountryCurrencyStreetNameCityPostalCodeAndClicksOnContinue(String FName, String LName, String Country, String Currency, String StreetName, String City, String PostalCode) throws Throwable {
        LogCapture.info("Enter FirstName......................");
        String vFName = Constants.DashboardOR.getProperty("PayeeFirstName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vFName, FName));
        LogCapture.info("Enter Lastname......................");
        String vLName = Constants.DashboardOR.getProperty("PayeeLastName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vLName, LName));
        // Select Country
        String vSelectCountry = Constants.DashboardOR.getProperty("SelectCountryDropDown");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCountry, ""));
        //Enter Country
        LogCapture.info("Entering Country......................");
        String vEnterCountry = Constants.DashboardOR.getProperty("SelectCountryTextBox");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCountry, Country));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "enter"));
        // Select Currency
        String vSelectCurrency = Constants.DashboardOR.getProperty("SelectCurrencyDropDown");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCurrency, ""));
        //Enter Currency
        LogCapture.info("Entering Currency......................");
        String vEnterCurrency = Constants.DashboardOR.getProperty("SelectCurrencyTextBox");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterCurrency, Currency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vEnterCountry, "enter"));
        // Enter Address
        String vStreetName = Constants.DashboardOR.getProperty("StreetName");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vStreetName, StreetName));

        String vCity = Constants.DashboardOR.getProperty("City");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vCity, City));

        String vPostalCode = Constants.DashboardOR.getProperty("PostalCode");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCode, PostalCode));
        // Press Continue
        String vContinue = Constants.DashboardOR.getProperty("Continue");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vContinue, ""));
    }


    @Then("^User Enters some (Invalid|Valid) IBAN Number \"([^\"]*)\" and Click on RetriveBankDetails$")
    public void user_Enters_some_Invalid_IBAN_Number_and_Click_on_RetriveBankDetails(String type, String
            IBAN) throws
            Throwable {

        LogCapture.info("Entering Iban......................");
        String vEnterIBAN = Constants.DashboardOR.getProperty("IbanTextField");
        Assert.assertEquals("PASS", Constants.key.pause("15", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEnterIBAN, IBAN));
        String vContinue = Constants.DashboardOR.getProperty("RetriveBankDetailsButton");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vContinue, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
    }

    @Then("^System will give error message as Sorry the IBAN Number is InValid$")
    public void system_will_give_error_message_as_Sorry_the_IBAN_Number_is_InValid() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Error Message ......");
        Constants.key.pause("2", "");
        String vRecipentText = Constants.DashboardOR.getProperty("IbanErrorMessage");
        Assert.assertEquals("PASS", Constants.key.verifyText(vRecipentText, "Sorry, the IBAN number you entered is invalid. Please check your recipient's account details and try again."));

    }

    @And("^User should see Chat option under help$")
    public void userShouldSeeChatOptionUnderHelp() throws Exception {
        String vObjHelpButton = Constants.HelpOR.getProperty("HelpButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjHelpButton, ""));

        String vChatOption = Constants.HelpOR.getProperty("ChatOption");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vChatOption, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vChatOption, ""));

        String vCloseHelp = Constants.DashboardOR.getProperty("CloseHelp");
        Assert.assertEquals("PASS", Constants.key.click(vCloseHelp, ""));
    }

    @And("^User should see Email us option under help$")
    public void userShouldSeeEmailUsOptionUnderHelp() throws Exception {
        String vObjHelpButton = Constants.HelpOR.getProperty("HelpButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjHelpButton, ""));

        String vEmailUs = Constants.HelpOR.getProperty("EmailUs");
        Assert.assertEquals("PASS", Constants.key.verifyText(vEmailUs, "Email us"));
    }

    @Then("^User shoud see give us a call option along with (CD|HL) customer care number$")
    public void userShoudSeeGiveUsACallOptionAlongWithCDCustomerCareNumber(String app) throws Exception {
        if (app.equals("CD")) {
            String vGiveUsCall = Constants.HelpOR.getProperty("GiveUsCall");
            Assert.assertEquals("PASS", Constants.key.verifyText(vGiveUsCall, "Give us a call"));
            String vCDPhoneNO = Constants.HelpOR.getProperty("CDPhoneNO");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCDPhoneNO, "+44 (0) 20 7847 9494"));
        } else if (app.equals("HL")) {
            String vGiveUsCall = Constants.HelpOR.getProperty("GiveUsCall");
            Assert.assertEquals("PASS", Constants.key.verifyText(vGiveUsCall, "Give us a call"));
            String vHLPhoneNO = Constants.HelpOR.getProperty("HLPhoneNO");
            Assert.assertEquals("PASS", Constants.key.verifyText(vHLPhoneNO, "+44 (0) 207 847 9250"));
        }
    }

    @And("^User clicks on add new recipients from Transfer section$")
    public void userClicksOnAddNewRecipientsFromTransferSection() throws Exception {
        String vAddRecipientButtonObj = Constants.DashboardOR.getProperty("AddRecipientButton");
        if (Constants.driver.findElement(By.xpath(vAddRecipientButtonObj)).isDisplayed()) {
//            Assert.assertEquals("PASS", Constants.key.verifyText(vAddRecipientButtonObj, "Add recipient"));
            Assert.assertEquals("PASS", Constants.key.click(vAddRecipientButtonObj, ""));
        } else {
            String vObjAddNewRecipient = Constants.MakeTransferOR.getProperty("AddNewRecipient");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddNewRecipient, ""));
        }

    }


    @And("^User clicks Continue button for (adding|editing) Beneficiary$")
    public void userClicksContinueButtonForAddingBeneficiary(String page) throws Exception {
        if (page.equals("adding")) {
            LogCapture.info("Clicks on Continue button for adding new beneficiary ......");
            String vObjAddRecipientNxt = Constants.MakeTransferOR.getProperty("AddRecipientNxt");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddRecipientNxt, ""));
        } else if (page.equals("editing")) {
            LogCapture.info("Clicks on Continue button for Editing new beneficiary ......");
            String vObjEditRecipientNxt = Constants.MakeTransferOR.getProperty("EditRecipientNxt");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjEditRecipientNxt, ""));
        }
    }

    @And("^User Clicks deleteX Button on (FCG|CD|TORFX|TMO|Ramsdens|TORAU|TORSINGAPORE|HL) Rate Alert Page if Rate alert exists$")
    public void userClicksDeleteXButtonOnRateAlertPageIfRateAlertExists(String application) throws Exception {
        String vDeleteRateAlert = Constants.NewRateAlertOR.getProperty("DeleteRateAlert");
        String vElementExist = Constants.key.exist(vDeleteRateAlert, "");
        if (vElementExist.equals("PASS")) {
            Assert.assertEquals("PASS", Constants.key.click(vDeleteRateAlert, ""));
            Constants.key.pause("2", "");
            String vDeletePopUpTitle = Constants.NewRateAlertOR.getProperty("DeletePopUpTitle");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeletePopUpTitle, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vDeletePopUpTitle, "Do you want to delete this rate alert?"));
            String vDeleteConfirm = Constants.NewRateAlertOR.getProperty("DeleteConfirm");
            Assert.assertEquals("PASS", Constants.key.click(vDeleteConfirm, ""));
            if (application.equalsIgnoreCase("CD")) {
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("CD_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            } else if (application.equalsIgnoreCase("FCG")) {
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, you have successfully deleted this Rate Alert."));
            } else if (application.equalsIgnoreCase("TORFX")) {
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            } else if (application.equalsIgnoreCase("TMO")) {
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            } else if (application.equalsIgnoreCase("Ramsdens")) {
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("Ramsdens_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            } else if (application.equalsIgnoreCase("TORAU")) {
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            } else if (application.equalsIgnoreCase("TORSINGAPORE")) {
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("TORFX_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            } else if (application.equalsIgnoreCase("HL")) {
                String vDeleteSuccessMessage = Constants.NewRateAlertOR.getProperty("CD_DeleteSuccessMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeleteSuccessMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vDeleteSuccessMessage, "Thanks, You have successfully deleted this Rate Alert."));
            }

            String vBrandLogo = Constants.DashboardOR.getProperty("BrandLogo");
            Assert.assertEquals("PASS", Constants.key.click(vBrandLogo, ""));
        } else {
            String vBrandLogo = Constants.DashboardOR.getProperty("BrandLogo");
            Assert.assertEquals("PASS", Constants.key.click(vBrandLogo, ""));

        }

    }

    @Then("^User Clicks on Change Password link under Account Details tab$")
    public void userClicksOnChangePassworkLinkUnderAccountDeatailsTab() throws Exception {
        LogCapture.info("Clicks on Change password link ......");
        String vObjChangeLink = Constants.ProfileManagementOR.getProperty("ChangeLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjChangeLink, ""));
    }

    @And("^User enters Existing \"([^\"]*)\" New \"([^\"]*)\" password and clicks Save$")
    public void userEntersExistingNewPasswordAndClicksSave(String Epassword, String Npassword) throws
            Throwable {
        LogCapture.info("Enters existing password ......");
        //String vPassword = Constants.CONFIG.getProperty(password);
        String vObjExistingPWD = Constants.ProfileManagementOR.getProperty("ExistingPWD");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjExistingPWD, "selectall"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjExistingPWD, Epassword));

        LogCapture.info("Enters new password ......");
        String vObjNewPWD = Constants.ProfileManagementOR.getProperty("NewPWD");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNewPWD, "selectall"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNewPWD, Npassword));

        LogCapture.info("Confirms new password ......");
        String vObjConfirmPWD = Constants.ProfileManagementOR.getProperty("ConfirmPWD");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjConfirmPWD, "selectall"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjConfirmPWD, Npassword));

        LogCapture.info("Clicks on Save new password button ......");
        String vObjSavePWD = Constants.ProfileManagementOR.getProperty("SavePWD");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSavePWD, ""));

    }

    @And("^User should get success message for changing the password$")
    public void userShouldGetSuccessMessageForChangingThePassword() throws Exception {
        String vObjPWDsuccessMSG = Constants.ProfileManagementOR.getProperty("PWDsuccessMSG");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPWDsuccessMSG, ""));
//        Assert.assertEquals("PASS", Constants.driver.findElement(By.xpath(vObjPWDsuccessMSG)).isDisplayed());
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjPWDsuccessMSG, "Your changes have been saved."));

    }

    @And("^User then Reset password to original by entering Existing \"([^\"]*)\" New \"([^\"]*)\" password and clicks Save$")
    public void userThenResetPasswordToOriginalByEnteringExistingNewPasswordAndClicksSave(String
                                                                                                  Epassword, String
                                                                                                  Npassword) throws Throwable {
        LogCapture.info("Enters existing password ......");
        //String vPassword = Constants.CONFIG.getProperty(password);
        String vObjExistingPWD = Constants.ProfileManagementOR.getProperty("ExistingPWD");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjExistingPWD, "selectall"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjExistingPWD, Npassword));

        LogCapture.info("Enters new password ......");
        String vObjNewPWD = Constants.ProfileManagementOR.getProperty("NewPWD");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNewPWD, "selectall"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNewPWD, Epassword));

        LogCapture.info("Confirms new password ......");
        String vObjConfirmPWD = Constants.ProfileManagementOR.getProperty("ConfirmPWD");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjConfirmPWD, "selectall"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjConfirmPWD, Epassword));

        LogCapture.info("Clicks on Save new password button ......");
        String vObjSavePWD = Constants.ProfileManagementOR.getProperty("SavePWD");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSavePWD, ""));
    }

    @And("^Enters the OTP \"([^\"]*)\" and Click on Confirm Pin to (SignUp|Add Recipient|Change Pin)$")
    public void entersTheOTPAndClickOnConfirmPin(String otp, String page) throws Throwable {
        if (page.equals("SignUp")) {
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("Entering pin for signup......................");
            String vEnterPin = Constants.SignUp.getProperty("EnterPinTextBox");
            Assert.assertEquals("PASS", Constants.key.Enter_OTP(vEnterPin, otp));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("Clicked on confirm button for signup................");
            String vConfirmOTP = Constants.SignUp.getProperty("ConfirmOTP");
            Assert.assertEquals("PASS", Constants.key.click(vConfirmOTP, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            LogCapture.info("Pin Verification....");
        } else if (page.equals("Add Recipient")) {
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("Entering pin for adding recipient......................");
            String vEnterPin = Constants.SignUp.getProperty("AddRecipientPIN");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEnterPin, ""));
            Assert.assertEquals("PASS", Constants.key.Enter_OTP(vEnterPin, otp));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("Clicked on confirm button for adding recipient......");
            String vConfirmOTP = Constants.SignUp.getProperty("ConfirmOTP");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vConfirmOTP, ""));
            Assert.assertEquals("PASS", Constants.key.click(vConfirmOTP, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            LogCapture.info("Pin Verification....");
        } else if (page.equals("Change Pin")) {
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("Entering pin for changing password...................");
            String vEnterPin = Constants.SignUp.getProperty("AddRecipientPIN");
            Assert.assertEquals("PASS", Constants.key.Enter_OTP(vEnterPin, otp));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("Clicked on confirm button for changing password......");
            String vConfirmOTP = Constants.SignUp.getProperty("ConfirmOTP");
            Assert.assertEquals("PASS", Constants.key.click(vConfirmOTP, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            LogCapture.info("Pin Verification....");
        }
    }

    @Then("^User should get success message for (adding|editing) Recipient$")
    public void userShouldGetSuccessMessageForAddingRecipient(String page) throws Exception {
        if (page.equals("adding")) {
            LogCapture.info("Recipient added successfully....");
            String vObjAddReciientSuccessMsg = Constants.DashboardOR.getProperty("AddReciientSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddReciientSuccessMsg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjAddReciientSuccessMsg, "Recipient added successfully"));
        } else if (page.equals("editing")) {
            LogCapture.info("Recipient changes saved successfully....");
            String vObjEditRecipientSuccessMSG = Constants.DashboardOR.getProperty("EditRecipientSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEditRecipientSuccessMSG, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjEditRecipientSuccessMSG, "Thanks, your changes have been saved. The recipient's new details will not affect any transfers you have already started."));
        }
        Constants.driver.navigate().refresh();
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
    }

    @And("^User enters invalid OTP \"([^\"]*)\" and clicks on Confirm Pin to Add Recipient$")
    public void userEntersInvalidOTPAndClicksOnConfirmPinToAddRecipient(String invalidOTP) throws Throwable {
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        LogCapture.info("Entering invalid pin for adding recipient......................");
        String vEnterPin = Constants.SignUp.getProperty("AddRecipientPIN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEnterPin, ""));
        Assert.assertEquals("PASS", Constants.key.Enter_OTP(vEnterPin, invalidOTP));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        LogCapture.info("Clicked on confirm button for adding recipient......");
        String vConfirmOTP = Constants.SignUp.getProperty("ConfirmOTP");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vConfirmOTP, ""));
        Assert.assertEquals("PASS", Constants.key.click(vConfirmOTP, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("Pin Verification....");
    }

    @And("^User should get error message for incorrect PIN$")
    public void userShouldGetErrorMessageForIncorrectPIN() throws Exception {
        String vObjErrorForInvalidPIN = Constants.SignUp.getProperty("ErrorForInvalidPIN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjErrorForInvalidPIN, ""));
        Assert.assertEquals("PASS", Constants.key.exist(vObjErrorForInvalidPIN, ""));
    }

    @And("^User should click on Resend OTP via (SMS|Phone call)$")
    public void userShouldClickOnResendOTPViaSMS(String via) throws Exception {
        if (via.equals("SMS")) {
            LogCapture.info("User selected Resend OTP via " + via + "");
            String vObjResendPINViaSms = Constants.SignUp.getProperty("ResendPINViaSms");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjResendPINViaSms, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjResendPINViaSms, ""));
        } else if (via.equals("Phone call")) {
            LogCapture.info("User selected Resend OTP via " + via + "");
            String vObjResendPINViaPhone = Constants.SignUp.getProperty("ResendPINViaPhone");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjResendPINViaPhone, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjResendPINViaPhone, ""));
        }
    }

    @And("^User Enters Valid account number \"([^\"]*)\" sort code \"([^\"]*)\" and Click on RetriveBankDetails$")
    public void userEntersValidAccountNumberSortCodeAndClickOnRetriveBankDetails(String
                                                                                         accountnumber, String
                                                                                         sortcode) throws Throwable {
        String vObjAccountNo = Constants.DashboardOR.getProperty("AccountNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAccountNo, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNo, accountnumber));

        String vObjSortNo = Constants.DashboardOR.getProperty("SortNo");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSortNo, sortcode));

        String vContinue = Constants.DashboardOR.getProperty("RetriveBankDetailsButton");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vContinue, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
    }

    @And("^User clicks on edit button of recently added recipient$")
    public void userClicksOnEditButtonOfRecentlyAddedRecipient() throws Exception {
        String vObjEditNewRecipient = Constants.loginPageOR.getProperty("EditNewRecipient");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjEditNewRecipient, ""));
    }

    @And("^User clicks on continue button to edit account number \"([^\"]*)\" sort code \"([^\"]*)\" and Click on RetriveBankDetails$")
    public void userClicksOnContinueButtonToEditAccountNumberSortCodeAndClickOnRetriveBankDetails(String
                                                                                                          newaccount, String newsortcode) throws Throwable {
        String vEditContinue = Constants.DashboardOR.getProperty("EditContinue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEditContinue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vEditContinue, ""));

        String vObjAccountNo = Constants.DashboardOR.getProperty("AccountNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAccountNo, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjAccountNo, "selectall"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNo, newaccount));

        String vObjSortNo = Constants.DashboardOR.getProperty("SortNo");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSortNo, "selectall"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSortNo, newsortcode));

        String vObjEditRetriveBankDetails = Constants.DashboardOR.getProperty("EditRetriveBankDetails");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjEditRetriveBankDetails, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));

    }

    @Then("^User clicks on recipient type as company and enter company name \"([^\"]*)\" and clicks continue$")
    public void userClicksOnRecipientTypeAsCompanyAndEnterCompanyNameAndClicksContinue(String companyname) throws
            Throwable {
        String vObjCompanyTypebutton = Constants.DashboardOR.getProperty("CompanyTypebutton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCompanyTypebutton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCompanyTypebutton, ""));

        String vObjCompanyName = Constants.DashboardOR.getProperty("CompanyName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCompanyName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, companyname));

        String vEditContinue = Constants.DashboardOR.getProperty("EditContinue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEditContinue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vEditContinue, ""));
    }


    @And("^User enters country \"([^\"]*)\" with address details manually filled as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userEntersCountryWithAddressDetailsManuallyFilledAs(String country, String
            AddressLine1, String
                                                                            City, String PostalCode, String state) throws Throwable {
        if (country.equalsIgnoreCase("United States of America")) {
            LogCapture.info("Select Country as " + country);
            String Country = Constants.SignUp.getProperty("Country");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(Country, ""));
            String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, country));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));

            LogCapture.info("Click on Enter Address Manually Link.. ");
            String vEnterAddressManLink = Constants.SignUp.getProperty("EnterAddressManLink");
            Assert.assertEquals("PASS", Constants.key.click(vEnterAddressManLink, ""));
            Constants.key.pause("2", "");

            LogCapture.info("Enter Street " + AddressLine1);
            String vAddressLine1TextBox = Constants.SignUp.getProperty("AddressLine1TextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vAddressLine1TextBox, AddressLine1));

            LogCapture.info("Enter City " + City);

            String vCityTextBox = Constants.SignUp.getProperty("CityTextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vCityTextBox, City));

            LogCapture.info("Select state as " + state);
            String vStateSearchTextBox = Constants.SignUp.getProperty("StateSearchTextBox");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(Country, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vStateSearchTextBox, state));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));

            LogCapture.info("Select Postal Code as " + PostalCode);
            String vPostalCodeTextBox = Constants.SignUp.getProperty("PostalCodeTextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCodeTextBox, PostalCode));


        } else if (country.equalsIgnoreCase("United Kingdom")) {
            LogCapture.info("Select Country as " + country);
            String Country = Constants.SignUp.getProperty("Country");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(Country, ""));
            String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, country));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));

            LogCapture.info("Click on Enter Address Manually Link.. ");
            String vEnterAddressManLink = Constants.SignUp.getProperty("EnterAddressManLink");
            Assert.assertEquals("PASS", Constants.key.click(vEnterAddressManLink, ""));
            LogCapture.info("Select Address line 1.............");
            String vAddressLine1TextBox = Constants.SignUp.getProperty("AddressLine1TextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vAddressLine1TextBox, AddressLine1));

            LogCapture.info("Select City............");
            String vCityTextBox = Constants.SignUp.getProperty("CityTextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vCityTextBox, City));

            LogCapture.info("Select Postal Code............");
            String vPostalCodeTextBox = Constants.SignUp.getProperty("PostalCodeTextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCodeTextBox, PostalCode));
        } else if (country.equalsIgnoreCase("Spain")) {
            LogCapture.info("Select Country as " + country);
            String Country = Constants.SignUp.getProperty("Country");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(Country, ""));
            String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, country));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));

            LogCapture.info("Click on Enter Address Manually Link.. ");
            String vEnterAddressManLink = Constants.SignUp.getProperty("EnterAddressManLink");
            Assert.assertEquals("PASS", Constants.key.click(vEnterAddressManLink, ""));
            LogCapture.info("Select Address line 1.............");
            String vAddressLine1TextBox = Constants.SignUp.getProperty("AddressLine1TextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vAddressLine1TextBox, AddressLine1));

            LogCapture.info("Select City............");
            String vCityTextBox = Constants.SignUp.getProperty("CityTextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vCityTextBox, City));

            LogCapture.info("Select Postal Code............");
            String vPostalCodeTextBox = Constants.SignUp.getProperty("PostalCodeTextBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCodeTextBox, PostalCode));
        }
    }


//LogCapture.info("Enter Country.....................");


    @And("^User enters country \"([^\"]*)\" with address details manually filled as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userEntersCountryWithAddressDetailsManuallyFilledAs(String country, String
            AddressLine1, String
                                                                            City, String PostalCode) throws Throwable {
        LogCapture.info("Select Country.............");
        String Country = Constants.SignUp.getProperty("Country");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Country, ""));
        LogCapture.info("Enter Country.....................");
        String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, country));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));
        LogCapture.info("Click on Enter Address Manually Link.. ");
        String vEnterAddressManLink = Constants.SignUp.getProperty("EnterAddressManLink");
        Assert.assertEquals("PASS", Constants.key.click(vEnterAddressManLink, ""));

        LogCapture.info("Select Address line 1.............");
        String vAddressLine1TextBox = Constants.SignUp.getProperty("AddressLine1TextBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vAddressLine1TextBox, AddressLine1));

        LogCapture.info("Select City............");
        String vCityTextBox = Constants.SignUp.getProperty("CityTextBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vCityTextBox, City));

        LogCapture.info("Select Postal Code............");
        String vPostalCodeTextBox = Constants.SignUp.getProperty("PostalCodeTextBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCodeTextBox, PostalCode));


    }

    @And("^User selects radio button as (NO|YES) for Joint Account Registration$")
    public void userSelectsRadioButtonAsNOForJointAccountRegistration(String condition) throws Exception {
        if (condition.equalsIgnoreCase("NO")) {
            LogCapture.info("Select Radio Button as " + condition);
            String vNoJointAccountRadioBox = Constants.SignUp.getProperty("NoJointAccountRadioBox");
            Assert.assertEquals("PASS", Constants.key.click(vNoJointAccountRadioBox, ""));
        } else if (condition.equalsIgnoreCase("Yes")) {
            LogCapture.info("Select Radio Button as " + condition);
            String vYesJointAccountRadioBox = Constants.SignUp.getProperty("YesJointAccountRadioBox");
            Assert.assertEquals("PASS", Constants.key.click(vYesJointAccountRadioBox, ""));
        }


    }

    @And("^User clicks on Next button on signup$")
    public void userClicksOnNextButtonOnSignup() throws Exception {
        LogCapture.info("User clicks on Next button on signup");
        String vNextContButton = Constants.SignUp.getProperty("NextContButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vNextContButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vNextContButton, ""));

    }

    @And("^User enters (SSN|DrivingLicense) number$")
    public void userEntersSSNNumber(String id) throws Exception {
        if (id.equalsIgnoreCase("SSN"))
            LogCapture.info("User enters " + id + " number");
        String vSSNNumberTextBox = Constants.SignUp.getProperty("SSNNumberTextBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSSNNumberTextBox, "123456789"));
    }

    @When("^User clicks on Next button on ID page$")
    public void userClicksOnNextButtonOnIDPage() throws Exception {
        String vSSNNextButton = Constants.SignUp.getProperty("SSNNextButton");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vSSNNextButton, ""));

    }

    @And("^User Enters Country \"([^\"]*)\" and address \"([^\"]*)\"$")
    public void userEntersCountryAndAddress(String country, String add) throws Throwable {
        LogCapture.info("Select Country.............");
        String countryClick = Constants.SignUp.getProperty("Country");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(countryClick, ""));
        LogCapture.info("Enter Country.....................");
        String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, country));
        //Assert.assertEquals("PASS", Constants.key.click(CountrySearchValue,""));

        ////Assert.assertEquals("PASS", Constants.key.sendkeyboardStroke("","enter"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));
        Constants.key.pause("5", "");
        LogCapture.info("Enter Address.....................");
        String AddressSearchValue = Constants.SignUp.getProperty("Address_Filed");
        //Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        //Assert.assertEquals("PASS", Constants.key.click(AddressSearchValue, ""));
        //Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(AddressSearchValue, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.clearText(AddressSearchValue));

        Assert.assertEquals("PASS", Constants.key.writeInInputObO(AddressSearchValue, add));
        Constants.key.pause("5", "");
        //String vdropdownAddValues = Constants.SignUp.getProperty("dropdownAddValues");
        //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vdropdownAddValues,""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(AddressSearchValue, "downArrow"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(AddressSearchValue, "enter"));
        LogCapture.info("Address Loaded successfully");
        Constants.key.pause("2", "");


    }

    @And("^User enters address details manually as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userEntersAddressDetailsManuallyAs(String country, String StreetNumber, String
            StreetName, String
                                                           StreetType, String Suburb, String state, String Postcode) throws Throwable {

        LogCapture.info("User Entering Country..");
        String countryClick = Constants.SignUp.getProperty("Country");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(countryClick, ""));
        String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, country));

        //Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));
        Constants.key.pause("2", "");

        String vclickOutside = Constants.SignUp.getProperty("clickOutside");
        Assert.assertEquals("PASS", Constants.key.click(vclickOutside, ""));

        LogCapture.info("Click on Enter Address Manually Link.. ");
        String vEnterAddressManLink = Constants.SignUp.getProperty("EnterAddressManLink");
        Assert.assertEquals("PASS", Constants.key.click(vEnterAddressManLink, ""));


        LogCapture.info("User Entering Street Number..");
        String vStreetNumber = Constants.SignUp.getProperty("StreetNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vStreetNumber, StreetNumber));

        LogCapture.info("User Entering Street Name..");
        String vStreetTextBox = Constants.SignUp.getProperty("StreetTextBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vStreetTextBox, StreetName));

        LogCapture.info("User Entering Street Type..");
        String vStreetTypeDD = Constants.SignUp.getProperty("StreetTypeDD");
        Assert.assertEquals("PASS", Constants.key.click(vStreetTypeDD, ""));
        Constants.key.pause("2", "");
        String vStreetTypeSearchField = Constants.SignUp.getProperty("StreetTypeSearchField");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vStreetTypeSearchField, StreetType));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vStreetTypeSearchField, "enter"));

        LogCapture.info("User Entering Suburb..");
        String vSuburbTextBox = Constants.SignUp.getProperty("SuburbTextBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSuburbTextBox, Suburb));

        LogCapture.info("User Entering state..");
        String vStateDD = Constants.SignUp.getProperty("StateDD");
        Assert.assertEquals("PASS", Constants.key.click(vStateDD, ""));
        Constants.key.pause("2", "");
        String vStateSearchBox = Constants.SignUp.getProperty("StateSearchBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vStateSearchBox, state));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vStateSearchBox, "enter"));

        LogCapture.info("User Entering Postal Code..");
        String vPostCodeTextBox = Constants.SignUp.getProperty("PostCodeTextBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPostCodeTextBox, Postcode));


    }

    @And("^User enters NIF \"([^\"]*)\" number$")
    public void userEntersNIFNumber(String nifNumber) throws Throwable {
        LogCapture.info("User enters " + nifNumber + " number");
        String vNIFTextBox = Constants.SignUp.getProperty("NIFTextBox");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vNIFTextBox, ""));
        Assert.assertEquals("PASS", Constants.key.click(vNIFTextBox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vNIFTextBox, nifNumber));

    }

    @When("^User Clicks on Next button on NIF Page$")
    public void userClicksOnNextButtonOnNIFPage() throws Exception {
        String vNIFNextButton = Constants.SignUp.getProperty("NIFNextButton");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vNIFNextButton, ""));
    }


    @Then("^User Should observe appropriate error message \"([^\"]*)\"$")
    public void userShouldObserveAppropriateErrorMessage(String expectedMsg) throws Throwable {
        //String vExpected = "Either your email or your password is incorrect. Please re-enter your correct credentials. If you are not registered with us already, please click here to register with us.";
        String vErrorObj = Constants.SignUp.getProperty("InvalidPinErrorMsg");
        LogCapture.info("Validating error message...");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vErrorObj, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vErrorObj, expectedMsg));

    }

    @And("^User clicks on Details option to navigate to Your details screen$")
    public void userClicksOnDetailsOptionToNavigateToYourDetailsScreen() throws Exception {
        String vDetailsTab = Constants.SignUp.getProperty("DetailsTab");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vDetailsTab, ""));
        Constants.key.pause("6", "");

    }

    @And("^User Clicks on (Phone call|SMS text message) as Account authentication preference and clicks Save$")
    public void userClicksOnPhoneCallAsAccountAuthenticationPreference(String authentication) throws
            Exception {
        if (authentication.equals("Phone call")) {
            LogCapture.info("User selects authentication preference as  " + authentication + "");
            String vObjPhoneCall = Constants.ProfileManagementOR.getProperty("PhoneCall");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjPhoneCall, ""));
        } else if (authentication.equals("SMS text message")) {
            LogCapture.info("User selects authentication preference as  " + authentication + "");
            String vObjSMSTextMessage = Constants.ProfileManagementOR.getProperty("SMSTextMessage");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjSMSTextMessage, ""));
        }
        LogCapture.info("User clicking Save button...");
        String vSaveButton = Constants.ProfileManagementOR.getProperty("SaveButton");
        Assert.assertEquals("PASS", Constants.key.click(vSaveButton, ""));
    }

    @Then("^User observe the Account authentication response (change|remains) from (Phone to SMS|SMS to Phone|Phone to Phone|SMS to SMS)$")
    public void userObserveTheAccountAuthenticationResponseChangeFromPhoneToSMS(String response, String
            from) throws
            Exception {
        if (from.equals("SMS to Phone")) {
            LogCapture.info("User verifies authentication preference changes from  " + from + "");
            String vObjPhoneRadio = Constants.ProfileManagementOR.getProperty("PhoneRadio");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPhoneRadio, "selected"));
        } else if (from.equals("Phone to SMS")) {
            LogCapture.info("User verifies authentication preference changes from  " + from + "");
            String vObjSMSRadio = Constants.ProfileManagementOR.getProperty("SMSRadio");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSMSRadio, "selected"));
        } else if (from.equals("Phone to Phone")) {
            LogCapture.info("User verifies authentication preference changes from  " + from + "");
            String vObjPhoneRadio = Constants.ProfileManagementOR.getProperty("PhoneRadio");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPhoneRadio, "selected"));
        } else if (from.equals("SMS to SMS")) {
            LogCapture.info("User verifies authentication preference changes from  " + from + "");
            String vObjSMSRadio = Constants.ProfileManagementOR.getProperty("SMSRadio");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSMSRadio, "selected"));
        }
    }

    @And("^User ticks the Checkbox to use same address details of primary contact and enters \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userTicksTheCheckboxToUseSameAddressDetailsOfPrimaryContactAndEntersAnd(String SSN, String
            drivingLiceneNo, String issuingState) throws Throwable {
        LogCapture.info("User ticks the Checkbox to use same address details of primary contact..");
        String vContactDetailsCheckBox = Constants.ProfileManagementOR.getProperty("ContactDetailsCheckBox");
        Assert.assertEquals("PASS", Constants.key.click(vContactDetailsCheckBox, ""));

        LogCapture.info("User entering " + SSN + " as Social Security Number");
        String vObjSocialSecurityNo = Constants.ProfileManagementOR.getProperty("SocialSecurityNo");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSocialSecurityNo, SSN));

        LogCapture.info("User entering " + drivingLiceneNo + " as Driving Licence Number");
        String vObjDrivingLiceneNo = Constants.ProfileManagementOR.getProperty("DrivingLiceneNo");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjDrivingLiceneNo, drivingLiceneNo));

        LogCapture.info("User selecting " + issuingState + " as Issuing State");
        String vObjIssuingState = Constants.ProfileManagementOR.getProperty("IssuingState");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjIssuingState, ""));
        String vObjIssuingStateSearch = Constants.ProfileManagementOR.getProperty("IssuingStateSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIssuingStateSearch, issuingState));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjIssuingStateSearch, "enter"));
    }


    @And("^User enters invalid OTP \"([^\"]*)\" and clicks on Confirm Pin to Add Recipient for six more times$")
    public void userEntersInvalidOTPAndClicksOnConfirmPinToAddRecipientForFiveMoreTimesAndObserve
            (String invalidOTP) throws
            Throwable {
        LogCapture.info("Trying invalid OTP attempts 5 times.......");
        int attempts = 1;
        while (attempts < 7) {
            //  for(int i=0;i<5;i++) {
            System.out.println("Loop" + attempts);
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("Entering invalid pin for adding recipient......................");
            String vEnterPin = Constants.SignUp.getProperty("AddRecipientPIN");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEnterPin, ""));
            Assert.assertEquals("PASS", Constants.key.Enter_OTP(vEnterPin, invalidOTP));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            LogCapture.info("Clicked on confirm button for adding recipient......");
            String vConfirmOTP = Constants.SignUp.getProperty("ConfirmOTP");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vConfirmOTP, ""));
            Assert.assertEquals("PASS", Constants.key.click(vConfirmOTP, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            LogCapture.info("Pin Verification....");
            attempts++;
        }
        LogCapture.info("Validating error message...");
    }


    @Then("^User should be locked as user has entered multiple times invalid pin$")
    public void userShouldBeLockedAsUserHasEnteredMultipleTimesInvalidPin() throws Exception {
        String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on. +441442892060"));
    }

    // NGOPAdmin
    @When("^User enter NGOPAdamin UserName \"([^\"]*)\" password \"([^\"]*)\" and click submit button$")
    public void user_enter_NGOPAdamin_UserName_password_and_click_submit_button(String userName, String
            password)
            throws Exception {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.loginPageOR.getProperty("NGOPAdmin_Username");
        String vObjPass = Constants.loginPageOR.getProperty("NGOPAdmin_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjSubmitButton = Constants.loginPageOR.getProperty("SubmitButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjSubmitButton, ""));
    }

    @When("^User clicks on Metrics And Analytics tab$")
    public void user_clicks_on_Metrics_And_Analytics_link_and_User_Selects() throws Exception {
        LogCapture.info("clicks on Metrics And Analytics link.....");
        String vObjSubMenutLink = Constants.loginPageOR.getProperty("MetricsAndAnalytics_submenu");
        Assert.assertEquals("PASS", Constants.key.click(vObjSubMenutLink, ""));
        Constants.key.pause("2", "");
    }



 /*   @Then("^User should be locked as user has entered multiple times invalid pin$")
    public void userShouldBeLockedAsUserHasEnteredMultipleTimesInvalidPin() throws Exception {
    String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
    Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on."));
    Constants.key.pause("2", "");
    } */

    @Then("^(FCG|CD|TORFX|TMO|Ramsdens|TORAU|HL|CDLCA) User should be locked as user has entered multiple times invalid pin$")
    public void userShouldBeLockedAsUserHasEnteredMultipleTimesInvalidPin(String application) throws
            Exception {
        if (application.equals("FCG")) {
            String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on. +441442892060"));
            Constants.key.pause("2", "");
        } else if (application.equals("CD")) {
            String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on. +442078479494"));
            Constants.key.pause("2", "");
        } else if (application.equals("TORFX")) {
            String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on. +441736335250"));
            Constants.key.pause("2", "");
        } else if (application.equals("TMO")) {
            String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on. +61 7 55 60 44 40"));
            Constants.key.pause("2", "");
        } else if (application.equals("Ramsdens")) {
            String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on. +441736335291"));
            Constants.key.pause("2", "");
        } else if (application.equals("TORAU")) {
            String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on. +61755604444"));
            Constants.key.pause("2", "");
        } else if (application.equals("HL")) {
            String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "As your attempts to log in have been unsuccessful we've locked your account for security reasons - please call us on. +442078479250"));
            Constants.key.pause("2", "");
        } else if (application.equals("CDLCA")) {
            String vObjMultipleInvalidOTPAttemptError = Constants.ProfileManagementOR.getProperty("MultipleInvalidOTPAttemptError");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMultipleInvalidOTPAttemptError, "Your account has been locked due to multiple unsuccessful log in attempts"));
            Constants.key.pause("2", "");
        }
    }


    @When("^User Selects the organisation \"([^\"]*)\" and Click on Go button$")
    public void user_Selects_the_organisation_and_Click_on_Go_button(String orgName) throws Exception {
        LogCapture.info("User is selecting organisation.....");
        String vObjOrganisation = Constants.loginPageOR.getProperty("ChooseOrganisation");
        Assert.assertEquals("PASS", Constants.key.click(vObjOrganisation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.selectList(vObjOrganisation, orgName));
        //Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjOrganisation, "enter"));
        Constants.key.pause("2", "");

        String vObjGoButton = Constants.loginPageOR.getProperty("GoButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjGoButton, ""));
        Constants.key.pause("2", "");
    }

    @When("^User clicks on Customers \\(details & communication\\) link$")
    public void user_clicks_on_Customers_details_communication_link() throws Exception {
        String vObjCustomersDetailsCommunicationLink = Constants.loginPageOR.getProperty("CustomersLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomersDetailsCommunicationLink, ""));
        Constants.key.pause("2", "");
    }

    @When("^User enter EmailID \"([^\"]*)\" and Click on search button$")
    public void user_enter_EmailID_and_Click_on_search_button(String LockedUserEmail) throws Exception {
        String vEmailIDBox = Constants.loginPageOR.getProperty("EmailIDBox");
        String vObjEmailID = Constants.CONFIG.getProperty(LockedUserEmail);
        LogCapture.info("Email ID" + vObjEmailID + " is searched ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vEmailIDBox, vObjEmailID));
        Constants.key.pause("2", "");

        String vObjSearchButton = Constants.loginPageOR.getProperty("SerachButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchButton, ""));
        Constants.key.pause("2", "");
    }

    @When("^User click on unlock link$")
    public void user_click_on_unlock_link() throws Exception {
        String vObjUnlockLink = Constants.loginPageOR.getProperty("UnlockLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjUnlockLink, ""));
        Constants.key.pause("2", "");
    }

    @Then("^System should display relevant success messsage to the unlocked user$")
    public void system_should_display_relevant_success_messsage_to_the_unlocked_user() throws Exception {

        String vobjSuccessMessage = Constants.loginPageOR.getProperty("SuccessMessage");
        String vTestDataValidationMsg = Constants.CONFIG.getProperty("NGOPAdminUnlockMessage");
        LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
        String actualSuccessMessage = Constants.driver.findElement(By.xpath(vobjSuccessMessage)).getText();
        LogCapture.info("value of actual message is :" + actualSuccessMessage);
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSuccessMessage, vTestDataValidationMsg));
    }

    @When("^User is navigated to dashboard as invalid cvv entered$")
    public void user_is_navigated_to_dashboard_as_invalid_cvv_entered() throws Exception {
        String vObjdashboardLink = Constants.PaymentTrackingOR.getProperty("DashboardLink");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjdashboardLink, ""));
    }

    @Then("^User landed on PT Dashboard successfully$")
    public void user_landed_on_PT_Dashboard_successfully() throws Exception {
        Constants.key.pause("2", "");
        String vObjBacktoDashboardlink = Constants.PaymentTrackingOR.getProperty("BackToDashboard");
        Assert.assertEquals("PASS", Constants.key.click(vObjBacktoDashboardlink, ""));
    }

    @Then("^User should be able to view generic message on PT dashboard as no payment has been initiated$")
    public void user_should_be_able_to_view_generic_message_on_PT_dashboard_as_no_payment_has_been_initiated
            () throws Exception {
        String vObjPTheader = Constants.PaymentTrackingOR.getProperty("PTheader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjPTheader.trim(), "Payment tracking"));

        String vObjMsg1 = Constants.PaymentTrackingOR.getProperty("PTmsg");
        String expectedMsg1 = Constants.CONFIG.getProperty("PTMessage");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjMsg1.trim(), expectedMsg1));
    }

    @When("^User should successfully be able make a transfer with proper Instruction reference$")
    public void user_should_successfully_be_able_make_a_transfer_with_proper_Instruction_reference() throws
            Exception {
        LogCapture.info("Transfer success Validation.....");
        String vObjLinkInstReference = Constants.PaymentTrackingOR.getProperty("InstRefConfirmPage");
        Constants.key.pause("4", "");
        Constants.PTData = Constants.driver.findElement(By.xpath(vObjLinkInstReference)).getText();
    }

    @Then("^User should be able to view recent trade on PT dashboard$")
    public void user_should_be_able_to_view_recent_trade_on_PT_dashboard() throws Exception {
        String vObjInstRefDashboard = Constants.PaymentTrackingOR.getProperty("InstRefDashboard");
        String vObjPTRecords = Constants.PaymentTrackingOR.getProperty("PTList");
        Assert.assertEquals("PASS",
                Constants.key.selectPTRecord(vObjPTRecords, vObjInstRefDashboard + Constants.PTData + "')]", ""));
    }

    @When("^User should successfully be able make a transfer and click on Payment details link$")
    public void user_should_successfully_be_able_make_a_transfer_and_click_on_Payment_details_link() throws
            Exception {
        LogCapture.info("Transfer success Validation.....");
        Constants.key.pause("4", "");
        String vObjPaymentDetailButton = Constants.PaymentTrackingOR.getProperty("PaymentDetails");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDetailButton, ""));
        Constants.key.pause("4", "");


        String vObjLinkInstReference = Constants.PaymentTrackingOR.getProperty("InstRefConfirmPage");
        Constants.PTData = Constants.driver.findElement(By.xpath(vObjLinkInstReference)).getText();
        Constants.key.pause("4", "");

        String vObjLinkBackToDashboard = Constants.PaymentTrackingOR.getProperty("BackToDashboardlink");
        Assert.assertEquals("PASS", Constants.key.click(vObjLinkBackToDashboard, ""));
        Constants.key.pause("2", "");


    }


    /*************************************** Calypso steps***************************************************/


    @Given("^User select (English|Spanish|Chinese) language$")
    public void userSelectEnglishlanguage(String language) throws Exception {
        LogCapture.info("language..." + language);
        if (language.equals("English")) {
            LogCapture.info("User selecting English language...");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("English_language");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        } else if (language.equals("Spanish")) {
            LogCapture.info("User selecting Spanish language......");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("Spanish_language");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        } else if (language.equals("Chinese")) {
            LogCapture.info("User selecting Chinese language......");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("Chinese_language");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        }


    }

    @Then("^User clicks on relavant PT record and Click on download confirmation note successfully$")
    public void user_clicks_on_relavant_PT_record_and_Click_on_download_confirmation_note_successfully
            () throws Exception {
        String vObjPTRecords = Constants.PaymentTrackingOR.getProperty("PTList");
        String vObjPdfdownload = Constants.PaymentTrackingOR.getProperty("DownloadPdfLink");
        Assert.assertEquals("PASS", Constants.key.selectPTRecord(vObjPTRecords, vObjPdfdownload, ""));
        LogCapture.info("Payment confirmation PDF downloading.....");
        Constants.key.pause("4", "");
    }

    /*************************************** Calypso steps***************************************************/

    @Given("^User navigate to (CD|TORFX) Calypso portal \"([^\"]*)\"$")
    public void usernavigatetoCalypso_portal(String application, String vUrl) throws Exception {
        if (application.equals("CD")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("TORFX")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else
            LogCapture.info("Organization not found");
    }


    @And("^User enters National Registration Identity Card \"([^\"]*)\" and Nationality \"([^\"]*)\"$")
    public void userEntersNationalRegistrationIdentityCardAndNationality(String nric, String
            nationality) throws
            Throwable {
        LogCapture.info("Entering NRIC number as " + nric);
        String vObjNRIC = Constants.ProfileManagementOR.getProperty("NRIC");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNRIC, nric));

        LogCapture.info("Entering Nationality as " + nationality);
        String vObjNationality = Constants.ProfileManagementOR.getProperty("Nationality");
        Assert.assertEquals("PASS", Constants.key.click(vObjNationality, ""));
        String vObjNationalitySearch = Constants.ProfileManagementOR.getProperty("NationalitySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNationalitySearch, nationality));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNationalitySearch, "enter"));
    }


    @When("^User enter Calypso UserName \"([^\"]*)\" password \"([^\"]*)\" and click login button$")
    public void userenterCalypsoUserNamepasswordandclickloginbutton(String UserName, String password) throws
            Exception {
        String vCalUserName = Constants.CONFIG.getProperty(UserName);
        String vCalPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.CalypsologinPageOR.getProperty("CalypsoUsername");
        Constants.key.pause("2", "");
        String vObjPass = Constants.CalypsologinPageOR.getProperty("CalypsoPassword");
        LogCapture.info("User Name " + vCalUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vCalUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vCalPassword));
        Constants.key.pause("2", "");
        String vObjLoginButton = Constants.CalypsologinPageOR.getProperty("CalypsoLoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @Then("^User landed on Calypso Dashboard page successfully$")
    public void user_landed_on_Calypso_Dashboard_page_successfully() throws Throwable {
        LogCapture.info("Calypso Dashboard loading ......");
        Constants.key.pause("2", "");
        String vobjectDashboard = Constants.CalypsologinPageOR.getProperty("CalypsoDashboardORText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Make a transfer"));
    }

    @When("^User enter Calypso UserName \"([^\"]*)\" incorrect password \"([^\"]*)\" and click login button$")
    public void user_enter_Calypso_UserName_incorrect_password_and_click_login_button(String usernName,
                                                                                      String inPassword) throws Exception {
        LogCapture.info("Validating incorrect credentials.......");
        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.CalypsologinPageOR.getProperty("CalypsoUsername");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        String vObjPass = Constants.CalypsologinPageOR.getProperty("CalypsoPassword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));
        String vObjLoginButton = Constants.CalypsologinPageOR.getProperty("CalypsoLoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
        Constants.key.pause("4", "");
    }


    @Then("^error message is displayed on calypso Login page as account has been blocked$")
    public void error_message_is_displayed_on_calypso_Login_page_as_account_has_been_blocked() throws
            Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Validating error message...");

        String vExpected = "We’re sorry, we have locked your account for security reasons. Please contact us to unlock your account.";
        String vErrorObj = Constants.CalypsologinPageOR.getProperty("CalypsoErrorMsgLogin");
        LogCapture.info("Validating error message...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vErrorObj, vExpected));
    }

    @When("^User enter calypso UserName \"([^\"]*)\" incorrect password four times \"([^\"]*)\" and click login button$")
    public void user_enter_calypso_UserName_incorrect_password_four_times_and_click_login_button(String
                                                                                                         usernName,
                                                                                                 String inPassword) throws Exception {
        LogCapture.info("Validating incorrect credentials.......");
        int attempts = 1;
        while (attempts < 5) {
            // for(int i=0;i<5;i++) {
            System.out.println("Loop" + attempts);
            String vUserName = Constants.CONFIG.getProperty(usernName);
            String vObjUser = Constants.CalypsologinPageOR.getProperty("CalypsoUsername");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));

            String vObjPass = Constants.CalypsologinPageOR.getProperty("CalypsoPassword");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));

            String vObjLoginButton = Constants.CalypsologinPageOR.getProperty("CalypsoLoginButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
            LogCapture.info("Loop......");
            Constants.key.pause("5", "");
            attempts++;
        }
        LogCapture.info("Validating error message...");

        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.CalypsologinPageOR.getProperty("CalypsoUsername");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));

        String vObjPass = Constants.CalypsologinPageOR.getProperty("CalypsoPassword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));

        String vObjLoginButton = Constants.CalypsologinPageOR.getProperty("CalypsoLoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
        LogCapture.info("Loop......");
        Constants.key.pause("4", "");
    }

    @Given("^User clicks on Click here button to complete online activation$")
    public void user_clicks_on_Click_here_button_to_complete_online_activation() throws Exception {
        LogCapture.info("Activation Link...................");
        String vObjActButton = Constants.CalypsologinPageOR.getProperty("CalypsoActivationLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjActButton, ""));
        Constants.key.pause("2", "");
    }

    @Then("^User Landed on Calypso Activation Page$")
    public void user_Landed_on_Calypso_Activation_Page() throws Exception {
        String vDetailsPage = Constants.CalypsologinPageOR.getProperty("CalypsoActivationPage");
        Assert.assertEquals("PASS", Constants.key.verifyText(vDetailsPage, "Send activation email"));
    }

    @Then("^Enters the calypso EmailID \"([^\"]*)\" and Click on Send me a Link$")
    public void enters_the_calypso_EmailID_and_Click_on_Send_me_a_Link(String userName) throws Exception {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vObjUser = Constants.CalypsologinPageOR.getProperty("ActivationEmailId");
        LogCapture.info("User Name " + vUserName + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));

        String vObjLoginButton = Constants.CalypsologinPageOR.getProperty("Send_a_Link_button");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
        Constants.key.pause("2", "");
    }

    @Then("^System should display Calypso (CD|TORFX) error message as we need to verify some details$")
    public void system_should_display_Calypso_CD_error_message_as_we_need_to_verify_some_details(String
                                                                                                         application) throws Exception {
        if (application.equalsIgnoreCase("CD")) {
            String vobjErrorMessage = Constants.CalypsologinPageOR.getProperty("ActivationErrorMsg");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("CDActivationErrornInactive");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of actual message is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        }
    }

    @Then("^System should display relevant Calypso (CD|TORFX) error message related to the online active user$")
    public void system_should_display_relevant_Calypso_CD_error_message_related_to_the_online_active_user(
            String application) throws Exception {
        if (application.equalsIgnoreCase("CD")) {
            String vobjErrorMessage = Constants.CalypsologinPageOR.getProperty("CalypsoErrorMsgLogin");
            String vTestDataValidationMsg = Constants.CONFIG.getProperty("CDActivationErrorActive");
            LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
            String s2 = Constants.driver.findElement(By.xpath(vobjErrorMessage)).getText();
            LogCapture.info("value of s2 is :" + s2);
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjErrorMessage, vTestDataValidationMsg));
        }
    }

    @Given("^User clicks on Forgotten your login details link$")
    public void user_clicks_on_Forgotten_your_login_details_link() throws Exception {
        String vObjForgotdetails = Constants.CalypsologinPageOR.getProperty("ForgotdetailsLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjForgotdetails, ""));
    }

    @Given("^User landed on reset password page and enter EmailID \"([^\"]*)\"$")
    public void user_landed_on_reset_password_page_and_enter_EmailID(String usernName) throws Exception {
        LogCapture.info("Reset password Dashboard loading ......");
        Constants.key.pause("2", "");
        String vObjResetPassword = Constants.CalypsologinPageOR.getProperty("ResetPasswordText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjResetPassword, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjResetPassword, "Reset password "));

        //LogCapture.info("Entering invalid email address.......");
        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.CalypsologinPageOR.getProperty("ResetEmailIdBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
    }

    @Then("^System should display relevant error message related to invalid email address$")
    public void system_should_display_relevant_error_message_related_to_invalid_email_address() throws
            Exception {
        LogCapture.info("Validating error messages for invalid email ID........");
        // Constants.key.pause("2", "");
        String vobjectErrorMsg = Constants.CalypsologinPageOR.getProperty("InvalidEmailMsg");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectErrorMsg, "Please enter a valid email address"));

    }

    @Given("^User click on Send a link button of Reset password page$")
    public void user_click_on_Send_a_link_button_of_Reset_password_page() throws Exception {
        String vObjResetSendlink = Constants.CalypsologinPageOR.getProperty("ResetPwdSend_a_Link_button");
        Assert.assertEquals("PASS", Constants.key.click(vObjResetSendlink, ""));
        Constants.key.pause("2", "");

    }

    @Then("^System should display relevant error message related to Inactive user email address$")
    public void system_should_display_relevant_error_message_related_to_Inactive_user_email_address() throws
            Exception {
        LogCapture.info("Validating error messages for inactive user ......");
        // Constants.key.pause("2", "");
        String vobjectErrorMsg = Constants.CalypsologinPageOR.getProperty("ResetPwdInactiveUserErrorMsg");
        String vTestDataValidationMsg = Constants.CONFIG.getProperty("CDInactiveUserResetPwdError");
        LogCapture.info("value of vTestDataValidationMsg is :" + vTestDataValidationMsg);
        String s2 = Constants.driver.findElement(By.xpath(vobjectErrorMsg)).getText();
        LogCapture.info("value of s2 is :" + s2);
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectErrorMsg, vTestDataValidationMsg));
    }


    @When("^User selects \"([^\"]*)\" language from drop down$")
    public void userSelectsFrenchLanguageFromDropDown(String vLang) throws Throwable {
        String vLanguageDropDown = Constants.loginPageOR.getProperty("LanguageDropDown");
        String vDynamicLanguage = "//li[contains(text(),'(" + vLang + ")')]";
        Assert.assertEquals("PASS", Constants.key.LanguageDD(vLanguageDropDown, vDynamicLanguage));
    }

    @Then("^User selects (France|English|Norge|Sverige) language from drop down$")
    public void userSelectsLanguageFromDropDown(String vLang) throws Throwable {
        String vLanguageDropDown = Constants.loginPageOR.getProperty("LanguageDropDown");
        String vDynamicLanguage = "//*[@class='select2-container select2-container--default select2-container--open']//following::*//*[contains(text(),'" + vLang + "')]";
        Assert.assertEquals("PASS", Constants.key.LanguageDD(vLanguageDropDown, vDynamicLanguage));
    }

    @And("^User clicks on Change Language Preference link$")
    public void userClicksOnChangeLanguagePreferenceLink() throws Exception {
        String vChangeLangPrefLink = Constants.loginPageOR.getProperty("ChangeLangPrefLink");
        Assert.assertEquals("PASS", Constants.key.click(vChangeLangPrefLink, ""));
        Constants.key.pause("2", "");
    }

    @And("^User clicks on Confirm button$")
    public void userClicksOnConfirmButton() throws Exception {
        String vConfirmButtonLanguage = Constants.loginPageOR.getProperty("ConfirmButtonLanguage");
        Assert.assertEquals("PASS", Constants.key.click(vConfirmButtonLanguage, ""));
        Constants.key.pause("2", "");
    }

    @And("^User clicks on seemore link$")
    public void userClicksOnSeeMore() throws Exception {
        String vConfirmButtonLanguage = Constants.MakeTransferOR.getProperty("SeeMore");
        Assert.assertEquals("PASS", Constants.key.click(vConfirmButtonLanguage, ""));
        Constants.key.pause("4", "");
    }

    @Then("^error message is displayed on Login page for (French|English) language$")
    public void errorMessageIsDisplayedOnLoginPageForFrenchLanguage(String lang) throws Exception {
        if (lang.equalsIgnoreCase("French")) {
            String vExpected = "Votre e-mail ou votre mot de passe est incorrect. Veuillez saisir de nouveau vos informations d'identification de sécurité. Si vous n'êtes pas déjà inscrit, cliquez ici pour procéder à votre inscription.";
            String vErrorObj = Constants.loginPageOR.getProperty("ErrorMessageLogin");
            LogCapture.info("Validating error message...");
            Assert.assertEquals("PASS", Constants.key.verifyText(vErrorObj, vExpected));
        } else if (lang.equalsIgnoreCase("Ënglish")) {
            String vExpected = "Either your email or your password is incorrect. Please re-enter your correct credentials. If you are not registered with us already, please click here to register with us.";
            String vErrorObj = Constants.loginPageOR.getProperty("ErrorMessageLogin");
            LogCapture.info("Validating error message...");
            Assert.assertEquals("PASS", Constants.key.verifyText(vErrorObj, vExpected));
        }
    }

    @And("^User Clicks on Change language preference and selects (English|French|Norwegian|Swedish) as laguage and clicks confirm$")
    public void userClicksOnChangeLanguagePreferenceAndSelectsEnglishAsLaguageAndClicksConfirm(String language) throws Exception {
        LogCapture.info("Changing language preference");
        String vObjChangeLanguageLink = Constants.loginPageOR.getProperty("ChangeLanguageLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjChangeLanguageLink, ""));
        String vObjLanguageSelectList = Constants.loginPageOR.getProperty("LanguageSelectList");
        Assert.assertEquals("PASS", Constants.key.click(vObjLanguageSelectList, ""));
        if (language.equals("English")) {
            LogCapture.info("language..." + language);
            String vObjEnglishLanguage = Constants.loginPageOR.getProperty("EnglishLanguage");
            Assert.assertEquals("PASS", Constants.key.click(vObjEnglishLanguage, ""));
        } else if (language.equals("French")) {
            LogCapture.info("language..." + language);
            String vObjFrenchLanguage = Constants.loginPageOR.getProperty("FrenchLanguage");
            Assert.assertEquals("PASS", Constants.key.click(vObjFrenchLanguage, ""));
        } else if (language.equals("Norwegian")) {
            LogCapture.info("language..." + language);
            String vObjNorwegianLanguage = Constants.loginPageOR.getProperty("NorwegianLanguage");
            Assert.assertEquals("PASS", Constants.key.click(vObjNorwegianLanguage, ""));
        } else if (language.equals("Swedish")) {
            LogCapture.info("language..." + language);
            String vObjSwedishLanguage = Constants.loginPageOR.getProperty("SwedishLanguage");
            Assert.assertEquals("PASS", Constants.key.click(vObjSwedishLanguage, ""));
        }
        LogCapture.info("Clicking on Confirm Button after selecting preferred Language as " + language);
        String vObjLanguageConfirmButton = Constants.loginPageOR.getProperty("LanguageConfirmButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLanguageConfirmButton, ""));
        Constants.key.pause("5", "");

    }

    @And("^User enter Your occupation \"([^\"]*)\" field$")
    public void userEnterYourOccupationField(String occp) throws Throwable {
        LogCapture.info("Select Occupation as " + occp);
        String vOccupationFieldClick = Constants.OccupationGenericOR.getProperty("OccupationFieldClick");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vOccupationFieldClick, ""));
        String vOccupationSearchInput = Constants.OccupationGenericOR.getProperty("OccupationSearchInput");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOccupationSearchInput, occp));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOccupationSearchInput, "enter"));

    }

    @And("^User enter Your occupation \"([^\"]*)\" field for Joint Account$")
    public void userEnterYourOccupationFieldForJointAccount(String occp) throws Throwable {
        LogCapture.info("Select Occupation as " + occp + "for joint registartion");
        String vOccupationJointUserFieldClick = Constants.OccupationGenericOR.getProperty("OccupationJointUserFieldClick");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vOccupationJointUserFieldClick, ""));
        String vOccupationSearchInput = Constants.OccupationGenericOR.getProperty("OccupationSearchInput");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOccupationSearchInput, occp));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOccupationSearchInput, "enter"));

    }


    @And("^User enters country \"([^\"]*)\" with address details \"([^\"]*)\" for joint Registration$")
    public void userEntersCountryWithAddressDetailsForJointRegistration(String Country, String Address) throws Throwable {
        LogCapture.info("Select Country as " + Country);
        String vObjChangeLink = Constants.SignUp.getProperty("ChangeLink");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjChangeLink, ""));
        String vObjSecondaryCountry = Constants.SignUp.getProperty("SecondaryCountry");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSecondaryCountry, ""));
        String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, Country));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));

        String vObjSecondarySearchField = Constants.SignUp.getProperty("SecondarySearchField");
        Assert.assertEquals("PASS", Constants.key.click(vObjSecondarySearchField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSecondarySearchField, Address));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSecondarySearchField, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSecondarySearchField, "enter"));

        String vNext_Button = Constants.SignUp.getProperty("NextButonJointAccount");
        Assert.assertEquals("PASS", Constants.key.click(vNext_Button, ""));
        LogCapture.info("Registration in Processs....");
    }

    @And("^User enters country \"([^\"]*)\" with address details manually filled as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" for joint Registration$")
    public void userEntersCountryWithAddressDetailsManuallyFilledAsForJointRegistration(String Country, String AddressLine1, String City, String PostalCode) throws Throwable {
        // if(Country.equalsIgnoreCase("United Kingdom")||Country.equalsIgnoreCase("France")||Country.equalsIgnoreCase("India")){
        LogCapture.info("Select Country as " + Country);
        String vObjChangeLink = Constants.SignUp.getProperty("ChangeLink");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjChangeLink, ""));
        String vObjSecondaryCountry = Constants.SignUp.getProperty("SecondaryCountry");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSecondaryCountry, ""));
        String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, Country));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));

        LogCapture.info("Click on Enter Address Manually Link.. ");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vEnterAddressManLink = Constants.SignUp.getProperty("SecondaryEnterAddressManually");
        // ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].click();", vEnterAddressManLink);
        Assert.assertEquals("PASS", Constants.key.click(vEnterAddressManLink, ""));
        LogCapture.info("Select Address line 1.............");
        String vAddressLine1TextBox = Constants.SignUp.getProperty("SecondaryAddressLine1Text");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vAddressLine1TextBox, AddressLine1));

        LogCapture.info("Select City............");
        String vCityTextBox = Constants.SignUp.getProperty("SecondaryCity");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vCityTextBox, City));

        LogCapture.info("Select Postal Code............");
        String vPostalCodeTextBox = Constants.SignUp.getProperty("SecondaryPostcode");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vPostalCodeTextBox, PostalCode));

//            String vObjSecondarySearchField = Constants.SignUp.getProperty("SecondarySearchField");
//            Assert.assertEquals("PASS", Constants.key.click(vObjSecondarySearchField, ""));
//            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSecondarySearchField,Address));
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSecondarySearchField, "downArrow"));
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSecondarySearchField, "enter"));

        String vNext_Button = Constants.SignUp.getProperty("NextButonJointAccount");
        Assert.assertEquals("PASS", Constants.key.click(vNext_Button, ""));
        LogCapture.info("Registration in Processs....");

    }


    @And("^User enters the first name \"([^\"]*)\" last name \"([^\"]*)\" mobile number \"([^\"]*)\" \"([^\"]*)\" dateofbirth Day\"([^\"]*)\" Month\"([^\"]*)\" year\"([^\"]*)\" (emailAddress|registeredEmailAddress|registeredSecondaryEmailAddress) and job title \"([^\"]*)\"$")
    public void userEntersTheFirstNameLastNameMobileNumberDateofbirthDayMonthYearEmailAddressAndJobTitle(String fname, String lname, String countryCode, String mobileNo, String day, String month, String year, String emailtype, String jobtitle) throws Throwable {

        LogCapture.info("User entering first name....");
        String vFN = Constants.ProfileManagementOR.getProperty("FN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFN, ""));
        Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vFN, 4));

/*        Assert.assertEquals("PASS", Constants.key.click(vFN, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vFN, fname));*/
        //Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vFN, 5));
        String vFirstName = Constants.key.getText(vFN, "");
        LogCapture.info("First name is " + vFirstName);

        //Assert.assertEquals("PASS", Constants.key.writeInInput(vFN, fname));
        LogCapture.info("User entering last name....");
        String vLN = Constants.ProfileManagementOR.getProperty("LN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vLN, ""));
        Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vLN, 4));
        /*Assert.assertEquals("PASS", Constants.key.click(vLN, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vLN, lname));*/
        //Assert.assertEquals("PASS", Constants.key.randomWordGenerator(vLN, 5));
        String vLastName = Constants.key.getText(vLN, "");
        LogCapture.info("Last name is " + vLastName);

        LogCapture.info("User entering country code.....");
        String vCountryDD = Constants.ProfileManagementOR.getProperty("CountryDD");
        Assert.assertEquals("PASS", Constants.key.click(vCountryDD, ""));
        String vCountrySearchText = Constants.ProfileManagementOR.getProperty("CountrySearchText");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vCountrySearchText, countryCode));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vCountrySearchText, "enter"));

        LogCapture.info("User entering mobile number.....");
        String vNumber = Constants.ProfileManagementOR.getProperty("Number");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vNumber, mobileNo));

        LogCapture.info("User entering Day .....");
        String vDayDropDown = Constants.ProfileManagementOR.getProperty("DayDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vDayDropDown, ""));
        String vcommonSearchTextBx = Constants.ProfileManagementOR.getProperty("commonSearchTextBx");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, day));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        LogCapture.info("User entering Month .....");
        String vMonthDropDown = Constants.ProfileManagementOR.getProperty("MonthDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vMonthDropDown, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, month));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        LogCapture.info("User entering Year .....");
        String vYearDropDown = Constants.ProfileManagementOR.getProperty("YearDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vYearDropDown, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vcommonSearchTextBx, year));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vcommonSearchTextBx, "enter"));

        if (emailtype.equalsIgnoreCase("emailAddress")) {
            LogCapture.info("User entering email Address....");
            String vEmailAddressTextBox = Constants.ProfileManagementOR.getProperty("EmailAddressTextBox");
            Assert.assertEquals("PASS", Constants.key.uniqueEmailID(vEmailAddressTextBox, ""));
        } else if (emailtype.equalsIgnoreCase("registeredEmailAddress")) {
            LogCapture.info("User entering email Address...." + vSignUp_EmailID);
            String vEmailAddressTextBox = Constants.ProfileManagementOR.getProperty("EmailAddressTextBox");
            LogCapture.info(vSignUp_EmailID);
            Assert.assertEquals("PASS", Constants.key.writeInInput(vEmailAddressTextBox, vSignUp_EmailID));
        } else if (emailtype.equalsIgnoreCase("registeredSecondaryEmailAddress")) {
            LogCapture.info("User entering seconadary email Address...." + vSignUp_SecondaryEmailID);
            String vEmailAddressTextBox = Constants.ProfileManagementOR.getProperty("EmailAddressTextBox");
            LogCapture.info(vSignUp_SecondaryEmailID);
            Assert.assertEquals("PASS", Constants.key.writeInInput(vEmailAddressTextBox, vSignUp_SecondaryEmailID));
        }
        //registeredSecondaryEmailAddress
        LogCapture.info("User selecting Job Title .....");
        String vJobTitle = Constants.ProfileManagementOR.getProperty("JobTitle");
        Assert.assertEquals("PASS", Constants.key.selectList(vJobTitle, jobtitle));
        Constants.key.pause("2", "");
    }


    @Then("^User is NOT able to view Debit Card option under Payment methods for (Make a transfer|Topup Wallet)$")
    public void userIsNOTAbleToViewDebitCardOptionUnderPayemntMethods(String transaction) throws Throwable {
        LogCapture.info("Checking Debit card under Payment method.....");
        String vObjPaymentMethod = Constants.MakeTransferOR.getProperty("PaymentMethod");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentMethod, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
        if (transaction.equals("Make a transfer")) {
            String vObjFromDebitCard = Constants.MakeTransferOR.getProperty("FromDebitCard");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjFromDebitCard, ""));
            LogCapture.info("User NOT able to see Debit card option under " + transaction + "...");
        }
        if (transaction.equals("Topup Wallet")) {
            String vObjFromDebitCard = Constants.MakeTransferOR.getProperty("FromDebitCard");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjFromDebitCard, ""));
            LogCapture.info("User NOT able to see Debit card option under " + transaction + "...");

        }
    }

    @And("^User clicks on \"([^\"]*)\" on (our bank account details|Dashboard) page$")
    public void userClicksOnOnOurBankDetailsPage(String currency, String page) throws Throwable {

        if (page.equalsIgnoreCase("Our bank account details")) {

            LogCapture.info(currency);
            LogCapture.info("Selecting Currency - " + currency);

            String vObjCurrency = Constants.DashboardOR.getProperty("CurrencyTypeDropDown");
            Assert.assertEquals("PASS", Constants.key.click(vObjCurrency, ""));
            Constants.key.pause("2", "");
            String vObjPaySearchCurrency = Constants.DashboardOR.getProperty("CurrencyTypeSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPaySearchCurrency, currency));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPaySearchCurrency, "enter"));
            Constants.key.pause("2", "");
            LogCapture.info("Selected currency - " + currency);
        } else if (page.equalsIgnoreCase("Dashboard")) {

//a[@id='sek_curr']
            // String vObjCurrency="//*[@onclick=\"showOurBankDetails('"+currency+"');\"]";
            String vObjCurrency = "//a[@id=\'" + currency.toLowerCase() + "_curr']";
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjCurrency, ""));
            // Assert.assertEquals("PASS", Constants.key.click(vObjCurrency, ""));
            Constants.key.pause("2", "");
            String vObjBankDetails = "//*[@onclick=\"getOrganizationBankDetailsForWalletList('" + currency + "');\"]";
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjBankDetails, ""));
            Constants.key.pause("2", "");
        }
    }

    @And("^User verify Next button is disable while Registration process$")
    public void userVerifyNextButtonIsDisableWhileRegistrationProcess() throws Throwable {
        String vNextContButton = Constants.SignUp.getProperty("NextContButton");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vNextContButton, "disabled"));
        LogCapture.info("Next button is disabled..");
    }

    @And("^User verify all Required fields on Your details page for Registration$")
    public void userVerifyAllRequiredFieldsOnYourDetailsPageForRegistration() throws Throwable {
        String ErrorMsg = "Required field";
        Constants.key.pause("2", "");
        String Sign_F_Name_ErrorMsg = Constants.SignUp.getProperty("Sign_F_Name_ErrorMsg");
        String Sign_L_Name_ErrorMsg = Constants.SignUp.getProperty("Sign_L_Name_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.exist(Sign_F_Name_ErrorMsg, ""));
        LogCapture.info("First name is Required...");
        Assert.assertEquals("PASS", Constants.key.verifyText(Sign_L_Name_ErrorMsg, ErrorMsg));
        LogCapture.info("Last name is Required...");

        String vObjDOB_Day_ErrorMsg = Constants.SignUp.getProperty("DOB_Day_ErrorMsg");
        String vObjDOB_Month_ErrorMsg = Constants.SignUp.getProperty("DOB_Month_ErrorMsg");
        String vObjDOB_Year_ErrorMsg = Constants.SignUp.getProperty("DOB_Year_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjDOB_Day_ErrorMsg, ErrorMsg));
        LogCapture.info("DOB Date is Required...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjDOB_Month_ErrorMsg, ErrorMsg));
        LogCapture.info("DOB month is Required...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjDOB_Year_ErrorMsg, ErrorMsg));
        LogCapture.info("DOB year is Required...");


        String vObjAddress1_ErrorMsg = Constants.SignUp.getProperty("Address1_ErrorMsg");
        String vObjCity_ErrorMsg = Constants.SignUp.getProperty("City_ErrorMsg");
        String vObjPostcode_ErrorMsg = Constants.SignUp.getProperty("Postcode_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAddress1_ErrorMsg, ErrorMsg));
        LogCapture.info("Address1 field is Required...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCity_ErrorMsg, ErrorMsg));
        LogCapture.info("City field is Required...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjPostcode_ErrorMsg, ErrorMsg));
        LogCapture.info("Postcode is Required...");

        String vObjOccupation_ErrorMsg = Constants.SignUp.getProperty("Occupation_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjOccupation_ErrorMsg, ErrorMsg));
        LogCapture.info("Occupation field is Required...");

    }

    @And("^User enters country \"([^\"]*)\" on Your details page$")
    public void userEntersCountryOnYourDetailsPage(String country) throws Throwable {
        LogCapture.info("Select Country as " + country);
        String Country = Constants.SignUp.getProperty("Country");
        WebElement element = Constants.driver.findElement(By.xpath(Country));
        ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView(true);", element);
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(Country, ""));
        String CountrySearchValue = Constants.SignUp.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(CountrySearchValue, country));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(CountrySearchValue, "enter"));

        String vYourOccupationHeader = Constants.SignUp.getProperty("YourOccupationHeader");
        Assert.assertEquals("PASS", Constants.key.click(vYourOccupationHeader, ""));

        LogCapture.info("Click on Enter Address Manually Link.. ");
        String vEnterAddressManLink = Constants.SignUp.getProperty("EnterAddressManLink");
        Assert.assertEquals("PASS", Constants.key.click(vEnterAddressManLink, ""));
        Constants.key.pause("2", "");
    }

    @And("^User verify NIF is Required fields for Registration$")
    public void userVerifyNIFIsRequiredFieldsForRegistration() throws Throwable {
        String ErrorMsg = "Required field";
        String vObjNIFnumber_ErrorMsg = Constants.SignUp.getProperty("NIFnumber_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjNIFnumber_ErrorMsg, ErrorMsg));
        LogCapture.info("NIF number is Required...");
    }

    @And("^User clicks on Send Pin button$")
    public void userClicksOnSendPinButton() throws Throwable {
        String vSendOTP = Constants.SignUp.getProperty("SendPin");
        Assert.assertEquals("PASS", Constants.key.click(vSendOTP, ""));
        LogCapture.info("User clicked on Send pin button..");
    }

    @And("^User verify Mobile number is Required fields for (Single|Joint) Registration$")
    public void userVerifyMobileNumberIsRequiredFieldsForRegistration(String RegType) throws Throwable {
        String ErrorMsg = "Required field";
        if (RegType.equalsIgnoreCase("Single")) {
            String vObjMobileNumber_ErrorMsg = Constants.SignUp.getProperty("MobileNumber_ErrorMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMobileNumber_ErrorMsg, ErrorMsg));
            LogCapture.info("Mobile number 1 is Required...");
        }
        if (RegType.equalsIgnoreCase("Joint")) {
            String vObjMobileNumber_ErrorMsg = Constants.SignUp.getProperty("MobileNumber_ErrorMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMobileNumber_ErrorMsg, ErrorMsg));
            LogCapture.info("Mobile number 1 is Required...");

            String vObjMobileNumber2_ErrorMsg = Constants.SignUp.getProperty("MobileNumber2_ErrorMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMobileNumber2_ErrorMsg, ErrorMsg));
            LogCapture.info("Mobile number 2 is Required...");
        }

    }

    @And("^User verify all Required fields on Their details page for Registration$")
    public void userVerifyAllRequiredFieldsOnTheirDetailsPageForRegistration() throws Throwable {
        String ErrorMsg = "Required field";
        Constants.key.pause("2", "");
        String Sign_F_Name_ErrorMsg = Constants.SignUp.getProperty("Sign2_F_Name_ErrorMsg");
        String Sign_L_Name_ErrorMsg = Constants.SignUp.getProperty("Sign2_L_Name_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.exist(Sign_F_Name_ErrorMsg, ""));
        LogCapture.info("First name is Required...");
        Assert.assertEquals("PASS", Constants.key.verifyText(Sign_L_Name_ErrorMsg, ErrorMsg));
        LogCapture.info("Last name is Required...");

        String vObjDOB_Day_ErrorMsg = Constants.SignUp.getProperty("DOB2_Day_ErrorMsg");
        String vObjDOB_Month_ErrorMsg = Constants.SignUp.getProperty("DOB2_Month_ErrorMsg");
        String vObjDOB_Year_ErrorMsg = Constants.SignUp.getProperty("DOB2_Year_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjDOB_Day_ErrorMsg, ErrorMsg));
        LogCapture.info("DOB Date is Required...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjDOB_Month_ErrorMsg, ErrorMsg));
        LogCapture.info("DOB month is Required...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjDOB_Year_ErrorMsg, ErrorMsg));
        LogCapture.info("DOB year is Required...");


        String vObjAddress1_ErrorMsg = Constants.SignUp.getProperty("EmailAddress2_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAddress1_ErrorMsg, ErrorMsg));
        LogCapture.info("Email Address is Required...");

        String vObjOccupation_ErrorMsg = Constants.SignUp.getProperty("Occupation2_ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjOccupation_ErrorMsg, ErrorMsg));
        LogCapture.info("Occupation field is Required...");
    }

    @And("^User verify \"([^\"]*)\" details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" for respective \"([^\"]*)\"$")
    public void userVerifyDetailsForRespective(String bank, String AccountName, String BankName, String BranchCode, String AccountNo, String IbanNo, String SwiftCode, String currency) throws Throwable {

        String vObjAccountName = Constants.DashboardOR.getProperty("AccountNameInput");
        String vObjBankName = Constants.DashboardOR.getProperty("BankNameTextArea");
        String vObjBranchCode = Constants.DashboardOR.getProperty("SortCodeInput");
        String vObjAccountNo = Constants.DashboardOR.getProperty("AccountNumberInput");
        String vObjIbanNo = Constants.DashboardOR.getProperty("IBANInput");
        String vObjSwiftCode = Constants.DashboardOR.getProperty("SwiftCodeInput");

        String vObjAccountNameLabel = Constants.DashboardOR.getProperty("AccountNameLabel");
        String vObjBankNameLabel = Constants.DashboardOR.getProperty("BankNameTextLabel");
        String vObjBranchCodeLabel = Constants.DashboardOR.getProperty("SortCodeLabel");
        String vObjAccountNoLabel = Constants.DashboardOR.getProperty("AccountNumberLabel");
        String vObjIbanNoLabel = Constants.DashboardOR.getProperty("IBANLabel");
        String vObjSwiftCodeLabel = Constants.DashboardOR.getProperty("SwiftCodeLabel");

        LogCapture.info("Validating " + currency + " Currency bank details...");
        Constants.key.pause("2", "");

        LogCapture.info("Verifying for " + currency + " bank details AccountName..");
        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjAccountName,""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountName, AccountName));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNameLabel,"Account name"));
        LogCapture.info("Verification for " + currency + "  Currency bank details AccountName has been successfully done");

        LogCapture.info("Verifying for " + currency + "  Currency bank details BankName..");
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjBankName, ""));
        Constants.key.pause("1", "");
        // Assert.assertEquals("PASS",Constants.key.verifyText(vObjBankName,varBankName));
        //  Assert.assertEquals("PASS",Constants.key.verifyText(vObjBankNameLabel,"Bank name"));
        LogCapture.info("Verification for " + currency + "  Currency bank details BankName has been successfully done");

        LogCapture.info("Verifying for " + currency + "  Currency bank details BranchCode");
        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjBranchCode,""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBranchCode, BranchCode));
        // Assert.assertEquals("PASS",Constants.key.verifyText(vObjBranchCodeLabel,"Sort Code"));
        LogCapture.info("Verification for " + currency + "  Currency bank details BranchCode has been successfully done");

        LogCapture.info("Verifying for " + currency + " Currency bank details AccountNo");
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjAccountNo, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountNo, AccountNo));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNoLabel,"Account/IBAN no."));
        LogCapture.info("Verification for " + currency + " Currency bank details AccountNo has been successfully done");

        LogCapture.info("Verifying for " + currency + " Currency bank details IbanNo");
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjIbanNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjIbanNo, IbanNo));
        // Assert.assertEquals("PASS",Constants.key.verifyText(vObjIbanNoLabel,"IBAN"));
        LogCapture.info("Verification for " + currency + " Currency bank details IbanNo has been successfully done");

        LogCapture.info("Verifying for " + currency + " Currency bank details SwiftCode");
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjSwiftCode, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjSwiftCode, SwiftCode));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjSwiftCodeLabel,"SWIFT code"));
        LogCapture.info("Verification for " + currency + " Currency bank details SwiftCode has been successfully done");

        LogCapture.info(currency + " bank details validated");

    }

    @And("^Verify Currencies Bank Details on (Our bank account details|Dashboard) page$")
    public void verifyCurrenciesBankDetailsOnOurBankDetailsPage(String page, DataTable currenciedBankDetails) throws Exception {

        List<Map<String, String>> list = currenciedBankDetails.asMaps(String.class, String.class);
        int col = list.size();
        //int row=list.get(0).size();

        String vObjAccountName = Constants.DashboardOR.getProperty("AccountNameInput");
        String vObjBankName = Constants.DashboardOR.getProperty("BankNameTextArea");
        String vObjBranchCode = Constants.DashboardOR.getProperty("SortCodeInput");
        String vObjAccountNo = Constants.DashboardOR.getProperty("AccountNumberInput");
        String vObjIbanNo = Constants.DashboardOR.getProperty("IBANInput");
        String vObjSwiftCode = Constants.DashboardOR.getProperty("SwiftCodeInput");

        String vObjAccountNameLabel = Constants.DashboardOR.getProperty("AccountNameLabel");
        String vObjBankNameLabel = Constants.DashboardOR.getProperty("BankNameTextLabel");
        String vObjBranchCodeLabel = Constants.DashboardOR.getProperty("SortCodeLabel");
        String vObjAccountNoLabel = Constants.DashboardOR.getProperty("AccountNumberLabel");
        String vObjIbanNoLabel = Constants.DashboardOR.getProperty("IBANLabel");
        String vObjSwiftCodeLabel = Constants.DashboardOR.getProperty("SwiftCodeLabel");


        for (int i = 0; i < list.size(); i++) {
            String varCurrency = (list.get(i).get("currency"));
            String varAccountName = (list.get(i).get("accountName"));
            String varBankName = (list.get(i).get("bankName"));
            String varBranchCode = (list.get(i).get("branchCode"));
            String varAccountNo = (list.get(i).get("accountNo"));
            String varIbanNo = (list.get(i).get("ibanNo"));
            String varSwiftCode = (list.get(i).get("swiftCode"));


            if (page.equalsIgnoreCase("Our bank account details")) {
                LogCapture.info(varCurrency);
                LogCapture.info("Selecting Currency - " + varCurrency);

                String vObjCurrency = Constants.DashboardOR.getProperty("CurrencyTypeDropDown");
                Assert.assertEquals("PASS", Constants.key.click(vObjCurrency, ""));
                Constants.key.pause("2", "");
                String vObjPaySearchCurrency = Constants.DashboardOR.getProperty("CurrencyTypeSearch");
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPaySearchCurrency, varCurrency));
                Constants.key.pause("2", "");
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPaySearchCurrency, "enter"));
                Constants.key.pause("2", "");
                LogCapture.info("Selected currency - " + varCurrency);
            } else if (page.equalsIgnoreCase("Dashboard")) {

            }


            LogCapture.info("Validating " + varCurrency + " Currency bank details...");
            Constants.key.pause("2", "");

            LogCapture.info("Verifying for " + varCurrency + " bank details AccountName..");
            //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjAccountName,""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountName, varAccountName));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountNameLabel, "Account name"));
            LogCapture.info("Verification for " + varCurrency + "  Currency bank details AccountName has been successfully done");

            LogCapture.info("Verifying for " + varCurrency + "  Currency bank details BankName..");
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjBankName, ""));
            Constants.key.pause("1", "");
            // Assert.assertEquals("PASS",Constants.key.verifyText(vObjBankName,varBankName));
            //  Assert.assertEquals("PASS",Constants.key.verifyText(vObjBankNameLabel,"Bank name"));
            LogCapture.info("Verification for " + varCurrency + "  Currency bank details BankName has been successfully done");

            LogCapture.info("Verifying for " + varCurrency + "  Currency bank details BranchCode");
            //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjBranchCode,""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBranchCode, varBranchCode));
            // Assert.assertEquals("PASS",Constants.key.verifyText(vObjBranchCodeLabel,"Sort Code"));
            LogCapture.info("Verification for " + varCurrency + "  Currency bank details BranchCode has been successfully done");

            LogCapture.info("Verifying for " + varCurrency + " Currency bank details AccountNo");
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjAccountNo, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountNo, varAccountNo));
            //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNoLabel,"Account/IBAN no."));
            LogCapture.info("Verification for " + varCurrency + " Currency bank details AccountNo has been successfully done");

            LogCapture.info("Verifying for " + varCurrency + " Currency bank details IbanNo");
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjIbanNo, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjIbanNo, varIbanNo));
            // Assert.assertEquals("PASS",Constants.key.verifyText(vObjIbanNoLabel,"IBAN"));
            LogCapture.info("Verification for " + varCurrency + " Currency bank details IbanNo has been successfully done");

            LogCapture.info("Verifying for " + varCurrency + " Currency bank details SwiftCode");
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjSwiftCode, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjSwiftCode, varSwiftCode));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjSwiftCodeLabel, "SWIFT code"));
            LogCapture.info("Verification for " + varCurrency + " Currency bank details SwiftCode has been successfully done");

            LogCapture.info(varCurrency + " bank details validated");

        }
    }

    @And("^Verify \"([^\"]*)\" details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" for respective \"([^\"]*)\"$")
    public void verifyDetailsForRespective(String bank, String AccountName, String BankName, String BranchCode, String AccountNo, String IbanNo, String SwiftCode, String currency) throws Throwable {


        String vObjAccountName = "//span[@id=\'account_name_" + currency + "']";
        String vObjBankName = "//span[@id=\'bank_name_" + currency + "']";
        //String vObjBranchCode="//div[@id=\'sortCode_"+currency+"']";
        String vObjAccountNo = "//span[@id=\'account_number_" + currency + "']";
        String vObjIbanNo = "//span[@id=\'iban_number_" + currency + "']";
        String vObjSwiftCode = "//span[@id=\'swiftcode_" + currency + "']";

        String vObjAccountNameLabel = "//span[@id=\'account_name_" + currency + "']//preceding::span[1]";
        String vObjBankNameLabel = "//span[@id=\'bank_name_" + currency + "']//preceding::span[1]";
        String vObjBranchCodeLabel = "//span[@id=\'sortCode_" + currency + "']//preceding::span[1]";
        String vObjAccountNoLabel = "//span[@id=\'account_number_" + currency + "']//preceding::span[1]";
        String vObjIbanNoLabel = "//span[@id=\'iban_number_" + currency + "']//preceding::span[1]";
        String vObjSwiftCodeLabel = "//span[@id=\'swiftcode_" + currency + "']//preceding::span[1]";

        LogCapture.info("Validating " + currency + " Currency bank details...");
        Constants.key.pause("2", "");


        LogCapture.info("Verifying for " + currency + "  Currency bank details AccountName..");

        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(accountHeading,""));

        Assert.assertEquals("PASS", Constants.key.click(vObjAccountName, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountName, AccountName));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNameLabel,"Account name"));
        LogCapture.info("Verification for " + currency + "  Currency bank details AccountName has been successfully done");

        LogCapture.info("Verifying for " + currency + "  Currency bank details BankName..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankName, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBankName, BankName));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNameLabel,"Account name"));
        LogCapture.info("Verification for " + currency + "  Currency bank details BankName has been successfully done");

        LogCapture.info("Verifying for " + currency + "  Currency bank details AccountNo..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNo, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountNo, AccountNo));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNameLabel,"Account name"));
        LogCapture.info("Verification for " + currency + "  Currency bank details AccountNo has been successfully done");
//
        LogCapture.info("Verifying for " + currency + "  Currency bank details IbanNo..");
        Assert.assertEquals("PASS", Constants.key.click(vObjIbanNo, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjIbanNo, IbanNo));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNameLabel,"Account name"));
        LogCapture.info("Verification for " + currency + "  Currency bank details IbanNo has been successfully done");

        LogCapture.info("Verifying for " + currency + "  Currency bank details SwiftCode..");
        Assert.assertEquals("PASS", Constants.key.click(vObjSwiftCode, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjSwiftCode, SwiftCode));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNameLabel,"Account name"));
        LogCapture.info("Verification for " + currency + "  Currency bank details SwiftCode has been successfully done");

        LogCapture.info(currency + " bank details validated");

    }

    @And("^User enters NIP \"([^\"]*)\"$")
    public void userEntersNIP(String NIP) throws Throwable {
        LogCapture.info("User entering NIP.....");
        String vObjNIP = Constants.ProfileManagementOR.getProperty("NIP");
        Assert.assertEquals("PASS", Constants.key.click(vObjNIP, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNIP, NIP));

    }


    @And("^User clicks on Add new Card$")
    public void userClicksOnAddNewCard() throws Throwable {
        String vObjAddNewCardLink = Constants.ProfileManagementOR.getProperty("AddNewCardLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCardLink, ""));
        LogCapture.info("Clicked on Add new card...");
        String vObjAddNewCardPage = Constants.ProfileManagementOR.getProperty("AddNewCardPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddNewCardPage, ""));
        LogCapture.info("Add new card popup is displayed...");
    }

    @Then("^User verify available Card types for (CDINC|FCGEU|CDEU|TORAU|TOREU|HL|TORFX|FCG|Ramsdens)$")
    public void userVerifyAvailableCardTypesForCDINC(String CardType) throws Throwable {

        String vObjCardType = Constants.MakeTransferOR.getProperty("CardType");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardType, ""));
        String vObjVisaDebitCardType = Constants.ProfileManagementOR.getProperty("VisaDebitCardType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjVisaDebitCardType, "visible"));
        LogCapture.info("Card Type - Visa Debit visible..");

        String vObjVisaElectronCardType = Constants.ProfileManagementOR.getProperty("VisaElectronCardType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjVisaElectronCardType, "visible"));
        LogCapture.info("Card Type - Visa Electron visible..");

        String vObjDebitMastercardCardType = Constants.ProfileManagementOR.getProperty("DebitMastercardCardType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebitMastercardCardType, "visible"));
        LogCapture.info("Card Type - Debit Mastercard visible..");

        if (CardType.equalsIgnoreCase("CDINC")) {
            String vObjMaestroCardType = Constants.ProfileManagementOR.getProperty("MaestroCardType");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjMaestroCardType, ""));
            LogCapture.info("All card types verified for CDINC..");
        }
        if (CardType.equalsIgnoreCase("Ramsdens") || CardType.equalsIgnoreCase("FCG") || CardType.equalsIgnoreCase("FCGEU") || CardType.equalsIgnoreCase("CDEU") || CardType.equalsIgnoreCase("TORAU") || CardType.equalsIgnoreCase("TOREU") || CardType.equalsIgnoreCase("HL") || CardType.equalsIgnoreCase("TORFX")) {
            String vObjMaestroCardType = Constants.ProfileManagementOR.getProperty("MaestroCardType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjMaestroCardType, "visible"));
            LogCapture.info("Card Type - Maestro visible..");
            LogCapture.info("All card types verified..");
        }
    }

    @And("^User verify SMS PhoneCall Save buttons are displayed under Authentication preference$")
    public void userVerifyALLParametersDisplayedUnderAuthenticationPreference() throws Exception {

        Constants.key.pause("2", "");
        String vObjSMSTextMessage = Constants.ProfileManagementOR.getProperty("SMSTextMessage");
        Assert.assertEquals("PASS", Constants.key.exist(vObjSMSTextMessage, ""));
        LogCapture.info("SMS text message button is visible..");

        String vObjPhoneCall = Constants.ProfileManagementOR.getProperty("PhoneCall");
        Assert.assertEquals("PASS", Constants.key.exist(vObjPhoneCall, ""));
        LogCapture.info("Phone call button is visible..");

        String vObjSaveButton = Constants.ProfileManagementOR.getProperty("SaveButton");
        Assert.assertEquals("PASS", Constants.key.exist(vObjSaveButton, ""));
        LogCapture.info("Save button is visible..");

    }

    @And("^Verify (SMS|Voice) radio button is selected by default for OTP preference$")
    public void verifySMSRadioButtonIsSelectedByDefaultForOTPPreference(String Preference) throws Throwable {
        if (Preference.equalsIgnoreCase("SMS")) {
            String vObjSMSRadio = Constants.ProfileManagementOR.getProperty("SMSRadio");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSMSRadio, "selected"));
            LogCapture.info(Preference + " is selected by default...");
        }
        if (Preference.equalsIgnoreCase("Voice")) {
            String vObjPhoneRadio = Constants.ProfileManagementOR.getProperty("PhoneRadio");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPhoneRadio, "selected"));
            LogCapture.info(Preference + " is selected by default...");
        }
    }

    @Then("^User Enters the details with firstname \"([^\"]*)\" Lastname \"([^\"]*)\"$")
    public void user_Entersdetails_firstname_Lastname(String Sign_F_Name, String Sign_L_Name) throws
            Throwable {
        String vSign_F_Name = Constants.SignUp.getProperty("Sign_F_Name");
        String vSign_L_Name = Constants.SignUp.getProperty("Sign_L_Name");
        LogCapture.info("Sign Up First Name " + Sign_F_Name + ", Sign Up Last Name " + Sign_L_Name + " is validated ....");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSign_F_Name, Sign_F_Name));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vSign_L_Name, Sign_L_Name));
        Constants.key.pause("2", "");

    }

    @And("^User close browser$")
    public void userCloseBrowser() throws Throwable {

        Assert.assertEquals("PASS", Constants.key.closeBrowser("", ""));
    }

    @And("^User navigate to portal \"([^\"]*)\"$")
    public void userNavigateToPortal(String vUrl) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String url = Constants.CONFIG.getProperty(vUrl);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        Constants.key.pause("4", "");

    }

    @Then("^User should get Agent Offline message$")
    public void userShouldGetAgentOfflineMessage() throws Throwable {
        int count = 0;
        LogCapture.info("User Validating Agent Offline Message....");
        String vHelpMessage = Constants.loginPageOR.getProperty("AgentOfflineMsg");
        do {
            count = count + 1;
        } while (!Constants.driver.findElement(By.xpath(vHelpMessage)).isDisplayed());

        LogCapture.info("Repeat the Loop Untill the HelpMessage : Count:->" + count);
        Assert.assertEquals("PASS", Constants.key.verifyText(vHelpMessage, "Agent Offline"));
        LogCapture.info("Agent Offline Message has been validated successfully");

    }

    @And("^User navigate to (TORAU) portal \"([^\"]*)\" in new tab$")
    public void userNavigateToTORAUPortalInNewTab(String application, String vUrl) throws Throwable {
        Constants.key.pause("5", "");

        // Write code here that turns the phrase above into concrete actions
        if (application.equals("TORAU")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigateNewTab("", url));
            Constants.key.pause("7", "");
            Assert.assertEquals("PASS", Constants.key.navigateTab("", 1));
            LogCapture.info("User has been navigated to " + application + " application portal now");
            Constants.key.pause("7", "");

        }
    }

    @Then("^User should get Chat Now option$")
    public void userShouldGetChatNowOption() throws Throwable {
        int count = 0;
        LogCapture.info("Validating Chat Now option....");
        String vChatNowMsg = Constants.loginPageOR.getProperty("ChatNowButton");
        do {
            count = count + 1;
        } while (!Constants.driver.findElement(By.xpath(vChatNowMsg)).isDisplayed());

        LogCapture.info("Repeat the Loop Untill the HelpMessage : Count:->" + count);
        Assert.assertEquals("PASS", Constants.key.verifyText(vChatNowMsg, "Chat now"));
        LogCapture.info("Chat Now option validated successfully");

    }

    @Then("^User navigate back to (SF|TORAU) Application$")
    public void userNavigateBackToSFApplication(String application) throws Throwable {
        if (application.equalsIgnoreCase("SF")) {
            Assert.assertEquals("PASS", Constants.key.navigateTab("", 0));
            Constants.key.pause("10", "");
            LogCapture.info("User navigated to " + application);

        } else if (application.equalsIgnoreCase("TORAU")) {
            Assert.assertEquals("PASS", Constants.key.navigateTab("", 1));
            Constants.key.pause("10", "");
            LogCapture.info("User navigated to " + application);
        }

    }

    @And("^User should get Waiting for Chat Success message$")
    public void userShouldGetWaitingForChatSuccessMessage() throws Throwable {
        int count = 0;
        LogCapture.info("Validating Waiting Chat Now Success message....");
        String vWaitingToChatSuccessMessage = Constants.loginPageOR.getProperty("WaitingToChatSuccessMsg");
        do {
            count = count + 1;
        } while (!Constants.driver.findElement(By.xpath(vWaitingToChatSuccessMessage)).isDisplayed());

        LogCapture.info("Repeat the Loop Untill the HelpMessage : Count:->" + count);
        Assert.assertEquals("PASS", Constants.key.verifyText(vWaitingToChatSuccessMessage, "A member of our team will join the chat shortly."));
        LogCapture.info("Waiting Chat Now Success message validated successfully");

    }

    @And("^User shuould get chat acceptance welcome message$")
    public void userShuouldGetChatAcceptanceWelcomeMessage() throws Throwable {
        int count = 0;
        LogCapture.info("Validating Chat accepted welcome  message....");
        String vObjChatAcceptanceWelcomeMessage = Constants.loginPageOR.getProperty("ChatAcceptanceSuccessMsg");
        do {
            count = count + 1;
        } while (!Constants.driver.findElement(By.xpath(vObjChatAcceptanceWelcomeMessage)).isDisplayed());

        LogCapture.info("Repeat the Loop Untill the HelpMessage : Count:->" + count);
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjChatAcceptanceWelcomeMessage, "How can I help you?"));
        LogCapture.info("Chat accepted Welcome Message validated successfully");

    }

    @And("^User sent message \"([^\"]*)\"$")
    public void userSentMessage(String msg) throws Throwable {
        LogCapture.info("User sending message to SF Chat agent ->" + "'" + msg + "'....");
        String vObjChatTextArea = Constants.loginPageOR.getProperty("TextAreaChatBox");
        Assert.assertEquals("PASS", Constants.key.click(vObjChatTextArea, ""));

        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjChatTextArea, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjChatTextArea, "enter"));
        Constants.key.pause("5", "");
        LogCapture.info("User sent message to SF Chat agent successfully->" + "'" + msg + "'");
    }

    @And("^User should get Yes, I'm done and No, take me back to chat buttons$")
    public void userShouldGetYesIMDoneAndNoTakeMeBackToChatButtons() throws Throwable {
        LogCapture.info("Verfiying Yes, I'm done and No button visible...");
        String vObjesIMDoneButton = Constants.loginPageOR.getProperty("YesChatCloseOption");
        Assert.assertEquals("PASS", Constants.key.exist(vObjesIMDoneButton, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjesIMDoneButton, "Yes, I'm done"));
        LogCapture.info("Yes, I'm done button is exist");

        LogCapture.info("Verfiying Yes, I'm done and No button visible...");
        String vObjNoChatCloseOption = Constants.loginPageOR.getProperty("NoChatCloseOption");
        Assert.assertEquals("PASS", Constants.key.exist(vObjNoChatCloseOption, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjNoChatCloseOption, "No, take me back to chat"));
        LogCapture.info("Yes, No, take me back to chat button is exist");

    }

    @And("^Verify downloaded User Chat History$")
    public void verifyDownloadedUserChatHistory() throws IOException {

        Assert.assertEquals("PASS", Constants.key.ChatFileOperation("exist", "transcript"));
        Assert.assertEquals("PASS", Constants.key.ChatFileOperation("verifycontent", "transcript"));


    }

    @And("^User verify \"([^\"]*)\" Bank Transfer Instruction \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" for respective \"([^\"]*)\"$")
    public void userVerifyBankTransferInstructionForRespective(String bank, String AccountName, String BankName, String BranchCode, String AccountNo, String IbanNo, String SwiftCode, String currency) throws Throwable {
        String vObjAccountName = "//table[@class='transfer-complete-details']//following::*//span[contains(text(),'" + AccountName + "')]";
        String vObjBankName = "//table[@class='transfer-complete-details']//following::*//span[contains(text(),'" + BankName + "')]";
        String vObjBranchCode = "//table[@class='transfer-complete-details']//following::*//span[contains(text(),'" + BranchCode + "')]";
        String vObjAccountNo = "//table[@class='transfer-complete-details']//following::*//span[contains(text(),'" + AccountNo + "')]";
        String vObjIbanNo = "//table[@class='transfer-complete-details']//following::*//span[contains(text(),'" + IbanNo + "')]";
        String vObjSwiftCode = "//table[@class='transfer-complete-details']//following::*//span[contains(text(),'" + SwiftCode + "')]";

        String vObjAccountNameLabel = Constants.DashboardOR.getProperty("AccountNameTransferLabel");
        String vObjBankNameLabel = Constants.DashboardOR.getProperty("BankNameTransferLabel");
        String vObjBranchCodeLabel = Constants.DashboardOR.getProperty("SortCodeTransferLabel");
        String vObjAccountNoLabel = Constants.DashboardOR.getProperty("AcoountNumberTransferLabel");
        String vObjIbanNoLabel = Constants.DashboardOR.getProperty("IbanNumberTransferLabel");
        String vObjSwiftCodeLabel = Constants.DashboardOR.getProperty("SwiftCodeTransferLabel");

        LogCapture.info("Validating +" + currency + " bank details...");
        Constants.key.pause("2", "");

        LogCapture.info("Verifying for " + currency + "  bank details AccountName..");
        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjAccountName,""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountName, AccountName));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountNameLabel, "Account name"));
        LogCapture.info("Verification for " + currency + " Currency bank details AccountName has been successfully done");

        LogCapture.info("Verifying for " + currency + "  Currency bank details BankName..");
        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjBankName,""));
        Constants.key.pause("1", "");
        // Assert.assertEquals("PASS",Constants.key.verifyText(vObjBankName,BankName));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBankNameLabel, "Bank name"));
        LogCapture.info("Verification for " + currency + "  Currency bank details BankName has been successfully done");

        LogCapture.info("Verifying for " + currency + "  Currency bank details BranchCode");
        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjBranchCode,""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBranchCode, BranchCode));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjBranchCodeLabel, "Sort code"));
        LogCapture.info("Verification for " + currency + "  Currency bank details BranchCode has been successfully done");

        LogCapture.info("Verifying for " + currency + " Currency bank details AccountNo");
        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjAccountNo,""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAccountNo, AccountNo));
        //Assert.assertEquals("PASS",Constants.key.verifyText(vObjAccountNoLabel,"Account number"));
        LogCapture.info("Verification for " + currency + " Currency bank details AccountNo has been successfully done");

        LogCapture.info("Verifying for " + currency + " Currency bank details IbanNo");
        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjIbanNo,""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjIbanNo, IbanNo));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjIbanNoLabel, "IBAN"));
        LogCapture.info("Verification for " + currency + "  Currency bank details IbanNo has been successfully done");

        LogCapture.info("Verifying for " + currency + " Currency bank details SwiftCode");
        //Assert.assertEquals("PASS",Constants.key.Mouse_Events(vObjSwiftCode,""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjSwiftCode, SwiftCode));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjSwiftCodeLabel, "SWIFTBIC"));
        LogCapture.info("Verification for " + currency + " Currency bank details SwiftCode has been successfully done");

        LogCapture.info(currency + " bank details validated");


    }

}


//    @Then("^User Enters the details with firstname \"([^\"]*)\" Lastname \"([^\"]*)\"$")
//    public void user_Entersdetails_firstname_Lastname(String Sign_F_Name, String Sign_L_Name) throws Throwable {
//        String vSign_F_Name = Constants.SignUp.getProperty("Sign_F_Name");
//        String vSign_L_Name = Constants.SignUp.getProperty("Sign_L_Name");
//        LogCapture.info("Sign Up First Name " + Sign_F_Name + ", Sign Up Last Name " + Sign_L_Name + " is validated ....");
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vSign_F_Name, Sign_F_Name));
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vSign_L_Name, Sign_L_Name));
//        Constants.key.pause("2", "");
//    }


