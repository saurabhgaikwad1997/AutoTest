
/*ClassName: Resuables.java
Date: 17/April/2020
Author: Saurabh Gadgil
Purpose of class: To implement generic methods, all resuable using Xpath and selenium for robust framework.*/

package com.selenium.utillity;

import com.utility.LogCapture;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.io.*;

import java.io.File;
import java.io.IOException;

import java.net.URL;
import java.util.*;
import java.util.List;


import static com.selenium.utillity.Constants.*;


import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;

import static com.selenium.utillity.Constants.KEYWORD_FAIL;
import static com.selenium.utillity.Constants.KEYWORD_PASS;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;

//import com.sun.org.apache.bcel.internal.Const;
//import com.sun.org.apache.bcel.internal.Const;


public class Reusables {
    public String actual;
    public String emailID;
    public static String Email;
    public String ScreenshotFlag;
    public String PDFoutput;
    String downloadFilesPath = System.getProperty("user.dir") + "\\src\\main\\resources\\Downloads";

    public boolean openBrowser(String object, String data) throws Exception {
        try {
            String oSName = System.getProperty("os.name");
            if (data.equalsIgnoreCase("Chrome")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/windows/Chrome/chromedriver.exe");
                    WebDriverManager.chromedriver().setup();
                    ChromeOptions options = new ChromeOptions();
                    options.addArguments("--remote-allow-origins=*");
                    //System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver_old.exe");
                    Constants.driver = new ChromeDriver(options);
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((ChromeDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                } else {
                    //System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/linux/Chrome/chromedriver");
                    //System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
                    WebDriverManager.chromedriver().setup();
                    ChromeOptions options = new ChromeOptions();
                    options.setHeadless(true);
                    options.addArguments("--window-size=1920,1080");
                    options.addArguments("--disable-gpu");
                    options.addArguments("--disable-extensions");
                    options.setExperimentalOption("useAutomationExtension", false);
                    options.addArguments("--proxy-server='direct://'");
                    options.addArguments("--proxy-bypass-list=*");
                    options.addArguments("--start-maximized");
                    options.addArguments("--headless");
                    options.addArguments("--whitelisted-ips");
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    Constants.driver = new ChromeDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                    //options.addArguments("--no-sandbox");
                }
            } else if (data.equalsIgnoreCase("Firefox")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/windows/Firefox/geckodriver.exe");
                    WebDriverManager.firefoxdriver().setup();
                    File pathBinary = new File(System.getProperty("user.home") + "/AppData/Local/Mozilla Firefox/firefox.exe");
                    FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
                    //DesiredCapabilities desired = DesiredCapabilities.firefox();
                    FirefoxOptions options = new FirefoxOptions();
                    options.setBinary(firefoxBinary);
                    //desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
                    WebDriverManager.firefoxdriver().setup();
                    Constants.driver = new FirefoxDriver(options);
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((FirefoxDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                } else {
                    FirefoxBinary firefoxBinary = new FirefoxBinary();
                    firefoxBinary.addCommandLineOptions("--headless");
                    WebDriverManager.firefoxdriver().setup();
                    //System.setProperty("webdriver.gecko.driver", "/usr/local/bin/geckodriver");
                    FirefoxOptions options = new FirefoxOptions();
                    options.addArguments("--no-sandbox");
                    options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
                    options.setBinary(firefoxBinary);
                    Constants.driver = new FirefoxDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                }
            } else if (data.equalsIgnoreCase("Edge")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/windows/Edge/msedgedriver.exe");
                    WebDriverManager.edgedriver().setup();
                    Constants.driver = new EdgeDriver();
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((EdgeDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                    //takeSnapShot();
                    takeSnapShot();
                } else {
//                    System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/linux/Edge/msedgedriver");
                    System.setProperty("webdriver.edge.driver", "/usr/bin/edgedriver");
                    //WebDriverManager.edgedriver().setup();
                    EdgeOptions options = new EdgeOptions();
                    options.setHeadless(true);
                    options.addArguments("--window-size=1920,1080");
                    options.addArguments("--disable-gpu");
                    options.addArguments("--disable-extensions");
                    options.setExperimentalOption("useAutomationExtension", false);
                    options.addArguments("--proxy-server='direct://'");
                    options.addArguments("--proxy-bypass-list=*");
                    options.addArguments("--start-maximized");
                    options.addArguments("--headless");
                    options.addArguments("--whitelisted-ips");
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    Constants.driver = new EdgeDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                    //options.addArguments("--no-sandbox");
                }

            }
            takeSnapShot();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found...");
            takeSnapShot();
            return false;
        }
    }


    public String closeBrowser(String object, String data) throws Exception {
        try {
            Constants.driver.quit();
        } catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found..." + ex);

            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;

    }

    public String navigate(String object, String data) throws Exception {
        try {
            Constants.driver.navigate().to(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";

        }
        return KEYWORD_PASS;
    }

    public String writeInInput(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).sendKeys(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String click(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("actual value->>>>" + actual);
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String verifyInnerText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getAttribute("innerText");
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String pause(String object, String data) throws NumberFormatException, InterruptedException {
        long time = (long) Double.parseDouble(object);
        Thread.sleep(time * 1000L);
        return KEYWORD_PASS;

    }


    public String selectList(String object, String data) throws Exception {
        try {
            int attempt = 0;
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            if (!data.equals(Constants.RANDOM_VALUE)) {
                objSelect.selectByVisibleText(data);
                takeSnapShot();
            } else {
                WebElement droplist = Constants.driver.findElement(By.xpath(object));
                List<WebElement> droplist_contents = droplist.findElements(By.tagName("option"));
                Random num = new Random();
                int index = num.nextInt(droplist_contents.size());
                String selectedVal = droplist_contents.get(index).getText();
                objSelect.selectByVisibleText(selectedVal);
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "---Could not select from the List---" + e.getMessage();

        }
        return KEYWORD_PASS;
    }

    /*public String sendkeyboardStroke(String object, String data) throws Exception {
        //valid values for data = space,enter,up,tab,down,left,right
        try {
            Robot robot = new Robot();
            if (!object.equals("")) {
                WebElement browseBtn = Constants.driver.findElement(By.xpath(object));
                browseBtn.click();
                Thread.sleep(1000);
            }
            if (data.equals("space")) {
                robot.keyPress(KeyEvent.VK_SPACE);
                robot.keyRelease(KeyEvent.VK_SPACE);
            } else if (data.equals("enter")) {
                robot.keyPress(KeyEvent.VK_ENTER);
                robot.keyRelease(KeyEvent.VK_ENTER);
            } else if (data.equals("tab")) {
                robot.keyPress(KeyEvent.VK_TAB);
                robot.keyRelease(KeyEvent.VK_TAB);
            } else if (data.equals("down")) {
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Thread.sleep(1000);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "....unable to find element...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }*/

    public String getReportConfigPath() {
        String reportConfigPath = Constants.CONFIG.getProperty("reportConfigPath");
        if (reportConfigPath != null) return reportConfigPath;
        else
            throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
    }

    public String exist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String navigateSubMenu(String object, String data) throws Exception {
        try {
            WebElement ele = Constants.driver.findElement(By.xpath(object));
            //WebElement ele = driver.findElement(By.xpath("element_xpath"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", ele);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String AltasRejectDropDown(String object, String data) throws Exception {
        try {
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            //System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 0; i < dropdown_list.size(); i++) {
                //System.out.println(dropdown_list.get(i).getText());
                if (dropdown_list.get(i).getText().contains(data)) {
                    for (int j = 1; j < 10000; j++) {
                        String vdata = Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).getText();
                        if (vdata.equals(data)) {
                            Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).click();
                            break;
                        }
                    }
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }

 /*   public void ReadCookies() {
        // create file named Cookies to store Login Information
        File file = new File("C:\\POC2\\CucumberSeleniumProject\\Cookies.data");
        try {
            // Delete old file if exists
            file.delete();
            file.createNewFile();
            FileWriter fileWrite = new FileWriter(file);
            BufferedWriter Bwrite = new BufferedWriter(fileWrite);
            // loop for getting the cookie information

            // loop for getting the cookie information
            for (Cookie ck : Constants.driver.manage().getCookies()) {
                Bwrite.write((ck.getName() + ";" + ck.getValue() + ";" + ck.getDomain() + ";" + ck.getPath() + ";" + ck.getExpiry() + ";" + ck.isSecure()));
                Bwrite.newLine();
            }
            Bwrite.close();
            fileWrite.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void WriteCookies() {
        try {

            File file = new File("C:\\POC2\\CucumberSeleniumProject\\Cookies.data");
            FileReader fileReader = new FileReader(file);
            BufferedReader Buffreader = new BufferedReader(fileReader);
            String strline;
            while ((strline = Buffreader.readLine()) != null) {
                StringTokenizer token = new StringTokenizer(strline, ";");
                while (token.hasMoreTokens()) {
                    String name = token.nextToken();
                    String value = token.nextToken();
                    String domain = token.nextToken();
                    String path = token.nextToken();
                    Date expiry = null;

                    String val;
                    if (!(val = token.nextToken()).equals("null")) {
                        expiry = new Date(val);
                    }
                    Boolean isSecure = new Boolean(token.nextToken()).
                            booleanValue();
                    Cookie ck = new Cookie(name, value, domain, path, expiry, isSecure);
                    System.out.println(ck);
                    Constants.driver.manage().addCookie(ck); // This will add the stored cookie to your current session
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }*/

    public String isAlertPresent() {
        try {
            Alert alert = Constants.driver.switchTo().alert();
            System.out.println("Alert Message" + alert.getText());
            alert.accept();
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String clearText(String object) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).clear();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String SfLeadDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("2", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String VerifyTitle(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.getTitle();
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }
    //
    //        w.until(ExpectedConditions.visibilityOfAllElements( By.xpath(Constants.CreateFxTicketOR.getProperty("CloseFxSlipButton"))));

    public String VisibleConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, 300);
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String KeyboardAction(String object, String data) throws Exception {
        try {
            if (data.equalsIgnoreCase("enter")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("tab")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.TAB);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("space")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.SPACE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("downArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("selectall")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.chord(Keys.CONTROL, "a"));
                takeSnapShot();
            }else if (data.equalsIgnoreCase("upArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_UP);
                takeSnapShot();
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String SelectRecipient(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'Select')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String RecipientTransfer(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Transfer')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String RecipientPay(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Pay')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyElementProperties(String object, String data) throws Exception {
        try {
            if (data.contains("disabled")) {
                String buttonDisabled = Constants.driver.findElement(By.xpath(object)).getAttribute("disabled");
                if (buttonDisabled != null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not Disabled";
                }
            } else if (data.contains("enabled")) {
                String buttonEnabled = Constants.driver.findElement(By.xpath(object)).getAttribute("disabled");
                if (buttonEnabled == null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not Enabled";
                }

            } else if (data.contains("visible")) {
                if (Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Displayed";
                }
            } else if (data.contains("unselected")) {
                if (!Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("selected")) {
                if (Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("readonly")) {
                String readonly = Constants.driver.findElement(By.xpath(object)).getAttribute("readonly");
                if (readonly != null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not readonly";
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + " -  Could not find element";

        }
        return KEYWORD_PASS;
    }

    public String notexist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_PASS;
        }
        return KEYWORD_FAIL + "object exist ";
    }

    public String uniqueEmailID(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            String emailID = "AutoTestUser" + userName + "@gmail.com";
            LogCapture.info("emailID start with xyz is " + ": " + emailID);
            //System.out.println("Result......" + emailID);
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(1000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(emailID);
            // Constants.driver.findElement(By.xpath(object)).sendKeys("autotestuser213440261@gmail.com");
            Email = Constants.driver.findElement(By.xpath(object)).getText();
            System.out.println("AutoTestUser Email ID" + Email);
            Thread.sleep(1000);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String uniqueEmailAddress(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            emailID = "xyz" + userName + "@gmail.com";

            LogCapture.info("emailID is " + ": " + emailID);


        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return emailID;
    }

    public String ClickEachElementOfFrame(String object, String data) throws Exception {
        try {
            //    List<WebElement> Elements = driver.findElements(By.cssSelector(object));
            List<WebElement> Elements = Constants.driver.findElements(By.xpath(object));
            ListIterator<WebElement> ListOfElements = Elements.listIterator();
            while (ListOfElements.hasNext()) {
                WebElement elem = ListOfElements.next();
                // do something with elem
                elem.click();
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String MouseFunctions(String object, String data) throws Exception {
        try {
            WebElement Element = driver.findElement(By.xpath(object));
            Actions action = new Actions(Constants.driver);
            if (data.equalsIgnoreCase("clickAndHold")) {
                action.moveToElement(Element).build().perform();
                action.clickAndHold(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("ReleaseMouseClick")) {
                action.moveToElement(Element).build().perform();
                action.release(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("DoubleClick")) {
                action.doubleClick(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("MoveToElement")) {
                action.moveToElement(Element);
                action.perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("click")) {
                action.click(Element).build().perform();
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to clickAndHold...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    public String Mouse_Events(String Object, String data) throws Exception {
        try {
            Actions build = new Actions(Constants.driver);
            build.moveToElement(Constants.driver.findElement(By.xpath(Object))).moveByOffset(11, 11).click().build().perform();
        } catch (Exception e) {
            takeSnapShot();
            return
                    KEYWORD_FAIL;
        }
        return
                KEYWORD_PASS;
    }

    public String Enter_OTP(String object, String data) throws Exception {
        try {
            List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
            for (WebElement input : inputs) {
                input.clear();
                input.sendKeys(data);
                break;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }
//Xpath  Used for Entering OTP  EnterPinTextBox= //input[@class="pin-number"]
// input is the tag name of all the all the textfields which are in one frameand we have used it to iterate into the Loop

    public String ClickIfEnable(String object, String data) throws Exception {
        try {
            int attempts = 0;
            int maxAttempts = 10;
            Constants.key.VisibleConditionWait(object, "");
//        boolean buttonDisabled = false;
            while (attempts++ <= maxAttempts) {
                if (Constants.driver.findElement(By.xpath(object)).isEnabled()) {
                    Constants.driver.findElement(By.xpath(object)).click();
                    break;
                } else {
                    Thread.sleep(500);
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }

    public String writeInInputObO(String object, String data) throws Exception {
        try {
            String val = data;
            WebElement element = Constants.driver.findElement(By.xpath(object));
            element.clear();
            for (int i = 0; i < val.length(); i++) {
                char c = val.charAt(i);
                String s = new StringBuilder().append(c).toString();
                element.sendKeys(s);
                Thread.sleep(2000);
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write one by one " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public static String[] generateRandomWords(int numberOfWords) {
        String[] randomStrings = new String[numberOfWords];
        Random random = new Random();
        for (int i = 0; i < numberOfWords; i++) {
            char[] word = new char[random.nextInt(8) + 3]; // words of length 3 through 10. (1 and 2 letter words are boring.)
            for (int j = 0; j < word.length; j++) {
                word[j] = (char) ('a' + random.nextInt(26));
            }
            randomStrings[i] = new String(word);
        }
        return randomStrings;
    }

    public String randomWordGenerator(String object, int numberOfWords) throws Exception {
        try {
            String[] randomStrings = new String[numberOfWords];
            Random random = new Random();
            for (int i = 0; i < numberOfWords; i++) {
                char[] word = new char[random.nextInt(1) + 1]; // words of length 3 through 10. (1 and 2 letter words are boring.)
                for (int j = 0; j < word.length; j++) {
                    word[j] = (char) ('a' + random.nextInt(26));
                }
                randomStrings[i] = new String(word);

            }
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(2000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(randomStrings);
            System.out.println("Random string generated: " + randomStrings);

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String DeleteRecipient(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'x')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String selectPTRecord(String object, String innerObject, String data) throws Exception {
        try {
            List<WebElement> listElements = Constants.driver.findElements(By.xpath(object));
            for (int i = 0; i < listElements.size(); i++) {
                if (i % 5 == 0) {
                    click(Constants.PaymentTrackingOR.getProperty("ShowMoreButton"), "");
                }
                WebElement element = listElements.get(i);
                element.click();
                Thread.sleep(2000);
                try {
                    WebElement referenceElement = element.findElement(By.xpath(innerObject));
                    if (referenceElement != null) {
                        referenceElement.click();
                        LogCapture.info("Record displayed on PT dashboard =" + referenceElement.getText());
                        takeSnapShot();
                        return KEYWORD_PASS;
                    }
                } catch (Exception e) {
                    LogCapture.info(e.getMessage());
                }
            }
            return KEYWORD_FAIL + "Record is not displayed on PT dashboard";

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
    }

    public String LanguageDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("3", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String ConvertStringToCase(String word, String strcase) throws Exception {
        try {
            if (strcase.equalsIgnoreCase("lower")) {
                word = word.toLowerCase();
            } else if (strcase.equalsIgnoreCase("upper")) {
                word = word.toUpperCase();
            }
        } catch (Exception e) {
            LogCapture.info(e.getMessage());
        }
        return word;
    }


    public String getText(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("Actual Length:->" + actual.length());
            }
            LogCapture.info("Actual:->" + actual);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return actual;

    }

    public String ChatFileOperation(String operation, String data) throws IOException {
        try {
            String path = System.getProperty("user.home");

            path = path + "/Downloads";
            LogCapture.info(path);
            File file = new File(path);
            File files[] = file.listFiles();
            String filename, filename1;
            for (File f : files) {
                if (f.getName().contains(data)) {
                    filename = f.getName();
                    System.out.println(f.getName());
                    if (operation.equalsIgnoreCase("delete")) {
                        f.delete();
                        LogCapture.info(f.getName() + " file got deleted successfully");
                    } else if (operation.equalsIgnoreCase("exist")) {
                        if (filename.equalsIgnoreCase(data + ".txt")) {
                            LogCapture.info(f.getName() + " file downloaded successfully");
                        }
                    } else if (operation.equalsIgnoreCase("verifycontent")) {
                        FileInputStream fstream1 = new FileInputStream(path + "/" + data + ".txt");

                        DataInputStream in1 = new DataInputStream(fstream1);
                        //DataInputStream in2= new DataInputStream(fstream2);

                        BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
                        //BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));

                        String strLine1;
                        String strLine2 = "How can I help you?";


                        while ((strLine1 = br1.readLine()) != null) {
                            if (strLine1.contains(strLine2)) {
                                LogCapture.info(f.getName() + " file downloaded has chat conversation");
                                LogCapture.info(strLine1 + " file downloaded has content");
                                LogCapture.info(f.getName() + " file downloaded content has been compare with " + strLine2);

                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return KEYWORD_FAIL;

        }
        return KEYWORD_PASS;
    }


/*    HtmlUnitDriver driver = new HtmlUnitDriver(BrowserVersion.CHROME ,true);
driver.get("your web URL");
    WebDriverWait wait = new WebDriverWait(driver, 30);
wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("ppLoginForm"))));
wait.until(ExpectedConditions.elementToBeClickable(By.name("j_username")));*/


    public String navigateNewTab(String object, String data) throws Exception {
        try {
            String currentHandle = Constants.driver.getWindowHandle();

            ((JavascriptExecutor) Constants.driver).executeScript("window.open()");


            Set<String> handles = Constants.driver.getWindowHandles();
            for (String actual : handles) {

                if (!actual.equalsIgnoreCase(currentHandle)) {
                    //switching to the opened tab
                    Constants.driver.switchTo().window(actual);

                    //opening the URL saved.
                    Constants.driver.navigate().to(data);
                }
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";
        }
        return KEYWORD_PASS;
    }

    public String navigateTab(String Object, int data) throws Exception {
        try {
            ArrayList<String> tabs = new ArrayList<String>(Constants.driver.getWindowHandles());
            Constants.driver.switchTo().window(tabs.get(data));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String selectOrganisationBussinessPartner(String object, String data) throws Exception {
        WebElement element = null;
        String vObjOrganisationBussinessPartner = "";
        try {
            for (int i = 0; i <= 100; i++) {

                if (object.equals("Organisation")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisations-" + i + "']";
                } else if (object.equals("Business Partner")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisation-business-partner-" + i + "']";
                }
                //LogCapture.info(vObjOrganisation);

                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisationBussinessPartner, ""));
                String abc = Constants.key.getText(vObjOrganisationBussinessPartner, "");
                //LogCapture.info(abc);

                if (abc.equalsIgnoreCase(data)) {
                    // LogCapture.info("inside");
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "MoveToElement"));
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "click"));
                    //element.findElement(By.xpath(vObjOrganisation)).click();
                    takeSnapShot();
                    break;
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable select" + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyOrganisationIntableCustomer(String object, String data, String column) throws Exception {
        int a = 0, b = 0;
        try {
            List<WebElement> itemsfiler = driver.findElements(By.xpath("//tbody[@id='accountSummaryTableBody']/tr"));
            int trnofilter = itemsfiler.size() + 1;
            //LogCapture.info("Total rows" +trnofilter);
            for (int s = 2; s < trnofilter; s++) {
                String organization = "//tbody[@id='accountSummaryTableBody']/tr[" + s + "]/td[" + column + "]/a[1]";
                String rowdata = Constants.driver.findElement(By.xpath(organization)).getText();
                //LogCapture.info("organization" +rowdata);
                if (rowdata.equals(data)) {
                    a = a + 1;
                } else {
                    b = b + 1;
                }
            }
            //LogCapture.info("Number of match rows->" +a);
            //LogCapture.info("Number of unmatch rows->" +b);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "something went wrong while fetching data " + e.getMessage();
        }
        if (b > 0) {
            return KEYWORD_FAIL;
        } else {
            return KEYWORD_PASS;
        }
    }

    public String scrollIntoViewElement(String object, String data) throws Exception {
        try {
            WebElement vObject = Constants.driver.findElement(By.xpath(object));
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView", vObject);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String ReadPDFFile(String object, String data) throws IOException {
        try {
            String fileName = "T" + System.currentTimeMillis();
            File sourceFile = new File(System.getProperty("user.dir") + "/Downloads/" + data);
            File newFile = new File(System.getProperty("user.dir") + "/Downloads/" + fileName + ".pdf");
            if (sourceFile.exists()) {
                LogCapture.info("File name is correct: " + sourceFile.getName());
            } else {
                LogCapture.info("File name is INCORRECT: " + sourceFile.getName());
                Assert.fail();
            }

            LogCapture.info("Creating copy of file..");
            newFile.createNewFile();
            FileUtils.copyFile(sourceFile, newFile);
            String url = "file:///" + downloadFilesPath + fileName + ".pdf";
            URL pdfUrl = new URL(url);
            InputStream in = pdfUrl.openStream();
            BufferedInputStream bf = new BufferedInputStream(in);
            PDDocument doc = PDDocument.load(bf);
            if (object.equalsIgnoreCase("PageCount")) {
                int numberOfPages = doc.getNumberOfPages();
                System.out.println("The total number of pages " + numberOfPages);
            } else if (object.equalsIgnoreCase("PageText")) {
                PDFTextStripper pdfStrip = new PDFTextStripper();
                String content = pdfStrip.getPageStart();
                System.out.println("Content of the page is" + content);
            }
            doc.close();
//            LogCapture.info("Source file getting deleted with file name: " + sourceFile.getName());
//            boolean DeletSourceFile=sourceFile.delete();
//            if(DeletSourceFile){
//                LogCapture.info("Source file deleted");
//            }
//            else{
//                LogCapture.info("Source file NOT deleted");
//                Assert.fail();
//            }
            return KEYWORD_PASS;
        } catch (IOException e) {
            e.printStackTrace();
            return KEYWORD_FAIL;
        }

    }

    public String defaultDownloadFilesOperations(String object, String data) {
        try {
            if (object.equalsIgnoreCase("deleteAllFiles")) {
                try {
                    LogCapture.info("All files deleted present in directory: " + downloadFilesPath);
                    FileUtils.cleanDirectory(new File(downloadFilesPath));
                } catch (IOException e) {
                }
            } else if (object.equalsIgnoreCase("deleteSelectedFile")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        dir_contents[i].delete();
                        LogCapture.info(data + " file deleted..");
                        LogCapture.info("Number of files got deleted: " + i);
                    }
                }
            } else if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        LogCapture.info(data + " file downloaded..");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String renameDownloadedFile(String object, String data) {
        try {
            String NewfileName = "T" + System.currentTimeMillis();
            File sourceFile = new File(System.getProperty("user.dir") + "/Downloads/" + data);
            File newFile = new File(System.getProperty("user.dir") + "/Downloads/" + NewfileName + ".pdf");
            if(sourceFile.exists()) {
                LogCapture.info("File exist with name: " + sourceFile.getName());
                LogCapture.info("Creating copy of file..");
                newFile.createNewFile();
                FileUtils.copyFile(sourceFile, newFile);
                newFile.isFile();
                LogCapture.info("Created copy of file with filename: " + newFile.getName());
            }else{
                LogCapture.info("File DOES NOT exist with name: " + data);
                Assert.fail();
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public boolean openBrowserWithDefaultDownloadDirectory(String object, String data) throws Exception {
//        try {
//            String oSName = System.getProperty("os.name");
//            if (data.equals("Chrome")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/windows/chromedriver.exe");
//                    //System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
//                    ChromeOptions options = new ChromeOptions();
//                    options.addArguments("--start-maximized");
//                    Map<String, Object> prefs = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    prefs.put("download.default_directory", downloadFilesPath);
//                    prefs.put("plugins.always_open_pdf_externally", true);
//                    prefs.put("download.directory_upgrade", true);
//                    prefs.put("download.prompt_for_download", false);
//
//                    HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    DesiredCapabilities cap = DesiredCapabilities.chrome();
//                    cap.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
//                    cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//                    cap.setCapability(ChromeOptions.CAPABILITY, options);
//
//
//                    driver = new ChromeDriver(cap);
//                    // Constants.driver.manage().window().maximize();
//                    takeSnapShot();
//                } else {
//                    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/linux/chromedriver");
//                    ChromeOptions options = new ChromeOptions();
//                    options.setHeadless(true);
//                    //options.addArguments("--window-size=1920,1080")  ;
//                    //options.addArguments("--disable-gpu");
//                    //options.addArguments("--headless --disable-gpu --screenshot "+ data)   ;
//                    options.addArguments("--disable-extensions");
//                    options.setExperimentalOption("useAutomationExtension", false);
//                    options.addArguments("--proxy-server='direct://'");
//                    options.addArguments("--proxy-bypass-list=*");
//                    //options.addArguments("--start-maximized");
//                    //options.addArguments("--headless");
//                    options.addArguments("--whitelisted-ips");
//                    options.addArguments("--disable-dev-shm-usage");
//                    options.addArguments("--no-sandbox");
//
//                    options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
//                    Map<String, Object> prefs = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    prefs.put("download.default_directory", downloadFilesPath);
//                    prefs.put("plugins.always_open_pdf_externally", true);
//                    prefs.put("download.directory_upgrade", true);
//                    prefs.put("download.prompt_for_download", false);
//
//                    HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    DesiredCapabilities cap = DesiredCapabilities.chrome();
//                    cap.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
//                    cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//                    cap.setCapability(ChromeOptions.CAPABILITY, options);
//
//                    //options.addArguments("window-size=1920,1080");
//                    // options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
//
//                    driver = new ChromeDriver(cap);
//                    driver.manage().window().maximize();
//                    takeSnapShot();
//                    //options.addArguments("--no-sandbox");
//                }
//            } else if (data.equals("FF")) {
//                System.setProperty("webdriver.gecko.driver", "C:\\WhiteLabelAutomation\\Drivers\\FireFox\\geckodriver.exe");
//                File pathBinary = new File("C:\\Users\\saurabh.gadgil\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
//                FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
//                DesiredCapabilities desired = DesiredCapabilities.firefox();
//                FirefoxOptions options = new FirefoxOptions();
//                desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
//                driver = new FirefoxDriver(options);
//                driver.manage().window().maximize();
//
//
//                /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//                Constants.driver = new FirefoxDriver();
//                Constants.driver.manage().window().maximize();*/
//            } else if (data.equalsIgnoreCase("FireFox")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//                    File pathBinary = new File(System.getProperty("user.home") + "/AppData/Local/Mozilla Firefox/firefox.exe");
//                    FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
//                    DesiredCapabilities desired = DesiredCapabilities.firefox();
//                    FirefoxOptions options = new FirefoxOptions();
//                    desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
//                    driver = new FirefoxDriver(options);
//                    driver.manage().window().maximize();
//    /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//    Constants.driver = new FirefoxDriver();
//    Constants.driver.manage().window().maximize();*/
//                } else {
//                    //Firefox linux connection here
//                }
//            } else if (data.equalsIgnoreCase("Edge")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/Edge/msedgedriver.exe");
//                    driver = new EdgeDriver();
//                    driver.manage().window().maximize();
//                    //takeSnapShot();
//                    takeSnapShot();
//    /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//    Constants.driver = new FirefoxDriver();
//    Constants.driver.manage().window().maximize();*/
//                } else {
//                    //Firefox linux connection here
//                }
//            }
//
//            return true;
//        } catch (Exception ex) {
//            System.out.println(ex);
//            LogCapture.info("Webdriver not found..." + ex);
//            takeSnapShot();
//            LogCapture.info("Snapshot Captured..");
//            return false;
//        }
        return false;
    }
    public String fileDownload(String object, String data) throws Exception {
        try {
            Screen src = new Screen();
            Pattern fileInputTextBox = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "filedownload.png");
            LogCapture.info(String.valueOf(fileInputTextBox));
            src.type(Key.BACKSPACE);
            // src.type(fileInputTextBox,System.getProperty("user.dir") +File.separator+ "DownloadedFiles"+File.separator+data);
            src.type(fileInputTextBox, data);

            Pattern saveButton = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "save.png");
            LogCapture.info(String.valueOf(saveButton));
            src.click(saveButton);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String fileDownloadOperations(String object, String data) {
        File file = new File("C:"+ File.separator +"Users"+ File.separator +"Kshitija.Rangdale"+ File.separator +"Downloads"+File.separator+data);
        try {
            if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                if (file.exists())
                    System.out.println("File Exists on given path : " + data);
                else
                    System.out.println("File Does not Exists on given path");
            }
            else if (object.equalsIgnoreCase("deleteDownloadedFile")) {
                if (file.delete())
                    System.out.println("File deleted : " +  data);
                else
                    System.out.println("File was not deleted");
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


}
