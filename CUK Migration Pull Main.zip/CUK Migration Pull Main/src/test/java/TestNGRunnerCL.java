import com.selenium.utillity.TestNGCucumberExecutable;
import cucumber.api.CucumberOptions;

import com.selenium.utillity.TestNGCucumberExecutable;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = {"src/Feature"},
        glue = {"com.cucumber.stepdefinition"}
        /*      format = {"pretty",
                      "html:target/site/cucumber-pretty","json:target/cucumber-reports/cucumber.json"*/
        ,



        tags = {"@TC4_Titan_CDEU_PFX_REG_Customers,@TC3_Titan_CDEU_PFX_REG_Customers,@TC12_Titan_CDEU_PFX_REG_Customers,@TC63_Titan_CDEU_PFX_REG_Customers,@TC6_Titan_CDEU_PFX_REG_Customers,@TC9_Titan_CDEU_PFX_REG_Customers,@TC10_Titan_CDEU_PFX_REG_Customers,@TC13_Titan_CDEU_PFX_REG_Customers,@TC15_Titan_CDEU_PFX_REG_Customers,@TC16_Titan_CDEU_PFX_REG_Customers,@TC20_Titan_CDEU_PFX_REG_Customers,@TC11_Titan_CDEU_PFX_REG_Customers"},



        plugin = {"pretty", "html:target/site/cucumber-pretty", "json:target/cucumber-reports/cucumber.json", "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/ExtentReport.html"},
        //plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/Extentreport.html", "json:target/cucumber-reports/cucumber.json"},
        monochrome = true)
//AbstractTestNGCucumberTests
public class TestNGRunnerCL extends TestNGCucumberExecutable {

}