package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.service.utillity.*;
import com.service.utillity.Currency;
import com.utility.LogCapture;
import groovy.json.JsonException;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static com.selenium.utillity.Constants.JenkinsEnvironment;
import static com.service.utillity.ReusableMethod.softAssert;


@Slf4j
public class CommonStep {

    private double preAuthBillAmt;
    private Map<String, String> CCY_Flag;

    public GPSGetTxnReqDetails setAuthorisationReqDetails(String publicToken, String currencyCode, double transactionAmount) {
        GPSGetTxnReqDetails authorisationDetails = new GPSGetTxnReqDetails();
        authorisationDetails.setToken(publicToken);
        authorisationDetails.setBill_Ccy(currencyCode);
        authorisationDetails.setTxn_CCy(currencyCode);
        authorisationDetails.setBill_Amt(transactionAmount);
        authorisationDetails.setTxn_Amt(transactionAmount);
        authorisationDetails.setSettle_Amt(transactionAmount);
        authorisationDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
        authorisationDetails.setMatching_Txn_ID("");
        authorisationDetails.setTrans_link(ReusableMethod.getCurrentTimestamp() + "0000");
        String bnetId = "BNET-" + ReusableMethod.getCurrentDate() + "-MC " + ReusableMethod.getCurrentTime();
        authorisationDetails.setTraceid_lifecycle(bnetId);
        authorisationDetails.setTraceid_Message(bnetId);

        authorisationDetails.setSettle_Ccy(currencyCode);
        authorisationDetails.setTxn_Ctry("GBR");

        authorisationDetails.setTxn_GPS_Date(ReusableMethod.getCurrentGPSTxnDateTime());
        authorisationDetails.setSettlement_Date(ReusableMethod.getCurrentISO_DATE());
        authorisationDetails.setClearing_Process_Date(ReusableMethod.getCurrentISO_DATE());
        authorisationDetails.setPOS_Date_DE13(ReusableMethod.getCurrentDate());
        return authorisationDetails;
    }


    public GPSGetTxnReqDetails setAuthReqDetails(String publicToken) {
        GPSGetTxnReqDetails authorisationDetails = new GPSGetTxnReqDetails();
        authorisationDetails.setToken(publicToken);
        authorisationDetails.setMatching_Txn_ID("");
        authorisationDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
        authorisationDetails.setTrans_link(ReusableMethod.getCurrentTimestamp() + "0000");
        String bnetId = "BNET-" + ReusableMethod.getCurrentDate() + "-AUTO" + ReusableMethod.getCurrentTime();
        authorisationDetails.setTraceid_lifecycle(bnetId);
        authorisationDetails.setTraceid_Message(bnetId);

        authorisationDetails.setTxn_GPS_Date(ReusableMethod.getCurrentGPSTxnDateTime());
        authorisationDetails.setPOS_Date_DE13(ReusableMethod.getCurrentDate());
        return authorisationDetails;
    }

    public GPSGetTxnReqDetails setAuthReqDetails() {
        GPSGetTxnReqDetails authorisationDetails = new GPSGetTxnReqDetails();
        authorisationDetails.setMatching_Txn_ID("");
        authorisationDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
        authorisationDetails.setTrans_link(ReusableMethod.getCurrentTimestamp() + "0000");
        String bnetId = "BNET-" + ReusableMethod.getCurrentDate() + "-AUTO" + ReusableMethod.getCurrentTime();
        authorisationDetails.setTraceid_lifecycle(bnetId);
        authorisationDetails.setTraceid_Message(bnetId);

        authorisationDetails.setTxn_GPS_Date(ReusableMethod.getCurrentGPSTxnDateTime());
        authorisationDetails.setPOS_Date_DE13(ReusableMethod.getCurrentDate());
        return authorisationDetails;
    }

    public GPSGetTxnReqDetails setDeclinedAuthReqDetails(String publicToken, String declineCode) {
        GPSGetTxnReqDetails authorisationDetails = new GPSGetTxnReqDetails();
        authorisationDetails.setToken(publicToken);
        authorisationDetails.setResp_Code_DE39(declineCode);
        authorisationDetails.setMatching_Txn_ID("");
        authorisationDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
        authorisationDetails.setTrans_link(ReusableMethod.getCurrentTimestamp() + "0000");
        String bnetId = "BNET-" + ReusableMethod.getCurrentDate() + "-AUTO " + ReusableMethod.getCurrentTime();
        authorisationDetails.setTraceid_lifecycle(bnetId);
        authorisationDetails.setTraceid_Message(bnetId);

        authorisationDetails.setTxn_GPS_Date(ReusableMethod.getCurrentGPSTxnDateTime());
        authorisationDetails.setPOS_Date_DE13(ReusableMethod.getCurrentDate());
        return authorisationDetails;
    }

    public GPSGetTxnReqDetails setAuthReqDetails(String publicToken, CustomerDetails customerDetails) {
        GPSGetTxnReqDetails authorisationDetails = new GPSGetTxnReqDetails();
        authorisationDetails.setToken(publicToken);
        authorisationDetails.setMatching_Txn_ID("");
        authorisationDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
        authorisationDetails.setTrans_link(ReusableMethod.getCurrentTimestamp() + "0000");
        String bnetId = "BNET-" + ReusableMethod.getCurrentDate() + "-AUTO" + ReusableMethod.getCurrentTime();
        authorisationDetails.setTraceid_lifecycle(bnetId);
        authorisationDetails.setTraceid_Message(bnetId);

        authorisationDetails.setTxn_GPS_Date(ReusableMethod.getCurrentGPSTxnDateTime());
        authorisationDetails.setPOS_Date_DE13(ReusableMethod.getCurrentDate());
        authorisationDetails.setPaymentToken_id(customerDetails.getPaymentTokenId());
        authorisationDetails.setPaymentToken_wallet(customerDetails.getPaymentWallet());
        return authorisationDetails;
    }

    public void setPaymentTokenDetails(GPSGetTxnReqDetails gpsGetTxnReqDetails, TransactionType transactionType, String wallet, String creatorStatus) {
        gpsGetTxnReqDetails.setPaymentToken_id(ReusableMethod.getCurrentTimestamp().substring(7, 16));
        gpsGetTxnReqDetails.setPaymentToken_wallet(wallet);
        gpsGetTxnReqDetails.setProc_Code(transactionType);
        gpsGetTxnReqDetails.setResp_Code_DE39(transactionType);
        gpsGetTxnReqDetails.setPaymentToken_creatorStatus(creatorStatus);
    }

    public void setIncAuthReqDetails(GPSGetTxnReqDetails incAuthReqDetails) {
        incAuthReqDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
        incAuthReqDetails.setTxn_GPS_Date(ReusableMethod.getCurrentGPSTxnDateTime());
        incAuthReqDetails.setPOS_Date_DE13(ReusableMethod.getCurrentDate());
    }

    public void setPresentmentReqDetails(GPSGetTxnReqDetails authReqDetails, String authTxn_ID) {
        // we are overriding auth req details over here, in future we might need not to
        //First we need to save previous Txn_ID and then assign a new value to it
        if(authTxn_ID == null) {
            authReqDetails.setMatching_Txn_ID(authReqDetails.getTXn_ID());
        } else {
            authReqDetails.setMatching_Txn_ID(authTxn_ID);
        }
        authReqDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
        authReqDetails.setSettlement_Date(ReusableMethod.getCurrentISO_DATE());
        authReqDetails.setClearing_Process_Date(ReusableMethod.getCurrentISO_DATE());
    }

    public void setOfflinePresentmentReqDetails(GPSGetTxnReqDetails authReqDetails) {
        // we are overriding auth req details over here, in future we might need not to
        //First we need to save previous Txn_ID and then assign a new value to it
        authReqDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
        authReqDetails.setSettlement_Date(ReusableMethod.getCurrentISO_DATE());
        authReqDetails.setClearing_Process_Date(ReusableMethod.getCurrentISO_DATE());
    }

    public void setReversalReqDetails(GPSGetTxnReqDetails authReqDetails) {
        // we are overriding auth req details over here, in future we might need not to
        authReqDetails.setTXn_ID(ReusableMethod.getCurrentTimestamp());
    }

    public void saveAmtDetails(String authRequestBody, GPSGetTxnReqDetails authReqDetails) {
        // saving auth_type for future use
        authReqDetails.setAuth_type(ReusableMethod.getXpathValue(authRequestBody, "//auth_type"));
        authReqDetails.setTxn_Amt(Double.parseDouble(ReusableMethod.getXpathValue(authRequestBody, "//Txn_Amt")));
        authReqDetails.setTxn_CCy(ReusableMethod.getXpathValue(authRequestBody, "//Txn_CCy"));
        authReqDetails.setBill_Amt(Double.parseDouble(ReusableMethod.getXpathValue(authRequestBody, "//Bill_Amt")));
        authReqDetails.setBill_Ccy(ReusableMethod.getXpathValue(authRequestBody, "//Bill_Ccy"));
        String Settle_Amt = ReusableMethod.getXpathValue(authRequestBody, "//Settle_Amt");
        if(Settle_Amt != null && !Settle_Amt.contains("0.00")) {
            authReqDetails.setSettle_Amt(Double.parseDouble(Settle_Amt));
            authReqDetails.setSettle_Ccy(ReusableMethod.getXpathValue(authRequestBody, "//Settle_Ccy"));
        }
    }

    public void saveCustRef(String authRequestBody, CustomerDetails customerDetails) {
        String custRef = ReusableMethod.getXpathValue(authRequestBody, "//Cust_Ref");
        customerDetails.setCustRef(custRef);
    }

    public double getAtmFee(Currency txnCurrency, Currency billCcy) {
        double fee = 0.0;
        if(isSupportedCcy(txnCurrency)) {
            switch (txnCurrency) {
                case EUR:
                    fee = 1.2;
                    break;
                case AUD:
                    fee = 1.90;
                    break;
                case USD:
                    fee = 1.40;
                    break;
                case HKD:
                    fee = 9.9;
                    break;
                case AED:
                    fee = 4.6;
                    break;
                case CAD:
                    fee = 1.7;
                    break;
                case CHF:
                    fee = 1.1;
                    break;
                case CZK:
                    fee = 28;
                    break;
                case DKK:
                    fee = 8.7;
                    break;
                case ILS:
                    fee = 4.8;
                    break;
                case INR:
                    fee = 104;
                    break;
                case JPY:
                    fee = 184;
                    break;
                case NOK:
                    fee = 13.5;
                    break;
                case PLN:
                    fee = 5.2;
                    break;
                case SAR:
                    fee = 4.7;
                    break;
                case SEK:
                    fee = 13.9;
                    break;
                case SGD:
                    fee = 1.7;
                    break;
                case THB:
                    fee = 44;
                    break;
                case ZAR:
                    fee = 23.5;
                    break;
                case NZD:
                    fee=2.1;
                    break;
                default:
                    fee = 1.00;
            }
        } else {
            switch (billCcy) {
                case GBP:
                    fee = 1.00;
                    break;
                case EUR:
                    fee = 1.20;
            }
        }
        return fee;
    }

    public Currency getAtmFeeCcy(Currency baseCcy, Currency txnCcy) {
        if(isSupportedCcy(txnCcy)) {
            return txnCcy;
        } else {
            return baseCcy;
        }
    }

    public boolean isSupportedCcy(Currency currency) {

       if(CCY_Flag == null)
        CCY_Flag= ReusableMethod.getSqlQueryForKeyValueResult("CPAuthProcessor.SupportedCCYFlag.Query");
        try {
            if (CCY_Flag.get(currency.name()).equals("0"))
                return false;
            else
                return true;
        }catch(NullPointerException e){
            return false;
        }
    }

    public double getCrossBorderFee(double txnAmt) {
        return ReusableMethod.formatDecimalFee(Math.abs(txnAmt * 0.02));
    }

    /**
     * This method is used to calculate the bill amt when authorisation is performed.
     * It takes care of bill amt calculation in case of the Pre-Auth and Final-Auth requests
     * @param transactionType
     * @param authReqDetails
     * @return
     */
    public double getExpectedBillAmtApproved(TransactionType transactionType, GPSGetTxnReqDetails authReqDetails) {
        double billAmt = ReusableMethod.roundUpDecimals(calculateTotalAmount(transactionType, authReqDetails));
        if (Math.abs(preAuthBillAmt) > 0.00 && authReqDetails.getAuth_type().equals("F")) {
            billAmt = Math.abs(billAmt) - Math.abs(preAuthBillAmt);
        }
        return -Math.abs(billAmt);
    }

    /**
     * This method should be called to get bill amt in Presentment/Clearing
     * @param transactionType
     * @param authReqDetails
     * @return
     */
    public double getAmountToDebit(TransactionType transactionType, GPSGetTxnReqDetails authReqDetails) {
        return ReusableMethod.roundUpDecimals(Math.abs(calculateTotalAmount(transactionType, authReqDetails)));
    }

    public double getRequestedAmt(TransactionType transactionType, GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        double finalAmt = 0.0;
        switch (transactionType) {
            case REFUND:
                if(gpsGetTxnReqDetails.getTxnCurrency() != gpsGetTxnReqDetails.getBillCurrency()) {
                    finalAmt = gpsGetTxnReqDetails.getTxn_Amt();
                } else {
                    finalAmt = gpsGetTxnReqDetails.getBill_Amt();
                }
                break;
            default:
                finalAmt = calculateBillAmount(gpsGetTxnReqDetails);
        }
        return ReusableMethod.roundUp(finalAmt, 2).doubleValue();
    }

    public Currency getAmountToDebitCcy(GPSGetTxnReqDetails authReqDetails) {
        if(isSupportedCcy(authReqDetails.getTxnCurrency())) {
            return authReqDetails.getTxnCurrency();
        } else {
            return authReqDetails.getBillCurrency();
        }
    }

    private double calculateTotalAmount(TransactionType transactionType, GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        double finalAmt;
        switch (transactionType) {
            case ATM_CASH_WITHDRAWAL:
                finalAmt = calculateBillAmount(gpsGetTxnReqDetails) + getAtmFee(gpsGetTxnReqDetails.getTxnCurrency(), gpsGetTxnReqDetails.getBillCurrency());
                break;
            case REFUND:
                if(gpsGetTxnReqDetails.getTxnCurrency() != gpsGetTxnReqDetails.getBillCurrency()) {
                    finalAmt = gpsGetTxnReqDetails.getTxn_Amt();
                } else {
                    finalAmt = gpsGetTxnReqDetails.getBill_Amt();
                }
                break;
            default:
                finalAmt = calculateBillAmount(gpsGetTxnReqDetails);
        }
        return finalAmt;
    }

    public double calculateBillAmount(GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        double txnAmt = gpsGetTxnReqDetails.getTxn_Amt();
        double billAmt = Math.abs(gpsGetTxnReqDetails.getBill_Amt());
        double result;

        if(isSupportedCcy(gpsGetTxnReqDetails.getTxnCurrency())){
            result = txnAmt;
        }else{
            result = (billAmt + getCrossBorderFee(billAmt));
        }
        return result;
    }

    public String getBillAmtCurrency(GPSGetTxnReqDetails authReqDetails) {

        if(isSupportedCcy(authReqDetails.getTxnCurrency())){
            return authReqDetails.getTxnCurrency().name();
        }else{
            return authReqDetails.getBillCurrency().name();
        }
    }

    public void setPreAuthBillAmt(GPSGetTxnReqDetails authReqDetails) {
        preAuthBillAmt = calculateBillAmount(authReqDetails);
    }


    public void updateRequestBodyFromConfig(Map<String, String> testDataRow) {
        String updateBodyFromConfig = testDataRow.get("UpdateBodyFromConfig");

        String body = testDataRow.get("Body");
        String updatedBody = body;
        if (ReusableMethod.isNotNA(updateBodyFromConfig)) {
            String[] configParams = updateBodyFromConfig.split("\\|");
            for (String param : configParams) {
                updatedBody = updatedBody.replace(param, Constants.CONFIG.getProperty(param));
            }
            //String updatedBody = String.format(testDataRows.get(rowNumber-1).get("Body"), customerDetails.getCustRef(), customerDetails.getBaseCurrency().name());
            testDataRow.put("Body", updatedBody);
        }
    }

    /**
     * This method performs SQL query as per data specified on Excel row and modify the request body in testDataRow
     * (No need to return query result)
     * @param testDataRow
     * @return
     */

    public Map<String, String> prepareRequestUsingQuery(Map<String, String> testDataRow) {
        String Execution = testDataRow.get("Execution");
        Constants.TCCaseID = testDataRow.get("Test Case ID");
        Map<String, String> queryResult = null;
        if (Execution.equalsIgnoreCase("Y")) {
//            ReusableMethod.createReportParameters(Constants.TCCaseID);
            String HeaderFromExcel = testDataRow.get("Headers");
            String body = testDataRow.get("Body");
            String queryPath = testDataRow.get("Query Path");
            String queryParams = testDataRow.get("Query Parameter");
            Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
            Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
            String httpMethod = testDataRow.get("Http Method");
            String sqlQuery = testDataRow.get("Query");
            RestAssured.baseURI = testDataRow.get("Base URI");
            String updateBody = testDataRow.get("UpdateBody");
            String SaveFromResponse = testDataRow.get("SaveFromResponse");


            // Fetch SQL query from SQL config file
            if (ReusableMethod.isNotNA(sqlQuery)) {
                //String sqlQueryInfo = ConfigManager.getSqlQueryConfig(sqlQuery);
                //sqlQueryInfo = Objects.isNull(sqlQueryInfo) ? sqlQuery : sqlQueryInfo;

                String[] arrSqlQueryInfo = sqlQuery.split("\\|");
                queryResult = ReusableMethod.executeQuery(arrSqlQueryInfo[0] + JenkinsEnvironment, arrSqlQueryInfo[1]);
                if (Objects.nonNull(queryResult) && !queryResult.isEmpty()) {
                    String[] updateBodyParams = updateBody.split("\\|");
                    for (String param : updateBodyParams) {
                        if (httpMethod.equalsIgnoreCase("POST")) {
                            body = body.replace("{" + param + "}", queryResult.get(param));
                            testDataRow.put("Body", body);
                        } else {
                            queryPath = queryPath.replace("{" + param + "}", queryResult.get(param));
                            testDataRow.put("Query Path", queryPath);
                        }
                    }
                } else {
                    LogCapture.error("Could not find query result for query " + arrSqlQueryInfo[1]);
                }
            }
        }
        return queryResult;
    }

    public void updateGetRequest(Map<String, String> testDataRow, Map<String, String> queryResult) {
        String Execution = testDataRow.get("Execution");
        Constants.TCCaseID = testDataRow.get("Test Case ID");
        if (Execution.equalsIgnoreCase("Y")) {
            String queryPath = testDataRow.get("Query Path");
            RestAssured.baseURI = testDataRow.get("Base URI");
            String updateBody = testDataRow.get("UpdateBody");

            if(ReusableMethod.isNotNA(updateBody)) {
                for (String key : queryResult.keySet()) {
                    if(queryPath.contains("{" + key + "}"))
                        queryPath = queryPath.replace("{" + key + "}", queryResult.get(key));
                }
                testDataRow.put("Query Path", queryPath);
            }
        }
    }

    public Map<String, String> updateCalculatePreTxnRateReqBody(Map<String, String> testDataRow, CustomerDetails customerDetails, Currency txnCcy, double txnAmt) {
        String body = testDataRow.get("Body");
        body = body.replace("{titanAccountId}", customerDetails.getContactId())
                .replace("{transactionCurrency}", txnCcy.name())
                .replace("{transactionAmount}", String.valueOf(txnAmt))
                .replace("{cardholderBillingCurrency}", customerDetails.getBaseCurrency().name())
                .replace("{countryCode}", customerDetails.getCountryCode())
                .replace("{pricePlanId}", String.valueOf(customerDetails.getPricePlanId()))
                .replace("{conversionDate}", ReusableMethod.getCurrentISO_DATE());
        if(customerDetails.getBaseCurrency() == TitanCurrency.GBP) {
            body = body.replace("{legalEntity}", "CDLGB");
        } else {
            body = body.replace("{legalEntity}", "CDLEU");
        }
        testDataRow.put("Body", body);
        JsonPath jsonRequest = ReusableMethod.rawToJson(body);
        return jsonRequest.getMap("$", String.class, String.class);
    }

    public Map<String, String> updateStipBalReqBody(CustomerDetails customerDetails, Map<String, String> testDataRow) {
        Map<String, String> expectedDetails = new HashMap<>();
        String body = testDataRow.get("Body");
        double actualBalance = ThreadLocalRandom.current().nextDouble(100.00, 1000.00);
        double availableBalance = ThreadLocalRandom.current().nextDouble(95.00, actualBalance - 10);
        body = body.replace("{actualBalance}", String.valueOf(ReusableMethod.formatDecimalAmt(actualBalance)))
                .replace("{availableBalance}", String.valueOf(ReusableMethod.formatDecimalAmt(availableBalance)))
                .replace("{cdCustomerRef}", customerDetails.getCustRef())
                .replace("{currency}", customerDetails.getBaseCurrency().name());
        testDataRow.put("Body", body);
        expectedDetails.put("actualBalance", String.valueOf(ReusableMethod.formatDecimalAmt(actualBalance)));
        expectedDetails.put("availableBalance", String.valueOf(ReusableMethod.formatDecimalAmt(availableBalance)));
        return expectedDetails;
    }

    public Map<String, String> storeFromXmlResponse(Response response, Map<String, String> testDataRow) {
        Map<String, String> responseData = new HashMap<>();
        String saveFromResponse = testDataRow.get("SaveFromXmlResponse");

        // To fetch save data from Response after POST
        if (ReusableMethod.isNotNA(saveFromResponse)) {
            String[] xpaths = saveFromResponse.split("\\n");
            for (String xpath : xpaths) {
                String name = xpath.split("=")[0];
                xpath = xpath.split("=")[1];
                String value = XmlPath.from(response.getBody().asString()).get(xpath);
                responseData.put(name, value);
            }
        }
        return responseData;
    }

    private Map<String, String> getAuditMappings(String mappingFilePath) {
        Properties mappings = ReusableMethod.loadConfig(mappingFilePath);
        List<String> actualFieldName = new ArrayList<>(mappings.stringPropertyNames());
        Map<String, String> resultPaths = new HashMap<>();
        for(String path : actualFieldName) {
            String[] splitedPath = path.split("\\.");
            String pathPrefix = splitedPath[0];
            String auditColName = splitedPath[1].toLowerCase();
            if(pathPrefix.equalsIgnoreCase("MessageHeader")) {
                auditColName = "h" + auditColName;
            }
            resultPaths.put(auditColName, mappings.getProperty(path));
        }
        return resultPaths;
    }

    private Map<String, String> getKafkaMappings(String mappingFilePath) {
        Properties mappings = ReusableMethod.loadConfig(mappingFilePath);
        List<String> actualFieldName = new ArrayList<>(mappings.stringPropertyNames());
        Map<String, String> resultPaths = new HashMap<>();
        for(String path : actualFieldName) {
            resultPaths.put(path, mappings.getProperty(path));
        }
        return resultPaths;
    }

    public void compareJsonAgainstGetTxnMappings(String xmlRequestBody, JsonPath jsonPathObj, String mappingFilePath, boolean isAudit) {
        Map<String, String> fieldMappings;
        if(isAudit) {
            fieldMappings = getAuditMappings(mappingFilePath);
        } else {
            fieldMappings = getKafkaMappings(mappingFilePath);
        }
        String expectedValue; boolean isCompareDouble = false;
        for (String jsonPathStr : fieldMappings.keySet()) {
//            if(jsonPathStr.equals("MessageData.amountToDebit")) { //To debug any mapping property
//                System.out.println();
//            }
//            String fieldNameForReport = mappingFilePath + jsonPathStr;
            String actualValue = jsonPathObj.getString(jsonPathStr);
            actualValue = Objects.isNull(actualValue) || actualValue.equalsIgnoreCase("null") ? "" : actualValue;
            actualValue = ReusableMethod.cleanJsonPathValue(actualValue);

            String expectedMappingPropertyValue = fieldMappings.get(jsonPathStr);
            if (expectedMappingPropertyValue.startsWith("skip")) {
                continue;
            }

            if (expectedMappingPropertyValue.contains("value=")) {
                expectedValue = expectedMappingPropertyValue.split("=")[1];

            } else if (expectedMappingPropertyValue.contains("compareDouble=") || expectedMappingPropertyValue.contains("compareDoubleIgnoreSign=")) {
                String expectedMappingPropertyVal = expectedMappingPropertyValue.split("=")[1];

                expectedValue = ReusableMethod.getXpathValue(xmlRequestBody, "//" + expectedMappingPropertyVal);
                // If no value in XML, then nothing to check //TODO put this as common to all conditions
                if (ReusableMethod.isNotNullOrEmpty(expectedValue)) {
                    if (expectedMappingPropertyValue.contains("compareDoubleIgnoreSign=")) {
                        softAssert.assertEquals(Math.abs(Double.parseDouble(actualValue.trim())), Math.abs(Double.parseDouble(expectedValue)), "Assertion for " + mappingFilePath + " > " + jsonPathStr + " failed");
                    } else {
                        softAssert.assertEquals(Double.parseDouble(actualValue.trim()), Double.parseDouble(expectedValue), "Assertion for " + mappingFilePath + " > " + jsonPathStr + " failed");
                    }

                } else {
                    softAssert.assertTrue( ReusableMethod.isNullOrEmpty(actualValue) || actualValue.equals("0.0"), "Assertion for " + mappingFilePath + " > " + jsonPathStr + " failed");
                    //LogCapture.warn("No value found in XML for " + expectedMappingPropertyVal);
                }
                continue;
            } else if (expectedMappingPropertyValue.contains("concatenateXpathValues=")) {
                String allXpaths = expectedMappingPropertyValue.split("=")[1];
                String valueFromXML = "";
                // multiple Xpath values
                String[] xpaths = allXpaths.split(" ");
                for (String xpath : xpaths) {
                    String subString = ReusableMethod.getXpathValue(xmlRequestBody, "//" + xpath);
                    if(!subString.isEmpty())
                        valueFromXML = String.join(" ", valueFromXML, subString);
                }
                expectedValue = valueFromXML;

            } else if (expectedMappingPropertyValue.contains("method=")) { //compareDouble & method=addtnl_amt|Additional_Amt_DE54
                String[] propValues = expectedMappingPropertyValue.split("&");
                if(propValues.length > 1 && propValues[0].equalsIgnoreCase("compareDouble")) {
                    isCompareDouble = true;
                }
                String methodDetails = propValues[propValues.length - 1].split("=")[1];
                String methodName = methodDetails.split("\\|")[0];
                String methodArg = methodDetails.split("\\|")[1];
                String valueFromXML = ReusableMethod.getXpathValue(xmlRequestBody, "//" + methodArg);

                if (ReusableMethod.isNotNullOrEmpty(valueFromXML)) {
                    try {
                        Method method = this.getClass().getDeclaredMethod(methodName, String.class);
                        expectedValue = (String) method.invoke(null, valueFromXML);
                    } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                        LogCapture.error("Validation failed for " + jsonPathStr);
                        throw new RuntimeException(e);
                    }

                } else {
                    softAssert.assertTrue(actualValue.isEmpty(), "No value found in XML for " + methodDetails);
                    continue; // If no value in XML, then nothing to check
                }

            } else if (expectedMappingPropertyValue.contains("checkValueContainsKey")) {
                expectedMappingPropertyValue = expectedMappingPropertyValue.split("=")[1];
                expectedValue = ReusableMethod.getXpathValue(xmlRequestBody, "//" + expectedMappingPropertyValue);
                softAssert.assertTrue(expectedValue.trim().contains(actualValue.trim()), "Assertion for " + mappingFilePath + " > " + jsonPathStr + " failed");
                continue;

            } else if (expectedMappingPropertyValue.contains("ignoreSpaces")) {
                expectedMappingPropertyValue = expectedMappingPropertyValue.split("=")[1];
                expectedValue = ReusableMethod.getXpathValue(xmlRequestBody, "//" + expectedMappingPropertyValue).replaceAll(" ", "");
                actualValue = actualValue.replaceAll(" ", "");
            } else {
                expectedValue = ReusableMethod.getXpathValue(xmlRequestBody, "//" + expectedMappingPropertyValue);
            }

            actualValue = Objects.isNull(actualValue) ? "" : actualValue; //make json field value empty if null

            if(isCompareDouble) {
                softAssert.assertEquals(Double.parseDouble(actualValue), Double.parseDouble(expectedValue.trim()), "Assertion for " + mappingFilePath + " > " + jsonPathStr + " failed");
                isCompareDouble = false;
            } else {
                softAssert.assertEquals(actualValue, expectedValue.trim(), "Assertion for " + jsonPathStr + " failed");
            }

        }
    }

//    public void compareTxnDetails(String xmlRequest, Map<String, String> txnDetailsFromDB, String mappingsFilePath) {
//
//        Properties mappings = ConfigManager.getProperties(mappingsFilePath);
//        String valueInDBShouldBe, expectedValueFromXML;
//        Set<String> tableColumns = mappings.stringPropertyNames();
//
//        for (String columnName : tableColumns) {
//            valueInDBShouldBe = Objects.isNull(txnDetailsFromDB.get(columnName)) || txnDetailsFromDB.get(columnName).equalsIgnoreCase("null") ? "" : txnDetailsFromDB.get(columnName);
//            String xmlFieldName = mappings.getProperty(columnName);
//
//            if (xmlFieldName.equalsIgnoreCase("skip")) {
//                continue;
//            }
//
//            if (xmlFieldName.contains("value=")) {
//                expectedValueFromXML = xmlFieldName.split("=")[1];
//
//            } else if (xmlFieldName.contains("compareDouble")) {
//                xmlFieldName = xmlFieldName.split("=")[1];
//
//                expectedValueFromXML = ReusableMethod.getXpathValue(xmlRequest, "//" + xmlFieldName);
//                // If no value in XML, then nothing to check
//                if(ReusableMethod.isNotNullOrEmpty(expectedValueFromXML)) {
//                    softAssert.assertEquals(Double.parseDouble(valueInDBShouldBe.trim()), Double.parseDouble(expectedValueFromXML), "Assertion for " + columnName + " failed");
//                } else {
//                    softAssert.assertTrue(valueInDBShouldBe.isEmpty(), "No value found in XML for " + xmlFieldName);
//                }
//                continue;
//            } else if (xmlFieldName.contains("method=")) {
//                String methodDetails = xmlFieldName.split("=")[1];
//                String methodName = methodDetails.split("\\|")[0];
//                String methodArg = methodDetails.split("\\|")[1];
//                String valueFromXML = ReusableMethod.getXpathValue(xmlRequest, "//" + methodArg);
//
//                if (ReusableMethod.isNotNullOrEmpty(valueFromXML)) {
//                    try {
//                        Class<CommonStep> classObj = CommonStep.class;
//                        Method method = classObj.getDeclaredMethod(methodName, String.class);
//                        expectedValueFromXML = (String) method.invoke(null, valueFromXML);
//                    } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
//                        throw new RuntimeException(e);
//                    }
//
//                } else {
//                    softAssert.assertTrue(valueInDBShouldBe.isEmpty(), "No value found in XML for " + methodDetails);
//                    continue; // If no value in XML, then nothing to check
//                }
//
//            } else if(xmlFieldName.contains("checkValueContainsKey")) {
//                xmlFieldName = xmlFieldName.split("=")[1];
//                expectedValueFromXML = ReusableMethod.getXpathValue(xmlRequest, "//" + xmlFieldName);
//                softAssert.assertTrue(expectedValueFromXML.trim().contains(valueInDBShouldBe.trim()), "Assertion for " + columnName + " failed");
//                continue;
//
//            /*} else if(xmlFieldName.contains("relaxDateCompare")) {
//                xmlFieldName = xmlFieldName.split("=")[1];
//                expectedValueFromXML = ReusableMethod.getXpathValue(xmlRequest, "//" + xmlFieldName);
//                ReusableMethod.softAssertDateTime(softAssert, valueInDBShouldBe, expectedValueFromXML, 2);
//                continue;*/
//            } else {
//                expectedValueFromXML = ReusableMethod.getXpathValue(xmlRequest, "//" + xmlFieldName);
//            }
//
//            softAssert.assertEquals(valueInDBShouldBe.trim(), expectedValueFromXML.trim(), "Assertion for " + columnName + " failed");
//        }
//    }

    public static String gpsDecisionCodeDescription(String Resp_Code_DE39) {
        String result = null;
        if(Resp_Code_DE39 == null || Resp_Code_DE39.isEmpty()) {
            result = "";
        } else if (Resp_Code_DE39.equals("00")) {
            result = "Approved";
        }
        return result;
    }

    public void compareDouble(String xmlRequest, String xmlFieldName, String actualValue, String fieldNameForReport) {
        xmlFieldName = xmlFieldName.split("=")[1];

        String expectedValueFromXML = ReusableMethod.getXpathValue(xmlRequest, "//" + xmlFieldName);
        // If no value in XML, then nothing to check
        if(ReusableMethod.isNotNullOrEmpty(expectedValueFromXML)) {
            softAssert.assertEquals(Double.parseDouble(actualValue.trim()), Double.parseDouble(expectedValueFromXML), "Assertion for " + fieldNameForReport + " failed");
        } else {
            softAssert.assertTrue(actualValue.isEmpty(), "No value found in XML for " + xmlFieldName);
        }
    }

    public static String toISO_InstantFormat(String dateTime) {
        return dateTime.replace(" ", "T") + "Z";
    }

    public static String queryContactId(String Token) {
        Map<String, String> cardDetails = ReusableMethod.getSqlQueryResult("CPCardAdmin.CardDetails.UsingToken.Query", Token);
        return cardDetails.get("contact_id");
    }
    public static String addtnl_amt_type(String additional_Amt_DE54) {
        return additional_Amt_DE54.substring(2,4);
    }

    public static Currency addtnlAmtCcy(String additional_Amt_DE54) {
        String currencyCode = additional_Amt_DE54.substring(4,7);
        return Currency.getCurrency(currencyCode);
    }

    public static String addtnl_amt_ccy(String additional_Amt_DE54) {
        String currencyCode = additional_Amt_DE54.substring(4,7);
        return Currency.getCurrency(currencyCode).name();
    }

    public void ValidateAddtnl_Amt_DE54(GPSGetTxnReqDetails gpsGetTxnReqDetails , List<String> addtnl_amt_de54, String txnType) {
        BigDecimal expected_addtnl_amt;
        String Titan_Req = "",proc_code="";
        Map<String, String> txnDetailsFromDB = null;
        Map<String, String> txnDetailsFromDB_Titan = null;

//        proc_code = gpsGetTxnReqDetails.getProc_Code().substring(0,2);
        proc_code = ReusableMethod.getXpathValue(Constants.testDataRows.get(CommonStepDefinitionCards.testDataRow).get("Body"), "//Proc_Code").substring(0,2);

        if(txnType.equalsIgnoreCase("AUTHORISATION")) {
            txnDetailsFromDB = ReusableMethod.getSqlQueryResult("CPAuthProcessor.TransactionRequest", gpsGetTxnReqDetails.getTXn_ID());
            switch(txnDetailsFromDB.get("txn_type")){
                case "AUTHORISATION_ADVICE":
                    Titan_Req= "BLOCK";
                    break;
                case "AUTHORISATION_REQUEST":
                    Titan_Req= "CHECK_AND_BLOCK";
                    break;
                default:
            }
            txnDetailsFromDB_Titan = ReusableMethod.getSqlQueryResult("TitanDB.CardTransactionMonitoringData.Query", gpsGetTxnReqDetails.getTraceid_lifecycle(),Titan_Req);
        }else if(txnType.equalsIgnoreCase("PRESENTMENT")) {
            Titan_Req= "UNBLOCK_AND_DEBIT";
            txnDetailsFromDB = ReusableMethod.getSqlQueryResult("CPClearingProcessor.TransactionRequest", gpsGetTxnReqDetails.getTXn_ID());
            txnDetailsFromDB_Titan = ReusableMethod.getSqlQueryResult("TitanDB.CardTransactionMonitoringData.Query", gpsGetTxnReqDetails.getTraceid_lifecycle(),Titan_Req);
        }

        if (proc_code.equals("09")) {
            boolean found = false;

            for(String s : addtnl_amt_de54) {
                if (addtnl_amt_type(s).equals("40") && addtnlAmtCcy(s).equals(Currency.getCurrency(gpsGetTxnReqDetails.getTxn_CCy())) ) {
                    expected_addtnl_amt = addtnl_amt_double(s);
                    Assert.assertEquals(txnDetailsFromDB.get("addtnl_amt"), expected_addtnl_amt.toString(), "Additional Amount is not matching in CARD DB");
                    if(txnType.equalsIgnoreCase("AUTHORISATION"))
                        Assert.assertEquals(Double.parseDouble(txnDetailsFromDB_Titan.get("AdditionalAmount")), expected_addtnl_amt.doubleValue(), "Additional Amount is not matching in Titan DB");
                    found = true;
                    break;
                }
            }
            if(!found) {
                for (String s : addtnl_amt_de54) {
                    if (addtnl_amt_type(s).equals("40")) {
                        expected_addtnl_amt = addtnl_amt_double(s);
                        Assert.assertEquals(txnDetailsFromDB.get("addtnl_amt"),expected_addtnl_amt.toString(),  "Additional Amount is not matching in CARD DB");
                        if (txnType.equalsIgnoreCase("AUTHORISATION"))
                            Assert.assertEquals(Double.parseDouble(txnDetailsFromDB_Titan.get("AdditionalAmount")), expected_addtnl_amt.doubleValue(), "Additional Amount is not matching in Titan DB");
                        found = true;
                        break;
                    }
                }
            }
            if(!found) {
                Assert.assertEquals(txnDetailsFromDB.get("addtnl_amt"),addtnl_amt_double(addtnl_amt_de54.get(0)).toString(),  "Additional Amount is not matching in CARD DB");
                Assert.assertNull(txnDetailsFromDB_Titan.get("AdditionalAmount"), "Additional Amount is not NULL in Titan DB");
            }
        } else {
            Assert.assertEquals(  txnDetailsFromDB.get("addtnl_amt"),addtnl_amt_double(addtnl_amt_de54.get(0)).toString(),"Additional Amount is not matching in Card DB");
            Assert.assertNull(txnDetailsFromDB_Titan.get("AdditionalAmount"), "Additional Amount is not NULL in Titan DB");
        }
    }

    public static BigDecimal addtnl_amt_double(String additional_Amt_DE54) {
        String amountValue = additional_Amt_DE54.substring(8,20);
        int amt = Integer.parseInt(amountValue);
        BigDecimal expected_addtnl_amt = ReusableMethod.roundUp(amt / (Math.pow(10,addtnlAmtCcy(additional_Amt_DE54).getExponent())), 2);
        return expected_addtnl_amt;
    }

    public static String addtnl_amt(String additional_Amt_DE54) {
        String amountValue = additional_Amt_DE54.substring(8,20);
        int amt = Integer.parseInt(amountValue);
        BigDecimal expected_addtnl_amt = ReusableMethod.roundUp(amt / (Math.pow(10,addtnlAmtCcy(additional_Amt_DE54).getExponent())), 2);
        return String.valueOf(expected_addtnl_amt);
    }

    public static String AuthenticationMethod(String GPS_POS_Data) {
        return String.valueOf(GPS_POS_Data.charAt(3));
    }

    public static String CardPresentInd(String GPS_POS_Data) {
        return String.valueOf(GPS_POS_Data.charAt(1));
    }

    public static String CardInputMode(String GPS_POS_Data) {
        return String.valueOf(GPS_POS_Data.charAt(2));
    }

    public static String CardInputModeDesc(String GPS_POS_Data) {
        switch (GPS_POS_Data.charAt(2)) {
            case '0':
                return "Information not provided";
            case '1':
                return "Manual, no terminal";
            case '2':
                return "Magnetic stripe read";
            case '3':
                return "Bar code";
            case '4':
                return "Optical Character Recognition";
            case '5':
                return "Chip dip (i.e. EMV contact)";
            case '6':
                return  "Key entered / added manually";
            case '7':
                return  "EMV contactless or VSDC contactless";
            case 'V':
                return "E-Commerce";
            case 'C':
                return  "E-Commerce with EMV cryptogram";
            case 'E':
                return  "Contactless magnetic stripe";
            case 'F':
                return  "Account Data on File";
            case 'G':
                return "Key entered by Acquirer (merchant phoned acquirer with card data)";
            case 'M':
                return "MICR reader";
            case 'Q':
                return "QR code";
        }
        return null;
    }

    public static String CardPresentDescription(String GPS_POS_Data) {
        switch (GPS_POS_Data.charAt(1)) {
            case '0':
                return "Card not present";
            case '1':
                return "Card present";
            case '9':
                return "Unknown";
        }
        return null;
    }

    public static String toCurrencyCode(String ccyCode) {
        return Currency.getCurrency(ccyCode).name();
    }

    public static String toTitanCurrencyCode(String ccyCode) {
        int id = Currency.getCurrency(ccyCode).toTitanCurrency().getId();
        return String.valueOf(id);
    }

    public static String BillAmountApprove() {
        return null;
    }

    public static String RequestedCurrency() {
        return null;
    }

    public static String RequestedAmount() {
        return null;
    }

    public static String AuthMethod(String GPS_POS_Data) {
        switch (GPS_POS_Data.charAt(2)) {
            case '5': return "Chip and PIN";
            case '7': return "Contactless";
            case 'V': return "Online transaction";
            default: return null;
        }
    }

    public static String toCreditOrDebit(String anyAmt) {
        if(Double.parseDouble(anyAmt) > 0) {
            return "Credit";
        } else {
            return "Debit";
        }
    }

    private void verifyTitanRequestForOfflineAndPOS(Map<String, String> actualDetails, GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        JsonPath requestJsonPath = new JsonPath(actualDetails.get("request_json"));
        double amountToDebitAmt = ReusableMethod.formatDecimalAmt(Double.parseDouble(requestJsonPath.getString("amountToDebit.amount")));
        String amountToDebitCcy = requestJsonPath.getString("amountToDebit.currency");
        softAssert.assertEquals(amountToDebitAmt, getAmountToDebit(TransactionType.POS, gpsGetTxnReqDetails), "Titan Outbox Table > amountToDebit.amount is not as expected");

         if(isSupportedCcy(gpsGetTxnReqDetails.getTxnCurrency())){
             softAssert.assertEquals(amountToDebitCcy, gpsGetTxnReqDetails.getTxnCurrency().name(), "Titan Outbox Table > amountToDebit.currency is not as expected");
         }else{
             softAssert.assertEquals(amountToDebitCcy, gpsGetTxnReqDetails.getBillCurrency().name(), "Titan Outbox Table > amountToDebit.currency is not as expected");
         }
        softAssert.assertEquals(requestJsonPath.getString("txnCategory"), "Spent", "Titan Outbox Table > txnCategory is not as expected");
    }

    public void verifyTitanRequestForOffline(Map<String, String> actualDetails, GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        verifyTitanRequestForOfflineAndPOS(actualDetails, gpsGetTxnReqDetails);
        softAssert.assertEquals(actualDetails.get("event_type"), "debit");
    }

    public void verifyTitanRequestForPOS(Map<String, String> actualDetails, GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        verifyTitanRequestForOfflineAndPOS(actualDetails, gpsGetTxnReqDetails);
        softAssert.assertEquals(actualDetails.get("event_type"), "fullUnblockAndDebit");
    }


    public void verifyTitanRequestForPartialUnblockAndDebit(Map<String, String> actualDetails, GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        verifyTitanRequestForOfflineAndPOS(actualDetails, gpsGetTxnReqDetails);
        softAssert.assertEquals(actualDetails.get("event_type"), "partialUnblockAndDebit");
    }

    public void verifyTitanRequestForATM(Map<String, String> actualDetails, GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        JsonPath requestJsonPath = new JsonPath(actualDetails.get("request_json"));
        double amountToDebitAmt = Double.parseDouble(requestJsonPath.getString("amountToDebit.amount"));
        String amountToDebitCcy = requestJsonPath.getString("amountToDebit.currency");
        softAssert.assertEquals(ReusableMethod.roundUpDecimals(amountToDebitAmt), getAmountToDebit(TransactionType.ATM_CASH_WITHDRAWAL, gpsGetTxnReqDetails), "Titan Outbox Request > amountToDebit.amount is not as expected");

        String feeType = requestJsonPath.getString("fee[0].type");
        double feeAmt = Double.parseDouble(requestJsonPath.getString("fee[0].amount"));
        String feeCcy = requestJsonPath.getString("fee[0].currency");
        softAssert.assertEquals(feeType, "ATM", "Titan Outbox Table > feeType is not as expected");
        softAssert.assertEquals(feeAmt, getAtmFee(gpsGetTxnReqDetails.getTxnCurrency(), gpsGetTxnReqDetails.getBillCurrency()), "Titan Outbox Request > feeAmt is not as expected");
        softAssert.assertEquals(requestJsonPath.getString("txnCategory"), "Withdrawal", "Titan Outbox Request > txnCategory is not as expected");
        Assert.assertEquals(actualDetails.get("event_type"), "fullUnblockAndDebit", "Titan Outbox Request > event_type is not as expected");

        if(isSupportedCcy(gpsGetTxnReqDetails.getTxnCurrency())){
            softAssert.assertEquals(feeCcy, gpsGetTxnReqDetails.getTxnCurrency().name(), "Titan Outbox Request > feeCcy is not as expected");
            softAssert.assertEquals(amountToDebitCcy, gpsGetTxnReqDetails.getTxnCurrency().name(), "Titan Outbox Request > amountToDebit.currency is not as expected");
        }else{
            softAssert.assertEquals(feeCcy, gpsGetTxnReqDetails.getBillCurrency().name(), "Titan Outbox Request > feeCcy is not as expected");
            softAssert.assertEquals(amountToDebitCcy, gpsGetTxnReqDetails.getBillCurrency().name(), "Titan Outbox Request > amountToDebit.currency is not as expected");
            String feeType1 = requestJsonPath.getString("fee[1].type");
            double feeAmt1 = Double.parseDouble(requestJsonPath.getString("fee[1].amount"));
            String feeCcy1 = requestJsonPath.getString("fee[1].currency");
            softAssert.assertEquals(feeAmt1, getCrossBorderFee(gpsGetTxnReqDetails.getBill_Amt()), "Titan Outbox Request > CROSSBORDER amount is not as expected");
            softAssert.assertEquals(feeCcy1, gpsGetTxnReqDetails.getBillCurrency().name(), "Titan Outbox Request > CROSSBORDER feeCcy is not as expected");
            softAssert.assertEquals(feeType1, "CROSSBORDER", "Titan Outbox Request > CROSSBORDER feeType is not as expected");
        }

    }

    public void verifyTitanRequestForRefund(Map<String, String> actualDetails, GPSGetTxnReqDetails gpsGetTxnReqDetails) {
        JsonPath requestJsonPath = new JsonPath(actualDetails.get("request_json"));
        double amountToCreditAmt = Double.parseDouble(requestJsonPath.getString("amountToCredit.amount"));
        String amountToCreditCcy = requestJsonPath.getString("amountToCredit.currency");
        softAssert.assertEquals(amountToCreditAmt, getAmountToDebit(TransactionType.REFUND, gpsGetTxnReqDetails));

        double billMoneyAmt;
        String billMoneyCcy;
        if(gpsGetTxnReqDetails.getTxnCurrency() != gpsGetTxnReqDetails.getBillCurrency()) {
            billMoneyAmt = Double.parseDouble(requestJsonPath.getString("txnMoney.amount"));
            billMoneyCcy = requestJsonPath.getString("txnMoney.currency");
        }else{
            billMoneyAmt = Double.parseDouble(requestJsonPath.getString("billMoney.amount"));
            billMoneyCcy = requestJsonPath.getString("billMoney.currency");
        }

        softAssert.assertEquals(-billMoneyAmt, getExpectedBillAmtApproved(TransactionType.REFUND, gpsGetTxnReqDetails));
        softAssert.assertEquals(billMoneyCcy, getBillAmtCurrency(gpsGetTxnReqDetails));

        double txnMoneyAmt = ReusableMethod.toFormatedDecimalAmt(requestJsonPath.getString("txnMoney.amount"));
        String txnMoneyCcy = requestJsonPath.getString("txnMoney.currency");
        softAssert.assertEquals(txnMoneyAmt, gpsGetTxnReqDetails.getTxn_Amt(), "txnMoney.amount was not matched");
        softAssert.assertEquals(txnMoneyCcy, Currency.getCurrency(gpsGetTxnReqDetails.getTxn_CCy()).name(), "txnMoney.currency was not matched");

        if (isSupportedCcy(gpsGetTxnReqDetails.getTxnCurrency())) {
            softAssert.assertEquals(amountToCreditCcy, gpsGetTxnReqDetails.getTxnCurrency().name());
        }else{
            softAssert.assertEquals(amountToCreditCcy, gpsGetTxnReqDetails.getBillCurrency().name());
        }

        softAssert.assertEquals(actualDetails.get("event_type").toLowerCase(), "credit");
    }

    public void verifyTitanOutboxCommons(Map<String, String> actualDetails, GPSGetTxnReqDetails gpsGetTxnReqDetails, CustomerDetails customerDetails) {
        //Assert.assertEquals(actualDetails.get("http_response_code"), "200");
        Assert.assertEquals(actualDetails.get("status"), "NEW");
        Assert.assertEquals(actualDetails.get("customer_ref"), customerDetails.getCustRef());
        Assert.assertEquals(actualDetails.get("public_token"), gpsGetTxnReqDetails.getToken());
        //TODO - can add more validations related to request_json and response_json

        String requestJson = actualDetails.get("request_json");
        String responseJson = actualDetails.get("response_json");
        JsonPath requestJsonPath = new JsonPath(requestJson);
        JsonPath responseJsonPath = new JsonPath(responseJson);

        //Common for all txn flows
        String cdCustomerRef = requestJsonPath.getString("cdCustomerRef");
        String publicToken = requestJsonPath.getString("publicToken");
        String cdPaymentLifecycleId = requestJsonPath.getString("cdPaymentLifecycleId");
        String baseCurrency = requestJsonPath.getString("baseCurrency");

        //Common for all
        softAssert.assertEquals(cdCustomerRef, customerDetails.getCustRef(), "Titan Outbox > Request > cdCustomerRef is not as expected");
        softAssert.assertEquals(publicToken, gpsGetTxnReqDetails.getToken(), "Titan Outbox > Request > publicToken is not as expected");
        softAssert.assertEquals(cdPaymentLifecycleId, gpsGetTxnReqDetails.getTraceid_lifecycle(), "Titan Outbox > Request > cdPaymentLifecycleId is not as expected");
        softAssert.assertEquals(baseCurrency, customerDetails.getBaseCurrency().name(), "Titan Outbox > Request > baseCurrency is not as expected");
    }

    public void verifyDateDetailsSentToSalesforce(Map<String, String> actualDetails, CustomerDetails customerDetails, String dateType) {
        if(customerDetails.getPaymentWallet().equalsIgnoreCase("MRCHTOKEN")) {
            softAssert.assertTrue(actualDetails.isEmpty(), "First Date details is sent to Salesforce");
            return;
        }
        softAssert.assertEquals(actualDetails.get("http_response_code"), "201");
//        Assert.assertEquals(actualDetails.get("titan_response_code"), "000");
        softAssert.assertEquals(actualDetails.get("status"), "NEW");
        softAssert.assertEquals(actualDetails.get("customer_ref"), customerDetails.getCustRef());

        String walletName = customerDetails.getPaymentWallet().equalsIgnoreCase("APPLE") ? "applePay" : "googlePay";

        String requestJson = actualDetails.get("request_json");
        String responseJson = actualDetails.get("response_json");
        JsonPath requestJsonPath = new JsonPath(requestJson);
        JsonPath responseJsonPath = new JsonPath(responseJson);

        //Common for all txn flows
        String cdCustomerRef = requestJsonPath.getString("cdCustomerRef");
        String publicToken = requestJsonPath.getString("publicToken");
        String contactId = requestJsonPath.getString("contactId");
        String eventType = requestJsonPath.getString("eventType");
        String eventDate = requestJsonPath.getString("eventDate");
        String eventStatus = requestJsonPath.getString("eventStatus");
        String eventReason = requestJsonPath.getString("eventReason");
        String isCardActive = requestJsonPath.getString("isCardActive");
        String deleted = requestJsonPath.getString("deleted");
        String baseCurrency = requestJsonPath.getString("baseCurrency");

        String paymentTokenID = requestJsonPath.getString(walletName + ".paymentTokenID");
        String firstRequestedDate = requestJsonPath.getString(walletName + ".firstRequestedDate");
        String firstActivatedDatetime = requestJsonPath.getString(walletName + ".firstActivatedDate");
        String firstTransactionDate = requestJsonPath.getString(walletName + ".firstTransactionDate");

        ReusableMethod.softAssertDateTime(softAssert, eventDate, "eventDate", 2);
        softAssert.assertTrue(requestJson.contains(walletName));
        softAssert.assertEquals(cdCustomerRef, customerDetails.getCustRef());
        softAssert.assertEquals(publicToken, customerDetails.getPublicToken());
        softAssert.assertEquals(contactId, customerDetails.getContactId());
        softAssert.assertEquals(eventType.toUpperCase(), "WALLETPAY");
        softAssert.assertEquals(eventStatus.toUpperCase(), "SUCCESS");
        softAssert.assertEquals(eventReason.toUpperCase(), "FIRST DATES USED");
        softAssert.assertEquals(isCardActive, "true");
        softAssert.assertEquals(deleted, "false");
        softAssert.assertEquals(baseCurrency, customerDetails.getBaseCurrency().name());
        softAssert.assertEquals(paymentTokenID, customerDetails.getPaymentTokenId());

        Map<String, String> tokenRecord = ReusableMethod.getSqlQueryResult("CPCardAdmin.TokenisationRequest.PaymentToken.Query", customerDetails.getPaymentTokenId());
        String expectedFirstReqDate = tokenRecord.get("first_requested_datetime");
        String expectedFirstActivatedDate = tokenRecord.get("first_activated_datetime");

        softAssert.assertNotNull(firstRequestedDate, "firstRequestedDate is null in request JSON");
        if(ReusableMethod.isNotNullOrEmpty(expectedFirstReqDate)) {
            softAssert.assertEquals(firstRequestedDate, tokenRecord.get("first_requested_datetime").substring(0,19), "firstRequestedDate is not matching");
        }
        switch (dateType) {
            case "first_requested_datetime":
                softAssert.assertNull(firstActivatedDatetime, "firstActivatedDatetime is not null in request JSON");
                softAssert.assertNull(firstTransactionDate, "firstTransactionDate is not null in request JSON");
                break;
            case "first_activated_datetime":
                softAssert.assertNull(firstTransactionDate, "firstTransactionDate is not null in request JSON");
                softAssert.assertNotNull(firstActivatedDatetime, "firstActivatedDatetime is null in request JSON");
                if(ReusableMethod.isNotNullOrEmpty(expectedFirstActivatedDate)) {
                    softAssert.assertEquals(firstActivatedDatetime, tokenRecord.get("first_activated_datetime").substring(0,19), "firstActivatedDatetime is not matching");
                }
                break;
            case "first_transaction_date":
                softAssert.assertNotNull(firstActivatedDatetime, "firstActivatedDatetime is null in request JSON");
                if(ReusableMethod.isNotNullOrEmpty(expectedFirstActivatedDate)) {
                    softAssert.assertEquals(firstActivatedDatetime, tokenRecord.get("first_activated_datetime").substring(0,19), "firstActivatedDatetime is not matching");
                }
                softAssert.assertNotNull(firstTransactionDate, "firstTransactionDate is null in request JSON");
                if(customerDetails.getFirstTransactionDate() != null) {
                    softAssert.assertEquals(firstTransactionDate, customerDetails.getFirstTransactionDate().substring(0,19), "firstTransactionDate is not matching");
                }
                break;
        }

    }


    // ignore this and validate separately before/after calling this method
    public void verifyJsonComparison(JsonPath actualJson, Map<String, String> expectedDetails, Properties mappings, SoftAssert softAssert) {
        for (String jsonFieldName : mappings.stringPropertyNames()) {
            String expectedFieldName = mappings.getProperty(jsonFieldName);
            if (expectedFieldName.contains("value=")) {
                softAssert.assertEquals(actualJson.get(jsonFieldName).toString(), expectedFieldName.split("=")[1]);
            } else if (!expectedFieldName.contains("dynamic")) {
                softAssert.assertEquals(actualJson.get(jsonFieldName), expectedDetails.get(expectedFieldName));
            }
        }
    }

    public void verifyAtlasResponse(Map<String, String> titanOutboxRecord) {
        // Validate Atlas response json
        JsonPath actualResponseJson = JsonPath.from(titanOutboxRecord.get("response_json"));
        softAssert.assertEquals(actualResponseJson.get("responseCode"), "000");
        softAssert.assertEquals(actualResponseJson.get("responseDescription"), "PASS");

        // Validate http_response_code
        softAssert.assertEquals(titanOutboxRecord.get("http_response_code"), "200");
        softAssert.assertEquals(titanOutboxRecord.get("titan_response_code"), "000");
    }

    public void verifyTitanResponse(Map<String, String> titanOutboxRecord) {
        // Validate response json
        JsonPath actualResponseJson = null;
        try {
            actualResponseJson = JsonPath.from(titanOutboxRecord.get("response_json"));
        } catch (JsonException ex) {
            softAssert.fail("JsonException occurred reading Titan Outbox > response_json for SAVE_NEW_CARD. Value found is " + titanOutboxRecord.get("response_json"));
        }
        softAssert.assertNotNull(actualResponseJson.get("id"), "Titan Create Card response json > id is NULL");
        softAssert.assertEquals(actualResponseJson.get("response_code"), "000");
        softAssert.assertEquals(actualResponseJson.get("response_description"), "Success");
//        softAssert.assertEquals(actualResponseJson.get("contact_id"), "Success");
        softAssert.assertEquals(actualResponseJson.getBoolean("succeed"), true);
        softAssert.assertNotNull(actualResponseJson.get("contact_id"));

        // Validate http_response_code
        softAssert.assertEquals(titanOutboxRecord.get("http_response_code"), "200");
        softAssert.assertEquals(titanOutboxRecord.get("titan_response_code"), "000");
    }

    public void verifySalesforceResponse(Map<String, String> titanOutboxRecord) {
        // Validate response json
        JsonPath actualResponseJson = JsonPath.from(titanOutboxRecord.get("response_json"));
        softAssert.assertEquals(actualResponseJson.get("code"), "000");
        softAssert.assertEquals(actualResponseJson.get("description"), "Record updated successfully");

        // Validate http_response_code
        softAssert.assertEquals(titanOutboxRecord.get("http_response_code"), "201");
        // softAssert.assertEquals(titanOutboxRecord.get("titan_response_code"), "000");
    }

    public String getTxnCategory(TransactionType transactionType) {
        switch (transactionType) {
            case ATM_CASH_WITHDRAWAL:
                return "Withdrawal";
            case POS:
            case AFD_TYPE1:
            case AFD_TYPE2:
                return "Spent";
            case REFUND:
                return "Refund";
        }
        return null;
    }


    public void setCardPresentIndicator(Map<String, String> testDataRow, String cardPresentIndicator) {
        String authRequestBody = testDataRow.get("Body");
        StringBuilder GPS_POS_Data = new StringBuilder(ReusableMethod.getXpathValue(authRequestBody, "//GPS_POS_Data"));
        GPS_POS_Data.setCharAt(1, cardPresentIndicator.charAt(0));
        authRequestBody = ReusableMethod.setXpathValue(authRequestBody, "//GPS_POS_Data", GPS_POS_Data.toString());
        testDataRow.put("Body", authRequestBody);
    }

    public double getFXQuotedPrice(GPSGetTxnReqDetails gpsGetTxnReqDetails, CustomerDetails customerDetails, int testDataRow) {
        Currency.getCurrency(gpsGetTxnReqDetails.getTxn_CCy()).name();
        gpsGetTxnReqDetails.setCust_Ref(customerDetails.getCustRef());

//        String authRequestBody = testDataRows.get(testDataRow - 1).get("Body");//testDataRows.stream().filter(x -> x.containsValue(testDataRow)).collect(Collectors.toList()).get(0).get("Body");
//        gpsGetTxnReqBody = ReusableMethod.replaceFields(authRequestBody, gpsGetTxnReqDetails);
//        testDataRows.get(testDataRow - 1).replace("Body", gpsGetTxnReqBody); //update the body saved in Map
//        Constants.RESPONSE = ServiceMethod.postAdvance(testDataRow - 1, "200");

        String FX= ReusableMethod.getXpathValue(Constants.RESPONSE, "//quotedPrice");
        double FX_Rate = ReusableMethod.toFormatedDecimalAmt(FX);
        LogCapture.info(Constants.RESPONSE);

        return FX_Rate;
    }

    public String prepareExpectedEmailForInactiveAccFailedClr(GPSGetTxnReqDetails gpsGetTxnReqDetails, String titanErrorResponse) {
        String expectedEmailContent = Constants.CONFIG.getProperty("FAILED_PRESENTMENT_EMAIL_TEMPLATE");
        expectedEmailContent = expectedEmailContent.replace("{txnId}", gpsGetTxnReqDetails.getTXn_ID());
        expectedEmailContent = expectedEmailContent.replace("{cdCustomerRef}", gpsGetTxnReqDetails.getCust_Ref());
        expectedEmailContent = expectedEmailContent.replace("{cdPaymentLifecycleId}", gpsGetTxnReqDetails.getTraceid_lifecycle());

        if(isSupportedCcy(gpsGetTxnReqDetails.getTxnCurrency())) {
            expectedEmailContent = expectedEmailContent.replace("{presentmentAmount}", ReusableMethod.toFormatedStrAmt(gpsGetTxnReqDetails.getTxn_Amt()));
            expectedEmailContent = expectedEmailContent.replace("{presentmentCurrency}", gpsGetTxnReqDetails.getTxnCurrency().name());
        } else {
            expectedEmailContent = expectedEmailContent.replace("{presentmentAmount}", ReusableMethod.toFormatedStrAmt(gpsGetTxnReqDetails.getBill_Amt()));
            expectedEmailContent = expectedEmailContent.replace("{presentmentCurrency}", gpsGetTxnReqDetails.getBillCurrency().name());
        }
        expectedEmailContent = expectedEmailContent.replace("{titanErrorResponse}", titanErrorResponse);
        expectedEmailContent = expectedEmailContent.replace("{errorTimestamp}", ReusableMethod.getCurrentISO_DATE_BST());
        return expectedEmailContent;
    }
}
