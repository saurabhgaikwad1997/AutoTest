package com.cucumber.stepdefinition;


import com.selenium.utillity.Constants;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;
import com.utility.LogCapture;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import org.testng.Assert;

import java.text.DecimalFormat;
import java.util.List;

public class TitanCardAPIStepDefination {
//
    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" for (Enterprise|Titan)$")
    public void forACallUserCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID,  String App) throws Throwable {
        //Constants.APIkey.checkNotEnabled(testCaseID);
        Constants.TCCaseID = testCaseID;
//        Constants.SHEET_NAME=enviroment;
        LogCapture.info("----------------Started API calls for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();

            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);

            LogCapture.info("---------------GET call started----------------");
        }
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        LogCapture.info("---------------Response is "+jp);
        LogCapture.info("----------------Ended API calls for testcase ID " + testCaseID + "---------------------");

    }
//
//    @Then("^User Validate errorCode \"([^\"]*)\" errorDescription \"([^\"]*)\" and fileUploadStatus as \"([^\"]*)\"$")
//    public void userValidateErrorCodeErrorDescriptionAndFileUploadStatusAs(String errorCode, String errorDescription, String fileUploadStatus) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(errorCode, jp.get("errorCode")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(errorDescription, jp.get("errorDescription")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(fileUploadStatus, jp.get("fileUploadStatus")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Capture (Document ID) \"([^\"]*)\" form Response and update in OnTheyFly property$")
//    public void userCaptureDocumentIDFormResponseAndUpdateInOnTheyFlyProperty(String arg, String property) throws Throwable {
//        // This will get the value of Specified Properties from Constants.RESPONSE and update the same in dynamicConfig.properties and HashMap so that we can use this in later execution
//        ReusableMethod.UpdateSpecificProperties(property);
//    }
//
//    @And("^From \"([^\"]*)\" User get (Document Name) \"([^\"]*)\" for API Body$")
//    public void fromUserGetDocumentNameForAPIBody(String testCaseID, String arg1, String key) throws Throwable {
//        Constants.apiBodyValue = ReusableMethod.getSpecificProperties(testCaseID, key);
//    }
//
//    @Given("^User \"([^\"]*)\" from API \"([^\"]*)\" call for \"([^\"]*)\" and observed status code as \"([^\"]*)\"$")
//    public void userFromAPICallForAndObservedStatusCodeAs(String actionType, String methodType, String testCaseID, String statCode) throws Throwable {
//        Constants.TCCaseID = testCaseID;
//        LogCapture.info("----------------Started API calls for testcase ID " + testCaseID + "---------------------");
//        if (methodType.equalsIgnoreCase("Post")) {
//            LogCapture.info("---------------POST call started----------------");
//            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//            LogCapture.info("---------------POST call ended----------------");
//        } else if (methodType.equalsIgnoreCase("Get")) {
//            LogCapture.info("---------------GET call started----------------");
//            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
//            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//            LogCapture.info("---------------GET call started----------------");
//        }
//        LogCapture.info("----------------Ended API calls for testcase ID " + testCaseID + "---------------------");
//
//    }
//
//    @Then("^User Validate Description \"([^\"]*)\" and Code \"([^\"]*)\" and api response status \"([^\"]*)\"$")
//    public void userValidateDescriptionAndCodeAndApiResponseStatus(String code, String description, String status) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("api_status.code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("api_status.description")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("api_response.status")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Description \"([^\"]*)\" and Code \"([^\"]*)\"$")
//    public void userValidateDescriptionAndCode(String code, String description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("api_status.code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("api_status.description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @And("^User validate \"([^\"]*)\"$")
//    public void userValidate(String comment) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(comment, jp.get("api_response.comment")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @And("^User validate recommended BIC field \"([^\"]*)\"$")
//    public void userValidateRecommendedBICField(String recBIC) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(recBIC, jp.get("api_response.recommendedBIC")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//
//    @Then("^User validate status \"([^\"]*)\"$")
//    public void userValidateStatus(String status) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validates response_code \"([^\"]*)\" and response_status \"([^\"]*)\"$")
//    public void userValidatesResponse_codeAndResponse_status(String response_code, String response_status) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_status, jp.get("response_status")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^user validate the city \"([^\"]*)\" and country \"([^\"]*)\"$")
//    public void userValidateTheCityAndCountry(String city, String country) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(city, jp.get("ipCity")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(country, jp.get("ipCountry")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate city \"([^\"]*)\"$")
//    public void userValidateCity(String city) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(city, jp.get("city")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate status \"([^\"]*)\" and code \"([^\"]*)\"$")
//    public void userValidateStatusAndCode(String status, String code) throws Throwable {
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\"$")
//    public void userValidateResponseCodeAndResponseDescription(String response_code, String response_description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response_description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validates response_code \"([^\"]*)\"$")
//    public void userValidatesResponse_code(String response_code) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate errorCode \"([^\"]*)\" errorDescription \"([^\"]*)\"$")
//    public void userValidateErrorCodeErrorDescription(String errorCode, String errorDescription) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(errorCode, jp.get("errorCode")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(errorDescription, jp.get("errorDescription")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate status_code \"([^\"]*)\" status_description \"([^\"]*)\"$")
//    public void userValidateStatus_codeStatus_description(String status_code, String status_description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(status_code, jp.get("status_code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(status_description, jp.get("status_description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\"$")
//    public void userValidateCodeAndDescription(String code, String description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the soap service$")
//    public void userValidateCodeAndDescriptionForTheSoapService(String code, String description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.result.code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.result.description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the soap service for fee management$")
//    public void userValidateCodeAndDescriptionForTheSoapServiceForFeeManagement(String code, String description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getPaymentFeesResponse.PaymentFeeServiceResponse.result.code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getPaymentFeesResponse.PaymentFeeServiceResponse.result.description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for Apply Financials$")
//    public void userValidateCodeAndDescriptionForApplyFinancials(String code, String description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getValidateBankDetailsResponse.ResponseStatusHeader.code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getValidateBankDetailsResponse.ResponseStatusHeader.description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate status \"([^\"]*)\" for DNB Service$")
//    public void userValidateStatusForDNBService(String status) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("company_detail.status")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate code \"([^\"]*)\" and status \"([^\"]*)\"$")
//    public void userValidateCodeAndStatus(String code, String status) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate response code \"([^\"]*)\" and response message \"([^\"]*)\"$")
//    public void userValidateResponseCodeAndResponseMessage(String code, String message) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("response_code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(message, jp.get("response_message")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate uploaded Document ID from the api response$")
//    public void userValidateUploadedDocumentIDFromTheApiResponse() {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        List AllDoc = jp.getList("documentList.document_id");
//        String docID = Constants.DynamicValue.get("<document_id>");
//        boolean Flag = false;
//        for (Object doc : AllDoc) {
//            String doc1 = doc.toString();
//            if (doc1.equals(docID)) {
//                Flag = true;
//                break;
//            }
//        }
//        Assert.assertTrue(Flag);
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the cancel quote$")
//    public void userValidateCodeAndDescriptionForTheCancelQuote(String response_code, String response_description) throws Throwable {
//
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("resp_code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("resp_desc")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//
//    }
//
//    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for the cancel quote$")
//    public void userValidateResponseCodeAndResponseDescriptionForTheCancelQuote(String response_code, String response_description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("fx_deal.response_code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("fx_deal.response_description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//
//    @Then("^User check Quote id and store Quote id$")
//    public void userCheckQuoteIdAndStoreQuoteId() {
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        ReusableMethod.updateConfig("<quote_id>", jp.get("create_quote.quote_id"));
//    }
//
//    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for subscribe rate alert$")
//    public void userValidateResponseCodeAndResponseDescriptionForSubscribeRateAlert(String response_code, String response_description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        ReusableMethod.updateConfig("<subscription_id>", Integer.toString(jp.get("subscription_details.subscription_id")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response.code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response.description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for Get Subscription rate alert$")
//    public void userValidateResponseCodeAndResponseDescriptionForGetSubscriptionRateAlert(String response_code, String response_description) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response.code")));
//        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response.description")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User verify latest quote rate$")
//    public void userVerifyLatestQuoteRate() {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//        Assert.assertEquals("PASS", ReusableMethod.compareString(jp.get("latest_quote.quote_rate"), jp.get("latest_quote.quote_rate")));
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @And("^User Verify \"([^\"]*)\" from responce body$")
//    public void userVerifyFromResponceBody(String liveRate) throws Throwable {
//        LogCapture.info("----------------Response Validations Live Rate Started-------------------");
//        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
//        String res = xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.debug");
//        res = res.split(",")[0].split(":")[1];
//        Assert.assertEquals(true, res.startsWith(liveRate));
//        LogCapture.info("----------------Response Validations Live Rate Ended-------------------");
//    }
//
//    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Currency Pair \"([^\"]*)\"$")
//    public void forACallUserCheckStatusCodeAsForOnEnvironmentForCurrencyPair(String methodType, String statCode, String testCaseID, String enviroment, String App) throws Throwable {
//        Constants.TCCaseID = testCaseID;
//        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
//        if (methodType.equalsIgnoreCase("Post")) {
//            LogCapture.info("---------------POST call started----------------");
//            if (Constants.DynamicValue.containsKey("CurrencyPair")) {
//                Constants.DynamicValue.replace("CurrencyPair", Constants.DynamicValue.get("CurrencyPair"), App);
//            }
//            else {
//                Constants.DynamicValue.put("CurrencyPair",App);
//            }
//            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            LogCapture.info("---------------POST call ended----------------");
//        }
//        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
//
//    }
//
//    @Then("^User validate Quote \"([^\"]*)\" from response body$")
//    public void userValidateQuoteFromResponseBody(String qutRate) throws Throwable {
//        LogCapture.info("----------------Response Validations Live Rate Started-------------------");
//        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
//        String res = xml.get("Envelope.Body.getRateSingularResponse.return");
//        JsonPath jp=Constants.APIkey.rawToJson(res);
//        res = jp.get("Result.Quote");
//        Assert.assertEquals(true, res.startsWith(qutRate));
//        LogCapture.info("----------------Response Validations Live Rate Ended-------------------");
//    }
//
//
//
//
//    @Given("^User Generate Token from API \"([^\"]*)\" call for \"([^\"]*)\" on \"([^\"]*)\" and observed status code as \"([^\"]*)\"$")
//    public void userGenerateTokenFromAPICallForOnAndObservedStatusCodeAs(String methodType, String testCaseID, String Environment, String statCode) throws Throwable {
//        Constants.TCCaseID = testCaseID;
//        LogCapture.info("----------------Started API calls for testcase ID " + testCaseID + "---------------------");
//        if (methodType.equalsIgnoreCase("Post")) {
//            LogCapture.info("---------------POST call started----------------");
//            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//            LogCapture.info("---------------POST call ended----------------");
//        }else if (methodType.equalsIgnoreCase("Get")) {
//            LogCapture.info("---------------GET call started----------------");
//            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
//            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//            LogCapture.info("---------------GET call started----------------");
//        }
//        LogCapture.info("----------------Ended API calls for testcase ID " + testCaseID + "---------------------");
//
//    }
//
//
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and \"([^\"]*)\" for get balance API$")
//    public void userValidateStatusDescriptionAndStatusCodeAndForGetBalanceAPI(String ResponseDescription, String ResponseCode, String CCY) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        String RespActBal = Float.toString(jp.get("actualBalance"));
//        String RespAvailBal = Float.toString(jp.get("availableBalance"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(jp.get("currency"),CCY));
//        LogCapture.info("-------------User verified Currency as >> "+jp.get("currency"));
//
//        LogCapture.info("-------------Able to see Actual balance >> "+RespActBal);
//        LogCapture.info("-------------Able to see Available balance >> "+RespAvailBal);
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" (for unsupported currency|when date is missing)$")
//    public void userValidateStatusDescriptionAndStatusCodeForUnsupportedCurrency(String ResponseDescription, String ResponseCode, String MissingField) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for invalid (customer reference|contact ID)$")
//    public void userValidateStatusDescriptionAndStatusCodeForInvalidCustomerReference(String ResponseDescription, String ResponseCode, String InvalidField) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when base currency is missing$")
//    public void userValidateStatusDescriptionAndStatusCodeWhenBaseCurrencyIsMissing(String ResponseDescription, String ResponseCode) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\"$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmount(String ResponseCode, String ResponseDescription, String BLKCCY, String BLKAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(BLKCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(BLKAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,Amount));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (customer reference number|fee currency|PaymentLifeCycleID field|Wallet currency|Base Currency) is missing$")
//    public void userValidateStatusDescriptionAndStatusCodeWhenCustomerReferenceNumberIsMissing(String ResponseDescription, String ResponseCode,String MissingField) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when amount to (block|Credit|Debit) is missing$")
//    public void userValidateStatusDescriptionAndStatusCodeWhenAmountToBlockIsMissing(String ResponseDescription, String ResponseCode,String AmtType) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (amountToBlock|amountToCredit|amountToDebit) currency is null$")
//    public void userValidateStatusDescriptionAndStatusCodeWhenAmountToBlockCurrencyIsNull(String ResponseDescription, String ResponseCode, String AmtType) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (base currency|decline code|decline reason|Contact ID) field is null$")
//    public void userValidateStatusDescriptionAndStatusCodeWhenBaseCurrencyFieldIsNull(String ResponseDescription, String ResponseCode,String Fieldtype) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" and Unblocked amount \"([^\"]*)\"$")
    public void userValidateThenVerifyUnblockedAmountCurrencyAndUnblockedAmount(String ResponseCode, String ResponseDescription, String BLKCCY, String BLKAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(BLKCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(BLKAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("unblockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,Amount));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("unblockedAmount.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when PaymentLifeCycleID field is null$")
//    public void userValidateStatusDescriptionAndStatusCodeWhenPaymentLifeCycleIDFieldIsNull(String ResponseDescription, String ResponseCode) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when wallet balance is not present$")
//    public void userValidateStatusDescriptionAndStatusCodeWhenWalletBalanceIsNotPresent(String ResponseDescription, String ResponseCode) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" Unblocked amount \"([^\"]*)\" and Debited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyUnblockedAmountCurrencyUnblockedAmountAndDebitedAmount(String ResponseCode, String ResponseDescription, String CKBLKCCY, String CKBLKAmount, String CKBLKDebitedAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);


        String CCY= Constants.OnTheFlyValue.getProperty(CKBLKCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(CKBLKAmount);
        String DebitedAmount= Constants.OnTheFlyValue.getProperty(CKBLKDebitedAmount);


        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified UnblockedAmount Currency as >> "+jp.get("unblockedAmount.amount"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,Amount));
        LogCapture.info("-------------User verified Unblocked amount as >> "+jp.get("unblockedAmount.amount"));

        String DebitedAmt =def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitedAmt,DebitedAmount));
        LogCapture.info("-------------User verified Debited amount as >> "+jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Credited Currency \"([^\"]*)\" and Credited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyAmountCreditedCurrencyAndCreditedAmount(String ResponseCode, String ResponseDescription, String CRDCCY, String CRDAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(CRDCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(CRDAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("amountCredited.currency")));
        LogCapture.info("-------------User verified amount Credited Currency as >> "+jp.get("amountCredited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String CreditedAmt =def.format(jp.get("amountCredited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(CreditedAmt,Amount));
        LogCapture.info("-------------User verified amount Credited as >> "+jp.get("amountCredited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Debited Currency \"([^\"]*)\" and Debited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyAmountDebitedCurrencyAndDebitedAmount(String ResponseCode, String ResponseDescription, String DebitedCCY, String DebitedAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(DebitedCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(DebitedAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified amount Debited Currency as >> "+jp.get("amountDebited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String DebitedAmt =def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitedAmt,Amount));
        LogCapture.info("-------------User verified amount Debited as >> "+jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" (for decline card transaction|For Send money)$")
    public void userValidateForDeclineCardTransaction(String ResponseCode, String ResponseDescription, String data) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }
//
//    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify account_number\"([^\"]*)\" Organization \"([^\"]*)\" and PaymentLifeCycleID \"([^\"]*)\" details$")
//    public void userValidateThenVerifyAccount_numberOrganizationAndPaymentLifeCycleIDDetails(String ResponseCode, String ResponseDescription, String ActivityTAN, String ActivityOrganization, String ActivityPamentLifeCycleID) throws Throwable {
//
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        String TAN= Constants.OnTheFlyValue.getProperty(ActivityTAN);
//        String Organization= Constants.OnTheFlyValue.getProperty(ActivityOrganization);
//        String PamentLifeCycleID= Constants.OnTheFlyValue.getProperty(ActivityPamentLifeCycleID);
//
//        Assert.assertEquals(jp.get("response_code"), ResponseCode);
//        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));
//
//        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
//        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals(jp.get("org_code"),  Organization);
//        Assert.assertEquals(jp.get("contract_note_search_criteria.filter.organization[0]"),  Organization);
//        LogCapture.info("User verified Organization as >> "+jp.get("org_code"));
//
//        Assert.assertEquals(jp.get("card_activity_history_details[0].cdPaymentLifecycleId"),  PamentLifeCycleID);
//
//        LogCapture.info("User verified Instruction Number as >> "+jp.get("card_activity_history_details[0].instruction_number"));
//
//        Assert.assertEquals(jp.get("account_number"),  TAN);
//        LogCapture.info("User verified account number as >> "+jp.get("account_number"));
//
//        LogCapture.info("User verified transaction Date as >> "+jp.get("card_activity_history_details[0].transactionDate"));
//        LogCapture.info("User verified merchant Name as >> "+jp.get("card_activity_history_details[0].merchantName"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for (invalid organization code|Organization Code is Missing|invalid PaymentlifeCycle ID)$")
//    public void userValidateStatusDescriptionAndStatusCodeForInvalidOrganizationCode(String ResponseDescription, String ResponseCode, String OrgCodetype) throws Throwable {
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//
    @Given("^User Generate Token for Titan Card API Validation from \"([^\"]*)\" for Titan-Card Application$")
    public void userGenerateTokenForTitanCardAPIValidationFromForTitanCardApplication(String tcID) throws Throwable {
        LogCapture.info("--------------Token Generation started for testcase ID " + tcID + "---------------");
        Constants.RESPONSE = ServiceMethod.post(tcID, "200");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Constants.ACCESS_TOKEN = jp.get("access_token");
        LogCapture.info("--------------Token Generation ended--------------");
        LogCapture.info("--------------Token Generation ended for testcase ID " + tcID + "--------------");
    }
//
//
//    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Contact ID \"([^\"]*)\"$")
//    public void userValidateThenVerifyContactID(String ResponseCode, String ResponseDescription, String CardOrderContactID) throws Throwable {
//
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        String ContactID= Constants.OnTheFlyValue.getProperty(CardOrderContactID);
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        String ContactId = Integer.toString(jp.get("contact_id"));
//        Assert.assertEquals(ContactId,  ContactID);
//        LogCapture.info(".............User verified Contact ID as >> "+ContactId);
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//    }
//
//    @Given("^User connects to Titan UAT DB and fetches the Customer (TAN) having zero wallet balance$")
//    public void userConnectsToTitanUATDBAndFetchesTheCustomerHavingZeroWalletBalance(String TitanAccountNumber) throws Exception {
//
//        TitanAccountNumber= Constants.APIkey.VerifyDBDetails("UAT", "", "FetchTANWithZeroWalletBalance");
//         Constants.APIkey.VerifyDBDetails("UAT", "", "Fetch TitanAccountNumber");
//        System.out.println("Titan Account Number having zero wallet balance : " + TitanAccountNumber);
//    }
//
//
//    @Given("^User connects to Titan UAT DB and verify the PtToken ID and PtToken Wallet fields on titan database$")
//    public void userConnectsToTitanUATDBAndVerifyThePtTokenIDAndPtTokenWalletFieldsOnTitanDatabase() throws Exception {
//
//        String ActPtTokenID = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyPtTokenID");
//        String ExpPtTokenID = Constants.RandomPtTokenID;
//        if(ActPtTokenID.equals(ExpPtTokenID))
//        {
//            LogCapture.info("User verified PtToken ID stored in Titan DB as >> "+ActPtTokenID);
//        }else
//        {
//            LogCapture.info("TC Failed : PtToken ID Not stored in Titan DB >> "+ActPtTokenID);
//            Assert.fail();
//        }
//
//        String ActPtTokenWallet = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyPtTokenWallet");
//        String ExpPtTokenWallet = Constants.OnTheFlyValue.getProperty("<PtTokenWallet1>");
//        if(ActPtTokenWallet.equals(ExpPtTokenWallet))
//        {
//            LogCapture.info("User verified PtToken Wallet stored in Titan DB as >> "+ActPtTokenWallet);
//        }else
//        {
//            LogCapture.info("TC Failed : PtToken Wallet Not stored in Titan DB >> "+ActPtTokenWallet);
//            Assert.fail();
//        }
//    }
//
//    @Then("^User Verify Consolidated Wallet balances for Non Supported Currency on titan DB$")
//    public void userVerifyConsolidatedWalletBalancesForNonSupportedCurrencyOnTitanDB() throws Exception {
//
//        String ActConsolidatedWalletBalances = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyConsolidatedWalletBalances");
//        if(!ActConsolidatedWalletBalances.equals(""))
//        {
//            LogCapture.info("User verified Consolidated Wallet Balances reflected for Non supported Currency on Titan DB  >> "+ActConsolidatedWalletBalances);
//        }else
//        {
//            LogCapture.info("TC Failed : Consolidated Wallet Balances Not reflected for Non supported Currency on Titan DB >> "+ActConsolidatedWalletBalances);
//            Assert.fail();
//        }
//    }
//
//    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount newly added multi Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\"$")
//    public void userValidateThenVerifyBlockedAmountNewlyAddedMultiCurrencyAndBlockedAmount(String ResponseCode, String ResponseDescription, String MultiCCY, String MultiAmount) throws Throwable {
//
//        LogCapture.info("----------------Response Validations Started-------------------");
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
//
//        String Amount= Constants.OnTheFlyValue.getProperty(MultiAmount);
//        String BaseCCY = Constants.OnTheFlyValue.getProperty("<CkAndBlock_CCY>");
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
//        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
//        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(MultiCCY,jp.get("blockedAmount.currency")));
//        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));
//
//        DecimalFormat def=new DecimalFormat("0.00");
//        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
//        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,Amount));
//        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));
//
//        Assert.assertEquals("PASS",ReusableMethod.compareString(BaseCCY,jp.get("balance.currency")));
//        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
//        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
//        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));
//
//        LogCapture.info("----------------Response Validations Ended-------------------");
//
//    }
}
