package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.selenium.utillity.Constants.*;

/**
 * @author sunny.goyal
 */
public class CommonStepDefinitionAtlas {

    public static String ClientNumber;
    public static String ReportName;
    public static String Comments;
    public static String CopiedTAN;

    @Then("^Verify atlas kafka message using \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyAtlasKafkaMessageUsingOperationType(String expectedMsgFieldsSqlQueryProperty, String OperationType) throws Throwable {

        String messageFieldXpath = Constants.KafkaUI.getProperty("MessageFieldFundsIn");

        messageFieldXpath = messageFieldXpath.replace("{Operation}", OperationType).replace("{uniqueMessageId}", KafkaMessageCDID);

        JsonPath actualKafkaMsgJsonObj = ReusableMethod.waitForKafkaMessage(messageFieldXpath);
        LogCapture.info("--------------User fetch Fund IN details from DB for kafka -------------------");
        String Enviroment = Constants.CONFIG.getProperty("Environment");
        kafkaExpectedKeyValues = ReusableMethod.getSqlQueryResult(expectedMsgFieldsSqlQueryProperty, KafkaMessageCDID);//Reusables.verifyDBDetailsEnhanced(Enviroment, KafkaMessageCDID, expectedMsgFieldsSqlQueryProperty);
//        kafkaExpectedKeyValues = ReusableMethod.getSqlQueryResult(expectedMsgFieldsSqlQueryProperty, Constants.DynamicValue.get("<dynamic>"),);
        ReusableMethod.verifyKafkaMessage(kafkaExpectedKeyValues, actualKafkaMsgJsonObj);
    }

    @And("^Verify Kafka message audit logs for \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyKafkaMessageAuditLogsForAnd(String auditLogSqlQueryProperty, String OperationType) throws Throwable {
        Map<String, String> actualAuditRecord = ReusableMethod.getSqlQueryResult(auditLogSqlQueryProperty, KafkaMessageCDID, OperationType);
        System.out.println("Actual Audit Log for '" + KafkaMessageCDID + "' :: " + actualAuditRecord);
        ReusableMethod.verifyKafkaAuditLog(kafkaExpectedKeyValues, actualAuditRecord);
    }

    @And("^User navigate to (Atlas|Saleforce) Application \"([^\"]*)\"$")
    public void userNavigateToAtlasApplication(String page, String vUrl) throws Exception {
        if (page.equals("Atlas")) {
            LogCapture.info("Atlas Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (page.equals("Salesforce")) {
            //Line of code
        }
    }

    @When("^User enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click log In button on Altas Application$")
    public void userEnterUserNamePasswordAndClickLogInButtonOnAltasApplication(String userName, String password) throws Exception {
        LogCapture.info("----------------User enters UserName and Password-------------------");
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.AtlasloginOR.getProperty("Atlas_Username");
        String vObjPass = Constants.AtlasloginOR.getProperty("Atlas_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, vPassword));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.AtlasloginOR.getProperty("Atlas_LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));

    }


    @Then("^User successfully landed on Atlas Dashboard page$")
    public void userSuccessfullyLandedOnAtlasDashboardPage() throws Exception {
        LogCapture.info("Dashboard loading ......");
        Constants.key.pause("5", "");
        String vobjectDashboard = Constants.AtlasDashboardOR.getProperty("Atlas_Dashboard");
        String vobjectPFXBox = Constants.AtlasDashboardOR.getProperty("AtlasPFXBox");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectPFXBox, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "ATLAS"));

    }


    @And("^User navigates to (Payment In Report|Registration Queue|Registration Report|Payment In Queue|Payment Out Queue|Payment Out Report) from Dashboard$")
    public void userNavigatesToRespectivePageFromDashboard(String Menu) throws Exception {
        if (Menu.equalsIgnoreCase("Payment In Report")) {
            LogCapture.info("User is selecting Payment In hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("Atlas_PaymentInReportTab");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
        } else if (Menu.equalsIgnoreCase("Registration Queue")) {
            LogCapture.info("User is selecting Registration Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasRegistrationQueue = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationQueue");
            String vObjAtlasRegistrationQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasRegistrationQueue, ""));
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAtlasRegistrationQueueText, ""));
            if (Constants.driver.findElement(By.xpath(vObjAtlasRegistrationQueueText)).getText().contains("Registration queue")) {
                LogCapture.info("User Successfully redirecting to Registration Queue ");
            } else {
                LogCapture.info("User is not Successfully redirecting to Registration Queue ");
                Assert.fail();
            }

        } else if (Menu.equalsIgnoreCase("Registration Report")) {
            LogCapture.info("User is selecting Registration Report hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasRegistrationReport = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReport");
            String vObjAtlasRegistrationReportText = Constants.AtlasRegistrationOR.getProperty("AtlasRegistrationReportText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasRegistrationReport, ""));
            if (Constants.driver.findElement(By.xpath(vObjAtlasRegistrationReportText)).getText().contains("Registration report")) {
                LogCapture.info("User Successfully redirecting to Registration Report ");
            } else {
                LogCapture.info("User is not Successfully redirecting to Registration Report ");
                Assert.fail();
            }

        } else if (Menu.equalsIgnoreCase("Payment In Queue")) {
            LogCapture.info("User is selecting Payment In Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vPaymentinTab = Constants.AtlasDashboardOR.getProperty("AtlasPaymentInTabQueue");
            String vObjAtlasPaymentInQueueText = Constants.AtlasRegistrationOR.getProperty("AtlasPaymentInQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vPaymentinTab, ""));
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAtlasPaymentInQueueText, ""));
//            if (Constants.driver.findElement(By.xpath(vObjAtlasPaymentInQueueText)).getText().contains("Payment In queue")) {
//                LogCapture.info("User Successfully redirecting to Payment In Queue ");
//            } else {
//                LogCapture.info("User is not Successfully redirecting to Payment In Queue ");
//                Assert.fail();
//            }
        } else if (Menu.equalsIgnoreCase("Payment Out Queue")) {
            LogCapture.info("User is selecting Payment Out Queue hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vObjAtlasPaymentOutTabQueue = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutTabQueue");
            String vObjAtlasPaymentOutQueueText = Constants.AtlasPaymentOutOR.getProperty("AtlasPaymentOutQueueText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAtlasPaymentOutTabQueue, ""));

        } else if (Menu.equalsIgnoreCase("Payment Out Report")) {
            LogCapture.info("User is selecting Payment Out Report hyperlink from dashboard..");
            String vObjAtlasSelectTabView = Constants.AtlasDashboardOR.getProperty("AtlasSelectTabView");
            String vPaymentOutTab = Constants.AtlasDashboardOR.getProperty("Atlas_PaymentOutReportTab");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAtlasSelectTabView, ""));
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.click(vPaymentOutTab, ""));
        }
    }


    @And("^User Click on (Transaction Id|Client Name) Hyper Link on (Payment In|Payment Out)$")
    public void userClickHyperLink(String Column, String Action) throws Exception {
        LogCapture.info("----------------User click on Transaction ID Hyper link-------------------");
        String vShowingZeroResult = Constants.AtlasPaymentInOR.getProperty("ShowingZeroResult");
        String ShowingZeroResult = Constants.driver.findElement(By.xpath(vShowingZeroResult)).getText();
        if (ShowingZeroResult.contains("0")) {
            LogCapture.info("No payment found");
            driver.quit();
        } else {
            if (Action.equalsIgnoreCase("Payment In")) {
                String vObjPaymentInQueueTable = Constants.AtlasPaymentInOR.getProperty("PaymentInQueueTable");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInQueueTable, ""));
                List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentInQueueTable));
                LogCapture.info("Total number of elements present: " + listOfElements.size());
                if (Column.equalsIgnoreCase("Transaction Id")) {
                    for (int i = 0; i <= listOfElements.size(); i++) {
                        String DynamicValue = "//*[@id='payInQueueBody']//tr[" + (i + 1) + "]//td[2]";
                        String TranasctionId = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                        System.out.println(TranasctionId);
                        if (TranasctionId.length() > 0) {
                            WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + TranasctionId + "']"));
                            JavascriptExecutor executor = (JavascriptExecutor) driver;
                            executor.executeScript("arguments[0].click();", ele);
                            break;
                        }
                    }
                } else if (Column.equalsIgnoreCase("Client Id")) {
                    for (int i = 0; i <= listOfElements.size(); i++) {
                        String ClientId = "//*[@id='payInQueueBody']//tr[" + (i + 1) + "]//td[4]";
                        String Value = Constants.driver.findElement(By.xpath(ClientId)).getText();
                        System.out.println(Value);
                        if (Value.length() > 0) {
                            WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                            JavascriptExecutor executor = (JavascriptExecutor) driver;
                            executor.executeScript("arguments[0].click();", ele);
                            break;
                        }
                    }
                }
                String vObjTransactionText = Constants.AtlasPaymentInOR.getProperty("TransactionText");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionText, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjTransactionText, ""));

            } else if (Action.equalsIgnoreCase("Payment Out")) {
                String vObjPaymentOutQueueTable = Constants.AtlasPaymentOutOR.getProperty("PaymentOutQueueTable");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutQueueTable, ""));
                List<WebElement> listOfElements = Constants.driver.findElements(By.xpath(vObjPaymentOutQueueTable));
                LogCapture.info("Total number of elements present: " + listOfElements.size());
                if (Column.equalsIgnoreCase("Transaction Id")) {
                    for (int i = 0; i <= listOfElements.size(); i++) {
                        String DynamicValue = "//*[@id='payOutQueueBody']//tr[" + (i + 1) + "]//td[2]";
                        String TranasctionId = Constants.driver.findElement(By.xpath(DynamicValue)).getText();
                        System.out.println(TranasctionId);
                        if (TranasctionId.length() > 0) {
                            WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + TranasctionId + "']"));
                            JavascriptExecutor executor = (JavascriptExecutor) driver;
                            executor.executeScript("arguments[0].click();", ele);
                            break;
                        }
                    }
                } else if (Column.equalsIgnoreCase("Client Id")) {
                    for (int i = 0; i <= listOfElements.size(); i++) {
                        String ClientId = "//*[@id='payOutQueueBody']//tr[" + (i + 1) + "]//td[4]";
                        String Value = Constants.driver.findElement(By.xpath(ClientId)).getText();
                        System.out.println(Value);
                        if (Value.length() > 0) {
                            WebElement ele = Constants.driver.findElement(By.xpath("//a[text()='" + Value + "']"));
                            JavascriptExecutor executor = (JavascriptExecutor) driver;
                            executor.executeScript("arguments[0].click();", ele);
                            break;
                        }
                    }
                }
                String vObjTransactionText = Constants.AtlasPaymentInOR.getProperty("TransactionText");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionText, ""));
                Assert.assertEquals("PASS", Constants.key.exist(vObjTransactionText, ""));

            }
        }
    }


    @Then("^User (Lock|UnLock) the Record$")
    public void userLockTheRecord(String Lock) throws Exception {
        if (Lock.equalsIgnoreCase("Lock")) {
            String vLockObj = Constants.AtlasPaymentInOR.getProperty("Atlas_LockToggle");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vLockObj, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vLockObj, ""));
        }
        if (Lock.equalsIgnoreCase("UnLock")) {
            String vLockObj = Constants.AtlasPaymentInOR.getProperty("Atlas_UnLockToggle");
            Assert.assertEquals("PASS", Constants.key.click(vLockObj, ""));
        }
    }


    @Then("^(Registration|Payment In|Registration CFX|Payment Out) Status to be Observed as (INACTIVE|ACTIVE|HOLD)$")
    public void registrationStatusToBeObservedAsINACTIVE(String action, String status) throws Exception {
        if (status.equalsIgnoreCase("INACTIVE") && action.equalsIgnoreCase("Registration")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));

        } else if (status.equalsIgnoreCase("ACTIVE") && action.equalsIgnoreCase("Registration")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));

        } else if (status.equalsIgnoreCase("HOLD") && action.equalsIgnoreCase("Payment In")) {
            LogCapture.info("----------------Verifying PaymentIn status  to be hold-------------------");
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "HOLD"));
            LogCapture.info("----------------Verified PaymentIn status as hold-------------------");

        } else if (status.equalsIgnoreCase("ACTIVE") && action.equalsIgnoreCase("Registration CFX")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));

        } else if (status.equalsIgnoreCase("INACTIVE") && action.equalsIgnoreCase("Registration CFX")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));

        } else if (status.equalsIgnoreCase("HOLD") && action.equalsIgnoreCase("Payment Out")) {
            String vObjStatus = Constants.AtlasPaymentInOR.getProperty("Status");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "HOLD"));

        }
    }


    @And("^Mark the (Registration|Payment In CFX|Payment Out CFX|Payment In PFX|Payment Out PFX|Payment Out CFX-Etailer|Payment In CFX-Etailer|) Status as (CLEAR|ACTIVE|INACTIVE|REJECT|SEIZE|HOLD) with comments$")
    public void markThePaymentInStatusAsCLEARWithComments(String Value, String Action) throws Exception {
        Comments = RandomStringUtils.randomAlphabetic(10);
        System.out.println(Comments);
        if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("ACTIVE")) {
            String vObjActive = Constants.AtlasRegistrationOR.getProperty("Active");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjActive, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("INACTIVE")) {
            String vObjActive = Constants.AtlasRegistrationOR.getProperty("InActive");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjActive, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("REJECT")) {
            String vObjReject = Constants.AtlasRegistrationOR.getProperty("Reject");
            String vTextInput = Constants.AtlasRegistrationOR.getProperty("Comments");
            Assert.assertEquals("PASS", Constants.key.click(vObjReject, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("REJECT")) {
            Constants.key.pause("5", "");
            String vRejectButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vRejectButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vRejectButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeize");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vClearButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButton = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vholdButton, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment Out CFX-Etailer") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButton = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButton, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButtonpfx = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButtonpfx, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButtonCfx = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButtonCfx, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("CLEAR")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("Atlas_UpdateStatusClear");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("REJECT")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusReject");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("SEIZE")) {
            String vClearButton = Constants.AtlasPaymentInOR.getProperty("AtlasUpdateStatusSeiz");
            String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vClearButton, ""));
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user add comments.....");
            String vholdButtonCfxE = Constants.AtlasPaymentOutOR.getProperty("Atlas_UpdateStatushold");
            String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
            Assert.assertEquals("PASS", Constants.key.click(vholdButtonCfxE, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
        }
    }


    @When("^User Click on (Apply|Apply&Unlock) button on (Registration Queue|Payment In Queue|Payment In Report|Registration Queues|Payment Out Queue|Registration Queue CFX|Payment In Queue CFX|Payment Out Queue CFX|Payment Out Queue PFX|Registration Queue PFX|Payment Out CFX-Etailer|Payment In CFX-Etailer|)$")
    public void userClickOnApplyApplyUnlock(String Lock, String Queue) throws Exception {
        if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue")) {
            String vApplyButton = Constants.AtlasRegistrationOR.getProperty("Apply");
            String vObjSanctions = Constants.AtlasRegistrationOR.getProperty("Sanctions");
            String vObjRepeatCheck = Constants.AtlasRegistrationOR.getProperty("RepeatCheck");
            String vObjSanctionStatus = Constants.AtlasRegistrationOR.getProperty("SanctionsTable");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
            if (Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe")) {
                JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
                je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='regDetails_profile_update']")));
                JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
                executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vApplyButton)));
                Constants.key.pause("6", "");
            } else {
                int count = 0;
                do {
                    count = count + 1;
                    do {
                        count = count + 1;
                    } while (!Constants.driver.findElement(By.xpath(vObjRepeatCheck)).isEnabled());
                    Assert.assertEquals("PASS", Constants.key.click(vObjRepeatCheck, ""));
                } while (!Constants.driver.findElement(By.xpath(vObjSanctionStatus)).getText().equalsIgnoreCase("Safe"));
                System.out.println("Count" + count);
                Constants.key.pause("2", "");
                JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
                je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='regDetails_profile_update']")));
                Constants.key.pause("2", "");
                // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
                String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("Apply");
                JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
                executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
                Constants.key.pause("6", "");
            }
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queues")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='regDetails_profile_update']")));
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In Queue")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentIn']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasPaymentInOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment Out Queue")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentOut']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApply = Constants.AtlasPaymentOutOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApply)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue CFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='regDetails_profile_update']")));
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In Queue CFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentIn']")));
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasPaymentInOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment Out Queue CFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentOut']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApply = Constants.AtlasPaymentOutOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApply)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment Out Queue PFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[@id='updatePaymentOut']")));
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApply = Constants.AtlasPaymentOutOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApply)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Registration Queue PFX")) {
            Constants.key.pause("2", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasRegistrationOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");


        } else if (Lock.equalsIgnoreCase("Apply&Unlock") && Queue.equalsIgnoreCase("Payment Out Queue PFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//input[@id='updatePaymentOutAndUnlock']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyandunlk = Constants.AtlasPaymentOutOR.getProperty("Apply&Unlock");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            LogCapture.info("user click on apply & unlock button....");
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyandunlk)));
            Constants.key.pause("6", "");

        } else if (Lock.equalsIgnoreCase("Apply&Unlock") && Queue.equalsIgnoreCase("Payment Out Queue CFX")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//input[@id='updatePaymentOutAndUnlock']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyandunlk = Constants.AtlasPaymentOutOR.getProperty("Apply&Unlock");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            LogCapture.info("user click on apply & unlock button....");
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyandunlk)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply&Unlock") && Queue.equalsIgnoreCase("Payment Out CFX-Etailer")) {
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//input[@id='updatePaymentOutAndUnlock']")));
            Constants.key.pause("2", "");
            // ((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyandunlk = Constants.AtlasPaymentOutOR.getProperty("Apply&Unlock");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            LogCapture.info("user click on apply & unlock button....");
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyandunlk)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In Report")) {
            Constants.key.pause("3", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasPaymentInOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");
        } else if (Lock.equalsIgnoreCase("Apply") && Queue.equalsIgnoreCase("Payment In CFX-Etailer")) {
            Constants.key.pause("3", "");
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");
            String vObjApplyAndUnLock = Constants.AtlasPaymentInOR.getProperty("Apply");
            JavascriptExecutor executor = ((JavascriptExecutor) Constants.driver);
            executor.executeScript("arguments[0].click();", Constants.driver.findElement(By.xpath(vObjApplyAndUnLock)));
            Constants.key.pause("6", "");
        }
    }


    @Then("^User clicks (Yes|No) for the Intuition PopUp$")
    public void userClicksYesForTheIntuitionPopUp(String value) throws Exception {
        String vIntuiionButtonYes = AtlasPaymentInOR.getProperty("IntuitionYesButton");
        String vIntuiionButtonNo = AtlasPaymentInOR.getProperty("IntuitionNoButton");
        String vIntuitionMessage = AtlasPaymentInOR.getProperty("IntuitionConfirmationMessage");
        if (driver.findElement(By.xpath(vIntuitionMessage)).isDisplayed()) {
            Assert.assertEquals("PASS", Constants.key.verifyText(vIntuitionMessage, "Manual action on Intuition is pending, do you want to continue clearing?"));
            if (value.equalsIgnoreCase("Yes")) {
                Assert.assertEquals("PASS", Constants.key.click(vIntuiionButtonYes, ""));
                LogCapture.info("User clicked on Yes for Clearing the Payment");
            } else if (value.equalsIgnoreCase("No")) {
                Assert.assertEquals("PASS", Constants.key.click(vIntuiionButtonNo, ""));
                LogCapture.info("User clicked on No for Clearing the Payment");
            }
        }
    }


    @Then("^User Scan the Payment transaction number from UI$")
    public void userScanThePaymentTransactionNumberFromUI() throws Exception {
        LogCapture.info("--------------User gets the Transaction Number -------------------");
        String VPayment_TransNum = AtlasPaymentOutOR.getProperty("Payment_TransNum");
        Constants.key.pause("3", "");
        String Payment_TransNum = Constants.key.getText(VPayment_TransNum);
        String input = Payment_TransNum;
        String pattern = "-(\\d+)";
        Pattern regexPattern = Pattern.compile(pattern);
        Matcher matcher = regexPattern.matcher(input);
        String extractedValue = null;
        if (matcher.find()) {
            extractedValue = matcher.group(1);
            String substringToRemove = "00";
            extractedValue = extractedValue.replace(substringToRemove, "");

            System.out.println("Extracted value: " + extractedValue);
        } else {
            System.out.println("No match found.");
        }
        LogCapture.info("--------------User gets UniqueIdentifier from UI -------------------");
        DynamicValue.put("<dynamic>", extractedValue);
        System.out.println(DynamicValue);
//       Constants.DynamicValue.get("<dynamic>").replace(Constants.DynamicValue.get("<dynamic>"),extractedValue);


    }

    @Then("^Verify FundsOut kafka message for \"([^\"]*)\" for Operation Type \"([^\"]*)\"$")
    public void verifyFundsOutKafkaMessageForForOperationType(String mappingFilePath, String OperationType) throws Throwable {

        String messageFieldXpath = KafkaUI.getProperty("MessageFieldFundsOut");
        messageFieldXpath = messageFieldXpath.replace("{Operation}", OperationType).replace("{uniqueMessageId}", paymentLifeCycleID);

        JsonPath jsonPath = ReusableMethod.waitForKafkaMessage(messageFieldXpath);
//        Add method to get DB output , and get Resultset as out put here.
//        String vObjRecordDropdown = KafkaPropertiesOR.getProperty("RecordDropdown");
//        Assert.assertEquals("PASS", Constants.key.click(vObjRecordDropdown, ""));
//        String vdropdown = Constants.KafkaPropertiesOR.getProperty("CD_OrgValue");
//        Assert.assertEquals("PASS", Constants.key.click(vdropdown, ""));
//        LogCapture.info("-----------------------Newest First is selected----------------------------");
//        //
        LogCapture.info("--------------User fetch Fund IN details from DB for kafka -------------------");
        Map<String, String> FundsOutKafkaMsg = Constants.key.verifyDBDetailsEnhanced("UAT", Constants.DynamicValue.get("<dynamic>"), "Fetch FundsOutDATA");
        System.out.println(FundsOutKafkaMsg.toString());
        Reusables.compareJsonAgainstGetTxnMappings(FundsOutKafkaMsg, jsonPath, mappingFilePath, false);
    }

    @Then("^Verify kafka message for \"([^\"]*)\" for Operation Type \"([^\"]*)\"$")
    public void verifyKafkaMessageForForOperationType(String mappingFilePath, String OperationType) throws Throwable {

        String messageFieldXpath= KafkaUI.getProperty("MessageFieldFundsIn");

        messageFieldXpath = messageFieldXpath.replace("{Operation}",OperationType).replace("{uniqueMessageId}", DynamicValue.get("<dynamic>"));

        JsonPath jsonPath = ReusableMethod.waitForKafkaMessage(messageFieldXpath);
//        Add method to get DB output , and get Resultset as out put here.
        LogCapture.info("--------------User fetch Fund IN details from DB for kafka -------------------");
        Map<String, String> FundsInKafkaMsg = Constants.key.verifyDBDetailsEnhanced("UAT", Constants.DynamicValue.get("<dynamic>"), "Fetch FundsInDATA");
        System.out.println(FundsInKafkaMsg.toString());
        Reusables.compareJsonAgainstGetTxnMappings(FundsInKafkaMsg, jsonPath, mappingFilePath,false);

    }

}
