package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.testng.Assert;

import java.util.Map;
import java.util.Objects;

/**
 * @author sunny.goyal
 */
public class CommonStepDefinition {

    static boolean isKafkaLaunched;

    @Given("^User launched application through \"([^\"]*)\" browser$")
    public void userLaunchedApplicationThrough(String data) throws Throwable {

        LogCapture.info(data + " Application is launching....");
        String vBrowserName = Constants.CONFIG.getProperty("browser");
        try {
            if (Objects.equals(Constants.JenkinsBrowser, null)){
                Constants.JenkinsBrowser = "";
            }
            else if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                vBrowserName = Constants.JenkinsBrowser;
                LogCapture.info("Browser is :" + Constants.JenkinsBrowser);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));

    }


    @Then("^Verify Kafka message audit logs for \"([^\"]*)\"$")
    public void verify_kafka_message_audit_logs_for_mappings_file(String auditLogSqlQueryProperty) {

        Map<String, String> actualAuditRecord = ReusableMethod.getSqlQueryResult(auditLogSqlQueryProperty, Constants.KafkaMessageCDID);
        System.out.println("Actual Audit Log for '" + Constants.KafkaMessageCDID + "' :: " + actualAuditRecord);
        ReusableMethod.verifyKafkaAuditLog(Constants.kafkaExpectedKeyValues, actualAuditRecord);
    }


    @Given("^User launches Kafka UI application for \"([^\"]*)\" topic$")
    public void launchKafkaUI(String topic) throws Exception {

        if(!isKafkaLaunched) {
            if(Constants.JenkinsBrowser == null || Constants.JenkinsBrowser.isEmpty()) {
                Constants.JenkinsBrowser = Constants.CONFIG.getProperty("browser");
            }

            Assert.assertTrue(Reusables.openBrowser("", Constants.JenkinsBrowser));
            LogCapture.info("Kafka UI is launching....");
            String kafkaUrl = Constants.CONFIG.getProperty("KafkaUIUrl");
            kafkaUrl = kafkaUrl.replace("{TOPIC}", topic).replace("{ENV}", Constants.JenkinsEnvironment).replace("{KEY}", Constants.KafkaMessageCDID);
            Assert.assertEquals("PASS", Reusables.navigate("", kafkaUrl));

            Reusables.loginToKafkaUI();
            isKafkaLaunched = true;
        } else {
            String kafkaUrl = Constants.CONFIG.getProperty("KafkaUIUrl");
            kafkaUrl = kafkaUrl.replace("{TOPIC}", topic).replace("{ENV}", Constants.JenkinsEnvironment).replace("{KEY}", Constants.KafkaMessageCDID);
            Assert.assertEquals("PASS", Reusables.navigate("", kafkaUrl));
            //Constants.driver.navigate().refresh();
        }
    }

}
