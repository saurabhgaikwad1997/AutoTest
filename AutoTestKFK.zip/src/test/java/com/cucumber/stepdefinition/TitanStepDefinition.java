package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;


import com.utility.LogCapture;
import cucumber.api.java.en.*;
import io.restassured.path.json.JsonPath;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assume;
import org.openqa.selenium.*;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;


import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.Constants.IndradayMSL_ID;
import static com.selenium.utillity.Reusables.executeQuery;


public class TitanStepDefinition {
    String WalletBalanceOnTab;
    String winHandleBefore;
    String PayeeFirstName;
    String PayeeLastName;
    String PayeeNickName;
    String PayeeCompanyName;
    String InstructionNumber;
    String CurrentBrowser = Constants.CONFIG.getProperty("browser");

    @Given("^User launched application through \"([^\"]*)\"$")
    public void userLaunchedApplicationThrough(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        Constants.vBrowserName = Constants.CONFIG.getProperty("browser");
        try {
            if (Objects.equals(Constants.JenkinsBrowser, null)) {
                Constants.JenkinsBrowser = "";
            } else if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                vBrowserName = Constants.JenkinsBrowser;
                LogCapture.info("Browser is :" + Constants.JenkinsBrowser);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));
    }


    @Given("^User navigate to Titan Application \"(.*?)\"$")
    public void user_navigate_to_Titan_Application(String vUrl) throws Throwable {
        LogCapture.info("Titan Applicatiion is loading....");
        String url = Constants.CONFIG.getProperty(vUrl);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
    }

    @When("^User enter UserName \"(.*?)\" password \"(.*?)\" and click log In button$")
    public void user_enter_UserName_password_and_click_log_In_button(String userName, String password) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.TitanLoginOR.getProperty("Titan_Username");
        String vObjPass = Constants.TitanLoginOR.getProperty("Titan_Password");
        LogCapture.info("User Name " + vUserName + ", Password is validated ....");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.TitanLoginOR.getProperty("LogInButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @When("^User enter UserName \"(.*?)\" Incorrect password \"(.*?)\" and click log In button$")
    public void user_enter_UserName_Incorrect_password_and_click_log_In_button(String usernName, String inPassword) throws Throwable {
        LogCapture.info("Validating incorrect credentials.......");
        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.TitanLoginOR.getProperty("Titan_Username");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        String vObjPass = Constants.TitanLoginOR.getProperty("Titan_Password");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));
        String vObjLoginButton = Constants.TitanLoginOR.getProperty("LogInButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @Then("^User successfully landed on Titan Dashboard page$")
    public void user_successfully_landed_on_Titan_Dashboard_page() throws Throwable {
        LogCapture.info("Dashboard loading ......");
        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vobjectDashboard = Constants.TitanLoginOR.getProperty("DashboardPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Dashboard"));
        LogCapture.info("Dasehboard loaded successfully");
    }

    @Then("^User clicks on Logout button and successfully logout from application$")
    public void user_clicks_on_Logout_button_and_successfully_logout_from_application() throws Throwable {
        String vObjLogOutLink = Constants.TitanLoginOR.getProperty("LogOutLink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLogOutLink, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjLogOutLink, ""));
        LogCapture.info("User clicks on Logout button..");
        Constants.key.pause("2", "");
    }

    @Then("^User should get error and should not be able to login in to Titan$")
    public void user_should_get_error_and_should_not_be_able_to_login_in_to_Titan() throws Throwable {
        String vObjInvalidLoginError = Constants.TitanLoginOR.getProperty("InvalidLoginError");
        LogCapture.info("Validating error message...");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjInvalidLoginError, "Invalid username or password."));
    }

    @Then("^User clicks on Customers option under Titan$")
    public void user_clicks_on_Customers_option_under_Titan() throws Throwable {
        String vObjTitanMenu = Constants.CreateFxTicketOR.getProperty("TitanMenu");
        Assert.assertEquals("PASS", Constants.key.click(vObjTitanMenu, ""));
        String vObjCustomers = Constants.CreateFxTicketOR.getProperty("Customers");
        LogCapture.info("Opening Customer detail page");
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomers, ""));
    }

    @Then("^User clicks on Filter option$")
    public void user_clicks_on_Filter_option() throws Throwable {
        String vObjFilter = Constants.CreateFxTicketOR.getProperty("Filter");
        LogCapture.info("Opening Filter section");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilter, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User search for client number \"(.*?)\" and hits Enter key$")
    public void user_enters_client_number_and_hits_Enter_key(String clientNumber) throws Throwable {
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, clientNumber));
        LogCapture.info("Searching for Client number : " + clientNumber);
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");
    }

    @Then("^User clicks on client number link to navigate to customer detail page$")
    public void user_clicks_on_client_number_link_to_navigate_to_customer_detail_page() throws Throwable {
        String vObjClientDetailLink = Constants.CreateFxTicketOR.getProperty("ClientDetailLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjClientDetailLink, ""));
        Constants.key.pause("2", "");

    }

    @And("^User clicks on (FX|Payment In|Payment Out|Payee|Instructions|RT) button$")
    public void user_clicks_on_fx_button(String Button) throws Throwable {
        String vObjButton = null;
        if (Button.equalsIgnoreCase("FX")) {
            vObjButton = Constants.CreateFxTicketOR.getProperty("Fxbutton");
        }
        if (Button.equalsIgnoreCase("Payment In")) {
            vObjButton = Constants.TitanPaymentInOR.getProperty("PaymentInButton");
        }
        if (Button.equalsIgnoreCase("Payment Out")) {
            vObjButton = Constants.TitanPaymentOutOR.getProperty("PaymentOutButton");
        }

        if (Button.equalsIgnoreCase("Payee")) {
            vObjButton = Constants.TitanPayeeOR.getProperty("PayeeButton");
        }
        if (Button.equalsIgnoreCase("Instructions")) {
            vObjButton = Constants.TitanInstructionsOR.getProperty("InstructionButton");
        }
        if (Button.equalsIgnoreCase("RT")) {
            vObjButton = Constants.TitanCustomersOR.getProperty("RegularTransferBtn");
            WebElement RegularTransferBtn = Constants.driver.findElement(By.xpath(vObjButton));
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView();", RegularTransferBtn);

        }


        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjButton, ""));
        LogCapture.info("User clicks on " + Button + " button..");
        Constants.key.pause("2", "");
    }

    @Then("^User selects Instructed by \"(.*?)\" Deal type\"(.*?)\" purpose of payment \"(.*?)\"( with Option flag ticked and clicks Next| with Option flag unticked and clicks Next| with SWAP flag ticked and clicks Next| with SWAP flag unticked and clicks Next| and clicks Next)$")
    public void user_selects_Instructed_by_Deal_type_purpose_of_payment_and_clicks_Next(String instructedBy, String DealType, String purposeOfPayment, String OptionFlag) throws Throwable {
        String vObjInstructedBy = Constants.CreateFxTicketOR.getProperty("InstructedBy");
        //Assert.assertEquals("PASS", Constants.key.click(vObjInstructedBy, ""));

        String vObjInstructedBySearch = Constants.CreateFxTicketOR.getProperty("InstructedBySearch");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructedBySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructedBySearch, instructedBy));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearch, "enter"));
        LogCapture.info("Instructed By: " + instructedBy + " is selected..");
        String vObjDealType = null;
        if (DealType.equalsIgnoreCase("Spot")) {
            vObjDealType = Constants.CreateFxTicketOR.getProperty("SpotDealType");
        }
        if (DealType.equalsIgnoreCase("Forward")) {
            vObjDealType = Constants.CreateFxTicketOR.getProperty("ForwardDealType");
        }
        if (DealType.equalsIgnoreCase("Limit")) {
            vObjDealType = Constants.CreateFxTicketOR.getProperty("LimitDealType");
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealType, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjDealType, ""));
        LogCapture.info("Deal type: " + DealType + " is selected...");

        if (OptionFlag.equalsIgnoreCase(" with Option flag ticked and clicks Next")) {
            String vObjOptionFlagCheckBox = Constants.CreateFxTicketOR.getProperty("OptionFlagCheckBox");
            Assert.assertEquals("PASS", Constants.key.click(vObjOptionFlagCheckBox, ""));
            LogCapture.info("User Ticks Option flag as true..");
            Constants.key.pause("2", "");
            if (DealType.equalsIgnoreCase("Spot")) {
                String vObjB2BFlagDisabled = Constants.CreateFxTicketOR.getProperty("B2BFlagDisabled");
                Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjB2BFlagDisabled, "visible"));
                LogCapture.info("B2B deal is disabled..");
            } else if (DealType.equalsIgnoreCase("Forward")) {
                String vObjB2BFlagDisabled = Constants.CreateFxTicketOR.getProperty("B2BFlagDisabled");
                Assert.assertEquals("PASS", Constants.key.notexist(vObjB2BFlagDisabled, ""));
                LogCapture.info("B2B deal is enable..");
            }
        }

        String vObjPurposeOfPayment = Constants.CreateFxTicketOR.getProperty("PurposeOfPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPurposeOfPayment, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPayment, ""));

        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vPurposeOfPaymentSearch_FireFox = Constants.CreateFxTicketOR.getProperty("PurposeOfPaymentSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vPurposeOfPaymentSearch_FireFox, ""));
            LogCapture.info("Purpose Of Payment: " + purposeOfPayment + " is selected...");
        } else {
            String vObjPurposeOfPaymentSearch = Constants.CreateFxTicketOR.getProperty("PurposeOfPaymentSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
            LogCapture.info("Purpose Of Payment: " + purposeOfPayment + " is selected...");
        }
        Constants.key.pause("2", "");
        String vObjSourceOfFundDownArrow = Constants.CreateFxTicketOR.getProperty("SourceOfFundDownArrow");
        boolean vSourceOfFund = Constants.driver.findElement(By.xpath(vObjSourceOfFundDownArrow)).isDisplayed();
        if (vSourceOfFund) {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSourceOfFundDownArrow, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSourceOfFundDownArrow, ""));
            //    Assert.assertEquals("PASS", Constants.key.click(vObjSourceOfFundDownArrow, ""));
            String vObjSourceOfFundSearch = Constants.CreateFxTicketOR.getProperty("SourceOfFundSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSourceOfFundSearch, "SAVINGS"));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSourceOfFundSearch_FireFox = Constants.CreateFxTicketOR.getProperty("SourceOfFundSearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSourceOfFundSearch_FireFox, ""));
                LogCapture.info("Source of funds: SAVINGS is selected...");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundSearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundSearch, "enter"));
                LogCapture.info("Source of funds: SAVINGS is selected...");
            }
        }
        if (OptionFlag.equalsIgnoreCase(" with SWAP flag ticked and clicks Next")) {

            String vObjSwapFlagHeaderFXPage = TitanFXTicketsOR.getProperty("SwapFlagHeaderFXPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapFlagHeaderFXPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSwapFlagHeaderFXPage, "visible"));

            String vObjSwapFlagFXPage = Constants.TitanFXTicketsOR.getProperty("SwapFlagFXPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapFlagFXPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSwapFlagFXPage, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapFlagFXPage, ""));
            LogCapture.info("User select Swap Flag option on FX page....");
        }

        Constants.key.pause("3", "");
        String vObjNext1Button = Constants.CreateFxTicketOR.getProperty("Next1Button");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjNext1Button, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @Then("^User selects Selling Currency \"(.*?)\" Buying currency \"(.*?)\" Selling amount \"(.*?)\"and clicks on Fetch rates button$")
    public void user_selects_Selling_Currency_Buying_currency_Selling_amount_and_clicks_on_Fetch_rates_button(String SellCurrency, String BuyCurrency, String sellingAmount) throws Throwable {
        String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
        //Assert.assertEquals("PASS", Constants.key.click(vObjCurrenciesAndAmounts, ""));
        LogCapture.info("User is on FX details page..");
        Constants.key.pause("7", "");
        //String vObjSellingCurrency = Constants.CreateFxTicketOR.getProperty("SellingCurrency");
        //Assert.assertEquals("PASS", Constants.key.click(vObjSellingCurrency, ""));
        String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
        //Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjSellingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");

        Constants.key.pause("2", "");
        String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

        String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
        LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

        String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
        LogCapture.info("Amount: " + sellingAmount + " is entered..");

        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
        Assert.assertEquals("PASS", Constants.key.click(vObjFetchRates, ""));
        Constants.key.pause("4", "");

    }

    @Then("^User clicks on Next button$")
    public void user_clicks_on_Next_button() throws Throwable {
        String vObjNext2Button = Constants.CreateFxTicketOR.getProperty("Next2Button");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNext2Button, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjNext2Button, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Clicked on Next button..");

    }

    @Then("^User selects method Bank$")
    public void user_selects_method_bank() throws Throwable {
        String vObjPaymentMethodBank = Constants.CreateFxTicketOR.getProperty("PaymentMethodBank");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodBank, ""));
    }

    @Then("^User clicks on Add Credit button$")
    public void user_clicks_on_add_credit_button() throws Throwable {
        String vObjAddCreditButton = Constants.CreateFxTicketOR.getProperty("AddCreditButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCreditButton, ""));
        Constants.key.pause("4", "");

    }

    @Then("^User clicks on Skip button$")
    public void user_clicks_on_Skip_button() throws Throwable {
        String vObjSkipButton = Constants.CreateFxTicketOR.getProperty("SkipButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSkipButton, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User clicks on Yes button for popup$")
    public void user_clicks_on_Yes_button_for_popup() throws Throwable {
        String vObjYesSkipButton = Constants.CreateFxTicketOR.getProperty("YesSkipButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjYesSkipButton, ""));
        LogCapture.info("Clicked on Yes button on pop-up..");
        Constants.key.pause("2", "");
    }

    @Then("^user clicks on Submit button$")
    public void user_clicks_on_Submit_button() throws Throwable {
        String vObjSubmitButton = Constants.CreateFxTicketOR.getProperty("SubmitButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubmitButton, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSubmitButton, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User clicked on Submit button..");
    }

    @Then("^User clicks on Close Slip button for (FX|Payee|RT|Payment in|Payment out)$")
    public void UserClicksOnCloseSlipButton(String TargetPage) throws Throwable {
        String vObjCloseSlipButton = null;
        if (TargetPage.equalsIgnoreCase("FX")) {
            vObjCloseSlipButton = Constants.CreateFxTicketOR.getProperty("CloseFxSlipButton");
        }
        if (TargetPage.equalsIgnoreCase("Payee")) {
            vObjCloseSlipButton = Constants.TitanPayeeOR.getProperty("ClosePayeeSlipButton");
        }
        if (TargetPage.equalsIgnoreCase("RT")) {
            vObjCloseSlipButton = Constants.TitanCustomersOR.getProperty("CloseRegularTransferSlipBtn");
        }
        if (TargetPage.equalsIgnoreCase("Payment in")) {
            vObjCloseSlipButton = Constants.TitanPaymentOutOR.getProperty("PaymentInCloseSlipButton");
        }
        if (TargetPage.equalsIgnoreCase("Payment out")) {
            vObjCloseSlipButton = Constants.TitanPaymentOutOR.getProperty("PaymentOutCloseSlipButton");
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCloseSlipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCloseSlipButton, ""));
        LogCapture.info("User clicked on Close Slip button...");
        Constants.key.pause("2", "");
    }

    @Then("^User clicks on customer number link to navigate to customer detail page$")
    public void user_clicks_on_customer_number_link_to_navigate_to_customer_detail_page() throws Throwable {
        Constants.key.pause("2", "");
        String vObjCustomerDetailLink = Constants.CreateFxTicketOR.getProperty("CustomerDetailLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerDetailLink, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User selects method Card selects card \"(.*?)\" enters CVV \"(.*?)\" for FX(| and No Warning Msg for EU customers)$")
    public void user_selects_method_Card_selects_card_enters_CVV(String selectCard, String cvv, String WarningMsg) throws Throwable {
        String vObjPaymentMethodCard = Constants.CreateFxTicketOR.getProperty("PaymentMethodCard");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodCard, ""));
        Constants.key.pause("2", "");
        LogCapture.info("clicking om Card tab...");
        if (WarningMsg.equalsIgnoreCase(" and No Warning Msg for EU customers")) {
            Constants.key.pause("2", "");
            String vObjFXSPOTWarningMsgEU = Constants.CreateFxTicketOR.getProperty("FXSPOTWarningMsgEU");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjFXSPOTWarningMsgEU, ""));
            LogCapture.info("Warning for EU customer is NOT visible while payment...");
        }
        String vObjSelectCard = Constants.CreateFxTicketOR.getProperty("SelectCard");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectCard, ""));
        Constants.key.pause("3", "");

        String vObjSelectCardSearch = Constants.CreateFxTicketOR.getProperty("SelectCardSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSelectCardSearch, selectCard));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectCardSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectCardSearch, "enter"));
        Constants.key.pause("3", "");
        LogCapture.info("Card searched and selected...");
        String vObjCardCvv = Constants.CreateFxTicketOR.getProperty("CardCvv");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardCvv, cvv));
        LogCapture.info("Card CVV entered: " + cvv);
    }


    @Then("^User clicks on client number\"([^\"]*)\" link to navigate to customer detail page$")
    public void userClicksOnClientNumberLinkToNavigateToCustomerDetailPage(String clientNumber) throws Throwable {

        String vclientNumberXpath = "//*[contains(text(),'" + clientNumber + "')]";
        //String vclientNumberXpath= Constants.TitanCustomersOR.getProperty("CustomerFirstLine");

        //String vObjCustomerDetailLink = Constants.CreateFxTicketOR.getProperty("CustomerDetailLink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
    }

    @And("^User clicks on Titan organization on Dashboard page$")
    public void userClicksOnTitanOrganisationOnDashboardPage() throws Throwable {
        Constants.key.pause("2", "");
        String vObjTitanOrgLink = Constants.TitanLoginOR.getProperty("TitanOrgLink");
        Assert.assertEquals("PASS", Constants.key.click(vObjTitanOrgLink, ""));
        Constants.key.pause("2", "");
    }

    @And("^User successfully landed on Dashboard In Titan page$")
    public void userSuccessfullyLandedOnDashboardInTitanPage() throws Throwable {
        String vObjDashboardInTitan = Constants.TitanLoginOR.getProperty("DashboardInTitan");
        Assert.assertEquals("PASS", Constants.key.click(vObjDashboardInTitan, ""));
        Constants.key.pause("2", "");
    }

    @And("^User Select \"([^\"]*)\" on Titan Dashboard$")
    public void userSelectOnTitanDashboard(String Organisation) throws Throwable {
        String vObjSelectOrganisationDropdown = Constants.TitanLoginOR.getProperty("SelectOrganisationDropdown");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectOrganisationDropdown, ""));
        Constants.key.pause("2", "");
        String OrganisationToBeSelected = "//input[@name='rad-org' and @value='" + Organisation + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(OrganisationToBeSelected, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(OrganisationToBeSelected, ""));
        LogCapture.info(Organisation + " is selected...");
        Constants.key.pause("2", "");
    }

    @And("^User Select \"([^\"]*)\" for respective Organisation$")
    public void userSelectForRespectiveOrganisation(String Section) throws Throwable {
        Constants.key.pause("2", "");
        String SectionToBeSelected = "//a[text()='" + Section + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SectionToBeSelected, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(SectionToBeSelected, ""));
        LogCapture.info("Clicked on " + Section + " section...");
        Constants.key.pause("2", "");
    }

    @And("^Verify that Wallet page is displayed with Alphabetical order$")
    public void verifyThatWalletPageIsDisplayedWithAlphabeticalOrder() throws Throwable {
        String vObjWalletPageMsg = Constants.TitanDashboardOR.getProperty("WalletPageMsg");
        String ExpectWalletPageMsg = "Select what you want to see above.";
        // Assert.assertEquals("PASS", Constants.key.verifyText(vObjWalletPageMsg, ExpectWalletPageMsg));
        LogCapture.info("User is on Wallet page...");
        Constants.key.pause("2", "");
        String WalletTypes = "//ul[@id='walletTypeId']/li";
        List<WebElement> WalletListTypes = Constants.driver.findElements(By.xpath(WalletTypes));
        char start = 'A';
        int j = 2;
        for (int i = 0; i < WalletListTypes.size(); i++) {
            String CurrentWalletListType = WalletListTypes.get(i).getAttribute("data-wallet-initial");
            LogCapture.info(CurrentWalletListType);
            if (CurrentWalletListType.equals("TOP")) {
                if (i == 0) {
                    LogCapture.info("TOP is displayed at Position " + i);
                } else {
                    LogCapture.info("TOP is NOT displayed at Position " + i);
                    Assert.fail();
                }
            } else if (CurrentWalletListType.equals("ALL")) {
                if (i == 1) {
                    LogCapture.info("ALL is displayed at Position " + i);
                } else {
                    LogCapture.info("ALL is NOT displayed at Position " + i);
                    Assert.fail();
                }
            } else if (CurrentWalletListType.matches("[A-Z]")) {

                if (i == j) {
                    LogCapture.info(start + " is displayed at Position " + i);
                    start++;
                    j++;
                } else {
                    LogCapture.info(start + " is NOT displayed at Position " + i);
                    Assert.fail();
                }
            }
        }
    }

    @And("^User selects Titan wallet as \"([^\"]*)\" and Wallet Currency as \"([^\"]*)\"$")
    public void userSelectsTitanWalletAsAndWalletCurrencyAs(String WalletSelection, String WalletCurrency) throws Throwable {
        String WalletSelected = "//ul[@id='walletTypeId']/li[@data-wallet-initial='" + WalletSelection + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelected, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(WalletSelected, ""));
        LogCapture.info("Wallet " + WalletCurrency + " is clicked...");
        Constants.key.pause("2", "");
        String WalletCurrencySelected;

        if (WalletSelection.equalsIgnoreCase("TOP")) {
            WalletCurrencySelected = "//div[@id='wallet-detail-top']//a[@data-wallet-currency='" + WalletCurrency + "']";
        } else {
            WalletCurrencySelected = "//div[@id='wallet-detail-" + WalletSelection.toUpperCase() + "']//a[@data-wallet-currency='" + WalletCurrency + "']";
        }
        LogCapture.info(WalletCurrencySelected);

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletCurrencySelected, ""));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(WalletCurrencySelected, ""));
        LogCapture.info("Wallet Currency " + WalletCurrency + " is clicked...");
        Constants.key.pause("2", "");
    }

    @Then("^User is able to view Wallet \"([^\"]*)\" details$")
    public void userIsAbleToViewWalletDetails(String WalletCurrency) throws Throwable {
        String WalletSelected = "//h3[@id='modal-currency' and text()='" + WalletCurrency + "']";
        String WalletSelectedFlag = "//img[@class='droplist__flag' and @alt='" + WalletCurrency + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelected, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(WalletSelected, "visible"));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelectedFlag, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(WalletSelectedFlag, "visible"));
        LogCapture.info("Wallet details with flag for " + WalletCurrency + " are displayed...");

        String vObjWalletBalanceHeader = Constants.TitanDashboardOR.getProperty("WalletBalanceHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletBalanceHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletBalanceHeader, "visible"));
        LogCapture.info("Wallet Balance header is visible...");

        String vObjReferenceColumn = Constants.TitanDashboardOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReferenceColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible...");

        String vObjDateTimeColumn = Constants.TitanDashboardOR.getProperty("DateTimeColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDateTimeColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateTimeColumn, "visible"));
        LogCapture.info("Date/Time Column is visible...");

        String vObjTypeColumn = Constants.TitanDashboardOR.getProperty("TypeColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTypeColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTypeColumn, "visible"));
        LogCapture.info("Type Column is visible...");

        String vObjAmountColumn = Constants.TitanDashboardOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountColumn, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible...");

        String vObjTransferToClientBtn = Constants.TitanDashboardOR.getProperty("TransferToClientBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransferToClientBtn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTransferToClientBtn, "enabled"));
        LogCapture.info("Transfer To Client button is enabled...");

        String vObjWalletBalanceOnPage = Constants.TitanDashboardOR.getProperty("WalletBalanceOnPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletBalanceOnPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletBalanceOnPage, "visible"));
        LogCapture.info("Wallet balance is visible...");

        LogCapture.info("Wallet details for " + WalletCurrency + " are Verified...");

    }

    @And("^User navigate to (Customers|Conflicts|Incoming Funds|Payments in|Payments out|FX tickets|Payees|Invoices|Profit Adjustment|B2B Queue|Deal Report|Add Deal) section under (Titan|Queues|Reports|Treasury)$")
    public void userNavigateToCustomerSectionUnderTitan(String Section, String Header) throws Throwable {
        String vObjTreasuryIcon = Constants.TitanDashboardOR.getProperty("TreasuryIcon");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjTreasuryIcon, "MoveToElement"));
        Constants.key.pause("2", "");
        if (Section.equalsIgnoreCase("Customers") && Header.equalsIgnoreCase("Titan")) {
            String vObjCustomersSection = Constants.TitanDashboardOR.getProperty("CustomersSection");
            String vObjProfilesInTitanHeader = Constants.TitanCustomersOR.getProperty("ProfilesInTitanHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomersSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomersSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomersSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProfilesInTitanHeader, ""));
            LogCapture.info("User is on Profiles in Titan page..");
        }
        if (Section.equalsIgnoreCase("Conflicts") && Header.equalsIgnoreCase("Titan")) {
            String vObjConflictsSection = Constants.TitanDashboardOR.getProperty("ConflictsSection");
            String vObjConflictsInTitanHeader = Constants.TitanConflictsOR.getProperty("ConflictsInTitanHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjConflictsSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictsSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjConflictsSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjConflictsInTitanHeader, ""));
            LogCapture.info("User is on Conflicts in Titan page..");
        }
        if (Section.equalsIgnoreCase("Incoming Funds") && Header.equalsIgnoreCase("Queues")) {
            String vObjIncomingFundsSection = Constants.TitanDashboardOR.getProperty("IncomingFundsSection");
            String vObjIncomingFundsHeader = Constants.TitanQueuesOR.getProperty("IncomingFundsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIncomingFundsSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjIncomingFundsSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjIncomingFundsSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIncomingFundsHeader, ""));
            LogCapture.info("User is on Incoming Funds in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments in") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuesPaymentInSection = Constants.TitanDashboardOR.getProperty("QueuesPaymentInSection");
            String vObjPaymentsInHeader = Constants.TitanQueuesOR.getProperty("PaymentsInHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuesPaymentInSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuesPaymentInSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuesPaymentInSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsInHeader, ""));
            LogCapture.info("User is on PaymentsIn in Titan page..");
        }
        if (Section.equalsIgnoreCase("FX tickets") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuefxTicketSection = Constants.TitanDashboardOR.getProperty("QueuefxTicketSection");
            String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuefxTicketSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuefxTicketSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuefxTicketSection, ""));
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
            LogCapture.info("User is on FX tickets in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payees") && Header.equalsIgnoreCase("Reports")) {
            String vObjPayeeReportSection = Constants.TitanDashboardOR.getProperty("PayeeReportSection");
            String vObjPayeeReportHeader = Constants.TitanPayeeOR.getProperty("PayeeReportHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeReportHeader, ""));
            LogCapture.info("User is on Payees report in Titan page..");
        }
        if (Section.equalsIgnoreCase("Add Deal") && Header.equalsIgnoreCase("Treasury")) {
            String vObjAddDealSection = Constants.TitanDashboardOR.getProperty("AddDealSection");
            String vObjAddDealPageHeader = Constants.TitanTreasuryOR.getProperty("AddDealPageHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddDealSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddDealSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddDealSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddDealPageHeader, ""));
            LogCapture.info("User is on Add booking in Titan page..");
        }
        if (Section.equalsIgnoreCase("B2B Queue") && Header.equalsIgnoreCase("Treasury")) {
            String vObjB2BSection = Constants.TitanDashboardOR.getProperty("B2BSection");
            String vObjUpdateB2BPage = Constants.TitanTreasuryOR.getProperty("UpdateB2BPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjB2BSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjB2BSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUpdateB2BPage, ""));
            LogCapture.info("User is on Update B2B in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments out") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuesPaymentOutSection = Constants.TitanDashboardOR.getProperty("QueuesPaymentOutSection");
            String vObjPaymentsOutHeader = Constants.TitanQueuesOR.getProperty("PaymentsOutHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuesPaymentOutSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuesPaymentOutSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuesPaymentOutSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsOutHeader, ""));
            LogCapture.info("User is on PaymentsOut in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments in") && Header.equalsIgnoreCase("Reports")) {
            String vObjPaymentInReportSection = Constants.TitanDashboardOR.getProperty("PaymentInReportSection");
            String vObjPaymentInReportPage = Constants.TitanReportsOR.getProperty("PaymentInReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentInReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInReportPage, "visible"));
            LogCapture.info("User is on Payments In Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments out") && Header.equalsIgnoreCase("Reports")) {
            String vObjPaymentOutReporSection = Constants.TitanDashboardOR.getProperty("PaymentOutReporSection");
            String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReporSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentOutReporSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutReporSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
            LogCapture.info("User is on Payments Out Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("FX tickets") && Header.equalsIgnoreCase("Reports")) {
            String vObjfxTicketReportSection = Constants.TitanDashboardOR.getProperty("fxTicketReportSection");
            String vObjFXTicketsHeader = Constants.TitanReportsOR.getProperty("FXticketsReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjfxTicketReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjfxTicketReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjfxTicketReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
            LogCapture.info("User is on FX tickets Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("Invoices") && Header.equalsIgnoreCase("Reports")) {
            String vObjInvoicesReportSection = Constants.TitanDashboardOR.getProperty("DeferredInvoiceSection");
            String vObjInvoicesReportPage = Constants.TitanReportsOR.getProperty("InvoicesReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvoicesReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInvoicesReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjInvoicesReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvoicesReportPage, ""));
            LogCapture.info("User is on Invoices in Titan page under Reports..");
        }
        if (Section.equalsIgnoreCase("Deal Report") && Header.equalsIgnoreCase("Treasury")) {
            String vObjDealReportSection = Constants.TitanDashboardOR.getProperty("DealReport");
            String vObjDealQueueHeader = Constants.TitanTreasuryOR.getProperty("DealQueueHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealQueueHeader, ""));
            LogCapture.info("User is on Deal queue in Titan page..");
        }

    }

    @Then("^User is able to view Customers page details in Titan and Not error message$")
    public void userIsAbleToViewCustomersDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjProfilesInTitanHeader = Constants.TitanCustomersOR.getProperty("ProfilesInTitanHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjProfilesInTitanHeader, "visible"));
        LogCapture.info("Profiles in Titan header is visible..");

        String vObjDownloadBtn = Constants.TitanCustomersOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download button visible..");

        String vObjOrganisationsColumn = Constants.TitanCustomersOR.getProperty("OrganisationsColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationsColumn, "visible"));
        LogCapture.info("Org Column is visible..");

        String vObjLegalEntityColumn = Constants.TitanCustomersOR.getProperty("LegalEntityColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLegalEntityColumn, "visible"));
        LogCapture.info("Legal Entity Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanCustomersOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjDateTimeCreatedColumn = Constants.TitanCustomersOR.getProperty("DateTimeCreatedColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateTimeCreatedColumn, "visible"));
        LogCapture.info("Date/Time Created Column is visible..");

        String vObjAccountColumn = Constants.TitanCustomersOR.getProperty("AccountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAccountColumn, "visible"));
        LogCapture.info("Account Column is visible..");

        String vObjClientNumberCoulmn = Constants.TitanCustomersOR.getProperty("ClientNumberCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberCoulmn, "visible"));
        LogCapture.info("Client Number Column is visible..");

        String vObjLegacyAccountCoulmn = Constants.TitanCustomersOR.getProperty("LegacyAccountCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLegacyAccountCoulmn, "visible"));
        LogCapture.info("Legacy Account Column is visible..");

        String vObjCountryCoulmn = Constants.TitanCustomersOR.getProperty("CountryCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCountryCoulmn, "visible"));
        LogCapture.info("Country Column is visible..");

        String vObjTypeColumn = Constants.TitanCustomersOR.getProperty("TypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTypeColumn, "visible"));
        LogCapture.info("Type Column is visible..");

        String vObjStatusColumn = Constants.TitanCustomersOR.getProperty("StatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatusColumn, "visible"));
        LogCapture.info("Status Column is visible..");

        String vObjAffiliateNumberColumn = Constants.TitanCustomersOR.getProperty("AffiliateNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAffiliateNumberColumn, "visible"));
        LogCapture.info("Affiliate Number Column is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        LogCapture.info("Customers page - All details are visible and Not error message..");

    }

    @Then("^User is able to view Conflicts page details in Titan and Not error message$")
    public void userIsAbleToViewConflictsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjConflictsInTitanHeader = Constants.TitanConflictsOR.getProperty("ConflictsInTitanHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictsInTitanHeader, "visible"));
        LogCapture.info("Conflicts page Header is visible..");

        String vObjConflictsPageLandingMsg = Constants.TitanConflictsOR.getProperty("ConflictsPageLandingMsg");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictsPageLandingMsg, "visible"));
        LogCapture.info("Conflicts Page Landing message is visible..");

        String vObjCustomerNumberHeader = Constants.TitanConflictsOR.getProperty("CustomerNumberHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerNumberHeader, "visible"));
        LogCapture.info("Customer Number header is visible..");

        String vObjCustomerNumberSearch = Constants.TitanConflictsOR.getProperty("CustomerNumberSearch");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerNumberSearch, "visible"));
        LogCapture.info("Customer Number Search field is visible..");

        String vObjSearchButton = Constants.TitanConflictsOR.getProperty("SearchButton");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSearchButton, "visible"));
        LogCapture.info("Search button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanConflictsOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Search Another customer is visible..");

        LogCapture.info("Conflicts page - All details are visible..");

    }

    @Then("^User is able to view Queues Incoming Funds page details in Titan and Not error message$")
    public void userIsAbleToViewQueuesIncomingFundsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjIncomingFundsHeader = Constants.TitanQueuesOR.getProperty("IncomingFundsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjIncomingFundsHeader, "visible"));
        LogCapture.info("Incoming Funds header is visible..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanQueuesOR.getProperty("DateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjOrganisationColumn = Constants.TitanQueuesOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanQueuesOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientNoColumn = Constants.TitanQueuesOR.getProperty("ClientNoColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNoColumn, "visible"));
        LogCapture.info("Client Number Column is visible..");

        String vObjClientNameColumn = Constants.TitanQueuesOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjDebtorColumn = Constants.TitanQueuesOR.getProperty("DebtorColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebtorColumn, "visible"));
        LogCapture.info("Debtor Column is visible..");

        String vObjCategoryColumn = Constants.TitanQueuesOR.getProperty("CategoryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCategoryColumn, "visible"));
        LogCapture.info("Category Column is visible..");

        String vObjSellCurrencyColumn = Constants.TitanQueuesOR.getProperty("SellCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellCurrencyColumn, "visible"));
        LogCapture.info("Sell Currency Column is visible..");

        String vObjAmountColumn = Constants.TitanQueuesOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible..");

        String vObjReferenceColumn = Constants.TitanQueuesOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible..");

        String vObjPaymentMethodColumn = Constants.TitanQueuesOR.getProperty("PaymentMethodColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentMethodColumn, "visible"));
        LogCapture.info("Payment Method Column is visible..");

        String vObjTitanStatusColumn = Constants.TitanQueuesOR.getProperty("TitanStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTitanStatusColumn, "visible"));
        LogCapture.info("Titan Status Column is visible..");

        String vObjAtlasStatusColumn = Constants.TitanQueuesOR.getProperty("AtlasStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAtlasStatusColumn, "visible"));
        LogCapture.info("Atlas Status Column is visible..");

        String vObjErrorReasonColumn = Constants.TitanQueuesOR.getProperty("ErrorReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjErrorReasonColumn, "visible"));
        LogCapture.info("Error Reason Column is visible..");


        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        LogCapture.info("Conflicts page - All details are visible..");

    }


    @Then("^User is able to view Queues Payment In page details in Titan and Not error message$")
    public void userIsAbleToViewQueuesPaymentInPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentsInHeader = Constants.TitanQueuesOR.getProperty("PaymentsInHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentsInHeader, "visible"));
        LogCapture.info("Payments In header is visible..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjSplitColumn = Constants.TitanQueuesOR.getProperty("SplitColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSplitColumn, "visible"));
        LogCapture.info("Split Column is visible..");

        String vObjOrganisationColumn = Constants.TitanQueuesOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjDateColumn = Constants.TitanQueuesOR.getProperty("DateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjStatementDateColumn = Constants.TitanQueuesOR.getProperty("StatementDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatementDateColumn, "visible"));
        LogCapture.info("Statement Date Column is visible..");

        String vObjValueDateColumn = Constants.TitanQueuesOR.getProperty("ValueDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjValueDateColumn, "visible"));
        LogCapture.info("Value Date Column is visible..");

        String vObjDebtorNameColumn = Constants.TitanQueuesOR.getProperty("DebtorNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebtorNameColumn, "visible"));
        LogCapture.info("Debtor Name Column is visible..");

        String vObjDebtorAccNoColumn = Constants.TitanQueuesOR.getProperty("DebtorAccNoColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebtorAccNoColumn, "visible"));
        LogCapture.info("Debtor Acc No Column is visible..");

        String vObjDebitEntryReasonColumn = Constants.TitanQueuesOR.getProperty("DebitEntryReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebitEntryReasonColumn, "visible"));
        LogCapture.info("Debit Entry Reason Column is visible..");

        String vObjSenderToReceiverInfoColumn = Constants.TitanQueuesOR.getProperty("SenderToReceiverInfoColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSenderToReceiverInfoColumn, "visible"));
        LogCapture.info("Sender To Receiver Info Column is visible..");

        String vObjCreditorReferenceColumn = Constants.TitanQueuesOR.getProperty("CreditorReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCreditorReferenceColumn, "visible"));
        LogCapture.info("Creditor Reference Column is visible..");

        String vObjRemitterReferenceColumn = Constants.TitanQueuesOR.getProperty("RemitterReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjRemitterReferenceColumn, "visible"));
        LogCapture.info("Remitter Reference Column is visible..");

        String vObjCCYCoulmn = Constants.TitanQueuesOR.getProperty("CCYCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYCoulmn, "visible"));
        LogCapture.info("CCY Coulmn is visible..");

        String vObjEntryTypeColumn = Constants.TitanQueuesOR.getProperty("EntryTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjEntryTypeColumn, "visible"));
        LogCapture.info("Entry Type Column is visible..");

        String vObjPaymentInAmountColumn = Constants.TitanQueuesOR.getProperty("PaymentInAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible..");

        String vObjFundTypeColumn = Constants.TitanQueuesOR.getProperty("FundTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFundTypeColumn, "visible"));
        LogCapture.info("Fund Type Column is visible..");

        String vObjFPTPColumn = Constants.TitanQueuesOR.getProperty("FPTPColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFPTPColumn, "visible"));
        LogCapture.info("FPTP Column is visible..");

        //Navigating on top of page
        JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        js.executeScript("window.scrollTo(0, 0)");
        Constants.key.pause("2", "");

        //Slid slider to right
        String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        Constants.key.pause("2", "");
        WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        int width = slider.getSize().getWidth();
        Actions move = new Actions(Constants.driver);
        move.moveToElement(slider, ((width * 10) / 100), 0).click();
        move.build().perform();
        LogCapture.info("Slider dragged to right...");
        Constants.key.pause("2", "");

        String vObjMethodColumn = Constants.TitanQueuesOR.getProperty("MethodColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjMethodColumn, "visible"));
        LogCapture.info("Method Column is visible..");

        String vObjClientNumberColumn = Constants.TitanQueuesOR.getProperty("ClientNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client Number (View all rules) column is visible..");

        String vObjPaymentInErrorReasonColumn = Constants.TitanQueuesOR.getProperty("PaymentInErrorReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInErrorReasonColumn, "visible"));
        LogCapture.info("Error Reason Column is visible..");

        String vObjStatusColumn = Constants.TitanQueuesOR.getProperty("StatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatusColumn, "visible"));
        LogCapture.info("Status Column is visible..");

        LogCapture.info("Payment In page - All details are visible..");


    }

    @Then("^User is able to view details such as CustomerName\"([^\"]*)\" CustomerNumber\"([^\"]*)\" Status\"([^\"]*)\" Brand\"([^\"]*)\" ClientType\"([^\"]*)\" Contact\"([^\"]*)\" CountryOfResidence\"([^\"]*)\" and Not error message$")
    public void userIsAbleToViewDetailsSuchAsCustomerNameCustomerNumberStatusBrandClientTypeContactCountryOfResidenceAndNotErrorMessage(String CustomerName, String CustomerNumber, String Status, String Brand, String ClientType, String Contact, String CountryOfResidence) throws Throwable {
        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String ExpectedCustomerName = "//h1[contains(text(),'" + CustomerName + " ')]";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedCustomerName, "visible"));
        LogCapture.info("Customer name: " + CustomerName + " is visible as expected..");

        String ExpectedCustomerNumber = "//h1[contains(text(),'#" + CustomerNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedCustomerNumber, "visible"));
        LogCapture.info("Customer Number: #" + CustomerNumber + " is visible as expected..");

        if (Status.equalsIgnoreCase("Active")) {
            String vObjActiveStatusIndicator = Constants.TitanCustomersOR.getProperty("ActiveStatusIndicator");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjActiveStatusIndicator, "visible"));
            LogCapture.info("Customer is Active...");
        }
        if (Status.equalsIgnoreCase("Inactive")) {
            String vObjInactiveStatusIndicator = Constants.TitanCustomersOR.getProperty("InactiveStatusIndicator");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInactiveStatusIndicator, "visible"));
            LogCapture.info("Customer is Inactive...");
        }

        String ExpectedBrand = "//dt[text()='Brand']//following-sibling::dd[text()='" + Brand + "']";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedBrand, "visible"));
        LogCapture.info("Brand: " + Brand + " is visible as expected..");

        String ExpectedClientType = "//dt[text()='Client Type']//following-sibling::dd[text()='" + ClientType + "']";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedClientType, "visible"));
        LogCapture.info("ClientType: " + ClientType + " is visible as expected..");

        String ExpectedContact = "//h2[text()='Contacts']//following::div[@class='tabs space-after']//a[text()='" + Contact + " ']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedContact, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedContact, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(ExpectedContact, ""));
        Constants.key.pause("2", "");
        String vObjContactPlusBtn = Constants.TitanCustomersOR.getProperty("ContactPlusBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjContactPlusBtn, ""));
        String ExpectedCountryOfResidence = "//dt[text()='Country of residence']//following-sibling::dd[text()='" + CountryOfResidence + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedCountryOfResidence, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedCountryOfResidence, "visible"));
        LogCapture.info("Country Of Residence: " + CountryOfResidence + " is visible as expected..");

    }

    @And("^User selects Payee\"([^\"]*)\" and clicks on Finished Adding Payment button and Yes button$")
    public void userSelectsPayeeAndClicksOnAddPaymentButton(String Payee) throws Throwable {
        String vObjAddAPaymentPage = Constants.CreateFxTicketOR.getProperty("AddAPaymentPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddAPaymentPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddAPaymentPage, "visible"));
        LogCapture.info("User is on 4 of 4: Add a Payment page...");

        String vObjSelectPayeeDownArrow = Constants.CreateFxTicketOR.getProperty("SelectPayeeDownArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectPayeeDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjSearchPayee = Constants.CreateFxTicketOR.getProperty("SearchPayee");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchPayee, ""));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSearchPayee_FireFox = Constants.CreateFxTicketOR.getProperty("SearchPayee_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSearchPayee_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
            LogCapture.info("Payee: " + Payee + " is selected..");
        }

        String vObjFXFinishedAddPaymentBtn = Constants.CreateFxTicketOR.getProperty("FXFinishedAddPaymentBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXFinishedAddPaymentBtn, ""));
        LogCapture.info("Clicking on Finished Adding Payment button...");

        String vObjAddPaymentYesButton = Constants.CreateFxTicketOR.getProperty("AddPaymentYesButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentYesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjAddPaymentYesButton, ""));
        LogCapture.info("Clicking on YES button for pop-up...");

    }

    @And("^User is on (Credit page|Add Payment page|Drawdown Credit page|Drawdown payments page) and clicks on Skip button$")
    public void userIsOnCreditPageAndClicksOnSkipButton(String page) throws Throwable {

        if (page.equalsIgnoreCase("Credit page")) {

            String vObjFXCreditPage = Constants.CreateFxTicketOR.getProperty("FXCreditPage");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXCreditPage, "visible"));
            LogCapture.info("User is on 3 of 4: Credit page...");

            String vObjFXCreditPageSkipBtn = Constants.CreateFxTicketOR.getProperty("FXCreditPageSkipBtn");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXCreditPageSkipBtn, ""));
            //    Assert.assertEquals("PASS", Constants.key.click(vObjFXCreditPageSkipBtn, ""));
            LogCapture.info("User clicks on SKIP button...");
        } else if (page.equalsIgnoreCase("Add Payment page")) {
            String vObjFXAddPaymentPage = Constants.CreateFxTicketOR.getProperty("ConfirmSkipBtn");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentPage, ""));
            LogCapture.info("User clicks on SKIP button...");
        }else if (page.equalsIgnoreCase("Drawdown Credit page")) {
            String vObjFXAddPaymentPage = Constants.CreateFxTicketOR.getProperty("drawdown_credits_skip");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentPage, ""));
            LogCapture.info("User clicks on SKIP button...");
        }else if (page.equalsIgnoreCase("Drawdown payments page")) {
            String vObjFXAddPaymentPage = Constants.CreateFxTicketOR.getProperty("drawdown_payments_skip");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentPage, ""));
            LogCapture.info("User clicks on SKIP button...");
        }
    }


    @And("^User clicks on Yes button for FX (Credit|Add Payment|Drawdown Credit|Drawdown Payment) popup$")
    public void userClicksOnYesButtonForFXCreditSkipPopup(String value) throws Throwable {
        if (value.equalsIgnoreCase("Credit")) {
            String vObjFXCreditSkipYesBtn = Constants.CreateFxTicketOR.getProperty("FXCreditSkipYesBtn");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXCreditSkipYesBtn, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFXCreditSkipYesBtn, ""));
            LogCapture.info("Clicking on Yes button for FX credit skip pop-up....");
            Constants.key.pause("2", "");
        } else if (value.equalsIgnoreCase("Add Payment")) {
            String vObjFXAddPaymentSkipYesBtn = Constants.CreateFxTicketOR.getProperty("FXAddpaymentSkipButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXAddPaymentSkipYesBtn, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentSkipYesBtn, ""));
            LogCapture.info("Clicking on Yes button for FX Add Payment page pop-up....");
            Constants.key.pause("2", "");

        }else if (value.equalsIgnoreCase("Drawdown Credit")) {
            String vObjFXAddPaymentSkipYesBtn = Constants.CreateFxTicketOR.getProperty("FXCreditDrawDownSkipButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXAddPaymentSkipYesBtn, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentSkipYesBtn, ""));
            LogCapture.info("Clicking on Yes button for Credit DrawDown page pop-up....");
            Constants.key.pause("2", "");

        }else if (value.equalsIgnoreCase("Drawdown Payment")) {
            String vObjFXAddPaymentSkipYesBtn = Constants.CreateFxTicketOR.getProperty("FXPaymentDrawDownSkipButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXAddPaymentSkipYesBtn, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentSkipYesBtn, ""));
            LogCapture.info("Clicking on Yes button for Payment DrawDown page pop-up....");
            Constants.key.pause("2", "");

        }


    }

    @And("^User clicks on CARDS tab under Linked to client(| for second time)$")
    public void clickOnCARDSTabUnderLinkedToClient(String Occurance) throws Throwable {
        if (Occurance.equalsIgnoreCase("")) {
            String vObjCARDSTab = Constants.CreateFxTicketOR.getProperty("CARDSTab");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCARDSTab, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCARDSTab, ""));
            LogCapture.info("Clicking on Cards tab...");
        }
        if (Occurance.equalsIgnoreCase(" for second time")) {
            String vObjCARDSTab = Constants.CreateFxTicketOR.getProperty("CARDSTab");
            String vObjWalletsTab = Constants.CreateFxTicketOR.getProperty("WalletsTab");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletsTab, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjWalletsTab, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjCARDSTab, ""));
            LogCapture.info("Clicking on Cards tab...");
        }
    }

    @And("^User clicks on Add Card button$")
    public void userClicksOnAddCardButton() throws Throwable {
        winHandleBefore = Constants.driver.getWindowHandle();
        String vObjAddCardBtn = Constants.CreateFxTicketOR.getProperty("AddCardBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCardBtn, ""));
        Constants.key.pause("4", "");
        LogCapture.info("Clicking on Add Card button...");

    }

    @And("^User enter only mandatory card details \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userEnterCardDetailsSuchAs(String CardType, String CardNumber, String CVV, String ExpireDate, String CardholderName, String Country, String Postcode, String Address, String City, String State) throws Throwable {
        Constants.key.pause("5", "");

        //Switch to child window
        for (String winHandle : Constants.driver.getWindowHandles()) {
            Constants.driver.switchTo().window(winHandle);
            Constants.driver.manage().window().maximize();
            LogCapture.info("Switched to Child window...");
        }

        //Perform operation on child window

        //String vObjAddNewCardPage = "//h1[contains(text(),'Add a new card')]";
        String vObjAddNewCardPage = Constants.CreateFxTicketOR.getProperty("AddNewCardPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddNewCardPage, ""));
        LogCapture.info("Add new card page is visible on child window...");

        Constants.key.pause("3", "");

        String vObjCardType = Constants.CreateFxTicketOR.getProperty("CardType");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardType, ""));
        LogCapture.info("Clicking Card type dropdown...");

        String vObjSelectCardType = "//input[@data-name='" + CardType + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCardType, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectCardType, ""));
        LogCapture.info("Card type: " + CardType + " is selected...");

        String vObjCardNumber = Constants.CreateFxTicketOR.getProperty("CardNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardNumber, CardNumber));
        LogCapture.info("Card number entered is: " + CardNumber);

        String vObjCVVnumber = Constants.CreateFxTicketOR.getProperty("CVVnumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjCVVnumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVVnumber, CVV));
        LogCapture.info("CVV entered is: " + CVV);

        String vObjCardExpireDate = Constants.CreateFxTicketOR.getProperty("CardExpireDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardExpireDate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardExpireDate, ExpireDate));
        LogCapture.info("Expire date entered is: " + ExpireDate);

        String vObjCardHolderName = Constants.CreateFxTicketOR.getProperty("CardHolderName");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardHolderName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardHolderName, CardholderName));
        LogCapture.info("Card holder name entered is: " + CardholderName);


        String vObjCountryDropdown = Constants.CreateFxTicketOR.getProperty("CountryDropdown");
        String vObjSearchCountry = Constants.CreateFxTicketOR.getProperty("SearchCountry");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountryDropdown, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchCountry, Country));
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSearchCountry_FireFox = Constants.CreateFxTicketOR.getProperty("SearchCountry_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSearchCountry_FireFox, ""));
            LogCapture.info("Country: " + Country + " is selected..");
        } else {
            if (Country.equalsIgnoreCase("UK")) {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "upArrow"));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "enter"));
                LogCapture.info("Country: " + Country + " is selected..");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "downArrow"));
                Constants.key.pause("2", "");
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "enter"));
                LogCapture.info("Country: " + Country + " is selected..");
            }
            LogCapture.info("Country: " + Country + " is selected..");
            //            if(Country.equalsIgnoreCase("UK")){
//                if(Constants.driver.findElement(By.xpath("//ul[@class='singlelist__options--scrollable']//li/label[@for='rad-card-country-114']")).isDisplayed())
//                {
//                    String vUKField = Constants.CreateFxTicketOR.getProperty("UKField1");
//                    Assert.assertEquals("PASS" , Constants.key.VisibleConditionWait(vUKField, ""));
//                    Assert.assertEquals("PASS" , Constants.key.MouseFunctions(vUKField , "DoubleClick"));
//                }
//                else if(Constants.driver.findElement(By.xpath("//ul[@class='singlelist__options--scrollable']//li/label[@for='rad-card-country-119']")).isDisplayed()) {
//                    String vUKField = Constants.CreateFxTicketOR.getProperty("UKField2");
//                    Assert.assertEquals("PASS" , Constants.key.VisibleConditionWait(vUKField, ""));
//                    Assert.assertEquals("PASS" , Constants.key.MouseFunctions(vUKField , "DoubleClick"));
//                }
//                else{
//                    String vUKField = Constants.CreateFxTicketOR.getProperty("UKField3");
//                    Assert.assertEquals("PASS" , Constants.key.VisibleConditionWait(vUKField, ""));
//                    Assert.assertEquals("PASS" , Constants.key.MouseFunctions(vUKField , "DoubleClick"));
//                }
//            }
//            else {
//                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCountry, "downArrow"));
//            }
//            LogCapture.info("Country: " + Country + " is selected..");
        }

        String vObjPostcode = Constants.CreateFxTicketOR.getProperty("Postcode");
        Assert.assertEquals("PASS", Constants.key.click(vObjPostcode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPostcode, Postcode));
        LogCapture.info("Postcode entered is: " + Postcode);

        String vObjCardAddress = Constants.CreateFxTicketOR.getProperty("CardAddress");
        Assert.assertEquals("PASS", Constants.key.click(vObjCardAddress, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardAddress, Address));
        LogCapture.info("Address entered is: " + Address);

        String vObjAddressTown = Constants.CreateFxTicketOR.getProperty("AddressTown");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressTown, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressTown, City));
        LogCapture.info("City entered is: " + City);

        String vObjAddressState = Constants.CreateFxTicketOR.getProperty("AddressState");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressState, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressState, State));
        LogCapture.info("State entered is: " + State);
        String vObjAddCardBtn = Constants.CreateFxTicketOR.getProperty("AddCardBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCardBtn, ""));
        LogCapture.info("Clicking on Add Card button...");
        //Constants.key.pause("5", "");
        //Constants.driver.close();

        String vObjCardAddedSuccessfulMsg = Constants.CreateFxTicketOR.getProperty("CardAddedSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCardAddedSuccessfulMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCardAddedSuccessfulMsg, "visible"));
        String ActualMsg = Constants.driver.findElement(By.xpath(vObjCardAddedSuccessfulMsg)).getText();
        if (ActualMsg.contains("added")) {
            LogCapture.info(ActualMsg);
        } else {
            LogCapture.info("Unable to add card... Error occured " + ActualMsg);
            Assert.fail();
        }
        Constants.key.pause("2", "");
        LogCapture.info("Card Added successfully message is visible...");

        // Switch back to the original browser (first window)
        Constants.driver.switchTo().window(winHandleBefore);
        String vObjBrand = "//dt[text()='Brand']";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBrand, "visible"));
    }

    @And("^User clicks on newly added card \"([^\"]*)\"$")
    public void userClicksOnNewlyAddedCard(String CardholderName) throws Throwable {

        String vObjSelectCard = "//tr[@id='customerCardDetail']//a[text()='" + CardholderName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCard, ""));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectCard, ""));
        LogCapture.info("user clicks on Card with name: " + CardholderName);
    }

    @And("^User is navigated to card details page$")
    public void userIsNavigatedToCardDetailsPage() throws Throwable {
        String vObjCardDetailsPage = Constants.CreateFxTicketOR.getProperty("CardDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCardDetailsPage, ""));
        LogCapture.info("User is on Card details page...");
    }

    @And("^User click on Delete card button$")
    public void userClickOnDeleteCardButton() throws Throwable {
        String vObjDeleteCardBtn = Constants.CreateFxTicketOR.getProperty("DeleteCardBtn");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjDeleteCardBtn, ""));
        LogCapture.info("Üser clisk on Delete card button..");
        String vObjDeleteCardYesBtn = Constants.CreateFxTicketOR.getProperty("DeleteCardYesBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeleteCardYesBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjDeleteCardYesBtn, ""));
        LogCapture.info("User clicks on Yes button..");
    }

    @And("^User is able to view Card deleted successful message$")
    public void userIsAbleToViewCardDeletedSuccessfulMessage() throws Throwable {
        String vObjCardDeleteSuccessfulMsg = Constants.CreateFxTicketOR.getProperty("CardDeleteSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCardDeleteSuccessfulMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCardDeleteSuccessfulMsg, "visible"));
        LogCapture.info("Card deleted successful message is visible...");
    }

    @And("^User selects Instructed by \"([^\"]*)\" Amount\"([^\"]*)\" Currency\"([^\"]*)\" and Click on Next button$")
    public void userSelectsInstructedByAmountCurrencyAndClickOnNextButton(String instructedBy, String Amount, String Currency) throws Throwable {

        String RandomNumber = RandomStringUtils.randomNumeric(3);
        InAmount = Double.parseDouble(RandomNumber);

        String vObjBasicDetailsPage = Constants.TitanPaymentInOR.getProperty("BasicDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPage, ""));
        LogCapture.info("1 of 2: Basic details page is visible..");

        String vObjInstructedBySearch = Constants.TitanPaymentInOR.getProperty("InstructedBySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructedBySearch, instructedBy));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearch, "enter"));
        LogCapture.info("Instructed By: " + instructedBy + " is selected..");

        if (Amount.equals("") || Amount.isEmpty()) {
            String vObjAmount = Constants.TitanPaymentInOR.getProperty("Amount");
            Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Double.toString(InAmount)));
            LogCapture.info("Amount: " + InAmount + " is entered..");

        } else {
            String vObjAmount = Constants.TitanPaymentInOR.getProperty("Amount");
            Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Amount));
            LogCapture.info("User enters amount: " + Amount);
        }

        String vObjCurrencyDropdownArrow = Constants.TitanPaymentInOR.getProperty("CurrencyDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyDropdownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCurrencyDropdownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencySearch = Constants.TitanPaymentInOR.getProperty("CurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencySearch, Currency));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vCurrencySearch_FireFox = Constants.TitanPaymentInOR.getProperty("CurrencySearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vCurrencySearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "enter"));
            LogCapture.info("Currency selected is: " + Currency);
        }
        Constants.key.pause("2", "");

        String vObjSourceOfFundsDropArrow = Constants.TitanPaymentInOR.getProperty("SourceOfFundsDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjSourceOfFundsDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjSourceOfFundsSearch = Constants.TitanPaymentInOR.getProperty("SourceOfFundsSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSourceOfFundsSearch, "SAVINGS"));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSourceOfFundsSearch_FireFox = Constants.TitanPaymentInOR.getProperty("SourceOfFundsSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSourceOfFundsSearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundsSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundsSearch, "enter"));
            LogCapture.info("Source of funds is: SAVINGS");
        }
        Constants.key.pause("2", "");
        String vObjBasicDetailsPageNextButton = Constants.TitanPaymentInOR.getProperty("BasicDetailsPageNextButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPageNextButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBasicDetailsPageNextButton, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User selects Payment method\"([^\"]*)\" for Titan Payment In$")
    public void userEntersPaymentMethodForTitanPaymentIn(String Method) throws Throwable {
        String vObjMethodDetailsPage = Constants.TitanPaymentInOR.getProperty("MethodDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMethodDetailsPage, ""));
        LogCapture.info("2 of 2: Method page is visible..");
        String vObjSelectPaymentInMethod = TitanPaymentInOR.getProperty("SelectPaymentinMethod");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPaymentInMethod, ""));

        String vObjSelectMethod = null;
        if (Method.equalsIgnoreCase("Card")) {
            vObjSelectMethod = Constants.TitanPaymentInOR.getProperty("PaymentMethodCardTab");
        }
        if (Method.equalsIgnoreCase("Bank")) {
            vObjSelectMethod = Constants.TitanPaymentInOR.getProperty("PaymentMethodBankTab");
        }
        if (Method.equalsIgnoreCase("DD")) {
            vObjSelectMethod = Constants.TitanPaymentInOR.getProperty("PaymentMethodDDTab");
        }

        LogCapture.info(vObjSelectMethod);
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectMethod, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectMethod, ""));
        LogCapture.info("Method selected is: " + Method);

    }


    @And("^User selects Card \"([^\"]*)\" enters CVV \"([^\"]*)\" for Payment In$")
    public void userSelectsMethodCardSelectsCardEntersCVVForPaymentIn(String CardNumberFirst, String CVV) throws Throwable {
        String vObjSelectCardDownArrow = Constants.TitanPaymentInOR.getProperty("SelectCardDownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCardDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectCardDownArrow, ""));
        Constants.key.pause("2", "");

        String vObjSearchCard = Constants.TitanPaymentInOR.getProperty("SearchCard");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchCard, CardNumberFirst));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSearchCard_FireFox = Constants.TitanPaymentInOR.getProperty("SearchCard_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSearchCard_FireFox, ""));
            LogCapture.info("Card selected..");
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCard, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchCard, "enter"));
            LogCapture.info("Card selected..");
        }

        String vObjCVVfield = Constants.TitanPaymentInOR.getProperty("CVVfield");
        Assert.assertEquals("PASS", Constants.key.click(vObjCVVfield, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVVfield, CVV));
        Constants.key.pause("2", "");
        LogCapture.info("CVV entered is: " + CVV);

    }

    @And("^User select Bank details for Titan Payment In$")
    public void userSelectBankDetailsForTitanPaymentIn() throws Throwable {

        String vObjSelectBankDownArrow = Constants.TitanPaymentInOR.getProperty("SelectBankDownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBankDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectBankDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjSelectBank = Constants.TitanPaymentInOR.getProperty("SelectBank");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectBank, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectBank, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Bank selected: I am not sure");
    }

    @And("^User clicks on Finish button for Payment In$")
    public void userClicksOnFinishButtonForPaymentIn() throws Throwable {
        String vObjFinshBtn = Constants.TitanPaymentInOR.getProperty("FinshBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFinshBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFinshBtn, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User clicks on Finish button...");
    }

    @Then("^User is able to view Payment In successful message with (Bank|DD) payment for client number\"([^\"]*)\"$")
    public void userIsAbleToViewPaymentInSuccessfulMessageWithBankPaymentForClientNumber(String PaymentType, String clientNumber) throws Throwable {
        String ExpectedPaymentInBankMethodSuccessMsg = "//*[@class='message--positive' and contains(text(),' It is expected that it will be processed. Your Instruction Number is " + clientNumber + "-')]/*[text()='Your payment in instruction has been submitted.']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedPaymentInBankMethodSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedPaymentInBankMethodSuccessMsg, "visible"));
        LogCapture.info("Payment In Success message for " + PaymentType + " method is displayed for client number: " + clientNumber);
    }

    @And("^User is able to view Payment (in|out) message before submitting$")
    public void userIsAbleToViewPaymentInMessageBeforeSubmitting(String PaymentType) throws Throwable {
        String vObjPaymentInBeforeSubmitMsg = "//p[text()='Your payment " + PaymentType + " instruction is complete and ready to submit. Please check the summary before submitting.']";
        LogCapture.info(vObjPaymentInBeforeSubmitMsg);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInBeforeSubmitMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInBeforeSubmitMsg, "visible"));
        LogCapture.info("Before submission message is visible...");
    }


    @Then("^User is able to view Payment In successful with Card payment for client number\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void userIsAbleToViewPaymentInSuccessfulWithCardPaymentForClientNumber(String clientNumber, String CardType, String CardNumber) throws Throwable {
        String CardNumberFirst = CardNumber.substring(0, 4);
        int TotalDigits=CardNumber.length();
        LogCapture.info(CardNumber);
        LogCapture.info(CardNumberFirst);
        String CardNumberLast = CardNumber.substring(TotalDigits-4, TotalDigits);
        LogCapture.info(CardNumberLast);
        String NumberOfStars="";
        for (int i=1;i<=(TotalDigits-8);i++){
            NumberOfStars=NumberOfStars+"*";
        }
        String ExpectedPaymentInBankMethodSuccessMsg = "//*[@class='message--positive' and contains(text(),' It is expected that it will be processed. Your Instruction Number is " + clientNumber + "-') and contains(text(),'AUTHCODE FOR " + CardType + "-" + CardNumberFirst + NumberOfStars + CardNumberLast + " is')]/*[text()='Your payment in instruction has been submitted.']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedPaymentInBankMethodSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedPaymentInBankMethodSuccessMsg, "visible"));
        LogCapture.info("Payment In Success message for bank method is displayed for client number: " + clientNumber);

        String vObjInstructionNumber = Constants.TitanPaymentInOR.getProperty("InstructionNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumber, ""));
        String text=Constants.key.getText(vObjInstructionNumber,"").split("-")[1];
        text=text.substring(0,9);
        Constants.InstructionNumber1=clientNumber+"-"+text;
        LogCapture.info("InstructionNumber1 ="+InstructionNumber1);
        LogCapture.info("1 of 2: Basic details page is visible..");
    }

    @And("^User selects Instructed by \"([^\"]*)\" Currency\"([^\"]*)\" and Click on Next button for Payment Out$")
    public void userSelectsInstructedByCurrencyAndClickOnNextButtonForPaymentOut(String instructedBy, String Currency) throws Throwable {
        String vObjPaymentOutBasicDetailsPage = Constants.TitanPaymentOutOR.getProperty("PaymentOutBasicDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutBasicDetailsPage, ""));
        LogCapture.info("1 of 2: Basic details page is visible..");

        String vObjInstructionBySearch = Constants.TitanPaymentOutOR.getProperty("InstructionBySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionBySearch, instructedBy));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionBySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionBySearch, "enter"));
        LogCapture.info("Instructed By: " + instructedBy + " is selected..");

        String vObjCurrencyDropdownArrow = Constants.TitanPaymentOutOR.getProperty("CurrencyDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyDropdownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCurrencyDropdownArrow, ""));
        Constants.key.pause("3", "");
        String vObjCurrencySearch = Constants.TitanPaymentOutOR.getProperty("CurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencySearch, Currency));
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "enter"));
        LogCapture.info("Currency selected is: " + Currency);

        Constants.key.pause("3", "");
        String vObjBasicDetailsPageNextButton = Constants.TitanPaymentOutOR.getProperty("BasicDetailPageNextBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPageNextButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBasicDetailsPageNextButton, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User selects Payee\"([^\"]*)\" PaymentDate Amount\"([^\"]*)\" PurposeOfPayment\"([^\"]*)\"and clicks on Add Payment button and Yes button for Payment Out$")
    public void userSelectsPayeePaymentDateAmountPurposeOfPaymentAndClicksOnAddPaymentButtonAndYesButtonForPaymentOut(String Payee, String Amount, String purposeOfPayment) throws Throwable {
        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");

        String vObjPaymentDate = Constants.TitanPaymentOutOR.getProperty("PaymentDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDate, ""));
        Constants.key.pause("2", "");
        String vObjTodaysDate = Constants.TitanPaymentOutOR.getProperty("TodaysDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjTodaysDate, ""));
        LogCapture.info("Selecting Todays date...");

        String vObjAmount = Constants.TitanPaymentOutOR.getProperty("Amount");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Amount));
        LogCapture.info("Amount entred is: " + Amount);


        String vObjPurposeOfPaymentDropdownArrow = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPurposeOfPaymentDropdownArrow, ""));
        String vObjPurposeOfPaymentSearch = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPaymentSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
        LogCapture.info("Purpose of Payment: " + purposeOfPayment + " is selected..");

        String vObjAddPaymentBtn = Constants.TitanPaymentOutOR.getProperty("AddPaymentBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddPaymentBtn, ""));
        LogCapture.info("Clicked on Add Payment button...");
        String vObjPaymentOutYesBtn = Constants.TitanPaymentOutOR.getProperty("PaymentOutYesBtn");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjPaymentOutYesBtn, ""));
        LogCapture.info("Clicking on YES button for pop-up...");
    }

    @And("^User clicks on Finish Adding Payment button for Payment Out$")
    public void userClicksOnFinishAddingPaymentButtonForPaymentOut() throws Throwable {
        String vObjPayOutPayeeFinishAddingPayment = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeFinishAddingPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayOutPayeeFinishAddingPayment, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayOutPayeeFinishAddingPayment, ""));
        LogCapture.info("Clicked on Finish Adding Payment button...");
    }

    @Then("^User is able to view Payment Out successful message for client number\"([^\"]*)\"$")
    public void userIsAbleToViewPaymentOutSuccessfulMessageForClientNumber(String clientNumber) throws Throwable {
        String ExpectedPaymentOutBankMethodSuccessMsg = "//*[contains(text(),'Your payment Out instruction has been submitted. It is expected that it will be processed.Your Instruction Number is " + clientNumber + "-')]";
        LogCapture.info(ExpectedPaymentOutBankMethodSuccessMsg);
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedPaymentOutBankMethodSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedPaymentOutBankMethodSuccessMsg, "visible"));
        String PaymentOutSuccessMsg = Constants.driver.findElement(By.xpath(ExpectedPaymentOutBankMethodSuccessMsg)).getText();
        String[] vInstructionNumber = PaymentOutSuccessMsg.split("Your Instruction Number is ");
        InstructionNumber = vInstructionNumber[1].replace(".", "");
        LogCapture.info("Payment Out Success message for bank method is displayed for client number: " + clientNumber);
    }

    @And("^User selects Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\" according to DealType\"([^\"]*)\" UpperRatePercentage\"([^\"]*)\" and clicks on Fetch rates button(| for forward fixed type deal)$")
    public void userSelectsSellingCurrencyBuyingCurrencySellingAmountAccordingToDealTypeUpperRateAndClicksOnFetchRatesButton(String SellCurrency, String BuyCurrency, String sellingAmount, String DealType, String UpperRatePercentage, String ForwardSubType) throws Throwable {
        if (DealType.equalsIgnoreCase("Spot")) {
            String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSellingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSellingCurrencySearch_FireFox, ""));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            }

            Constants.key.pause("2", "");
            String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

            String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vBuyingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vBuyingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
                LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");
            }

            String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
            LogCapture.info("Amount: " + sellingAmount + " is entered..");

            String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
            LogCapture.info("User clicks on Fetch Rates button..");
            Constants.key.pause("4", "");
            String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
            String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
            if (LiveRate == null) {
                Assert.fail();
                LogCapture.info("Fetching rates.. Live Rate is Null...");
            } else {
                LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
            }
            LogCapture.info("Rates fetched..");

        }


        if (DealType.equalsIgnoreCase("Limit")) {
            String vObjLimitOrderCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("LimitOrderCurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLimitOrderCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("LimitOrderSellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
            LogCapture.info("Sell currency: " + SellCurrency + " is selected..");

            Constants.key.pause("2", "");
            String vObjLimitOrderBuyingCurrency = Constants.CreateFxTicketOR.getProperty("LimitOrderBuyingCurrencyDropArrow");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrency, ""));

            String vObjLimitOrderBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("LimitOrderBuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderBuyingCurrencySearch, BuyCurrency));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "enter"));
            LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

            String vObjLimitOrderSellingAmount = Constants.CreateFxTicketOR.getProperty("LimitOrderSellingAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderSellingAmount, sellingAmount));
            LogCapture.info("Amount: " + sellingAmount + " is entered..");

            String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
            LogCapture.info("User clicks on Fetch Rates button..");
            Constants.key.pause("4", "");
            String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
            String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
            if (LiveRate == null) {
                Assert.fail();
                LogCapture.info("Fetching rates.. Live Rate is Null...");
            } else {
                LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
            }
            LogCapture.info("Rates fetched..");

            String vObjSuggestedRate = Constants.CreateFxTicketOR.getProperty("SuggestedRate");
            String vSuggestedRateValNum = Constants.driver.findElement(By.xpath(vObjSuggestedRate)).getText();
            Constants.key.pause("2", "");
            int UpperRate = Integer.parseInt(UpperRatePercentage);
            double d = Double.parseDouble(vSuggestedRateValNum);
            double vDoubleCurrRate = ((UpperRate * d / 100) + d);
            String vTargetValueCalculated = Double.toString(vDoubleCurrRate);

            String vObjLimitLimitOrderUpperRate = Constants.CreateFxTicketOR.getProperty("LimitOrderUpperRate");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitLimitOrderUpperRate, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitLimitOrderUpperRate, vTargetValueCalculated));
            LogCapture.info("Upper rate entered is: " + vTargetValueCalculated);

            String vObjLimitOrderEndDateNoneCheckbox = Constants.CreateFxTicketOR.getProperty("LimitOrderEndDateNoneCheckbox");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderEndDateNoneCheckbox, ""));
            LogCapture.info("End date-good until cancelled selected...");
            Constants.key.pause("2", "");
        }

        if (DealType.equalsIgnoreCase("Forward")) {
            String vObjLimitOrderCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("ForwardOrderCurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLimitOrderCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("3", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vForwardOrderSellingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vForwardOrderSellingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            }

            Constants.key.pause("2", "");
            String vObjLimitOrderBuyingCurrency = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencyDropArrow");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrency, ""));

            String vObjLimitOrderBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderBuyingCurrencySearch, BuyCurrency));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vForwardOrderBuyingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vForwardOrderBuyingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "enter"));
                LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");
            }

            String vObjLimitOrderSellingAmount = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderSellingAmount, sellingAmount));
            LogCapture.info("Amount: " + sellingAmount + " is entered..");

            String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
            LogCapture.info("User clicks on Fetch Rates button..");
            Constants.key.pause("4", "");
            String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
            String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
            if (LiveRate == null) {
                Assert.fail();
                LogCapture.info("Fetching rates.. Live Rate is Null...");
            } else {
                LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
            }
            LogCapture.info("Rates fetched..");

            String vObjForwardOrderClientRatePercentage = Constants.CreateFxTicketOR.getProperty("ForwardOrderClientRatePercentage");
            Assert.assertEquals("PASS", Constants.key.click(vObjForwardOrderClientRatePercentage, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardOrderClientRatePercentage, UpperRatePercentage));
            LogCapture.info("Client rate % entered is: " + UpperRatePercentage);

            if (ForwardSubType.equalsIgnoreCase(" for forward fixed type deal")) {
                String vObjFixedForwardType = Constants.CreateFxTicketOR.getProperty("FixedForwardType");
                Assert.assertEquals("PASS", Constants.key.click(vObjFixedForwardType, ""));
                Constants.key.pause("2", "");
                LogCapture.info("Fixed forward selected..");
                String vObjSelectDate = Constants.CreateFxTicketOR.getProperty("SelectDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjSelectDate, ""));
                Constants.key.pause("2", "");
                String vObjDateMonthChangeNextBtn = Constants.CreateFxTicketOR.getProperty("DateMonthChangeNextBtn");
                Assert.assertEquals("PASS", Constants.key.click(vObjDateMonthChangeNextBtn, ""));
                Constants.key.pause("2", "");
                String vObjToDate = Constants.CreateFxTicketOR.getProperty("ToDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
                Constants.key.pause("2", "");
                LogCapture.info("Date selected...");
            } else {
                String vObjForwardOrderFromDate = Constants.CreateFxTicketOR.getProperty("ForwardOrderFromDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjForwardOrderFromDate, ""));
                Constants.key.pause("3", "");
                String vObjTodaysFromDate = Constants.CreateFxTicketOR.getProperty("TodaysFromDate");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTodaysFromDate, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjTodaysFromDate, ""));
                LogCapture.info("From Date selected...");
                String vObjForwardOrderToDate = Constants.CreateFxTicketOR.getProperty("ForwardOrderToDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjForwardOrderToDate, ""));
                Constants.key.pause("2", "");
                String vObjDateMonthChangeNextBtn = Constants.CreateFxTicketOR.getProperty("DateMonthChangeNextBtn");
                Assert.assertEquals("PASS", Constants.key.click(vObjDateMonthChangeNextBtn, ""));
                Constants.key.pause("2", "");
                String vObjToDate = Constants.CreateFxTicketOR.getProperty("ToDate");
                Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
                Constants.key.pause("2", "");
                LogCapture.info("To Date selected...");
            }
        }

    }

    @Then("^User is able to view FX creation (successful message|decline message) for DealType\"([^\"]*)\" client number\"([^\"]*)\"$")
    public void userIsAbleToViewFXCreationSuccessfulMessageForDealTypeClientNumber(String message, String DealType, String clientNumber) throws Throwable {
        if (message.equalsIgnoreCase("successful message")) {
            String ExpectedFXSuccessfulMsgPart1 = null;
            String ExpectedFXSuccessfulMsgPart2 = null;
            if (DealType.equalsIgnoreCase("spot") || DealType.equalsIgnoreCase("Forward")) {
                ExpectedFXSuccessfulMsgPart1 = "//*[@id='fx-done-message' and contains(text(),'Thank you. Your FX instruction(" + clientNumber + "-')]";
                ExpectedFXSuccessfulMsgPart2 = "//*[@id='fx-done-message' and contains(text(),') has been created.')]";
            }
            if (DealType.equalsIgnoreCase("Limit")) {
                ExpectedFXSuccessfulMsgPart1 = "//*[@id='fx-done-message' and contains(text(),'Thank you. Your Drawdown (" + clientNumber + "-')]";
                ExpectedFXSuccessfulMsgPart2 = "//*[@id='fx-done-message' and contains(text(),') has been created.')]";
            }if (DealType.equalsIgnoreCase("Drawdown")) {
                ExpectedFXSuccessfulMsgPart1 = "//*[@id='drawdown-done-message' and contains(text(),'Thank you. Your Drawdown (" + clientNumber + "-')]";
                ExpectedFXSuccessfulMsgPart2 = "//*[@id='drawdown-done-message' and contains(text(),') has been created for FX (" + clientNumber + "-')]";
            }
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExpectedFXSuccessfulMsgPart1, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedFXSuccessfulMsgPart1, "visible"));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(ExpectedFXSuccessfulMsgPart2, "visible"));
            String vObjActualFXSuccessfulMsg;
            if (DealType.equalsIgnoreCase("Drawdown")) {
                vObjActualFXSuccessfulMsg=Constants.CreateFxTicketOR.getProperty("drawdownSuccessMsg");
            }else {
                vObjActualFXSuccessfulMsg=Constants.CreateFxTicketOR.getProperty("FXSuccessMsg");
            }
            String ActualFXSuccessMsg = Constants.driver.findElement(By.xpath(vObjActualFXSuccessfulMsg)).getText();

            String[] vInstructionNumber = ActualFXSuccessMsg.split("-");
            String InstructionNumberOnly1 = vInstructionNumber[0].replaceAll("[^0-9]", "");
            String InstructionNumberOnly2 = vInstructionNumber[1].replaceAll("[^0-9]", "");
            if(InstructionNumberOnly2.contains(InstructionNumberOnly1)){
                InstructionNumberOnly2=InstructionNumberOnly2.replace(InstructionNumberOnly1,"");
            }
            InstructionNumber = InstructionNumberOnly1 + "-" + InstructionNumberOnly2;
            LogCapture.info("Instruction Number is: " + InstructionNumber);
            LogCapture.info("Actual FX creation Success message: " + ActualFXSuccessMsg);
            LogCapture.info("FX creation Success message is displayed for client number: " + clientNumber);
        } else if (message.equalsIgnoreCase("decline message")) {
            String ForwardDeclineText = Constants.CONFIG.getProperty("FXForwardDeclineText");
            String vObjDeclineMsg = Constants.CreateFxTicketOR.getProperty("FXForwardDeclineMsgText");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeclineMsg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjDeclineMsg, ForwardDeclineText));
            LogCapture.info("Decline text is visible on the page for the deal type " + DealType + " , " + clientNumber);
        }
    }

    @And("^User enters Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" and Clicks on Next button$")
    public void userEntersPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAndClicksOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country) throws Throwable {
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName + RandomStringUtils.randomAlphabetic(5);
            String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName + RandomStringUtils.randomAlphabetic(5);
            String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCompanyPayeeType, "selected"));
            LogCapture.info("Company Payee type is selected..");

            String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");
            PayeeCompanyName = CompanyName + RandomStringUtils.randomAlphabetic(5);
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vCurrencyReceiveSearch_FireFox = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vCurrencyReceiveSearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
            LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");
        }

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vCountrySearch_FireFox = Constants.TitanPayeeOR.getProperty("CountrySearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vCountrySearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        }
        LogCapture.info("Country selected is: " + Country);

        Constants.key.pause("3", "");


        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, "400066"));
        Constants.key.pause("2", "");

        String vObjGetAddressButton = Constants.TitanCustomersOR.getProperty("GetAddressButton");
        // Assert.assertEquals("PASS", Constants.key.click(vObjGetAddressButton, ""));
        Constants.key.pause("2", "");

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, "Avenue"));
        Constants.key.pause("2", "");

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, "New York"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeTownField, "tab"));
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" BankCodeType\"([^\"]*)\" BankCode\"([^\"]*)\" and click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberBankCodeTypeABANumberSWIFTCodeAndClickOnNextButton(String AccountNumber, String BankCodeType, String BankCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        if (AccountNumber.equalsIgnoreCase("")) {
            LogCapture.info("Account number NOT required but IBAN number for EUR required..");
            String vObjIBANNumber = Constants.TitanPayeeOR.getProperty("IBANNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjIBANNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIBANNumber, "ES9121000418450200051332"));
            LogCapture.info("IBAN number is entered..");


        } else {
            String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
            LogCapture.info("Account number is entered..");
        }
        if (BankCodeType.equalsIgnoreCase("ABA")) {
            String vObjABANumber = Constants.TitanPayeeOR.getProperty("ABANumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjABANumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjABANumber, BankCode));
            LogCapture.info("ABA number is entered..");

        }
        if (BankCodeType.equalsIgnoreCase("SWIFT")) {
            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number is entered..");
        }

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");
        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");

    }

    @And("^User is on Additional details page and clicks on Skip button$")
    public void userIsOnAdditionalDetailsPageAndClicksOnSkipButton() throws Throwable {
        String vObjAdditionalDetailsPage = Constants.TitanPayeeOR.getProperty("AdditionalDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAdditionalDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAdditionalDetailsPage, "visible"));
        LogCapture.info("User is on 3 of 3: Additional details page...");

        String vObjAdditionalDetailsSkipBtn = Constants.TitanPayeeOR.getProperty("AdditionalDetailsSkipBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAdditionalDetailsSkipBtn, ""));
        LogCapture.info("User clicks on SKIP button...");
    }

    @And("^Before submission message is displayed for (Payee|RT|FX)$")
    public void beforeSubmissionMessageIsDisplayedForPayee(String Type) throws Throwable {
        String vObjBeforeSubmitMsg = null;
        if (Type.equalsIgnoreCase("Payee")) {
            vObjBeforeSubmitMsg = Constants.TitanPayeeOR.getProperty("PayeeBeforeSubmitMsg");
        }
        if (Type.equalsIgnoreCase("RT")) {
            vObjBeforeSubmitMsg = Constants.TitanCustomersOR.getProperty("RTBeforeSuccessMsg");
        }
        if (Type.equalsIgnoreCase("FX")) {
            vObjBeforeSubmitMsg = Constants.CreateFxTicketOR.getProperty("FXBeforeSubmitMsg");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBeforeSubmitMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBeforeSubmitMsg, "visible"));
        LogCapture.info("Before submission message is visible...");
    }

    @And("^User is able to view Payee (created|updated) successful message$")
    public void userIsAbleToViewPayeeCreatedSuccessfulMessage(String TargetMsg) throws Throwable {
        if (TargetMsg.equalsIgnoreCase("created")) {
            String vObjPayeeSuccessMsg = Constants.TitanPayeeOR.getProperty("PayeeSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeSuccessMsg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeSuccessMsg, "visible"));
            LogCapture.info("Payee created successfully message is displayed.....");
        }
        if (TargetMsg.equalsIgnoreCase("updated")) {
            String vObjPayeeUpdatedMsg = Constants.TitanPayeeOR.getProperty("PayeeUpdatedMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeUpdatedMsg, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeUpdatedMsg, "visible"));
            LogCapture.info("Payee updated successfully message is displayed.....");
        }
    }

    @And("^User search for Organisations\"([^\"]*)\" Currency\"([^\"]*)\" and EntryType\"([^\"]*)\" and hits Enter key$")
    public void userSearchForOrganisationsCurrencyAndEntryTypeAndHitsEnterKey(String Organisations, String Currency, String EntryType) throws Throwable {

        String vObjFilterSearchOrganisationDropdownArrow = Constants.TitanQueuesOR.getProperty("FilterSearchOrganisationDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilterSearchOrganisationDropdownArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisationList = Constants.TitanQueuesOR.getProperty("OrganisationOptionsList");
        List<WebElement> allElements = Constants.driver.findElements(By.xpath(vObjOrganisationList));
        for (WebElement ele : allElements) {
            String Currentelement = ele.getText();
            ele.click();
            Constants.key.pause("1", "");
            LogCapture.info("User deselected: " + Currentelement);
        }

        String vObjOrganisation = "//ul[@class='multilist__options']//input[@value='" + Organisations + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisations);

        String vObjCurrenciesDropArrow = Constants.TitanQueuesOR.getProperty("CurrenciesDropArrow");
        //Assert.assertEquals("PASS", Constants.key.click(vObjCurrenciesDropArrow, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCurrenciesDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrenciesSearch = Constants.TitanQueuesOR.getProperty("CurrenciesSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrenciesSearch, Currency));
        Constants.key.pause("2", "");
        String vObjCurrencyMousehover = "//*[@value='" + Currency + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyMousehover, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjCurrencyMousehover, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCurrencyMousehover, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrenciesDropArrow, ""));
        LogCapture.info("Currency: " + Currency + " is selected..");

        String vObjEntryTypeDownArrow = Constants.TitanQueuesOR.getProperty("EntryTypeDownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEntryTypeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjEntryTypeDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjEntryType = "//*[@value='" + EntryType + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEntryType, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjEntryType, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjEntryTypeDownArrow, ""));
        LogCapture.info("Entry Type selected: " + EntryType);

        String vObjAmountHeader = Constants.TitanQueuesOR.getProperty("AmountHeader");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmountHeader, ""));

        String vObjApplyBtn = Constants.TitanQueuesOR.getProperty("ApplyBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjApplyBtn, ""));
        Constants.key.pause("2", "");
        LogCapture.info("USer clicks on Apply button..");
    }

    @And("^User is on clicks on any FX from the list$")
    public void userIsOnClicksOnAnyFXFromTheList() throws Throwable {
        String vObjPageNavigation = Constants.TitanFXTicketsOR.getProperty("PageNavigation");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPageNavigation, ""));
        Constants.key.pause("2", "");
        String vObjRandomFX = "//*[@id='fxTicketQueueTableBody']/tr[1]/td[7]/a";
        //String ReferenceNumber=Constants.driver.findElement(By.xpath(vObjRandomFX)).getText();
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRandomFX, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjRandomFX, ""));
        LogCapture.info("User selected FX with Reference number: ");
    }

    @And("^User navigates to FX ticket details page and clicks on Cancel FX button and Yes button$")
    public void userNavigatesToFXTicketDetailsPageAndClicksOnCancelFXButton() throws Throwable {
        String vObjFXTicketQueueHeader = Constants.TitanFXTicketsOR.getProperty("FXTicketQueueHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketQueueHeader, ""));
        LogCapture.info("User is on FX ticket for client page...");
        String vObjCancelFXBtn = Constants.TitanFXTicketsOR.getProperty("CancelFXBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjCancelFXBtn, ""));
        LogCapture.info("User clicks on Cancel FX button..");
        Constants.key.pause("2", "");

        String vObjCancelReasonDownArrow = Constants.TitanFXTicketsOR.getProperty("CancelReasonDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCancelReasonDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCancelReason1 = Constants.TitanFXTicketsOR.getProperty("CancelReason1");
        Assert.assertEquals("PASS", Constants.key.click(vObjCancelReason1, ""));
        LogCapture.info("User selects Cancel reason..");
        String vObjApplyBtn = Constants.TitanFXTicketsOR.getProperty("ApplyBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjApplyBtn, ""));
        LogCapture.info("User clicks on Apply button..");
        Constants.key.pause("2", "");

        String vObjPopUpYesBtn = Constants.TitanFXTicketsOR.getProperty("PopUpYesBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjPopUpYesBtn, ""));
        LogCapture.info("User clicks on Yes button..");

    }

    @And("^User navigates to FX ticket details page and clicks on Amend FX button and enters details \"([^\"]*)\" \"([^\"]*)\" and (Yes button|Select SWAP flag Yes button|Select SWAP flag Yes button for Forward Deal)$")
    public void userNavigatesToFXTicketDetailsPageAndClicksOnAmendFXButtonAndEntersDetailsAndYesButton(String DealRate, String NewSellAmount, String SwapButton) throws Throwable {
        String vObjFXTicketQueueHeader = Constants.TitanFXTicketsOR.getProperty("FXTicketQueueHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketQueueHeader, ""));
        LogCapture.info("User is on FX ticket for client page...");

        String vObjAmendFX = Constants.TitanFXTicketsOR.getProperty("AmendFX");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmendFX, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjAmendFX, ""));
        LogCapture.info("User clicks on Amend FX button..");

        Constants.key.pause("3", "");
        String vObjDateCalender = "";
        String vObjSwapFlagHeaderAmendFXPage = "";
        String vObjSwapFlagAmendFXPage = "";

        if (SwapButton.equalsIgnoreCase("Select SWAP flag Yes button for Forward Deal")) {
            vObjDateCalender = Constants.TitanFXTicketsOR.getProperty("CalenderDateTabForward");
            vObjSwapFlagHeaderAmendFXPage = TitanFXTicketsOR.getProperty("SwapFlagHeaderAmendFXPageForward");
            vObjSwapFlagAmendFXPage = Constants.TitanFXTicketsOR.getProperty("SwapFlagAmendFXPageForward");
        } else {
            vObjDateCalender = Constants.TitanFXTicketsOR.getProperty("CalenderDateTab");
            vObjSwapFlagHeaderAmendFXPage = TitanFXTicketsOR.getProperty("SwapFlagHeaderAmendFXPage");
            vObjSwapFlagAmendFXPage = Constants.TitanFXTicketsOR.getProperty("SwapFlagAmendFXPage");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDateCalender, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjDateCalender, ""));
        Constants.key.pause("7", "");

        String vFirstAvailableDate = Constants.TitanFXTicketsOR.getProperty("FirstAvailableDate");
        boolean FirstAvailableDate = Constants.driver.findElement(By.xpath(vFirstAvailableDate)).isDisplayed();
        String vLastAvailableDate = Constants.TitanFXTicketsOR.getProperty("LastAvailableDate");
        boolean LastAvailableDate = Constants.driver.findElement(By.xpath(vLastAvailableDate)).isDisplayed();
        LogCapture.info("First: " + FirstAvailableDate + " Last: " + LastAvailableDate);
        if (FirstAvailableDate) {
            Assert.assertEquals("PASS", Constants.key.click(vFirstAvailableDate, ""));
            Constants.key.pause("2", "");
            LogCapture.info("User selects Maturity date..");
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vLastAvailableDate, ""));
            Constants.key.pause("2", "");
            LogCapture.info("User selects Maturity date..");
        }
        //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDefaultDate, "MoveToElement"));
        //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDefaultDate, "click"));


        String vObjSellAmount = Constants.TitanFXTicketsOR.getProperty("SellAmount");
        Assert.assertEquals("PASS", Constants.key.click(vObjSellAmount, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellAmount, "selectall"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellAmount, "delete"));
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellAmount, NewSellAmount));
        LogCapture.info("New Sell Amount entered is: " + NewSellAmount);

        String vObjFetchRatesBtn = Constants.TitanFXTicketsOR.getProperty("FetchRatesBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjFetchRatesBtn, ""));
        Constants.key.pause("2", "");
        String vObjDealRateHeader = Constants.TitanFXTicketsOR.getProperty("DealRateHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealRateHeader, ""));
        LogCapture.info("Rates fetched successfully...");

        String vObjSuggestedRates = Constants.TitanFXTicketsOR.getProperty("SuggestedRates");
        String SuggestedRates = Constants.driver.findElement(By.xpath(vObjSuggestedRates)).getText();

        int DealRateInt = Integer.parseInt(DealRate);
        double d = Double.parseDouble(SuggestedRates);
        double vDoubleCurrRate = ((DealRateInt * d / 100) + d);
        String vTargetValueCalculated = Double.toString(vDoubleCurrRate);


        String vObjDealerRateInput = Constants.TitanFXTicketsOR.getProperty("DealerRateInput");
        Assert.assertEquals("PASS", Constants.key.click(vObjDealerRateInput, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjDealerRateInput, vTargetValueCalculated));
        LogCapture.info("Deal Rate entered: " + vTargetValueCalculated);

        if (SwapButton.equalsIgnoreCase("Select SWAP flag Yes button") || SwapButton.equalsIgnoreCase("Select SWAP flag Yes button for Forward Deal")) {

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapFlagHeaderAmendFXPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSwapFlagHeaderAmendFXPage, "visible"));
            LogCapture.info("User verify Swap Flag is visible on Amend FX page....");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapFlagAmendFXPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSwapFlagAmendFXPage, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapFlagAmendFXPage, ""));
            LogCapture.info("User select Swap Flag option on Amend FX page....");
        }

        String vObjAmendReasonDropArrow = Constants.TitanFXTicketsOR.getProperty("AmendReasonDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmendReasonDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjAmendReason = Constants.TitanFXTicketsOR.getProperty("AmendReason");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmendReason, ""));
        LogCapture.info("User selects Amend reason..");

        String vObjApplyBtn = Constants.TitanFXTicketsOR.getProperty("ApplyBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjApplyBtn, ""));
        LogCapture.info("User clicks on Apply button..");
        Constants.key.pause("2", "");

//         String vObjPopUpYesBtn= Constants.TitanFXTicketsOR.getProperty("PopUpYesBtn");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPopUpYesBtn, ""));
//        Assert.assertEquals("PASS", Constants.key.click(vObjPopUpYesBtn, ""));
//        LogCapture.info("User clicks on Yes button..");

    }


    @And("^User is able to view successful message for FX cancelled$")
    public void userIsAbleToViewSuccessfulMessageForFXCancelled() throws Throwable {
        String vObjFXCancelledSuccessfulMsg = Constants.TitanFXTicketsOR.getProperty("FXCancelledSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXCancelledSuccessfulMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXCancelledSuccessfulMsg, "visible"));
        LogCapture.info("FX cancelled successful message visible...");

    }

    @Then("^User is able to view FX Amend successful message for clientNumber\"([^\"]*)\"$")
    public void userIsAbleToViewSuccessfulMessageForFXAmended(String clientNumber) throws Throwable {
        String vObjAmendSuccessfulMsg = Constants.TitanFXTicketsOR.getProperty("AmendSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmendSuccessfulMsg, ""));
        //String vObjInstructionNumberGenerated = Constants.TitanFXTicketsOR.getProperty("InstructionNumberGenerated");
        String vObjInstructionNumberGenerated = "//*[contains(text(),'Instruction Number : " + clientNumber + "-')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumberGenerated, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInstructionNumberGenerated, "visible"));
        String InstructionNumner = Constants.driver.findElement(By.xpath(vObjInstructionNumberGenerated)).getText();
        LogCapture.info("FX Amended successful message visible...");
        LogCapture.info("Instruction number message: " + InstructionNumner);
        InstructionNumber1=InstructionNumner.split(":")[1].trim();
    }

    @And("^User selects FundType\"([^\"]*)\" Party\"([^\"]*)\" ClientNumber\"([^\"]*)\" clicks on Accept button (.|and Yes button on Popup)$")
    public void userSelectsFundTypePartyClientNumberClicksOnAcceptButtonAndYesButtonOnPopup(String FundType, String Party, String ClientNumber, String data) throws Throwable {

        String vObjFirstRecord = "//*[@id='pillchoice-category-0']//*[@value='"+FundType+"']//parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirstRecord, ""));
        Constants.key.pause("2", "");

        //Slid slider to right
        String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        Constants.key.pause("2", "");
        WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        int width = slider.getSize().getWidth();
        Actions move = new Actions(Constants.driver);
        move.moveToElement(slider, ((width * 10) / 100), 0).click();
        move.build().perform();
        LogCapture.info("Slider dragged to right...");
        Constants.key.pause("2", "");
        String TargetedCPEnable = null;
        for (int i = 0; i < 100; i++) {
            String vObjCP = "//*[@id='pillchoice-category-" + i + "']//*[@value='"+FundType+"']";
            boolean vFundTypeEnable = Constants.driver.findElement(By.xpath(vObjCP)).isEnabled();
            if (vFundTypeEnable) {
                TargetedCPEnable = String.valueOf(i);
                LogCapture.info("target CP record: " + TargetedCPEnable);
                break;
            }
        }

        String vObjFundTypeFocused = "//*[@id='pillchoice-category-" + TargetedCPEnable + "']//*[@value='" + FundType + "']//parent::label";
        String vObjPartyFocused = "//*[@id='pillchoice-payment-type-" + TargetedCPEnable + "']//*[@value='" + Party + "']//parent::label";

        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFundTypeFocused, "visible"));
        String vObjFundType = Constants.driver.findElement(By.xpath(vObjFundTypeFocused)).getAttribute("class");
        LogCapture.info(vObjFundType);
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPartyFocused, "visible"));
        String vObjParty = Constants.driver.findElement(By.xpath(vObjPartyFocused)).getAttribute("class");
        LogCapture.info(vObjParty);
        if (vObjFundType.contains("focussed")) {
            LogCapture.info("Fund type already selected: " + FundType);
        } else {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFundTypeFocused, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFundTypeFocused, ""));
            LogCapture.info("Fund type clicked: " + FundType);
        }
        if (vObjParty.contains("focussed")) {
            LogCapture.info("Party already selected: " + Party);
        } else {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPartyFocused, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPartyFocused, ""));
            LogCapture.info("Party type clicked: " + Party);
        }
        Constants.key.pause("2", "");
        //String vObjClientNumber = Constants.TitanQueuesOR.getProperty("ClientNumber");
        String vObjClientNumber = "//*[@id='txt-accept-learn-" + TargetedCPEnable + "']";
        Assert.assertEquals("PASS", Constants.key.click(vObjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjClientNumber, ClientNumber));
        LogCapture.info("USer enters Client number: " + ClientNumber);

        //String vObjAcceptBtn = Constants.TitanQueuesOR.getProperty("AcceptBtn");
        String vObjAcceptBtn = "//*[@id='btn-accept-learn-accept-" + TargetedCPEnable + "']";
        Assert.assertEquals("PASS", Constants.key.click(vObjAcceptBtn, ""));
        LogCapture.info("User clicks on Accept button..");
        if(data.equalsIgnoreCase("and Yes button on Popup")) {

            String vObjYesButton = Constants.TitanQueuesOR.getProperty("YesButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesButton, ""));
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
            LogCapture.info("User clicks on Yes button..");
            Constants.key.pause("3", "");
            try {
                String vObjErrorMsg = Constants.TitanQueuesOR.getProperty("LegalEntiyNotSupportedMsg");
                boolean vErrorMsg = Constants.driver.findElement(By.xpath(vObjErrorMsg)).isDisplayed();
                assert TargetedCPEnable != null;
                int j = Integer.parseInt(TargetedCPEnable);
                j++;
                while (Constants.driver.findElement(By.xpath(vObjErrorMsg)).isDisplayed()) {
                    LogCapture.info("Error: Legal entity is not supported..");
                    LogCapture.info("Trying for another record..");

                    String UpdatedTargetedCPEnable = null;

                    String vObjUpdatedCP = "//*[@id='pillchoice-category-" + j + "']//*[@value='CP']";
                    boolean vUpdatedCPEnable = Constants.driver.findElement(By.xpath(vObjUpdatedCP)).isEnabled();
                    if (vUpdatedCPEnable) {
                        UpdatedTargetedCPEnable = String.valueOf(j);
                        LogCapture.info("Updated target CP record: " + UpdatedTargetedCPEnable);
                        //break;
                    }

                    vObjFundTypeFocused = "//*[@id='pillchoice-category-" + UpdatedTargetedCPEnable + "']//*[@value='" + FundType + "']//parent::label";
                    vObjPartyFocused = "//*[@id='pillchoice-payment-type-" + UpdatedTargetedCPEnable + "']//*[@value='" + Party + "']//parent::label";

                    Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFundTypeFocused, "visible"));
                    vObjFundType = Constants.driver.findElement(By.xpath(vObjFundTypeFocused)).getAttribute("class");
                    LogCapture.info(vObjFundType);
                    Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPartyFocused, "visible"));
                    vObjParty = Constants.driver.findElement(By.xpath(vObjPartyFocused)).getAttribute("class");
                    LogCapture.info(vObjParty);
                    if (vObjFundType.contains("focussed")) {
                        LogCapture.info("Fund type already selected: " + FundType);
                    } else {
                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFundTypeFocused, ""));
                        Constants.key.pause("2", "");
                        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFundTypeFocused, ""));
                        LogCapture.info("Fund type clicked: " + FundType);
                    }
                    if (vObjParty.contains("focussed")) {
                        LogCapture.info("Party already selected: " + Party);
                    } else {
                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPartyFocused, ""));
                        Constants.key.pause("2", "");
                        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPartyFocused, ""));
                        LogCapture.info("Party type clicked: " + Party);
                    }
                    Constants.key.pause("2", "");
                    //String vObjClientNumber = Constants.TitanQueuesOR.getProperty("ClientNumber");
                    vObjClientNumber = "//*[@id='txt-accept-learn-" + UpdatedTargetedCPEnable + "']";
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClientNumber, ""));
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjClientNumber, ClientNumber));
                    LogCapture.info("USer enters Client number: " + ClientNumber);

                    //String vObjAcceptBtn = Constants.TitanQueuesOR.getProperty("AcceptBtn");
                    vObjAcceptBtn = "//*[@id='btn-accept-learn-accept-" + UpdatedTargetedCPEnable + "']";
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAcceptBtn, ""));
                    LogCapture.info("User clicks on Accept button..");

                    vObjYesButton = Constants.TitanQueuesOR.getProperty("YesButton");
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesButton, ""));
                    Constants.key.pause("2", "");
                    Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
                    Constants.key.pause("2", "");
                    if (Constants.driver.findElement(By.xpath(vObjYesButton)).isDisplayed()) {
                        Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
                        LogCapture.info("User clicks on Yes button..");
                    }
                    LogCapture.info("User clicks on Yes button..");
                    Constants.key.pause("3", "");
                    String vObjErrorMsgNew = Constants.TitanQueuesOR.getProperty("LegalEntiyNotSupportedMsg");
                    boolean vErrorMsgNew = Constants.driver.findElement(By.xpath(vObjErrorMsgNew)).isDisplayed();
                    if (!vErrorMsgNew) {
                        LogCapture.info("No error msg visible..");
                        break;
                    }
                    j++;

                }
            } catch (Exception e) {
                LogCapture.info("No Error...");
            }
        }
    }

    @Then("^User is able to view successful message for allocation of funds via Payment In Queue$")
    public void userIsAbleToViewSuccessfulMessageForAllocationOfFundsViaPaymentInQueue() throws Throwable {

        String vObjPaymentInSuccessMsg = Constants.TitanQueuesOR.getProperty("PaymentInSuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInSuccessMsg, "visible"));
        LogCapture.info("Payment allocated successful message is visible..");

    }


    @And("^User search for Payee ClientName Organisation\"([^\"]*)\" and hits Enter key$")
    public void userSearchForPayeeClientNameOrganisationAndHitsEnterKey(String Organisation) throws Throwable {

        String vObjFilterSearchOrganisationDropdownArrow = Constants.TitanQueuesOR.getProperty("FilterSearchOrganisationDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilterSearchOrganisationDropdownArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisation = "//ul[@class='multilist__options']//input[@value='" + Organisation + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisation);
        Constants.key.pause("2", "");
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        String ClientName = PayeeFirstName + " " + PayeeLastName;
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, ClientName));
        LogCapture.info("Searching for Client name: " + ClientName);
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");
    }

    @And("^User clicks on newly added Payee from the list$")
    public void userClicksOnNewlyAddedPayeeFromTheList() throws Throwable {
        String ClientName = PayeeFirstName + " " + PayeeLastName;
        String vObjClientName = "//*[text()='" + ClientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClientName, ""));
        LogCapture.info("User clicks on client name: " + ClientName);
    }

    @And("^User is on Payee details page and clicks on Delete Payee button$")
    public void userIsOnPayeeDetailsPageAndClicksOnDeletePayeeButton() throws Throwable {
        String vObjPayeeDetailsHeader = Constants.TitanPayeeOR.getProperty("PayeeDetailsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailsHeader, ""));
        LogCapture.info("User is on Payee details page...");
        String vObjDeletePayeeBtn = Constants.TitanPayeeOR.getProperty("DeletePayeeBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjDeletePayeeBtn, ""));
        LogCapture.info("Clicks on Delete Payee button...");
        String vObjDeletePayeeYesBtn = Constants.TitanPayeeOR.getProperty("DeletePayeeYesBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDeletePayeeYesBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjDeletePayeeYesBtn, ""));
        LogCapture.info("Clicks on YES button for Delete Payee..");
    }

    @Then("^User is able to view success message for Payee deleted$")
    public void userIsAbleToViewSuccessMessageForPayeeDeleted() throws Throwable {
        String vObjPayeeDeleteMsg = Constants.TitanPayeeOR.getProperty("PayeeDeleteMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDeleteMsg, ""));
        LogCapture.info("Payee deleted success message is visible..");
    }

    @And("^User checks the status of Payee is (Active|Inactive)$")
    public void userChecksTheStatusOfPayeeIsActive(String Status) throws Throwable {
        String ClientName = PayeeFirstName + " " + PayeeLastName;
        String vObjClientName = "//*[text()='" + ClientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));

        if (Status.equalsIgnoreCase("Active")) {
            String vObjCurrentStatus = "//*[text()='" + ClientName + "']//parent::td//following-sibling::td//*[text()='ACTIVE']";
            String ExpectedStatus = Constants.driver.findElement(By.xpath(vObjCurrentStatus)).getText();
            if (ExpectedStatus.equalsIgnoreCase("Active")) {
                LogCapture.info("Status is ACTIVE..");
            } else {
                LogCapture.info("Customer Status is INACTIVE but should be ACTIVE..");
                Assert.fail();
            }
        }
        if (Status.equalsIgnoreCase("Inactive")) {
            String vObjCurrentStatus = "//*[text()='" + ClientName + "']//parent::td//following-sibling::td//*[text()='INACTIVE']";
            String ExpectedStatus = Constants.driver.findElement(By.xpath(vObjCurrentStatus)).getText();
            if (ExpectedStatus.equalsIgnoreCase("Inactive")) {
                LogCapture.info("Status is INACTIVE..");
            } else {
                LogCapture.info("Customer Status is ACTIVE but should be INACTIVE..");
                Assert.fail();
            }

        }
    }

    @Then("^User is on Instructions page$")
    public void userIsOnInstructionsPageAndUserClicksOnDownloadPDFButton() throws Throwable {
        String vObjInstructionPageHeader = Constants.TitanInstructionsOR.getProperty("InstructionPageHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionPageHeader, ""));
        LogCapture.info("Instructions page is visible..");

    }

    @And("^User is on Regular Transfer page$")
    public void userIsOnRegularTransferPage() throws Throwable {
        String vObjRegularTransferHeader = Constants.TitanCustomersOR.getProperty("RegularTransferHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRegularTransferHeader, ""));
        LogCapture.info("Regular transfer page is visible..");
    }


    @And("^User is Add new Transfer button$")
    public void userIsAddNewTransferButton() throws Throwable {
        String vObjAddNewTransferBtn = Constants.TitanCustomersOR.getProperty("AddNewTransferBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddNewTransferBtn, ""));
        LogCapture.info("Add new transfer button..");

    }

    @And("^User enters Basic details InstructedBy\"([^\"]*)\" SellCurrency\"([^\"]*)\" BuyCurrency\"([^\"]*)\" Amount\"([^\"]*)\" TransferType\"([^\"]*)\" and clicks on Next button$")
    public void userEntersBasicDetailsInstructedBySellCurrencyBuyCurrencyAmountTransferTypeAndClicksOnNextButton(String InstructedBy, String SellCurrency, String BuyCurrency, String Amount, String TransferType) throws Throwable {
        String vObjBasicDetailsPage = Constants.TitanCustomersOR.getProperty("BasicDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPage, ""));
        LogCapture.info("1 of 2: Basic details page visible..");

        String vObjRTInstructedByDropdownArrow = Constants.TitanCustomersOR.getProperty("RTInstructedByDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRTInstructedByDropdownArrow, ""));

        String vObjRTInstructedBySearch = Constants.TitanCustomersOR.getProperty("RTInstructedBySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRTInstructedBySearch, InstructedBy));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTInstructedBySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTInstructedBySearch, "enter"));
        LogCapture.info("Instructed By: " + InstructedBy + " is selected..");

        String vObjRTSellCurrencyDropArrow = Constants.TitanCustomersOR.getProperty("RTSellCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRTSellCurrencyDropArrow, ""));
        String vObjRTSellCurrencySearch = Constants.TitanCustomersOR.getProperty("RTSellCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRTSellCurrencySearch, SellCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTSellCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTSellCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");

        String vObjRTBuyCurrencyDropArrow = Constants.TitanCustomersOR.getProperty("RTBuyCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRTBuyCurrencyDropArrow, ""));
        String vObjRTBuyCurrencySearch = Constants.TitanCustomersOR.getProperty("RTBuyCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRTBuyCurrencySearch, BuyCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTBuyCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRTBuyCurrencySearch, "enter"));
        LogCapture.info("Buy Currency: " + BuyCurrency + " is selected..");

        String vObjRTAmount = Constants.TitanCustomersOR.getProperty("RTAmount");
        Assert.assertEquals("PASS", Constants.key.click(vObjRTAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRTAmount, Amount));
        Constants.key.pause("2", "");
        LogCapture.info("Amount entered is: " + Amount);


        String vObjTransferType = null;
        if (TransferType.equalsIgnoreCase("Sell")) {
            vObjTransferType = Constants.TitanCustomersOR.getProperty("RTSellTransfer");
        }
        if (TransferType.equalsIgnoreCase("Buy")) {
            vObjTransferType = Constants.TitanCustomersOR.getProperty("RTBuyTransfer");
        }
        Assert.assertEquals("PASS", Constants.key.click(vObjTransferType, ""));
        LogCapture.info("Transfer type: " + TransferType + " is selected...");
        Constants.key.pause("2", "");
        String vObjBasicDetailsNextBtn = Constants.TitanCustomersOR.getProperty("BasicDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBasicDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }


    @And("^User enters Payment details Payee\"([^\"]*)\" PaymentMethod\"([^\"]*)\" CardholderName\"([^\"]*)\" EndDate RecurrenceType\"([^\"]*)\" RecurrenceMonth\"([^\"]*)\" DatePreference\"([^\"]*)\" PurposeOfPayment\"([^\"]*)\" and click on Finish button$")
    public void userEntersPaymentDetailsPayeePaymentMethodCardholderNameEndDateRecurrenceTypeRecurrenceDatePreferencePurposeOfPaymentAndClickOnFinishButton(String Payee, String PaymentMethod, String CardholderName, String RecurrenceType, String RecurrenceMonth, String DatePreference, String PurposeOfPayment) throws Throwable {

        String vObjPaymentDetailsPage = Constants.TitanCustomersOR.getProperty("PaymentDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentDetailsPage, ""));
        LogCapture.info("2 of 2: Payment details page visible..");

        String vObjPayeeSelectDropArrow = Constants.TitanCustomersOR.getProperty("PayeeSelectDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeSelectDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjPayeeSelectSearch = Constants.TitanCustomersOR.getProperty("PayeeSelectSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeSelectSearch, Payee));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeSelectSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeSelectSearch, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");

        String vObjSelectCreditMethod = Constants.TitanCustomersOR.getProperty("SelectCreditMethod");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectCreditMethod, ""));
        Constants.key.pause("2", "");

        if (PaymentMethod.equalsIgnoreCase("Card")) {
            String vObjPaymentMethod = Constants.TitanCustomersOR.getProperty("SelectMethodCard");
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
            LogCapture.info("Payment method: " + PaymentMethod + " is selected...");

            String vObjSelectCardDropArrow = Constants.TitanCustomersOR.getProperty("SelectCardDropArrow");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectCardDropArrow, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectCardDropArrow, ""));
            Constants.key.pause("2", "");
            String vObjSelectCardSearch = Constants.TitanCustomersOR.getProperty("SelectCardSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSelectCardSearch, CardholderName));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectCardSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectCardSearch, "enter"));
            LogCapture.info("Card: " + CardholderName + " is selected..");
        }
        if (PaymentMethod.equalsIgnoreCase("DD")) {
            String vObjPaymentMethod = Constants.TitanCustomersOR.getProperty("SelectMethodDD");
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
            LogCapture.info("Payment method: " + PaymentMethod + " is selected...");
            String vObjSelectDirectDebitDropArrow = Constants.TitanCustomersOR.getProperty("SelectDirectDebitArrow");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectDirectDebitDropArrow, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectDirectDebitDropArrow, ""));
            Constants.key.pause("2", "");
            String vObjSelectDirectDebitSearch = Constants.TitanCustomersOR.getProperty("SelectDirectDebitSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSelectDirectDebitSearch, CardholderName));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectDirectDebitSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectDirectDebitSearch, "enter"));
            LogCapture.info("DD: " + CardholderName + " is selected..");
        }


        String vObjRecurrenceTypeDropArrow = Constants.TitanCustomersOR.getProperty("RecurrenceTypeDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRecurrenceTypeDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjRecurrenceTypeSearch = Constants.TitanCustomersOR.getProperty("RecurrenceTypeSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRecurrenceTypeSearch, RecurrenceType));
        Constants.key.pause("2", "");
        String vObjRecurrenceValue = "//*[@value='" + RecurrenceType + "']//parent::label";
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjRecurrenceValue, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjRecurrenceValue, "click"));
        LogCapture.info("Recurrence Type: " + RecurrenceType + " is selected..");
        Constants.key.pause("4", "");

        String vObjPurposeOfPaymentDropArrow = Constants.TitanCustomersOR.getProperty("PurposeOfPaymentDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPaymentDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjPurposeOfPaymentSearch = Constants.TitanCustomersOR.getProperty("PurposeOfPaymentSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, PurposeOfPayment));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
        LogCapture.info("Purpose of Payment: " + PurposeOfPayment + " is selected..");


        String Recurrance = "//*[text()='Recurrence ']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(Recurrance, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(Recurrance, ""));
        Constants.key.pause("2", "");

        String numberOnly = DatePreference.replaceAll("[^0-9]", "");
        String vObjDateOnly = "//*[@value='" + numberOnly + "']//parent::label";
        String vObjRecurrenceDayDropArrow = Constants.TitanCustomersOR.getProperty("RecurrenceDayDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjRecurrenceDayDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjRecurrenceDaySearch = Constants.TitanCustomersOR.getProperty("RecurrenceDaySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRecurrenceDaySearch, DatePreference));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDateOnly, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDateOnly, "click"));
        LogCapture.info("Date: " + DatePreference + " is selected..");
        Assert.assertEquals("PASS", Constants.key.click(Recurrance, ""));
        Constants.key.pause("10", "");


        if (RecurrenceType.equalsIgnoreCase("Monthly")) {

        } else if (RecurrenceType.equalsIgnoreCase("Quarterly") || RecurrenceType.equalsIgnoreCase("Yearly")) {
            String vObjRecurrenceMonthDropArrow = Constants.TitanCustomersOR.getProperty("RecurrenceMonthDropArrow");
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjRecurrenceMonthDropArrow, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjRecurrenceMonthDropArrow, "click"));
            //Assert.assertEquals("PASS", Constants.key.click(vObjRecurrenceMonthDropArrow, ""));
            Constants.key.pause("2", "");
            String vObjRecurrenceMonthSearch = Constants.TitanCustomersOR.getProperty("RecurrenceMonthSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRecurrenceMonthSearch, RecurrenceMonth));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRecurrenceMonthSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjRecurrenceMonthSearch, "enter"));
            LogCapture.info("Recurrence Month: " + RecurrenceMonth + " is selected..");
        }
        Constants.key.pause("2", "");
        String vObjFinishBtn = Constants.TitanCustomersOR.getProperty("FinishBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFinishBtn, ""));
        LogCapture.info("clicked on Finish button....");

    }

    @Then("^User is able view RT created successfully$")
    public void userIsAbleViewRTCreatedSuccessfully() throws Throwable {
        String vObjSuccessMsgPartOne = Constants.TitanCustomersOR.getProperty("SuccessMsgPartOne");
        String vObjSuccessMsgPartTwo = Constants.TitanCustomersOR.getProperty("SuccessMsgPartTwo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSuccessMsgPartOne, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSuccessMsgPartOne, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSuccessMsgPartTwo, "visible"));
        LogCapture.info("RT created successful message is visible..");

    }

    @And("^user clicks on Submit button for RT$")
    public void userClicksOnSubmitButtonForRT() throws Throwable {
        String vObjSubmitRTBtn = Constants.TitanCustomersOR.getProperty("SubmitRTBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSubmitRTBtn, ""));
        LogCapture.info("clicked on Finish button....");

    }

    @And("^User search for Instruction number generated$")
    public void userSearchForInstructionNumberGenerated() throws Throwable {
        String vObjInstructionNumberSearch = Constants.TitanInstructionsOR.getProperty("InstructionNumberSearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionNumberSearch, InstructionNumber));


        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionNumberSearch, "enter"));
        LogCapture.info("Searching Instruction number: " + InstructionNumber);
        Constants.key.pause("4", "");
    }

    @And("^Download PDF button is (Disable|Enable)$")
    public void downlaodPDFButtonIsDisable(String ButtonStatus) throws Throwable {
        if (ButtonStatus.equalsIgnoreCase("Disable")) {
            String vObjDisableDownloadPDFbtn = Constants.TitanInstructionsOR.getProperty("DisableDownloadPDFbtn");
            String vObjInstructionNumber = "//*[text()='" + InstructionNumber + "']";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumber, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDisableDownloadPDFbtn, "visible"));
            LogCapture.info("PDF download button is disable..");
        }
        if (ButtonStatus.equalsIgnoreCase("Enable")) {
            String vObjEnableDownloadPDFbtn = Constants.TitanInstructionsOR.getProperty("EnableDownloadPDFbtn");
            String vObjInstructionNumber = "//*[text()='" + InstructionNumber + "']";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumber, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjEnableDownloadPDFbtn, "visible"));
            LogCapture.info("PDF download button is Enable..");
        }


    }

    @Then("^User enters basic details Organisation\"([^\"]*)\" Date Counterparty\"([^\"]*)\" B2BDeal\"([^\"]*)\" SellCurrency\"([^\"]*)\" BuyCurrency\"([^\"]*)\" EnterAmount\"([^\"]*)\" Amount\"([^\"]*)\" EnterRate\"([^\"]*)\" Rate\"([^\"]*)\" Blotter\"([^\"]*)\" and click on Book button for Treasury deal$")
    public void userEntersBasicDetailsOrganisationDateCounterpartyBBDealSellCurrencyBuyCurrencyEnterAmountAmountEnterRateRateBlotterAndClickOnBookButtonForTreasuryDeal(String Organisation, String Counterparty, String B2BDeal, String SellCurrency, String BuyCurrency, String EnterAmount, String Amount, String EnterRate, String Rate, String Blotter) throws Throwable {

        String vObjOrganisationDropArrow = Constants.TitanTreasuryOR.getProperty("OrganisationDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjOrganisationDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisation = "//ul[@class='singlelist__options org-list']//input[@value='" + Organisation + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisation);

        String vObjDateField = Constants.TitanTreasuryOR.getProperty("DateField");
        Assert.assertEquals("PASS", Constants.key.click(vObjDateField, ""));
        Constants.key.pause("2", "");
        String vObjTodaysHighlightedDate = Constants.TitanTreasuryOR.getProperty("TodaysHighlightedDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjTodaysHighlightedDate, ""));
        LogCapture.info("Today's Date selected..");


        String vObjCounterPartiesDropArrow = Constants.TitanTreasuryOR.getProperty("CounterPartiesDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCounterPartiesDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCounterPartiesSearch = Constants.TitanTreasuryOR.getProperty("CounterPartiesSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCounterPartiesSearch, Counterparty));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCounterPartiesSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCounterPartiesSearch, "enter"));
        LogCapture.info("Counterparty: " + Counterparty + " is selected..");

        if (B2BDeal.equalsIgnoreCase("Yes")) {
            String vObjB2BCheckBox = Constants.TitanTreasuryOR.getProperty("B2BCheckBox");
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BCheckBox, ""));
            Constants.key.pause("2", "");
            LogCapture.info("B2B deal checkbox is selected..");
        } else if (B2BDeal.equalsIgnoreCase("No")) {
            LogCapture.info("B2B deal checkbox is NOT selected..");
        }
        String vObjSellCurrencyDropArrow = Constants.TitanTreasuryOR.getProperty("SellCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjSellCurrencyDropArrow, ""));
        Constants.key.pause("4", "");
        String vObjSellCurrencySearch = Constants.TitanTreasuryOR.getProperty("SellCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellCurrencySearch, SellCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellCurrencySearch, "enter"));
        LogCapture.info("SellCurrency: " + SellCurrency + " is selected..");

        String vObjBuyCurrencyDropArrow = Constants.TitanTreasuryOR.getProperty("BuyCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyCurrencyDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjBuyCurrencySearch = Constants.TitanTreasuryOR.getProperty("BuyCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyCurrencySearch, BuyCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyCurrencySearch, "enter"));
        LogCapture.info("BuyCurrency: " + BuyCurrency + " is selected..");


        if (EnterAmount.equalsIgnoreCase("Sell")) {
            String vObjSellAmount = Constants.TitanTreasuryOR.getProperty("SellAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjSellAmount, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellAmount, Amount));
            LogCapture.info("Sell Amount entered is " + Amount);
        } else if (EnterAmount.equalsIgnoreCase("Buy")) {
            String vObjBuyAmount = Constants.TitanTreasuryOR.getProperty("BuyAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyAmount, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyAmount, Amount));
            LogCapture.info("Buy Amount entered is " + Amount);
        }

        if (EnterRate.equalsIgnoreCase("Rate")) {
            String vObjRateText = Constants.TitanTreasuryOR.getProperty("RateText");
            Assert.assertEquals("PASS", Constants.key.click(vObjRateText, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRateText, Rate));
            LogCapture.info("Rate entered is " + Rate);
        } else if (EnterRate.equalsIgnoreCase("Inverse")) {
            String vObjInverseRate = Constants.TitanTreasuryOR.getProperty("InverseRate");
            Assert.assertEquals("PASS", Constants.key.click(vObjInverseRate, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInverseRate, Rate));
            LogCapture.info("Inverse rate entered is " + Rate);
        }

        String vObjBlotterDropArrow = Constants.TitanTreasuryOR.getProperty("BlotterDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBlotterDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjBlotterSearch = Constants.TitanTreasuryOR.getProperty("BlotterSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBlotterSearch, Blotter));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBlotterSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBlotterSearch, "enter"));
        LogCapture.info("Blotter: " + Blotter + " is selected..");

        if (Organisation.equalsIgnoreCase("TorFXOz")) {
            String vObjPayeeReference = Constants.TitanTreasuryOR.getProperty("PayeeReference");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeReference, "Payeeref@123"));
            LogCapture.info("User enters payee reference as Payeeref@123...");
        }
        String vObjBookBtn = Constants.TitanTreasuryOR.getProperty("BookBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBookBtn, ""));
        LogCapture.info("User clicks on Book button..");


    }

    @Then("^User is able to view Treasury booked successful message$")
    public void userIsAbleToViewTreasuryBookedSuccessfulMessage() throws Throwable {
        String vObjTreasurySuccessMsg = Constants.TitanTreasuryOR.getProperty("TreasurySuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTreasurySuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTreasurySuccessMsg, "visible"));
        LogCapture.info("Treasury successfully created message is visible..");

    }


    @And("^User search for newly added deal details such as Organisation\"([^\"]*)\" TreasuryTicket\"([^\"]*)\" B2BDeal\"([^\"]*)\" FromCurrency\"([^\"]*)\" ToCurrency\"([^\"]*)\" DealType\"([^\"]*)\" Blotter\"([^\"]*)\"$")
    public void userSearchForNewlyAddedDealDetailsSuchAsOrganisationTreasuryTicketBBDealSellCurrencyBuyCurrencyDealTypeBlotter(String Organisation, String TreasuryTicket, String B2BDeal, String FromCurrency, String ToCurrency, String DealType, String Blotter) throws Throwable {
        String vObjB2BOrganisationDropArrow = Constants.TitanTreasuryOR.getProperty("B2BOrganisationDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjB2BOrganisationDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisation = "//ul[@class='multilist__options']//input[@value='" + Organisation + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisation);

        if (TreasuryTicket.equalsIgnoreCase("Yes")) {
            String vObjTreasuryTicketCheckbox = Constants.TitanTreasuryOR.getProperty("TreasuryTicketCheckbox");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjTreasuryTicketCheckbox, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Treasury ticket checkbox checked..");
        }
        if (TreasuryTicket.equalsIgnoreCase("No")) {
            LogCapture.info("Treasury ticket checkbox NOT checked..");
        }

        if (B2BDeal.equalsIgnoreCase("Yes")) {
            String vObjB2BFilterCheckBox = Constants.TitanTreasuryOR.getProperty("B2BFilterCheckBox");
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BFilterCheckBox, ""));
            Constants.key.pause("2", "");
            LogCapture.info("B2B deal checkbox is checked..");
        } else if (B2BDeal.equalsIgnoreCase("No")) {
            LogCapture.info("B2B deal checkbox is NOT checked..");
        }

        String vObjFromCurrencyDropArrow = Constants.TitanTreasuryOR.getProperty("FromCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjFromCurrencyDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjFromCurrencySearch = Constants.TitanTreasuryOR.getProperty("FromCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromCurrencySearch, FromCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromCurrencySearch, "enter"));
        LogCapture.info("From Currency: " + FromCurrency + " is selected..");

        String vObjToCurrencyDropArrow = Constants.TitanTreasuryOR.getProperty("ToCurrencyDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjToCurrencyDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjToCurrencySearch = Constants.TitanTreasuryOR.getProperty("ToCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjToCurrencySearch, ToCurrency));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjToCurrencySearch, ToCurrency));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToCurrencySearch, "enter"));
        LogCapture.info("SellCurrency: " + ToCurrency + " is selected..");

        String vObjB2BBlotterDropArrow = Constants.TitanTreasuryOR.getProperty("B2BBlotterDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjB2BBlotterDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjBlotter = "//ul[@class='multilist__options']//input[@value='" + Blotter + "']/parent::label[contains(@for,'blotter')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlotter, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBlotter, ""));
        LogCapture.info("Blotter selected: " + Blotter);
        String vObjB2BBlotterHeader = Constants.TitanTreasuryOR.getProperty("B2BBlotterHeader");
        Assert.assertEquals("PASS", Constants.key.click(vObjB2BBlotterHeader, ""));


        String vObjDealTypeDropArrow = Constants.TitanTreasuryOR.getProperty("DealTypeDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealTypeDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjDealType = "//ul[@class='multilist__options']//input[@value='" + DealType + "']/parent::label[contains(@for,'dealtype')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealType, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealType, ""));
        LogCapture.info("Deal type selected: " + DealType);

        Assert.assertEquals("PASS", Constants.key.click(vObjB2BBlotterHeader, ""));

        String vObjApplyButton = Constants.TitanTreasuryOR.getProperty("ApplyButton");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjApplyButton, ""));
        LogCapture.info("User clicks on Apply button..");
        Constants.key.pause("5", "");
    }

    @And("^User selects the required ticket from records displayed and clicked on Update B2B button and Yes button$")
    public void userSelectsTheRequiredTicketFromRecordsDisplayed() throws Throwable {
        Constants.key.pause("2", "");
        String vObjFirstRecordSelect = Constants.TitanTreasuryOR.getProperty("FirstRecordSelect");
        Assert.assertEquals("PASS", Constants.key.click(vObjFirstRecordSelect, ""));
        LogCapture.info("User checked the checkbox for the record..");
        Constants.key.pause("2", "");
        String vObjUpdateB2BBtn = Constants.TitanTreasuryOR.getProperty("UpdateB2BBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjUpdateB2BBtn, ""));
        LogCapture.info("User clicked on Update B2B button..");
        Constants.key.pause("2", "");
        String vObjYesButton = Constants.TitanTreasuryOR.getProperty("YesButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
        LogCapture.info("User clicked on Yes button..");
    }

    @Then("^User is able to view successful message for Update$")
    public void userIsAbleToViewSuccessfulMessageForUpdate() throws Throwable {
        String vObjUpdateSuccessMsg = Constants.TitanTreasuryOR.getProperty("UpdateSuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUpdateSuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdateSuccessMsg, "visible"));
        LogCapture.info("Success message is visible..");
    }

    @Then("^Slid the Slider button$")
    public void SlidTheSliderButton() throws Throwable {

        String vObjSliderButton = Constants.TitanTreasuryOR.getProperty("SliderButton");
        WebElement Element = Constants.driver.findElement(By.xpath(vObjSliderButton));
        Actions build = new Actions(Constants.driver);
        build.dragAndDropBy(Element, 50, 0).build().perform();
        LogCapture.info("Slider dragged to right...");
        Constants.key.pause("2", "");

    }

    @And("^User clicks on download PDF button$")
    public void userClicksOnDownloadPDFButton() throws Throwable {
        winHandleBefore = Constants.driver.getWindowHandle();
        WebElement link = Constants.driver.findElement(By.cssSelector(".downloadPDF"));
        link.click();
        Constants.key.pause("10", "");

    }

    @Then("^User is able to view horizontal slider$")
    public void userIsAbleToViewHorizontalSliderOnQueuesIncomingFundsPageInTitan() throws Throwable {

        String vObjIncomingFundsHeader = Constants.TitanCustomersOR.getProperty("InTitanPage");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjIncomingFundsHeader, "visible"));
        LogCapture.info("Incoming Funds header is visible..");

//        String vObjHorizontalTableSlider = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjHorizontalTableSlider, ""));
//        Assert.assertEquals("PASS", Constants.key.exist(vObjHorizontalTableSlider, "visible"));
//        LogCapture.info("Table slider is visible..");

    }

    @And("^User is able to view Queues Payment Out page details in Titan and Not error message$")
    public void userIsAbleToViewQueuesPaymentOutPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentsOutHeader = Constants.TitanQueuesOR.getProperty("PaymentsOutHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsOutHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentsOutHeader, "visible"));
        LogCapture.info("Payments Out header is visible..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjDateTimeColumn = Constants.TitanQueuesOR.getProperty("DateTimeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateTimeColumn, "visible"));
        LogCapture.info("Date/Time Column is visible..");

        String vObjOrganisationColumn = Constants.TitanQueuesOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanQueuesOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientColumn = Constants.TitanQueuesOR.getProperty("ClientColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientColumn, "visible"));
        LogCapture.info("Client # Column is visible..");

        String vObjPayeeNameColumn = Constants.TitanQueuesOR.getProperty("PayeeNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeNameColumn, "visible"));
        LogCapture.info("Payee Name Column is visible..");

        String vObjAmountColumn = Constants.TitanQueuesOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible..");

        String vObjCCYCoulmn = Constants.TitanQueuesOR.getProperty("CCYCoulmn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYCoulmn, "visible"));
        LogCapture.info("CCY Column is visible..");

        String vObjPayeeAccountNumberColumn = Constants.TitanQueuesOR.getProperty("PayeeAccountNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeAccountNumberColumn, "visible"));
        LogCapture.info("Payee Account Number Column is visible..");

        String vObjPayeeCountryColumn = Constants.TitanQueuesOR.getProperty("PayeeCountryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeCountryColumn, "visible"));
        LogCapture.info("Payee Country Column is visible..");

        String vObjTitanStatusColumn = Constants.TitanQueuesOR.getProperty("TitanStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTitanStatusColumn, "visible"));
        LogCapture.info("Titan Status Column is visible..");

        String vObjReferenceColumn = Constants.TitanQueuesOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible..");

        String vObjInstructionNumberColumn = Constants.TitanQueuesOR.getProperty("InstructionNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInstructionNumberColumn, "visible"));
        LogCapture.info("Instruction Number Column is visible..");

        String vObjReasonColumn = Constants.TitanQueuesOR.getProperty("ReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReasonColumn, "visible"));
        LogCapture.info("Reason Column is visible..");

        //Navigating on top of page
        JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        js.executeScript("window.scrollTo(0, 0)");
        Constants.key.pause("2", "");

        //Slid slider to right
//        String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
//        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
//        Constants.key.pause("2", "");
//        WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
//        int width = slider.getSize().getWidth();
//        Actions move = new Actions(Constants.driver);
//        move.moveToElement(slider, ((width * 10) / 100), 0).click();
//        move.build().perform();
//        LogCapture.info("Slider dragged to right...");
//        Constants.key.pause("2", "");

        String vObjErrorReasonColumn = Constants.TitanQueuesOR.getProperty("ErrorReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjErrorReasonColumn, "visible"));
        LogCapture.info("Error Reason Column is visible..");

        String vObjConflictStatusColumn = Constants.TitanQueuesOR.getProperty("ConflictStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictStatusColumn, "visible"));
        LogCapture.info("Conflict Status Column is visible..");

        String vObjPayOutAtlasStatusColumn = Constants.TitanQueuesOR.getProperty("PaymentOutAtlasStatus");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayOutAtlasStatusColumn, "visible"));
        LogCapture.info("Atlas Status Column is visible..");

        String vObjBankingStatusColumn = Constants.TitanQueuesOR.getProperty("BankingStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBankingStatusColumn, "visible"));
        LogCapture.info("Banking Status Column is visible..");

        String vObjClientTypeColumn = Constants.TitanQueuesOR.getProperty("ClientTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTypeColumn, "visible"));
        LogCapture.info("Client Type Column is visible..");

        String vObjDealerNameColumn = Constants.TitanQueuesOR.getProperty("DealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        String vObjUpdatedByColumn = Constants.TitanQueuesOR.getProperty("UpdatedByColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdatedByColumn, "visible"));
        LogCapture.info("UpdatedBy Column is visible..");

        LogCapture.info("Payment Out page - All details are visible..");
    }

    @And("^User is able to view Queues FX Ticket page details in Titan and Not error message$")
    public void userIsAbleToViewQueuesFXTicketPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
        LogCapture.info("User is on FX tickets in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanQueuesOR.getProperty("DateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjOrganisationColumn = Constants.TitanQueuesOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanQueuesOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientColumn = Constants.TitanQueuesOR.getProperty("ClientColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientColumn, "visible"));
        LogCapture.info("Client # Column is visible..");

        String vObjClientNameColumn = Constants.TitanQueuesOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjReferenceColumn = Constants.TitanQueuesOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible...");

        String vObjSellCurrencyColumn = Constants.TitanQueuesOR.getProperty("SellCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellCurrencyColumn, "visible"));
        LogCapture.info("Sell Currency Column is visible..");

        String vObjSellAmountColumn = Constants.TitanQueuesOR.getProperty("SellAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellAmountColumn, "visible"));
        LogCapture.info("Sell Amount Column is visible..");

        String vObjBuyCurrencyColumn = Constants.TitanQueuesOR.getProperty("BuyCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyCurrencyColumn, "visible"));
        LogCapture.info("Buy Currency Column is visible..");

        String vObjBuyAmountColumn = Constants.TitanQueuesOR.getProperty("BuyAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyAmountColumn, "visible"));
        LogCapture.info("Buy Amount Column is visible..");

        String vObjRateColumn = Constants.TitanQueuesOR.getProperty("RateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjRateColumn, "visible"));
        LogCapture.info("Rate Column is visible..");

        String vObjFXTypeColumn = Constants.TitanQueuesOR.getProperty("FXTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXTypeColumn, "visible"));
        LogCapture.info("FX Type Column is visible..");

//        Navigating on top of page
//
//        WebElement element = Constants.driver.findElement(By.xpath(vObjFXTypeColumn));
//        JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
//        js.executeScript("window.scrollTo(0, 0)");
//        Constants.key.pause("2", "");


        //Slid slider to right
//        String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
//       if (Constants.driver.findElement(By.xpath(vObjSliderButton)).isDisplayed()) {
//           Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
//         Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
//        Constants.key.pause("2", "");
//            WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
//           int width = slider.getSize().getWidth();
//           Actions move = new Actions(Constants.driver);
//           move.moveToElement(slider, ((width * 10) / 100), 0).click();
//           move.build().perform();
//           LogCapture.info("Slider dragged to right...");
//           Constants.key.pause("2", "");
//        } else {
//          String vObjFXTableScrollbarVisible = Constants.TitanCustomersOR.getProperty("FXTableScrollbarVisible");
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXTableScrollbarVisible, "visible"));
//            LogCapture.info("Table scroll is visible..");
//        }
        String vObjStatusColumn = Constants.TitanQueuesOR.getProperty("StatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatusColumn, "visible"));
        LogCapture.info("Status Column is visible..");

        String vObjConflictStatusColumn = Constants.TitanQueuesOR.getProperty("ConflictStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictStatusColumn, "visible"));
        LogCapture.info("Conflict Status Column is visible..");

        String vObjReasonColumn = Constants.TitanQueuesOR.getProperty("ReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReasonColumn, "visible"));
        LogCapture.info("Reason Column is visible..");

        String vObjErrorReasonColumn = Constants.TitanQueuesOR.getProperty("FXErrorReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjErrorReasonColumn, "visible"));
        LogCapture.info("Error Reason Column is visible..");

        String vObjDealerNameColumn = Constants.TitanQueuesOR.getProperty("DealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        String vObjClientTypeColumn = Constants.TitanQueuesOR.getProperty("ClientTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTypeColumn, "visible"));
        LogCapture.info("Client Type Column is visible..");

        LogCapture.info("FX Tickets page - All details are visible..");
    }

    @And("^User is able to view Payment In Reports page details in Titan and Not error message$")
    public void userIsAbleToViewPaymentInReportsPageDetailsInTitanAndNotErrorMessage() throws Throwable {
        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");
        String vObjPaymentInReportPage = Constants.TitanReportsOR.getProperty("PaymentInReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportPage, ""));
        LogCapture.info("User is on Payments In Reports in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanReportsOR.getProperty("DateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date column is visible..");

        String vObjOrganisationColumn = Constants.TitanReportsOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanReportsOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner column is visible..");

        String vObjLegalEntityColumn = Constants.TitanReportsOR.getProperty("LegalEntityColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLegalEntityColumn, "visible"));
        LogCapture.info("Legal Entity column is visible..");

        String vObjDebtorAccCardNoColumn = Constants.TitanReportsOR.getProperty("DebtorAccCardNoColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebtorAccCardNoColumn, "visible"));
        LogCapture.info("Debtor Acc No/Card No column is visible..");

        String vObjCCYColumn = Constants.TitanReportsOR.getProperty("CCYColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYColumn, "visible"));
        LogCapture.info("CCY column is visible..");

        String vObjAmountColumn = Constants.TitanReportsOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount column is visible..");

        String vObjReferenceColumn = Constants.TitanReportsOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference column is visible..");

        String vObjFTTPColumn = Constants.TitanReportsOR.getProperty("FTTPColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFTTPColumn, "visible"));
        LogCapture.info("FT/TP column is visible..");

        String vObjClientNumberColumn = Constants.TitanReportsOR.getProperty("ClientNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client Number column is visible..");

        String vObjClientNameColumn = Constants.TitanReportsOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name column is visible..");

        String vObjStatusColumn = Constants.TitanReportsOR.getProperty("StatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjStatusColumn, "visible"));
        LogCapture.info("Status column is visible..");

        String vObjModeOfPaymentColumn = Constants.TitanReportsOR.getProperty("ModeOfPaymentColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjModeOfPaymentColumn, "visible"));
        LogCapture.info("Mode Of Payment column is visible..");

        String vObjSourceApplicationColumn = Constants.TitanReportsOR.getProperty("SourceApplicationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSourceApplicationColumn, "visible"));
        LogCapture.info("Source Application column is visible..");

        String vObjFICountryColumn = Constants.TitanReportsOR.getProperty("FICountryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFICountryColumn, "visible"));
        LogCapture.info("FI Country column is visible..");

        //Navigating on top of page
        // JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        // js.executeScript("window.scrollTo(0, 0)");
        // Constants.key.pause("2", "");

        //Slid slider to right
        //String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        //Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        //Constants.key.pause("2", "");
        //WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        //int width = slider.getSize().getWidth();
        //Actions move = new Actions(Constants.driver);
        //move.moveToElement(slider, ((width * 10) / 100), 0).click();
        //move.build().perform();
        //LogCapture.info("Slider dragged to right...");
        //Constants.key.pause("2", "");

        String vObjUpdatedByDateTimeColumn = Constants.TitanReportsOR.getProperty("UpdatedByDateTimeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdatedByDateTimeColumn, "visible"));
        LogCapture.info("Updated by-Date & Time column is visible..");

        String vObjUpdatedByColumn = Constants.TitanReportsOR.getProperty("UpdatedByColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdatedByColumn, "visible"));
        LogCapture.info("Updated by column is visible..");

        String vObjAllocatedTypeColumn = Constants.TitanReportsOR.getProperty("AllocatedTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAllocatedTypeColumn, "visible"));
        LogCapture.info("Allocated Type column is visible..");

        String vObjDebitReasonColumn = Constants.TitanReportsOR.getProperty("DebitReasonColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDebitReasonColumn, "visible"));
        LogCapture.info("Debit Reason column is visible..");

        LogCapture.info("Payment In Reports page - All details are visible..");

    }

    @Then("^User is able to view Payment Out Reports page details in Titan and Not error message$")
    public void userIsAbleToViewPaymentOutReportsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
        LogCapture.info("User is on Payments Out Reports in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanReportsOR.getProperty("PayOutDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanReportsOR.getProperty("BusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientNumberColumn = Constants.TitanReportsOR.getProperty("ClientNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client Number column is visible..");

        String vObjClientNameColumn = Constants.TitanReportsOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjCCYColumn = Constants.TitanReportsOR.getProperty("CCYColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYColumn, "visible"));
        LogCapture.info("CCY column is visible..");

        String vObjAmountColumn = Constants.TitanReportsOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible...");

        String vObjPayeeAccountNumberColumn = Constants.TitanReportsOR.getProperty("PayeeAccountNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeAccountNumberColumn, "visible"));
        LogCapture.info("Payee Account Number Column is visible..");

        String vObjPayeeNameColumn = Constants.TitanReportsOR.getProperty("PayeeNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeNameColumn, "visible"));
        LogCapture.info("Payee Name Column is visible..");

        String vObjPayeeCountryColumn = Constants.TitanReportsOR.getProperty("PayeeCountryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeCountryColumn, "visible"));
        LogCapture.info("Payee Country Column is visible..");

        String vObjTitanStatusColumn = Constants.TitanReportsOR.getProperty("TitanStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTitanStatusColumn, "visible"));
        LogCapture.info("Titan Status Column is visible..");

        String vObjReferenceColumn = Constants.TitanReportsOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible..");

        String vObjInstructionNumberColumn = Constants.TitanReportsOR.getProperty("InstructionNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInstructionNumberColumn, "visible"));
        LogCapture.info("Instruction Number Column is visible..");

        //Navigating on top of page

        // JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        //js.executeScript("window.scrollTo(0, 0)");
        // Constants.key.pause("2", "");

        //Slid slider to right
        //String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        //Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        //Constants.key.pause("2", "");
        //WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        //int width = slider.getSize().getWidth();
        //Actions move = new Actions(Constants.driver);
        //move.moveToElement(slider, ((width * 10) / 100), 0).click();
        //move.build().perform();
        //LogCapture.info("Slider dragged to right...");
        //Constants.key.pause("2", "");

        String vObjAtlasStatusColumn = Constants.TitanReportsOR.getProperty("AtlasStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAtlasStatusColumn, "visible"));
        LogCapture.info("Atlas Status Column is visible..");

        String vObjBankingStatusColumn = Constants.TitanReportsOR.getProperty("BankingStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBankingStatusColumn, "visible"));
        LogCapture.info("Banking Status Column is visible..");

        String vObjClientTypeColumn = Constants.TitanReportsOR.getProperty("ClientTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTypeColumn, "visible"));
        LogCapture.info("Client Type Column is visible..");

        String vObjDealerNameColumn = Constants.TitanReportsOR.getProperty("DealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        LogCapture.info("Payment Out Reports page - All details are visible..");

    }

    @And("^User is able to view FX tickets Reports page details in Titan and Not error message$")
    public void userIsAbleToViewFXTicketsReportsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXticketsReportPage = Constants.TitanReportsOR.getProperty("FXticketsReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXticketsReportPage, ""));
        LogCapture.info("User is on FX tickets Reports in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjDateColumn = Constants.TitanReportsOR.getProperty("FXDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateColumn, "visible"));
        LogCapture.info("Date Column is visible..");

        String vObjOrganisationColumn = Constants.TitanReportsOR.getProperty("FXOrgColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanReportsOR.getProperty("FXBusinessPartnerColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientNumberColumn = Constants.TitanReportsOR.getProperty("FXClientNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client Number column is visible..");

        String vObjClientNameColumn = Constants.TitanReportsOR.getProperty("FXClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjReferenceColumn = Constants.TitanReportsOR.getProperty("FXReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible..");

        String vObjSellCurrencyColumn = Constants.TitanReportsOR.getProperty("FXSellCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellCurrencyColumn, "visible"));
        LogCapture.info("Sell Currency Column is visible..");

        String vObjSellAmountColumn = Constants.TitanReportsOR.getProperty("FXSellAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellAmountColumn, "visible"));
        LogCapture.info("Sell Amount Column is visible..");

        String vObjBuyCurrencyColumn = Constants.TitanReportsOR.getProperty("FXBuyCurrencyColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyCurrencyColumn, "visible"));
        LogCapture.info("Buy Currency Column is visible..");

        String vObjBuyAmountColumn = Constants.TitanReportsOR.getProperty("FXBuyAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyAmountColumn, "visible"));
        LogCapture.info("Buy Amount Column is visible..");

        String vObjRateColumn = Constants.TitanReportsOR.getProperty("FXRateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjRateColumn, "visible"));
        LogCapture.info("Rate Column is visible..");

        String vObjFXTypeColumn = Constants.TitanReportsOR.getProperty("FXTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXTypeColumn, "visible"));
        LogCapture.info("FX Type Column is visible..");

        String vObjFXStatusColumn = Constants.TitanReportsOR.getProperty("FXStatusColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXStatusColumn, "visible"));
        LogCapture.info("Status Column is visible..");

        String vObjFXProfitColumn = Constants.TitanReportsOR.getProperty("FXProfitColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXProfitColumn, "visible"));
        LogCapture.info("Profit Column is visible..");

        String vObjDealerNameColumn = Constants.TitanReportsOR.getProperty("FXDealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        //Navigating on top of page
        //JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        //js.executeScript("window.scrollTo(0, 0)");
        //Constants.key.pause("10", "");

        //Slid slider to right
        //String vObjSliderButton = Constants.TitanCustomersOR.getProperty("HorizontalTableSlider");
        //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSliderButton, "visible"));
        //Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSliderButton, ""));
        //Constants.key.pause("2", "");
        //WebElement slider = Constants.driver.findElement(By.xpath(vObjSliderButton));
        //int width = slider.getSize().getWidth();
        //Actions move = new Actions(Constants.driver);
        //move.moveToElement(slider, ((width * 10) / 100), 0).click();
        //move.build().perform();
        //LogCapture.info("Slider dragged to right...");
        //Constants.key.pause("2", "");


        String vObjClientTypeColumn = Constants.TitanReportsOR.getProperty("FXClientTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTypeColumn, "visible"));
        LogCapture.info("Client Type Column is visible..");

        String vObjFXDueToColumn = Constants.TitanReportsOR.getProperty("FXDueToColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXDueToColumn, "visible"));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXDueToColumn, ""));
        LogCapture.info("FX ticket report page - All details are visible..");
    }


    @And("^User clicks on (Filter icon|Incoming funds Queue|Payment out Queue|FX tickets queue)$")
    public void userClicksOnFilterIcon(String option) throws Throwable {
        if (option.equals("Filter icon")) {
            String vObjFilter = Constants.TitanPaymentInOR.getProperty("FilterIcon");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFilter, ""));
            LogCapture.info("User clicks on Filter icon.");
        } else if (option.equals("Incoming funds Queue")) {
            String vObjIncomingFundsQueue = Constants.TitanPaymentInOR.getProperty("IncomingFundsQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIncomingFundsQueue, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjIncomingFundsQueue, ""));
            // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjIncomingFundsQueue, "MoveToElement"));
            // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjIncomingFundsQueue, "click"));
            LogCapture.info("User clicks on Incoming funds Queue");

        } else if (option.equals("Payment out Queue")) {
            String vObjPaymentOutDetailpagelink = Constants.TitanPaymentOutOR.getProperty("PaymentOutDetailpagelink");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutDetailpagelink, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPaymentOutDetailpagelink, ""));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutDetailpagelink, "MoveToElement"));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutDetailpagelink, "click"));
            LogCapture.info("User clicks on Payment out Queue");

        } else if (option.equals("FX tickets queue")) {
            String vObjFXTicketDetailLink = Constants.TitanFXTicketsOR.getProperty("FXTicketDetailLink");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketDetailLink, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXTicketDetailLink, ""));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFXTicketDetailLink, "MoveToElement"));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFXTicketDetailLink, "click"));
            LogCapture.info("User clicks on FX tickets queue");

        }

    }

    @And("^User search by (keyword|fxkeyword|CustomerKeyword) \"([^\"]*)\"$")
    public void userSearchByKeyword(String filter, String searchstring) throws Throwable {
        if (filter.equals("keyword")) {
            String vObjKeywordFilterText = Constants.TitanPaymentInOR.getProperty("KeywordFilterText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeywordFilterText, "enter"));
            LogCapture.info("User search by " + filter + "->" + searchstring);
            Constants.key.pause("2", "");

        } else if (filter.equals("fxkeyword")) {
            String vObjKeywordFilterText = Constants.TitanFXTicketsOR.getProperty("KeySearchText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeywordFilterText, "enter"));
            LogCapture.info("User search by " + filter + "->" + searchstring);
            Constants.key.pause("2", "");

        } else if (filter.equals("CustomerKeyword")) {
            String vObjKeywordFilterText = Constants.TitanCustomersOR.getProperty("KeyWorkFilterText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjKeywordFilterText, searchstring));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeywordFilterText, "enter"));
            LogCapture.info("User search by " + filter + "->" + searchstring);
            Constants.key.pause("2", "");

        }

    }

    @Then("^User navigate to search result and click on (ClientID|Result) \"([^\"]*)\" record$")
    public void userNavigateToSearchResultAndClickOnRecord(String column, String data) throws Throwable {
        if (column.equals("Result")) {
            int a = Integer.parseInt(data) - 1;
            String vObjDateDateColumn = "//tbody/tr[@id='row-" + a + "']/td[7]/a[1]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDateDateColumn, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDateDateColumn, ""));
            // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDateDateColumn, "MoveToElement"));
            //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjDateDateColumn, "click"));
            LogCapture.info("User navigate to search result and click on " + column + "'" + data + "' record");
        } else if (column.equals("ClientID")) {
            String vObjClientID = "//a[contains(text(),'" + data + "')]";
            // LogCapture.info(vObjClientID);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientID, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClientID, ""));
            // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjClientID, "MoveToElement"));
            //  Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjClientID, "click"));
            LogCapture.info("User navigate to search result and click on " + column + "'" + data + "' record");

        }
    }


    @And("^User navigate to (Debitor Number|Payment out|Customer|FX ticket) \"([^\"]*)\" Detail$")
    public void userNavigateToDebitorNumberDetail(String page, String data) throws Throwable {
        if (page.equals("Debitor Number")) {
            String de = data.substring(4);
            String vObjKeywordFilterText = "//h1[contains(text(),'Debitor Number #" + de + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            LogCapture.info("User navigate to " + page + " #" + de + " Detail");
        } else if (page.equals("Payment out")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'Payment out #" + data + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
        } else if (page.equals("Customer")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'" + data + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

            String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
            String vObjCustomerStatus = Constants.TitanPaymentOutOR.getProperty("CustomerStatus");
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerStatus, "visible"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCustomerStatus, "ACTIVE"));
            LogCapture.info("Customer status is Active verified..");

        } else if (page.equals("FX ticket")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'" + data + "')]";
            String vObjKeywordFilterText1 = "//h1[contains(text(),'Debitor Number #" + data + "')]";

            LogCapture.info(vObjKeywordFilterText);

            //String vObjKeywordFilterText = "//h1[contains(text(),'FX ticket for client #')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

            //String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
        }
    }

    @And("^User navigate to Payment In Titan page$")
    public void userNavigateToPaymentInTitanPage() throws Exception {
        String vObjPaymentInH1 = Constants.TitanPaymentInOR.getProperty("PaymentInH1");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInH1, ""));
        LogCapture.info("User navigate to Payment In Titan page");

    }

    @And("^Select (Organisation|Business Partner) as \"([^\"]*)\"$")
    public void selectOrganisationAs(String dropdown, String organization) throws Throwable {

        if (dropdown.equals("Organisation")) {
            String vObjFilterOrganisation = Constants.TitanPaymentOutOR.getProperty("FilterOrganisation");
            //LogCapture.info(vObjFilterOrganisation);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFilterOrganisation, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFilterOrganisation, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFilterOrganisation, "click"));
            Assert.assertEquals("PASS", Constants.key.selectOrganisationBussinessPartner(dropdown, organization));
            LogCapture.info("User Selected " + dropdown + "as " + organization);
        } else if (dropdown.equals("Business Partner")) {
            String vObjFilterOrganisation = Constants.TitanPaymentOutOR.getProperty("FilterBusinessPartner");
            //LogCapture.info(vObjFilterOrganisation);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFilterOrganisation, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFilterOrganisation, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjFilterOrganisation, "click"));
            Assert.assertEquals("PASS", Constants.key.selectOrganisationBussinessPartner(dropdown, organization));
            LogCapture.info("User Selected " + dropdown + "as " + organization);
            Constants.key.pause("8", "");
        }

    }


    @And("^User navigate to (Payment Out Queue|Payment In Queue|FX tickets queue) page$")
    public void userNavigateToPaymentOutQueuePage(String page) throws Throwable {
        if (page.equals("Payment Out Queue")) {
            String vObjPaymentOutHeading = Constants.TitanPaymentOutOR.getProperty("PaymentOutHeading");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutHeading, ""));
            String HeadingPaymentOut = Constants.key.getText(vObjPaymentOutHeading, "");
            LogCapture.info(HeadingPaymentOut);

            LogCapture.info("User navigate to" + page + "page");
        } else if (page.equals("Payment In Queue")) {
            String vObjPaymentInHeading = Constants.TitanPaymentInOR.getProperty("PaymentInH1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInHeading, ""));
            String HeadingPaymentIn = Constants.key.getText(vObjPaymentInHeading, "");
            LogCapture.info(HeadingPaymentIn);

            LogCapture.info("User navigate to" + page + "page");
        } else if (page.equals("FX tickets queue")) {
            String vObjFXTicketQueueHeaderg = Constants.TitanFXTicketsOR.getProperty("FXQueueH1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketQueueHeaderg, ""));
            String HeadingPaymentIn = Constants.key.getText(vObjFXTicketQueueHeaderg, "");
            LogCapture.info(HeadingPaymentIn);

            LogCapture.info("User navigate to" + page + "page");
        }
    }

    @And("^Select Viewing payments type as (Future|Current)$")
    public void selectViewingPaymentsTypeAsFuture(String type) throws Throwable {
        if (type.equals("Future")) {
            String vObjPaymentOutTypeFuture = Constants.TitanPaymentOutOR.getProperty("PaymentOutTypeFuture");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutTypeFuture, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutTypeFuture, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutTypeFuture, "click"));
            LogCapture.info("User Select Viewing payments type as " + type);


        } else if (type.equals("Current")) {
            String vObjPaymentOutTypeCurrent = Constants.TitanPaymentOutOR.getProperty("PaymentOutTypeCurrent");

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutTypeCurrent, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutTypeCurrent, "MoveToElement"));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjPaymentOutTypeCurrent, "click"));
            LogCapture.info("User Select Viewing payments type as " + type);
        }
    }

    @Then("^User Search from Right Hand Side top search with searchkey \"([^\"]*)\"$")
    public void userSearchFromRightHandSideTopSearchWithSearchkey(String seachkey) throws Throwable {
        String vObjPaymentOutRightHandTopSearch = Constants.TitanPaymentOutOR.getProperty("PaymentOutRightHandTopSearch");

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutRightHandTopSearch, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPaymentOutRightHandTopSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPaymentOutRightHandTopSearch, seachkey));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPaymentOutRightHandTopSearch, "enter"));
        LogCapture.info("User Search from Right Hand Side top search with searchkey " + seachkey);
    }

    @And("^Click on Apply filter button$")
    public void clickOnApplyFilterButton() throws Throwable {
        String vObjApplyFilterbutton = Constants.TitanCustomersOR.getProperty("ApplyFilterbutton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApplyFilterbutton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjApplyFilterbutton, ""));

        // Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjApplyFilterbutton, "MoveToElement"));
        //Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjApplyFilterbutton, "click"));
        Constants.key.pause("5", "");
        LogCapture.info("User click on Apply filter button");

    }


    @And("^User should get all \"([^\"]*)\" records in search result$")
    public void userShouldGetAllRecordsInSearchResult(String org) throws Throwable {
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.verifyOrganisationIntableCustomer("", org, "1"));
        LogCapture.info("Search result content is validated for Organisation " + org);

    }

    @And("^User should get all \"([^\"]*)\" records in column \"([^\"]*)\"$")
    public void userShouldGetAllRecordsInColumn(String org, String column) throws Throwable {

        String vObjPageNavigation = Constants.TitanFXTicketsOR.getProperty("PageNavigation");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPageNavigation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyOrganisationIntableCustomer("", org, column));
        LogCapture.info("Search result content is validated for Organisation " + org + " in table column " + column);

    }

    @And("^User clicks on required \"([^\"]*)\" ticket from records displayed$")
    public void userClicksOnRequiredTicketFromRecordsDisplayed(String clientNumber) throws Throwable {
        String vObjFirstRecord = "//*[contains(@id,'Table')]//tr[1]//*[text()='" + clientNumber + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirstRecord, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFirstRecord, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirstRecord, ""));
        LogCapture.info("User clicks on first available record for clientNumber " + clientNumber);

    }

    @And("^User is able to view FX record details for clientNumber\"([^\"]*)\" clientName\"([^\"]*)\"$")
    public void userIsAbleToViewFXRecordDetailsForClientNumber(String clientNumber, String clientName) throws Throwable {

        String vObjClientName = "//*[text()='Client name']//following::*[@href='#other-info'][text()='" + clientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientName, "visible"));
        LogCapture.info("Client name :" + clientName + " is visible...");

        String vObjFXTicketRecordHeader = Constants.TitanQueuesOR.getProperty("FXTicketRecordHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketRecordHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXTicketRecordHeader, "visible"));
        String FXTicketRecordHeaderStr = Constants.driver.findElement(By.xpath(vObjFXTicketRecordHeader)).getText();
        if (FXTicketRecordHeaderStr.contains(clientNumber)) {
            LogCapture.info("Required Header visible: " + FXTicketRecordHeaderStr);
        } else {
            LogCapture.info("Required Header NOT visible: " + FXTicketRecordHeaderStr);
            Assert.fail();
        }
    }

    @And("^User clicks on (FX Tickets Queue|Payee Report) hyperlink$")
    public void userClicksOnFXTicketsQueueHyperlink(String TargetPage) throws Throwable {
        String vObjHyperLink = null;
        if (TargetPage.equalsIgnoreCase("FX Tickets Queue")) {
            vObjHyperLink = Constants.TitanQueuesOR.getProperty("FXTicketsQueueHyperLink");
        } else if (TargetPage.equalsIgnoreCase("Payee Report")) {
            vObjHyperLink = Constants.TitanReportsOR.getProperty("PayeeReportHyperLink");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjHyperLink, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjHyperLink, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjHyperLink, ""));
        LogCapture.info("User clicks on hyperlink: " + TargetPage);

    }

    @And("^User search for Email \"([^\"]*)\" in search box and hits Enter key$")
    public void userSearchForEmailInSearchboxAndHitsEnterKey(String EmailAdd) throws Throwable {

        String vObjFXSearchAnother = Constants.TitanQueuesOR.getProperty("FXSearchAnother");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXSearchAnother, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXSearchAnother, "visible"));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXSearchAnother, ""));
        String EmailAddress = CONFIG.getProperty(EmailAdd);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFXSearchAnother, EmailAddress));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFXSearchAnother, "enter"));
        Constants.key.pause("5", "");
        LogCapture.info("User search client details with EmailAddress: " + EmailAddress);

    }

    @And("^User is able to view customer details EmailAddress\"([^\"]*)\" Contact\"([^\"]*)\" CountryOfResidence\"([^\"]*)\" for clientNumber\"([^\"]*)\" and clientName\"([^\"]*)\"$")
    public void userIsAbleToViewCustomerDetailsEmailAddressContactForClientNumberAndClientName(String EmailAdd, String Contacts, String CountryResidence, String clientTAN, String CustomerName) throws Throwable {

        Constants.key.pause("4", "");
        String vObjCustomersHyperlink = Constants.TitanCustomersOR.getProperty("CustomersHyperlink");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomersHyperlink, "visible"));
        LogCapture.info("Customer detail page is visible...");

        String EmailAddress = CONFIG.getProperty(EmailAdd);
        String Contact = CONFIG.getProperty(Contacts);
        String CountryOfResidence = CONFIG.getProperty(CountryResidence);
        String clientNumber = CONFIG.getProperty(clientTAN);
        String clientName = CONFIG.getProperty(CustomerName);


        String vObjClientName = "//*[contains(text(),'" + clientName + " ')]";
        LogCapture.info(vObjClientName);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientName, "visible"));
        LogCapture.info("Client name :" + clientName + " is visible...");

        String vObjClientNumber = "//*[contains(text(),'#" + clientNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumber, "visible"));
        LogCapture.info("Client Number :" + clientNumber + " is visible...");

        String vObjContactName = "//*[text()='Contacts']//following::a[@href='#'][text()='" + Contact + " ']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContactName, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContactName, ""));
        Constants.key.pause("3", "");
        String vObjCustomerPrimaryContact = Constants.TitanCustomersOR.getProperty("CustomerPrimaryContact");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerPrimaryContact, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerPrimaryContact, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCustomerPrimaryContact, ""));
        LogCapture.info("User clicks on particular customer primary contact button..");

        String vObjContactEmailHeader = Constants.TitanCustomersOR.getProperty("ContactEmailHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContactEmailHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjContactEmailHeader, "visible"));
        LogCapture.info("Email header is visible..");

        String vObjEmailValue = Constants.TitanCustomersOR.getProperty("EmailAddressValue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjEmailValue, EmailAddress));
        LogCapture.info("Email Value: " + EmailAddress + " is visible..");

        String vObjCountryOfResidence = "//*[text()='Country of residence']//following::*[contains(text(),'" + CountryOfResidence + "')]";
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCountryOfResidence, "visible"));
        LogCapture.info("Country Of Residence: " + CountryOfResidence + " is visible..");

    }

    @And("^User is able to view Payees Reports page details in Titan and Not error message$")
    public void userIsAbleToViewPayeesReportsPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPayeeReportHeader = Constants.TitanPayeeOR.getProperty("PayeeReportHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeReportHeader, ""));
        LogCapture.info("User is on Payee Reports in Titan page..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjFilterListBtn = Constants.TitanQueuesOR.getProperty("FilterListBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFilterListBtn, "visible"));
        LogCapture.info("Filter list button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjAddedDateColumn = Constants.TitanReportsOR.getProperty("PayeeAddedDate");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddedDateColumn, "visible"));
        LogCapture.info("Added Date Column is visible..");

        String vObjOrganisationColumn = Constants.TitanReportsOR.getProperty("PayeeOrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBusinessPartnerColumn = Constants.TitanReportsOR.getProperty("PayeeBusinessPartner");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBusinessPartnerColumn, "visible"));
        LogCapture.info("Business Partner Column is visible..");

        String vObjClientNumberColumn = Constants.TitanReportsOR.getProperty("PayeeClientNumber");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNumberColumn, "visible"));
        LogCapture.info("Client# is visible..");

        String vObjPayeeNameColumn = Constants.TitanReportsOR.getProperty("PayeeName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeNameColumn, "visible"));
        LogCapture.info("Payee Name Column is visible..");

        String vObjPayeeAccountIBANColumn = Constants.TitanReportsOR.getProperty("PayeeAccountIBAN");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeAccountIBANColumn, "visible"));
        LogCapture.info("Payee Account/IBAN Column is visible..");

        String vObjPayeeCountryColumn = Constants.TitanReportsOR.getProperty("PayeeCountry");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeCountryColumn, "visible"));
        LogCapture.info("Payee Country Column is visible..");

        String vObjPayeeCurrencyColumn = Constants.TitanReportsOR.getProperty("PayeeCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeCurrencyColumn, "visible"));
        LogCapture.info("Payee Currency Column is visible..");

        String vObjPayeeStatusColumn = Constants.TitanReportsOR.getProperty("PayeeStatus");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeStatusColumn, "visible"));
        LogCapture.info("Payee Status Column is visible..");

        String vObjPayeeDeletedColumn = Constants.TitanReportsOR.getProperty("PayeeDeleted");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDeletedColumn, "visible"));
        LogCapture.info("Deleted Column is visible..");

        LogCapture.info("Payee Report page - All details are visible..");

    }

    @And("^User is able to view Payees details for clientNumber\"([^\"]*)\"$")
    public void userIsAbleToViewPayeesDetailsForClientNumberClientName(String clientNumber) throws Throwable {

        String vObjPayeeRecordHeader = "//span[@class='breadcrumbs']//parent::h1[contains(text(),'Client #" + clientNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeRecordHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeRecordHeader, "visible"));
        LogCapture.info("Client #" + clientNumber + " Header is visible");

        String vObjPayeeDetailsPage = Constants.TitanReportsOR.getProperty("PayeeDetailsPage");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsPage, "visible"));
        LogCapture.info("Payee Details page is visible..");

    }

    @And("^User is on Invoices in Titan page and message is displayed and No error Message$")
    public void userIsOnInvoicesInTitanPageAndMessageIsDisplayedAndNoErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjInvoicesReportPage = Constants.TitanReportsOR.getProperty("InvoicesReportPage");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInvoicesReportPage, "visible"));

        String vObjInvoicesPageMessage = Constants.TitanReportsOR.getProperty("InvoicesPageMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvoicesPageMessage, ""));
        LogCapture.info("Invoices page message visisble..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

    }


    @Then("^User is able to view Update B2B page details in Titan and Not error message$")
    public void userIsAbleToViewUpdateB2BPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjUpdateB2BPage = Constants.TitanTreasuryOR.getProperty("UpdateB2BPage");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdateB2BPage, "visible"));
        LogCapture.info("Update B2B in Titan header is visible..");

        String vObjSelectAllCheckbox = Constants.TitanTreasuryOR.getProperty("SelectAllCheckbox");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSelectAllCheckbox, "visible"));
        LogCapture.info("Select All at once checkbox is visible..");

        String vObjOrganisationColumn = Constants.TitanTreasuryOR.getProperty("OrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjDealNumberColumn = Constants.TitanTreasuryOR.getProperty("DealNumberColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealNumberColumn, "visible"));
        LogCapture.info("Dealer number Column is visible..");

        String vObjDealerNameColumn = Constants.TitanTreasuryOR.getProperty("B2BDealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer name Column is visible..");

        String vObjCCYCoulmn = Constants.TitanTreasuryOR.getProperty("CCYPairColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCCYCoulmn, "visible"));
        LogCapture.info("CCY Pair Coulmn is visible..");

        String vObjSellingAmountColumn = Constants.TitanTreasuryOR.getProperty("SellingAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellingAmountColumn, "visible"));
        LogCapture.info("Selling Amount Column is visible..");

        String vObjBuyingAmountColumn = Constants.TitanTreasuryOR.getProperty("BuyingAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyingAmountColumn, "visible"));
        LogCapture.info("Buying Amount Column is visible..");

        String vObjDealTypeColumn = Constants.TitanTreasuryOR.getProperty("DealTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealTypeColumn, "visible"));
        LogCapture.info("Deal Type Column is visible..");

        String vObjClientNameColumn = Constants.TitanTreasuryOR.getProperty("ClientNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientNameColumn, "visible"));
        LogCapture.info("Client Name Column is visible..");

        String vObjClientTreasuryDealColumn = Constants.TitanTreasuryOR.getProperty("ClientTreasuryDealColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjClientTreasuryDealColumn, "visible"));
        LogCapture.info("Client/Treasury Deal Column is visible..");

        LogCapture.info("Update B2B page - All details are visible..;");
    }


    @Then("^User is able to view Deal Report page details in Titan and Not error message$")
    public void userIsAbleToViewDealReportPageDetailsInTitanAndNotErrorMessage() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjDealQueueHeader = Constants.TitanTreasuryOR.getProperty("DealQueueHeader");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealQueueHeader, "visible"));
        LogCapture.info("Deal queue in Titan header is visible..");

        String vObjDownloadBtn = Constants.TitanQueuesOR.getProperty("DownloadBtn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDownloadBtn, "visible"));
        LogCapture.info("Download Button is visible..");

        String vObjCustomerSearchAnother = Constants.TitanQueuesOR.getProperty("CustomerSearchAnother");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomerSearchAnother, "visible"));
        LogCapture.info("Another customer search field is visible..");

        String vObjOrganisationColumn = Constants.TitanTreasuryOR.getProperty("DealReportOrganisationColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjOrganisationColumn, "visible"));
        LogCapture.info("Organisation Column is visible..");

        String vObjBankColumn = Constants.TitanTreasuryOR.getProperty("BankColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBankColumn, "visible"));
        LogCapture.info("Bank Column is visible..");

        String vObjExternalReferenceColumn = Constants.TitanTreasuryOR.getProperty("ExternalReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjExternalReferenceColumn, "visible"));
        LogCapture.info("External Reference Column is visible..");

        String vObjBlotterCategoryColumn = Constants.TitanTreasuryOR.getProperty("BlotterCategoryColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBlotterCategoryColumn, "visible"));
        LogCapture.info("Blotter Category Column is visible..");

        String vObjTradeDateColumn = Constants.TitanTreasuryOR.getProperty("TradeDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTradeDateColumn, "visible"));
        LogCapture.info("Trade Date Column is visible..");

        String vObjValueDateColumn = Constants.TitanTreasuryOR.getProperty("ValueDateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjValueDateColumn, "visible"));
        LogCapture.info("Value Date Column is visible..");

        String vObjExchangeRateColumn = Constants.TitanTreasuryOR.getProperty("ExchangeRateColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjExchangeRateColumn, "visible"));
        LogCapture.info("Exchange Rate Column is visible..");

        String vObjSellCCYColumn = Constants.TitanTreasuryOR.getProperty("SellCCYColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSellCCYColumn, "visible"));
        LogCapture.info("Sell CCY Column is visible..");

        String vObjDealReportSellingAmountColumn = Constants.TitanTreasuryOR.getProperty("DealReportSellingAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportSellingAmountColumn, "visible"));
        LogCapture.info("Selling Amount Column is visible..");

        String vObjBuyCCYColumn = Constants.TitanTreasuryOR.getProperty("BuyCCYColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBuyCCYColumn, "visible"));
        LogCapture.info("Buy CCY Column is visible..");

        String vObjDealReportBuyingAmountColumn = Constants.TitanTreasuryOR.getProperty("DealReportBuyingAmountColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportBuyingAmountColumn, "visible"));
        LogCapture.info("Buying Amount Column is visible..");

        String vObjDealReportDealTypeColumn = Constants.TitanTreasuryOR.getProperty("DealReportDealTypeColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportDealTypeColumn, "visible"));
        LogCapture.info("Deal Type Column is visible..");

        ((JavascriptExecutor) Constants.driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Constants.key.pause("2", "");
        String vObjScrollbar = Constants.TitanTreasuryOR.getProperty("Scrollbar");
        Assert.assertEquals("PASS", Constants.key.click(vObjScrollbar, ""));
        LogCapture.info("Clicked on scrollbar..");

        WebElement scrollArea = Constants.driver.findElement(By.xpath(vObjScrollbar));
        ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", scrollArea);
        Constants.key.pause("2", "");
        ((JavascriptExecutor) Constants.driver).executeScript("window.scrollTo(0, 0)");
        Constants.key.pause("2", "");

        String vObjDealerNameColumn = Constants.TitanTreasuryOR.getProperty("DealerNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealerNameColumn, "visible"));
        LogCapture.info("Dealer Name Column is visible..");

        String vObjUpdatedByColumn = Constants.TitanTreasuryOR.getProperty("UpdatedByColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjUpdatedByColumn, "visible"));
        LogCapture.info("Updated By Column is visible..");

        String vObjSourceNameColumn = Constants.TitanTreasuryOR.getProperty("SourceNameColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSourceNameColumn, "visible"));
        LogCapture.info("Source Name Column is visible..");

        String vObjActionColumn = Constants.TitanTreasuryOR.getProperty("ActionColumn");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjActionColumn, "visible"));
        LogCapture.info("Action Column is visible..");

        LogCapture.info("Deal Report page - All details are visible..;");
    }

    @Then("^User is able to view Logout page message with Log In hyperlink$")
    public void userIsAbleToViewLogoutPageMessageWithLogInHyperlink() throws Throwable {

        String vObjLogoutPageMsg = Constants.TitanCustomersOR.getProperty("LogoutPageMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLogoutPageMsg, ""));
        LogCapture.info("User successfully logout..");

        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLogoutPageMsg, "visible"));
        LogCapture.info("Logout page message is visible..");

        String vObjLogInHyperlink = Constants.TitanCustomersOR.getProperty("LogInHyperlink");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjLogInHyperlink, "visible"));
        LogCapture.info("Log In hyperlink is visible..");

    }

    @And("^User is able to view new tab where PDF file is opened$")
    public void userIsAbleToViewNewTabWherePDFFileIsOpened() throws Throwable {

        //Switch to child window
        for (String winHandle : Constants.driver.getWindowHandles()) {
            //Constants.driver.switchTo().window(winHandle);
            // Constants.key.pause("10","");
            // Constants.driver.manage().window().maximize();
            LogCapture.info("Switched to Child window...");
            Constants.key.pause("2", "");
            // Switch back to the original browser (first window)
            Constants.driver.switchTo().window(winHandleBefore);
            LogCapture.info("Switched to Parent window...");
            //String vObjBrand = "//dt[text()='Brand']";
            //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjBrand, "visible"));
            Constants.key.pause("2", "");

        }
    }

    @And("^User enters Add Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" and Clicks on Next button$")
    public void userEntersPayeeDetailsPayeeTypeFirshghtNameLastNameCompanyNameCurrencyReceiveCountryAndClicksOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country) throws Throwable {
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName;
            String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName;
            String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCompanyPayeeType, "selected"));
            LogCapture.info("Company Payee type is selected..");

            String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");
            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);
        Constants.key.pause("3", "");


        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, "400066"));
        Constants.key.pause("2", "");

        String vObjGetAddressButton = Constants.TitanCustomersOR.getProperty("GetAddressButton");
        // Assert.assertEquals("PASS", Constants.key.click(vObjGetAddressButton, ""));
        Constants.key.pause("2", "");

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, "Avenue"));
        Constants.key.pause("2", "");

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, "New York"));
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeTownField, "tab"));

        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User click on first record from Payment in Reports page to navigate to Incoming Funds Reports page$")
    public void userClickOnFirstRecordFromPaymentInReportsPageToNavigateToIncomingFundsReportsPage() throws Throwable {
        String vobjFirstRecordPaymentsInReport = Constants.TitanPaymentInOR.getProperty("FirstRecordPaymentsInReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsInReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsInReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");
        String vobjIncomingFundsReports = Constants.TitanPaymentInOR.getProperty("IncomingFundsReports");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIncomingFundsReports, ""));
        LogCapture.info("Incoming Funds Report page is visible..");
    }


    @Then("^User clicks on Incoming Funds Reports hyperlink for client\"([^\"]*)\" and navigate back to Payment in reports page$")
    public void userClicksOnIncomingFundsReportsHyperlinkToNavigateBackToPaymentInReportsPage(String clientNumber) throws Throwable {
        String vobjPaymentInHeader = "//h1[contains(text(),'Payment In #" + clientNumber + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentInHeader, ""));
        String vobjIncomingFundsReports = Constants.TitanPaymentInOR.getProperty("IncomingFundsReports");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIncomingFundsReports, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjIncomingFundsReports, ""));
        LogCapture.info("User clicks on Incoming Funds hyperlink...");
        String vobjPaymentInReportPageHeader = Constants.TitanPaymentInOR.getProperty("PaymentInReportPageHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentInReportPageHeader, ""));
        LogCapture.info("Payment in report page is visible...");
    }

    @Then("^User should be navigate to Customer details page$")
    public void userShouldBeNavigateToCustomerDetailsPage() throws Throwable {
        String vobjPaymentInCustomerDetails = Constants.TitanPaymentInOR.getProperty("PaymentInCustomerDetails");
        String vobjBrookClongNum = Constants.driver.findElement(By.xpath(vobjPaymentInCustomerDetails)).getText();
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vobjPaymentInCustomerDetails, ""));
        LogCapture.info("User is able to view the customer details of" + vobjBrookClongNum);

    }


    @And("^User clicks on Payment out reports hyperlink to navigate back to Payments out report page$")
    public void userClicksOnPaymentOutReportsHyperlinkToNavigateBackToPaymentsOutReportPage() throws Throwable {
        String vobjPaymentOutReports = Constants.TitanPaymentOutOR.getProperty("PaymentOutReports");
        //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentOutReports, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjPaymentOutReports, ""));
        LogCapture.info("User clicks on Payment out report hyperlink..");
        String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
        LogCapture.info("User is on Payments Out Reports in Titan page..");
    }

    @And("^User click on first record from Payment out Reports page and navigates to Payment out details page for client\"([^\"]*)\"$")
    public void userClickOnFirstRecordFromPaymentOutReportsPageAndNavigatesToPaymentOutDetailsPage(String clientNumber) throws Throwable {
        String vobjFirstRecordPaymentsOutReport = Constants.TitanPaymentInOR.getProperty("FirstRecordPaymentsOutReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsOutReport, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjFirstRecordPaymentsOutReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");
        String vobjIncomingFundsReports = "//h1[contains(text(),'Payment out #" + clientNumber + "-')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIncomingFundsReports, ""));
        LogCapture.info("Incoming Funds Report page is visible..");
    }

    @And("^User selects payment method as DD and selects Select Direct Debit$")
    public void userSelectsPaymentMethodAsDDAndSelectsSelectDirectDebit() throws Throwable {

        String vObjFXCreditPage = Constants.CreateFxTicketOR.getProperty("FXCreditPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXCreditPage, ""));
        LogCapture.info("User is on 3 of 4: Credit page...");

        String vObjPaymentMethodDD = Constants.CreateFxTicketOR.getProperty("PaymentMethodDD");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodDD, ""));
        LogCapture.info("user selects DD as payment method...");

        String vObjSelectDirectDebitHeader = Constants.CreateFxTicketOR.getProperty("SelectDirectDebitHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectDirectDebitHeader, ""));
        LogCapture.info("Select Direct Debit header is visible...");
        Constants.key.pause("2", "");

        String vObjSelectDirectDebitDropArrow = Constants.CreateFxTicketOR.getProperty("SelectDirectDebitDropArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectDirectDebitDropArrow, ""));
        Constants.key.pause("3", "");
        String vObjDirectDebitFirstOption = Constants.CreateFxTicketOR.getProperty("DirectDebitFirstOption");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDirectDebitFirstOption, ""));
        Constants.key.pause("3", "");
        LogCapture.info("Direct Debiter selected...");

    }

    @And("^User selects Direct Debit for Payment In$")
    public void userSelectsDirectDebitForPaymentIn() throws Throwable {

        String vObjSelectDirectDebitHeaderPayIn = Constants.TitanPaymentInOR.getProperty("SelectDirectDebitHeaderPayIn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectDirectDebitHeaderPayIn, ""));
        LogCapture.info("Select Direct Debit header is visible...");
        Constants.key.pause("2", "");

        String vObjSelectDirectDebitDropArrowPayIn = Constants.TitanPaymentInOR.getProperty("SelectDirectDebitDropArrowPayIn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectDirectDebitDropArrowPayIn, ""));
        Constants.key.pause("3", "");
        String vObjDirectDebitFirstOptionPayIn = Constants.TitanPaymentInOR.getProperty("DirectDebitFirstOptionPayIn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDirectDebitFirstOptionPayIn, ""));
        Constants.key.pause("3", "");
        LogCapture.info("Direct Debit selected...");

    }


    @And("^User search for Client Number \"([^\"]*)\" in search box and hits Enter key$")
    public void userSearchForclientIDInSearchboxAndHitsEnterKey(String clientTAN) throws Throwable {

        String vObjFXSearchAnother = Constants.TitanQueuesOR.getProperty("FXSearchAnother");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXSearchAnother, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXSearchAnother, "visible"));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXSearchAnother, ""));
        String ClientNumber = CONFIG.getProperty(clientTAN);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFXSearchAnother, ClientNumber));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFXSearchAnother, "enter"));
        Constants.key.pause("5", "");
        LogCapture.info("User search client details with client number: " + ClientNumber);

    }

    @And("^User is able to view Queues FX Ticket page details in Titan$")
    public void userIsAbleToViewQueuesFXTicketPageDetailsInTitan() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
        LogCapture.info("User is on FX tickets in Titan page..");


    }

    @And("^User is able to view FX tickets Reports page details in Titan$")
    public void userIsAbleToViewFXTicketsReportsPageDetailsInTitan() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXticketsReportPage = Constants.TitanReportsOR.getProperty("FXticketsReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXticketsReportPage, ""));
        LogCapture.info("User is on FX tickets Reports in Titan page..");

    }

    @And("^User is able to view Payment In Reports page details in Titan$")
    public void userIsAbleToViewPaymentInReportsPageDetailsInTitan() throws Throwable {
        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");
        String vObjPaymentInReportPage = Constants.TitanReportsOR.getProperty("PaymentInReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportPage, ""));
        LogCapture.info("User is on Payments In Reports in Titan page..");


    }

    @Then("^User is able to view Payment Out Reports page details in Titan$")
    public void userIsAbleToViewPaymentOutReportsPageDetailsInTitan() throws Throwable {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
        LogCapture.info("User is on Payments Out Reports in Titan page..");


    }

    @And("^User is able to view newly added Payee with PayeeName\"([^\"]*)\" PayeeType\"([^\"]*)\"$")
    public void userIsAbleToViewNewlyAddedPayeeWithPayeeNamePayeeType(String PayeeName, String PayeeType) throws Throwable {

        String vPayeeNameText = "//*[@id='profilePayeeBody']/tr[1]//*[text()='" + PayeeName + "']";
        String vPayeeTypeText = "//*[@id='profilePayeeBody']/tr[1]//*[text()='" + PayeeType + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPayeeNameText, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vPayeeNameText, "visible"));
        LogCapture.info("Payee name is visible...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vPayeeTypeText, "visible"));
        LogCapture.info("Payee type is visible...");

    }

    @And("^User clicks on Payee button under Activity$")
    public void userClicksOnPayeeButtonUnderActivity() throws Throwable {
        String vObjActivityPayees = Constants.TitanPayeeOR.getProperty("ActivityPayees");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjActivityPayees, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjActivityPayees, ""));
        Constants.key.pause("3", "");
        LogCapture.info("User clicks on PAYEES tab under Activity...");
    }

    @And("^User clicks on newly added PayeeName\"([^\"]*)\" and view payee details$")
    public void userClicksOnNewlyAddedPayeeNameAndViewPayeeDetails(String PayeeName) throws Throwable {
        String vPayeeNameText = "//*[@id='profilePayeeBody']/tr[1]//*[text()='" + PayeeName + "']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vPayeeNameText, ""));
        LogCapture.info("user clicks on Payee name...");
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
    }

    @And("^User verify Address Details Address\"([^\"]*)\" Town\"([^\"]*)\" Postcode\"([^\"]*)\"$")
    public void userVerifyAddressDetailsAddressTownPostcode(String Address, String Town, String Postcode) throws Throwable {
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");

        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        String ActualPostcode = Constants.driver.findElement(By.xpath(vObjAddressPostCodeField)).getText();
        LogCapture.info(ActualPostcode);
        if (ActualPostcode.contains(Postcode)) {
            LogCapture.info("Postcode Verified- " + ActualPostcode);
        } else {
            LogCapture.info("Postcode NOT Verified- " + ActualPostcode);
            Assert.fail();
        }
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjAddressPostCodeField, Postcode));
        Constants.key.pause("2", "");
        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjPayeeAddressField, Address));
        String ActualAddress = Constants.driver.findElement(By.xpath(vObjPayeeAddressField)).getText();
        LogCapture.info(ActualAddress);
        if (ActualAddress.contains(Address)) {
            LogCapture.info("Address Verified- " + ActualAddress);
        } else {
            LogCapture.info("Address NOT Verified- " + ActualPostcode);
            Assert.fail();
        }
        Constants.key.pause("2", "");
        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        //Assert.assertEquals("PASS", Constants.key.verifyText(vObjPayeeTownField, Town));
        String ActualTown = Constants.driver.findElement(By.xpath(vObjPayeeTownField)).getText();
        LogCapture.info(ActualTown);
        if (ActualTown.contains(Town)) {
            LogCapture.info("Town Verified- " + ActualTown);
        } else {
            LogCapture.info("Town NOT Verified- " + ActualTown);
            Assert.fail();
        }
        Constants.key.pause("2", "");

    }

    @And("^User enters Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" Address\"([^\"]*)\" Town\"([^\"]*)\" Postcode\"([^\"]*)\"(| for Canada Regulatory)$")
    public void userEntersPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAddressTownPostcodeForCanadaRegulatory(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country, String Address, String Town, String Postcode, String Target) throws Throwable {
        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, FirstName));
            LogCapture.info("First name entered is: " + FirstName);

            String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, LastName));
            LogCapture.info("Last name entered is: " + LastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            //Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCompanyPayeeType, "selected"));
            LogCapture.info("Company Payee type is selected..");

            String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, CompanyName));
            LogCapture.info("Company name entered is: " + CompanyName);
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);

        Constants.key.pause("3", "");

        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disable...");
        }
        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
        Constants.key.pause("2", "");

        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disable...");
        }

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
        Constants.key.pause("2", "");

        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disable...");
        }

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
        Constants.key.pause("2", "");

        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled...");
        }
        if (Target.equalsIgnoreCase("")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeDetailsNextBtnEnable, ""));
            LogCapture.info("Click on Next button...");
        }


        if (Target.equalsIgnoreCase(" for Canada Regulatory")) {
            String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeTownField));
            LogCapture.info("Clear town field..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled...");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled...");
            LogCapture.info("Verified: Town field mandatory..");

            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeAddressField));
            LogCapture.info("Clear Address field..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled...");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled...");
            LogCapture.info("Verified: Address field mandatory..");

            Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjAddressPostCodeField));
            LogCapture.info("Clear Address field..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled...");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled...");
            LogCapture.info("Verified: Postcode field mandatory..");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtnEnable, ""));
            LogCapture.info("Click on Next button...");

        }
    }

    @And("^User updates the NewAddress\"([^\"]*)\" NewTown\"([^\"]*)\" NewPostcode\"([^\"]*)\" for Canada Regulatory$")
    public void userUpdatesTheNewAddressNewTownNewPostcodeForCanadaRegulatory(String NewAddress, String NewTown, String NewPostcode) throws Throwable {

        String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeTownField));
        LogCapture.info("Clear town field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled...");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, NewTown));
        Constants.key.pause("2", "");
        LogCapture.info("Updated town field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled...");
        LogCapture.info("Verified: Town field mandatory..");

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeAddressField));
        LogCapture.info("Clear Address field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled...");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, NewAddress));
        Constants.key.pause("2", "");
        LogCapture.info("Updated Address field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled...");
        LogCapture.info("Verified: Address field mandatory..");

        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAddressPostCodeField));
        LogCapture.info("Clear Address field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled...");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, NewPostcode));
        Constants.key.pause("2", "");
        LogCapture.info("Updated Address field..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled...");
        LogCapture.info("Verified: Postcode field mandatory..");

        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtnEnable, ""));
        LogCapture.info("Click on Next button...");
    }

    @And("^User is on Payee Bank details and clicks on Next button$")
    public void userIsOnPayeeBankDetailsAndClicksOnNextButton() throws Throwable {

        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");
        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^User search for Payee ClientNumber\"([^\"]*)\" Organisation\"([^\"]*)\" and hits Enter key$")
    public void userSearchForPayeeClientNumberOrganisationAndHitsEnterKey(String ClientNumber, String Organisation) throws Throwable {
        String vObjFilterSearchOrganisationDropdownArrow = Constants.TitanQueuesOR.getProperty("FilterSearchOrganisationDropdownArrow");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilterSearchOrganisationDropdownArrow, ""));
        Constants.key.pause("2", "");
        String vObjOrganisation = "//ul[@class='multilist__options']//input[@value='" + Organisation + "']/parent::label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisation, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjOrganisation, ""));
        LogCapture.info("Organisation selected: " + Organisation);
        Constants.key.pause("2", "");
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, ClientNumber));
        LogCapture.info("Searching for Client number: " + ClientNumber);
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");
    }

    @And("^User checks the status of Payee\"([^\"]*)\" is (Active|Inactive)$")
    public void userChecksTheStatusOfPayeeIsActiveOrNot(String ClientName, String Status) throws Throwable {

        String vObjClientName = "//tr[@id='payee-row-0']//*[text()='" + ClientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));

        if (Status.equalsIgnoreCase("Active")) {
            String vObjCurrentStatus = "//tr[@id='payee-row-0']//*[text()='" + ClientName + "']//parent::td//following-sibling::td//*[text()='ACTIVE']";
            String ExpectedStatus = Constants.driver.findElement(By.xpath(vObjCurrentStatus)).getText();
            if (ExpectedStatus.equalsIgnoreCase("Active")) {
                LogCapture.info("Status is ACTIVE..");
            } else {
                LogCapture.info("Customer Status is INACTIVE but should be ACTIVE..");
                Assert.fail();
            }
        }
        if (Status.equalsIgnoreCase("Inactive")) {
            String vObjCurrentStatus = "//tr[@id='payee-row-0']//*[text()='" + ClientName + "']//parent::td//following-sibling::td//*[text()='INACTIVE']";
            String ExpectedStatus = Constants.driver.findElement(By.xpath(vObjCurrentStatus)).getText();
            if (ExpectedStatus.equalsIgnoreCase("Inactive")) {
                LogCapture.info("Status is INACTIVE..");
            } else {
                LogCapture.info("Customer Status is ACTIVE but should be INACTIVE..");
                Assert.fail();
            }

        }
    }

    @And("^User clicks on newly added Payee\"([^\"]*)\" from the list$")
    public void userClicksOnNewlyAddedPayeeNameFromTheList(String ClientName) throws Throwable {
        String vObjClientName = "//tr[@id='payee-row-0']//*[text()='" + ClientName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClientName, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClientName, ""));
        LogCapture.info("User clicks on client name: " + ClientName);
    }

    @And("^User clicks(| again) on newly generated Instruction number$")
    public void userClicksOnNewlyGeneratedInstructionNumber(String clicks) throws Throwable {
        String vObjInstructionNumberSearch = "//*[text()='" + InstructionNumber + "']";

        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Constants.key.pause("2", "");
        if (clicks.equals("")) {
            String vObjDealTypeHeader = Constants.CreateFxTicketOR.getProperty("DealTypeHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealTypeHeader, ""));
        }
        LogCapture.info("User successfully clicked on Instruction number..");
    }

    @And("^User is able to view Option flag as (Yes|No) under deal details$")
    public void userIsAbleToViewOptionFlagAsYes(String OptionFlagStatus) throws Throwable {
        String vObjOptionFlagStatus = null;
        if (OptionFlagStatus.equalsIgnoreCase("Yes")) {
            vObjOptionFlagStatus = Constants.CreateFxTicketOR.getProperty("OptionFlagStatusYes");
        } else if (OptionFlagStatus.equalsIgnoreCase("No")) {
            vObjOptionFlagStatus = Constants.CreateFxTicketOR.getProperty("OptionFlagStatusNo");
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOptionFlagStatus, ""));
        LogCapture.info("User able to view Option flag- " + OptionFlagStatus);
    }

    @Then("^User is able to view Queues Payment Out page details in Titan and Not error message for SIT$")
    public void userIsAbleToViewQueuesPaymentOutPageDetailsInTitanAndNotErrorMessageForSIT() throws Throwable {
        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjPaymentsOutHeader = Constants.TitanQueuesOR.getProperty("PaymentsOutHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsOutHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentsOutHeader, "visible"));
        LogCapture.info("Payments Out header is visible..");
    }


    @And("^User verify PDF file\"([^\"]*)\" downloaded successfully$")
    public void userVerifyPDFFileDownloadedSuccessfully(String fileName) throws Throwable {
        //Assert.assertEquals("PASS",Constants.key.renameDownloadedFile("",fileName));
        Assert.assertEquals("PASS", Constants.key.defaultDownloadFilesOperations("isFileDownloaded", fileName));
        LogCapture.info("PDF file downloaded successfully..");
        Assert.assertEquals("PASS", Constants.key.defaultDownloadFilesOperations("deleteAllFiles", fileName));
        LogCapture.info("Deleted All downloaded files..");
    }


    @And("^User able to view (|Add new card Window with )Warning message for EU Customers$")
    public void userAbleToViewAddNewCardWindowWithWarningMessageForEUCustomers(String TargetScreen) throws Throwable {

        if (TargetScreen.equalsIgnoreCase("Add new card Window with ")) {
            Constants.key.pause("5", "");
            for (String winHandle : Constants.driver.getWindowHandles()) {
                Constants.driver.switchTo().window(winHandle);
                Constants.driver.manage().window().maximize();
                LogCapture.info("Switched to Child window...");
            }
            String vObjAddNewCardPage = Constants.CreateFxTicketOR.getProperty("AddNewCardPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddNewCardPage, ""));
            LogCapture.info("Add new card page is visible on child window...");
            Constants.key.pause("3", "");
        }
        String WarningMsgEU = Constants.CONFIG.getProperty("WarningMsgEU");
        String vObjWarningMsgEU = Constants.CreateFxTicketOR.getProperty("WarningMsgEU");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjWarningMsgEU, WarningMsgEU));
        LogCapture.info("Warning for EU customer is visible on Add new card child window...");

        if (TargetScreen.equalsIgnoreCase("Add new card Window with ")) {
            Constants.driver.switchTo().window(winHandleBefore);
        }

    }

    @And("^User selects payment method as (Card|Bank)(| for FX)$")
    public void userSelectsPaymentMethodAsCard(String PaymentType, String Scenario) throws Throwable {
        Constants.key.pause("2", "");
        if (PaymentType.equalsIgnoreCase("Card")) {
            String vObjPaymentMethodCard = null;
            if (Scenario.equalsIgnoreCase("")) {
                vObjPaymentMethodCard = Constants.CreateFxTicketOR.getProperty("CardPaymentMethods");
            }
            if (Scenario.equalsIgnoreCase(" for FX")) {
                vObjPaymentMethodCard = Constants.CreateFxTicketOR.getProperty("PaymentMethodCard");
            }
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodCard, ""));
            LogCapture.info("clicking on Card tab...");
        }

        if (PaymentType.equalsIgnoreCase("Bank")) {
            String vObjPaymentMethodBanks = null;
            if (Scenario.equalsIgnoreCase("")) {
                vObjPaymentMethodBanks = Constants.CreateFxTicketOR.getProperty("BankPaymentMethods");
            }
            if (Scenario.equalsIgnoreCase(" for FX")) {
                vObjPaymentMethodBanks = Constants.CreateFxTicketOR.getProperty("PaymentMethodBank");
            }
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodBanks, ""));
            LogCapture.info("clicking on Bank tab...");
        }

    }

    @And("^User (|does not )observe Warning message for Card Payments$")
    public void userObserveWarningMessageForCardPayments(String WarningVisible) throws Throwable {
        if (WarningVisible.equalsIgnoreCase("")) {
            String WarningMsgEU = Constants.CONFIG.getProperty("WarningMsgEU");
            String vObjFXSPOTWarningMsgEU = Constants.CreateFxTicketOR.getProperty("FXSPOTWarningMsgEU");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXSPOTWarningMsgEU, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjFXSPOTWarningMsgEU, WarningMsgEU));
            LogCapture.info("Warning for EU customer is visible while 1st payment using Card...");
        }
        if (WarningVisible.equalsIgnoreCase("does not ")) {
            Constants.key.pause("2", "");
            String vObjFXSPOTWarningMsgEU = Constants.CreateFxTicketOR.getProperty("FXSPOTWarningMsgEU");
            Assert.assertEquals("PASS", Constants.key.notexist(vObjFXSPOTWarningMsgEU, ""));
            LogCapture.info("Warning for EU customer is NOT visible while payment...");
        }
    }

    @And("^User clicks on X to close the FX Deal$")
    public void userClicksOnXToCloseTheFXDeal() throws Throwable {
        String vObjCloseSlip = Constants.CreateFxTicketOR.getProperty("CloseSlip");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCloseSlip, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Closing the slip for ongoing payment...");
    }

    @And("^User clicks on (FX TICKETS|) tab$")
    public void userClicksOnFXTICKETSTab(String TargetTab) throws Throwable {
        if (TargetTab.equalsIgnoreCase("FX TICKETS")) {
            String vObjFXTicketTab = Constants.CreateFxTicketOR.getProperty("FXTicketTab");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXTicketTab, ""));
            Constants.key.pause("2", "");
            String vObjFXPagination = Constants.CreateFxTicketOR.getProperty("FXPagination");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXPagination, ""));
        }
        LogCapture.info("Clicked on " + TargetTab + " tab...");
    }

    @And("^User is able to view and click on FX Deal\"([^\"]*)\"$")
    public void userIsAbleToViewAndClickOnFXDeal(String DealNumber) throws Throwable {
        String vObjDealReference="";
        if(DealNumber.equalsIgnoreCase("InstructionNumber")){
             vObjDealReference = "//tbody[@id='profileFxTicketBody']//*[contains(text(),'" + InstructionNumber + "')]";
        }else {
             vObjDealReference = "//tbody[@id='profileFxTicketBody']//*[contains(text(),'" + DealNumber + "')]";
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealReference, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealReference, ""));
        Constants.key.pause("2", "");
        LogCapture.info("Clicked on " + DealNumber + " deal reference...");
    }

    @And("^User clicks on Add a Drawdown button on FX ticket for client$")
    public void userClicksOnAddADrawdownButtonOnFXTicketForClient() throws Throwable {
        String vObjAddDrawdownBtn = Constants.CreateFxTicketOR.getProperty("AddDrawdownBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddDrawdownBtn, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddDrawdownBtn, ""));
        LogCapture.info("Clicking on Add a Drawdown button...");
    }

    @And("^User enters InstructedBy\"([^\"]*)\" and clicks on Next button on Drawdown details page$")
    public void userEntersInstructedByAndClicksOnNextButtonOnDrawdownDetailsPage(String instructedBy) throws Throwable {

        String vObjDrawdownDetailsPage = Constants.CreateFxTicketOR.getProperty("DrawdownDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDrawdownDetailsPage, ""));

        String vObjInstructedByDrawdown = Constants.CreateFxTicketOR.getProperty("InstructedByDrawdown");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructedByDrawdown, ""));
        Constants.key.pause("2", "");
        String vObjInstructedBySearchDrawdown = Constants.CreateFxTicketOR.getProperty("InstructedBySearchDrawdown");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructedBySearchDrawdown, instructedBy));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearchDrawdown, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructedBySearchDrawdown, "enter"));
        LogCapture.info("Instructed By: " + instructedBy + " is selected..");

        Constants.key.pause("2", "");
        String vObjNextBtnDrawdown = Constants.CreateFxTicketOR.getProperty("NextBtnDrawdown");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNextBtnDrawdown, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjNextBtnDrawdown, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User is on Credit page of Drawdown$")
    public void userIsOnCreditPageOfDrawdown() throws Throwable {
        String vObjCreditPageDrawdown = Constants.CreateFxTicketOR.getProperty("CreditPageDrawdown");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCreditPageDrawdown, ""));
        LogCapture.info("User is on 2 of 3: Credit page..");
    }

    @And("^User is on Credit page and selects Card for Credit using the First four digits of card \"([^\"]*)\" and CVV \"([^\"]*)\" and clicks on add credit button$")
    public void userIsOnCreditPageAndSelectsCardForCreditUsingTheFirstFourDigitsOfCardAndCVVAndClicksOnAddCreditButton(String CardNumFirst, String CVV) throws Throwable {
        String vCreditMethodCard = Constants.CreateFxTicketOR.getProperty("CreditMethodCard");
        Assert.assertEquals("PASS", Constants.key.click(vCreditMethodCard, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vSelectCard = Constants.CreateFxTicketOR.getProperty("SelectCard");
        Assert.assertEquals("PASS", Constants.key.click(vSelectCard, ""));
        String vWriteCardNumber = Constants.CreateFxTicketOR.getProperty("SelectCardSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vWriteCardNumber, CardNumFirst));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vWriteCardNumber, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vWriteCardNumber, "enter"));

        String vObjCVVfield = Constants.CreateFxTicketOR.getProperty("CardCvv");
        Assert.assertEquals("PASS", Constants.key.click(vObjCVVfield, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVVfield, CVV));
        Constants.key.pause("2", "");
        LogCapture.info("CVV entered is: " + CVV);

        String vAddCreditBtn = Constants.CreateFxTicketOR.getProperty("AddCreditButton");
        Assert.assertEquals("PASS", Constants.key.click(vAddCreditBtn, ""));
    }

    @And("^User clicks on Client type as \"([^\"]*)\"$")
    public void userClicksOnClientTypeAs(String value) throws Throwable {
        if (value.equalsIgnoreCase("PFX")) {
            String vPFXFilter = Constants.TitanCustomersOR.getProperty("PFX_Filter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPFXFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPFXFilter, ""));
            Assert.assertEquals("PASS", Constants.key.pause("4", ""));
        } else if (value.equalsIgnoreCase("CFX")) {
            String vCFXFilter = Constants.TitanCustomersOR.getProperty("ClientCFX");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vCFXFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vCFXFilter, ""));
            Assert.assertEquals("PASS", Constants.key.pause("4", ""));
        }
    }

    @And("^User clicks on the First Hyperlink generated$")
    public void userClicksOnTheFirstHyperlinkGenerated() throws Exception {

        String vHyperlink = Constants.TitanCustomersOR.getProperty("Hyperlink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vHyperlink, ""));
        Assert.assertEquals("PASS", Constants.key.click(vHyperlink, ""));
        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
    }


    @And("^User is on Add Payment Page and clicks on Skip Button$")
    public void userIsOnAddPaymentPageAndClicksOnSkipButton() throws Exception {

        String vSkipButton = TitanCustomersOR.getProperty("ConfirmSkipBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
    }

    @And("^User is on Credit page and selects Card for Credit using the First four digits of card \"([^\"]*)\" and CVV \"([^\"]*)\"$")
    public void userIsOnCreditPageAndSelectsCardForCredit(String value, String CVV) throws Exception {


        String vCreditMethodCard = Constants.CreateFxTicketOR.getProperty("CreditMethodCard");
        String vSelectCard = Constants.CreateFxTicketOR.getProperty("SelectCard");
        String vWriteCardNumber = Constants.CreateFxTicketOR.getProperty("SelectCardSearch");
        Assert.assertEquals("PASS", Constants.key.click(vCreditMethodCard, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vSelectCard, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vWriteCardNumber, value));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vWriteCardNumber, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vWriteCardNumber, "enter"));

        String vObjCVVfield = Constants.CreateFxTicketOR.getProperty("CardCvv");
        Assert.assertEquals("PASS", Constants.key.click(vObjCVVfield, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVVfield, CVV));
        Constants.key.pause("2", "");
        LogCapture.info("CVV entered is: " + CVV);

        String vAddCreditBtn = Constants.CreateFxTicketOR.getProperty("AddCreditButton");
        Assert.assertEquals("PASS", Constants.key.click(vAddCreditBtn, ""));


    }

    @And("^User is on Add a Payment page and clicks on Skip button$")
    public void userIsOnAddAPaymentPageAndClicksOnSkipButton() throws Exception {

        String vObjFXAddPaymentPageSkipBtn = Constants.CreateFxTicketOR.getProperty("FXAddPaymentPageSkipBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXAddPaymentPageSkipBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXAddPaymentPageSkipBtn, ""));
        LogCapture.info("User clicks on SKIP button...");

    }

    @And("^User clicks in Instructions button and is navigated to the instructions page$")
    public void userClicksInInstructionsButtonAndIsNavigatedToTheInstructionsPage() throws Exception {

        String vObjInstructionsBtn = CreateFxTicketOR.getProperty("InstructionsBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionsBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionsBtn, ""));
        LogCapture.info("Clicking on instructions button...");
        Constants.key.pause("2", "");
    }

    @And("^User searches for the new instruction number$")
    public void userSearchesForTheNewInstructionNumber() throws Exception {

        String vOjbInstHeader = CreateFxTicketOR.getProperty("InstHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vOjbInstHeader, ""));
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, InstructionNumber));
        LogCapture.info("Searching for Client number : " + InstructionNumber);
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");

        String vclientNumberXpath = "//*[contains(text(),'" + InstructionNumber + "')]";
        //String vclientNumberXpath= Constants.TitanCustomersOR.getProperty("CustomerFirstLine");
        //String vObjCustomerDetailLink = Constants.CreateFxTicketOR.getProperty("CustomerDetailLink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vclientNumberXpath, ""));


    }

    @And("^User clicks on Yes button for FX credit skip popup$")
    public void userClicksOnYesButtonForCreditSkipPopup() throws Throwable {
        Constants.key.pause("3", "");
        String vObjFXCreditSkipYesBtn = Constants.CreateFxTicketOR.getProperty("FXCreditSkipYesBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXCreditSkipYesBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXCreditSkipYesBtn, ""));
        LogCapture.info("Clicking on Yes button for FX credit skip pop-up....");
        Constants.key.pause("3", "");

    }

    @Then("^User validates Delete Payment Button is disabled$")
    public void userValidatesDeletePaymentButtonIsDisabled() throws Exception {
        LogCapture.info("Validating the delete payment button is disabled....");
        Constants.key.pause("2", "");
        String vObjDisabledPaymentDeleteBtn = Constants.TitanPaymentOutOR.getProperty("DisabledPaymentDeleteBtn");
        Assert.assertEquals("PASS", Constants.key.exist(vObjDisabledPaymentDeleteBtn, ""));

    }


    @And("^User Click on Apply button$")
    public void userClickOnApplyButton() throws Exception {
        LogCapture.info("User is now click on the Appply button after applying filter");
        String vObjApply = Constants.TitanCDSAPhase1OR.getProperty("ApplyButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjApply, ""));
        Constants.key.pause("5", "");

    }

    @And("^User Successfully landed on blank page on Titan$")
    public void userSuccessfullyLandedOnBlankPageOnTitan() throws Exception {
        LogCapture.info("Blank Page loading ......");
        Constants.key.pause("3", "");
        String vobjectDashboard = Constants.TitanCDSAPhase1OR.getProperty("ClientNumber");
        Assert.assertEquals("PASS", Constants.key.notexist(vobjectDashboard, ""));
        LogCapture.info("BlankPage loaded successfully");
    }

    @When("^User select file to upload and click on upload button$")
    public void userSelectFileToUploadAndClickOnUploadButton() throws Exception {
        LogCapture.info("User is selecting file to upload");
        Constants.key.pause("2", "");
        String vObjChooseFile = Constants.TitanCDSAPhase1OR.getProperty("chooseFile");
        String vUploadButton = Constants.TitanCDSAPhase1OR.getProperty("uploadButton");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjChooseFile, System.getProperty("user.dir") + "//src//File//Sample Aadhar.pdf"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vUploadButton, ""));
        LogCapture.info("User clicked on upload button");

    }

    @Then("^User should get error message as Please select Document Type$")
    public void userShouldGetErrorMessageAsPleaseSelectDocumentType() throws Exception {

        Constants.key.pause("2", "");
        String vErrorMessage = TitanCDSAPhase1OR.getProperty("uploadDocumentError");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vErrorMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vErrorMessage, "Please select Document Type"));
        LogCapture.info("User gets error message : Please select Document Type");

    }

    @When("^User select file to upload and document type$")
    public void userSelectFileToUploadAndDocumentType() throws Exception {
        LogCapture.info("User is selecting file to upload and document type");
        Constants.key.pause("2", "");
        String vObjChooseFile = Constants.TitanCDSAPhase1OR.getProperty("chooseFile");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjChooseFile, System.getProperty("user.dir") + "//src//File//Sample Aadhar.pdf"));
        String vObjdocumentDD = Constants.TitanCDSAPhase1OR.getProperty("documentTypeDD");
        Assert.assertEquals("PASS", Constants.key.click(vObjdocumentDD, ""));
        String vObjaddressProof = Constants.TitanCDSAPhase1OR.getProperty("proofOfAddress");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjaddressProof, ""));
        Constants.key.pause("1", "");

    }

    @And("^User click on upload button$")
    public void userClickOnUploadButton() throws Exception {
        LogCapture.info("User click on upload button");
        String vUploadButton = Constants.TitanCDSAPhase1OR.getProperty("uploadButton");
        Assert.assertEquals("PASS", Constants.key.click(vUploadButton, ""));
        Constants.key.pause("2", "");

    }

    @Then("^user uploads document successfully with success message$")
    public void userUploadsDocumentSuccessfullyWithSuccessMessage() throws Exception {

        String vObjsuccessMsg = TitanCDSAPhase1OR.getProperty("uploadDocSuccessMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjsuccessMsg, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjsuccessMsg, "Success"));
        LogCapture.info("Document uploaded successfully");

    }

    @And("^click on clear all filter$")
    public void clickOnClearAllFilter() throws Exception {
        LogCapture.info("clearing all filters");
        String vclearall = Constants.TitanCDSAPhase1OR.getProperty("clearallbutton");
        Constants.key.click(vclearall, "");

    }

    @And("^user clicks on download button$")
    public void userClicksOnDownloadButton() throws Throwable {
        String vdownload = Constants.TitanCDSAPhase1OR.getProperty("vdownload");
        Assert.assertEquals("PASS", Constants.key.click(vdownload, ""));
        String vCSV = Constants.TitanCDSAPhase1OR.getProperty("vCSV");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vCSV, ""));
        Constants.key.fileDownload("", "CSV file.csv");
        Constants.key.pause("3", "");
    }

    @Then("^delete downloaded file$")
    public void deleteDownloadedFile() throws Throwable {
        Assert.assertEquals("PASS", Constants.key.fileDownloadOperations("isFileAvailable", "CSV file.csv"));
        Assert.assertEquals("PASS", Constants.key.fileDownloadOperations("deleteDownloadedFile", "CSV file.csv"));
    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" SORTCode\"([^\"]*)\" and click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberSORTCodeAndClickOnNextButton(String AccountNumber, String SORTCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        LogCapture.info("Account number is entered..");

        String vObjSORTCode = Constants.TitanCDSAPhase1OR.getProperty("SORTCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSORTCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSORTCode, SORTCode));
        LogCapture.info("SORT Code is entered..");

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");

        Constants.key.pause("3", "");
        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" SWIFTCode\"([^\"]*)\" and click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberSWIFTCodeAndClickOnNextButton(String AccountNumber, String SWIFTCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        LogCapture.info("Account number is entered..");

        String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SWIFTCode));
        LogCapture.info("SWIFT Code is entered..");

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");

        Constants.key.pause("3", "");
        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^user select bank\"([^\"]*)\"$")
    public void userSelectBank(String selectbank) throws Throwable {
        LogCapture.info("select bank option....");
        Constants.key.pause("4", "");
        String vObjSelectbank = Constants.TitanCDSAPhase1OR.getProperty("SelectBankCDSA");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjSelectbank, ""));
        Constants.key.pause("5", "");
        String vObjSelectbankdrowdown = Constants.TitanCDSAPhase1OR.getProperty("SelectBankCDSA");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectbankdrowdown, ""));
        String vObjselectbankSearch = Constants.TitanCDSAPhase1OR.getProperty("selectbanksearch");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjselectbankSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjselectbankSearch, selectbank));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjselectbankSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjselectbankSearch, "enter"));
        LogCapture.info("select bank..");
    }

    @And("^user clicks on forwards button$")
    public void userClicksOnForwardsButton() throws Exception {
        LogCapture.info("clicks on forwards button....");
        String vObjForwardButton = Constants.TitanCDSAPhase1OR.getProperty("ForwardsButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjForwardButton, ""));
    }

    @And("^user clicks on filter close button$")
    public void userClicksOnFilterCloseButton() throws Exception {
        LogCapture.info("clicks on filter close button....");
        String vObjFilterCloseButton = Constants.TitanCDSAPhase1OR.getProperty("FilterCloseButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilterCloseButton, ""));
        Constants.key.pause("4", "");
    }

    @And("^click on Fx and landed on fx window$")
    public void clickOnFxAndLandedOnFxWindow() throws Exception {
        LogCapture.info("clicks on Fx....");
        String vObjAccountsectionFX = Constants.TitanCDSAPhase1OR.getProperty("AccountsectionFX");
        Assert.assertEquals("PASS", Constants.key.click(vObjAccountsectionFX, ""));
        Constants.key.pause("4", "");
    }

    @And("^select the selling \"([^\"]*)\" and buying currencey \"([^\"]*)\" and enter selling amount \"([^\"]*)\"$")
    public void selectTheSellingAndBuyingCurrenceyAndEnterSellingAmount(String Sellingcurreny, String Buyingcurrency) throws Throwable {
        //    enter selling currencey
        LogCapture.info("Navigate selling currencey....");
        String vObjsellingcurrenceyDD = Constants.TitanCDSAPhase1OR.getProperty("sellingcurrenceyDD");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjsellingcurrenceyDD, Sellingcurreny));
        LogCapture.info("click on ZAR currencey....");
        String vObjZARcurrencey = Constants.TitanCDSAPhase1OR.getProperty("ZARcurrencey");
        Assert.assertEquals("PASS", Constants.key.click(vObjZARcurrencey, ""));
        Constants.key.pause("2", "");
        //enter buying currencey
        LogCapture.info("Navigate buying currencey....");
        String vObjbuyingcurrenceyDD = Constants.TitanCDSAPhase1OR.getProperty("buyingcurrenceyDD");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjbuyingcurrenceyDD, Buyingcurrency));
        LogCapture.info("click on USD currencey....");
        String vObjUSDcurrencey = Constants.TitanCDSAPhase1OR.getProperty("USDcurrencey");
        Assert.assertEquals("PASS", Constants.key.click(vObjUSDcurrencey, ""));
        Constants.key.pause("2", "");
    }

    @And("^select purpose of payment \"([^\"]*)\" and clicks Next$")
    public void selectPurposeOfPaymentAndClicksNext(String purposeOfPayment) throws Throwable {
        String vObjPurposeOfPayment = Constants.CreateFxTicketOR.getProperty("PurposeOfPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPurposeOfPayment, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPayment, ""));

        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vPurposeOfPaymentSearch_FireFox = Constants.CreateFxTicketOR.getProperty("PurposeOfPaymentSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vPurposeOfPaymentSearch_FireFox, ""));
            LogCapture.info("Purpose Of Payment: " + purposeOfPayment + " is selected...");
        } else {
            String vObjPurposeOfPaymentSearch = Constants.CreateFxTicketOR.getProperty("PurposeOfPaymentSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
            LogCapture.info("Purpose Of Payment: " + purposeOfPayment + " is selected...");
        }
        Constants.key.pause("2", "");
        String vObjSourceOfFundDownArrow = Constants.CreateFxTicketOR.getProperty("SourceOfFundDownArrow");
        boolean vSourceOfFund = Constants.driver.findElement(By.xpath(vObjSourceOfFundDownArrow)).isDisplayed();
        if (vSourceOfFund) {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSourceOfFundDownArrow, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSourceOfFundDownArrow, ""));
            String vObjSourceOfFundSearch = Constants.CreateFxTicketOR.getProperty("SourceOfFundSearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSourceOfFundSearch, "SAVINGS"));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSourceOfFundSearch_FireFox = Constants.CreateFxTicketOR.getProperty("SourceOfFundSearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSourceOfFundSearch_FireFox, ""));
                LogCapture.info("Source of funds: SAVINGS is selected...");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundSearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSourceOfFundSearch, "enter"));
                LogCapture.info("Source of funds: SAVINGS is selected...");
            }
        }
        LogCapture.info("Navigate Next button....");
        String vObjNextbutton = Constants.TitanCDSAPhase1OR.getProperty("Nextbutton");
        Assert.assertEquals("PASS", Constants.key.click(vObjNextbutton, ""));
        Constants.key.pause("2", "");
        LogCapture.info("click on Next button....");
    }

    @And("^click on Instructed by option and spot \"([^\"]*)\"$")
    public void clickOnInstructedByOptionAndSpot(String DealType) throws Throwable {
        //click on Porteous1,Aubrey (P)
        LogCapture.info("Navigate Porteous1,Aubrey (P)....");
        Constants.key.pause("6", "");
        String vObjInstructedByoption = Constants.TitanCDSAPhase1OR.getProperty("InstructedByoption");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructedByoption, ""));
        LogCapture.info("click on Porteous1,Aubrey (P)....");
        Constants.key.pause("4", "");
        //click on spot
        LogCapture.info("Navigate deal type spot....");
        String vObjDealtypespot = Constants.TitanCDSAPhase1OR.getProperty("Dealtypespot");
        Assert.assertEquals("PASS", Constants.key.click(vObjDealtypespot, DealType));
        LogCapture.info("click on deal type spot....");
        Constants.key.pause("4", "");
    }

    @And("^User selects Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\"$")
    public void userSelectsSellingCurrencyBuyingCurrencySellingAmount(String BuyCurrency, String SellCurrency, String sellingAmount) throws Throwable {
        String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
        LogCapture.info("User is on FX details page..");
        Constants.key.pause("7", "");
        String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
        //Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjSellingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
        Constants.key.pause("4", "");
        String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

        String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
        LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

        String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
        LogCapture.info("Amount: " + sellingAmount + " is entered..");
    }

    @And("^user selects Bank, value date$")
    public void userSelectsBankValueDate() throws Exception {
        LogCapture.info("select bank option....");
        Constants.key.pause("4", "");
        String vObjBankname = Constants.TitanCDSAPhase1OR.getProperty("Bankname");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankname, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "enter"));
        String vObjselectbanklable = Constants.TitanCDSAPhase1OR.getProperty("selectbanklable");
        Assert.assertEquals("PASS", Constants.key.click(vObjselectbanklable, ""));
        LogCapture.info("select bank..");
        //click on value date
        LogCapture.info("select value date....");
        Constants.key.pause("7", "");
        String vObjvaluedate = Constants.TitanCDSAPhase1OR.getProperty("valuedate");
        Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjvaluedate, "enter"));

    }


    @And("^user selects value date and click on fetch rate$")
    public void userSelectsValueDateAndClickOnFetchRate() throws Exception {
        //click on value date
        LogCapture.info("select value date....");
        Constants.key.pause("7", "");
        String vObjvaluedate = Constants.TitanCDSAPhase1OR.getProperty("valuedate");
        Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjvaluedate, "enter"));
    }

    @Then("^verify fetch rate field is disabled$")
    public void verifyFetchRateFieldIsDisabled() throws Exception {
        String vObjfetchrate = Constants.TitanCDSAPhase1OR.getProperty("fetchrate");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjfetchrate, "enabled"));
        LogCapture.info(" fetch rate field is disabled....");
    }


    @Then("^User should validates the coustomer detail$")
    public void userShouldValidatesTheCoustomerDetail() throws Exception {
        LogCapture.info("verifying coustomer detail");
        String vCoustomername = Constants.TitanCDSAPhase1OR.getProperty("Coustomername");
        Assert.assertEquals("PASS", Constants.key.verifyText(vCoustomername, "Aubrey Porteous1   #0501001006788766 ACTIVE\n" +
                "CUSTOMERS"));
    }

    @Then("^User is able to view Wallet \"([^\"]*)\" detail$")
    public void userIsAbleToViewWalletDetail(String WalletCurrency) throws Throwable {

        String WalletSelected = "//h3[@id='modal-currency' and text()='" + WalletCurrency + "']";
        String WalletSelectedFlag = "//img[@class='droplist__flag' and @alt='" + WalletCurrency + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelected, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(WalletSelected, "visible"));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(WalletSelectedFlag, "visible"));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(WalletSelectedFlag, "visible"));
        LogCapture.info("Wallet details with flag for " + WalletCurrency + " are displayed...");

        String vObjWalletBalanceHeader = Constants.TitanDashboardOR.getProperty("WalletBalanceHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletBalanceHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletBalanceHeader, "visible"));
        LogCapture.info("Wallet Balance header is visible...");

        String vObjReferenceColumn = Constants.TitanDashboardOR.getProperty("ReferenceColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReferenceColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjReferenceColumn, "visible"));
        LogCapture.info("Reference Column is visible...");

        String vObjDateTimeColumn = Constants.TitanDashboardOR.getProperty("DateTimeColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDateTimeColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDateTimeColumn, "visible"));
        LogCapture.info("Date/Time Column is visible...");

        String vObjTypeColumn = Constants.TitanDashboardOR.getProperty("TypeColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTypeColumn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjTypeColumn, "visible"));
        LogCapture.info("Type Column is visible...");

        String vObjAmountColumn = Constants.TitanDashboardOR.getProperty("AmountColumn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountColumn, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmountColumn, "visible"));
        LogCapture.info("Amount Column is visible...");

        String vObjWalletBalanceOnPage = Constants.TitanDashboardOR.getProperty("WalletBalanceOnPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjWalletBalanceOnPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletBalanceOnPage, "visible"));
        LogCapture.info("Wallet balance is visible...");

        LogCapture.info("Wallet details for " + WalletCurrency + " are Verified...");

    }


    @And("^User navigate to (Debitor Number|Payment out|Customer|FX ticket) \"([^\"]*)\" Details$")
    public void userNavigateToDebitorNumberDetails(String page, String data) throws Throwable {
        if (page.equals("Debitor Number")) {
            String de = data.substring(4);
            String vObjKeywordFilterText = "//h1[contains(text(),'Debitor Number #" + de + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            LogCapture.info("User navigate to " + page + " #" + de + " Detail");
        } else if (page.equals("Payment out")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'Payment out #" + data + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));
            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
        } else if (page.equals("Customer")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'" + data + "')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

            String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

            LogCapture.info("User navigate to " + page + " # " + data + " Detail");
            String vObjCustomerStatus = Constants.TitanPaymentOutOR.getProperty("CustomerStatus");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjCustomerStatus, "ACTIVE"));
            LogCapture.info("Customer status is Active verified..");

            String vObjLegalEntity = Constants.TitanCustomersOR.getProperty("LegalEntity");
            String LegalEntity = Constants.key.getText(vObjLegalEntity, "");
            LogCapture.info("Legal Entity " + LegalEntity + " is Verified");

            String vObjContacts = Constants.TitanCustomersOR.getProperty("ContactsTab");
            String vObjContactPlus = Constants.TitanCustomersOR.getProperty("ContactPlusBtn");
            String vObjContactMobileNo = Constants.TitanCustomersOR.getProperty("ContactMobileNo");

            Assert.assertEquals("PASS", Constants.key.click(vObjContacts, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjContactPlus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjContactMobileNo, "visible"));
            LogCapture.info("Customer Contacts Tab Verified");

            String vObjCreditLimit = Constants.TitanCustomersOR.getProperty("CreditLimitTab");
            String vObjCreditSpotTrading = Constants.TitanCustomersOR.getProperty("CreditSpotTradingLine");
            Assert.assertEquals("PASS", Constants.key.click(vObjCreditLimit, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCreditSpotTrading, "visible"));
            LogCapture.info("Credit Limit Tab Verified");

            String vObjDocument = Constants.TitanCustomersOR.getProperty("DocumentsTab");
            String vObjDocumentName = Constants.TitanCustomersOR.getProperty("DocumentName");
            Assert.assertEquals("PASS", Constants.key.click(vObjDocument, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDocumentName, "visible"));
            LogCapture.info("Document Tab Verified");

            String vObjActivity = Constants.TitanCustomersOR.getProperty("ActivityLogs");
            String vObjActivityMemo = Constants.TitanCustomersOR.getProperty("ActivityMemo");
            Assert.assertEquals("PASS", Constants.key.click(vObjActivity, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjActivityMemo, "visible"));
            LogCapture.info("Activity Log Tab Verified");


        } else if (page.equals("FX ticket")) {
            String vObjKeywordFilterText = "//h1[contains(text(),'" + data + "')]";
            String vObjKeywordFilterText1 = "//h1[contains(text(),'Debitor Number #" + data + "')]";

            LogCapture.info(vObjKeywordFilterText);

            //String vObjKeywordFilterText = "//h1[contains(text(),'FX ticket for client #')]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

            //String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

            LogCapture.info("User navigate to " + page + " # " + data + " Detail=========");
        }

    }

    @Then("^User click on first record from Payment in Queue page to verify debitor details$")
    public void userClickOnFirstRecordFromPaymentInQueuePageToVerifyDebitorDetails() throws Exception {

        String vobjFirstRecordPaymentsInQueue = Constants.TitanPaymentInOR.getProperty("FirstRecordPaymentsInQueue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsInQueue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsInQueue, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayInQueueDebitorAcctNo = Constants.TitanPaymentInOR.getProperty("PayInQueueDebitorAcctNo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInQueueDebitorAcctNo, "visible"));
        LogCapture.info("User able to view Debitor Account number on Debitor details page");

        String vobjPayInQueueAmount = Constants.TitanPaymentInOR.getProperty("PayInQueueAmount");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInQueueAmount, "visible"));
        LogCapture.info("User able to view Amount on Debitor details page");

        String vobjPayInQueueCurrency = Constants.TitanPaymentInOR.getProperty("PayInQueueCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInQueueCurrency, "visible"));
        LogCapture.info("User able to view Currency on Debitor details page");

    }

    @Then("^User click on first record from Payment Out Queue page to verify payee details$")
    public void userClickOnFirstRecordFromPaymentOutQueuePageToVerifyPayeeDetails() throws Exception {

        String vobjFirstRecordPaymentsOutQueue = TitanPaymentOutOR.getProperty("FirstRecordPaymentsOutQueue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsOutQueue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsOutQueue, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayOutCurrencyAmount = Constants.TitanPaymentOutOR.getProperty("PayOutCurrencyAmount");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutCurrencyAmount, "visible"));
        LogCapture.info("User able to View Currency and Amount on PaymentOut Customers details page");

        String vobjPayOutPayeeName = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutPayeeName, "visible"));
        LogCapture.info("User able to View Payee Name on PaymentOut Customers details page");

        String vobjPayOutPayeeCurrency = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutPayeeCurrency, "visible"));
        LogCapture.info("User able to View Payee-Currency on PaymentOut Customers details page");

        String vobjPayOutPayeeDetails = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeDetails");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutPayeeDetails, "visible"));
        LogCapture.info("User able to View Payee Details on PaymentOut details page");


    }

    @Then("^User click on first record from FX tickets Queue page to verify FX details$")
    public void userClickOnFirstRecordFromFXTicketsQueuePageToVerifyFXDetails() throws Exception {

        String vobjFirstRecordFXticketsQueue = TitanFXTicketsOR.getProperty("FirstRecordFXticketsQueue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordFXticketsQueue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordFXticketsQueue, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjFXQueueDetailsClientName = Constants.TitanFXTicketsOR.getProperty("FXQueueDetailsClientName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFXQueueDetailsClientName, "visible"));
        LogCapture.info("User able to View Client Name on FX Ticket details page");

        String vobjFXQueueDetailsDealType = Constants.TitanFXTicketsOR.getProperty("FXQueueDetailsDealType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFXQueueDetailsDealType, "visible"));
        LogCapture.info("User able to View Deal type on FX Ticket details page");

        String vobjFurtherClientDetails = Constants.TitanFXTicketsOR.getProperty("FurtherClientDetails");
        Assert.assertEquals("PASS", Constants.key.click(vobjFurtherClientDetails, ""));
        LogCapture.info("User Clicked on Further client details tab");

        String vobjFurtherdetailsClientName = Constants.TitanFXTicketsOR.getProperty("FurtherdetailsClientName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFurtherdetailsClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFurtherdetailsClientName, "visible"));
        LogCapture.info("User able to View Client name under further client Details Tab");

    }

    @Then("^User click on first record from Payment in Report page to verify debitor details$")
    public void userClickOnFirstRecordFromPaymentInReportPageToVerifyDebitorDetails() throws Exception {

        String vobjFirstRecordPaymentsInReport = Constants.TitanPaymentInOR.getProperty("FirstRecordPaymentsInReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsInReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsInReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayInReportsDebitorName = Constants.TitanPaymentInOR.getProperty("PayInReportsDebitorName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInReportsDebitorName, "visible"));
        LogCapture.info("User able to view Debitor Name on Debitor details page");

        String vobjPayInReportsAmount = Constants.TitanPaymentInOR.getProperty("PayInReportsAmount");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInReportsAmount, "visible"));
        LogCapture.info("User able to view Amount on Debitor details page");

        String vobjPayInReportCurrency = Constants.TitanPaymentInOR.getProperty("PayInReportCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayInReportCurrency, "visible"));
        LogCapture.info("User able to view Currency on Debitor details page");
    }

    @Then("^User click on first record from Payment Out Report page to verify Payment Out Details$")
    public void userClickOnFirstRecordFromPaymentOutReportPageToVerifyPaymentOutDetails() throws Exception {

        String vobjFirstRecordPaymentsOutReport = TitanPaymentOutOR.getProperty("FirstRecordPaymentsOutReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPaymentsOutReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPaymentsOutReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayOutReportCurrencyAmount = Constants.TitanPaymentOutOR.getProperty("PayOutReportCurrencyAmount");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutReportCurrencyAmount, "visible"));
        LogCapture.info("User able to view Currency/Amount on PaymentOut details page");

        String vobjPayoutReportPayeeDetails = Constants.TitanPaymentOutOR.getProperty("PayoutReportPayeeDetails");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayoutReportPayeeDetails, "visible"));
        LogCapture.info("User able to view Payee Details on PaymentOut details page");

        String vobjPayOutReportPayeeName = Constants.TitanPaymentOutOR.getProperty("PayOutReportPayeeName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutReportPayeeName, "visible"));
        LogCapture.info("User able to view Payee Name under Payee detail Section");

        String vobjPayoutReportPayeeCurrency = Constants.TitanPaymentOutOR.getProperty("PayoutReportPayeeCurrency");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayoutReportPayeeCurrency, "visible"));
        LogCapture.info("User able to view Payee Currency under Payee detail Section");

    }

    @Then("^User click on first record from FX details Report page to verify Payment Out Details$")
    public void userClickOnFirstRecordFromFXDetailsReportPageToVerifyPaymentOutDetails() throws Exception {

        String vobjFirstRecordFXticketReports = TitanFXTicketsOR.getProperty("FirstRecordFXticketReports");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordFXticketReports, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordFXticketReports, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPFXReportDetailsClientName = Constants.TitanFXTicketsOR.getProperty("FXReportDetailsClientName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPFXReportDetailsClientName, "visible"));
        LogCapture.info("User able to view Client Name on FX details page under Report");

        String vobjFXReportDetailsDealType = Constants.TitanFXTicketsOR.getProperty("FXReportDetailsDealType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFXReportDetailsDealType, "visible"));
        LogCapture.info("User able to view Deal Type on FX details page under Report");

        String vobjFurtherClientDetails = Constants.TitanFXTicketsOR.getProperty("FurtherClientDetails");
        Assert.assertEquals("PASS", Constants.key.click(vobjFurtherClientDetails, ""));
        LogCapture.info("User Clicked on Further client details tab");

        String vobjFurtherdetailsClientName = Constants.TitanFXTicketsOR.getProperty("FurtherdetailsClientName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFurtherdetailsClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFurtherdetailsClientName, "visible"));
        LogCapture.info("User able to View Client name under further client Details Tab");
    }

    @Then("^User click on first record from Payee Report page to verify Payment Out Details$")
    public void userClickOnFirstRecordFromPayeeReportPageToVerifyPaymentOutDetails() throws Exception {

        String vobjFirstRecordPayeeReport = TitanPayeeOR.getProperty("FirstRecordPayeeReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPayeeReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPayeeReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayeeDetailsName = Constants.TitanPayeeOR.getProperty("PayeeDetailsName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsName, "visible"));
        LogCapture.info("User able to view Payee Name on Payee details page");

        String vobjPayeeDetailsAdress = Constants.TitanPayeeOR.getProperty("PayeeDetailsAdress");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsAdress, "visible"));
        LogCapture.info("User able to view Payee Address on Payee details page");

        String vobjPayeeDetailsAccountNo = Constants.TitanPayeeOR.getProperty("PayeeDetailsAccountNo");
        Assert.assertEquals("PASS", Constants.key.click(vobjPayeeDetailsAccountNo, ""));
        LogCapture.info("User able to view Bank Account Number on Payee details page");

        String vobjPayeeDetailsBankName = Constants.TitanPayeeOR.getProperty("PayeeDetailsBankName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsBankName, "visible"));
        LogCapture.info("User able to View Bank Name on Payee details page");
    }


    @Then("^verify FX Amend button is disabled$")
    public void verifyFXAmendButtonIsDisabled() throws Exception {
        String vObjAmend = Constants.TitanFXTicketsOR.getProperty("AmendFX");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAmend, "enabled"));
        LogCapture.info(" Amend button is disabled....");
    }


    @Then("^User Successfully landed on blank page on Titan Customer$")
    public void userSuccessfullyLandedOnBlankPageOnTitanCustomer() throws Exception {

        LogCapture.info("Titan Customer Blank Page loading ......");
        Constants.key.pause("3", "");
        String vobjectDashboard = Constants.TitanCDSAPhase1OR.getProperty("OrgRecord");
        Assert.assertEquals("PASS", Constants.key.notexist(vobjectDashboard, ""));
        LogCapture.info("Titan Customer BlankPage loaded successfully");
    }

    @When("^user clicks on click on clear all filter$")
    public void userClicksOnClickOnClearAllFilter() throws Exception {
        LogCapture.info("clicks on clear all filter....");
        String vObjClearFilter = TitanCustomersOR.getProperty("ClearFilter");
        Assert.assertEquals("PASS", Constants.key.click(vObjClearFilter, ""));
        Constants.key.pause("4", "");
    }

    @Then("^User landed on default Customers Page$")
    public void userLandedOnDefaultCustomersPage() throws Exception {

        String vObjCustRecord1 = TitanCustomersOR.getProperty("CustRecord1");
        String organization1 = Constants.driver.findElement(By.xpath(vObjCustRecord1)).getText();
        String vObjCustRecord2 = TitanCustomersOR.getProperty("CustRecord2");
        String organization2 = Constants.driver.findElement(By.xpath(vObjCustRecord2)).getText();
        String vObjCustRecord3 = TitanCustomersOR.getProperty("CustRecord3");
        String organization3 = Constants.driver.findElement(By.xpath(vObjCustRecord3)).getText();

        LogCapture.info(organization1 + " > " + organization2 + " > " + organization3);
        if (organization1.equals(organization2) && organization1.equals(organization3)) {
            LogCapture.info("Not landed on default Customers Page...");
            Assert.assertEquals("PASS", Constants.KEYWORD_FAIL);
        } else {
            Assert.assertEquals("PASS", KEYWORD_PASS);
            LogCapture.info("Successfully landed on default Customers Page...");
        }
    }

    @And("^User selects Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\" select Bank$")
    public void userSelectsSellingCurrencyBuyingCurrencySellingAmountSelectBank(String SellCurrency, String BuyCurrency, String sellingAmount) throws Throwable {

        String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
        LogCapture.info("User is on FX details page..");
        Constants.key.pause("7", "");
        String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
        //Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjSellingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
        Constants.key.pause("4", "");
        String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

        String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
        LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

        String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
        LogCapture.info("Amount: " + sellingAmount + " is entered..");

        Constants.key.pause("4", "");
        String vObjSelectBank = Constants.CreateFxTicketOR.getProperty("SelectMBank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectBank, ""));
        String vObjMercantileBank1 = Constants.CreateFxTicketOR.getProperty("MercantileBank1");
        Assert.assertEquals("PASS", Constants.key.click(vObjMercantileBank1, ""));

        LogCapture.info("Bank is selected..");
    }

    @And("^user selects value date \"([^\"]*)\" and click on fetch rate$")
    public void userSelectsValueDateAndClickOnFetchRate(String VDate) throws Throwable {

        if (VDate.equals("T1")) {
            LogCapture.info("select value date " + VDate + " ....");
            Constants.key.pause("7", "");
            String vObjvaluedate = CreateFxTicketOR.getProperty("valuedate");
            Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
            String vObjt1ValueDate = Constants.CreateFxTicketOR.getProperty("t1ValueDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjt1ValueDate, ""));
            LogCapture.info("Value date " + VDate + " Selected....");

        } else if (VDate.equals("T2")) {
            LogCapture.info("select value date " + VDate + " ....");
            Constants.key.pause("7", "");
            String vObjvaluedate = Constants.CreateFxTicketOR.getProperty("valuedate");
            Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
            String vObjt1ValueDate = Constants.CreateFxTicketOR.getProperty("t2ValueDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjt1ValueDate, ""));
            LogCapture.info("Value date " + VDate + " Selected....");

        } else if (VDate.equals("T")) {
            LogCapture.info("select value date " + VDate + " ....");
            Constants.key.pause("7", "");
            String vObjvaluedate = Constants.CreateFxTicketOR.getProperty("valuedate");
            Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
            String vObjt2ValueDate = Constants.CreateFxTicketOR.getProperty("t2ValueDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjt2ValueDate, ""));

            String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
            Assert.assertEquals("PASS", Constants.key.click(vObjFetchRates, ""));

            Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
            String vObjtValueDate = Constants.CreateFxTicketOR.getProperty("tValueDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjtValueDate, ""));
            LogCapture.info("Value date " + VDate + " Selected....");
        }

    }

    @And("^User is on Credit page and select Bank option and click on add payment$")
    public void userIsOnCreditPageAndSelectBankOptionAndClickOnAddPayment() throws Exception {

        LogCapture.info("select Bank Method and click on Add Payment....");
        Constants.key.pause("5", "");
        String vObjPaymentMethodBank = CreateFxTicketOR.getProperty("PaymentMethodBank");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentMethodBank, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethodBank, ""));

        String vObjAddCreditButton = CreateFxTicketOR.getProperty("AddCreditButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddCreditButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCreditButton, ""));
    }

    @Then("^User click on first record from FX details Report page to verify FX Details$")
    public void userClickOnFirstRecordFromFXDetailsReportPageToVerifyFXDetails() throws Exception {
        String vobjFirstRecordFXticketReports = TitanFXTicketsOR.getProperty("FirstRecordFXticketReports");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordFXticketReports, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordFXticketReports, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPFXReportDetailsClientName = Constants.TitanFXTicketsOR.getProperty("FXReportDetailsClientName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPFXReportDetailsClientName, "visible"));
        LogCapture.info("User able to view Client Name on FX details page under Report");

        String vobjFXReportDetailsDealType = Constants.TitanFXTicketsOR.getProperty("FXReportDetailsDealType");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFXReportDetailsDealType, "visible"));
        LogCapture.info("User able to view Deal Type on FX details page under Report");

        String vobjFurtherClientDetails = Constants.TitanFXTicketsOR.getProperty("FurtherClientDetails");
        Assert.assertEquals("PASS", Constants.key.click(vobjFurtherClientDetails, ""));
        LogCapture.info("User Clicked on Further client details tab");

        String vobjFurtherdetailsClientName = Constants.TitanFXTicketsOR.getProperty("FurtherdetailsClientName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFurtherdetailsClientName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFurtherdetailsClientName, "visible"));
        LogCapture.info("User able to View Client name under further client Details Tab");
    }

    @And("^User clicks on FX reports hyperlink to navigate back to FX report page$")
    public void userClicksOnFXReportsHyperlinkToNavigateBackToFXReportPage() throws Exception {

        String vobjFXTicketsReport = Constants.TitanFXTicketsOR.getProperty("FXTicketsReportlink");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vobjFXTicketsReport, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vobjFXTicketsReport, "click"));
        //      Assert.assertEquals("PASS", Constants.key.click(vobjFXTicketsReport, ""));
        LogCapture.info("User clicks on FX Tickets report hyperlink..");
        String vObjFXTicketsReport = Constants.TitanFXTicketsOR.getProperty("FXTicketsReportPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsReport, ""));
        LogCapture.info("User is on FX Reports in Titan page..");
    }

    @And("^Select Organisation as \"([^\"]*)\" and apply filter$")
    public void selectOrganisationAsAndApplyFilter(String Organisation) throws Throwable {

        String vObjOrgFilterInvoices = TitanCustomersOR.getProperty("OrgFilterInvoices");
        Assert.assertEquals("PASS", Constants.key.click(vObjOrgFilterInvoices, ""));

        String SelectOrg = "//input[@value='" + Organisation + "']//parent :: label";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(SelectOrg, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(SelectOrg, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(SelectOrg, "click"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(SelectOrg, "enter"));

        LogCapture.info("User Selected organisation as " + Organisation);


    }

    @Then("^User is able to click on Pay out button$")
    public void userIsAbleToClickOnPayOutButton() throws Throwable {
        String vobjPayeeout = TitanPaymentOutOR.getProperty("PaymentOutButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPayeeout, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjPayeeout, ""));

    }


    @And("^user click on bank option$")
    public void userClickOnBankOption() throws Exception {

        String vObjCustDetailsBankTab = TitanCustomersOR.getProperty("CustDetailsBankTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustDetailsBankTab, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjCustDetailsBankTab, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjCustDetailsBankTab, "click"));

        LogCapture.info("User click on bank option");
    }

    @Then("^User click on send email option and observe the message$")
    public void userClickOnSendEmailOptionAndObserveTheMessage() throws Exception {

        String vObjSendEmailOption = TitanCustomersOR.getProperty("SendEmailOption");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjSendEmailOption, ""));

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendEmailOption, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjSendEmailOption, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjSendEmailOption, "click"));

        LogCapture.info("User click send email option");

    }

    @And("^System should open the Incoming Fund queue Page  with Zero \"([^\"]*)\" records should be seen\\.$")
    public void systemShouldOpenTheIncomingFundQueuePageWithZeroRecordsShouldBeSeen(String application) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //td//a[text()="CDLZA"]
        String vclient = "//td//a[text()='" + application + "']";
        Assert.assertEquals("PASS", Constants.key.notexist(vclient, ""));
        LogCapture.info("User validate no records of  " + application + ",should present.");
        Constants.key.pause("2", "");

    }

    @And("^click on Instructed by option and Forward \"([^\"]*)\"$")
    public void clickOnInstructedByOptionAndForward(String DealType) throws Throwable {
        LogCapture.info("Navigate Porteous1,Aubrey (P)....");
        Constants.key.pause("3", "");
        String vObjInstructedByoption = Constants.TitanCDSAPhase1OR.getProperty("InstructedByoption");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructedByoption, ""));
        LogCapture.info("click on Porteous1,Aubrey (P)....");
        Constants.key.pause("3", "");
        //click on spot
        LogCapture.info("Navigate deal type Forward....");
        String vObjDealtypeForward = Constants.TitanCDSAPhase1OR.getProperty("DealtypeForward");
        Assert.assertEquals("PASS", Constants.key.click(vObjDealtypeForward, DealType));
        LogCapture.info("click on deal type Forward....");
        Constants.key.pause("3", "");
    }

    @And("^User Select Forward type \"([^\"]*)\" and Select From date and To date$")
    public void userSelectForwardTypeAndSelectFromDateAndToDate(String data) throws Throwable {
        if (data.equalsIgnoreCase("Open")) {
            LogCapture.info("select From date....");
            Constants.key.pause("4", "");
            String vObjFromDate = Constants.TitanCDSAPhase1OR.getProperty("FromDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjFromDate, ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromDate, "enter"));
            Constants.key.pause("3", "");

            LogCapture.info("select To Date....");
            Constants.key.pause("4", "");
            String vObjToDate = Constants.TitanCDSAPhase1OR.getProperty("ToDate");
            Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToDate, "enter"));
            Constants.key.pause("4", "");
        } else if (data.equalsIgnoreCase("Fixed")) {
            String vObjFixed = CreateFxTicketOR.getProperty("FixedForwardType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFixed, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFixed, ""));
            LogCapture.info("User clicked on Fixed Forward type....");

            LogCapture.info("select  Date....");
            Constants.key.pause("2", "");
            String vObjToDate = Constants.TitanCDSAPhase1OR.getProperty("Selectdate");
            Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToDate, "enter"));
            Constants.key.pause("2", "");
        }
    }

    @And("^User select Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\"$")
    public void userSelectSellingCurrencyBuyingCurrencySellingAmount(String SellCurrency, String BuyCurrency, String sellingAmount) throws Throwable {
        String vObjSellingCurrencySearch = Constants.TitanCDSAPhase1OR.getProperty("SellingCurrencySearch");
        //Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjSellingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
        LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
        Constants.key.pause("4", "");
        String vObjBuyingCurrency = Constants.TitanCDSAPhase1OR.getProperty("BuyingCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));
        LogCapture.info("User clicked on buy currency");
        Constants.key.pause("4", "");
        String vObjBuyingCurrencySearch = Constants.TitanCDSAPhase1OR.getProperty("BuyingCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
        LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");

        String vObjSellingAmount = Constants.TitanCDSAPhase1OR.getProperty("SellingAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
        LogCapture.info("Amount: " + sellingAmount + " is entered..");
    }

    @And("^user selects Bank$")
    public void userSelectsBank() throws Exception {
        LogCapture.info("selecting bank....");
        Constants.key.pause("4", "");
        String vObjSelectBank = Constants.TitanCDSAPhase1OR.getProperty("SelectBank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectBank, ""));
        LogCapture.info("user clicked on dropdown option to select bank....");
        Constants.key.pause("4", "");
        String vObjBankName = Constants.TitanCDSAPhase1OR.getProperty("BankName");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjBankName, "click"));
        LogCapture.info("User successfully selected bank of his choice...");
    }

    @Then("^verify fetch rate field is enabled$")
    public void verifyFetchRateFieldIsEnabled() throws Exception {
        String vObjfetchrate = Constants.TitanCDSAPhase1OR.getProperty("fetchrate");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjfetchrate, "enabled"));
        LogCapture.info(" fetch rate field is enabled....");

    }

    @And("^User selects Payee\"([^\"]*)\" PaymentDate Amount\"([^\"]*)\" PurposeOfPayment\"([^\"]*)\"and select bank \"([^\"]*)\" clicks on Add Payment button and Yes button for Payment Out$")
    public void userSelectsPayeePaymentDateAmountPurposeOfPaymentAndSelectBankClicksOnAddPaymentButtonAndYesButtonForPaymentOut
            (String Payee, String Amount, String purposeOfPayment, String bank) throws Throwable {
        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");

        String vObjPaymentDate = Constants.TitanPaymentOutOR.getProperty("PaymentDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDate, ""));
        Constants.key.pause("2", "");
        String vObjTodaysDate = Constants.TitanPaymentOutOR.getProperty("TodaysDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjTodaysDate, ""));
        LogCapture.info("Selecting Todays date...");

        String vObjAmount = Constants.TitanPaymentOutOR.getProperty("Amount");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Amount));
        LogCapture.info("Amount entred is: " + Amount);

        String vObjPurposeOfPaymentDropdownArrow = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPurposeOfPaymentDropdownArrow, ""));
        String vObjPurposeOfPaymentSearch = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPaymentSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
        LogCapture.info("Purpose of Payment: " + purposeOfPayment + " is selected..");
        Constants.key.pause("2", "");
        String vObjSelectbank = TitanPaymentOutOR.getProperty("Selectbank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectbank, ""));
        Constants.key.pause("2", "");
        String vObjSearchbox2 = TitanPaymentOutOR.getProperty("Searchbox2");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchbox2, bank));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchbox2, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchbox2, ""));
        LogCapture.info("Select Bank is selected..");
        Constants.key.pause("1", "");
        String vObjAddPaymentBtn = Constants.TitanPaymentOutOR.getProperty("AddPaymentBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddPaymentBtn, ""));
        LogCapture.info("Clicked on Add Payment button...");
        String vObjPaymentOutYesBtn = Constants.TitanPaymentOutOR.getProperty("PaymentOutYesBtn");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjPaymentOutYesBtn, ""));
        LogCapture.info("Clicking on YES button for pop-up...");
    }

    @And("^User selects Bank for (PayOut|FX)$")
    public void userSelectsBank(String Value) throws Exception {
        if (Value.equalsIgnoreCase("PayOut")) {
            String vObjBankDropdownArrow = Constants.TitanCDSAPhase1OR.getProperty("BankDropdown");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDropdownArrow, ""));
            String vObjBankSearch = Constants.TitanCDSAPhase1OR.getProperty("BankSearch");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjBankSearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBankSearch, "Test"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankSearch, "enter"));
            LogCapture.info("Bank is selected by User..");
        } else if (Value.equalsIgnoreCase("FX")) {
            LogCapture.info("select bank option....");
            Constants.key.pause("2", "");
            String vObjBankname = Constants.TitanCDSAPhase1OR.getProperty("Bankname");
            Assert.assertEquals("PASS", Constants.key.click(vObjBankname, ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "enter"));
            String vObjselectbanklable = Constants.TitanCDSAPhase1OR.getProperty("selectbanklable");
            Assert.assertEquals("PASS", Constants.key.click(vObjselectbanklable, ""));
            LogCapture.info("select bank..");
        }
    }

    @And("^User selects Payee\"([^\"]*)\" PaymentDate Amount\"([^\"]*)\" PurposeOfPayment\"([^\"]*)\"$")
    public void userSelectsPayeePaymentDateAmountPurposeOfPayment(String Payee, String Amount, String purposeOfPayment) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");

        String vObjPaymentDate = Constants.TitanPaymentOutOR.getProperty("PaymentDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDate, ""));
        Constants.key.pause("2", "");
        String vObjTodaysDate = Constants.TitanPaymentOutOR.getProperty("TodaysDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjTodaysDate, ""));
        LogCapture.info("Selecting Todays date...");

        String vObjAmount = Constants.TitanPaymentOutOR.getProperty("Amount");
        Assert.assertEquals("PASS", Constants.key.click(vObjAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmount, Amount));
        LogCapture.info("Amount entred is: " + Amount);


        String vObjPurposeOfPaymentDropdownArrow = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPurposeOfPaymentDropdownArrow, ""));
        String vObjPurposeOfPaymentSearch = Constants.TitanPaymentOutOR.getProperty("PurposeOfPaymentSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeOfPaymentSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeOfPaymentSearch, purposeOfPayment));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPurposeOfPaymentSearch, "enter"));
        LogCapture.info("Purpose of Payment: " + purposeOfPayment + " is selected..");
    }

    @And("^User clicks on Add Payment button and Yes button for Payment Out$")
    public void userClicksOnAddPaymentButtonAndYesButtonForPaymentOut() throws Exception {

        String vObjAddPaymentBtn = Constants.TitanPaymentOutOR.getProperty("AddPaymentBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddPaymentBtn, ""));
        LogCapture.info("Clicked on Add Payment button...");
        String vObjPaymentOutYesBtn = Constants.TitanPaymentOutOR.getProperty("PaymentOutYesBtn");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjPaymentOutYesBtn, ""));
        LogCapture.info("Clicking on YES button for pop-up...");

    }

    @And("^User selects Selling Currency \"([^\"]*)\" Buying currency \"([^\"]*)\" Selling amount \"([^\"]*)\" according to DealType\"([^\"]*)\"$")
    public void userSelectsSellingCurrencyBuyingCurrencySellingAmountAccordingToDealType(String SellCurrency, String BuyCurrency, String sellingAmount, String DealType) throws Throwable {

        String RandomNumber = RandomStringUtils.randomNumeric(3);
        InAmount = Double.parseDouble(RandomNumber);

        if (DealType.equalsIgnoreCase("Spot")) {
            String vObjCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("CurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSellingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("SellingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSellingCurrencySearch_FireFox, ""));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            }

            Constants.key.pause("2", "");
            String vObjBuyingCurrency = Constants.CreateFxTicketOR.getProperty("BuyingCurrency");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrency, ""));

            String vObjBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyingCurrencySearch, BuyCurrency));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vBuyingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("BuyingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vBuyingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuyingCurrencySearch, "enter"));
                LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");
            }
            if (sellingAmount.equals("") || sellingAmount.isEmpty()) {

                LogCapture.info("New Sell Amount : " + InAmount + "" + RandomNumber);
                String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, Double.toString(InAmount)));
                LogCapture.info("Amount: " + InAmount + " is entered..");
            } else {
                String vObjSellingAmount = Constants.CreateFxTicketOR.getProperty("SellingAmount");
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingAmount, sellingAmount));
                LogCapture.info("Amount: " + sellingAmount + " is entered..");
            }
        }

        if (DealType.equalsIgnoreCase("Forward")) {
            String vObjLimitOrderCurrenciesAndAmounts = Constants.CreateFxTicketOR.getProperty("ForwardOrderCurrenciesAndAmounts");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLimitOrderCurrenciesAndAmounts, ""));
            LogCapture.info("User is on FX details page..");
            Constants.key.pause("3", "");
            String vObjSellingCurrencySearch = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellingCurrencySearch, SellCurrency));
            Constants.key.pause("4", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vForwardOrderSellingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vForwardOrderSellingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellingCurrencySearch, "enter"));
                LogCapture.info("Sell currency: " + SellCurrency + " is selected..");
            }

            Constants.key.pause("2", "");
            String vObjLimitOrderBuyingCurrency = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencyDropArrow");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrency, ""));

            String vObjLimitOrderBuyingCurrencySearch = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencySearch");
            Assert.assertEquals("PASS", Constants.key.click(vObjLimitOrderBuyingCurrencySearch, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderBuyingCurrencySearch, BuyCurrency));
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vForwardOrderBuyingCurrencySearch_FireFox = Constants.CreateFxTicketOR.getProperty("ForwardOrderBuyingCurrencySearch_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vForwardOrderBuyingCurrencySearch_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjLimitOrderBuyingCurrencySearch, "enter"));
                LogCapture.info("Buy currency: " + BuyCurrency + " is selected..");
            }

            if (sellingAmount.equals("") || sellingAmount.isEmpty()) {

                LogCapture.info("New Sell Amount : " + InAmount + "" + RandomNumber);
                String vObjLimitOrderSellingAmount = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingAmount");
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderSellingAmount, Double.toString(InAmount)));
                LogCapture.info("Amount: " + InAmount + " is entered..");
            } else {
                String vObjLimitOrderSellingAmount = Constants.CreateFxTicketOR.getProperty("ForwardOrderSellingAmount");
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLimitOrderSellingAmount, sellingAmount));
                LogCapture.info("Amount: " + sellingAmount + " is entered..");
            }


        }
    }

    @And("^User clicks on Fetch rates button$")
    public void userClicksOnFetchRatesButton() throws Exception {

        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");
        String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
        String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
        if (LiveRate == null) {
            Assert.fail();
            LogCapture.info("Fetching rates.. Live Rate is Null...");
        } else {
            LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
        }
        LogCapture.info("Rates fetched..");
    }

    @And("^User selects Value date plus one$")
    public void userSelectsValueDatePlusOne() throws Exception {
        String Valuedate;
        String vObjCalendar = Constants.TitanCDSAPhase1OR.getProperty("Calendar");
        Assert.assertEquals("PASS", Constants.key.click(vObjCalendar, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        DateFormat dateFormat = new SimpleDateFormat("dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY)) {
            cal.add(Calendar.DATE, 3);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)) {
            cal.add(Calendar.DATE, 2);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)) {
            cal.add(Calendar.DATE, 1);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else {
            cal.add(Calendar.DATE, 1);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        }

        if (Valuedate.equals("01")) {
            Valuedate = "1";
        } else if (Valuedate.equals("02")) {
            Valuedate = "2";
        } else if (Valuedate.equals("03")) {
            Valuedate = "3";
        } else if (Valuedate.equals("04")) {
            Valuedate = "4";
        } else if (Valuedate.equals("05")) {
            Valuedate = "5";
        } else if (Valuedate.equals("06")) {
            Valuedate = "6";
        } else if (Valuedate.equals("07")) {
            Valuedate = "7";
        } else if (Valuedate.equals("08")) {
            Valuedate = "8";
        } else if (Valuedate.equals("09")) {
            Valuedate = "9";
        }

        String CDSAValueDate = "//a[@class='ui-state-default' and contains(text(),'" + Valuedate + "')]";
        Assert.assertEquals("PASS", Constants.key.click(CDSAValueDate, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User select Value Date " + Valuedate);

    }

    @And("^User selects Bank and clicks Add Credit$")
    public void userSelectsBankAndClicksAddCredit() throws Exception {
        String vObjCreditPageBank = Constants.TitanCDSAPhase1OR.getProperty("CreditPageBank");
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        //Assert.assertEquals("PASS", Constants.key.click(vObjCreditPageBank, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCreditPageBank, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjAddCredit = Constants.TitanCDSAPhase1OR.getProperty("AddCredit");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddCredit, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
    }

    @And("^User clicks on Next button for credit page$")
    public void userClicksOnNextButtonForCreditPage() throws Exception {
        Constants.key.pause("2", "");
        String vObjNext2Button = Constants.CreateFxTicketOR.getProperty("Next2Button");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjNext2Button, ""));
        LogCapture.info("Clicking on Next button....");
    }

    @And("^User clicks on Fetch rates button for CDSA$")
    public void userClicksOnFetchRatesButtonForCDSA() throws Exception {
        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");
        String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValueCDSA");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveRateValue, ""));
        String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
        if (LiveRate == null) {
            Assert.fail();
            LogCapture.info("Fetching rates.. Live Rate is Null...");
        } else {
            LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
        }
        LogCapture.info("Rates fetched..");

    }

    @And("^User selects Payee\"([^\"]*)\"$")
    public void userSelectsPayee(String Payee) throws Throwable {

        String vObjAddAPaymentPage = Constants.CreateFxTicketOR.getProperty("AddAPaymentPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddAPaymentPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddAPaymentPage, "visible"));
        LogCapture.info("User is on 4 of 4: Add a Payment page...");

        String vObjSelectPayeeDownArrow = Constants.CreateFxTicketOR.getProperty("SelectPayeeDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjSearchPayee = Constants.CreateFxTicketOR.getProperty("SearchPayee");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchPayee, ""));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vSearchPayee_FireFox = Constants.CreateFxTicketOR.getProperty("SearchPayee_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vSearchPayee_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
            LogCapture.info("Payee: " + Payee + " is selected..");

        }
    }

    @And("^User enters Fee Amount$")
    public void userEntersFeeAmount() throws Exception {
        String vObjFeeAmount = TitanCDSAPhase1OR.getProperty("FeeAmount");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFeeAmount, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFeeAmount, "2.5"));
        Constants.key.pause("2", "");
    }


    @And("^User clicks on Finished Adding Payment button$")
    public void userClicksOnFinishedAddingPaymentButton() throws Exception {
        String vObjFXFinishedAddPaymentBtn = Constants.CreateFxTicketOR.getProperty("FXFinishedAddPaymentBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXFinishedAddPaymentBtn, ""));
        LogCapture.info("Clicking on Finished Adding Payment button...");
    }

    @And("^User verifies No Payee Alert$")
    public void userVerifiesNoPayeeAlert() throws Exception {
        String vObjNoPayeeAlert = TitanCDSAPhase1OR.getProperty("NoPayeeAlert");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNoPayeeAlert, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjNoPayeeAlert, "visible"));
        LogCapture.info("Payee not visible");
    }

    @And("^User clicks on Skip button and Yes button for popup$")
    public void userClicksOnSkipButtonAndYesButtonForPopup() throws Exception {

        String vObjSkipButton = TitanCDSAPhase1OR.getProperty("SkipButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSkipButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSkipButton, ""));
        Constants.key.pause("2", "");

        String vObjYesButton = TitanCDSAPhase1OR.getProperty("YesButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjYesButton, ""));
        LogCapture.info("Clicking on YES button for pop-up...");
    }


    @When("^user clicks on Fetch rates buttons$")
    public void userClicksOnFetchRatesButtons() throws Exception {
        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("fetrate");
        Assert.assertEquals("PASS", Constants.key.click(vObjFetchRates, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");

    }

    @Then("^User enter UpperRatePercentage \"([^\"]*)\"$")
    public void userEnterUpperRatePercentage(String UpperRatePercentage) throws Throwable {
        String vObjupperrate = Constants.CreateFxTicketOR.getProperty("ForwardOrderClientRatePercent");
        Assert.assertEquals("PASS", Constants.key.click(vObjupperrate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjupperrate, UpperRatePercentage));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjupperrate, "enter"));
        Constants.key.pause("2", "");
        LogCapture.info("Client rate % entered is: " + UpperRatePercentage);
    }

    @When("^User click on bank method$")
    public void userClickOnBankMethod() throws Exception {
        String vObjbnkopt = Constants.CreateFxTicketOR.getProperty("Bankopt");
        Assert.assertEquals("PASS", Constants.key.click(vObjbnkopt, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");
    }

    @And("^User clicks on Skips button$")
    public void userClicksOnSkipsButton() throws Exception {
        String vObjskipopt = Constants.CreateFxTicketOR.getProperty("ConfirmSkipBtn");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjskipopt, ""));
        LogCapture.info("User clicks on SKIP button...");
    }

    @Then("^user click on yes option$")
    public void userClickOnYesOption() throws Exception {
        String vObjyesButton = Constants.CreateFxTicketOR.getProperty("yesbtton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjyesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjyesButton, ""));
        Constants.key.pause("2", "");

    }

    @And("^User Select Forward type and Select date$")
    public void userSelectForwardTypeAndSelectDate() throws Exception {
        String vObjFixed = CreateFxTicketOR.getProperty("FixedForwardType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFixed, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFixed, ""));
        LogCapture.info("User clicked on Fixed Forward type....");

        LogCapture.info("select  Date....");
        Constants.key.pause("4", "");
        String vObjToDate = Constants.TitanCDSAPhase1OR.getProperty("Selectdate");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjToDate, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjToDate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjToDate, "enter"));
        Constants.key.pause("4", "");
    }

    @And("^User click on fee fetch$")
    public void userClickOnFeeFetch() throws Exception {
        String vObjfeefetch = Constants.CreateFxTicketOR.getProperty("feefetch");
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjfeefetch, ""));
        Constants.key.pause("5", "");
        LogCapture.info("User clicks on fee fetch ...");

    }


    @And("^Add \"([^\"]*)\" payment date enters \"([^\"]*)\"insert \"([^\"]*)\"$")
    public void addPaymentDateEntersInsert(String Payee, String Amount, String Fee) throws Throwable {

        String RandomNumber = RandomStringUtils.randomNumeric(3);
        InAmount = Double.parseDouble(RandomNumber);

        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
        LogCapture.info("Payee: " + Payee + " is selected..");
        Constants.key.pause("3", "");
        //entering date
        LogCapture.info("select value date....");
        Constants.key.pause("4", "");
        String vObjPaymentDate = Constants.TitanCDSAPhase1OR.getProperty("PaymentDate");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPaymentDate, "enter"));
        //enters amount
        Constants.key.pause("4", "");
        if (Amount.equals("") || Amount.isEmpty()) {

            String vObjEnterAmount = Constants.TitanCDSAPhase1OR.getProperty("EnterAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjEnterAmount, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEnterAmount, Double.toString(InAmount)));
            LogCapture.info("Amount entred is: " + InAmount);
        } else {
            Constants.key.pause("4", "");
            String vObjEnterAmount = Constants.TitanCDSAPhase1OR.getProperty("EnterAmount");
            Assert.assertEquals("PASS", Constants.key.click(vObjEnterAmount, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEnterAmount, Amount));
            LogCapture.info("Amount entred is: " + Amount);
        }



        //enters fee
        Constants.key.pause("4", "");
        String vObjEnterFee = Constants.TitanCDSAPhase1OR.getProperty("EnterFee");
        Assert.assertEquals("PASS", Constants.key.click(vObjEnterFee, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEnterFee, Fee));
        LogCapture.info("Fee entred is: " + Fee);
    }

    @And("^select purpose of payment \"([^\"]*)\"and Select the bank\"([^\"]*)\"$")
    public void selectPurposeOfPaymentAndSelectTheBank(String purposeOfPayment, String bank) throws Throwable {
        Constants.key.pause("1", "");
        String vObjpurposeofpayment = TitanCDSAPhase1OR.getProperty("purposeofpayment");
        Assert.assertEquals("PASS", Constants.key.click(vObjpurposeofpayment, ""));
        Constants.key.pause("2", "");
        String vObjsearchbox1 = TitanCDSAPhase1OR.getProperty("Searchbox1");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjsearchbox1, purposeOfPayment));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjsearchbox1, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.click(vObjsearchbox1, ""));
        LogCapture.info("Select purpose Of Payment : is selected..");
        //select bank
        Constants.key.pause("2", "");
        String vObjSelectbank = TitanCDSAPhase1OR.getProperty("Selectbank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectbank, ""));
        Constants.key.pause("2", "");
        String vObjSearchbox2 = TitanCDSAPhase1OR.getProperty("Searchbox2");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchbox2, bank));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchbox2, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchbox2, ""));
        LogCapture.info("Select Bank is selected..");
        Constants.key.pause("1", "");
    }

    @And("^User clicks on Add payment button and finish adding payment button$")
    public void userClicksOnAddPaymentButtonAndFinishAddingPaymentButton() throws Exception {
        //clicks on add payment
        LogCapture.info("Navigate Add payment button....");
        Constants.key.pause("4", "");
        String vObjAddPaymentBtn = Constants.TitanCDSAPhase1OR.getProperty("AddPaymentBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddPaymentBtn, ""));
        LogCapture.info("click on Add payment button....");
        Constants.key.pause("4", "");
        //click on finish adding payment button
        LogCapture.info("navigate finish adding payment....");
        Constants.key.pause("1", "");
        String vObjfinishpayment = Constants.TitanCDSAPhase1OR.getProperty("finishpayment");
        Assert.assertEquals("PASS", Constants.key.click(vObjfinishpayment, ""));
        LogCapture.info("click on finish payment button....");
        Constants.key.pause("4", "");
    }

    @And("^user clicks on Submit button in payout and click on close payment out slip$")
    public void userClicksOnSubmitButtonInPayoutAndClickOnClosePaymentOutSlip() throws Exception {
        //click on submit button
        LogCapture.info("navigate payout submit button....");
        Constants.key.pause("1", "");
        String vObjSubmitButton = Constants.TitanCDSAPhase1OR.getProperty("SubmitButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjSubmitButton, ""));
        LogCapture.info("click on submit button....");
        Constants.key.pause("4", "");
        //click on closeout slip button
        LogCapture.info("navigate to closeout slip button....");
        Constants.key.pause("1", "");
        String vObjCloseSlipButton = Constants.TitanCDSAPhase1OR.getProperty("CloseSlipButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjCloseSlipButton, ""));
        LogCapture.info("click on to closeout slip button....");
        Constants.key.pause("4", "");
    }


    @Then("^verify \"([^\"]*)\" field is disabled$")
    public void verifyFieldIsDisabled(String data) throws Throwable {
        if (data.equalsIgnoreCase("card")) {
            String vObjCardOption = TitanCDSAPhase1OR.getProperty("CardOption");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCardOption, "enabled"));
            Constants.key.pause("2", "");
            LogCapture.info(" card field is disabled....");
        }
        if (data.equalsIgnoreCase("DD")) {
            String vObjDDOption = TitanCDSAPhase1OR.getProperty("DDOption");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDDOption, "enabled"));
            Constants.key.pause("2", "");
            LogCapture.info(" DD field is disabled....");
        }
        if (data.equalsIgnoreCase("DD")) {
            String vObjchequeOption = TitanCDSAPhase1OR.getProperty("chequeOption");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjchequeOption, "enabled"));
            Constants.key.pause("2", "");
            LogCapture.info("cheque field is disabled....");
        }
    }

    @And("^User selects Value date plus two$")
    public void userSelectsValueDatePlusTwo() throws Exception {
        String Valuedate;
        String vObjCalendar = Constants.TitanCDSAPhase1OR.getProperty("Calendar");
        Assert.assertEquals("PASS", Constants.key.click(vObjCalendar, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        DateFormat dateFormat = new SimpleDateFormat("dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY)) {
            cal.add(Calendar.DATE, 4);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if ((cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY)) {
            cal.add(Calendar.DATE, 3);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if (Calendar.DAY_OF_WEEK == Calendar.SATURDAY) {
            cal.add(Calendar.DATE, 2);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else if (Calendar.DAY_OF_WEEK == Calendar.SUNDAY) {
            cal.add(Calendar.DATE, 1);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        } else {
            cal.add(Calendar.DATE, 1);
            Valuedate = dateFormat.format(cal.getTime());
            System.out.println("ValueDate = " + Valuedate);
        }
        if (Valuedate.equals("01")) {
            Valuedate = "1";
        } else if (Valuedate.equals("02")) {
            Valuedate = "2";
        } else if (Valuedate.equals("03")) {
            Valuedate = "3";
        } else if (Valuedate.equals("04")) {
            Valuedate = "4";
        } else if (Valuedate.equals("05")) {
            Valuedate = "5";
        } else if (Valuedate.equals("06")) {
            Valuedate = "6";
        } else if (Valuedate.equals("07")) {
            Valuedate = "7";
        } else if (Valuedate.equals("08")) {
            Valuedate = "8";
        } else if (Valuedate.equals("09")) {
            Valuedate = "9";
        }


        String CDSAValueDate = "//a[@class='ui-state-default' and contains(text(),'" + Valuedate + "')]";
        Assert.assertEquals("PASS", Constants.key.click(CDSAValueDate, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User select value date as " + Valuedate);


    }

    @And("^user selects value date$")
    public void userSelectsValueDate() throws Exception {
        LogCapture.info("select value date....");
        Constants.key.pause("7", "");
        String vObjvaluedate = Constants.TitanCDSAPhase1OR.getProperty("valuedate");
        Assert.assertEquals("PASS", Constants.key.click(vObjvaluedate, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjvaluedate, "enter"));
        LogCapture.info("User select value date");

    }

    @And("^user able to selects Bank$")
    public void userabletoSelectsBank() throws Exception {
        LogCapture.info("select bank option....");
        Constants.key.pause("4", "");
        String vObjBankname = Constants.TitanCDSAPhase1OR.getProperty("Bankname");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankname, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBankname, "enter"));
        String vObjselectbanklable = Constants.TitanCDSAPhase1OR.getProperty("selectbanklable");
        Assert.assertEquals("PASS", Constants.key.click(vObjselectbanklable, ""));
        LogCapture.info("select bank..");
    }


    @Then("^User click on first record from Payee Report page to verify Payee Details$")
    public void userClickOnFirstRecordFromPayeeReportPageToVerifyPayeeDetails() throws Exception {
        String vobjFirstRecordPayeeReport = TitanPayeeOR.getProperty("FirstRecordPayeeReport");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordPayeeReport, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordPayeeReport, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

        String vobjPayeeDetailsName = Constants.TitanPayeeOR.getProperty("PayeeDetailsName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsName, "visible"));
        LogCapture.info("User able to view Payee Name on Payee details page");

        String vobjPayeeDetailsAdress = Constants.TitanPayeeOR.getProperty("PayeeDetailsAdress");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsAdress, "visible"));
        LogCapture.info("User able to view Payee Address on Payee details page");

        String vobjPayeeDetailsAccountNo = Constants.TitanPayeeOR.getProperty("PayeeDetailsAccountNo");
        Assert.assertEquals("PASS", Constants.key.click(vobjPayeeDetailsAccountNo, ""));
        LogCapture.info("User able to view Bank Account Number on Payee details page");

        String vobjPayeeDetailsBankName = Constants.TitanPayeeOR.getProperty("PayeeDetailsBankName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayeeDetailsBankName, "visible"));
        LogCapture.info("User able to View Bank Name on Payee details page");
    }

    @And("^User selects bank for FX$")
    public void userSelectsBankForFX() throws Exception {
        LogCapture.info("select bank option....");
        Constants.key.pause("4", "");
        String vObjBan_kname = Constants.TitanCDSAPhase1OR.getProperty("Bank_name");
        Assert.assertEquals("PASS", Constants.key.click(vObjBan_kname, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBan_kname, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBan_kname, "enter"));
        String vObjfirstBank = TitanCDSAPhase1OR.getProperty("firstBank");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjfirstBank, ""));
        LogCapture.info("select bank..");
    }

    @And("^User clicks on BANKS tab under Linked to client$")
    public void userClicksOnBANKSTabUnderLinkedToClient() throws Exception {
        String vObjBANKSTab = Constants.TitanCDSAPhase1OR.getProperty("BANKSTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBANKSTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjBANKSTab, ""));
        LogCapture.info("Clicking on BANKS tab...");
    }

    @And("^User clicks on SEND EMAIL$")
    public void userClicksOnSENDEMAIL() throws Exception {
        Constants.key.pause("4", "");
        String vObjSendEmailButton = Constants.TitanCDSAPhase1OR.getProperty("SendEmailButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendEmailButton, ""));
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjSendEmailButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSendEmailButton, ""));
        LogCapture.info("Clicking on Send Email Button...");

    }

    @Then("^User is able to view Email Sent Successfully message$")
    public void userIsAbleToViewEmailSentSuccessfullyMessage() throws Exception {
        Constants.key.pause("4", "");
        String vobjEmailMessage = Constants.TitanCDSAPhase1OR.getProperty("EmailMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjEmailMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjEmailMessage, "visible"));
        LogCapture.info("Email Sent Successfully message is visible...");
    }

    @And("^User clicks on Fetch rates button for forward$")
    public void userClicksOnFetchRatesButtonForForward() throws Exception {
        String vObjFetchRates = Constants.CreateFxTicketOR.getProperty("FetchRates");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFetchRates, ""));
        LogCapture.info("User clicks on Fetch Rates button..");
        Constants.key.pause("4", "");
        String vObjLiveRateValue = Constants.CreateFxTicketOR.getProperty("LiveRateValueCDSA");
        String LiveRate = Constants.driver.findElement(By.xpath(vObjLiveRateValue)).getText();
        if (LiveRate == null) {
            LogCapture.info("Fetching rates.. Live Rate is Null...");
            Assert.fail();
        } else {
            LogCapture.info("Fetching rates.. Live rate is: " + LiveRate);
        }
        LogCapture.info("Rates fetched..");


    }


    @And("^User click on first record from FX tickets Queue page$")
    public void userClickOnFirstRecordFromFXTicketsQueuePage() throws Exception {

        String vObjErrorMsg = Constants.TitanCustomersOR.getProperty("ErrorMsg");
        Assert.assertEquals("PASS", Constants.key.notexist(vObjErrorMsg, ""));
        LogCapture.info("Error Msg is not visible as expected..");

        String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
        LogCapture.info("User is on FX tickets in Titan page..");

        String vobjFirstRecordFXticketsQueue = TitanFXTicketsOR.getProperty("FirstRecordFXticketsQueue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFirstRecordFXticketsQueue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFirstRecordFXticketsQueue, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User able to view first record and clicked on it...");

    }

    @Then("^User verify Actual profit and Tax amount field present on FX details page$")
    public void userVerifyActualProfitAndTaxAmountFieldPresentOnFXDetailsPage() throws Exception {

        Constants.key.pause("4", "");
        String vobjActualProfit = Constants.TitanFXTicketsOR.getProperty("FXActualProfit");
        String vobjActualProfitValue = Constants.TitanFXTicketsOR.getProperty("FXActualProfitValue");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjActualProfit, "visible"));
        String ActualProfitValue = Constants.driver.findElement(By.xpath(vobjActualProfitValue)).getText();
        LogCapture.info("User able to View Actual Profit = " + ActualProfitValue + " on FX Ticket details page");

        String vobjTaxAmount = Constants.TitanFXTicketsOR.getProperty("FXTaxAmount");
        String vobjTaxAmountValue = Constants.TitanFXTicketsOR.getProperty("FXTaxAmountValue");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjTaxAmount, "visible"));
        String TaxAmountValue = Constants.driver.findElement(By.xpath(vobjTaxAmountValue)).getText();
        LogCapture.info("User able to View Tax Amount =" + TaxAmountValue + " on FX Ticket details page");
    }

    @And("^User enter Client rate \"([^\"]*)\"$")
    public void userEnterClientRate(String ClientRate) throws Throwable {
        String vObjClientRate = Constants.CreateFxTicketOR.getProperty("ClientRate");
        Assert.assertEquals("PASS", Constants.key.click(vObjClientRate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjClientRate, ClientRate));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjClientRate, "enter"));
        Constants.key.pause("2", "");
        LogCapture.info("Client rate decimal entered is: " + ClientRate);

    }

    @And("^User enter Forward Client rate \"([^\"]*)\"$")
    public void userEnterForwardClientRate(String ClientRate) throws Throwable {
        String vObjForwardClientRate = Constants.CreateFxTicketOR.getProperty("ForwardClientRate");
        Assert.assertEquals("PASS", Constants.key.click(vObjForwardClientRate, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardClientRate, ClientRate));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjForwardClientRate, "enter"));
        Constants.key.pause("2", "");
        LogCapture.info("Client rate decimal entered is: " + ClientRate);
    }


    @And("^User enters Add Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" and verify mandatory fields then click on Next button$")
    public void userEntersAddPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAndVerifyMandatoryFieldsThenClickOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country) throws Throwable {

        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
        String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
        String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
        String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Company Payee type is selected..");

            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);
        Constants.key.pause("3", "");

        String vObjLegalEntity = Constants.TitanPayeeOR.getProperty("LegalEntity");
        String LegalEntity = Constants.driver.findElement(By.xpath(vObjLegalEntity)).getText();

        if (LegalEntity.equals("TORAU") || LegalEntity.equals("CDINC")) {
            String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, "123456"));
            LogCapture.info("Payee Address Post Code: 200333 entered..");

            String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, "18dong"));
            LogCapture.info("Payee Address: 18dong entered..");

            String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, "Shanghai"));
            LogCapture.info("Payee Address: Shanghai entered..");
        }

        String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjFirstName));
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjLastName));
            LogCapture.info("Payee FirstName and Last Name Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified: Payee FirstName and Lastname field mandatory.");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName + " CNY"));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("4", "");
            LogCapture.info("User enters all mandatory fields on Payee details page...");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled: Verified all mandatory fields on 1/3 Payee details page...");
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjCompanyName));
            LogCapture.info("Company Name Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified: Payee Company Name field mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            LogCapture.info("User enters all mandatory fields on Payee details page...");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
            LogCapture.info("Next button is enabled: Verified all mandatory fields on 1/3 Payee details page...");
        }

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");
    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" BankCodeType\"([^\"]*)\" BankCode\"([^\"]*)\" and verify mandatory fields then click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberBankCodeTypeBankCodeAndVerifyMandatoryFieldsThenClickOnNextButton(String AccountNumber, String BankCodeType, String BankCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");
        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        String vObjIBANNumber = Constants.TitanPayeeOR.getProperty("IBANNumber");
        String vObjABANumber = Constants.TitanPayeeOR.getProperty("ABANumber");
        String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
        String vObjBankNameHeader = Constants.TitanPayeeOR.getProperty("BankNameHeader");
        String vObjPayeeBankDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnEnable");
        String vObjPayeeBankDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnDisable");


        if (AccountNumber.equalsIgnoreCase("IBAN")) {
            LogCapture.info("Account number NOT required but IBAN number for EUR required..");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIBANNumber, "ES9121000418450200051332"));
            LogCapture.info("IBAN number is entered..");

        } else {
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
            LogCapture.info("Account number is entered..");
        }
        if (BankCodeType.equalsIgnoreCase("ABA")) {
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjABANumber, BankCode));
            LogCapture.info("ABA number is entered..");
        }
        if (BankCodeType.equalsIgnoreCase("SWIFT")) {
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number is entered..");
        }

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");

        if (AccountNumber.equalsIgnoreCase("IBAN")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjIBANNumber, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjIBANNumber));
            LogCapture.info("Payee IBAN Number Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified IBAN number is mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIBANNumber, "ES9121000418450200051332"));
            Constants.key.pause("1", "");
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjAccountNumber));
            LogCapture.info("Payee Account Number Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified Account number fields is mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
            Constants.key.pause("1", "");
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjSWIFTCode));
        LogCapture.info("Payee Swift Code Cleared ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified Swift code field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");

        LogCapture.info("User enters all mandatory fields on 2/3 Payee Bank details page... ");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified: Payee Account Number and Swift code field is mandatory...");

        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^User enters Add Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" and verify mandatory fields for Etailer then click on Next button$")
    public void userEntersAddPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAndVerifyMandatoryFieldsForEtailerThenClickOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country) throws Throwable {

        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
        String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
        String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
        String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Company Payee type is selected..");

            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }

        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);
        Constants.key.pause("3", "");

        String vObjCountryCode = Constants.TitanPayeeOR.getProperty("PayeeCountryCode");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountryCode, "+86"));
        LogCapture.info("Payee Country Code: +86 is entered");
        String vObjPhoneNumber = Constants.TitanPayeeOR.getProperty("PayeePhoneNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPhoneNumber, "13910998888"));
        LogCapture.info("Payee Phone Numner: 13910998888 is entered");

        String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjFirstName));
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjLastName));
            LogCapture.info("Payee FirstName and Last Name Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified Payee FirstName and Lastname field mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName + " CNY"));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjCompanyName));
            LogCapture.info("Company Name Cleared ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified: Payee Company Name field mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("1", "");
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjCountryCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjCountryCode));
        Assert.assertEquals("PASS", Constants.key.click(vObjPhoneNumber, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPhoneNumber));
        LogCapture.info("Payee CountryCode and Phone Number Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee CountryCode and Phone Number field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountryCode, "+84"));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPhoneNumber, "13910998888"));
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User enters all mandatory fields on payee details page...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified all mandatory field on payee details page 1/3...");

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");
    }


    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" ResidentialID\"([^\"]*)\" Name In Local LanguageCode\"([^\"]*)\" CNAP code \"([^\"]*)\" Swift Code \"([^\"]*)\" and verify mandatory fields then click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberResidentialIDNameInLocalLanguageCodeCNAPCodeSwiftCodeAndVerifyMandatoryFieldsThenClickOnNextButton(String AccountNumber, String FFCDetails, String NameInLocalLang, String CNAP, String SwiftCode) throws Throwable {

        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        LogCapture.info("Account number is entered..");

        String vObjFFCDetails = Constants.TitanPayeeOR.getProperty("FFCDetails");
        Assert.assertEquals("PASS", Constants.key.click(vObjFFCDetails, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFFCDetails, FFCDetails));
        LogCapture.info("FFC details(Residential ID) is entered..");

        String vObjNameinLocalLanguage = Constants.TitanPayeeOR.getProperty("NameinLocalLanguage");
        Assert.assertEquals("PASS", Constants.key.click(vObjNameinLocalLanguage, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameinLocalLanguage, NameInLocalLang));
        LogCapture.info("Name in local language is entered..");

        String vObjCNAPCode = Constants.TitanPayeeOR.getProperty("CNAPCode");
        Assert.assertEquals("PASS", Constants.key.click(vObjCNAPCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCNAPCode, CNAP));
        LogCapture.info("CNAP Code is entered..");

        String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SwiftCode));
        LogCapture.info("SWIFT number is entered..");

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");

        String vObjBankNameHeader = Constants.TitanPayeeOR.getProperty("BankNameHeader");
        String vObjPayeeBankDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnEnable");
        String vObjPayeeBankDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnDisable");

        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAccountNumber));
        LogCapture.info("Payee Account Number Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee Account Number field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjFFCDetails, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjFFCDetails));
        LogCapture.info("FFC (Residential ID) Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee FFC (Residential ID) field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFFCDetails, FFCDetails));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjNameinLocalLanguage, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjNameinLocalLanguage));
        LogCapture.info("Name in local language is Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee Name in local language field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameinLocalLanguage, NameInLocalLang));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjCNAPCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjCNAPCode));
        LogCapture.info("CNAP Code is Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee CNAP Code field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCNAPCode, CNAP));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjSWIFTCode));
        LogCapture.info("Payee Swift Code Cleared ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Swift Code  field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SwiftCode));
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("1", "");

        LogCapture.info("User enters all mandatory fields on Bank details Page");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified: all mandatory fields on Bank details page...");

        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }

    @And("^User enters Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" Address\"([^\"]*)\" Town\"([^\"]*)\" Postcode\"([^\"]*)\" and verify mandatory fields for NonEtailer then click on Next button$")
    public void userEntersPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameCurrencyReceiveCountryAddressTownPostcodeAndVerifyMandatoryFieldsForNonEtailerThenClickOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String CurrencyReceive, String Country, String Address, String Town, String Postcode) throws Throwable {

        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");
        String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
        String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
        String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("Payee First Name: " + FirstName + " entered..");

            PayeeLastName = LastName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Payee Last Name: " + LastName + " entered..");
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            LogCapture.info("Company Payee type is selected..");

            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Payee Company Name entered..");
        }


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
        LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
        LogCapture.info("Country selected is: " + Country);
        Constants.key.pause("2", "");

        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
        LogCapture.info("Payee Address Post Code: " + Postcode + " entered..");

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
        LogCapture.info("Payee Address: " + Address + " entered..");

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
        LogCapture.info("Payee Town: " + Town + " entered..");

        String vObjAddressHeader = Constants.TitanPayeeOR.getProperty("AddressHeader");
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        String vObjPayeeDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnEnable");
        String vObjPayeeDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtnDisable");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjFirstName));
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjLastName));
            LogCapture.info("Payee FirstName and Last Name Removed ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled: Verified: Payee FirstName and Lastname field mandatory...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName + " CNY"));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("1", "");
        } else {
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjCompanyName));
            LogCapture.info("Company Name Removed ..");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
            LogCapture.info("Next button is disabled...");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
            Constants.key.pause("1", "");
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAddressPostCodeField));
        LogCapture.info("Payee Post Code field removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee PostCode Field mandatory.....");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeAddressField));
        LogCapture.info("Payee Address field removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified: Payee Address Field mandatory....");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPayeeTownField));
        LogCapture.info("Payee Town field removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button disabled: Verified: Payee Town Field mandatory.....");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
        Constants.key.pause("1", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjAddressHeader, ""));
        LogCapture.info("User enters all mandatory fields on Payee details page...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified all mandatory fields...");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" Purpose code \"([^\"]*)\" Swift Code \"([^\"]*)\" and verify mandatory fields then click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberPurposeCodeSwiftCodeAndVerifyMandatoryFieldsThenClickOnNextButton(String AccountNumber, String PurposeCode, String SwiftCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
        LogCapture.info("Account number is entered..");

        String vObjPurposeCode = Constants.TitanPayeeOR.getProperty("PurposeCode");
        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeCode, PurposeCode));
        LogCapture.info("Purpose Code is entered..");

        String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SwiftCode));
        LogCapture.info("SWIFT number is entered..");

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");

        String vObjBankNameHeader = Constants.TitanPayeeOR.getProperty("BankNameHeader");
        String vObjPayeeBankDetailsNextBtnEnable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnEnable");
        String vObjPayeeBankDetailsNextBtnDisable = Constants.TitanPayeeOR.getProperty("PayeeBankDetailsNextBtnDisable");

        Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAccountNumber));
        LogCapture.info("Payee Account Number Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified Payee Account Number field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));

        Assert.assertEquals("PASS", Constants.key.click(vObjPurposeCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPurposeCode));
        LogCapture.info("Purpose Code is Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified Payee Purpose Code field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeCode, PurposeCode));

        Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjSWIFTCode));
        LogCapture.info("Payee Swift Code Removed ..");
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnDisable, "visible"));
        LogCapture.info("Next button is disabled: Verified Swift Code  field is mandatory...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, SwiftCode));
        Assert.assertEquals("PASS", Constants.key.click(vObjBankNameHeader, ""));

        LogCapture.info("User enters all mandatory fields on Bank details page...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeBankDetailsNextBtnEnable, "visible"));
        LogCapture.info("Next button is enabled: Verified: all mandatory fields on 2/3 Bank details page...");

        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("Clicked on Next button..");
    }


    @And("^User navigate to search result and click on (INPROCESS|AWAITINGBANKAPPROVAL|APPROVED|PARTIALLYAPPROVED|CANCELLED) Payment out record$")
    public void userNavigateToSearchResultAndClickOnINPROCESSPaymentOutRecord(String PayOutStatus) throws Exception {

        Thread.sleep(2000);
        for (int i = 1; i <= 50; i++) {
            String vObjPayOutStatus = "//table[@id='tbl-funds-out']//tbody//tr[" + i + "]//td[10]//a";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayOutStatus, ""));
            String PaymentOutStatus = Constants.key.getText(vObjPayOutStatus, "");

            if (PaymentOutStatus.equals(PayOutStatus)) {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayOutStatus, ""));
                LogCapture.info("User navigate to " + PaymentOutStatus + " Payment Out Record");
                break;
            }
        }
    }

    @Then("^User navigate to Payment out details page$")
    public void userNavigateToPaymentOutDetailsPage() throws Exception {

        String vobjPaymentOutHeader = Constants.TitanPaymentOutOR.getProperty("PaymentOutHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentOutHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPaymentOutHeader, "visible"));

        String vObjPaymentOutStatus = TitanPaymentOutOR.getProperty("PaymentOutStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutStatus, ""));
        //       Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentOutStatus, "visible"));
        String ActualPayOutStatus = Constants.key.getText(vObjPaymentOutStatus, "");
        LogCapture.info("Payment Out Status " + ActualPayOutStatus + " Verified");

        String vobjPayOutPayeeName = Constants.TitanPaymentOutOR.getProperty("PayOutPayeeName");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPayOutPayeeName, "visible"));
        String PayeeName = Constants.key.getText(vobjPayOutPayeeName, "");
        LogCapture.info("User able to View Payee Name = " + PayeeName + " on PaymentOut Customers details page");

    }

    @Then("^User click on Add Memo and verify Delete Payment button is (Enable|Disable)$")
    public void userClickOnAddMemoAndVerifyDeletePaymentButtonIsEnable(String Button) throws Exception {

        String vobjAddMemoLink = TitanPaymentOutOR.getProperty("AddMemoLink");
        Assert.assertEquals("PASS", key.navigateSubMenu(vobjAddMemoLink, ""));
        String vobjMemoHeader = TitanPaymentOutOR.getProperty("MemoHeader");
        LogCapture.info("Clicking on Add Memo Link.....");

        if (Button.equals("Enable")) {
            Assert.assertEquals("PASS", key.VisibleConditionWait(vobjMemoHeader, ""));
            Assert.assertEquals("PASS", key.verifyElementProperties(vobjMemoHeader, "visible"));
            LogCapture.info("Memo PopUp Header is visible");

            String vobjAddMemoTextArea = TitanPaymentOutOR.getProperty("AddMemoTextArea");
            String vobjAddMemoButton = TitanPaymentOutOR.getProperty("AddMemoButton");
            Assert.assertEquals("PASS", key.writeInInput(vobjAddMemoTextArea, "Wrong Payment Out Allocation"));
            Assert.assertEquals("PASS", key.click(vobjAddMemoButton, ""));
            LogCapture.info("User Add Memo note and Click on Add Memo Button");

            String vobjDeletePaymentEnable = TitanPaymentOutOR.getProperty("DeletePaymentEnable");
            Assert.assertEquals("PASS", key.verifyElementProperties(vobjDeletePaymentEnable, "enabled"));
            Assert.assertEquals("PASS", key.click(vobjDeletePaymentEnable, ""));
            LogCapture.info("User Verify Delete Payment Button is Enable and Click on Delete Payment...");

            String vobjDeletePaymentYes = TitanPaymentOutOR.getProperty("DeletePaymentYes");
            Assert.assertEquals("PASS", key.navigateSubMenu(vobjDeletePaymentYes, ""));
            LogCapture.info("User Click on delete Payment => Yes .....");

            String vobjPaymentDeletedSuccessfully = TitanPaymentOutOR.getProperty("PaymentDeletedSuccessfully");
            Assert.assertEquals("PASS", key.VisibleConditionWait(vobjPaymentDeletedSuccessfully, ""));
            Assert.assertEquals("PASS", key.verifyElementProperties(vobjPaymentDeletedSuccessfully, "visible"));
            String PaymentDeletedSuccessfullyMSG = key.getText(vobjPaymentDeletedSuccessfully, "");
            LogCapture.info("User able to see <" + PaymentDeletedSuccessfullyMSG + "> Message....");

        } else if (Button.equals("Disable")) {
            String vobjDeletePaymentDisable = TitanPaymentOutOR.getProperty("DeletePaymentDisable");
            String Dis = driver.findElement(By.xpath(vobjDeletePaymentDisable)).getAttribute("class");
            if (Dis.contains("disabled")) {
                LogCapture.info("User Verify Delete Payment Button is Disable and unable to delete Payment...");
                Assert.assertEquals("PASS", "PASS");
            } else {
                LogCapture.info("TC Failed >> Delete Payment Button is Enabled..");
                Assert.assertEquals("PASS", "FAIL");
            }
        }
    }

    @Then("^User verify if the Method is (BACS/CHAPS/TT|RETURN_OF_FUNDS|CHEQUE/DRAFT|WALLET|DEBIT_CARD) and Titan Status is Funded$")
    public void userVerifyIfTheMethodIsBACSCHAPSTTAndTitanStatusIsFunded(String Method) throws Exception {

        if (Method.equals("RETURN_OF_FUNDS")) {
            for (int i = 1; i <= 50; i++) {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if (PauymentMode.equals("RETURN_OF_FUNDS") && TitanStatus.equals("FUNDED")) {
                    LogCapture.info("User verify ModeOfPayment As RETURN_OF_FUNDS and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        } else if (Method.equals("BACS/CHAPS/TT")) {
            for (int i = 1; i <= 50; i++) {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if (PauymentMode.equals("BACS/CHAPS/TT") && TitanStatus.equals("FUNDED")) {
                    LogCapture.info("User verify ModeOfPayment As BACS/CHAPS/TT and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        } else if (Method.equals("WALLET")) {
            for (int i = 1; i <= 50; i++) {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if (PauymentMode.equals("WALLET") && TitanStatus.equals("FUNDED")) {
                    LogCapture.info("User verify ModeOfPayment As WALLET and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
//                }else if(PauymentMode.equals("WALLET") && TitanStatus.equals("INPROCESS")){
//                    LogCapture.info("User verify ModeOfPayment As WALLET and Titan Status INPROCESS");
//                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
//                    break;
//                }
            }
        } else if (Method.equals("CHEQUE/DRAFT")) {
            for (int i = 1; i <= 50; i++) {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if (PauymentMode.equals("CHEQUE/DRAFT") && TitanStatus.equals("FUNDED")) {
                    LogCapture.info("User verify ModeOfPayment As CHEQUE/DRAFT and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        } else if (Method.equals("DEBIT_CARD")) {
            for (int i = 1; i <= 50; i++) {
                String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[7]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
                String PauymentMode = key.getText(VObjPauymentMode, "");

                String VObjTitanStatus = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[9]//a";
                Assert.assertEquals("PASS", key.VisibleConditionWait(VObjTitanStatus, ""));
                String TitanStatus = key.getText(VObjTitanStatus, "");

                if (PauymentMode.equals("DEBIT_CARD") && TitanStatus.equals("FUNDED")) {
                    LogCapture.info("User verify ModeOfPayment As DEBIT_CARD and Titan Status Funded");
                    Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                    break;
                }
            }
        }

    }

    @And("^User Click on Payment in Button$")
    public void userClickOnPaymentInButton() throws Exception {
        LogCapture.info("User clicking On Payment in Button");
        String VobjPaymentInButton = Constants.TitanCustomersOR.getProperty("PaymentInBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjPaymentInButton, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User Clicked on Payment In Button.. ");
    }

    @Then("^User verify release button (Enable|Disable)$")
    public void userVerifyReleaseButtonEnable(String Button) throws Exception {

        LogCapture.info("User is on Incoming Funds profile page... ");
        String VobjIncomingFundsProfile = Constants.TitanCustomersOR.getProperty("IncomingFundsProfile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VobjIncomingFundsProfile, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjIncomingFundsProfile, "visible"));

        LogCapture.info("User Verifying Release button is " + Button + "... ");
        String VobjReleaseButton = Constants.TitanCustomersOR.getProperty("ReleaseButton");
        if (Button.equals("Enable")) {
            String Dis = driver.findElement(By.xpath(VobjReleaseButton)).getAttribute("class");
            if (Dis.contains("disabled")) {
                LogCapture.info("TC Failed >> Release Payment Button is Disabled..");
                Assert.assertEquals("PASS", "FAIL");
            } else {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjReleaseButton, ""));
                String VobjReleaseCancel = Constants.TitanCustomersOR.getProperty("ReleaseCancel");
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjReleaseCancel, ""));
                LogCapture.info("User Verify release Button is Enable and able to release Payment...");
                Assert.assertEquals("PASS", "PASS");
            }
        } else if (Button.equals("Disable")) {
            String Dis = driver.findElement(By.xpath(VobjReleaseButton)).getAttribute("class");
            if (Dis.contains("disabled")) {
                LogCapture.info("User Verify release Button is Diasable and unable to release Payment...");
                Assert.assertEquals("PASS", "PASS");
            } else {
                LogCapture.info("TC Failed >> Release Payment Button is Enable..");
                Assert.assertEquals("PASS", "FAIL");
            }
        }
    }

    @Then("^User verify Release & Re-allocate button is button (Enable|Disable)$")
    public void userVerifyReleaseReAllocateButtonIsButtonEnable(String Button) throws Exception {

        LogCapture.info("User is on Incoming Funds profile page... ");
        String VobjIncomingFundsProfile = Constants.TitanCustomersOR.getProperty("IncomingFundsProfile");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VobjIncomingFundsProfile, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjIncomingFundsProfile, "visible"));

        LogCapture.info("User Verifying Release & Reallocate button is " + Button + "... ");
        String VobjReallocateButton = Constants.TitanCustomersOR.getProperty("ReallocateButton");
        if (Button.equals("Enable")) {
            String Dis = driver.findElement(By.xpath(VobjReallocateButton)).getAttribute("class");
            if (Dis.contains("disabled")) {
                LogCapture.info("TC Failed >> Release Payment Button is Disabled..");
                Assert.assertEquals("PASS", "FAIL");
            } else {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjReallocateButton, ""));
                LogCapture.info("User Verify Release & Re-allocate button is Enable and able to click on re-allocate button...");
                Assert.assertEquals("PASS", "PASS");
            }
        } else if (Button.equals("Disable")) {
            String Dis = driver.findElement(By.xpath(VobjReallocateButton)).getAttribute("class");
            if (Dis.contains("disabled")) {
                LogCapture.info("User Verify release Button is Diasable and unable to release Payment...");
                Assert.assertEquals("PASS", "PASS");
            } else {
                LogCapture.info("TC Failed >> Release Payment Button is Enable..");
                Assert.assertEquals("PASS", "FAIL");
            }
        }
    }

    @And("^User enter Mandatory details \"([^\"]*)\" on transfer to client page$")
    public void userEnterMandatoryDetailsOnTransferToClientPage(String CreditorNumber) throws Throwable {

        String VobjTransferButtonDisable = Constants.TitanCustomersOR.getProperty("MakeTransferButtonDisable");
        String VobjTransferButtonEnable = Constants.TitanCustomersOR.getProperty("MakeTransferButtonDisable");
        String VobjTransferToClient = Constants.TitanCustomersOR.getProperty("TransferToClient");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VobjTransferToClient, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferToClient, "visible"));
        LogCapture.info("User is on Transfer to client page..");

        String VobjClientNumber = Constants.TitanCustomersOR.getProperty("ClientNumber");
        Assert.assertEquals("PASS", Constants.key.click(VobjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjClientNumber, CreditorNumber));

        String VobjTransferNote = Constants.TitanCustomersOR.getProperty("TransferNote");
        Assert.assertEquals("PASS", Constants.key.click(VobjTransferNote, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjTransferNote, "Testing Funds In"));

        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferButtonDisable, "visible"));
        LogCapture.info("Make Transfer button is disabled: Verified Transfer reason is mandatory...");

        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjTransferNote, "Testing_funds"));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(VobjTransferNote, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(VobjTransferNote, "enter"));
        LogCapture.info("Transfer reason Testing Funds is selected..");

        Assert.assertEquals("PASS", Constants.key.click(VobjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(VobjClientNumber));
        LogCapture.info("Client Number Cleared ..");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferButtonDisable, "visible"));
        LogCapture.info("Make Transfer button is disabled: Verified Client Number is mandatory...");

        Assert.assertEquals("PASS", Constants.key.click(VobjClientNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjClientNumber, CreditorNumber));

        Assert.assertEquals("PASS", Constants.key.click(VobjTransferNote, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(VobjTransferNote));
        LogCapture.info("Transfer note Cleared ..");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferButtonDisable, "visible"));
        LogCapture.info("Make Transfer button is disabled: Verified Transfer note is mandatory...");

        Assert.assertEquals("PASS", Constants.key.click(VobjTransferNote, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(VobjTransferNote, "Testing Funds In"));
        LogCapture.info("User enter all mandatory details...");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(VobjTransferButtonEnable, "visible"));
        LogCapture.info("User verify : Make Transfer button is Enable and able to re-allocate...");

    }

    @And("^User selects Method\"([^\"]*)\" and enter State \"([^\"]*)\"$")
    public void userSelectsMethodAndEnterState(String arg0, String State) throws Throwable {
        String vObjPaymnetInQueueMethod = Constants.TitanPaymentInOR.getProperty("PaymnetInQueueMethod");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymnetInQueueMethod, ""));
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymnetInQueueMethod, ""));
        String vObjPaymnetInQueueMethodDropdown = Constants.TitanPaymentInOR.getProperty("PaymnetInQueueMethodDropdown");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPaymnetInQueueMethodDropdown, ""));
        Constants.key.pause("2", "");
        String CHEQUE_DRAFT_ToBeSelected = Constants.TitanPaymentInOR.getProperty("CHEQUE_DRAFT_ToBeSelected");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CHEQUE_DRAFT_ToBeSelected, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CHEQUE_DRAFT_ToBeSelected, ""));
        LogCapture.info(CHEQUE_DRAFT_ToBeSelected + " is selected...");
        Constants.key.pause("2", "");
        String vObjStateBox = Constants.TitanPaymentInOR.getProperty("StateBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjStateBox, State));
        LogCapture.info("User enter State name...");


    }


    @Then("^User verify value date on Fx details page$")
    public void userVerifyValueDateOnFxDetailsPage() throws Exception {

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter DateDDMMYYYY = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String ActualvalueDate = DateDDMMYYYY.format(now);

        String vObjValueDate2of4Page = Constants.CreateFxTicketOR.getProperty("ValueDate2of4Page");
        String ValueDateonFetchrate = Constants.driver.findElement(By.xpath(vObjValueDate2of4Page)).getText();

        if (ValueDateonFetchrate.equals(ActualvalueDate)) {
            Assert.assertEquals(ValueDateonFetchrate, ActualvalueDate);
            LogCapture.info("User verify value date as todays date 2/4 fetch rate page " + ValueDateonFetchrate);
        } else if (!ValueDateonFetchrate.equals(ActualvalueDate) && !ValueDateonFetchrate.equals("")) {
            Assert.assertNotEquals(ValueDateonFetchrate, ActualvalueDate);
            LogCapture.info("User verify value date is not todays date 2/4 fetch rate page <<<<<<< " + ValueDateonFetchrate + " >>>>>>>>>>");
        } else {
            Assert.fail();
        }
    }

    @And("^User verify value date on Summary details$")
    public void userVerifyValueDateOnSummaryDetails() {

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter DateDDMMYYYY = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String valueDateonSummary = DateDDMMYYYY.format(now);

        String vObjValueDateonSummary = Constants.CreateFxTicketOR.getProperty("ValueDateonSummary");
        String DateSummary = Constants.driver.findElement(By.xpath(vObjValueDateonSummary)).getText();
        if (valueDateonSummary.equals(DateSummary)) {
            Assert.assertEquals(valueDateonSummary, DateSummary);
            LogCapture.info("User verify value date as todays date on transaction summary details " + DateSummary);
        } else if (!DateSummary.equals(valueDateonSummary) && !DateSummary.equals("")) {
            Assert.assertNotEquals(valueDateonSummary, DateSummary);
            LogCapture.info("User verify value date is not todays date on transaction summary details " + DateSummary);
        }
    }


    @Then("^User click on transfer to client option$")
    public void userClickOnTransferToClientOption() throws Exception {

        String vObjTransferToClient = TitanDashboardOR.getProperty("TransferToClientButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransferToClient, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjTransferToClient, ""));
        LogCapture.info("Verify User click on Transfer to client option.........");

    }

    @And("^User enter CustomerTAN \"([^\"]*)\" Amount \"([^\"]*)\" TransferReason \"([^\"]*)\" and then click on make transfer$")
    public void userEnterCustomerTANAmountTransferReasonAndThenClickOnMakeTransfer(String CustomerTAN, String Amount, String TransferReason) throws Throwable {

        String vObjTransferToClientHeader = TitanDashboardOR.getProperty("TransferToClientHeader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferToClientHeader, "Transfer to client"));
        LogCapture.info("Verify user is on transfer to client page.........");

        String vObjClientNumberDash = TitanDashboardOR.getProperty("ClientNumberDash");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjClientNumberDash, CustomerTAN));
        LogCapture.info("Verify user Client Number as " + CustomerTAN + ".........");

        String TransferAmount = TitanDashboardOR.getProperty("TransferAmount");
        Assert.assertEquals("PASS", Constants.key.writeInInput(TransferAmount, Amount));
        LogCapture.info("Verify user Amount as " + Amount + ".........");

        String vObjTransferReasonDash = TitanDashboardOR.getProperty("TransferReasonDash");
        Assert.assertEquals("PASS", Constants.key.click(vObjTransferReasonDash, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjTransferReasonDash, ""));
        String vObjTransferReasonSearchBarDash = TitanDashboardOR.getProperty("TransferReasonSearchBarDash");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjTransferReasonSearchBarDash, TransferReason));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjTransferReasonSearchBarDash, "downArrow"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjTransferReasonSearchBarDash, "enter"));
        LogCapture.info("Verify user select transfer reason as " + TransferReason + ".........");

        String vObjMakeTransferButton = TitanDashboardOR.getProperty("MakeTransferButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjMakeTransferButton, ""));
        LogCapture.info("Verify user click on make transfer.........");

        String vObjTransferHasBeenMade = TitanDashboardOR.getProperty("TransferHasBeenMade");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransferHasBeenMade, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjTransferHasBeenMade, "Transfer has been made."));
        LogCapture.info("Verify user able to see [Transfer Has Been Made.] message.........");

        String vObjCloseTransferSlip = TitanDashboardOR.getProperty("CloseTransferSlip");
        Assert.assertEquals("PASS", Constants.key.click(vObjCloseTransferSlip, ""));
        LogCapture.info("Verify user click on Close Transfer Slip.........");


    }

    @Then("^User verify Mode of payment as Wallet and Amount as \"([^\"]*)\"$")
    public void userVerifyModeOfPaymentAsWalletAndAmountAs(String Amt) throws Throwable {

        for (int i = 1; i <= 50; i++) {
            String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[7]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
            String PauymentMode = key.getText(VObjPauymentMode, "");

            String VObjAmount = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjAmount, ""));
            String TitanAmount = key.getText(VObjAmount, "");

            if (PauymentMode.equals("WALLET") && TitanAmount.equals(Amt)) {
                LogCapture.info("User verify ModeOfPayment As WALLET and Amount as " + Amt);
                break;
            }
        }
    }


    @And("^User is able verify value date under FX Activity tab on customer details Page$")
    public void userIsAbleVerifyValueDateUnderFXActivityTabOnCustomerDetailsPage() throws Exception {

        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter DateDDMMYYYY = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String ValueDateActivityTan = DateDDMMYYYY.format(now);

        for (int i = 1; i <= 50; i++) {
            String VObjFXInstruction = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[3]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjFXInstruction, ""));
            String ActInstructionNumber = Constants.driver.findElement(By.xpath(VObjFXInstruction)).getText();

            if (ActInstructionNumber.equals(InstructionNumber)) {

                String VObjValueDate = "(//tbody[@id='profileFxTicketBody']//tr[\"+i+\"]//td[2]//a)[" + i + "]";
                String ActTabValueDate = Constants.driver.findElement(By.xpath(VObjValueDate)).getText();
                String ValueDateActTab = ActTabValueDate.substring(0, 10);

                if (ValueDateActTab.equals(ValueDateActivityTan)) {
                    Assert.assertEquals(ValueDateActTab, ValueDateActivityTan);
                    LogCapture.info("User verify value date as todays date on FX Activity tab >> " + ValueDateActTab);
                } else if (!ValueDateActTab.equals(ValueDateActivityTan) && !ValueDateActTab.equals("")) {
                    Assert.assertNotEquals(ValueDateActTab, ValueDateActivityTan);
                    LogCapture.info("User verify value date is not todays date on FX Activity tab >> " + ValueDateActTab);
                }
                break;
            }
        }
    }

    @Then("^To Verify Transfer Reason for CDSA And E4F (FX|PaymentOut|OpenForward|PaymentIn) \"([^\"]*)\"$")
    public void verifyTransferReasonCDSAE4F(String Deal, String TransferReason) throws Throwable {
        if (Deal.equalsIgnoreCase("FX")||Deal.equalsIgnoreCase("PaymentIn")) {
            String vObjTransferReasonCDSAE4F = TitanFXTicketsOR.getProperty("TransferReasonCDSAE4F");
            String ActualMsg = Constants.driver.findElement(By.xpath(vObjTransferReasonCDSAE4F)).getText();
            Assert.assertEquals(ActualMsg, TransferReason);
            LogCapture.info("Validate Transfer Reason........." + ActualMsg + ":" + TransferReason);
        } else if (Deal.equalsIgnoreCase("PaymentOut") || Deal.equalsIgnoreCase("OpenForward")) {
            String vObjTransferReasonCDSAE4F = TitanFXTicketsOR.getProperty("TransferReasonCDSAE4F");
            String ActualMsg = Constants.driver.findElement(By.xpath(vObjTransferReasonCDSAE4F)).getText();
            Assert.assertNotEquals(ActualMsg, TransferReason);
            LogCapture.info("Validate Transfer Reason........." + ActualMsg + ":" + TransferReason);
        }
    }

    @Then("^User verify Swap flag is visible and then click on the same on Book deal page$")
    public void userVerifySwapFlagIsVisibleAndThenClickOnTheSameOnBookDealPage() throws Exception {

        String vObjSwapFlagHeaderTreasury = Constants.TitanTreasuryOR.getProperty("SwapFlagHeaderTreasury");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapFlagHeaderTreasury, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSwapFlagHeaderTreasury, "visible"));
        LogCapture.info("User able to see Swap Flag option on Book Treasury page....");

        String vObjSwapFlagTreasury = Constants.TitanTreasuryOR.getProperty("SwapFlagTreasury");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapFlagHeaderTreasury, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSwapFlagTreasury, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSwapFlagHeaderTreasury, "visible"));
        LogCapture.info("User select Swap Flag option on Book Treasury page....");
    }

    @Then("^User verify SwapFlag as Yes for newly added treasury deal having SellEnterAmount \"([^\"]*)\" BuyingAmount \"([^\"]*)\" Exchangerate \"([^\"]*)\"$")
    public void userVerifySwapFlagAsYesForNewlyAddedTreasuryDealHavingSellEnterAmountBuyingAmountExchangerate(String SellingAmount, String BuyingAmount, String ExRate) throws Throwable {

        for (int i = 1; i <= 50; i++) {
            String vObjSellAmount = "//tbody[@id='treasuryTicketTableBodyForDeal']//tr[" + i + "]//td[11]";
            Assert.assertEquals("PASS", key.VisibleConditionWait(vObjSellAmount, ""));
            String SellAmount = key.getText(vObjSellAmount, "");

            String vObjBuyAmount = "//tbody[@id='treasuryTicketTableBodyForDeal']//tr[" + i + "]//td[13]";
            Assert.assertEquals("PASS", key.VisibleConditionWait(vObjBuyAmount, ""));
            String BuyAmount = key.getText(vObjBuyAmount, "");

            String vObjExchangerate = "//tbody[@id='treasuryTicketTableBodyForDeal']//tr[" + i + "]//td[9]";
            Assert.assertEquals("PASS", key.VisibleConditionWait(vObjExchangerate, ""));
            String ExChangeRate = key.getText(vObjExchangerate, "");

            String vObjSwapFlag = "//tbody[@id='treasuryTicketTableBodyForDeal']//tr[" + i + "]//td[18]";
            Assert.assertEquals("PASS", key.VisibleConditionWait(vObjSwapFlag, ""));
            String SwapFlag = key.getText(vObjSwapFlag, "");

            if (SellingAmount.equals(SellAmount) && ExRate.equals(ExChangeRate) && BuyingAmount.equals(BuyAmount)) {
                if (SwapFlag.equals("YES")) {
                    LogCapture.info("User verify Swap Flag as [" + SwapFlag + "] on Deal report page.... ");
                } else if (SwapFlag.equals("NO")) {
                    LogCapture.info("User verify Swap flag as [" + SwapFlag + "] on Deal report page...");
                } else {
                    LogCapture.info("Test Case failed unable to validate Swap Flag on Deal report page << " + SwapFlag + "] >>>...");
                    Assert.fail();
                }
                break;
            }
        }
    }

    @And("^User is able verify Swap Flag under FX Activity tab on customer details Page$")
    public void userIsAbleVerifySwapFlagUnderFXActivityTabOnCustomerDetailsPage() throws Exception {

        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 50; i++) {
            String VObjFXInstruction = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[3]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjFXInstruction, ""));
            String ActInstructionNumber = Constants.driver.findElement(By.xpath(VObjFXInstruction)).getText();

            if (ActInstructionNumber.equals(InstructionNumber)) {

                String VObjSwapFlag = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[5]//a)";
                String ActSwapFlagValue = Constants.driver.findElement(By.xpath(VObjSwapFlag)).getText();
                if (ActSwapFlagValue.equals("YES")) {
                    LogCapture.info("User verify Swap flag as [" + ActSwapFlagValue + "] on FX page...");
                } else if (ActSwapFlagValue.equals("NO")) {
                    LogCapture.info("User verify Swap flag as [" + ActSwapFlagValue + "] on FX page...");
                } else {
                    LogCapture.info("Test Case failed unable to validate Swap Flag on FX page << " + ActSwapFlagValue + "] >>>...");
                    Assert.fail();
                }
                break;
            }
        }
    }

    @And("^User is able verify Swap Flag under Limit Order Activity tab on customer details Page$")
    public void userIsAbleVerifySwapFlagUnderLimitOrderActivityTabOnCustomerDetailsPage() throws Exception {

        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjCustomerLimitOrderActivityTab = TitanCustomersOR.getProperty("CustomerLimitOrderActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerLimitOrderActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerLimitOrderActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on Limit Order Activity Tab...");

        for (int i = 1; i <= 10; i++) {
            String VObjLimitOrderInstruction = "(//tbody[@id='limitOrderBody']//tr[" + i + "]//td[2]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjLimitOrderInstruction, ""));
            String ActInstructionNumber = Constants.driver.findElement(By.xpath(VObjLimitOrderInstruction)).getText();

            if (ActInstructionNumber.equals(InstructionNumber)) {

                String VObjSwapFlag = "(//tbody[@id='limitOrderBody']//tr[" + i + "]//td[14]//a)";
                String ActSwapFlagValue = Constants.driver.findElement(By.xpath(VObjSwapFlag)).getText();
                if (ActSwapFlagValue.equals("YES")) {
                    LogCapture.info("User verify Swap flag as [" + ActSwapFlagValue + "] on Limit order FX activity page...");

                } else if (ActSwapFlagValue.equals("NO")) {
                    LogCapture.info("User verify Swap flag as [" + ActSwapFlagValue + "] on Limit order FX activity page...");
                } else {
                    LogCapture.info("Test Case failed unable to validate Swap Flag on Limit order FX activity page << " + ActSwapFlagValue + "] >>>...");
                    Assert.fail();
                }
                break;
            }
        }
    }

    @And("^User is on clicks on newly created FX ticket from the list$")
    public void userIsOnClicksOnNewlyCreatedFXTicketFromTheList() throws Exception {

        for (int i = 1; i <= 50; i++) {
            String VObjFXQueInstructionNo = "//*[@id='fxTicketQueueTableBody']/tr[" + i + "]/td[7]/a";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjFXQueInstructionNo, ""));
            String ActInstructionNumber = Constants.driver.findElement(By.xpath(VObjFXQueInstructionNo)).getText();
            if (ActInstructionNumber.equals(InstructionNumber)) {
                Assert.assertEquals("PASS", Constants.key.click(VObjFXQueInstructionNo, ""));
                Assert.assertEquals("PASS", Constants.key.pause("1", ""));
                LogCapture.info("User Click on newly created Instruction number " + ActInstructionNumber + "...");
                break;
            }
        }
    }


    @And("^User is able verify Swap Flag under FX Activity tab on customer details Page for Current Amend and Reverse Amend$")
    public void userIsAbleVerifySwapFlagUnderFXActivityTabOnCustomerDetailsPageForCurrentAmendAndReverseAmend() throws Exception {

        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 5; i++) {
            String VObjAmendStatus = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[15]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjAmendStatus, ""));
            String ActAmendStatus = Constants.driver.findElement(By.xpath(VObjAmendStatus)).getText();

            String VObjFXStatus = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[12]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjFXStatus, ""));
            String ActFXStatus = Constants.driver.findElement(By.xpath(VObjFXStatus)).getText();

            if (ActAmendStatus.equals("CA") && ActFXStatus.equals("OPEN")) {
                String VObjSwapFlag = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[5]//a)";
                String ActSwapFlagValue = Constants.driver.findElement(By.xpath(VObjSwapFlag)).getText();
                if (ActSwapFlagValue.equals("YES")) {
                    LogCapture.info("User verify Swap flag as [" + ActSwapFlagValue + "] for Current Amend [ " + ActAmendStatus + " ] on FX activity page...");
                } else if (ActSwapFlagValue.equals("NO")) {
                    LogCapture.info("User verify Swap flag as [" + ActSwapFlagValue + "] for Current Amend [ " + ActAmendStatus + " ] on FX activity page...");
                } else {
                    LogCapture.info("Test Case failed unable to validate Swap Flag for Current Amend [ " + ActAmendStatus + " ]<< " + ActSwapFlagValue + "] >>>...");
                    Assert.fail();
                }
                break;
            }
        }
        for (int i = 1; i <= 5; i++) {
            String VObjAmendStatus = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[15]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjAmendStatus, ""));
            String ActAmendStatus = Constants.driver.findElement(By.xpath(VObjAmendStatus)).getText();

            String VObjFXStatus = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[12]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjFXStatus, ""));
            String ActFXStatus = Constants.driver.findElement(By.xpath(VObjFXStatus)).getText();

            if (ActAmendStatus.equals("RA") && ActFXStatus.equals("CLOSED")) {
                String VObjSwapFlag = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[5]//a)";
                String ActSwapFlagValue = Constants.driver.findElement(By.xpath(VObjSwapFlag)).getText();
                if (ActSwapFlagValue.equals("YES")) {
                    LogCapture.info("User verify Swap flag as [" + ActSwapFlagValue + "] for Reverse Amend [ " + ActAmendStatus + " ] on FX activity page...");
                } else if (ActSwapFlagValue.equals("NO")) {
                    LogCapture.info("User verify Swap flag as [" + ActSwapFlagValue + "] for Reverse Amend [ " + ActAmendStatus + " ] on FX activity page...");
                } else {
                    LogCapture.info("Test Case failed unable to validate Swap Flag for Reverse Amend [ " + ActAmendStatus + " ] << " + ActSwapFlagValue + "] >>>...");
                    Assert.fail();
                }
                break;
            }
        }
    }

    @When("^Change the \"([^\"]*)\" file name for \"([^\"]*)\"\"([^\"]*)\"$")
    public void changeTheFileNameFor(String FileType, String Bank, String AccountNumber) throws Exception {
        Constants.Bank = Bank;
        Constants.FileType = FileType;
        File Rename = Constants.key.RenameCAMTFile(FileType, Bank, AccountNumber);
        String newFileName = Rename.getName();
        Constants.NewFileName = newFileName;
        LogCapture.info(Rename.getName());
    }
/*

    @When("^Update \"([^\"]*)\" xml file for \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void updateXmlFileFor(String FileType, String Bank, String AccountNumber, String CdtDbtInd) throws ParserConfigurationException, IOException, SAXException, TransformerException, InterruptedException {

        File NewCamtFile = new File("Files/" + Bank + "/" + NewFileName);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  // Using XML classes to modify file content
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(NewCamtFile);
        Constants.doc1 = doc;
        LogCapture.info(" Selected Document/File for updates is " + NewFileName);
//        DateTimeFormatter dtf=DateTimeFormatter.ISO_LOCAL_DATE;
//        DateTimeFormatter dtf1=DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        String RandomNumber = RandomStringUtils.randomNumeric(3);
        InAmount = Double.parseDouble(RandomNumber);
        LogCapture.info("New Trade Amount : " + InAmount);

         // if you want to change AddtlNtryInf for single transaction then use below commented lines
        // Specific AddtlNtryInf need to change at config AddtlNtryInf
        String AddtlNtryInf = Constants.CONFIG.getProperty("AddtlNtryInf");
        Constants.key.updateXmlFile("AddtlNtryInf", AddtlNtryInf);

        Constants.key.updateXmlFile("CdtDbtInd", CdtDbtInd);
        Constants.key.updateXmlFile("CreDtTm", String.valueOf(now));  //Updating tag (CretTm) of xml files using new value
        Constants.key.updateXmlFile("DtTm", String.valueOf(now));
        Constants.key.updateXmlParentChild("Othr", "Id", AccountNumber);
        if (FileType.equalsIgnoreCase("camt.053.")) {
            Constants.key.updateXmlParentChild("Dt", "Dt", currentDate);
            Constants.key.updateXmlParentChild("BookgDt", "Dt", currentDate);
            Constants.key.updateXmlParentChild("ValDt", "Dt", currentDate);
        } else {
            Constants.key.updateXmlFile("Dt", currentDate);
        }

        double sum = 0;
        double lastAmount = 0;                           //lastAmount = Amount used in last transaction

        if (FileType.equalsIgnoreCase("camt.05.2.")) {
            NodeList nodeList = doc.getElementsByTagName("Amt");
            LogCapture.info("Number of Amt fields are " + nodeList.getLength());
            for (int j = 0; j < nodeList.getLength(); j++) {
                Node node = nodeList.item(j);
                node.setTextContent(String.valueOf(InAmount));
                LogCapture.info("Value ot Amt(" + j + ") is " + InAmount);
                sum = sum + InAmount;
                InAmount = InAmount + 1.00;

            }
            lastAmount = InAmount - 1;
        } else if (FileType.equalsIgnoreCase("camt.052ROF.")) {
            NodeList nodeList = doc.getElementsByTagName("Amt");
            LogCapture.info("Number of Amt fields are " + nodeList.getLength());
            for (int j = 0; j < nodeList.getLength(); j++) {
                Node node = nodeList.item(j);
                node.setTextContent(String.valueOf(InAmount));
                LogCapture.info("Value ot Amt(" + j + ") is " + InAmount);
                sum = sum + InAmount;
                InAmount = InAmount + 1.00;

            }
            lastAmount = InAmount - 1;
        } else {
            LogCapture.info("payment in amount is " + PaymentInAmount);
            if (PaymentInAmount == null) {
                Constants.key.updateXmlFile("Amt", String.valueOf(InAmount));
            } else {
                InAmount = Double.parseDouble(PaymentInAmount);
                Constants.key.updateXmlFile("Amt", String.valueOf(InAmount));
            }

            lastAmount = InAmount;
        }

        Constants.key.updateXmlFile("Sum", String.valueOf(sum));


        LogCapture.info("Required Tags are modified for file: " + NewFileName);

        TransformerFactory transformerFactory = TransformerFactory.newInstance(); //Updated information send to local NewCamtFile
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc1);
        StreamResult result = new StreamResult(NewCamtFile);
        transformer.transform(source, result);
        LogCapture.info(" Updates are saved in document/file: " + NewFileName);

        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        Constants.PaymentInAmount = decimalFormat.format((lastAmount));
        LogCapture.info("value of Payment In Amount at last transaction is: " + PaymentInAmount);
    }
*/

   /* @When("^For a \"([^\"]*)\" call user push file from local to S3 bucket and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment\"([^\"]*)\"$")
    public void forACallUserPushFileFromLocalToSBucketAndCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID1, String Environment, String Bank) throws Throwable {
        LogCapture.info("---------------POST call started----------------");
        DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime today = LocalDateTime.now();
        String nameDate = date.format(today);
        Constants.TCCaseID = testCaseID1;
        Constants.SHEET_NAME = Environment;

        String filePath = "Files/" + Bank + "/" + NewFileName;
        String destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/camt/" + nameDate + "/" + NewFileName;
//        key.pause("2", "");
        Constants.RESPONSE = ServiceMethod.postAdvanceFileUploadToS3Bucket(testCaseID1, statCode, Constants.DynamicValue, filePath, destinationPath);
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        LogCapture.info(jp + "---------------POST call ended----------------");
    }*/

    @When("^For a \"([^\"]*)\" call user generates messageIn and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void forACallUserGeneratesMessageInAndCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String Environment, String Bank, String msg_type, String msg_ID, String queue_Name, String message_No) throws Throwable {
        key.pause("7", "");
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime today = LocalDateTime.now();
        String nameDate = date.format(today);
        String destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/camt/" + nameDate + "/" + NewFileName;
        DynamicValue.put("<destinationPath>", destinationPath);
        DynamicValue.put("<msg_type>", msg_type);
        DynamicValue.put("<msg_ID>", msg_ID);
        DynamicValue.put("<queue_Name>", queue_Name);
        DynamicValue.put("<message_No>", message_No);

        LogCapture.info("---------------POST call started----------------");
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        LogCapture.info(jp + "---------------POST call ended----------------");
        Assert.assertFalse(RESPONSE.contains("null"));
        String external_reference_id = RESPONSE.split(":")[3].split("}")[0];
        LogCapture.info("MessageInId =" + external_reference_id);
//        Constants.MessageInId = external_reference_id;
        MessageInIdMap.put("MessageInId for "+message_No,external_reference_id);
    }

    @When("^User modifies \"([^\"]*)\" timing for 14 sec and reschedule timing to 60 sec for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userModifiesSchedulerTimingForSecAndRescheduleTimingToSecForOn(String scheduler, String testCaseID, String Environment) throws Throwable {
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<scheduler>", scheduler);
        try {
            DynamicValue.put("<CronExpression>", "0/10 * * 1/1 * ? *");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, "200", Constants.DynamicValue);
            LogCapture.info(" Scheduler is modified to trigger after 10 sec");
            LogCapture.info(" Scheduler is awaiting for 14 sec for parsing files");
            key.pause("14", "");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            DynamicValue.put("<CronExpression>", "0 0/1 * 1/1 * ? *");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, "200", Constants.DynamicValue);
            LogCapture.info(" Scheduler is modified to trigger after 60 sec");
        }
    }
    @And("^Do \"([^\"]*)\" DB verification and get StatementLineID$")
    public void doDBVerificationAndGetStatementLineID(String Environment) throws Exception {
        String MessageInId=MessageInIdMap.get("MessageInId for 53");
        if (MessageInId==null){
            Object firstKey = MessageInIdMap.keySet().toArray()[0];
            MessageInId = MessageInIdMap.get(firstKey);
        }
        String StatementLine = Constants.key.VerifyDBDetails(Environment, MessageInId, "Find the StatementLineID");
        Constants.StatementLineID = StatementLine;
        LogCapture.info("StatementLineID : " + StatementLineID);
    }

    @And("^User gets MSL_ID from \"([^\"]*)\" DB$")
    public void userGetsMSL_IDFromDB(String Environment) throws Exception {
        String MSL = Constants.key.VerifyDBDetails(Environment, StatementLineID, "Find the MSL_ID");
        Constants.EODMSL_ID = MSL;
        LogCapture.info("MSL_ID : " + EODMSL_ID);
    }
    @Then("^User verify if the Method is (BACS/CHAPS/TT|WalletFx|WalletForward|WalletPaymentOut) and Status is on (Hold|)$")
    public void userVerifyIfTheMethodIsBACSCHAPSTTAndAtlasStatusIsOnHold(String MethodType, String Status) throws Exception {
if(MethodType.equalsIgnoreCase("BACS/CHAPS/TT")||MethodType.equalsIgnoreCase("WalletFx")) {
    LogCapture.info("User verify Auto Auto Allocation under Payment In tab");
    for (int i = 1; i <= 50; i++) {
        String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[7]//a";
        Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
        String PauymentMode = key.getText(VObjPauymentMode, "");

        String vObjAmount = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[5]//a";
        Assert.assertEquals("PASS", key.VisibleConditionWait(vObjAmount, ""));
        String ActualAmount = key.getText(vObjAmount, "");
        double Act1 = Double.parseDouble(ActualAmount);
        int ActualAmount1 = (int) Act1;
        int ExpectedAmount1 = (int) InAmount;

        if (MethodType.equals("BACS/CHAPS/TT") || MethodType.equals("WalletFx") && Status.equals("Hold")) {
            if (ActualAmount1 == ExpectedAmount1) {
                LogCapture.info("Payment in is allocated automatically::" + ActualAmount1 + ":" + ExpectedAmount1);
                Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                key.pause("2", "");
                break;
            }
        }
        LogCapture.info("Payment in is not allocated automatically::" + ActualAmount1 + ":" + ExpectedAmount1);
        Assert.fail();
    }
}else if(MethodType.equalsIgnoreCase("WalletForward")||MethodType.equalsIgnoreCase("WalletPaymentOut")){
    LogCapture.info("User verify Auto Auto Allocation under Payment In tab");
    for (int i = 1; i <= 50; i++) {
        String VObjPauymentMode = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[7]//a";
        Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPauymentMode, ""));
        String PauymentMode = key.getText(VObjPauymentMode, "");

        String vObjAmount = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[5]//a";
        Assert.assertEquals("PASS", key.VisibleConditionWait(vObjAmount, ""));
        String ActualAmount = key.getText(vObjAmount, "");
        double Act1 = Double.parseDouble(ActualAmount);
        int ActualAmount1 = (int) Act1;
        int ExpectedAmount1 = (int) InAmount;

        if (MethodType.equals("WalletForward") || MethodType.equals("WalletPaymentOut") && Status.equals("Hold")) {
            if (ActualAmount1 != ExpectedAmount1) {
                LogCapture.info("Payment in is not allocated automatically::" + ActualAmount1 + ":" + ExpectedAmount1);
                //Assert.assertEquals("PASS", key.navigateSubMenu(VObjPauymentMode, ""));
                key.pause("2", "");
                break;
            }
        }
        LogCapture.info("Payment in is allocated automatically::" + ActualAmount1 + ":" + ExpectedAmount1);
        Assert.fail();
    }

}

    }

    @And("^Select the bank for CDSA$")
    public void selectTheBank() throws Throwable {
        Constants.key.pause("2", "");
        String vObjSelectbank = TitanCDSAPhase1OR.getProperty("SelectCDSABank");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectbank, ""));
        Constants.key.pause("2", "");

        String vObjSelectbank1 = TitanCDSAPhase1OR.getProperty("SelectCDSABank1");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectbank1, ""));

//        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSelectbank, "downArrow"));
//        Assert.assertEquals("PASS", Constants.key.click(vObjSelectbank, ""));
        LogCapture.info("Select Bank is selected..");
        Constants.key.pause("1", "");
    }
    @And("^User clicks on Submit button for Payment In$")
    public void userClicksOnSubButtonForPaymentIn() throws Throwable {
        String vObjSubBtn = Constants.TitanPaymentInOR.getProperty("SubmitBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSubBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSubBtn, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User clicks on Submit button...");
        Constants.key.pause("3", "");
        String vObjcloBtn = Constants.TitanPaymentInOR.getProperty("ClosePaymentInSlipBtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjcloBtn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjcloBtn, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User clicks on close button...");


    }

    @And("^User enters Payee details PayeeType\"([^\"]*)\" FirstName\"([^\"]*)\" LastName\"([^\"]*)\" CompanyName\"([^\"]*)\" NickName \"([^\"]*)\" PhoneNumber \"([^\"]*)\" Email \"([^\"]*)\" CurrencyReceive\"([^\"]*)\" Country\"([^\"]*)\" Address\"([^\"]*)\" Town\"([^\"]*)\" Postcode\"([^\"]*)\" and then click on next button$")
    public void userEntersPayeeDetailsPayeeTypeFirstNameLastNameCompanyNameNickNamePhoneNumberEmailCurrencyReceiveCountryAddressTownPostcodeAndThenClickOnNextButton(String PayeeType, String FirstName, String LastName, String CompanyName, String NickName, String PhoneNumber, String EmailAddress, String CurrencyReceive, String Country, String Address, String Town, String Postcode) throws Throwable {

        String vObjPayeeDetailPage = Constants.TitanPayeeOR.getProperty("PayeeDetailPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeDetailPage, ""));
        LogCapture.info("1 of 3: Payee details page is visible..");

        if (PayeeType.equalsIgnoreCase("Individual")) {
            String vObjDefaultIndividualPayeeType = Constants.TitanPayeeOR.getProperty("DefaultIndividualPayeeType");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDefaultIndividualPayeeType, "selected"));
            LogCapture.info("By Default Individual Payee type is selected..");

            PayeeFirstName = FirstName + RandomStringUtils.randomAlphabetic(5);
            String vObjFirstName = Constants.TitanPayeeOR.getProperty("FirstName");
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFirstName, PayeeFirstName));
            LogCapture.info("First name entered is: " + PayeeFirstName);

            PayeeLastName = LastName + RandomStringUtils.randomAlphabetic(5);
            String vObjLastName = Constants.TitanPayeeOR.getProperty("LastName");
            Assert.assertEquals("PASS", Constants.key.click(vObjLastName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjLastName, PayeeLastName));
            LogCapture.info("Last name entered is: " + PayeeLastName);
        }
        if (PayeeType.equalsIgnoreCase("Company")) {
            String vObjCompanyPayeeType = Constants.TitanPayeeOR.getProperty("CompanyPayeeType");
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyPayeeType, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCompanyPayeeType, "selected"));
            LogCapture.info("Company Payee type is selected..");

            String vObjCompanyName = Constants.TitanPayeeOR.getProperty("CompanyName");
            PayeeCompanyName = CompanyName;
            Assert.assertEquals("PASS", Constants.key.click(vObjCompanyName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCompanyName, PayeeCompanyName));
            LogCapture.info("Company name entered is: " + PayeeCompanyName);
        }

        PayeeNickName = NickName + RandomStringUtils.randomAlphabetic(5);
        String vObjPayeenickName = Constants.TitanPayeeOR.getProperty("PayeenickName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeenickName, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeenickName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeenickName, PayeeNickName));
        LogCapture.info("Payee Nick name entered is : " + PayeeNickName);

        String vObjPayeeCountryCode = Constants.TitanPayeeOR.getProperty("PayeeCountryCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeCountryCode, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeCountryCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeCountryCode, "+91"));
        LogCapture.info("Payee country code entered is : +91 ");

        String vObjPayeePhoneNumber = Constants.TitanPayeeOR.getProperty("PayeePhoneNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeePhoneNumber, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeePhoneNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeePhoneNumber, PhoneNumber));
        LogCapture.info("Payee Phone number entered is : " + PhoneNumber);

        String vObjPayeeEmail = Constants.TitanPayeeOR.getProperty("PayeeEmail");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeEmail, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeEmail, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeEmail, EmailAddress));
        LogCapture.info("Payee Email address entered is : " + EmailAddress);


        String vObjCurrencyReceiveDownArrow = Constants.TitanPayeeOR.getProperty("CurrencyReceiveDownArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrencyReceiveDownArrow, ""));
        Constants.key.pause("2", "");
        String vObjCurrencyReceiveSearch = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencyReceiveSearch, CurrencyReceive));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vCurrencyReceiveSearch_FireFox = Constants.TitanPayeeOR.getProperty("CurrencyReceiveSearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vCurrencyReceiveSearch_FireFox, ""));
        } else {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencyReceiveSearch, "enter"));
            LogCapture.info("Currency to receive: " + CurrencyReceive + " is selected..");
        }

        String vObjCountrytDropArrow = Constants.TitanPayeeOR.getProperty("CountrytDropArrow");
        Assert.assertEquals("PASS", Constants.key.click(vObjCountrytDropArrow, ""));
        Constants.key.pause("2", "");
        String vObjCountrySearch = Constants.TitanPayeeOR.getProperty("CountrySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCountrySearch, Country));
        Constants.key.pause("2", "");
        if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
            String vCountrySearch_FireFox = Constants.TitanPayeeOR.getProperty("CountrySearch_FireFox");
            Assert.assertEquals("PASS", Constants.key.click(vCountrySearch_FireFox, ""));
        } else {
            if(Country.equalsIgnoreCase("UK"))
            {
                String vObjUKGBPCountry = Constants.TitanPayeeOR.getProperty("UKGBPCountry");
                Assert.assertEquals("PASS", Constants.key.click(vObjUKGBPCountry, ""));

            }else
            {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCountrySearch, "enter"));
            }
        }
        LogCapture.info("Country selected is: " + Country);

        Constants.key.pause("2", "");
        String vObjAddressPostCodeField = Constants.TitanPayeeOR.getProperty("AddressPostCodeField");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjAddressPostCodeField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAddressPostCodeField, Postcode));
        LogCapture.info("Payee Post code entered is : " + Postcode);

        String vObjPayeeAddressField = Constants.TitanPayeeOR.getProperty("PayeeAddressField");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeAddressField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeAddressField, Address));
        LogCapture.info("Payee Address entered is : " + Address);

        String vObjPayeeTownField = Constants.TitanPayeeOR.getProperty("PayeeTownField");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeTownField, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayeeTownField, Town));
        LogCapture.info("Payee Town entered is : " + Town);

        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayeeTownField, "tab"));
        String vObjPayeeDetailsNextBtn = Constants.TitanPayeeOR.getProperty("PayeeDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeeDetailsNextBtn, ""));
        LogCapture.info("Clicking on Next button....");

    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" BankCodeType\"([^\"]*)\" BankCode\"([^\"]*)\" FFCDetail \"([^\"]*)\" NameInLocalLang \"([^\"]*)\" SwiftCode \"([^\"]*)\" PurposeCode \"([^\"]*)\" and click on get bank details$")
    public void userEntersPayeeBankDetailsAccountNumberBankCodeTypeBankCodeFFCDetailNameInLocalLangSwiftCodePurposeCodeAndClickOnGetBankDetails(String AccountNumber, String BankCodeType, String BankCode, String FFCDetail, String NameInLocalLanguage, String SwiftCode, String PurposeCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        if (AccountNumber.contains("ES") || AccountNumber.contains("DE")|| AccountNumber.contains("SE")) {
            LogCapture.info("Account number NOT required but IBAN number for EUR required..");
            String vObjIBANNumber = Constants.TitanPayeeOR.getProperty("IBANNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjIBANNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIBANNumber, AccountNumber));
            LogCapture.info("IBAN number entered is : "+AccountNumber);

        } else {
            String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
            LogCapture.info("Payee Account number entered is : "+AccountNumber);
        }
        if (BankCodeType.equalsIgnoreCase("ABA")) {
            String vObjABANumber = Constants.TitanPayeeOR.getProperty("ABANumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjABANumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjABANumber, "011103093"));
            LogCapture.info("Payee ABA number entered is : 011103093");

            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number entered is : "+BankCode);
        }
        if (BankCodeType.equalsIgnoreCase("SWIFT")) {
            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number entered is : "+BankCode);
        }
        if (BankCodeType.equalsIgnoreCase("SORT")) {
            String vObjSortCode = Constants.TitanPayeeOR.getProperty("SortCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSortCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSortCode, BankCode));
            LogCapture.info("SORT code entered is : "+BankCode);
        }
        if (BankCodeType.equalsIgnoreCase("CNAPS")) {
            String vObjCNAPS = Constants.TitanPayeeOR.getProperty("CNAPCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjCNAPS, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCNAPS, "50122200000017"));

            String vObjPurposeCode = Constants.TitanPayeeOR.getProperty("PurposeCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjPurposeCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeCode, PurposeCode));
            LogCapture.info("Purpose code entered is : "+PurposeCode);

            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number entered is : "+BankCode);
        }
        if (BankCodeType.equalsIgnoreCase("Transit")) {
            String vObjBSBNumber = Constants.TitanPayeeOR.getProperty("PayeeTransitNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjBSBNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBSBNumber, "001610129"));
            LogCapture.info("SORT code entered is : 001610129");

            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number entered is : "+BankCode);
        }

        String vObjFFCDetails = Constants.TitanPayeeOR.getProperty("FFCDetails");
        Assert.assertEquals("PASS", Constants.key.click(vObjFFCDetails, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFFCDetails, FFCDetail));
        LogCapture.info("FFC Detail entered is : "+FFCDetail);

        String vObjNameinLocalLanguage = Constants.TitanPayeeOR.getProperty("NameinLocalLanguage");
        Assert.assertEquals("PASS", Constants.key.click(vObjNameinLocalLanguage, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameinLocalLanguage, NameInLocalLanguage));
        LogCapture.info("Name in Local Language entered is : "+NameInLocalLanguage);

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");

    }


    @Then("^User navigate to Payee section under Activity tab on customer details page and click on view payee option$")
    public void userNavigateToPayeeSectionUnderActivityTabOnCustomerDetailsPageAndClickOnViewPayeeOption() throws Exception {

        String vObjPayeeSectionActivity = Constants.TitanPayeeOR.getProperty("PayeeSectionActivity");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeSectionActivity, ""));
        LogCapture.info("User navigate to Payee section under customer details page..");

        for(int i = 1; i <=10 ; i++) {
            String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
            String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();
            String ExpPayeeFullname = PayeeFirstName + " " + PayeeLastName;
            String ExpCompanyName = PayeeCompanyName;
            if (ActPayeeFullname.equals(ExpPayeeFullname) || ActPayeeFullname.equals(ExpCompanyName)) {
                String VObjViewPayeeOption = "//tbody[@id='profilePayeeBody']//tr["+i+"]//td[14]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjViewPayeeOption, ""));
                Assert.assertEquals("PASS", Constants.key.click(VObjViewPayeeOption, ""));
                Constants.key.pause("6", "");
                break;
            }
        }
    }

    @Then("^User select Intermediary bank as Yes and enter IntermediaryBankCountry \"([^\"]*)\" IntermediarySortCode \"([^\"]*)\" IntermediarySwiftCode \"([^\"]*)\" IntermediaryFFCDetail \"([^\"]*)\" then click on get bank details and then click on Next button$")
    public void userSelectIntermediaryBankAsYesAndEnterIntermediaryBankCountryIntermediarySortCodeIntermediarySwiftCodeIntermediaryFFCDetailThenClickOnGetBankDetailsAndThenClickOnNextButton(String IntermediaryBankCountry, String IntermediarySortCode, String IntermediarySwiftCode, String IntermediaryFFCDetail) throws Throwable {

        String vObjInterbankYesButton = Constants.TitanPayeeOR.getProperty("InterbankYesButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInterbankYesButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjInterbankYesButton, ""));
        LogCapture.info("User click on Intermediary Bank [YES] button.... ");

        String vObjInterBankCountry = Constants.TitanPayeeOR.getProperty("InterBankCountry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInterBankCountry, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjInterBankCountry, ""));
        LogCapture.info("User click on Intermediary Bank country button.... ");

        String vObjInterBankCountrySearchBar = Constants.TitanPayeeOR.getProperty("InterBankCountrySearchBar");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInterBankCountrySearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjInterBankCountrySearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInterBankCountrySearchBar, IntermediaryBankCountry));
        Constants.key.pause("4", "");

        if(IntermediaryBankCountry.equalsIgnoreCase("UK"))
        {
            String vObjInterBankCountryGBR = Constants.TitanPayeeOR.getProperty("InterBankCountryGBR");
            Assert.assertEquals("PASS", Constants.key.click(vObjInterBankCountryGBR, ""));
        }else
        {
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInterBankCountrySearchBar, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInterBankCountrySearchBar, "enter"));
        }
        LogCapture.info("Intermediary Bank Country selected is: " + IntermediaryBankCountry);

//        String vObjInterbankSortCode = Constants.TitanPayeeOR.getProperty("InterbankSortCode");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInterbankSortCode, ""));
//        Assert.assertEquals("PASS", Constants.key.click(vObjInterbankSortCode, ""));
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInterbankSortCode, IntermediarySortCode));
//        LogCapture.info("Intermediary Bank's Sort Code Entered is: " + IntermediarySortCode);

        String vObjinterBankSwiftCode = Constants.TitanPayeeOR.getProperty("interBankSwiftCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjinterBankSwiftCode, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjinterBankSwiftCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjinterBankSwiftCode, IntermediarySwiftCode));
        LogCapture.info("Intermediary Bank's Swift Code Entered is: " + IntermediarySwiftCode);

        String vObjInterBankFFCDetails = Constants.TitanPayeeOR.getProperty("InterBankFFCDetails");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInterBankFFCDetails, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjInterBankFFCDetails, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInterBankFFCDetails, IntermediaryFFCDetail));
        LogCapture.info("Intermediary Bank's FFC detail Entered is: " + IntermediaryFFCDetail);

        String vObjInterBankGetDetails = Constants.TitanPayeeOR.getProperty("InterBankGetDetails");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInterBankGetDetails, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjInterBankGetDetails, ""));
        LogCapture.info("User click on Get Intermediatery Bank details... ");
        Constants.key.pause("4", "");

        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("User clicked on Next button..");

    }

    @And("^User veriy payee details as PayeeType \"([^\"]*)\" FirstName LastName CurrencyToRecieve \"([^\"]*)\" Country \"([^\"]*)\" Address \"([^\"]*)\" Town \"([^\"]*)\" Postcode \"([^\"]*)\" PhoneNumber \"([^\"]*)\" EmailAddress \"([^\"]*)\" on View payee page$")
    public void userVeriyPayeeDetailsAsPayeeTypeFirstNameLastNameCurrencyToRecieveCountryAddressTownPostcodePhoneNumberEmailAddressOnViewPayeePage(String PayeeType, String CurrencyReceive, String Country, String Address, String Town, String Postcode, String PhoneNumber, String EmailAddress) throws Throwable {

        String vObjViewPayeeDetailsHeader = Constants.TitanPayeeOR.getProperty("ViewPayeeDetailsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeeDetailsHeader, ""));
        String ViewPayeeDetailsHeader = Constants.driver.findElement(By.xpath(vObjViewPayeeDetailsHeader)).getText();
        if(ViewPayeeDetailsHeader.contains("Payee details"))
        {
            LogCapture.info("User is on View Payee details page.."+ ViewPayeeDetailsHeader);
        }else
        {
            LogCapture.info("User is unable to View Payee details page..");
            Assert.fail();
        }

        String vObjViewPayeeType = Constants.TitanPayeeOR.getProperty("ViewPayeeType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeeType, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeeType, "Payee Type"));
        LogCapture.info("User verify Payee Type Header is visible on View Payee details page..");

        String vObjViewPayeeTypeValue = Constants.TitanPayeeOR.getProperty("ViewPayeeTypeValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeeTypeValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeeTypeValue, PayeeType));
        LogCapture.info("User verify Payee Type ["+PayeeType+"] is visible on View Payee details page..");

        String vObjViewFirstName = Constants.TitanPayeeOR.getProperty("ViewFirstName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewFirstName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewFirstName, "First name"));
        LogCapture.info("User verify Payee First Name Header is visible on View Payee details page..");

        String vObjViewFirstNameValue = Constants.TitanPayeeOR.getProperty("ViewFirstNameValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewFirstNameValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewFirstNameValue, PayeeFirstName));
        LogCapture.info("User verify Payee First Name ["+PayeeFirstName+"] is visible on View Payee details page..");

        String vObjViewLastName = Constants.TitanPayeeOR.getProperty("ViewLastName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewLastName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewLastName, "Last name"));
        LogCapture.info("User verify Payee Last Name Header is visible on View Payee details page..");

        String vObjViewLastNameValue = Constants.TitanPayeeOR.getProperty("ViewLastNameValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewLastNameValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewLastNameValue, PayeeLastName));
        LogCapture.info("User verify Payee First Name ["+PayeeLastName+"] is visible on View Payee details page..");

        String vObjViewPayeeStatus = Constants.TitanPayeeOR.getProperty("ViewPayeeStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeeStatus, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeeStatus, "Payee status"));
        LogCapture.info("User verify Payee Status Header is visible on View Payee details page..");

        String vObjViewPayeeStatusValue = Constants.TitanPayeeOR.getProperty("ViewPayeeStatusValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeeStatusValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeeStatusValue, "ACTIVE"));
        LogCapture.info("User verify Payee Status [ACTIVE] is visible on View Payee details page..");

        String vObjViewPayeeNickName = Constants.TitanPayeeOR.getProperty("ViewPayeeNickName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeeNickName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeeNickName, "Nick name"));
        LogCapture.info("User verify Payee Nick name Header is visible on View Payee details page..");

        String vObjViewPayeeNickNameValue = Constants.TitanPayeeOR.getProperty("ViewPayeeNickNameValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeeNickNameValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeeNickNameValue, PayeeNickName));
        LogCapture.info("User verify Payee Nick Name ["+PayeeNickName+"] is visible on View Payee details page..");

        String vObjViewPayeePriority = Constants.TitanPayeeOR.getProperty("ViewPayeePriority");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeePriority, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeePriority, "Priority payment"));
        LogCapture.info("User verify Payee Priority payment Header is visible on View Payee details page..");

        String vObjViewPayeePhoneNo = Constants.TitanPayeeOR.getProperty("ViewPayeePhoneNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeePhoneNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeePhoneNo, "Phone no"));
        LogCapture.info("User verify Payee Phone Number Header is visible on View Payee details page..");

        String vObjViewPayeePhoneNoValue = Constants.TitanPayeeOR.getProperty("ViewPayeePhoneNoValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeePhoneNoValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeePhoneNoValue, "+91-"+PhoneNumber));
        LogCapture.info("User verify Payee Phone number ["+PhoneNumber+"] is visible on View Payee details page..");

        String vObjViewPayeeReference = Constants.TitanPayeeOR.getProperty("ViewPayeeReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPayeeReference, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPayeeReference, "Payee reference"));
        LogCapture.info("User verify Payee reference Header is visible on View Payee details page..");

        String vObjViewBankIdentificationCode = Constants.TitanPayeeOR.getProperty("ViewBankIdentificationCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankIdentificationCode, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankIdentificationCode, "Bank identification code"));
        LogCapture.info("User verify Payee Bank identification code Header is visible on View Payee details page..");

        String vObjViewPurposeCode = Constants.TitanPayeeOR.getProperty("ViewPurposeCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPurposeCode, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPurposeCode, "Purpose code"));
        LogCapture.info("User verify Payee Purpose code Header is visible on View Payee details page..");

        String vObjViewEmailAdd = Constants.TitanPayeeOR.getProperty("ViewEmailAdd");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewEmailAdd, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewEmailAdd, "Email address"));
        LogCapture.info("User verify Payee Email Address Header is visible on View Payee details page..");

        String vObjViewEmailAddValue = Constants.TitanPayeeOR.getProperty("ViewEmailAddValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewEmailAddValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewEmailAddValue, EmailAddress));
        LogCapture.info("User verify Payee Email Address ["+EmailAddress+"] is visible on View Payee details page..");

        String vObjViewCountryPaymentGoingTo = Constants.TitanPayeeOR.getProperty("ViewCountryPaymentGoingTo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewCountryPaymentGoingTo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewCountryPaymentGoingTo, "Country payment is going to"));
        LogCapture.info("User verify Payee Country payment is going to Header is visible on View Payee details page..");

        String vObjViewCountryPaymentGoingToValue = Constants.TitanPayeeOR.getProperty("ViewCountryPaymentGoingToValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewCountryPaymentGoingToValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewCountryPaymentGoingToValue, Country));
        LogCapture.info("User verify Payee Country payment is going to ["+Country+"] is visible on View Payee details page..");

        String vObjViewCCYToRecieve = Constants.TitanPayeeOR.getProperty("ViewCCYToRecieve");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewCCYToRecieve, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewCCYToRecieve, "Currency to receive"));
        LogCapture.info("User verify Payee Currency to recieve Header is visible on View Payee details page..");

        String vObjViewCCYToRecieveValue = Constants.TitanPayeeOR.getProperty("ViewCCYToRecieveValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewCCYToRecieveValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewCCYToRecieveValue, CurrencyReceive));
        LogCapture.info("User verify Payee Currency to recieve ["+CurrencyReceive+"] is visible on View Payee details page..");

        String vObjViewChargesOn= Constants.TitanPayeeOR.getProperty("ViewChargesOn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewChargesOn, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewChargesOn, "Charges on..."));
        LogCapture.info("User verify Payee Charges On Header is visible on View Payee details page..");

        String vObjViewChargesOnValue = Constants.TitanPayeeOR.getProperty("ViewChargesOnValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewChargesOnValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewChargesOnValue, "SHA"));
        LogCapture.info("User verify Payee Charges On [SHA] is visible on View Payee details page..");

        String vObjViewPostCode = Constants.TitanPayeeOR.getProperty("ViewPostCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPostCode, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPostCode, "Postcode"));
        LogCapture.info("User verify Payee Charges On Header is visible on View Payee details page..");

        String vObjViewPostCodeValue = Constants.TitanPayeeOR.getProperty("ViewPostCodeValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewPostCodeValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewPostCodeValue, Postcode));
        LogCapture.info("User verify Payee Charges On ["+Postcode+"] is visible on View Payee details page..");

        String vObjViewAddress = Constants.TitanPayeeOR.getProperty("ViewAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewAddress, "Address"));
        LogCapture.info("User verify Payee Address Header is visible on View Payee details page..");

        String vObjViewAddressValue = Constants.TitanPayeeOR.getProperty("ViewAddressValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewAddressValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewAddressValue, Address));
        LogCapture.info("User verify Payee Address ["+Address+"] is visible on View Payee details page..");

        String vObjViewTownCity = Constants.TitanPayeeOR.getProperty("ViewTownCity");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewTownCity, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewTownCity, "Town/City"));
        LogCapture.info("User verify Payee Address Header is visible on View Payee details page..");

        String vObjViewTownCityValue = Constants.TitanPayeeOR.getProperty("ViewTownCityValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewTownCityValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewTownCityValue, Town));
        LogCapture.info("User verify Payee Address ["+Address+"] is visible on View Payee details page..");

        String vObjViewInTaxIdentifier = Constants.TitanPayeeOR.getProperty("ViewInTaxIdentifier");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewInTaxIdentifier, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewInTaxIdentifier, "Inn tax identifier"));
        LogCapture.info("User verify Payee Inn tax identifier Header is visible on View Payee details page..");

        String vObjViewVOCode = Constants.TitanPayeeOR.getProperty("ViewVOCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewVOCode, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewVOCode, "VO code"));
        LogCapture.info("User verify Payee VO Code Header is visible on View Payee details page..");

        String vObjViewCourseBankACNumber = Constants.TitanPayeeOR.getProperty("ViewCourseBankACNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewCourseBankACNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewCourseBankACNumber, "Corres bank A/C number"));
        LogCapture.info("User verify Payee Corres bank A/C number Header is visible on View Payee details page..");

    }

    @Then("^User verify payee bank details AccountNumber \"([^\"]*)\" SwifCode \"([^\"]*)\" BankCodeType \"([^\"]*)\" NameInLicalLanguage \"([^\"]*)\" FFCDetail \"([^\"]*)\" IntermediarySwiftCode \"([^\"]*)\" and other bank details$")
    public void userVerifyPayeeBankDetailsAccountNumberSwifCodeBankCodeTypeNameInLicalLanguageFFCDetailIntermediarySwiftCodeAndOtherBankDetails(String AccountNumber, String BankCode, String BankCodeType, String NameInLocalLanguage, String FFCDetail, String IntermediarySwiftCode) throws Throwable {

        String vObjViewIBAN= Constants.TitanPayeeOR.getProperty("ViewIBAN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewIBAN, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewIBAN, "IBAN"));
        LogCapture.info("User verify Payee IBAN Header is visible on View Payee details page..");

        String vObjViewAccountNumber = Constants.TitanPayeeOR.getProperty("ViewAccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewAccountNumber, "Account number"));
        LogCapture.info("User verify Payee Account number Header is visible on View Payee details page..");

        if(AccountNumber.contains("DE") || AccountNumber.contains("ES") || AccountNumber.contains("SE"))
        {
            String vObjViewIBANValues = Constants.TitanPayeeOR.getProperty("ViewIBANValues");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewIBANValues, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewIBANValues, AccountNumber));
            LogCapture.info("User verify Payee IBAN ["+AccountNumber+"] is visible on View Payee details page..");
        }else
        {
            String vObjViewAccountNumbervalues = Constants.TitanPayeeOR.getProperty("ViewAccountNumbervalues");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewAccountNumbervalues, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewAccountNumbervalues, AccountNumber));
            LogCapture.info("User verify Payee Account Number ["+AccountNumber+"] is visible on View Payee details page..");
        }

        String vObjViewBackBIC = Constants.TitanPayeeOR.getProperty("ViewBackBIC");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBackBIC, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBackBIC, "Bank bic"));
        LogCapture.info("User verify Payee Bank BIC Header is visible on View Payee details page..");
        String BankCodeTxt = BankCode+"XXX";
        if (BankCodeType.equalsIgnoreCase("SORT"))
        {
            LogCapture.info("User verify Payee Bank BIC as null for is visible on View Payee details page..");
        }else
        {
            String vObjViewBankBICValues = Constants.TitanPayeeOR.getProperty("ViewBankBICValues");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankBICValues, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankBICValues, BankCodeTxt));
            LogCapture.info("User verify Payee Bank BIC ["+BankCodeTxt+"] is visible on View Payee details page..");
        }

        String vObjViewBankInfraCountryCode = Constants.TitanPayeeOR.getProperty("ViewBankInfraCountryCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankInfraCountryCode, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankInfraCountryCode, "Bank intra country code"));
        LogCapture.info("User verify Payee Bank intra country code Header is visible on View Payee details page..");

        if (BankCodeType.equalsIgnoreCase("SORT"))
        {
            String vObjViewBankInfraCountryCodeValue = Constants.TitanPayeeOR.getProperty("ViewBankInfraCountryCodevalue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankInfraCountryCodeValue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankInfraCountryCodeValue, BankCode));
            LogCapture.info("User verify Payee Bank intra country code "+BankCode+" is visible on View Payee details page..");
        }
        else if(BankCodeType.equalsIgnoreCase("ABA"))
        {
            String vObjViewBankInfraCountryCodeValue = Constants.TitanPayeeOR.getProperty("ViewBankInfraCountryCodevalue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankInfraCountryCodeValue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankInfraCountryCodeValue, "011103093"));
            LogCapture.info("User verify Payee Bank intra country code [011103093] is visible on View Payee details page..");
        }
        else if(BankCodeType.equalsIgnoreCase("CNAPS"))
        {
            String vObjViewBankInfraCountryCodeValue = Constants.TitanPayeeOR.getProperty("ViewBankInfraCountryCodevalue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankInfraCountryCodeValue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankInfraCountryCodeValue, "50122200000017"));
            LogCapture.info("User verify Payee Bank intra country code [50122200000017] is visible on View Payee details page..");
        }
        else if(BankCodeType.equalsIgnoreCase("Transit"))
        {
            String vObjViewBankInfraCountryCodeValue = Constants.TitanPayeeOR.getProperty("ViewBankInfraCountryCodevalue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankInfraCountryCodeValue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankInfraCountryCodeValue, "001610129"));
            LogCapture.info("User verify Payee Bank intra country code [001610129] is visible on View Payee details page..");
        }

        String vObjViewSwiftCode = Constants.TitanPayeeOR.getProperty("ViewSwiftCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewSwiftCode, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewSwiftCode, "SWIFT CODE"));
        LogCapture.info("User verify Payee SWIFT CODE Header is visible on View Payee details page..");

        if (BankCodeType.equalsIgnoreCase("SORT"))
        {
            LogCapture.info("User verify Payee Swift Code as [Null] on View Payee details page...");
        }else
        {
            String vObjViewSwiftCodeValue = Constants.TitanPayeeOR.getProperty("ViewSwiftCodeValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewSwiftCodeValue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewSwiftCodeValue, BankCodeTxt));
            LogCapture.info("User verify Payee Swift Code ["+BankCodeTxt+"] is visible on View Payee details page..");
        }

        String vObjViewAccountName = Constants.TitanPayeeOR.getProperty("ViewAccountName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewAccountName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewAccountName, "Account name"));
        LogCapture.info("User verify Payee Account name Header is visible on View Payee details page..");

        String vObjViewAccountNameValues = Constants.TitanPayeeOR.getProperty("ViewAccountNameValues");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewAccountNameValues, ""));
        String AccountName = Constants.driver.findElement(By.xpath(vObjViewAccountNameValues)).getText();
        String AccountNameTxt = PayeeFirstName +" "+PayeeLastName;

        if(AccountName.equals(AccountNameTxt))
        {
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewAccountNameValues, AccountNameTxt));
            LogCapture.info("User verify Payee Account Name ["+AccountNameTxt+"] is visible on View Payee details page..");
        }else
        {
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewAccountNameValues, PayeeCompanyName));
            LogCapture.info("User verify Payee Account Name ["+PayeeCompanyName+"] is visible on View Payee details page..");
        }

        String vObjViewNameInLocalLanguage = Constants.TitanPayeeOR.getProperty("ViewNameInLocalLanguage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewNameInLocalLanguage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewNameInLocalLanguage, "Account Name in local language"));
        LogCapture.info("User verify Payee Account Name in local language Header is visible on View Payee details page..");

        String vObjViewNameInLocalLanguageValues = Constants.TitanPayeeOR.getProperty("ViewNameInLocalLanguageValues");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewNameInLocalLanguageValues, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewNameInLocalLanguageValues, NameInLocalLanguage));
        LogCapture.info("User verify Payee Account Name in local language ["+NameInLocalLanguage+"] is visible on View Payee details page..");

        String vObjViewCurrrency = Constants.TitanPayeeOR.getProperty("ViewCurrrency");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewCurrrency, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewCurrrency, "Currency"));
        LogCapture.info("User verify Payee Currency Header is visible on View Payee details page..");

        String vObjViewIntermediateryBankname = Constants.TitanPayeeOR.getProperty("ViewIntermediateryBankname");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewIntermediateryBankname, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewIntermediateryBankname, "Intermediary bank"));
        LogCapture.info("User verify Payee Intermediary bank header is visible on View Payee details page..");

        String vObjViewIntermediateryBanknameValues = Constants.TitanPayeeOR.getProperty("ViewIntermediateryBanknameValues");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewIntermediateryBanknameValues, ""));
        String InterMediateryBankNameTxt = Constants.driver.findElement(By.xpath(vObjViewIntermediateryBanknameValues)).getText();

        if(!InterMediateryBankNameTxt.equals(""))
        {
            LogCapture.info("User verify Payee Intermediary bank name ["+InterMediateryBankNameTxt+"] is visible on View Payee details page..");
        }else {
            LogCapture.info("User verify Payee Intermediary bank name ["+InterMediateryBankNameTxt+"] is not visible on View Payee details page..");
            Assert.fail();
        }

        String vObjViewIntermediateryBankBIC = Constants.TitanPayeeOR.getProperty("ViewIntermediateryBankBIC");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewIntermediateryBankBIC, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewIntermediateryBankBIC, "Intermediary bank bic"));
        LogCapture.info("User verify Payee Intermediary bank bic Header is visible on View Payee details page..");

        String vObjViewIntermediateryBankBICValue = Constants.TitanPayeeOR.getProperty("ViewIntermediateryBankBICValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewIntermediateryBankBICValue, ""));
        String IntermediarySwiftCodeTxt = IntermediarySwiftCode+"XXX";
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewIntermediateryBankBICValue, IntermediarySwiftCodeTxt));
        LogCapture.info("User verify Payee Swift Code ["+IntermediarySwiftCodeTxt+"] is visible on View Payee details page..");

        String vObjViewIntermediateryBankCountry = Constants.TitanPayeeOR.getProperty("ViewIntermediateryBankCountry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewIntermediateryBankCountry, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewIntermediateryBankCountry, "Intermediary bank country code"));
        LogCapture.info("User verify Payee Intermediary bank country code Header is visible on View Payee details page..");

        String vObjViewIntermediateryBankCountryValues = Constants.TitanPayeeOR.getProperty("ViewIntermediateryBankCountryValues");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewIntermediateryBankCountryValues, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewIntermediateryBankCountryValues, "GBR"));
        LogCapture.info("User verify Payee Intermediary bank country code [GBR] is visible on View Payee details page..");

        String vObjViewBankIntraCountryCodeType = Constants.TitanPayeeOR.getProperty("ViewBankIntraCountryCodeType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankIntraCountryCodeType, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankIntraCountryCodeType, "Bank intra country code type"));
        LogCapture.info("User verify Payee Bank intra country code type header is visible on View Payee details page..");

        if (BankCodeType.equalsIgnoreCase("SORT") || BankCodeType.equalsIgnoreCase("BSB") || BankCodeType.equalsIgnoreCase("ABA") || BankCodeType.equalsIgnoreCase("CNAPS") || BankCodeType.equalsIgnoreCase("Transit"))
        {
            String vObjViewBankIntraCountryCodeTypeValues = Constants.TitanPayeeOR.getProperty("ViewBankIntraCountryCodeTypeValues");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankIntraCountryCodeTypeValues, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankIntraCountryCodeTypeValues, BankCodeType));
            LogCapture.info("User verify Payee Bank intra country code type ["+BankCodeType+"] is visible on View Payee details page..");
        }else
        {
            LogCapture.info("User verify Payee Bank intra country code type as null on View Payee details page..");
        }

        String vObjViewBankName = Constants.TitanPayeeOR.getProperty("ViewBankName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankName, "Bank name"));
        LogCapture.info("User verify Payee Bank name header is visible on View Payee details page..");

        String vObjViewBankNameValue = Constants.TitanPayeeOR.getProperty("ViewBankNameValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankNameValue, ""));
        String BankNameTxt = Constants.driver.findElement(By.xpath(vObjViewBankNameValue)).getText();
        if(!BankNameTxt.equals(""))
        {
            LogCapture.info("User verify Payee bank name ["+BankNameTxt+"] is visible on View Payee details page..");
        }else {
            LogCapture.info("User verify Payee bank name ["+BankNameTxt+"] is not visible on View Payee details page..");
            Assert.fail();
        }

        String vObjViewBankAddress = Constants.TitanPayeeOR.getProperty("ViewBankAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewBankAddress, "Bank address"));
        LogCapture.info("User verify Payee Bank address header is visible on View Payee details page..");

        String vObjViewBankAddressvalues = Constants.TitanPayeeOR.getProperty("ViewBankAddressvalues");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewBankAddressvalues, ""));
        String BankAddressTxt = Constants.driver.findElement(By.xpath(vObjViewBankAddressvalues)).getText();
        if(!BankAddressTxt.equals(""))
        {
            LogCapture.info("User verify Payee bank name ["+BankAddressTxt+"] is visible on View Payee details page..");
        }else {
            LogCapture.info("User verify Payee bank name ["+BankAddressTxt+"] is not visible on View Payee details page..");
            Assert.fail();
        }

        String vObjViewLagecyPayeeBankID = Constants.TitanPayeeOR.getProperty("ViewLagecyPayeeBankID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewLagecyPayeeBankID, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewLagecyPayeeBankID, "Legacy payee bank id"));
        LogCapture.info("User verify PLegacy payee bank id header is visible on View Payee details page..");

        String vObjViewMaskedIBAN = Constants.TitanPayeeOR.getProperty("ViewMaskedIBAN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjViewMaskedIBAN, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjViewMaskedIBAN, "Masked IBAN"));
        LogCapture.info("User verify Payee Masked IBAN header is visible on View Payee details page..");

        String vObjviewPayeePaymentMethod = Constants.TitanPayeeOR.getProperty("viewPayeePaymentMethod");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjviewPayeePaymentMethod, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjviewPayeePaymentMethod, "Payee payment method"));
        LogCapture.info("User verify Payee payment method header is visible on View Payee details page..");

        String vObjviewPayeePaymentMethodValue = Constants.TitanPayeeOR.getProperty("viewPayeePaymentMethodValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjviewPayeePaymentMethodValue, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjviewPayeePaymentMethodValue, "BACS/CHAPS/TT"));
        LogCapture.info("User verify Payee payment method [BACS/CHAPS/TT] is visible on View Payee details page..");

        String vObjClosePayeeDetailsPage = Constants.TitanPayeeOR.getProperty("ClosePayeeDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClosePayeeDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClosePayeeDetailsPage, ""));
        LogCapture.info("User Click on Close verify Payee details page..");
        Constants.key.pause("3", "");

    }

    @Then("^User is on add a payee page to verify FFC details \"([^\"]*)\"$")
    public void userIsOnAddAPayeePageToVerifyFFCDetails(String FFCDetail) throws Throwable {

        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("PayeeDropdownArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("PayeeSearch");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        String PayeetName = PayeeFirstName + " " + PayeeLastName;
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, PayeetName));
        Constants.key.pause("2", "");

        String vObjPayeename = Constants.TitanPaymentOutOR.getProperty("Payeename");
        String PayeeDetail = Constants.driver.findElement(By.xpath(vObjPayeename)).getAttribute("data-ot");

        if (PayeeDetail.contains("FFC Details") && PayeeDetail.contains(FFCDetail)) {
            LogCapture.info(PayeeDetail);
            LogCapture.info("User verify FFC Details while selecting payee [" + FFCDetail + "].....");

        } else {
            LogCapture.info("User not able to verify FFC Details while selecting payee.....");
            Assert.fail();
        }
        String vObjFXClosedPage = Constants.TitanPaymentOutOR.getProperty("FXClosedPage");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXClosedPage, ""));

    }

    @And("^User is on Credit page and clicks on Select method button and verify ACH Direct debit method is present or not$")
    public void userIsOnCreditPageAndClicksOnSelectMethodButtonAndVerifyACHDirectDebitMethodIsPresentOrNot() throws Exception {
        String vObjFXCreditPage = Constants.CreateFxTicketOR.getProperty("FXCreditPage");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFXCreditPage, "visible"));
        LogCapture.info("User is on 3 of 4: Credit page...");

        String vObjFXCreditDropDownBtn = Constants.CreateFxTicketOR.getProperty("ClickonDropdown");
        Assert.assertEquals("PASS", Constants.key.click(vObjFXCreditDropDownBtn, ""));
        Constants.key.pause("3", "");
        LogCapture.info("User clicks on DropDown button...");


        for(int i= 1; i<=5; i++)
        {
            String MethodXpath = "//ul[@id='pillchoice-fx-credit-method']//li["+i+"]";

            String ActualMethodXpath = Constants.driver.findElement(By.xpath(MethodXpath)).getText();
            if (ActualMethodXpath.contains("Card")) {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");
            }
            else if(ActualMethodXpath.contains("Bank"))
            {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");
            }
            else if(ActualMethodXpath.contains("Moneytech"))
            {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");
            }
            else if(ActualMethodXpath.contains("Cheque"))
            {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");
            }else if(ActualMethodXpath.contains("DD"))
            {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");
            }


        }
        String vObjFXClosedPage = Constants.TitanPaymentOutOR.getProperty("FXClosedPage");
         Constants.key.navigateSubMenu(vObjFXClosedPage, "");
        Constants.key.pause("2", "");

    }

    @And("^User enters Payee Bank details AccountNumber\"([^\"]*)\" BankCodeType\"([^\"]*)\" BankCode\"([^\"]*)\" FFCDetail \"([^\"]*)\" NameInLocalLang \"([^\"]*)\" SwiftCode \"([^\"]*)\" PurposeCode \"([^\"]*)\" and click on get bank details and then click on Next button$")
    public void userEntersPayeeBankDetailsAccountNumberBankCodeTypeBankCodeFFCDetailNameInLocalLangSwiftCodePurposeCodeAndClickOnGetBankDetailsAndThenClickOnNextButton(String AccountNumber, String BankCodeType, String BankCode, String FFCDetail, String NameInLocalLanguage, String SwiftCode, String PurposeCode) throws Throwable {
        String vObjBankDetailsPage = Constants.TitanPayeeOR.getProperty("BankDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankDetailsPage, ""));
        LogCapture.info("2 of 3: Bank details page is visible..");

        if (AccountNumber.contains("ES") || AccountNumber.contains("DE")|| AccountNumber.contains("SE")) {
            LogCapture.info("Account number NOT required but IBAN number for EUR required..");
            String vObjIBANNumber = Constants.TitanPayeeOR.getProperty("IBANNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjIBANNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjIBANNumber, AccountNumber));
            LogCapture.info("IBAN number entered is : "+AccountNumber);

        } else {
            String vObjAccountNumber = Constants.TitanPayeeOR.getProperty("AccountNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjAccountNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAccountNumber, AccountNumber));
            LogCapture.info("Payee Account number entered is : "+AccountNumber);
        }
        if (BankCodeType.equalsIgnoreCase("ABA")) {
            String vObjABANumber = Constants.TitanPayeeOR.getProperty("ABANumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjABANumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjABANumber, "011103093"));
            LogCapture.info("Payee ABA number entered is : 011103093");

            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number entered is : "+BankCode);
        }
        if (BankCodeType.equalsIgnoreCase("SWIFT")) {
            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number entered is : "+BankCode);
        }
        if (BankCodeType.equalsIgnoreCase("SORT")) {
            String vObjSortCode = Constants.TitanPayeeOR.getProperty("SortCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSortCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSortCode, BankCode));
            LogCapture.info("SORT code entered is : "+BankCode);
        }
        if (BankCodeType.equalsIgnoreCase("CNAPS")) {
            String vObjCNAPS = Constants.TitanPayeeOR.getProperty("CNAPCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjCNAPS, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCNAPS, "50122200000017"));

            String vObjPurposeCode = Constants.TitanPayeeOR.getProperty("PurposeCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjPurposeCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPurposeCode, PurposeCode));
            LogCapture.info("Purpose code entered is : "+PurposeCode);

            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number entered is : "+BankCode);
        }
        if (BankCodeType.equalsIgnoreCase("Transit")) {
            String vObjBSBNumber = Constants.TitanPayeeOR.getProperty("PayeeTransitNumber");
            Assert.assertEquals("PASS", Constants.key.click(vObjBSBNumber, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBSBNumber, "001610129"));
            LogCapture.info("SORT code entered is : 001610129");

            String vObjSWIFTCode = Constants.TitanPayeeOR.getProperty("SWIFTCode");
            Assert.assertEquals("PASS", Constants.key.click(vObjSWIFTCode, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSWIFTCode, BankCode));
            LogCapture.info("SWIFT number entered is : "+BankCode);
        }

        String vObjFFCDetails = Constants.TitanPayeeOR.getProperty("FFCDetails");
        Assert.assertEquals("PASS", Constants.key.click(vObjFFCDetails, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFFCDetails, FFCDetail));
        LogCapture.info("FFC Detail entered is : "+FFCDetail);

        String vObjNameinLocalLanguage = Constants.TitanPayeeOR.getProperty("NameinLocalLanguage");
        Assert.assertEquals("PASS", Constants.key.click(vObjNameinLocalLanguage, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameinLocalLanguage, NameInLocalLanguage));
        LogCapture.info("Name in Local Language entered is : "+NameInLocalLanguage);

        String vObjGetBankDetailsBtn = Constants.TitanPayeeOR.getProperty("GetBankDetailsBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjGetBankDetailsBtn, ""));
        LogCapture.info("Clicked on Get bank details button..");
        Constants.key.pause("4", "");

        String vObjBankDetailsNextBtn = Constants.TitanPayeeOR.getProperty("BankDetailsNextBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBankDetailsNextBtn, ""));
        LogCapture.info("User clicked on Next button..");
    }

    @Then("^User is on add a payee page of FX SPOT to verify FFC details \"([^\"]*)\"$")
    public void userIsOnAddAPayeePageOfFXSPOTToVerifyFFCDetails(String FFCDetail) throws Throwable {
        String vObjSelectPayeeDownArrow = Constants.TitanPaymentOutOR.getProperty("FXPayeeDrawdown");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectPayeeDownArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPayeeDownArrow, ""));
        String vObjSearchPayee = Constants.TitanPaymentOutOR.getProperty("FXpayeeSearch");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjSearchPayee, ""));
        String PayeetName = PayeeFirstName +" "+PayeeLastName;
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, PayeetName));
        Constants.key.pause("2", "");

        String vObjPayeename = Constants.TitanPaymentOutOR.getProperty("FXPayeeName");
        String PayeeDetail = Constants.driver.findElement(By.xpath(vObjPayeename)).getAttribute("data-ot");

        if(PayeeDetail.contains("FFC Details") && PayeeDetail.contains(FFCDetail))
        {
            LogCapture.info(PayeeDetail);
            LogCapture.info("User verify FFC Details while selecting payee ["+FFCDetail+"].....");

        }else
        {
            LogCapture.info("User not able to verify FFC Details while selecting payee.....");
            Assert.fail();
        }
        String vObjFXClosedPage = Constants.TitanPaymentOutOR.getProperty("FXClosedPage");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXClosedPage, ""));
        Constants.key.pause("2", "");

    }

    @And("^User is able to click on Swap$")
    public void userIsAbleToClickOnSwap() throws Exception {

        String vObjSWAPButton = Constants.CreateFxTicketOR.getProperty("SwapClick");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSWAPButton, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSWAPButton, ""));
        Constants.key.pause("2", "");
        LogCapture.info("User clicked on SWAP button..");

    }


    @And("^User is on Method and clicks on Select method button and verify ACH Direct debit method is present or not$")
    public void userIsOnMethodAndClicksOnSelectMethodButtonAndVerifyACHDirectDebitMethodIsPresentOrNot() throws Exception {
        String vObjMethodDetailsPage = Constants.TitanPaymentInOR.getProperty("MethodDetailsPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMethodDetailsPage, ""));
        LogCapture.info("2 of 2: Method page is visible..");
        String vObjSelectPaymentInMethod = TitanPaymentInOR.getProperty("SelectPaymentinMethod");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectPaymentInMethod, ""));

        for(int i= 1; i<=5; i++)
        {
            String MethodXpath = "//ul[@id='pillchoice-fx-credit-method']//li["+i+"]";

            String ActualMethodXpath = Constants.driver.findElement(By.xpath(MethodXpath)).getText();
            if (ActualMethodXpath.contains("Card")) {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");

            }else if(ActualMethodXpath.contains("Bank"))
            {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");

            }else if(ActualMethodXpath.contains("Moneytech"))
            {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");

            }
            else if(ActualMethodXpath.contains("Cheque"))
            {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");

            }else if(ActualMethodXpath.contains("DD"))
            {
                LogCapture.info("Payment method ["+ActualMethodXpath+"] is visible on Credit page.....");

            }
        }
        String vObjFXClosedPage = Constants.TitanPaymentOutOR.getProperty("FXClosedPage");
        Constants.key.navigateSubMenu(vObjFXClosedPage, "");
        Constants.key.pause("2", "");
    }

//    @Given("^User launches Kafka UI application for \"([^\"]*)\" topic$")
//    public void userLaunchesKafkaUIApplicationForTopic(String topic) throws Throwable {
//        if(vBrowserName!=null) {
//            Constants.driver.quit();
//        }
//        if(!isKafkaLaunched) {
//            if(Constants.JenkinsBrowser == null || Constants.JenkinsBrowser.isEmpty()) {
//                Constants.JenkinsBrowser = Constants.CONFIG.getProperty("browser");
//            }
//
//            Assert.assertTrue(Reusables.openBrowser("", Constants.JenkinsBrowser));
//            LogCapture.info("Kafka UI is launching....");
//            String kafkaUrl = Constants.CONFIG.getProperty("KafkaUIUrl");
//           // kafkaUrl = kafkaUrl.replace("{TOPIC}", topic).replace("{ENV}", Constants.CONFIG.getProperty("Environment")).replace( "{UniqueIdentifier}",Constants.DynamicValue.get("<dynamic>"));
//            kafkaUrl=kafkaUrl.replace("{TOPIC}", topic).replace("{ENV}", JenkinsEnvironment).replace("{FundsInId}", Constants.paymentLifeCycleID).replace("{KEY}", paymentLifeCycleID);
//            LogCapture.info("Kafka UTI is launching...."+kafkaUrl);
//            Assert.assertEquals("PASS", Reusables.navigate("", kafkaUrl));
//
//            Reusables.loginToKafkaUI();
//            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
////            Constants.driver.navigate().refresh();
//            isKafkaLaunched = true;
//        } else {
//            Constants.driver.navigate().refresh();
//        }
//    }

    @Then("^Verify kafka message for \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void verifyKafkaMessageFor(String ExpectedKeyValueSqlQueryProperty, String TitanEnvironment, String DBOperation) throws Throwable {
        verifyTitanKafkaMessageFor(ExpectedKeyValueSqlQueryProperty, DBOperation);
    }

    @Then("^Verify titan kafka message for \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verifyTitanKafkaMessageFor(String ExpectedKeyValueSqlQueryProperty, String DBOperation) throws Throwable {
//        key.pause("30","");
//        Constants.CustomerInstructionID=Constants.key.VerifyDBDetails(TitanEnvironment, paymentLifeCycleID, "Find InstructionIdReference");
//        String uniqueMessageId;
//        if (KafkaMessageCDID == null) {
//            uniqueMessageId = InstructionIdReference;
//        } else if (!Objects.equals(BankPaymentEntries_ID, "null")) {
//            uniqueMessageId = CustomerInstructionID;
//        } else {
//            uniqueMessageId = BankPaymentEntries_ID;
//        }
        String messageFieldXpath = KafkaUI.getProperty("MessageField");
        messageFieldXpath = messageFieldXpath.replace("{uniqueMessageOperation}", DBOperation);
        messageFieldXpath = messageFieldXpath.replace("{uniqueMessageId}", KafkaMessageCDID);
        LogCapture.info("MessageFieldXpath for kafka =" + messageFieldXpath);

        JsonPath actualKafkaMsgJsonObj = ReusableMethod.waitForKafkaMessage(messageFieldXpath);
        System.out.println(actualKafkaMsgJsonObj);
//        kafkaExpectedKeyValues = ReusableMethod.getSqlQueryResult(ExpectedKeyValueSqlQueryProperty, Kafka_ID);
//        kafkaExpectedKeyValues = Constants.key.getSqlQueryResult(TitanEnvironment, CustomerInstructionID, DBOperation);
        kafkaExpectedKeyValues = ReusableMethod.getSqlQueryResult(ExpectedKeyValueSqlQueryProperty, KafkaMessageCDID);
        LogCapture.info("kafkaExpectedKeyValues is " + kafkaExpectedKeyValues);
        ReusableMethod.verifyKafkaMessage(kafkaExpectedKeyValues, actualKafkaMsgJsonObj);

    }

    @And("^User clicks on FX button under Activity$")
    public void userClicksOnFXButtonUnderActivity() throws Exception {
        String vObjActivityFX = Constants.TitanFXTicketsOR.getProperty("ActivityFX");

        JavascriptExecutor js = (JavascriptExecutor) Constants.driver;
        js.executeScript("window.scrollTo(50, 600)");
        Constants.key.pause("2", "");

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjActivityFX, ""));
        Constants.key.pause("3", "");
        LogCapture.info("User clicks on FX tab under Activity...");


        String CoflictStatus = "//*[@id=\"profileFxTicketBody\"]/tr[1]/td[13]/a";

        String ActualCoflictStatus = Constants.driver.findElement(By.xpath(CoflictStatus)).getText();
        if (ActualCoflictStatus.contains("CoflictStatus")) {
            LogCapture.info("conflict visible [" + ActualCoflictStatus + "] is Activity Fx page.....");

        } else {
            LogCapture.info("Conflict is not display");
        }

    }

    @And("^User is enter client number \"([^\"]*)\" and hit enter$")
    public void userIsEnterClientNumberAndHitEnter(String clientNumber) throws Throwable {
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Customerno");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, clientNumber));
        LogCapture.info("Searching for Client number : " + clientNumber);
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");
        String vObjCurrency = Constants.CreateFxTicketOR.getProperty("ClickONCurrency");
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrency, ""));

        for (int i = 1; i <= 50; i++) {

            String InstNumber = "//tbody[@id='CAD']//tr[" + i + "]//td[5]";
            String ExecuteButton = "//tbody[@id='CAD']//tr[" + i + "]//td[6]";

            String ActualInstNumber = Constants.driver.findElement(By.xpath(InstNumber)).getText();

            if (ActualInstNumber.equals(""))
            {
                Constants.key.pause("2", "");
                Constants.key.navigateSubMenu(ExecuteButton, "");

                String vOjbExecuteConflictYes = Constants.CreateFxTicketOR.getProperty("ExecuteConflictYes");
                Constants.key.navigateSubMenu(vOjbExecuteConflictYes, "");
                LogCapture.info("Fx Executed from conflict for instruction no : [" + ActualInstNumber + "] ....");
                break;
            }
        }

    }

    @And("^User selects Payee\"([^\"]*)\" and enter amount \"([^\"]*)\" and clicks on AddPayment Button and clicks on YES button$")
    public void userSelectsPayeeAndEnterAmountAndClicksOnAddPaymentButtonAndClicksOnYESButton(String Payee1, String FXAmount) throws Throwable {
        {
            String vObjAddAPaymentPage = Constants.CreateFxTicketOR.getProperty("AddAPaymentPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddAPaymentPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddAPaymentPage, "visible"));
            LogCapture.info("User is on 4 of 4: Add a Payment page...");

            String vObjSelectPayeeDownArrow = Constants.CreateFxTicketOR.getProperty("SelectPayeeDownArrow");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectPayeeDownArrow, ""));
            Constants.key.pause("2", "");
            String vObjSearchPayee = Constants.CreateFxTicketOR.getProperty("SearchPayee");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchPayee, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee1));
            Constants.key.pause("2", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSearchPayee_FireFox = Constants.CreateFxTicketOR.getProperty("SearchPayee_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSearchPayee_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
                LogCapture.info("Payee: " + Payee1 + " is selected..");
            }


            String vObjclearAmount = Constants.CreateFxTicketOR.getProperty("FXAmount");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjclearAmount, ""));
            Assert.assertEquals("PASS", Constants.key.clearText(vObjclearAmount));
            LogCapture.info("Clear Amount field..");


            String vObjEnteramount = Constants.CreateFxTicketOR.getProperty("FXAmount");
            Constants.key.click(vObjEnteramount, "");
            Constants.key.writeInInput(vObjEnteramount, FXAmount);
            LogCapture.info("Payee Account number entered is : "+FXAmount);



            String vObjFXFinishedAddPaymentBtn = Constants.CreateFxTicketOR.getProperty("FXFinishedAddPaymentBtn");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXFinishedAddPaymentBtn, ""));
            LogCapture.info("Clicking on Finished Adding Payment button...");

            String vObjAddPaymentYesButton = Constants.CreateFxTicketOR.getProperty("AddPaymentYesButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentYesButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddPaymentYesButton, ""));
            LogCapture.info("Clicking on YES button for pop-up...");

        }
    }

    @And("^User selects Payee\"([^\"]*)\" and clicks on AddPayment Button button and Yes button$")
    public void userSelectsPayeeAndClicksOnAddPaymentButtonButtonAndYesButton(String Payee2) throws Throwable {
        {
            String vObjAddAPaymentPage = Constants.CreateFxTicketOR.getProperty("AddAPaymentPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddAPaymentPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddAPaymentPage, "visible"));
            LogCapture.info("User is on 4 of 4: Add a Payment page...");

            String vObjSelectPayeeDownArrow = Constants.CreateFxTicketOR.getProperty("SelectPayeeDownArrow");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectPayeeDownArrow, ""));
            Constants.key.pause("2", "");
            String vObjSearchPayee = Constants.CreateFxTicketOR.getProperty("SearchPayee");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchPayee, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchPayee, Payee2));
            Constants.key.pause("2", "");
            if (CurrentBrowser.equalsIgnoreCase("FireFox")) {
                String vSearchPayee_FireFox = Constants.CreateFxTicketOR.getProperty("SearchPayee_FireFox");
                Assert.assertEquals("PASS", Constants.key.click(vSearchPayee_FireFox, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchPayee, "enter"));
                LogCapture.info("Payee: " + Payee2 + " is selected..");
            }

            String vObjFXFinishedAddPaymentBtn = Constants.CreateFxTicketOR.getProperty("FXFinishedAddPaymentBtn");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFXFinishedAddPaymentBtn, ""));
            LogCapture.info("Clicking on Finished Adding Payment button...");

            String vObjAddPaymentYesButton = Constants.CreateFxTicketOR.getProperty("AddPaymentYesButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddPaymentYesButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjAddPaymentYesButton, ""));
            LogCapture.info("Clicking on YES button for pop-up...");

        }
    }

    @And("^User verify MoneyTech button is \"([^\"]*)\"$")
    public void userVerifyMoneyTechButtonIs(String button) throws Throwable {
        LogCapture.info("User verifying MoneyTech button is " + button + "... ");
        String vObjeMoneyTechBtn = TitanFXTicketsOR.getProperty("MoneyTechBtn");
        if (button.equals("Enable")) {
            String Obj = driver.findElement(By.xpath(vObjeMoneyTechBtn)).getAttribute("class");
            if (Obj.contains("disabled")) {
                LogCapture.info("MoneyTech Button is disabled..");
                Assert.assertEquals("PASS", Obj);
            } else {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjeMoneyTechBtn, ""));
                LogCapture.info("User verified MoneyTech Button is Enabled..");
                Assert.assertEquals("PASS", Obj);
            }
        } else if (button.equals("Disable")) {
            String Obj = driver.findElement(By.xpath(vObjeMoneyTechBtn)).getAttribute("class");
            if (Obj.contains("disabled")) {
                LogCapture.info("User verified MoneyTech Button is Disable");
                Assert.assertEquals("PASS", Obj);
            } else {
                LogCapture.info("Test case Failed >> MoneyTech Button is Enabled ");
                Assert.assertEquals("PASS", Obj);
            }
        }
    }

    @And("^User gets BankPaymentEntriesID$")
    public void userGetsBankPaymentEntriesIDFromDB() throws Throwable {
        if(MSL_ID==null) {
            LogCapture.info("MSL_ID is null");
            MSL_ID = IndradayMSL_ID;
        }else if(IndradayMSL_ID==null){
            LogCapture.info("IndradayMSL_ID is null ");
            MSL_ID = EODMSL_ID;
        }
//        String BankPaymentEntries = Constants.key.VerifyDBDetails(Environment, MSL_ID, "Find the BankPaymentEntriesID");
        Constants.KafkaMessageCDID = MSL_ID;
//        Constants.BankPaymentEntries_ID = BankPaymentEntries;
        LogCapture.info("BankPaymentEntriesID is : " + KafkaMessageCDID);

    }
    @And("^Do \"([^\"]*)\" DB verification and get ConfirmationPaymentAdvice ID for CAMT54$")
    public void doDBVerificationAndGetConfirmationPaymentAdviceIDForCAMT54(String Environment) throws Exception {

        String MessageInId=MessageInIdMap.get("MessageInId for 54");
        //String PaymentConfirmation=Constants.key.VerifyDBDetails(Environment, MessageInId, "ConfirmationPaymentAdvice ID");
        Map<String, String> result = ReusableMethod.getSqlQueryResult("MESSAGE_IN", MessageInId);

        String vIsParsed = result.get("IsParsed");
        String vParsedStatus=result.get("parsedStatus");
        LogCapture.info("Value of IsParsed is " + vIsParsed
                + "\n and Value of parsedStatus is " + vParsedStatus);
        Assert.assertTrue( vIsParsed.equals("1"));
        Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));

        Map<String, String> result1 = ReusableMethod.getSqlQueryResult("ConfirmationPaymentAdvice", MessageInId);
        ConfirmationID = result1.get("ID");
        LogCapture.info("Value of ConfirmationID: " + ConfirmationID);
        Assert.assertFalse(false, String.valueOf(ConfirmationID.contains("null")));
    }

    @And("^User \"([^\"]*)\" gets MSL_ID from DB for CAMT54$")
    public void userGetsMSL_IDFromDBForCAMT54(String Environment) throws Exception {
        String MSL=Constants.key.VerifyDBDetails(Environment, ConfirmationID, "Find the MSL_ID for CAMT54");
        Constants.MSL_ID=MSL;
        LogCapture.info("MSL_ID : " + MSL_ID);
    }
    @And("^Do \"([^\"]*)\" DB verification and get IntradayStatementLineID for Indraday$")
    public void doDBVerificationAndGetIntraStatementLineIDForIndraday(String Environment) throws Exception {
        String MessageInId=MessageInIdMap.get("MessageInId for 52");
        if (MessageInId==null){
            Object firstKey = MessageInIdMap.keySet().toArray()[0];
            MessageInId = MessageInIdMap.get(firstKey);
        }
        if (MessageInId==null){
            Object firstKey = MessageInIdMap.keySet().toArray()[0];
            MessageInId = MessageInIdMap.get(firstKey);
        }
        String IntradayStatementLine=Constants.key.VerifyDBDetails(Environment, MessageInId, "Find the StatementLineID for Indraday");
        Constants.IntradayStatementLineID=IntradayStatementLine;
        LogCapture.info("IntradayStatementLineID : " + IntradayStatementLineID);

    }
    @And("^User gets MSL_ID for Indraday from \"([^\"]*)\" DB$")
    public void userGetsMSL_IDForIndradayFromDB(String Environment) throws Exception {
        String MSL=Constants.key.VerifyDBDetails(Environment, IntradayStatementLineID, "Find the MSL_ID for Indraday");
        Constants.IndradayMSL_ID=MSL;
        LogCapture.info("MSL_ID : " + IndradayMSL_ID);
    }

    @And("^Do DB verification and get ID from (CustomerInstructionID|CustomerPaymentInID|InstructionIdReference|LimitOrder|CustomerPaymentOutID) Table$")
    public void doDBVerificationAndGetIDFromCustomerPaymentInTable(String data) throws Throwable {
       if(data.equalsIgnoreCase("CustomerInstructionID")) {
//           InstructionNumber1 = "0201001006940717-000000011";
           if(InstructionNumber1==null){
               InstructionNumber1=InstructionNumber;
           }
           LogCapture.info("InstructionNumber1 : " + InstructionNumber1);
           //String ID = Constants.key.VerifyDBDetails(TitanEnvironment, InstructionNumber1, "Find CustomerInstructionID");
           Map <String, String> result = ReusableMethod.getSqlQueryResult("CustomerInstructionID", InstructionNumber1);
           Constants.CustomerInstructionID=result.get("ID");
           Constants.KafkaMessageCDID = CustomerInstructionID;
        LogCapture.info("CustomerInstructionID : " + CustomerInstructionID);
       }else if(data.equalsIgnoreCase("CustomerPaymentInID")) {
           LogCapture.info("CustomerInstructionID : " + CustomerInstructionID);
//           String ID=Constants.key.VerifyDBDetails(TitanEnvironment, CustomerInstructionID, "Find CustomerPaymentInID");
           Map <String, String> result = ReusableMethod.getSqlQueryResult("CustomerInstructionID", CustomerInstructionID);
           Constants.CustomerPaymentInID=result.get("ID");
           Constants.KafkaMessageCDID =CustomerPaymentInID;
           LogCapture.info("CustomerPaymentInID : " + KafkaMessageCDID);
       } else if(data.equalsIgnoreCase("InstructionIdReference")) {
//           String ID=Constants.key.VerifyDBDetails(TitanEnvironment, InstructionIdReference, "Find CustomerPaymentInID using InstructionIdReference");
           Map <String, String> result = ReusableMethod.getSqlQueryResult("CustomerPaymentInIDUsingInstructionIdReference", InstructionIdReference);
           Constants.CustomerInstructionID=result.get("ID");
           Constants.KafkaMessageCDID = CustomerInstructionID;
        LogCapture.info("CustomerInstructionID : " + CustomerInstructionID);
       }else if(data.equalsIgnoreCase("LimitOrder")) {
           if(InstructionNumber1==null){
               InstructionNumber1=InstructionNumber;
           }
           LogCapture.info("InstructionNumber1 : " + InstructionNumber1);
//           String ID = Constants.key.VerifyDBDetails(TitanEnvironment, InstructionNumber1, "Find LimitOrderID");
           Map <String, String> result = ReusableMethod.getSqlQueryResult("LimitOrder", InstructionNumber1);
           Constants.LimitOrderID=result.get("ID");
           Constants.KafkaMessageCDID = LimitOrderID;
        LogCapture.info("CustomerInstructionID : " + CustomerInstructionID);
       }else if(data.equalsIgnoreCase("CustomerPaymentOutID")) {
           LogCapture.info("CustomerInstructionID : " + CustomerInstructionID);
//           String ID = Constants.key.VerifyDBDetails(TitanEnvironment, CustomerInstructionID, "Find CustomerPaymentOutID");
           Map <String, String> result = ReusableMethod.getSqlQueryResult("CustomerPaymentOutID", CustomerInstructionID);
           Constants.CustomerPaymentOutID = result.get("ID");
           Constants.KafkaMessageCDID = CustomerPaymentOutID;
           LogCapture.info("CustomerPaymentOutID : " + KafkaMessageCDID);
       }

    }


    @And("^user is click on newly for Added instruction number$")
    public void userIsClickOnNewlyForAddedInstructionNumber() throws Exception
    {



        for (int i = 1; i <= 25; i++)
        {
            String InstNumber = "//tbody[@id='CAD']//tr[" + i + "]//td[5]";
            String ExecuteButton = "//tbody[@id='CAD']//tr[" + i + "]//td[6]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(InstNumber, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExecuteButton, ""));
            String ActInstructionNumber = Constants.driver.findElement(By.xpath(InstNumber)).getText();
            String ActExecuteButton = Constants.driver.findElement(By.xpath(ExecuteButton)).getText();
            if (ActInstructionNumber.equals(InstructionNumber)) {

                Assert.assertEquals("PASS", Constants.key.click(InstNumber, ""));
                Assert.assertEquals("PASS", Constants.key.pause("1", ""));
                LogCapture.info("User Click on newly created Instruction number " + ActInstructionNumber + "...");
                Assert.assertEquals("PASS", Constants.key.pause("3", ""));
                String vOjbExecuteConflictYes = Constants.CreateFxTicketOR.getProperty("ExecuteConflictYes");
                Assert.assertEquals("PASS", Constants.key.click(vOjbExecuteConflictYes, ""));
                Constants.key.navigateSubMenu(vOjbExecuteConflictYes, "");
                break;

            }
        }
    }


    @And("^User is on Method and clicks on Select method button$")
    public void userIsOnMethodAndClicksOnSelectMethodButton() throws Exception {
            String vObjMethodDetailsPage = Constants.TitanPaymentInOR.getProperty("MethodDetailsPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMethodDetailsPage, ""));
            LogCapture.info("2 of 2: Method page is visible..");
            String vObjSelectPaymentInMethod = TitanPaymentInOR.getProperty("SelectPaymentinMethod");
            Assert.assertEquals("PASS", Constants.key.click(vObjSelectPaymentInMethod, ""));

        }


    @And("^user is click on \"([^\"]*)\" CUrrency$")
    public void userIsClickOnCUrrency(String CURRENCY) throws Throwable
    {
        String vObjCurrency = null;
        if (CURRENCY.equalsIgnoreCase("AUD")) {
            vObjCurrency = TitanConflictsOR.getProperty("ClickOnAUD");
        }
        if (CURRENCY.equalsIgnoreCase("CAD")) {
            vObjCurrency = TitanConflictsOR.getProperty("ClickOnCAD");
        }
        if (CURRENCY.equalsIgnoreCase("EUR")) {
            vObjCurrency = TitanConflictsOR.getProperty("ClickOnEUR");
        }

        if (CURRENCY.equalsIgnoreCase("GBP")) {
            vObjCurrency = TitanConflictsOR.getProperty("ClickOnGBP");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCurrency, ""));

        LogCapture.info("User clicks on " + CURRENCY + " currency..");

        key.pause("2", "");



    }
        @And("^User selects Instructed by \"([^\"]*)\" Currency\"([^\"]*)\" and Click on MoneyTech Option Click on Next button for Payment Out$")
        public void userSelectsInstructedByCurrencyAndClickOnMoneyTechOptionClickOnNextButtonForPaymentOut(String instructedBy, String Currency) throws Throwable
        {
            String vObjPaymentOutBasicDetailsPage = Constants.TitanPaymentOutOR.getProperty("PaymentOutBasicDetailsPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutBasicDetailsPage, ""));
            LogCapture.info("1 of 2: Basic details page is visible..");

            String vObjInstructionBySearch = Constants.TitanPaymentOutOR.getProperty("InstructionBySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionBySearch, instructedBy));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionBySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionBySearch, "enter"));
            LogCapture.info("Instructed By: " + instructedBy + " is selected..");

            String vObjCurrencyDropdownArrow = Constants.TitanPaymentOutOR.getProperty("CurrencyDropdownArrow");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyDropdownArrow, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCurrencyDropdownArrow, ""));
            Constants.key.pause("3", "");
            String vObjCurrencySearch = Constants.TitanPaymentOutOR.getProperty("CurrencySearch");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCurrencySearch, Currency));
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjCurrencySearch, "enter"));
            LogCapture.info("Currency selected is: " + Currency);

            String vObjclickOnMoneyTech = Constants.TitanPaymentOutOR.getProperty("ClickonMoneyTech");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjclickOnMoneyTech, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjclickOnMoneyTech, ""));

            Constants.key.pause("3", "");
            String vObjBasicDetailsPageNextButton = Constants.TitanPaymentOutOR.getProperty("BasicDetailPageNextBtn");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBasicDetailsPageNextButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBasicDetailsPageNextButton, ""));
            LogCapture.info("Clicking on Next button....");
        }

    @And("^user is click on newly Added instruction number$")
    public void userIsClickOnNewlyAddedInstructionNumber() throws Exception {
        for (int i = 1; i <= 25; i++) {
            String InstNumber = "//tbody[@id='CAD']//tr[" + i + "]//td[5]";
            String ExecuteButton = "//tbody[@id='CAD']//tr[" + i + "]//td[6]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(InstNumber, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ExecuteButton, ""));
            String ActInstructionNumber = Constants.driver.findElement(By.xpath(InstNumber)).getText();
            String ActExecuteButton = Constants.driver.findElement(By.xpath(ExecuteButton)).getText();
            if (ActInstructionNumber.equals(InstructionNumber)) {

                Assert.assertEquals("PASS", Constants.key.click(InstNumber, ""));
                Assert.assertEquals("PASS", Constants.key.pause("1", ""));
                LogCapture.info("User Click on newly created Instruction number " + ActInstructionNumber + "...");
                Assert.assertEquals("PASS", Constants.key.pause("3", ""));
                String vOjbExecuteConflictYes = Constants.CreateFxTicketOR.getProperty("ExecuteConflictYes");
                Assert.assertEquals("PASS", Constants.key.click(vOjbExecuteConflictYes, ""));
                Constants.key.navigateSubMenu(vOjbExecuteConflictYes, "");
                break;

            }
        }
    }

    @When("^User enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click login button$")
    public void userEnterUserNamePasswordAndClickLoginButton(String userName, String password) throws Throwable {
        Assert.assertEquals("PASS", Constants.key.AcceptCookies());
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.PFXOR.getProperty("FCG_Username");
        String vObjPass = Constants.PFXOR.getProperty("FCG_Password");
        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.PFXOR.getProperty("LoginButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLoginButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
        Constants.key.pause("5", "");

        boolean vDashboardHiMessage = false;
        String vObjDashboardHiMessage = Constants.PFXOR.getProperty("DashboardHiMessage");
        if (Constants.key.VisibleConditionWait(vObjDashboardHiMessage, "").equalsIgnoreCase("PASS")) {
            vDashboardHiMessage = Constants.driver.findElement(By.xpath(vObjDashboardHiMessage)).isDisplayed();
            LogCapture.info("Dashboard visible = " + vDashboardHiMessage);
        }
        if (vDashboardHiMessage) {
            LogCapture.info("Dashboard is visible...");
        } else {
            try {
                String vObjPINRequiredMessage = Constants.PFXOR.getProperty("PINRequiredMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPINRequiredMessage, ""));
                LogCapture.info("User Login requires OTP...");
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                LogCapture.info("Entering pin for Login......................");
                String vEnterPin = Constants.PFXOR.getProperty("EnterPinTextBox");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vEnterPin, ""));
                Assert.assertEquals("PASS", Constants.key.Enter_OTP(vEnterPin, "54321"));
                Assert.assertEquals("PASS", Constants.key.pause("3", ""));
                LogCapture.info("Clicked on confirm button for Login................");
                String vConfirmOTP = Constants.PFXOR.getProperty("ConfirmOTP");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vConfirmOTP, ""));
                Assert.assertEquals("PASS", Constants.key.click(vConfirmOTP, ""));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                LogCapture.info("Pin Entered...");
            } catch (Exception e) {
                LogCapture.info("User logged in without OTP...");
            }
        }
    }

    @Then("^User landed on (English|French|Norge|Swedish) Dashboard page successfully$")
    public void userLandedOnEnglishDashboardPageSuccessfully(String lang) throws Exception {
        LogCapture.info(lang + " Dashboard loading ......");
        if (lang.equalsIgnoreCase("English")) {
            Constants.key.pause("1", "");
            String vobjectDashboard = Constants.PFXOR.getProperty("DashboardORText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Check the exchange rate"));
        }
//        else if (lang.equalsIgnoreCase("French")) {
//            Constants.key.pause("4", "");
//            String vobjectDashboard = Constants.PFXOR.getProperty("DashboardORFrenchText");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
//            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Vérifiez le taux de change"));
//        } else if (lang.equalsIgnoreCase("Norge")) {
//            Constants.key.pause("4", "");
//            String vobjectDashboard = Constants.FrenchDashboardOR.getProperty("DashboardORNorgeText");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
//            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Sjekk vekslingskursen"));
//        } else if (lang.equalsIgnoreCase("")) {
//            Constants.key.pause("4", "Swedish");
//            String vobjectDashboard = Constants.FrenchDashboardOR.getProperty("DashboardORSwedishText");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
//            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Kontrollera växelkursen"));
//        }

    }
    @And("^User Clicks on (Create new Rate Alert|Transfer|Top up your wallet|Our Bank Details|Add recipient|Add GBP|Send GBP|Bank Details|Profile Management|Logout|Profile DropDown|save|Send EUR|Top Up Balance|Help|Live Chat|Chat Now|Close Chat|No, take me back to chat|Yes, I'm done|Chat Close|Save Chat|Nos coordonnées bancaires|Send CAD) Button$")
    public void userClicksOnCreateNewRateAlertButton(String button) throws Exception {
        Constants.key.pause("3", "");

        if (button.equals("Create new Rate Alert")) {
            LogCapture.info("User clicking " + button + " button...");
            String vNewRateAlertButton = Constants.PFXOR.getProperty("CrNewRateButton");
            Assert.assertEquals("PASS", Constants.key.click(vNewRateAlertButton, ""));
        } else if (button.equals("Transfer")) {
            LogCapture.info("User clicking " + button + " button...");
            String vTransferButton = Constants.PFXOR.getProperty("TransferButton");
            Assert.assertEquals("PASS", Constants.key.click(vTransferButton, ""));
        } else if (button.equals("Top up your wallet")) {
            LogCapture.info("User clicking " + button + " button...");
            String vTopUpButton = Constants.PFXOR.getProperty("TopUpButton");
            Assert.assertEquals("PASS", Constants.key.click(vTopUpButton, ""));
        } else if (button.equals("Our Bank Details")) {
            LogCapture.info("User clicking " + button + " button...");
            String vOurBankDetailButton = Constants.PFXOR.getProperty("OurBankDetailsButton");
            Assert.assertEquals("PASS", Constants.key.click(vOurBankDetailButton, ""));
        } else if (button.equals("Add recipient")) {
            LogCapture.info("User clicking " + button + " button...");
            String vAddRecipientButton = Constants.PFXOR.getProperty("AdRicpButton");
            Assert.assertEquals("PASS", Constants.key.click(vAddRecipientButton, ""));
        } else if (button.equals("Add GBP")) {
            LogCapture.info("User clicking " + button + " button...");
            String vAddGBPButton = Constants.PFXOR.getProperty("AddGBP");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vAddGBPButton, ""));
        } else if (button.equals("Send GBP")) {
            LogCapture.info("User clicking " + button + " button...");
            String vSendGBP = Constants.PFXOR.getProperty("SendGBP");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vSendGBP, ""));
        } else if (button.equals("Send EUR")) {
            LogCapture.info("User clicking " + button + " button...");
            String vSendEUR = Constants.PFXOR.getProperty("SendEUR");
            Assert.assertEquals("PASS", Constants.key.click(vSendEUR, ""));
        } else if (button.equals("Bank Details")) {
            LogCapture.info("User clicking " + button + " button...");
            String vBankDetails = Constants.PFXOR.getProperty("BankDetails");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBankDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBankDetails, ""));
        } else if (button.equals("Profile Management")) {
            LogCapture.info("User clicking " + button + " button...");
            Constants.key.pause("2", "");
            String vProfileManagementButton = Constants.PFXOR.getProperty("ProfileManagementButton");
            // Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vProfileManagementButton, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vProfileManagementButton, ""));
        } else if (button.equals("Logout")) {
            LogCapture.info("User clicking " + button + " button...");
            String vLogoutButton = Constants.PFXOR.getProperty("LogoutButton");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vLogoutButton, ""));
        } else if (button.equals("Profile DropDown")) {
            LogCapture.info("User clicking " + button + " button...");
            String vUserDD = Constants.PFXOR.getProperty("UserDD");
            //Assert.assertEquals("PASS", Constants.key.visibleConditionWait(vUserDD, ""));
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vUserDD, ""));
        } else if (button.equals("save")) {
            LogCapture.info("User clicking " + button + " button...");
            String vSaveButton = Constants.PFXOR.getProperty("SaveButton");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vSaveButton, ""));
        } else if (button.equals("Top Up Balance")) {
            LogCapture.info("User clicking " + button + " button...");
            String vTopUpButton = Constants.PFXOR.getProperty("TopUpWalletLink");
            Assert.assertEquals("PASS", Constants.key.click(vTopUpButton, ""));
        } else if (button.equals("Help")) {
            Constants.key.pause("10", "");
            LogCapture.info("User clicking " + button + " button...");
            String vHelpButton = Constants.PFXOR.getProperty("HelpLink");
            Assert.assertEquals("PASS", Constants.key.click(vHelpButton, ""));
        } else if (button.equals("Live Chat")) {
            Constants.key.pause("5", "");
            LogCapture.info("User clicking " + button + " button...");
            String vObjLiveChatButton = Constants.PFXOR.getProperty("LiveChatLink");
            Assert.assertEquals("PASS", Constants.key.click(vObjLiveChatButton, ""));
        } else if (button.equals("Chat Now")) {
            LogCapture.info("User clicking " + button + " button...");
            String vChatNowButton = Constants.PFXOR.getProperty("ChatNowButton");
            Assert.assertEquals("PASS", Constants.key.click(vChatNowButton, ""));
            Constants.key.pause("10", "");
        } else if (button.equals("Close Chat")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjCloseChatButton = Constants.PFXOR.getProperty("CloseChatBox");
            Assert.assertEquals("PASS", Constants.key.click(vObjCloseChatButton, ""));
            Constants.key.pause("10", "");
        } else if (button.equals("No, take me back to chat")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjNoChatCloseOption = Constants.PFXOR.getProperty("NoChatCloseOption");
            Assert.assertEquals("PASS", Constants.key.click(vObjNoChatCloseOption, ""));
            Constants.key.pause("5", "");
        } else if (button.equals("Yes, I'm done")) {
            Constants.key.pause("5", "");
            LogCapture.info("User clicking " + button + " button...");
            String vObjYesChatCloseOption = Constants.PFXOR.getProperty("YesChatCloseOption");
            Assert.assertEquals("PASS", Constants.key.click(vObjYesChatCloseOption, ""));
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.ChatFileOperation("delete", "transcript"));
        } else if (button.equals("Chat Close")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjCloseChatChatCloseOption = Constants.PFXOR.getProperty("CloseChatChatCloseOption");
            Assert.assertEquals("PASS", Constants.key.click(vObjCloseChatChatCloseOption, ""));
            Constants.key.pause("5", "");
        } else if (button.equals("Save Chat")) {
            LogCapture.info("User clicking " + button + " button...");
            String vObjSaveChatChatCloseOption = Constants.PFXOR.getProperty("SaveChatChatCloseOption");
            Assert.assertEquals("PASS", Constants.key.click(vObjSaveChatChatCloseOption, ""));
            Constants.key.pause("5", "");
        } else if (button.equals("Nos coordonnées bancaires")) {
            LogCapture.info("User clicking " + button + " button...");
            Constants.key.pause("5", "");
            String vObjOurBankDetailsButtonFrench = Constants.PFXOR.getProperty("OurBankDetailsButtonFrench");
            LogCapture.info("User clicking " + vObjOurBankDetailsButtonFrench + " button...");
            Assert.assertEquals("PASS", Constants.key.click(vObjOurBankDetailsButtonFrench, ""));
            Constants.key.pause("5", "");
        } else if (button.equals("Send CAD")) {
            LogCapture.info("User clicking " + button + " button...");
            String vSendCAD = Constants.PFXOR.getProperty("SendCAD");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vSendCAD, ""));
        }
        Constants.key.pause("5", "");
    }

    @Then("^User is navigated to (New Rate Alert|Make Transfer|Top up Wallet|Our Bank Account Details|Add your recipient|Top up wallet|Transfer|Your transfer details|getPersonalDetails|Delete Pop Up|Our bank account details|Your Transfer Details|Nos coordonnées bancaires|Activity) Page$")
    public void userIsNavigatedToNewRateAlertPage(String page) throws Exception {
        if (page.equals("New Rate Alert")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vNewRateALertTitle = Constants.PFXOR.getProperty("NewrateAlertTitle");
            Assert.assertEquals("PASS", Constants.key.verifyText(vNewRateALertTitle, "New rate alert"));
        } else if (page.equals("Make Transfer")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vMakeTransferHeader = Constants.PFXOR.getProperty("TransferPageHeading");
            Assert.assertEquals("PASS", Constants.key.verifyText(vMakeTransferHeader, "Transfer"));
        } else if (page.equals("Top up Wallet")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vTopUpWalletPgHeader = Constants.PFXOR.getProperty("TopUpWalletHeader");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vTopUpWalletPgHeader, "Top up wallet"));
        } else if (page.equals("Our Bank Account Details")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vOBAD = Constants.PFXOR.getProperty("OurBankAccountDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vOBAD, "Our Bank Account Details"));
            //Constants.key.pause("10","");
        } else if (page.equals("Nos coordonnées bancaires")) {
            LogCapture.info("User navigating to " + page + " page...");
            Constants.key.pause("4", "");
            String vOBADF = Constants.PFXOR.getProperty("OurBankAccountDetailsHeaderFrench1");
            Assert.assertEquals("PASS", Constants.key.exist(vOBADF, "Nos coordonnées bancaires"));
        } else if (page.equals("Add your recipient")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vAUR = Constants.PFXOR.getProperty("AddYourRecipientPage");
            Assert.assertEquals("PASS", Constants.key.verifyText(vAUR, "Add your recipient"));
        } else if (page.equals("Top up wallet")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vBuyCr = Constants.PFXOR.getProperty("TopUpWalletPage");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBuyCr, "Top up wallet"));
        } else if (page.equals("Transfer")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vTH = Constants.PFXOR.getProperty("TransferPageHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vTH, "Transfer"));
        } else if (page.equals("Your transfer details")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vYTDSendNote = Constants.PFXOR.getProperty("YTDSendNote");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vYTDSendNote, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vYTDSendNote, "How much do you need to send?"));
        } else if (page.equals("getPersonalDetails")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vProfileManagementPageHeader = Constants.PFXOR.getProperty("ProfileManagementPageHeader");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vProfileManagementPageHeader, "Your profile"));
        } else if (page.equals("Delete Pop Up")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vDeletePopUpTitle = Constants.PFXOR.getProperty("DeletePopUpTitle");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vDeletePopUpTitle, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vDeletePopUpTitle, "Do you want to delete this rate alert?"));
        } else if (page.equals("Your Transfer Details")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vYTDSendNote = Constants.PFXOR.getProperty("YTDSendNote");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vYTDSendNote, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vYTDSendNote, "Tell us some information about your transfer, and how much you’re looking to send."));
        } else if (page.equals("Our bank account details")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vOBAD = Constants.PFXOR.getProperty("CD_OurBankAccountDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.verifyText(vOBAD, "Our bank account details"));
        } else if (page.equals("Activity")) {
            LogCapture.info("User navigating to " + page + " page...");
            String vObjActivityPage = Constants.PFXOR.getProperty("ActivityTitle");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjActivityPage, "Activity"));
        }
    }
    @When("^User selects Payment currency \"(.*?)\" Select wallet \"(.*?)\"$")
    public void user_selects_Payment_currency_Select_wallet(String payCurrency, String selectWallet) throws Throwable {
        LogCapture.info("Selecting Payment Curreny and Wallet......");
        String vObjPaymentCurrency = Constants.PFXOR.getProperty("PaymentCurrency");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentCurrency, ""));
        String vObjPaySearchCurrency = Constants.PFXOR.getProperty("PayCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPaySearchCurrency, payCurrency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPaySearchCurrency, "enter"));
        String vObjSelectWallet = Constants.PFXOR.getProperty("SelectWallet");
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectWallet, ""));
        Constants.key.pause("2", "");
        String vObjBuySearchCurrency = Constants.PFXOR.getProperty("BuyCurrencySearch");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuySearchCurrency, selectWallet));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjBuySearchCurrency, "enter"));

    }
    @When("^User enters (Payment|Wallet) currency Amount \"(.*?)\" and clicks continue button$")
    public void user_enters_Payment_currency_Amount_and_clicks_countinue_button(String Currency, String amount) throws Throwable {
        LogCapture.info("Entering Currency and clicking continue button....");
        if (Currency.equals("Payment")) {
            String vObjPayCurrencyAMT = Constants.PFXOR.getProperty("PaymentCurrencyAMT");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPayCurrencyAMT, amount));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjPayCurrencyAMT, "enter"));
        } else if (Currency.equals("Wallet")) {
            String vObjWalletCurrencyAMT = Constants.PFXOR.getProperty("WalletCurrencyAMT");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjWalletCurrencyAMT, amount));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjWalletCurrencyAMT, "enter"));
        }
        String vObjButtonBuyCur1 = Constants.PFXOR.getProperty("ButtonBuyCur1");
        Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur1, ""));

    }
    @When("^User selects Payment method \"(.*?)\" and clicks on Continue button to (Make a transfer|Topup Wallet)$")
    public void user_selects_Payment_method_and_clicks_on_Continue_button(String method, String transaction) throws Throwable {
        LogCapture.info("Selecting Payment method.....");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjPaymentMethod = Constants.PFXOR.getProperty("PaymentMethod");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentMethod, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
        Constants.key.pause("5", "");

        if (transaction.equals("Make a transfer")) {
            if (method.equals("Balance")) {
                LogCapture.info("Payment method selected as " + method + "method for make a transfer");
                String vObjFromBalance = Constants.PFXOR.getProperty("FromBalance");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromBalance, ""));
                Constants.key.pause("5", "");
                String vObjButtonContinuetoSubmit = Constants.PFXOR.getProperty("ButtonContinuetoSubmit");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinuetoSubmit, ""));
            } else if (method.equals("DebitCard")) {
                LogCapture.info("Payment method selected as " + method + "method");
                String vObjFromDebitCard = Constants.PFXOR.getProperty("FromDebitCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromDebitCard, ""));
            } else if (method.equals("BankTransfer")) {
                LogCapture.info("Payment method selected as " + method + "method");
                String vObjFromBankTransfer = Constants.PFXOR.getProperty("FromBankTransfer");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromBankTransfer, ""));
                //Just for SG LE's Source of funds is additional field hence it is handled with below condition
                LogCapture.info("Source of Funds selected as Salary");
                String vObjSourceOfFunds = Constants.PFXOR.getProperty("SourceOfFunds");
                String vElementExist = Constants.key.verifyElementProperties(vObjSourceOfFunds, "visible");
                if (vElementExist.equals("PASS")) {
                    Assert.assertEquals("PASS", Constants.key.selectList(vObjSourceOfFunds, "Salary"));

                } else {
                }
                String vObjButtonContinuetoSubmit = Constants.PFXOR.getProperty("ButtonContinuetoSubmit");
                Constants.key.pause("3", "");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinuetoSubmit, ""));
            } else if (method.equals("Wallet")) {
                LogCapture.info("Payment method selected as " + method + "method for make a transfer");
                String vObjFromWallet = Constants.PFXOR.getProperty("FromWallet");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromWallet, ""));
                String vObjButtonContinuetoSubmit = Constants.PFXOR.getProperty("ButtonContinuetoSubmit");
                Constants.key.pause("3", "");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinuetoSubmit, ""));
            }
        } else if (transaction.equals("Topup Wallet")) {
            if (method.equals("Balance")) {
                LogCapture.info("Payment method selected as " + method + "method for topup wallet");
                String vObjFromBalance = Constants.PFXOR.getProperty("FromBalance");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromBalance, ""));
                String vObjButtonBuyCur2 = Constants.PFXOR.getProperty("ButtonBuyCur2");
                Constants.key.pause("3", "");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur2, ""));
            } else if (method.equals("DebitCard")) {
                LogCapture.info("Payment method selected as " + method + "method");
                String vObjFromDebitCard = Constants.PFXOR.getProperty("FromDebitCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjFromDebitCard, ""));
            } else if (method.equals("BankTransfer")) {
                LogCapture.info("Payment method selected as " + method + "method");
                String vObjFromBankTransfer = Constants.PFXOR.getProperty("FromBankTransfer");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFromBankTransfer, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjFromBankTransfer, ""));
                //Just for SG LE's Source of funds is additional field hence it is handled with below condition
                LogCapture.info("Source of Funds selected as Salary");
                String vObjSourceOfFunds = Constants.PFXOR.getProperty("SourceOfFunds");
                String vElementExist = Constants.key.verifyElementProperties(vObjSourceOfFunds, "visible");
                if (vElementExist.equals("PASS")) {
                    Assert.assertEquals("PASS", Constants.key.selectList(vObjSourceOfFunds, "Salary"));

                }
                String vObjButtonBuyCur2 = Constants.PFXOR.getProperty("ButtonBuyCur2");
                Constants.key.pause("2", "");
                Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur2, ""));
            }

        }
        Constants.key.pause("5", "");
    }
    @When("^User adds (temporary|new) debit card details Card Type \"([^\"]*)\" name on the card \"([^\"]*)\" card number \"([^\"]*)\" valid from \"([^\"]*)\" Ends \"([^\"]*)\" CVV \"([^\"]*)\"$")
    public void user_adds_temporary_debit_card_details_Card_Type_name_on_the_card_card_number_valid_from_Ends_CVV(String page, String cardtype, String name, String number, String from, String ends, String cvv) throws Throwable {
        String vObjCardTypes = "//*[contains(text(),'" + cardtype + "')]";
        String vObjCardName = "//*[contains(text(),'" + name + "')]";
        String vObjCardFirstNumbers = "//*[contains(text(),'" + number.substring(0, 4) + "')]";
        String vObjCardLastNumbers = "//*[contains(text(),'" + number.substring(8, 12) + "')]";

        if (page.equals("new")) {
            if ((Constants.key.notexist(vObjCardTypes, "").equalsIgnoreCase("PASS")) || (Constants.key.notexist(vObjCardName, "").equalsIgnoreCase("PASS")) || (Constants.key.notexist(vObjCardFirstNumbers, "").equalsIgnoreCase("PASS")) || (Constants.key.notexist(vObjCardLastNumbers, "").equalsIgnoreCase("PASS"))) {
                String vObjAddNewCardLink = Constants.PFXOR.getProperty("AddNewCardLink");
                Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCardLink, ""));
            } else {
                Assume.assumeTrue(" is skipped", false);
            }


        } else if (page.equals("temporary")) {
            String vObjCardList = Constants.PFXOR.getProperty("CardList");
            if (Constants.driver.findElement(By.xpath(vObjCardList)).isDisplayed()) {
                Assert.assertEquals("PASS", Constants.key.click(vObjCardList, ""));
                String vObjAddNewCard = Constants.PFXOR.getProperty("AddNewCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCard, ""));
                LogCapture.info("Clicking on Save card for future use checkbox...");
                String vObjSaveCardCheckbox = Constants.PFXOR.getProperty("SaveCardForFutureUseCheckbox");
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveCardCheckbox, ""));
                LogCapture.info("Clicked on Save card for future use checkbox...");


            } else {
            }
        }
        String vObjCardType = Constants.PFXOR.getProperty("CardType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCardType, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCardType, ""));
        String vObjSearchField = Constants.PFXOR.getProperty("SearchField");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchField, cardtype));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchField, "enter"));
        String vObjNameOnCard = Constants.PFXOR.getProperty("NameOnCard");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameOnCard, name));
        String vObjCardNumber = Constants.PFXOR.getProperty("CardNumber");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardNumber, number));
        String vObjStartDate = Constants.PFXOR.getProperty("StartDate");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjStartDate, from));
        String vObjExpiryDate = Constants.PFXOR.getProperty("ExpiryDate");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjExpiryDate, ends));
        String vObjCVV = Constants.PFXOR.getProperty("CVV");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVV, cvv));
        LogCapture.info("User entered required details...");
    }
    @When("^User Checks the check box for Use the same as your contact address\\? and clicks on continue button to (Make a Transfer|Top up Wallet|Add New Card|For Debit Card Transfer)$")
    public void user_Checks_the_check_box_for_Use_the_same_as_your_contact_address_and_clicks_on_continue_button(String page) throws Throwable {
        String vObjSameBillingAddressCheckBox = Constants.PFXOR.getProperty("SameBillingAddressCheckBox");
        Assert.assertEquals("PASS", Constants.key.click(vObjSameBillingAddressCheckBox, ""));
        Constants.key.pause("5", "");
        if (page.equals("Make a Transfer")) {
            String vObjButtonContinuetoSubmit = Constants.PFXOR.getProperty("ButtonContinuetoSubmit");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjButtonContinuetoSubmit, ""));
            LogCapture.info("User Checked the check box for Use the same as your contact address...");
        } else if (page.equals("Top up Wallet")) {
            String vObjButtonBuyCur2 = Constants.PFXOR.getProperty("ButtonBuyCur2");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjButtonBuyCur2, ""));
            LogCapture.info("User Checked the check box for Use the same as your contact address...");
        } else if (page.equals("Add New Card")) {
            String vObjAddCardSaveButton = Constants.PFXOR.getProperty("AddCardSaveButton");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjAddCardSaveButton, ""));
            LogCapture.info("User Checked the check box for Use the same as your contact address...");
        } else if (page.equals("For Debit Card Transfer")) {
            String vObjAddCardSaveButton = Constants.PFXOR.getProperty("ButtonContinue");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjAddCardSaveButton, ""));
        }
    }
    @When("^User clicks on Confirm button after validating details entered$")
    public void user_clicks_on_Confirm_button_after_validating_details_entered() throws Throwable {
        LogCapture.info("Confirming validations.....");
        String vObjButtonPurchaseConfirmation = Constants.PFXOR.getProperty("ButtonPurchaseConfirmation");
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjButtonPurchaseConfirmation, ""));
        Constants.key.pause("2", "");
    }
    @And("^User is navigated to World Pay site for submitting the (\\d+)d transaction$")
    public void userIsNavigatedToWorldPaySiteForSubmittingTheDTransaction(int arg0) throws Exception {
        Constants.key.pause("8", "");
        String vObjWorldPaySubmitButton = Constants.PFXOR.getProperty("WorldPaySubmitButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjWorldPaySubmitButton, ""));
    }
    @And("^User navigate to (FCG|TORFX|TORFXOZ|Ramsdens|TMO|CD|TORAU|TORSINGAPORE|HL|NGOPAdmin|None|CDLive|CD Landing|CD Calypso) portal \"([^\"]*)\"$")
    public void user_navigate_to_TORFX_portal(String application, String vUrl) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (application.equals("TORFX")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("FCG")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("TORFXOZ")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("Ramsdens")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("TMO")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("CD")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            LogCapture.info("URL Values is == " + url);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("TORAU")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("TORSINGAPORE")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("HL")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("NGOPAdmin")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("CDLive")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
        } else if (application.equals("CD Landing")) {
            LogCapture.info("Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            Assert.assertEquals("PASS", Constants.key.AcceptCookies());
        } else if (application.equals("CD Calypso")) {
            LogCapture.info("CD Calypso Portal is loading....");
            String url = Constants.CONFIG.getProperty(vUrl);
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            LogCapture.info(url);
            handleCookies(); // Handle cookies for all applications
        } else {
            LogCapture.info("Organization not found");
        }
    }
    private void handleCookies() {
        String vCookies_Accept = Constants.CalypsologinPageOR.getProperty("Cookies_Accept");
        LogCapture.info("Checking for Cookies Accept button using XPath: " + vCookies_Accept);
        WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(10));
        try {
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(vCookies_Accept)));
            WebElement cookiesAcceptButton = Constants.driver.findElement(By.xpath(vCookies_Accept));
            cookiesAcceptButton.click();
            LogCapture.info("Cookies Accepted..");
        } catch (Exception e) {
            LogCapture.info("Accept Cookies pop-up Not visible..");
        }
    }
    @And("^User should successfully be able top up wallet and click on Back to dashboard link$")
    public void userShouldSuccessfullyBeAbleTopUpWalletAndClickOnBackToDashboardLink() throws Exception {
        Constants.key.pause("2", "");
        String vObjInstructionReferenceNumber = Constants.PFXOR.getProperty("InstructionReferenceNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionReferenceNumber, ""));
        String InstructionReferenceNumber= Constants.key.getText(vObjInstructionReferenceNumber, "");
        String InstructionReference =InstructionReferenceNumber.split("-")[1];
        String NumberOfZeros="0";
        for(int i=1;i<(9-InstructionReference.length());i++){
            NumberOfZeros=NumberOfZeros+"0";
        }
        Constants.InstructionNumber1=InstructionReferenceNumber.split("-")[0]+"-"+NumberOfZeros+InstructionReferenceNumber.split("-")[1];
        LogCapture.info("InstructionNumber1"+InstructionNumber1);
    }

    @Then("^User gets InstructionIdReference$")
    public void userGetsInstructionIdReferenceFromEnvironment() throws Throwable {
        Map <String, String> result = ReusableMethod.getSqlQueryResult("InstructionIdReference", paymentLifeCycleID);
//        String ID=Constants.key.VerifyDBDetails(TitanEnvironment, paymentLifeCycleID, "Find InstructionIdReference");
        Constants.CustomerInstructionID=result.get("ID");
        Constants.KafkaMessageCDID =ID;
    }


    @And("^User adds dynamic values for Clear fund from Atlas \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userAddsDynamicValuesForClearFundFromAtlas(String trx_type, String Action, String TANNumber) throws Throwable {
//        String Id=CustomerPaymentInID;
//
//        if(CustomerPaymentInID.length()<9){
//             int NoOfZeros=9-CustomerPaymentInID.length();
//             for (int i=1;i<=NoOfZeros;i++){
//                Id=0+Id;
//            }
//        }
//        String TradeContractNumber=TANNumber+"-"+Id;

        Map <String, String> result = ReusableMethod.getSqlQueryResult("CustomerPaymentOutID", CustomerInstructionID);
        Constants.TransactionReferenceNumber = result.get("TransactionReferenceNumber");
        String AtlasTransactionID=TransactionReferenceNumber+"_3093349";
        String TradePaymentID = TransactionReferenceNumber.split("-")[1];

        DynamicValue.put("<trx_type>", trx_type);
        DynamicValue.put("<Action>", Action);
        DynamicValue.put("<AtlasTransactionID>",AtlasTransactionID );
        DynamicValue.put("<TradeContractNumber>", TransactionReferenceNumber);
        DynamicValue.put("<TradePaymentID>", TradePaymentID);
    }

    @Then("^User clicks on (Select|Transfer|Pay|Edit) link for relevant (CAD|EUR|GBP|NZD|USD|SGD) \"([^\"]*)\" recipient$")
    public void user_clicks_on_Select_link_for_relevant_CAD_recipent(String page, String type, String recipient) throws Throwable {

        LogCapture.info("Selecting Benificiary......");
        Constants.key.pause("3", "");

        // This Will click on Show More Button if button is visible on the Page
        String vRecipient_ShowMore = Constants.PFXOR.getProperty("Recipient_ShowMore");
        String vRecipientPage_ShowMore = Constants.PFXOR.getProperty("RecipientPage_ShowMore");
        if (Constants.key.exist(vRecipient_ShowMore, "").equalsIgnoreCase("PASS")) {
            LogCapture.info("Clicking on SeeMore Link ......");
            Assert.assertEquals("PASS", Constants.key.click(vRecipient_ShowMore, ""));
            Constants.key.pause("4", "");
        } else if (Constants.key.exist(vRecipientPage_ShowMore, "").equalsIgnoreCase("PASS")) {
            LogCapture.info("Clicking on SeeMore Link ......");
            Assert.assertEquals("PASS", Constants.key.click(vRecipientPage_ShowMore, ""));
            Constants.key.pause("4", "");
        }

        if (page.equals("Select")) {
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.SelectRecipient("", recipient));
        } else if (page.equals("Transfer")) {
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.RecipientTransfer("", recipient));
        } else if (page.equals("Pay")) {
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.RecipientPay("", recipient));
        } else if (page.equals("Edit")) {
            Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.RecipientEdit("", recipient));
        }
    }

    @When("^User selects you Pay \"(.*?)\" Amount \"(.*?)\"$")
    public void user_selects_you_Pay_Amount(String youPay, String amount) throws Throwable {
        LogCapture.info("Amount selection......");
        String vObjYouPay = Constants.PFXOR.getProperty("YouPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYouPay, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjYouPay, ""));
        String vObjYouPaySearch = Constants.PFXOR.getProperty("YouPaySearch");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjYouPaySearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjYouPaySearch, youPay));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjYouPaySearch, "enter"));
        String vObjSellInput = Constants.PFXOR.getProperty("SellInput");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellInput, amount));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSellInput, "enter"));

    }
     @And("^User selects Reason for this transfer \"([^\"]*)\" enters Recipient reference \"([^\"]*)\"$")
    public void userSelectsReasonForThisTransferEntersRecipientReference(String reason, String reference) throws Throwable {
        LogCapture.info("Reason for transfer and references.....");
        String vObjReasonForTransfer = Constants.PFXOR.getProperty("ReasonForTransfer");
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjReasonForTransfer, ""));
        String vObjReasonForTransferSearch = Constants.PFXOR.getProperty("ReasonForTransferSearch");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjReasonForTransferSearch, reason));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjReasonForTransferSearch, "enter"));
        String vObjRecipientReference = Constants.PFXOR.getProperty("RecipientReference");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjRecipientReference, reference));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjButtonContinue = Constants.PFXOR.getProperty("ButtonContinue");
        Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinue, ""));
    }
    @When("^User clicks on Confirm button after validating details entered for transfer$")
    public void user_clicks_on_Confirm_button_after_validating_details_entered_for_transfer() throws Throwable {
        // New method for mobile, desktop, tablet view
        String vObjConfirmButton = Constants.PFXOR.getProperty("ConfirmButton");

            LogCapture.info("Confirming post validations.....");
            Constants.key.pause("3", "");
            Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjConfirmButton, ""));
            LogCapture.info("Confirm button clicked...");

    }
    @Then("^User should successfully be able (make a transfer|) and click on (Back to dashboard|to activity|Back Activity|Back to activity|Your Activity) link$")
    public void user_should_sucessfully_be_able_make_a_transfer_and_click_on_Back_to_dashboard_link(String page, String back) throws Throwable {
        LogCapture.info("Transfer success Validation.....");
        Constants.key.pause("10", "");
        String vObjPaymentDetailsTab = Constants.PFXOR.getProperty("PaymentDetailsTab");
        if (Constants.key.verifyElementProperties(vObjPaymentDetailsTab, "visible").equalsIgnoreCase("PASS")) {
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentDetailsTab, ""));
            Constants.key.pause("2", "");
        }
        String vObjInstructionNumber = Constants.PFXOR.getProperty("InstructionReferenceNumber");
        Constants.FullInstructionNumber = driver.findElement(By.xpath(vObjInstructionNumber)).getText();
        Constants.InstructionReferenceNumber = FullInstructionNumber.split("-")[1];
        System.out.println("Instruction after split :: " + InstructionReferenceNumber);
        LogCapture.info("Successfully captured instruction reference number :: " + FullInstructionNumber);

        String InstructionReference =FullInstructionNumber.split("-")[1];
        String NumberOfZeros="0";
        for(int i=1;i<(9-InstructionReference.length());i++){
            NumberOfZeros=NumberOfZeros+"0";
        }
        Constants.InstructionNumber1=FullInstructionNumber.split("-")[0]+"-"+NumberOfZeros+FullInstructionNumber.split("-")[1];
        LogCapture.info("InstructionNumber is "+ InstructionNumber1);

    }

    @And("^User validates Save card checkbox for future use is (checked by default|not checked|checked)$")
    public void user_Validates_Save_Card_For_Future_Use_Checkbox_Is_Checked_By_Default(String boxCheck) throws Throwable {
        if (boxCheck.equalsIgnoreCase("checked by default")) {
            String vObjSaveCardCheckbox = Constants.PFXOR.getProperty("SaveCardForFutureUseCheckbox");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjSaveCardCheckbox, "selected"));
            LogCapture.info("User validates Save card for future use Checkbox is checked by default...");
        } else if (boxCheck.equalsIgnoreCase("not checked")) {
            String vObjSaveCardCheckbox = Constants.PFXOR.getProperty("SaveCardForFutureUseCheckbox");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveCardCheckbox, ""));
            LogCapture.info("User unchecks Save Card for future use checkbox ...");
        }
    }
    @And("^User Click on (Account details) tab$")
    public void userClickOnAccountDetailsTab(String tab) throws Exception {
        if (tab.equals("Account details")) {
            LogCapture.info("User clicking " + tab + " tab...");
            Constants.key.pause("3", "");
            String vAccountDetailsTab = Constants.PFXOR.getProperty("AccountDetailsTab");
            Assert.assertEquals("PASS", Constants.key.click(vAccountDetailsTab, ""));
        }

    }
    @And("^User validates that card is (added|not added) with Card Type \"([^\"]*)\" and name as \"([^\"]*)\" and card number as \"([^\"]*)\"$")
    public void userValidatesThatCardHasGotAddedWithCardTypeAndNameAs(String CardType, String Name, String usedcardno, String status) throws Throwable {
        LogCapture.info("User validating that Card has got saved or not...");
        if (status.equalsIgnoreCase("added")) {
            String vSavedCardTypeTopMost = Constants.PFXOR.getProperty("SavedCardTypeTopMost");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSavedCardTypeTopMost, CardType));
            String vSavedCardNameTopMost = Constants.PFXOR.getProperty("SavedCardNameTopMost");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSavedCardNameTopMost, Name));
            String vUsedCardNoXpath = "//*[contains(text(),'" + usedcardno + "')]";
            Assert.assertEquals("PASS", Constants.key.exist(vUsedCardNoXpath, ""));
            LogCapture.info("User validates that Card has got saved successfully...");
        } else if (status.equalsIgnoreCase("not added")) {
            String vUsedCardNoXpath = "//*[contains(text(),'" + usedcardno + "')]";
            Assert.assertEquals("PASS", Constants.key.notexist(vUsedCardNoXpath, ""));
            LogCapture.info("User validates that Card has not got saved...");
        }
    }

    @And("^User adds (Maestro|Visa Debit) debit card details Card Type \"([^\"]*)\" name on the card \"([^\"]*)\" card number \"([^\"]*)\" valid from \"([^\"]*)\" Ends \"([^\"]*)\" CVV \"([^\"]*)\" (if doesn't exist)$")
    public void userAddsNewDebitCardDetailsCardTypeNameOnTheCardCardNumberValidFromEndsCVVIfDoesnTExist(String page, String cardtype, String name, String number, String from, String ends, String cvv, String comment) throws Throwable {
        LogCapture.info("User Add Existing card if doesn't exist");
        String vExisting_card_list = Constants.PFXOR.getProperty("Existing_card_list");
        Constants.key.pause("3", "");
        if (Constants.key.exist(vExisting_card_list, "").equalsIgnoreCase("PASS")) {
            if (page.equalsIgnoreCase("Maestro") && comment.equalsIgnoreCase("if doesn't exist")) {
                String vExisting_Card_Mae = Constants.PFXOR.getProperty("Existing_Card_Mae");
                String vExisting_CardName_Mae = Constants.PFXOR.getProperty("Existing_CardName_Mae");
                String CardNameonApplication = Constants.key.getText(vExisting_CardName_Mae, "");
                if (Constants.key.notexist(vExisting_Card_Mae, "").equalsIgnoreCase("PASS") || !CardNameonApplication.equalsIgnoreCase(name)) {
                    String vObjAddNewCardLink = Constants.PFXOR.getProperty("AddNewCardLink");
                    Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCardLink, ""));
                    String vObjCardType = Constants.PFXOR.getProperty("CardType");
                    Assert.assertEquals("PASS", Constants.key.click(vObjCardType, ""));
                    String vObjSearchField = Constants.PFXOR.getProperty("SearchField");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchField, cardtype));
                    Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchField, "enter"));
                    String vObjNameOnCard = Constants.PFXOR.getProperty("NameOnCard");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameOnCard, name));
                    String vObjCardNumber = Constants.PFXOR.getProperty("CardNumber");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardNumber, number));
                    String vObjStartDate = Constants.PFXOR.getProperty("StartDate");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjStartDate, from));
                    String vObjExpiryDate = Constants.PFXOR.getProperty("ExpiryDate");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjExpiryDate, ends));
                    String vObjCVV = Constants.PFXOR.getProperty("CVV");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVV, cvv));
                    String vObjSameBillingAddressCheckBox = Constants.PFXOR.getProperty("SameBillingAddressCheckBox");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSameBillingAddressCheckBox, ""));
                    Constants.key.pause("5", "");
                    String vObjAddCardSaveButton = Constants.PFXOR.getProperty("AddCardSaveButton");
                    Constants.key.pause("3", "");
                    Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjAddCardSaveButton, ""));
                    String vObjAddCardSuccessMessage = Constants.PFXOR.getProperty("AddCardSuccessMessage");
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddCardSuccessMessage, ""));
                    Assert.assertEquals("PASS", Constants.key.exist(vObjAddCardSuccessMessage, ""));
                }
            } else if (page.equalsIgnoreCase("Visa Debit") && comment.equalsIgnoreCase("if doesn't exist")) {
                String vExisting_Card_Visa = Constants.PFXOR.getProperty("Existing_Card_Visa");
                String vExisting_CardName_Visa = Constants.PFXOR.getProperty("Existing_CardName_Visa");
                String CardNameonApplication = Constants.key.getText(vExisting_CardName_Visa, "");
                if (Constants.key.notexist(vExisting_Card_Visa, "").equalsIgnoreCase("PASS") || !CardNameonApplication.equalsIgnoreCase(name)) {
                    String vObjAddNewCardLink = Constants.PFXOR.getProperty("AddNewCardLink");
                    Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCardLink, ""));
                    String vObjCardType = Constants.PFXOR.getProperty("CardType");
                    Assert.assertEquals("PASS", Constants.key.click(vObjCardType, ""));
                    String vObjSearchField = Constants.PFXOR.getProperty("SearchField");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchField, cardtype));
                    Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjSearchField, "enter"));
                    String vObjNameOnCard = Constants.PFXOR.getProperty("NameOnCard");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNameOnCard, name));
                    String vObjCardNumber = Constants.PFXOR.getProperty("CardNumber");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCardNumber, number));
                    String vObjStartDate = Constants.PFXOR.getProperty("StartDate");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjStartDate, from));
                    String vObjExpiryDate = Constants.PFXOR.getProperty("ExpiryDate");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjExpiryDate, ends));
                    String vObjCVV = Constants.PFXOR.getProperty("CVV");
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVV, cvv));
                    String vObjSameBillingAddressCheckBox = Constants.PFXOR.getProperty("SameBillingAddressCheckBox");
                    Assert.assertEquals("PASS", Constants.key.click(vObjSameBillingAddressCheckBox, ""));
                    Constants.key.pause("5", "");
                    String vObjAddCardSaveButton = Constants.PFXOR.getProperty("AddCardSaveButton");
                    Constants.key.pause("3", "");
                    Assert.assertEquals("PASS", Constants.key.ClickIfEnable(vObjAddCardSaveButton, ""));
                    String vObjAddCardSuccessMessage = Constants.PFXOR.getProperty("AddCardSuccessMessage");
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddCardSuccessMessage, ""));
                    Assert.assertEquals("PASS", Constants.key.exist(vObjAddCardSuccessMessage, ""));
                }
            }
            String vBrandLogo = Constants.PFXOR.getProperty("BrandLogo");
            Assert.assertEquals("PASS", Constants.key.click(vBrandLogo, ""));
        }
    }

    @When("^User selects (Existing|New) (Visa|Maestro|Master||Visa Electron|Visa Debit|Debit Mastercard) card from the list$")
    public void user_selects_Existing_Visa_card_from_the_list(String type, String card) throws Throwable {
        String vObjExistingCardListDD = Constants.PFXOR.getProperty("ExistingCardListDD");
        Constants.key.pause("5", "");

        Assert.assertEquals("PASS", Constants.key.click(vObjExistingCardListDD, ""));
        if (type.equals("Existing")) {
            if (card.equals("Visa")) {
                String vObjExistingVisaCard = Constants.PFXOR.getProperty("ExistingVisaCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingVisaCard, ""));
            }

            else if (card.equals("Master")) {
                String vObjExistingMasterCard = Constants.PFXOR.getProperty("ExistingMasterCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingMasterCard, ""));
            }

            else if (card.equals("Visa Debit")) {
                String vObjExistingVisaDebitCard = Constants.PFXOR.getProperty("ExistingVisaDebitCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingVisaDebitCard, ""));
            } else if (card.equals("Debit Mastercard")) {
                String vObjExistingDebitMasterCard = Constants.PFXOR.getProperty("ExistingDebitMasterCard");
                Assert.assertEquals("PASS", Constants.key.click(vObjExistingDebitMasterCard, ""));
            }


        } else if (type.equals("New")) {
            String vObjAddNewCard = Constants.PFXOR.getProperty("AddNewCard");
            Assert.assertEquals("PASS", Constants.key.click(vObjAddNewCard, ""));
        }
    }

    @When("^User enters cvv \"([^\"]*)\" and clicks Continue button to (Make a Transaction|Top up Wallet)$")
    public void user_enters_cvv_and_clicks_Continue_button(String cvv, String page) throws Throwable {
        String vObjCVV = Constants.PFXOR.getProperty("CVV1");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjCVV, cvv));
        if (page.equals("Make a Transaction")) {
            String vObjButtonContinuetoSubmit = Constants.PFXOR.getProperty("ButtonContinuetoSubmit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjButtonContinuetoSubmit, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjButtonContinuetoSubmit, ""));
        } else if (page.equals("Top up Wallet")) {
            String vObjButtonBuyCur2 = Constants.PFXOR.getProperty("ButtonBuyCur2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjButtonBuyCur2, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjButtonBuyCur2, ""));
        }

    }

    // calypso StepDefination

    @Given("^User select (English|Spanish|Chinese|English_AIP|Chinese_AIP|English_DTAS|Chinese_DTAS) language$")
    public void userSelectEnglishlanguage(String language) throws Exception {
        LogCapture.info("language..." + language);
        Constants.key.pause("2", "");

        if (language.equals("English")) {
            LogCapture.info("User selecting English language...");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("English_language");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        } else if (language.equals("Spanish")) {
            LogCapture.info("User selecting Spanish language......");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("Spanish_language");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        } else if (language.equals("Chinese")) {
            LogCapture.info("User selecting Chinese language......");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("Chinese_language");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        } else if (language.equals("English_AIP")) {
            LogCapture.info("User selecting English language......");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("AIP_English_language");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        } else if (language.equals("Chinese_AIP")) {
            LogCapture.info("User selecting Chinese language......");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("AIP_Chinese_language");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        } else if (language.equals("English_DTAS")) {
            LogCapture.info("User selecting English language......");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("AIP_English_language");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        } else if (language.equals("Chinese_DTAS")) {
            LogCapture.info("User selecting Chinese language......");
            String vlanguage = Constants.CalypsologinPageOR.getProperty("AIP_Chinese_language");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vlanguage, ""));
        }
    }


    @When("^User enter Calypso UserName \"([^\"]*)\" password \"([^\"]*)\" and click login button$")
    public void userenterCalypsoUserNamepasswordandclickloginbutton(String UserName, String password) throws Exception {

        String vCalUserName = Constants.CONFIG.getProperty(UserName);
        String vCalPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.CalypsologinPageOR.getProperty("CalypsoUsername");
        Constants.key.pause("5", "");
        String vObjPass = Constants.CalypsologinPageOR.getProperty("CalypsoPassword");
        LogCapture.info("User Name " + vCalUserName + ", Password " + password + " is validated ....");
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vCalUserName));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vCalPassword));
        Constants.key.pause("2", "");
        LogCapture.info("Username and password entered...");
        String vObjLoginButton = Constants.CalypsologinPageOR.getProperty("CalypsoLoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
        if (!CONFIG.getProperty("browser").equalsIgnoreCase("FireFox")) {
            Constants.key.pause("8", "");
        }
        if (CONFIG.getProperty("browser").equalsIgnoreCase("FireFox")) {
            Constants.key.pause("13", "");
        }
        boolean vDashboardMessage = false;
        try {
            String vObjDashboardMessage = Constants.CalypsologinPageOR.getProperty("DashboardMessage");
            vDashboardMessage = Constants.driver.findElement(By.xpath(vObjDashboardMessage)).isDisplayed();
            LogCapture.info("Dashboard visible = " + vDashboardMessage);
        } catch (Exception e) {
            LogCapture.info("Dashboard NOT visible....");
        }
        if (vDashboardMessage) {
            LogCapture.info("Dashboard is visible...");
        } else {
            try {
                String vObjPINRequiredMessage = Constants.CalypsologinPageOR.getProperty("PINRequiredMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPINRequiredMessage, ""));
                LogCapture.info("User Login requires OTP...");
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                LogCapture.info("Entering pin for Login......................");
                String vObjOTP = Constants.CalypsologinPageOR.getProperty("EnterPinTextBoxLogin");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOTP, ""));
                Assert.assertEquals("PASS", Constants.key.Enter_OTP(vObjOTP, "54321"));
                Constants.key.pause("4", "");
                String vConfirmButton = Constants.CalypsologinPageOR.getProperty("ConfirmOTP");
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.click(vConfirmButton, ""));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                LogCapture.info("Pin Entered...");
            } catch (Exception e) {
                LogCapture.info("User logged in without OTP...");
            }
        }
    }

    @Then("^User landed on Calypso Dashboard page successfully$")
    public void user_landed_on_Calypso_Dashboard_page_successfully() throws Throwable {
        LogCapture.info("Calypso Dashboard loading ......");
        Constants.key.pause("5", "");
        String vobjectDashboard = Constants.CalypsologinPageOR.getProperty("CalypsoDashboardORText");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Make a transfer"));
    }

    @And("^Calypso User Clicks on (Rate alerts|Collection Accounts|Recipents|Dashboard|Batch|CDCFXEUBatchTab|Transactions|Forwards) Tab present on top$")
    public void calypso_User_Clicks_on_Rate_alerts_Tab_present_on_top(String tab) throws Throwable {
        LogCapture.info("Clicking on " + tab + "Tab");
        Constants.key.pause("5", "");
        if (tab.equals("Rate alerts")) {
            String vObjRateAletTab = Constants.CalypsologinPageOR.getProperty("RateAlertTab");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjRateAletTab, ""));
            String vObjRateAlertTitle = Constants.CalypsologinPageOR.getProperty("RateAlertTitle");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRateAlertTitle, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjRateAlertTitle, ""));
        } else if (tab.equals("Collection Accounts")) {
            String vObjCollectionAccountsTab = Constants.CalypsologinPageOR.getProperty("CollectionAccountTab");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCollectionAccountsTab, ""));
            String vObjCollectAcctTitle = Constants.CalypsologinPageOR.getProperty("CollectionAccountheader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCollectAcctTitle, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjCollectAcctTitle, ""));
        } else if (tab.equals("Recipents")) {
            LogCapture.info("User clicking On Recipents tab...");
            String vObjRecipentstab = Constants.CalypsologinPageOR.getProperty("RecipientsTab");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRecipentstab, ""));
            Constants.key.pause("5", "");
            Constants.key.click(vObjRecipentstab, "");
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjRecipentstab, ""));
//            Constants.key.click(vObjRecipentstab, "");
        } else if (tab.equals("Dashboard")) {
            LogCapture.info("User clicking On Dashboard tab...");
            String vObjDashboardtab = Constants.CalypsologinPageOR.getProperty("DashboardTab");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDashboardtab, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDashboardtab, ""));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        } else if (tab.equals("Batch")) {
            LogCapture.info("User clicking On Batch tab...");
            String vObjBatchtab = Constants.CalypsologinPageOR.getProperty("BatchTab");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBatchtab, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBatchtab, ""));
        } else if (tab.equals("CDCFXEUBatchTab")) {
            LogCapture.info("User clicking On Batch tab...");
            String vObjBatchtab = Constants.CalypsologinPageOR.getProperty("BatchTab");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBatchtab, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBatchtab, ""));
        } else if (tab.equals("Transactions")) {
            LogCapture.info("User clicking On Transactions tab...");
            String vObjTransactionTab = Constants.CalypsologinPageOR.getProperty("TransactionTab");
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionTab, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjTransactionTab, ""));
        } else if (tab.equals("Forwards")) {
            LogCapture.info("User clicking On Forwards tab...");
            String vObjForwardsTab = Constants.CalypsologinPageOR.getProperty("ForwardsTab");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjForwardsTab, ""));
        }
    }


    @Then("^User select (My accounts|Individual|Business|favourites|NonEtailerIndividual) recipent$")
    public void userselectMyaccountsrecipenttab(String recipentTab) throws Exception {
        Constants.key.pause("5", "");
        if (recipentTab.equals("My accounts")) {
            LogCapture.info("user selecting " + recipentTab + ".....");
            String vObjyouraccount = Constants.CalypsologinPageOR.getProperty("MyaccountsTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjyouraccount, ""));
        } else if (recipentTab.equals("Individual")) {
            LogCapture.info("user selecting " + recipentTab + ".....");
            String vObjIndividual = Constants.CalypsologinPageOR.getProperty("IndividualTab");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjIndividual, ""));
        } else if (recipentTab.equals("NonEtailerIndividual")) {
            LogCapture.info("user selecting " + recipentTab + ".....");
            String vObjIndividual = Constants.CalypsologinPageOR.getProperty("NonEtailerIndividualRadioBtn");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjIndividual, ""));
        } else if (recipentTab.equals("Business")) {
            LogCapture.info("user selecting " + recipentTab + ".....");
            String vObjBusiness = Constants.CalypsologinPageOR.getProperty("BusinessTab");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBusiness, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBusiness, ""));
        } else if (recipentTab.equals("favourites")) {
            LogCapture.info("user selecting " + recipentTab + ".....");
            String vObjfavourites = Constants.CalypsologinPageOR.getProperty("favouritesButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjfavourites, ""));
            Constants.key.pause("7", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjfavourites, ""));
        }
    }


    @Then("^User clicks on (add new|edit|pay|Add another) recipents button$")
    public void user_clicks_on_add_new_recipents_button(String button) throws Exception {
        if (button.equals("add new")) {
//            String vObjaddnewRecipents = Constants.CalypsologinPageOR.getProperty("AddRecipientBtn");
            String vObjaddnewRecipents = Constants.CalypsologinPageOR.getProperty("AddRecipientBtn2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjaddnewRecipents, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjaddnewRecipents, ""));
        } else if (button.equals("edit")) {
            Constants.key.pause("2", "");
            String vObjEditRecipents = Constants.CalypsologinPageOR.getProperty("Editbutton");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEditRecipents, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjEditRecipents, ""));
        } else if (button.equals("pay")) {
            Constants.key.pause("5", "");
            String vObjpayRecipents = Constants.CalypsologinPageOR.getProperty("PayButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjpayRecipents, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjpayRecipents, ""));
        } else if (button.equals("Add another")) {
            Constants.key.pause("3", "");
            String vObjAddAnotherRecipents = Constants.CalypsologinPageOR.getProperty("AddAnotherRecipients");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddAnotherRecipents, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjAddAnotherRecipents, "click"));
            Constants.key.pause("2", "");
            LogCapture.info("clicked on Add another recipient..");
        }
    }


    @Then("^User selects sell \"([^\"]*)\" amount \"([^\"]*)\"$")
    public void user_selects_sell_amount(String currency, String amount) throws Throwable {
        LogCapture.info("User selecting currency .....");
        String vObjsellCurrency = Constants.CalypsologinPageOR.getProperty("sellCurrency");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjsellCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjsellCurrency, ""));
        String vObjsellCurrencySearchBox = Constants.CalypsologinPageOR.getProperty("sellCurrencySearchBox");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjsellCurrencySearchBox, currency));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjsellCurrencySearchBox, "enter"));
        LogCapture.info("User entering amount .....");
        String vObjSellamount = Constants.CalypsologinPageOR.getProperty("sellAmount");
        Constants.key.clearText(vObjSellamount);
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellamount, amount));
        Constants.key.pause("4", "");
    }


//    @Then("^User selects Reason for this transfer \"([^\"]*)\" Click on continue button$")
//    public void user_selects_Reason_for_this_transfer_Click_on_continue_button(String reason) throws Throwable {
//        LogCapture.info("Reason for transfer....");
//        String vObjReasonForTransfer = Constants.CalypsologinPageOR.getProperty("reasonForPayment");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReasonForTransfer, ""));
//        ((JavascriptExecutor) Constants.driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
//        Constants.key.pause("5", "");
//        Assert.assertEquals("PASS", Constants.key.click(vObjReasonForTransfer, ""));
//        String vObjReasonForTransferSearch = Constants.CalypsologinPageOR.getProperty("reasonForPaymentSearch");
//        Constants.key.pause("3", "");
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjReasonForTransferSearch, reason));
//        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjReasonForTransferSearch, "enter"));
//        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
//        String vObjButtonContinue = Constants.CalypsologinPageOR.getProperty("ContinueBtnPay");
//        String countinuebtnn=Constants.key.VisibleConditionWait(vObjButtonContinue,"");
//        if(countinuebtnn.equalsIgnoreCase("PASS"))
//        {
//            Constants.key.click(vObjButtonContinue, "");
//        }
//        else {
//            String vObjButtonContinue2 = Constants.CalypsologinPageOR.getProperty("ContinueBtnPay2");
//            String vConfirmbutton = Constants.CalypsologinPageOR.getProperty("Confirmbutton");
//            String vObjButton = Constants.CalypsologinPageOR.getProperty("BtnPay");
//            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
//            Constants.key.click(vObjButton, "");
//            Constants.key.click(vConfirmbutton, "");
//            Constants.key.click(vObjButtonContinue2, "");
//            Constants.key.pause("3", "");
//        }
//    }

    @Then("^User selects Payment method for (Single|Multiple) user type \"([^\"]*)\"$")
    public void userSelectsPaymentMethodForSingleUserType(String User, String Method) throws Throwable {
        if (User.equalsIgnoreCase("Single")) {
            LogCapture.info("User clicks on Select Payment Method...");
            String vSelectMethod = Constants.CalypsologinPageOR.getProperty("Pmethod");
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vSelectMethod, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectMethod, ""));
            Constants.key.pause("8", "");
            Assert.assertEquals("PASS", Constants.key.click(vSelectMethod, ""));
            Constants.key.pause("8", "");
            if (Method.equalsIgnoreCase("type")) {
                LogCapture.info("Payment method selected as " + Method + " method");
                Assert.assertEquals("PASS", Constants.key.writeInInput(vSelectMethod, "Balances"));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vSelectMethod, "enter"));
            }
            String vType = Constants.CalypsologinPageOR.getProperty("PmSearchBox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vType, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vType, "Balance"));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vType, "enter"));
            Constants.key.pause("2", "");
        } else if (User.equalsIgnoreCase("Multiple")) {
            LogCapture.info("User clicks on Select Payment Method...");
            String vSelectMethod2 = Constants.CalypsologinPageOR.getProperty("Pmethod2");
            Constants.key.pause("8", "");
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vSelectMethod2, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectMethod2, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectMethod2, ""));
            String vType2 = Constants.CalypsologinPageOR.getProperty("PmSearchBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vType2, Method));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vType2, "enter"));
            Constants.key.pause("2", "");
        }
    }


    @And("^User clicks on Confirm button on page$")
    public void userClicksOnConfirmButtonOnPage() throws Exception {
        LogCapture.info("User clicks on Confirm button...");
        String vButton = Constants.CalypsologinPageOR.getProperty("ContinueBut");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vButton, ""));
        Constants.key.pause("5","");
        LogCapture.info("User Clicked on Continue button");
    }

    @Then("^User verify message and click on check box and click on confirm button$")
    public void userVerifyMessageAndClickOnCheckBoxAndClickOnConfirmButton() throws Exception {

        String vobj1 =  Constants.CalypsologinPageOR.getProperty("obj1");
        String vobj2 =  Constants.CalypsologinPageOR.getProperty("obj2");
        LogCapture.info(vobj1);
        LogCapture.info(vobj2);
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobj1, ""));
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobj2, ""));
        LogCapture.info("User landed on Payment details page");
        Constants.key.pause("5","");
    }

    @Then("^User navigate to payment confirmation page$")
    public void userNavigateToPaymentConfirmationPage() throws Exception {
        LogCapture.info("User Landed on payment confirmation page...");
        String vPconfirm = Constants.CalypsologinPageOR.getProperty("PaymentConformationPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPconfirm, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vPconfirm, "Payment details"));
        String vObjInstructionNumber = Constants.CalypsologinPageOR.getProperty("instructionNumberValue1");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumber, ""));
        InstructionReferenceNumber=Constants.key.getText(vObjInstructionNumber,"");
        String InstructionReference =InstructionReferenceNumber.split("-")[1];
        String NumberOfZeros="0";
        for(int i=1;i<(9-InstructionReference.length());i++){
            NumberOfZeros=NumberOfZeros+"0";
        }
        Constants.InstructionNumber1=InstructionReferenceNumber.split("-")[0]+"-"+NumberOfZeros+InstructionReferenceNumber.split("-")[1];


        LogCapture.info("Instrucation number is " +InstructionNumber1);

    }



    @And("^Calypso User is able to view (Wallet section|Fav recipient|Forwards tab) on Dashboard$")
    public void calypsoUserIsAbleToViewWalletSectionOnDashboard(String Target) throws Throwable {
        if (Target.equalsIgnoreCase("Wallet section")) {
            String vObjWalletSectionHeader = Constants.CalypsologinPageOR.getProperty("WalletSectionHeader");
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjWalletSectionHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjWalletSectionHeader, "visible"));
            LogCapture.info("Wallet section header is visible...");
        }
        if (Target.equalsIgnoreCase("Fav recipient")) {
            String vObjFavRecipientsHeader = Constants.CalypsologinPageOR.getProperty("FavRecipientsHeader");
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjFavRecipientsHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjFavRecipientsHeader, "visible"));
            LogCapture.info("Fav Recipient header is visible...");
        }
        if (Target.equalsIgnoreCase("Forwards tab")) {
            String vObjForwardsTab = Constants.CalypsologinPageOR.getProperty("ForwardsTab");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjForwardsTab, "visible"));
            LogCapture.info("Forwards Tab is visible on Dashboard header...");
        }
    }


//    @And("^Calypso User Clicks on (Rate alerts|Collection Accounts|Recipents|Dashboard|Batch|CDCFXEUBatchTab|Transactions|Forwards) Tab present on top$")
//    public void calypso_User_Clicks_on_Rate_alerts_Tab_present_on_top(String tab) throws Throwable {
//        LogCapture.info("Clicking on " + tab + "Tab");
//        Constants.key.pause("5", "");
//        if (tab.equals("Rate alerts")) {
//            String vObjRateAletTab = Constants.CalypsologinPageOR.getProperty("RateAlertTab");
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjRateAletTab, ""));
//            String vObjRateAlertTitle = Constants.CalypsologinPageOR.getProperty("RateAlertTitle");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRateAlertTitle, ""));
//            Assert.assertEquals("PASS", Constants.key.exist(vObjRateAlertTitle, ""));
//        } else if (tab.equals("Collection Accounts")) {
//            String vObjCollectionAccountsTab = Constants.CalypsologinPageOR.getProperty("CollectionAccountTab");
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCollectionAccountsTab, ""));
//            String vObjCollectAcctTitle = Constants.CalypsologinPageOR.getProperty("CollectionAccountheader");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCollectAcctTitle, ""));
//            Assert.assertEquals("PASS", Constants.key.exist(vObjCollectAcctTitle, ""));
//        } else if (tab.equals("Recipents")) {
//            LogCapture.info("User clicking On Recipents tab...");
//            String vObjRecipentstab = Constants.CalypsologinPageOR.getProperty("RecipientsTab");
//            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRecipentstab, ""));
//            Constants.key.pause("5", "");
//            Constants.key.click(vObjRecipentstab, "");
////            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjRecipentstab, ""));
////            Constants.key.click(vObjRecipentstab, "");
//        } else if (tab.equals("Dashboard")) {
//            LogCapture.info("User clicking On Dashboard tab...");
//            String vObjDashboardtab = Constants.CalypsologinPageOR.getProperty("DashboardTab");
//            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDashboardtab, ""));
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDashboardtab, ""));
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//        } else if (tab.equals("Batch")) {
//            LogCapture.info("User clicking On Batch tab...");
//            String vObjBatchtab = Constants.CalypsologinPageOR.getProperty("BatchTab");
//            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBatchtab, ""));
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBatchtab, ""));
//        } else if (tab.equals("CDCFXEUBatchTab")) {
//            LogCapture.info("User clicking On Batch tab...");
//            String vObjBatchtab = Constants.CalypsologinPageOR.getProperty("BatchTab");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBatchtab, ""));
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBatchtab, ""));
//        } else if (tab.equals("Transactions")) {
//            LogCapture.info("User clicking On Transactions tab...");
//            String vObjTransactionTab = Constants.CalypsologinPageOR.getProperty("TransactionTab");
//            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionTab, ""));
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjTransactionTab, ""));
//        } else if (tab.equals("Forwards")) {
//            LogCapture.info("User clicking On Forwards tab...");
//            String vObjForwardsTab = Constants.CalypsologinPageOR.getProperty("ForwardsTab");
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjForwardsTab, ""));
//        }
//    }



    @And("^User clicks on Drawdown link for relevant reference \"([^\"]*)\"$")
    public void userClicksOnDrawdownLinkForRelevantReference(String reference) throws Throwable {
        String drwDownButtonXpath = "//table [@class='no-fixed']//strong[text()='"+reference +"']//parent::span/parent::td/parent::tr//button";
        Constants.key.VisibleConditionWait(drwDownButtonXpath,"");
        Constants.key.scrollIntoViewElement(drwDownButtonXpath,"");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(drwDownButtonXpath, ""));
    }

    @And("^Choose a Payment type slider opens up on UI$")
    public void chooseAPaymentTypeSliderOpensUpOnUI() throws Throwable {
        String vChooseAPaymentType = Constants.CalypsologinPageOR.getProperty("ChooseAPaymentType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vChooseAPaymentType, ""));
        LogCapture.info("User is able to view ChooseAPaymentType Header..");
        String vPayIntoYourWallet = Constants.CalypsologinPageOR.getProperty("PayIntoYourWallet");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPayIntoYourWallet, ""));
        LogCapture.info("User is able to view PayIntoYourWallet title..");
        String vPayToNewOrExistingRecipient = Constants.CalypsologinPageOR.getProperty("PayToNewOrExistingRecipient");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPayToNewOrExistingRecipient, ""));
        LogCapture.info("User is able to view PayToNewOrExistingRecipient title..");
    }


    @And("^User clicks on (Pay into your wallet|Pay To New Or existing recipient|Pay to a new or existing recipient|Pay to a new or existing recipient for spanish) option for Forwards$")
    public void userClicksOnPayIntoYourWalletOptionForForwards(String paymentType) throws Exception {
        if (paymentType.equalsIgnoreCase("Pay into your wallet")) {
            String vObjPayIntoWalletBtn = Constants.CalypsologinPageOR.getProperty("PayIntoYourWallet");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayIntoWalletBtn, ""));
            LogCapture.info("User clicks on Pay into your wallet option");
            Constants.key.pause("2", "");
        } else if (paymentType.equalsIgnoreCase("Pay To New Or existing recipient")) {
            String vObjPayIntoWalletBtn = Constants.CalypsologinPageOR.getProperty("PayToNewOrExistingRecipient");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayIntoWalletBtn, ""));
            LogCapture.info("User clicks on Pay To New Or existing recipient option");
            Constants.key.pause("2", "");
        } else if (paymentType.equalsIgnoreCase("Pay to a new or existing recipient")) {
            String vObjPayIntoWalletBtn = Constants.CalypsologinPageOR.getProperty("PayToNewOrExistingRecipient");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayIntoWalletBtn, ""));
            LogCapture.info("User clicks on Pay To New Or existing recipient option");
            Constants.key.pause("2", "");
        } else if (paymentType.equalsIgnoreCase("Pay to a new or existing recipient for spanish")) {
            String vObjPayIntoWalletBtn = Constants.CalypsologinPageOR.getProperty("PayToNewOrExistingRecipientSpanish");
            Constants.key.VisibleConditionWait(vObjPayIntoWalletBtn, "");
            Assert.assertEquals("PASS", Constants.key.click(vObjPayIntoWalletBtn, ""));
            LogCapture.info("User clicks on Pay To New Or existing recipient option for spanish language");
        }
    }


//    @When("^User Enter the Amount \"([^\"]*)\" in YouPay textbox of (Recipient gets|)$")
//    public void userEnterTheAmountInYouPayTextboxOfRecipientGets(String amount, String journey) throws Throwable {
//        Constants.key.pause("3", "");
//        if (journey.equals("Recipient gets")) {
//            String vObjYouPay_Box = Constants.CalypsologinPageOR.getProperty("Youpay_box");
//            LogCapture.info("User clearing default amount if any.....");
//            Constants.key.clearText(vObjYouPay_Box);
//            Constants.key.pause("2", "");
//            LogCapture.info("User entered amount....." + amount);
//            String vObjSendInput = Constants.CalypsologinPageOR.getProperty("Sendinput");
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendInput, ""));
//            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSendInput, amount));
//            Constants.key.pause("3", "");
//        }
//    }


    @When("^User Enter the Amount \"([^\"]*)\" in YouPay textbox of (Recipient gets|)$")
    public void userEnterTheAmountInYouPayTextboxOfRecipientGets(String amount, String journey) throws Throwable {
        Constants.key.pause("3", "");
        if (journey.equals("Recipient gets")) {
            String vObjYouPay_Box = Constants.CalypsologinPageOR.getProperty("Youpay_box");
            LogCapture.info("User clearing default amount if any.....");
            Constants.key.clearText(vObjYouPay_Box);
            Constants.key.pause("2", "");
            LogCapture.info("User entered amount....." + amount);
            String vObjSendInput = Constants.CalypsologinPageOR.getProperty("Sendinput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendInput, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSendInput, amount));
            Constants.key.pause("3", "");
        }
    }

    @Then("^User selects Reason for this transfer \"([^\"]*)\" Click on continue button$")
    public void user_selects_Reason_for_this_transfer_Click_on_continue_button(String reason) throws Throwable {
        LogCapture.info("Reason for transfer....");
        String vObjReasonForTransfer = Constants.CalypsologinPageOR.getProperty("reasonForPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReasonForTransfer, ""));
        ((JavascriptExecutor) Constants.driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjReasonForTransfer, ""));
        String vObjReasonForTransferSearch = Constants.CalypsologinPageOR.getProperty("reasonForPaymentSearch");
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjReasonForTransferSearch, reason));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjReasonForTransferSearch, "enter"));
        Assert.assertEquals("PASS", Constants.key.pause("4", ""));
        String vObjButtonContinue = Constants.CalypsologinPageOR.getProperty("ContinueBtnPay");
        String countinuebtnn=Constants.key.VisibleConditionWait(vObjButtonContinue,"");
        if(countinuebtnn.equalsIgnoreCase("PASS"))
        {
            Constants.key.click(vObjButtonContinue, "");
        }
        else {
            String vObjButtonContinue2 = Constants.CalypsologinPageOR.getProperty("ContinueBtnPay2");
            String vConfirmbutton = Constants.CalypsologinPageOR.getProperty("Confirmbutton");
            String vObjButton = Constants.CalypsologinPageOR.getProperty("BtnPay");
            Assert.assertEquals("PASS", Constants.key.pause("3", ""));
            Constants.key.click(vObjButton, "");
            Constants.key.click(vConfirmbutton, "");
            Constants.key.click(vObjButtonContinue2, "");
            Constants.key.pause("3", "");
        }
    }


    @When("^User selects Calypso Payment method (for forwards|) \"([^\"]*)\" for new or existing$")
    public void userSelectsCalypsoPaymentMethodForForwardsForNewOrExisting(String page, String method) throws Throwable {
        String vObjSelectAPaymentMethod = null;
        if (page.equalsIgnoreCase("for forwards")) {
            vObjSelectAPaymentMethod = Constants.CalypsologinPageOR.getProperty("SelectAPaymentMethod");
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectAPaymentMethod, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectAPaymentMethod, ""));
        String vObjForwardsPaymentMethodSearchBox = Constants.CalypsologinPageOR.getProperty("ForwardsPaymentMethodSearchBox");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        if (method.equals("Wallet")) {
            LogCapture.info("Payment method selected as " + method + " method");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardsPaymentMethodSearchBox, "Balances"));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjForwardsPaymentMethodSearchBox, "enter"));
        } else if (method.equals("BankTransfer")) {
            LogCapture.info("Payment method selected as " + method + " method");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardsPaymentMethodSearchBox, "Other"));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjForwardsPaymentMethodSearchBox, "enter"));
        } else if (method.equals("DirectDebit")) {
            LogCapture.info("Payment method selected as " + method + " method");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardsPaymentMethodSearchBox, "Direct"));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjForwardsPaymentMethodSearchBox, "enter"));
        } else if (method.equals("AlreadySent")) {
            LogCapture.info("Payment method selected as " + method + " method");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjForwardsPaymentMethodSearchBox, "Other"));
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjForwardsPaymentMethodSearchBox, "downArrow"));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjForwardsPaymentMethodSearchBox, "enter"));
        }
    }

//    @And("^User clicks on Confirm button on page$")
//    public void userClicksOnConfirmButtonOnPage() throws Exception {
//        LogCapture.info("User clicks on Confirm button...");
//        String vButton = Constants.CalypsologinPageOR.getProperty("ContinueBut");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vButton, ""));
//        Assert.assertEquals("PASS", Constants.key.click(vButton, ""));
//        Constants.key.pause("5","");
//        LogCapture.info("User Clicked on Continue button");
//    }

    @Then("^User Should able to see the Payment has been successful message$")
    public void userShouldAbleToSeeThePaymentHasBeenSuccessfulMessage() throws Exception {
        String PaymentHasBeenSuccessfullMessage = Constants.CalypsologinPageOR.getProperty("PaymentHasBeenSuccessfullMessage");
        Assert.assertEquals("PASS", Constants.key.verifyText(PaymentHasBeenSuccessfullMessage, "Payment method"));
        LogCapture.info("User is able to see payment Successful Message ");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
    }

    @When("^User clicks on (Buy Currency|Transfer Now|Buy New Currency) link$")
    public void user_clicks_on_BuyCurrencyTranferNow_link(String link) throws Exception {
        if (link.equals("Buy Currency")) {
            LogCapture.info("User clicking On Buy Currency Link...");
            String vObjBuyCurrencyLink = Constants.CalypsologinPageOR.getProperty("BuyCurrencylink");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBuyCurrencyLink, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBuyCurrencyLink, ""));
        } else if (link.equals("Buy New Currency")) {
            LogCapture.info("User clicking On Buy New Currency Link...");
            String vObjBuyCurrencyLink = Constants.CalypsologinPageOR.getProperty("BuyNewCurrencylink");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBuyCurrencyLink, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBuyCurrencyLink, ""));
        } else if (link.equals("Transfer Now")) {
            String vObjTransferNowLink = Constants.CalypsologinPageOR.getProperty("TransferNowButton");
            Constants.key.VisibleConditionWait(vObjTransferNowLink, "");
            String vObjMakeATransfer = Constants.CalypsologinPageOR.getProperty("MakeATransferLabel");
            // Constants.key.pause("1", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjMakeATransfer, ""));
            Constants.key.ClickIfEnable(vObjTransferNowLink, "");
            LogCapture.info("User clicked On Transfer Now Link...");
        }
    }


        @And("^Calypso user clicks on continue button and navigated to second Payment Summary page for Payment Method selection$")
        public void calypso_user_clicks_on_continue_button_and_navigated_to_second_Payment_Summary_page_for_Payment_Method_selection()
            throws Throwable {
            LogCapture.info("User clicking on Continue Button");
            Constants.key.pause("4", "");
            String vObjCContinueButton = Constants.CalypsologinPageOR.getProperty("continueButtonAddFund");
            if (!Constants.CONFIG.getProperty("browser").equalsIgnoreCase("FireFox")) {
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCContinueButton, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCContinueButton, ""));
            } else {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCContinueButton, ""));
            }
            Constants.key.pause("2", "");
            String vObjPaymentSummary = Constants.CalypsologinPageOR.getProperty("paymentSummary");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjPaymentSummary, "Payment summary"));
        }

        @When("^User selects Calypso Payment method(| for forwards) \"([^\"]*)\"$")
        public void user_selects_Calypso_Payment_method(String page, String method) throws Throwable {
            LogCapture.info("Selecting Payment method.....");
            Constants.key.pause("3", "");
            // Select Method
            String vObjPaymentMethod = null;
            if (page.equalsIgnoreCase("")) {
                vObjPaymentMethod = Constants.CalypsologinPageOR.getProperty("paymentMethod");

            } else if (page.equalsIgnoreCase(" for forwards")) {
                vObjPaymentMethod ="//span[@class='select2-selection__placeholder'][normalize-space()='Select a payment method']";
//           vObjPaymentMethod = Constants.CalypsologinPageOR.getProperty("ForwardsPaymentMethod");

            } else if (page.equalsIgnoreCase("for forwards")) {
                vObjPaymentMethod = Constants.CalypsologinPageOR.getProperty("ForwardsPaymentMethod");

            }
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentMethod, ""));
            LogCapture.info(vObjPaymentMethod);
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentMethod, ""));
//        String vObjFromBankTransfer = Constants.CalypsologinPageOR.getProperty("paymentMethodSearch");
            String vObjFromBankTransfer ="//input[@role='searchbox']";
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            // Enter Method
            if (method.equals("Wallet")) {
                LogCapture.info("Payment method selected as " + method );
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromBankTransfer, "Balances"));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "enter"));
            } else if (method.equals("BankTransfer")) {
                LogCapture.info("Payment method selected as " + method );
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromBankTransfer, "Other"));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "enter"));
            } else if (method.equals("DirectDebit")) {
                LogCapture.info("Payment method selected as " + method );
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromBankTransfer, "Direct"));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "enter"));
            } else if (method.equals("AlreadySent")) {
                LogCapture.info("Payment method selected as " + method );
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromBankTransfer, "Other"));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "enter"));
            } else if (method.equals("MONEYTECH")) {
                LogCapture.info("Payment method selected as " + method );
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromBankTransfer, "Moneytech"));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "enter"));
            } else if (method.equals("Balances")) {
                LogCapture.info("Payment method selected as " + method );
                Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFromBankTransfer, method));
                Assert.assertEquals("PASS", Constants.key.pause("2", ""));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "downArrow"));
                Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjFromBankTransfer, "enter"));
            }


            String vobj2 = "//button[@id='submitBtnStep3DynamicMessage']";
            LogCapture.info(vobj2);
            Constants.key.pause("5", "");
            Constants.key.click(vobj2, "");


        }


        @And("^User clicks on Confirm button on Calypso Dashboard Payment Summary after validating details entered$")
        public void user_clicks_on_Confirm_button_on_Calypso_Dashboard_Payment_Summary_after_validating_details_entered() throws Throwable {
            LogCapture.info("User clicking Confirm  button...");
            String vObjPaymentDetailsPage = Constants.CalypsologinPageOR.getProperty("PaymentDetailsMsgScreen");
            String PaymentDetailsPage = Constants.key.exist(vObjPaymentDetailsPage, "");
            if(PaymentDetailsPage.equalsIgnoreCase("PASS")){
                String vobj1 = "//form[@data-form='validation-form']";
                String vobj2 = "//button[@id='dynamicFraudConfirmBtn']";
                LogCapture.info(vobj1);
                LogCapture.info(vobj2);
                Constants.key.pause("5", "");
                Constants.key.click(vobj1, "");
                Constants.key.pause("2", "");
                Constants.key.click(vobj2, "");
            }
            Assert.assertEquals("PASS", Constants.key.click(Constants.CalypsologinPageOR.getProperty("confirmButtonPaySummary"), ""));
        }


        @Then("^User should sucessfully be able to top up wallet generating (Instruction number|Contract number) \"([^\"]*)\" and click on Back to Calypso (dashboard|forwards) link$")
        public void user_should_sucessfully_be_able_to_top_up_wallet_generating_Instruction_number_and_click_on_Back_to_Calypso_dashboard_link(String labelType, String instructionNum, String page) throws Throwable {
            LogCapture.info("Top Up Wallet validation...");
            Constants.key.pause("2", "");
            if (labelType.equalsIgnoreCase("Instruction number")) {
                String vObjInstructionNumberLabel = Constants.CalypsologinPageOR.getProperty("instructionNumberLabel");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumberLabel, ""));
            } else if (labelType.equalsIgnoreCase("Contract number")) {
                String vObjContractNumberLabel = Constants.CalypsologinPageOR.getProperty("ContractNumberLabel");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContractNumberLabel, ""));
            }
            LogCapture.info("Verify instruction number...");
            String vObjinstructionNumberValue = Constants.CalypsologinPageOR.getProperty("instructionNumberValue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjinstructionNumberValue, ""));
            InstructionNumber1=Constants.key.getText(vObjinstructionNumberValue,"");
            Assert.assertEquals("PASS", Constants.key.exist(vObjinstructionNumberValue, instructionNum));
            Constants.key.pause("2", "");
            if (page.equalsIgnoreCase("dashboard")) {
                String vObjLinkBackToDashboard = Constants.CalypsologinPageOR.getProperty("BackToDashboardButton");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLinkBackToDashboard, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjLinkBackToDashboard, ""));
            } else if (page.equalsIgnoreCase("forwards")) {
                String vObjLinkBackToForwards = Constants.CalypsologinPageOR.getProperty("BackToForwardsButton");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLinkBackToForwards, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjLinkBackToForwards, ""));
            }
        }
    @And("^Calypso user is navigated to (Batch|Recipients|Transactions|Forwards) page$")
    public void calypsoUserIsNavigatedToBatchPage(String TargetTab) throws Throwable {
        if (TargetTab.contains("Batch")) {
            LogCapture.info("Calypso Batch page loading...");
            String vObjBatchPaymentText = Constants.CalypsologinPageOR.getProperty("BatchPaymentText");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBatchPaymentText, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjBatchPaymentText, ""));
            String vDashboardUploadfile = Constants.CalypsologinPageOR.getProperty("DashboardUploadfileBtn");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vDashboardUploadfile, "enabled"));
            String vObjAwaitingSubmissionBatch = Constants.CalypsologinPageOR.getProperty("AwaitingSubmissionBatch");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAwaitingSubmissionBatch, "visible"));
            LogCapture.info("old batch files awaiting for submission..");
            LogCapture.info("Batch page loaded successfully...");
//        } else if (TargetTab.contains("Recipients")) {
//            LogCapture.info("Calypso Recipients page loading...");
//            String vObjRecipientPageHeader = Constants.CalypsoRecipientOR.getProperty("RecipientPageHeader");
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRecipientPageHeader, ""));
//            Assert.assertEquals("PASS", Constants.key.exist(vObjRecipientPageHeader, ""));
//            String vAddRecipientBtn = Constants.CalypsoRecipientOR.getProperty("AddRecipientBtn");
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vAddRecipientBtn, "enabled"));
//            LogCapture.info("Recipients page loaded successfully...");
//        } else if (TargetTab.contains("Transactions")) {
//            LogCapture.info("Calypso Transactions page loading...");
//            String vObjTransactionsPageHeader = Constants.CalypsologinPageOR.getProperty("TransactionsPageHeader");
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTransactionsPageHeader, ""));
//            Assert.assertEquals("PASS", Constants.key.exist(vObjTransactionsPageHeader, ""));
//            String vTransactionBtn = Constants.CalypsologinPageOR.getProperty("TransactionBtn");
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vTransactionBtn, "visible"));
//            String vFXDealBtn = Constants.CalypsologinPageOR.getProperty("FXDealBtn");
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vFXDealBtn, "visible"));
//
//            String vOldFXDeal = Constants.CalypsologinPageOR.getProperty("OldFXDeal");
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vOldFXDeal, "visible"));
//            LogCapture.info("Old FX Deal visible..");
//            String vOldTransferInstruction = Constants.CalypsologinPageOR.getProperty("OldTransferInstruction");
//            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vOldTransferInstruction, "visible"));
//            LogCapture.info("Old Transfer instruction visible..");
//            LogCapture.info("Transactions page loaded successfully...");
        } else if (TargetTab.contains("Forwards")) {
            LogCapture.info("Calypso Forwards page loading...");
            String vObjForwardsPageHeader = Constants.CalypsologinPageOR.getProperty("ForwardsPageHeader");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjForwardsPageHeader, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjForwardsPageHeader, ""));
            LogCapture.info("Manage your forwards header is visible...");
            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            String vForwardsInProgressTabBtnActiveState = Constants.CalypsologinPageOR.getProperty("ForwardsInProgressTabBtnActiveState");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vForwardsInProgressTabBtnActiveState, "visible"));
            String vForwardsClosedTabBtn = Constants.CalypsologinPageOR.getProperty("ForwardsClosedTabBtn");
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vForwardsClosedTabBtn, "visible"));
            LogCapture.info("Forwards page loaded successfully...");
        }

    }
    @And("^User navigates to (Select Recipient) page for forwards$")
    public void userIsNavigatedToSelectRecipientPageForForwards(String Navigate) throws Exception {
        if (Navigate.equalsIgnoreCase("Select Recipient")) {
            LogCapture.info("Select Recipient page for forwards");
            String vSelectRecipient = Constants.CalypsologinPageOR.getProperty("SelectRecipient");
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSelectRecipient, "Select recipient"));
        }

    }
    @And("^User is able to view Pay button Enable and clicks on \"([^\"]*)\"$")
    public void userIsAbleToViewPayButtonEnableAndClicksOn(String RecipientName) throws Throwable {
        LogCapture.info("User is able to click on PayButton");
        String PayButtonXpath = "//table [@class='no-fixed']//strong[text()='" + RecipientName + "']//parent::span/parent::td/parent::tr//button";
        Assert.assertEquals("PASS", Constants.key.click(PayButtonXpath, ""));
    }
    @Then("^Enter the Amount \"([^\"]*)\" in YouPay textbox of (MAT|Standalone payout|Multipayout|Add Funds|ForwardsUserOne|ForwardsUserTwo)$")
    public void enter_the_Amount_in_YouPay_textbox_of_MAT(String amount, String journey) throws Throwable {
        Constants.key.pause("3", "");
        if (journey.equals("MAT")) {
            String vObjSellInputBOX = Constants.CalypsologinPageOR.getProperty("SellInput");

            LogCapture.info("User clearing default amount .....");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSellInputBOX, ""));
            Constants.key.clearText(vObjSellInputBOX);
            String vObjSellInput = Constants.CalypsologinPageOR.getProperty("YouPayEnterAmount");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellInput, amount));
            Constants.key.pause("2", "");
            LogCapture.info("User entered amount ....." + amount);
        } else if (journey.equals("Standalone payout")) {
            LogCapture.info("User entering amount .....");
            String vObjSendInput = Constants.CalypsologinPageOR.getProperty("PayAmount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendInput, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSendInput, amount));
            Constants.key.pause("2", "");
        } else if (journey.equals("Multipayout")) {
            LogCapture.info("User entering amount .....");
            String vObjSendInput1 = Constants.CalypsologinPageOR.getProperty("AmountTextBoxPayee2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendInput1, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSendInput1, amount));
            Constants.key.pause("2", "");
        } else if (journey.equals("Add Funds")) {
            String vObjYouPayBox = Constants.CalypsologinPageOR.getProperty("sendAmountInputBox");
            LogCapture.info("User clearing default amount if any.....");
            Constants.key.clearText(vObjYouPayBox);
            Constants.key.pause("2", "");
            LogCapture.info("User entered amount....." + amount);
            String vObjSendInput = Constants.CalypsologinPageOR.getProperty("sendAmountInputBox");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSendInput, amount));
            Constants.key.pause("2", "");
        } else if (journey.equals("ForwardsUserOne")) {
            String vObjYouPay = Constants.CalypsologinPageOR.getProperty("InputAmount1");
            LogCapture.info("User clearing default amount if any.....");
            Constants.key.clearText(vObjYouPay);
            Constants.key.pause("2", "");
            LogCapture.info("User entered amount....." + amount);
            String vObjSendInput = Constants.CalypsologinPageOR.getProperty("InputAmount1");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSendInput, amount));
            Constants.key.pause("2", "");
        } else if (journey.equals("ForwardsUserTwo")) {
            String vObjYouPay = Constants.CalypsologinPageOR.getProperty("InputAmount2");
            LogCapture.info("User clearing default amount if any.....");
            Constants.key.clearText(vObjYouPay);
            Constants.key.pause("2", "");
            LogCapture.info("User entered amount....." + amount);
            String vObjSendInput = Constants.CalypsologinPageOR.getProperty("InputAmount2");
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSendInput, amount));
            Constants.key.pause("2", "");
        }
    }
    @And("^User select Reason \"([^\"]*)\" for recipient payment and clicks on it$")
    public void userSelectReasonForPaymentAndClicksOnIt(String reason) throws Throwable {
        Constants.key.pause("2", "");
        LogCapture.info("User is selecting Reason for Payment");
        String vPaymentList = Constants.CalypsologinPageOR.getProperty("ReasonForPaymentList");
        Assert.assertEquals("PASS", Constants.key.click(vPaymentList, ""));
        Constants.key.pause("1", "");

        String vReasonInput = Constants.CalypsologinPageOR.getProperty("ReasonForPaymentInput");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vReasonInput, reason));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vReasonInput, "enter"));
    }
    @Then("^User Click on the Link to add another Payee$")
    public void userClickOnTheLinkToAddAnotherPayee() throws Exception {
        LogCapture.info("Link for adding another payee enabled");
        Constants.key.pause("1", "");
        String vAddAnotherRecipient = Constants.CalypsologinPageOR.getProperty("AddAnotherRecipient");
        Assert.assertEquals("PASS", Constants.key.click(vAddAnotherRecipient, ""));
    }
    @And("^user select another recipient from dropdown$")
    public void userSelectAnotherRecipientFromDropdown() throws Exception {

        LogCapture.info("Selecting recipient...");
        String SelectRecipient = Constants.CalypsologinPageOR.getProperty("SelectRecipientDropdown");
        Assert.assertEquals("PASS", Constants.key.click(SelectRecipient, ""));
        Constants.key.pause("1", "");
        String AnotherRecipientFmDropdown = Constants.CalypsologinPageOR.getProperty("AnotherRecipientFmDropdown");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(AnotherRecipientFmDropdown, " EUR Test2"));
        Assert.assertEquals("PASS", Constants.key.click(AnotherRecipientFmDropdown, ""));
    }
    @And("^user validates GBP currency is displayed for the selected recipient$")
    public void userValidatesOnlyEURAreDisplaying() throws Exception {
        LogCapture.info("Select Recipient page for forwards");
        String vEUR = Constants.CalypsologinPageOR.getProperty("ValidatingCCY");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.verifyText(vEUR, "GBP"));

    }


    @And("^User gets the Instruction Number$")
    public void userGetsTheInstructionNumber() throws Exception {
        LogCapture.info("Top Up Wallet validation...");
        Constants.key.pause("2", "");
        String vObjInstructionNumber = Constants.CalypsologinPageOR.getProperty("instructionNumberValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNumber, ""));
        InstructionReferenceNumber=Constants.key.getText(vObjInstructionNumber,"");
        String InstructionReference =InstructionReferenceNumber.split("-")[1];
        String NumberOfZeros="0";
        for(int i=1;i<(9-InstructionReference.length());i++){
            NumberOfZeros=NumberOfZeros+"0";
        }
        Constants.InstructionNumber1=InstructionReferenceNumber.split("-")[0]+"-"+NumberOfZeros+InstructionReferenceNumber.split("-")[1];

        LogCapture.info("Instrucation number is " +InstructionNumber1);
    }

    @Then("^User click on Payment details arrow$")
    public void userClickOnPaymentDetailsArrow() throws Exception {
        String vPaymentDetailsBtn = Constants.CalypsologinPageOR.getProperty("PaymentDetailsbtn");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPaymentDetailsBtn, ""));
        Assert.assertEquals("PASS", Constants.key.click(vPaymentDetailsBtn, ""));
    }

    @And("^User navigates to FX ticket details page and clicks on SellBack FX button and enters details \"([^\"]*)\" \"([^\"]*)\"$")
    public void userNavigatesToFXTicketDetailsPageAndClicksOnSellBackFXButtonAndEntersDetails(String DealRate, String NewSellAmount) throws Throwable {

        String vObjSellBack_BTN = Constants.TitanFXTicketsOR.getProperty("SellBack_BTN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSellBack_BTN, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSellBack_BTN, ""));
        LogCapture.info("User clicks on sellBack button..");

        String vObjSellBackBuy = Constants.TitanFXTicketsOR.getProperty("SellBackBuy");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSellBackBuy, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSellBackBuy, ""));
        LogCapture.info("User clicks on sellBack Buy side currency button..");

        String vObjSellBackdFX = Constants.TitanFXTicketsOR.getProperty("sellBackFetch");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSellBackdFX, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSellBackdFX, ""));
        LogCapture.info("User clicks on sellBack Fetch button..");

        key.pause("2","");
        String vObjSuggestedRates = Constants.TitanFXTicketsOR.getProperty("sellBack_SuggestedRates");
        String SuggestedRates = Constants.driver.findElement(By.xpath(vObjSuggestedRates)).getText();

        int DealRateInt = Integer.parseInt(DealRate);
        double d = Double.parseDouble(SuggestedRates);
        double vDoubleCurrRate = ((DealRateInt * d / 100) + d);
        String vTargetValueCalculated = Double.toString(vDoubleCurrRate);


        String vObjDealerRateInput = Constants.TitanFXTicketsOR.getProperty("sellBack_DealerRate");
        Assert.assertEquals("PASS", Constants.key.click(vObjDealerRateInput, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjDealerRateInput, vTargetValueCalculated));
        LogCapture.info("Deal Rate entered: " + vTargetValueCalculated);
        key.pause("2", "");
        String vObjsellBack_ReasonDropArrow = Constants.TitanFXTicketsOR.getProperty("sellBack_ReasonDropArrow");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjsellBack_ReasonDropArrow, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjsellBack_ReasonDropArrow, ""));
        LogCapture.info("User clicked on  sellBack Reason Drop Arrow..");
        key.pause("3", "");
        String vObjsellBack_Reason = Constants.TitanFXTicketsOR.getProperty("sellBack_Reason");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjsellBack_Reason, ""));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjsellBack_Reason, "MoveToElement"));
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjsellBack_Reason, "click"));
        LogCapture.info("User selects sellBack reason..");

        String vObjApplyBtn = Constants.TitanFXTicketsOR.getProperty("ApplyBtn");
        Assert.assertEquals("PASS", Constants.key.click(vObjApplyBtn, ""));
        LogCapture.info("User clicks on Apply button..");
        Constants.key.pause("2", "");
    }

    @Then("^User is able to view FX SellBack successful message for clientNumber\"([^\"]*)\"$")
    public void userIsAbleToViewFXSellBackSuccessfulMessageForClientNumber(String clientNumber) throws Throwable {
        String vObjsellBackSuccessfulMsg = Constants.TitanFXTicketsOR.getProperty("sellBackSuccessfulMsg");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjsellBackSuccessfulMsg, ""));
        LogCapture.info("FX ellBack successful message visible...");

    }

    @And("^User is able verify sell back and new instruction Number$")
    public void userIsAbleVerifySellBackAndNewInstructionNumber() throws Exception {
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 5; i++) {
            String VObjStatus = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[15]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjStatus, ""));
            String ActStatus = Constants.driver.findElement(By.xpath(VObjStatus)).getText();

            String VObjFXStatus = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[12]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjFXStatus, ""));
            String ActFXStatus = Constants.driver.findElement(By.xpath(VObjFXStatus)).getText();

            if (ActStatus.equals("RS")) {
                String VObjSwapFlag = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[3]//a)";
                String NewInstructionNumber = Constants.driver.findElement(By.xpath(VObjSwapFlag)).getText();
                InstructionNumber1=NewInstructionNumber;
                break;
            }
        }
    }

    @Then("^User select (LiveMode|NewestFirst|OldestFirst) option on kafka UI$")
    public void userSelectNewestFirstOptionOnKafkaUI(String data) throws Exception {
        key.pause("20","");
        String vObjSelectQueueType = KafkaUI.getProperty("selectQueueType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectQueueType, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectQueueType, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        String vObjLiveMode = null;
        if(data.equalsIgnoreCase("LiveMode")) {
            vObjLiveMode= KafkaUI.getProperty("LiveMode");
        }else if(data.equalsIgnoreCase("NewestFirst")) {
            vObjLiveMode = KafkaUI.getProperty("NewestFirst");
        }else if(data.equalsIgnoreCase("OldestFirst")) {
            vObjLiveMode = KafkaUI.getProperty("OldestFirst");
        }
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLiveMode, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjLiveMode, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on "+data+" on Kafka UI...");

    }


    @And("^User search for Instruction number using PaymentLifeCycleId$")
    public void userSearchForInstructionNumberUsingPaymentLifeCycleId() throws Exception {

        String vObjInstructionNumberSearch = Constants.TitanInstructionsOR.getProperty("InstructionNumberSearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionNumberSearch, Constants.UniquePaymentLifeCycleId));

        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionNumberSearch, "enter"));
        LogCapture.info("User Searching PaymentLifeCycleID: " + Constants.UniquePaymentLifeCycleId);
        Constants.key.pause("4","");

        String vObjCloseFilterInstPage = CreateFxTicketOR.getProperty("CloseFilterInstPage");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjCloseFilterInstPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCloseFilterInstPage, ""));

        String vObjPaymentLifeCycleIdHeader = Constants.CreateFxTicketOR.getProperty("PaymentLifeCycleIdHeader");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentLifeCycleIdHeader, ""));
        String ActualPaymentLifeId = Constants.driver.findElement(By.xpath(vObjPaymentLifeCycleIdHeader)).getText();
        LogCapture.info("Captured Payment life cycle id : " + ActualPaymentLifeId);

        String vObjInstructionNumberHeader = Constants.CreateFxTicketOR.getProperty("InstructionNumberHeader");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjInstructionNumberHeader, ""));
        Constants.InstructionNumber = Constants.driver.findElement(By.xpath(vObjInstructionNumberHeader)).getText();
        LogCapture.info("Captured Instruction Number is: " + Constants.InstructionNumber);

        Constants.key.pause("1", "");
        String vObjInstructionPageClientNumber = Constants.CreateFxTicketOR.getProperty("InstructionPageClientNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionPageClientNumber, ""));
        LogCapture.info("User clicked on client number on instruction page .....");
    }

    @And("^User search for client number \"([^\"]*)\" for CARD and hits Enter key$")
    public void userSearchForClientNumberForCARDAndHitsEnterKey(String ClientTANNumber) throws Throwable {

            String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
            String CARDClientTAN = Constants.OnTheFlyValue.getProperty(ClientTANNumber);

            Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, CARDClientTAN));
            LogCapture.info("Searching for Client number : " + CARDClientTAN);
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
            Constants.key.pause("4", "");
    }

    @And("^User clicks on client number\"([^\"]*)\" link for CARD to navigate to customer detail page$")
    public void userClicksOnClientNumberLinkForCARDToNavigateToCustomerDetailPage(String ClientTANNumber) throws Throwable {


        String CARDClientTAN = Constants.OnTheFlyValue.getProperty(ClientTANNumber);
        String vclientNumberXpath = "//*[contains(text(),'" + CARDClientTAN + "')]";

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
    }

    @And("^User navigate to Customer \"([^\"]*)\" Detail for CARD$")
    public void userNavigateToCustomerDetailForCARD(String DataClientNumber) throws Throwable {

        String CARDClientTAN = Constants.OnTheFlyValue.getProperty(DataClientNumber);
        String vObjKeywordFilterText = "//h1[contains(text(),'" + CARDClientTAN + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjKeywordFilterText, ""));

        String vObjCustomerDetailPageH2 = Constants.TitanPaymentOutOR.getProperty("CustomerDetailPageH2");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerDetailPageH2, ""));

        LogCapture.info("User navigate to Customer # " + CARDClientTAN + " Detail");
        String vObjCustomerStatus = Constants.TitanPaymentOutOR.getProperty("CustomerStatus");
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCustomerStatus, "ACTIVE"));
        LogCapture.info("Customer status is Active verified..");

    }

    @Then("^User click on Currency \"([^\"]*)\" to validate Block amount \"([^\"]*)\"entry on wallet activity history$")
    public void userClickOnCurrencyToValidateBlockAmountEntryOnWalletActivityHistory(String WalletCCY, String WalletAmount) throws Throwable {

        String vObjCustomerWalletn = Constants.TitanCustomersOR.getProperty("CustomerWallet");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjCustomerWalletn, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCustomerWalletn, ""));
        LogCapture.info("User clicked on wallet section......");
        Constants.key.pause("5", "");

        String zoomJS;
        JavascriptExecutor js = (JavascriptExecutor) driver;
        zoomJS = "document.body.style.zoom='0.5'";
        js.executeScript(zoomJS);
        Constants.key.pause("5", "");

        zoomJS = "document.body.style.zoom='0.9'";
        js.executeScript(zoomJS);
        Constants.key.pause("5", "");


        String vObjCCYWallet = "(//a[@data-wallet_currency='"+WalletCCY+"'])[1]";
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjCCYWallet, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCCYWallet, ""));
        LogCapture.info("User clicked on customer wallet section of CCY ["+WalletCCY+"]......");

        String BlockedAmount = Constants.OnTheFlyValue.getProperty(WalletAmount);

            for (int i=1; i<=10; i++)
            {
                String vObjInstructionNoWalletActivity= "//tbody[@id='customerWalletTransactionTablebody-CAD']//tr["+i+"]//td[1]";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstructionNoWalletActivity, ""));
                String InstructionNoWalletActivityTXT = Constants.driver.findElement(By.xpath(vObjInstructionNoWalletActivity)).getText();
                LogCapture.info("User get Instruction details ["+InstructionNoWalletActivityTXT+"]......");

                String vObjStatusWalletActivity= "//tbody[@id='customerWalletTransactionTablebody-CAD']//tr["+i+"]//td[3]";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatusWalletActivity, ""));
                String StatusWalletActivityTXT = Constants.driver.findElement(By.xpath(vObjStatusWalletActivity)).getText().trim();
                LogCapture.info("User get transactions Status ["+StatusWalletActivityTXT+"]......");

                String vObjAmountWalletActivity= "//tbody[@id='customerWalletTransactionTablebody-CAD']//tr["+i+"]//td[4]";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountWalletActivity, ""));
                String AmountWalletActivityTXT = Constants.driver.findElement(By.xpath(vObjAmountWalletActivity)).getText().trim();
                LogCapture.info("User get Txn Amount details ["+AmountWalletActivityTXT+"]......");

                if(InstructionNoWalletActivityTXT.contains(Constants.InstructionNumber) && AmountWalletActivityTXT.equals(BlockedAmount))
                {
                    if(StatusWalletActivityTXT.equals("Hold"))
                    {
                        LogCapture.info("User verify Amount ["+BlockedAmount+"] is on Hold for Instruction Number ["+Constants.InstructionNumber+"]......");
                        break;
                    }
                }else
                {
                    LogCapture.info("TC Failed : user unable to verify Hold amount on customer wallet activity history");
                    Assert.fail();
                }
            }
        }


//    @And("^Verify Kafka message audit logs for \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
//    public void verifyKafkaMessageAuditLogsFor(String mappingFilePath,String Environment,String DBOperation) throws Throwable {
//       key.pause("2","");
//       String Kafka_Audit_Property="";
//       if(DBOperation.equalsIgnoreCase("Customer Instruction")){
//           Kafka_Audit_Property="Customer_Instruction";
//       }else if(DBOperation.equalsIgnoreCase("New Payment out")){
//           Kafka_Audit_Property="New_Payment_out";
//       }
////        Map<String, String> auditRecord = Reusables.getSqlQueryResult1(Kafka_Audit_Property,Environment, Kafka_ID);
////        Gson gson = new Gson();
////        String json = gson.toJson(auditRecord);
////        System.out.println(json);
////        JsonPath jsonPath1 = JsonPath.from(json);
////        Reusables.compareJsonAgainstGetTxnMappings(KafkaMsg, jsonPath1, mappingFilePath, true);
//        Map<String, String> actualAuditRecord = ReusableMethod.getSqlQueryResult(mappingFilePath, paymentLifeCycleID);
//        System.out.println("Actual Audit Log for '" + Kafka_Audit_Property + "' :: " + actualAuditRecord);
//        ReusableMethod.verifyKafkaAuditLog(kafkaExpectedKeyValues, actualAuditRecord);
////        Gson gson = new Gson();
////        String json = gson.toJson(auditRecord);
////        JsonPath jsonPath = JsonPath.from(json);
////        commonStep.compareJsonAgainstGetTxnMappings(gpsGetTxnReqBody, jsonPath, mappingFilePath, true);
//
//    }

    @When("^For a \"([^\"]*)\" call user (generates instruction|trigger scheduler) and Check Status code As \"([^\"]*)\" for \"([^\"]*)\"$")
    public void forACallUserGeneratesInstructionAndCheckStatusCodeAsForOnEnvironment(String methodType, String data, String statCode, String testCaseID1) throws Throwable {
        LogCapture.info("---------------POST call started----------------");

        Constants.TCCaseID = testCaseID1;
//        Constants.SHEET_NAME = Environment;
        key.pause("1","");
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID1, statCode, Constants.DynamicValue);
//        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        LogCapture.info(RESPONSE + "---------------POST call ended----------------");
        Assert.assertFalse(RESPONSE.contains("null"));
        if(data.equalsIgnoreCase("generates instruction")) {
            String customer_instruction_number = RESPONSE.split(":")[3].split("\"")[1];
            Constants.KafkaMessageCDID = customer_instruction_number;
            LogCapture.info("customer_instruction_number =" + customer_instruction_number);
        Constants.MessageInId = external_reference_id;
            InstructionNumber1=customer_instruction_number;
        }

    }

    @And("^User verify achMandateId is available at \"([^\"]*)\" DB$")
    public void userVerifyAchMandateIdIsAvailableAtDB(String TitanEnvironment) throws Throwable {
        String ID=Constants.key.VerifyDBDetails(TitanEnvironment, InstructionNumber1, "Find achMandateId");
        LogCapture.info("achMandateId : " + ID);
        Assert.assertTrue(achMandateId.equalsIgnoreCase(ID),"true");
        LogCapture.info("Correct achMandateId is captured");

    }

    @And("^User takes Dynamic values which are required for Send Money API \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userTakesDynamicValuesWhichAreRequiredForSendMoneyAPI(String Organisation, String Source_application, String TAN, String customer_instruction_type, String selling_currency, String buying_currency, String payment_method, String existing_payee_id) throws Throwable {
        DynamicValue.put("<Organization>", Organisation);
        DynamicValue.put("<Source_application>",Source_application );
        DynamicValue.put("<TAN>",TAN );
        DynamicValue.put("<customer_instruction_type>",customer_instruction_type );
        DynamicValue.put("<selling_currency>", selling_currency);
        DynamicValue.put("<buying_currency>", buying_currency);
        DynamicValue.put("<payment_method>", payment_method);
        DynamicValue.put("<existing_payee_id>",existing_payee_id );
        key.pause("1","");
        String RandomNumber = RandomStringUtils.randomNumeric(9);
//        RandomNumber=RandomNumber.startsWith("0")? RandomNumber.substring(1):RandomNumber;
        RandomNumber=RandomNumber.startsWith("0")?RandomNumber.replace("0","1"):RandomNumber;
        DynamicValue.put("<achMandateId>",RandomNumber );
        Constants.achMandateId=RandomNumber;
        String RandomNumber1 = RandomStringUtils.randomNumeric(3);
        DynamicValue.put("<amount>",RandomNumber1 );

    }

    @Then("^User verify FundType is 'A' and StatusEnum is '(18|19)' for paymentIn As CVA at \"([^\"]*)\" DB$")
    public void userVerifyFundTypeIsAAndStatusEnumIsForPaymentInAsCVAAtDB(String data, String TitanEnvironment) throws Throwable {
        String FundTypeIs=Constants.key.VerifyDBDetails(TitanEnvironment, external_reference_id, "Find FundType and StatusEnum");
        Assert.assertTrue(FundType.equalsIgnoreCase("A"));
        Assert.assertTrue(StatusEnum.equalsIgnoreCase(data));
        LogCapture.info("We received FundType as: '"+FundType+ "' and StatusEnum is : '"+StatusEnum+"'.");
    }

    @When("^User fetch the bank details from Banking \"([^\"]*)\" AccountNumber \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userFetchTheBankDetailsFromBankingEnvironment(String AccountNumber, String Source_application, String TAN, String fund_type) throws Throwable {
//        String Currency = Constants.key.VerifyDBDetails(Environment, AccountNumber, "Find AccountNumber Details");

//        String query = SQLQUERIES.getProperty("BankDetails1");
//        query=query.replace("%s",AccountNumber);
//        System.out.println(query);

        Map<String, String> result =ReusableMethod.getSqlQueryResult("BankDetails1",AccountNumber);

        Constants.Currency_code = result.get("Currency_code");
        Constants.bank_name = result.get("bank_name");
        Constants.BIC = result.get("BIC");
        Constants.Address = result.get("Address");
        Constants.Name = result.get("Name");
        Constants.org_code = result.get("org_code");
        Constants.legal_entity = result.get("legal_entity");
        Constants.hyperion_bank_account_reference_id = result.get("External_BankAccount_Reference_Id");
        LogCapture.info("Currency_code is : "+Currency_code);
        DynamicValue.put("<hyperion_bank_account_reference_id>", hyperion_bank_account_reference_id);
        DynamicValue.put("<legal_entity>", legal_entity);
        DynamicValue.put("<org_code>", org_code);
        DynamicValue.put("<Name>", Name);
        DynamicValue.put("<Address>", Address);
        DynamicValue.put("<Currency_code>", Currency_code);
        DynamicValue.put("<bank_name>", bank_name);
        DynamicValue.put("<Source_application>", Source_application);
        key.pause("1","");
        if(BIC.length()>10){
            BIC=BIC.substring(0,BIC.length()-1);
        }

        DynamicValue.put("<BIC>", BIC);
        DynamicValue.put("<TAN>", TAN);
        DynamicValue.put("<fund_type>", fund_type);
        DynamicValue.put("<AccountNumber>", AccountNumber);
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
        String CurrentDateFor1 = dtf1.format(now);
        Constants.DynamicValue.put("<currentDate1>", CurrentDateFor1);
        String RandomNumber = RandomStringUtils.randomNumeric(2);
        RandomNumber = RandomNumber.startsWith("0") ? RandomNumber.replace("0", "1") : RandomNumber;
        DynamicValue.put("<amount>", RandomNumber);
        String RandomNumber1 = RandomStringUtils.randomNumeric(5);
        RandomNumber1 = RandomNumber1.startsWith("0") ? RandomNumber1.replace("0", "1") : RandomNumber1;
        DynamicValue.put("<external_reference_id>", RandomNumber1);
        Constants.external_reference_id = RandomNumber1;
    }

    @Then("^User verify PaymentMethod \"([^\"]*)\" is available on payment in queue page$")
    public void userVerifyPaymentMethodIsAvailableOnPaymentInQueuePage(String PayInMethod) throws Throwable {

        String vObjClosePaymentinQFilter = Constants.TitanPaymentInOR.getProperty("ClosePaymentinQFilter");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjClosePaymentinQFilter, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjClosePaymentinQFilter, ""));

        String vObjPayInQMethod = Constants.TitanPaymentInOR.getProperty("PayInQMethod");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPayInQMethod, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayInQMethod, ""));
        Constants.key.pause("2", "");

        for(int i=1; i<=10; i++)
        {
            String vObjPaymentMethodPayInQ = "(//ul[@class='singlelist__options'])[1]//li["+i+"]//label";
            String ActualMethod = Constants.driver.findElement(By.xpath(vObjPaymentMethodPayInQ)).getText().trim();

            if(ActualMethod.equals(PayInMethod))
            {
                LogCapture.info("User verified payment in method ["+ActualMethod+"] is visible.....");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentMethodPayInQ, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPaymentMethodPayInQ, ""));
                LogCapture.info("User clicked on payment in method ["+ActualMethod+"].....");
                break;
            }
        }



    }

    @And("^User is verify achMandateId is available at \"([^\"]*)\" DB$")
    public void userIsVerifyAchMandateIdIsAvailableAtDB(String TitanEnvironment) throws Throwable
    {

        String ID=Constants.key.VerifyDBDetails(TitanEnvironment, InstructionNumber1, "Find achMandateId");
        LogCapture.info("achMandateId : " + ID);
        achMandateId.equalsIgnoreCase(ID);
        LogCapture.info("Correct achMandateId is captured");

    }

    @And("^User takes Dynamic values which are required for Buy Currency API \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userTakesDynamicValuesWhichAreRequiredForBuyCurrencyAPI(String Organisation, String Source_application, String TAN, String customer_instruction_type, String selling_currency, String buying_currency, String payment_method, String existing_payee_id) throws Throwable {
            DynamicValue.put("<Organization>", Organisation);
            DynamicValue.put("<Source_application>",Source_application );
            DynamicValue.put("<TAN>",TAN );
            DynamicValue.put("<customer_instruction_type>",customer_instruction_type );
            DynamicValue.put("<selling_currency>", selling_currency);
            DynamicValue.put("<buying_currency>", buying_currency);
            DynamicValue.put("<payment_method>", payment_method);
            DynamicValue.put("<existing_payee_id>",existing_payee_id );
            key.pause("1","");
            String RandomNumber = RandomStringUtils.randomNumeric(9);
//        RandomNumber=RandomNumber.startsWith("0")? RandomNumber.substring(1):RandomNumber;
            RandomNumber=RandomNumber.startsWith("0")?RandomNumber.replace("0","1"):RandomNumber;
            DynamicValue.put("<achMandateId>",RandomNumber );
            Constants.achMandateId=RandomNumber;
            String RandomNumber1 = RandomStringUtils.randomNumeric(3);
            DynamicValue.put("<amount>",RandomNumber1 );

        }


}












