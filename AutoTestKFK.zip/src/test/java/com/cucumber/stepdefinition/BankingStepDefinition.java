package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;
import com.utility.LogCapture;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.String.valueOf;

import static com.selenium.utillity.Constants.*;


public class BankingStepDefinition {

    public Float SpotRate;
    public Float SellAmountValue;
    public String ValueDate;
    public String ActualSpot;
    public Integer ActualBuyCurrValue;
    public Integer BuyAmountValue1;
    public String PaymentApprovalRecordID;
    public String SecondPaymentApprovalRecordID;
    public String PaymentID;
    public String RandomNumber;
    public String SafeModeValue;
    public List<String> MultiPaymentID;
    public String QueryID;
    public String RelatedReference;
    public String TransactionReference;
    public String QueryIdValue;
    public String QueryID2;
    public String FilePath;
    public String CurrencyPosition;
    static boolean isKafkaLaunched;
    public String BankRef;

    @When("^Change the \"([^\"]*)\" banking file name for \"([^\"]*)\"\"([^\"]*)\"$")
    public void changeTheBankingFileNameFor(String FileType, String Bank, String  AccountNumber) throws Exception {
        key.pause("60","");
        Constants.Bank=Bank;
        Constants.FileType=FileType;
        File Rename=Constants.key.RenameCAMTFile(FileType,Bank,AccountNumber);
        String newFileName = Rename.getName();
        Constants.NewFileName=newFileName;
        LogCapture.info(Rename.getName());

    }

    @Given("^take a \"([^\"]*)\"script for \"([^\"]*)\" and insert into messageIn on \"([^\"]*)\"$")
    public void takeAScriptForAndInsertIntoMessageIn(String arg0, String Bank, String Environment) throws Throwable {
        String path="Files/"+Bank+"/"+ NewFileName;
        LogCapture.info("New file name with paths is: "+path);
        Constants.filePath=path;

        Reusables.modifyFile(filePath,dateReplace,currentDate);
        Reusables.modifyFile(filePath,oldAmountStarting,newAmount);
        Reusables.modifyFile(filePath,Olddate,currentDate1);

        String messageInId=Constants.key.VerifyDBDetails(Environment, "QueryForInsert", "Insert into MessageIn Table");
        LogCapture.info(Bank+" messageInId is "+messageInId);
        if(arg0.contains("MT942")){
            MessageInIdMap.put("MessageInId for 52",messageInId); //to have a less variable for MT942 taken MessageInId for 52
        }else if(arg0.contains("MT940")){
            MessageInIdMap.put("MessageInId for 53",messageInId);
        }else if(arg0.contains("MT103")){
            MessageInIdMap.put("MessageInId for 103",messageInId);
        }

        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        double one= Double.parseDouble(newAmount);
        Constants.PaymentInAmount= decimalFormat.format((one));
        LogCapture.info("Payment In amount is "+PaymentInAmount);
    }

    @When("^User modifies \"([^\"]*)\" timing for 10 sec and reschedule timing to 60 sec for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void userModifiesSchedulerTimingForSecAndRescheduleTimingToSecForOn(String scheduler,String testCaseID,String Environment) throws Throwable {
        Constants.SHEET_NAME=Environment;
        DynamicValue.put("<scheduler>", scheduler);
        try {
            DynamicValue.put("<CronExpression>", "0/10 * * 1/1 * ? *");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, "200", Constants.DynamicValue);
            LogCapture.info(" Scheduler is modified to trigger after 10 sec");
            LogCapture.info(" Scheduler is awaiting for 7 sec for parsing files");
            key.pause("14","");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            DynamicValue.put("<CronExpression>", "0 0/1 * 1/1 * ? *");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, "200", Constants.DynamicValue);
            LogCapture.info(" Scheduler is modified to trigger after 60 sec");
        }
    }

    @And("^User gets banking MSL_ID from \"([^\"]*)\" DB$")
    public void userGetsBankingMSL_IDFromDB(String Environment) throws Exception {

        Constants.key.pauseforSchedular();
        Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine53", Constants.StatementLineID);
        MSL_ID = result.get("ID");
        Assert.assertFalse(false, String.valueOf(MSL_ID.contains("null")));
        Constants.EODMSL_ID = MSL_ID;
        Constants.KafkaMessageCDID = MSL_ID;
        LogCapture.info("MSL_ID : " + EODMSL_ID);
    }

    @And("^Do \"([^\"]*)\" banking DB verification and get StatementLineID$")
    public void doBankingDBVerificationAndGetStatementLineID(String Environment) throws Exception {
        String MessageInId = MessageInIdMap.get("MessageInId for 53");
        if (MessageInId == null) {
            Object firstKey = MessageInIdMap.keySet().toArray()[0];
            MessageInId = MessageInIdMap.get(firstKey);
        }

        Constants.key.pauseforSchedular();

        Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", MessageInId);
        String vIsParsed = result.get("IsParsed");
        String vParsedStatus = result.get("parsedStatus");
        LogCapture.info("Value of IsParsed is " + vIsParsed + "\n and Value of parsedStatus is " + vParsedStatus);

        Assert.assertTrue(vIsParsed.equals("1"));
        Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));

        Map<String, String> result1 = Reusables.getSqlQueryResult("Statement_940", MessageInId);
        String StatementID = result1.get("ID");
        LogCapture.info("Value of StatementID: " + StatementID);
        Assert.assertFalse(false, String.valueOf(StatementID.contains("null")));
        Constants.RemitterNameID = StatementID;
        Map<String, String> result2 = Reusables.getSqlQueryResult("StatementLine_940", StatementID);
        StatementLineID = result2.get("ID");
        LogCapture.info("Value of StatementLineID: " + StatementLineID);
        Assert.assertFalse(false, String.valueOf(StatementLineID.contains("null")));

    }

    @And("^User gets KafkaMSL_ID from \"([^\"]*)\" DB$")
    public void userGetsKafkaMSL_IDFromDB(String Environment) throws Exception {
        String MSL=Constants.key.VerifyDBDetails(Environment, StatementLineID, "Find the MSL_ID");
        Constants.EODMSL_ID=MSL;
        Constants.KafkaMessageCDID =MSL;
        LogCapture.info("MSL_ID : " + EODMSL_ID);
    }

    @Given("^banking User launches Kafka UI application for \"([^\"]*)\"\"([^\"]*)\" topic$")
    public void BankinglaunchKafkaUI(String topic, String Environment) throws Exception {

        key.pause("50","");
        if(!isKafkaLaunched) {
            if(Constants.JenkinsBrowser == null || Constants.JenkinsBrowser.isEmpty()) {
                Constants.JenkinsBrowser = Constants.CONFIG.getProperty("browser");
            }

            Assert.assertTrue(Reusables.openBrowser("", Constants.JenkinsBrowser));
            LogCapture.info("Kafka UI is launching....");
            String kafkaUrl = Constants.CONFIG.getProperty("KafkaUIUrl");
            kafkaUrl = kafkaUrl.replace("{TOPIC}", topic).replace("{ENV}", Environment).replace("{MSL}", KafkaMessageCDID);
            Assert.assertEquals("PASS", Reusables.navigate("", kafkaUrl));

            Reusables.loginToKafkaUI();
//            System.out.println("Waiting for 20 seconds to login manually...");
//            ReusableMethod.pause(20);

//            int time = 0; LocalDateTime localDateTime = LocalDateTime.now();
//            while(time < 2000 && ReusableMethod.getTimeLapsedInSeconds(localDateTime) < 30) {
//                Constants.key.isElementDisplayed(Constants.KafkaUI.getProperty("LoadingTime"), 10);
//                String loadingTimeText = Constants.key.getText(Constants.KafkaUI.getProperty("LoadingTime"));
//                loadingTimeText = loadingTimeText.replace(" ms", "");
//                time = Integer.parseInt(loadingTimeText);
//            }
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            Constants.driver.navigate().refresh();

            isKafkaLaunched = true;
        } else if (isKafkaLaunched){
            String kafkaUrl = Constants.CONFIG.getProperty("KafkaUIUrl");
            kafkaUrl = kafkaUrl.replace("{TOPIC}", topic).replace("{ENV}", Environment).replace("{MSL}", KafkaMessageCDID);
            Assert.assertEquals("PASS", Reusables.navigate("", kafkaUrl));
//            Constants.driver.navigate().refresh();
        }else {
            Constants.driver.navigate().refresh();
        }
    }


    @And("^Verify Kafka message audit logs for \"([^\"]*)\"\"([^\"]*)\"$")
    public void verifyKafkaMessageAuditLogsFor(String AuditLogSqlQueryProperty,String Environment) throws Throwable {
        Map<String, String> auditRecord = ReusableMethod.getSqlQueryResult(AuditLogSqlQueryProperty, KafkaMessageCDID);
        System.out.println(auditRecord);
        ReusableMethod.verifyKafkaAuditLog(ExpectedKafkaKeyValues,auditRecord);
    }

    @And("^Do \"([^\"]*)\" banking DB verification and get IntradayStatementLineID for Indraday$")
    public void doBankingDBVerificationAndGetIntraStatementLineIDForIndraday(String Environment) throws Exception {
        String MessageInId=MessageInIdMap.get("MessageInId for 52");
        if (MessageInId==null){
            Object firstKey = MessageInIdMap.keySet().toArray()[0];
            MessageInId = MessageInIdMap.get(firstKey);
        }
        String IntradayStatementLine=Constants.key.VerifyDBDetails(Environment, MessageInId, "Find the StatementLineID for Indraday");
        Constants.IntradayStatementLineID=IntradayStatementLine;
        LogCapture.info("IntradayStatementLineID : " + IntradayStatementLineID);
//        HashMap<String,List<String>> remitter=new HashMap();
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo1"),List.of("20608830513822", "BROWN S"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo2"),List.of("NULL", "D+WOJC"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo3"),List.of("ES4721006073101300205825", "SIGNLED IMAGEN S.L. "));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo4"),List.of("20821330680435", "HUGHES B+K"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo5"),List.of("IE93IPBS99072625410215", ""));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo6"),List.of("IE93IPBS99072625410215", "HIGH TECH DEV LIMITED"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo7"),List.of("IE93IPBS99072625410215", "ADRIAN CHARLES LINDE CASTLEHILL CRESCENT"));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo8"),List.of("NULL",""));
//        remitter.put(Constants.CONFIG.getProperty("RemitterInfo9"),List.of("NULL", ""));
//        Assert.assertEquals("PASS",remitter.equals(ActualRemitterMap));

    }

    @And("^User gets banking MSL_ID for Indraday from \"([^\"]*)\" DB$")
    public void userGetsBankingMSL_IDForIndradayFromDB(String Environment) throws Exception {
        String MSL=Constants.key.VerifyDBDetails(Environment, IntradayStatementLineID, "Find the MSL_ID for Indraday");
        Constants.IndradayMSL_ID=MSL;
        Constants.KafkaMessageCDID =MSL;
        LogCapture.info("MSL_ID : " + IndradayMSL_ID);
    }

    @And("^Do DB verification and get CreditAdviceID \"([^\"]*)\"$")
    public void doDBVerificationAndGetCreditAdviceID(String Environment) throws Exception {

        if (MessageInId==null){
            Object firstKey = MessageInIdMap.keySet().toArray()[0];
            MessageInId = MessageInIdMap.get(firstKey);
        }
        String CreditAdvice=Constants.key.VerifyDBDetails(Environment, MessageInId, "Find the CreditAdviceID");
        Constants.CreditAdviceID=CreditAdvice;
        LogCapture.info("CreditAdviceID : " + CreditAdviceID);
    }

    @And("^User gets MSL_ID from \"([^\"]*)\" DB from CreditAdviceID$")
    public void userGetsMSL_IDFromDBFromCreditAdviceID(String Environment) throws Exception {
        String MSL=Constants.key.VerifyDBDetails(Environment, CreditAdviceID, "MSL_ID from CreditAdviceID");
        Constants.MSL_ID=MSL;
        Constants.KafkaMessageCDID =MSL;
        LogCapture.info("MSL_ID : " + MSL_ID);

    }

    @When("^Update \"([^\"]*)\" banking xml file for \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void updateBankingXmlFileFor(String FileType, String Bank, String AccountNumber,String CdtDbtInd) throws ParserConfigurationException, IOException, SAXException, TransformerException, InterruptedException {

        File NewCamtFile=new File("Files/"+Bank+"/" + NewFileName);

        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();  // Using XML classes to modify file content
        DocumentBuilder builder=factory.newDocumentBuilder();
        Document doc=builder.parse(NewCamtFile);
        Constants.doc1=doc;
        LogCapture.info(" Selected Document/File for updates is "+NewFileName);
//        DateTimeFormatter dtf=DateTimeFormatter.ISO_LOCAL_DATE;
//        DateTimeFormatter dtf1=DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        double InAmount=0;
        if(Amount.equalsIgnoreCase("")){
            String RandomNumber = RandomStringUtils.randomNumeric(3);
            InAmount = Double.parseDouble(RandomNumber);
            LogCapture.info("New Trade Amount : " + InAmount);
        }else{
            InAmount= Double.parseDouble(Amount);
        }
//            String RandomNumber = RandomStringUtils.randomNumeric(3);
//            double InAmount = Double.parseDouble(RandomNumber);
//            LogCapture.info("New Trade Amount : " + InAmount);
        if(Transaction_Reference_MessageOut!=null||Transaction_Reference!=null) {
            Constants.key.updateXmlFile("MsgId", Transaction_Reference_MessageOut);
            Constants.key.updateXmlFile("AcctSvcrRef", Transaction_Reference_MessageOut);
            Constants.key.updateXmlFile("EndToEndId", Transaction_Reference);
            Constants.key.updateXmlParentChild("Ntfctn", "Id", Transaction_Reference_MessageOut);
            Constants.key.updateXmlParentChild("Stmt", "Id", Transaction_Reference_MessageOut);
            Constants.key.updateXmlParentChild("Rpt", "Id", Transaction_Reference_MessageOut);
        }
        Constants.key.updateXmlFile("CdtDbtInd", "CdtDbtInd");
        Constants.key.updateXmlFile("CreDtTm", String.valueOf(now));  //Updating tag (CretTm) of xml files using new value
        Constants.key.updateXmlFile("DtTm", String.valueOf(now));
        Constants.key.updateXmlParentChild("Othr","Id", AccountNumber);
        if (FileType.equalsIgnoreCase("camt.053.") || FileType.equalsIgnoreCase("camt.053ALLEN.")|| FileType.equalsIgnoreCase("camt.053JPM1.")|| FileType.equalsIgnoreCase("camt.053JPM2.")|| FileType.equalsIgnoreCase("camt.053TREAS.")|| FileType.equalsIgnoreCase("camt.053Slash.")){
            Constants.key.updateXmlParentChild("Dt","Dt", currentDate);
            Constants.key.updateXmlParentChild("BookgDt","Dt", currentDate);
            Constants.key.updateXmlParentChild("ValDt","Dt", currentDate);
        }else {
            Constants.key.updateXmlFile("Dt", currentDate);
        }
//        Constants.key.updateXmlFile("Amt",String.valueOf(InAmount));

        double sum=0;
//        NodeList nodeList=doc.getElementsByTagName("Amt");
//        LogCapture.info("Number of Amt fields are " + nodeList.getLength());
//        for (int j=0; j < nodeList.getLength(); j++) {
//            Node node=nodeList.item(j);
//            node.setTextContent(String.valueOf(InAmount));
//            LogCapture.info("Value ot Amt(" + j + ") is " + InAmount);
//            sum=sum + InAmount;
//            InAmount=InAmount + 1.00;
//
//        }
        double lastAmount=0;                           //lastAmount = Amount used in last transaction

        if (FileType.equalsIgnoreCase("camt.05.2.")||FileType.equalsIgnoreCase("camt.052ROF.")){
            NodeList nodeList=doc.getElementsByTagName("Amt");
            LogCapture.info("Number of Amt fields are " + nodeList.getLength());
            for (int j=0; j < nodeList.getLength(); j++) {
                Node node=nodeList.item(j);
                node.setTextContent(String.valueOf(InAmount));
                LogCapture.info("Value ot Amt(" + j + ") is " + InAmount);
                sum=sum + InAmount;
                InAmount=InAmount + 1.00;

            }
            lastAmount = InAmount-1;
        } else {
            LogCapture.info("payment in amount is "+PaymentInAmount);
            if(PaymentInAmount.isEmpty()) {
                Constants.key.updateXmlFile("Amt",String.valueOf(InAmount));
            }else{
                InAmount= Double.parseDouble(PaymentInAmount);
                Constants.key.updateXmlFile("Amt",String.valueOf(InAmount));
            }

            lastAmount = InAmount;
        }
        // if you want to change AddtlNtryInf for single transaction then use below commented lines
        // if specific AddtlNtryInf need to change at config AddtlNtryInf
//        if (FileType.equalsIgnoreCase("camt.052REMI.")||FileType.equalsIgnoreCase("camt.053REMI.")){
//            String AddtlNtryInf = Constants.CONFIG.getProperty("AddtlNtryInf");
//            Constants.key.updateXmlFile("AddtlNtryInf", AddtlNtryInf);
//        }
        Constants.key.updateXmlFile("CdtDbtInd", CdtDbtInd);
        Constants.key.updateXmlFile("Sum",String.valueOf(sum));
        //PSR file updates
        if(Transaction_Reference_MessageOut==null) {
            Transaction_Reference_MessageOut="PET503825125";
        }
        if(Transaction_Reference==null){
            Transaction_Reference="PET503825125";
        }
        Constants.key.updateXmlFile("MsgId",Transaction_Reference_MessageOut);
        Constants.key.updateXmlFile("OrgnlMsgId",Transaction_Reference_MessageOut);
        Constants.key.updateXmlFile("OrgnlPmtInfId",Transaction_Reference);
        Constants.key.updateXmlFile("OrgnlEndToEndId",Transaction_Reference);
        Constants.key.updateXmlFile("OrgnlCtrlSum",Amount);
        Constants.key.updateXmlFile("ReqdExctnDt", currentDate);


        LogCapture.info("Required Tags are modified for file: "+NewFileName);

        TransformerFactory transformerFactory=TransformerFactory.newInstance(); //Updated information send to local NewCamtFile
        Transformer transformer=transformerFactory.newTransformer();
        DOMSource source=new DOMSource(doc1);
        StreamResult result=new StreamResult(NewCamtFile);
        transformer.transform(source, result);
        LogCapture.info(" Updates are saved in document/file: "+NewFileName);

        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        Constants.PaymentInAmount= decimalFormat.format((lastAmount));
        LogCapture.info("value of Payment In Amount at last transaction is: "+PaymentInAmount);
    }

    @When("^For a \"([^\"]*)\" call user push file from local to S3 bucket banking and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void forACallUserPushFileFromLocalToSBucketBankingAndCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID1, String Bank) throws Throwable {
        DateTimeFormatter date=DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime today=LocalDateTime.now();
        String nameDate=date.format(today);
        Constants.TCCaseID=testCaseID1;
//        Constants.SHEET_NAME=Environment;
        String Environment = Constants.CONFIG.getProperty("Environment");
        String filePath="Files/"+Bank+"/" + NewFileName;
        String destinationPath;
        if (NewFileName.contains("pain")){
            destinationPath="/home/ngopdr/banking_"+Environment+"/fileact/"+Bank+"/in/psr/"+nameDate+"/"+NewFileName;
        }else {
            destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/camt/" + nameDate + "/" + NewFileName;
        }
//        key.pause("2", "");
        Constants.RESPONSE=ServiceMethod.postAdvanceFileUploadToS3Bucket(testCaseID1, statCode, Constants.DynamicValue,filePath,destinationPath);
        JsonPath jp=Constants.APIkey.rawToJason(Constants.RESPONSE);

        LogCapture.info(jp+"---------------POST call ended----------------");
    }

    @When("^For a \"([^\"]*)\" call user generates banking messageIn and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void forACallUserGeneratesBankingMessageInAndCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String Environment, String Bank, String msg_type, String msg_ID, String queue_Name, String message_No) throws Throwable {
        key.pause("7","");
        Constants.message_No=message_No;
        Constants.TCCaseID=testCaseID;
        Constants.SHEET_NAME=Environment;
        DateTimeFormatter date=DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime today=LocalDateTime.now();
        String nameDate=date.format(today);
        String destinationPath ="";
        if(msg_type.equalsIgnoreCase("002.001.03")) {
            destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/psr/" + nameDate + "/" + NewFileName;
        }else{
            destinationPath = "/home/ngopdr/banking_" + Environment + "/fileact/" + Bank + "/in/camt/" + nameDate + "/" + NewFileName;
        }
        DynamicValue.put("<destinationPath>", destinationPath);
        DynamicValue.put("<msg_type>", msg_type);
        DynamicValue.put("<msg_ID>", msg_ID);
        DynamicValue.put("<queue_Name>", queue_Name);
        DynamicValue.put("<message_No>", message_No);

        LogCapture.info("---------------POST call started----------------");
        Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        LogCapture.info(jp+"---------------POST call ended----------------");
        Assert.assertFalse(RESPONSE.contains("null"));
        String external_reference_id=RESPONSE.split(":")[3].split("}")[0];
        LogCapture.info("MessageInId for "+message_No+" is: " + external_reference_id);

//        Constants.MessageInId=external_reference_id;
        MessageInIdMap.put("MessageInId for "+message_No,external_reference_id);
    }

    @And("^User \"([^\"]*)\" gets banking MSL_ID from DB for CAMT54$")
    public void userGetsBankingMSL_IDFromDBForCAMT54(String Environment) throws Exception {
        key.pause("2", "");
        Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine54", ConfirmationID);
        MSL_ID = result.get("ID");
        LogCapture.info("Value of MSL_ID is: " + MSL_ID);
        Assert.assertFalse(false, String.valueOf(MSL_ID.contains("null")));
        Constants.KafkaMessageCDID = MSL_ID;
    }

    @When("^Update BMO PaymentIn file$")
    public void updateBMOPaymentInFile() throws ParserConfigurationException, IOException, SAXException {
        String path="Files/BMO/" + NewFileName;
        LogCapture.info("New file name with paths is: "+path);
        Constants.filePath=path;

        Constants.key.modifyFile(filePath,dateReplace,currentDate);
        Constants.key.modifyFile(filePath,oldAmountStarting,newAmount);
        String lastAmount = newAmount + "9";
        double Amount = Integer.parseInt(lastAmount);
        double valueOfLastAmount= Amount/100;
        Constants.PaymentInAmount= String.valueOf(valueOfLastAmount);
    }

    @Given("^Update JPMG PaymentIn file \"([^\"]*)\"$")
    public void updateJPMGPaymentInFile(String AccountNumber) throws InterruptedException {

        String path="Files/JPMG/" + NewFileName;
        LogCapture.info("New file name with paths is: "+path);
        Constants.filePath=path;
//        key.pause("7","");
        Constants.key.modifyFile(filePath,dateReplace,currentDate);
        Reusables.modifyFile(filePath,OldAccountNumber,AccountNumber);
        Reusables.modifyFile(filePath,oldAmountStarting,newAmount);
        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        double one= Double.parseDouble(newAmount);
        Constants.PaymentInAmount= decimalFormat.format((one+0.37));
        LogCapture.info("Payment In amount is "+PaymentInAmount);
    }
//
//    @Given("^User launched application through \"([^\"]*)\" browser$")
//    public void userLaunchedApplicationThrough(String data) throws Throwable {
//
//        LogCapture.info(data + " Application is launching....");
//        String vBrowserName = Constants.CONFIG.getProperty("browser");
//        try {
//            if (Objects.equals(Constants.JenkinsBrowser, null)){
//                Constants.JenkinsBrowser = "";
//            }
//            else if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
//                vBrowserName = Constants.JenkinsBrowser;
//                LogCapture.info("Browser is :" + Constants.JenkinsBrowser);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));
//
//    }

    @And("^User navigate to Banking Application \"([^\"]*)\"$")
    public void userNavigateToBankingApplication(String vUrl) throws Exception {
        LogCapture.info("Banking Portal is loading....");

        String url=Constants.CONFIG.getProperty(vUrl);
        System.out.println("URLLInk:-> " + url);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
    }

    @When("^User enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click log In button on Banking Application$")
    public void userEnterUserNamePasswordAndClickLogInButtonOnBankingApplication(String userName, String password) throws Throwable {
        String vUserName=Constants.CONFIG.getProperty(userName);
        String vPassword=Constants.CONFIG.getProperty(password);
        String vObjUser=Constants.B2BOR.getProperty("Banking_Username");
        String vObjPass=Constants.B2BOR.getProperty("Banking_Password");

        LogCapture.info("User Name " + vUserName + ", Password " + password + " is validated ....");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));

        String vObjLoginButton=Constants.B2BOR.getProperty("Banking_LoginButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));

    }

    @Then("^User successfully landed on (TradingDashboardReport|DashBoard|Swapdeal|LimitDeal|BlotterReport|SpotDeal|Banking Dashboard|Banking Home|Spot Forward Deal|Swap Deal|AllTrade|MyTrade|TodayTrade|LiveTrade|PotentialDuplicateQueue|Account Balance|Balance Exception|Balance Entry|Bank Account|FXConfirmation Entries|Limit Deal|ROF Queue) page$")
    public void userShouldNavigateToTradingDashboardReportHomeScreen(String data) throws Exception {
        key.pause("6", "");
        if (data.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("Trading dashboard screen loading ......");

            String vObjAllTrade=Constants.B2BOR.getProperty("B2B_TradingDashboard_Alltrade");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjAllTrade, "All Trade"));
            String vObjMyTrade=Constants.B2BOR.getProperty("B2B_TradingDashboard_Mytrade");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjMyTrade, "My Trade"));
            String vObjTodayTrade=Constants.B2BOR.getProperty("B2B_TradingDashboard_Todaytrade");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTodayTrade, "Today Trade"));
            String vObjLiveTrade=Constants.B2BOR.getProperty("B2B_TradingDashboard_Livetrade");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjLiveTrade, "Live Trade(Limit Order)"));

        }
        if (data.equalsIgnoreCase("BlotterReport")) {
            LogCapture.info("Trading dashboard screen loading ......");
            String vObjOrganization=Constants.B2BOR.getProperty("B2B_BlotterReport_Organization");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjOrganization, "Organization:"));
            String vObjTreasureCategory=Constants.B2BOR.getProperty("B2B_BlotterReport_TreasuryCategory");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjTreasureCategory, "Treasury Category"));

        }
        if (data.equalsIgnoreCase("Banking Dashboard")) {
            LogCapture.info("Dashboard loading ......");
            String vobjectDashboard=Constants.B2BOR.getProperty("Banking_Dashboard");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Banking Accounts"));
        }
        if (data.equalsIgnoreCase("Banking Home")) {
            LogCapture.info("Banking Home Page loading ......");

            String vobjectDashboard=Constants.B2BOR.getProperty("Banking_Dashboard");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Banking Accounts"));

        }
        if (data.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("Dashboard Page loading ......");

            String vObjectB2BPage=Constants.B2BOR.getProperty("B2BPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectB2BPage, ""));
            //Assert.assertEquals("PASS", Constants.key.verifyText(vObjectB2BPage, "Banking Accounts"));

        }
        if (data.equalsIgnoreCase("Spot Forward Deal")) {
            LogCapture.info("Spot Forward Deal Page loading ......");

            String vObjSpotDealBooing=Constants.B2BOR.getProperty("SpotDealBooking");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotDealBooing, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjSpotDealBooing, "Spot deal booking"));

        }
        if (data.equalsIgnoreCase("Swap Deal")) {
            LogCapture.info("Swap Deal Page loading ......");

            String vObjSwapDeal_Text=Constants.B2BOR.getProperty("SwapDeal_Text");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal_Text, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjSwapDeal_Text, "Book swap deal"));

        }
        if (data.equalsIgnoreCase("AllTrade") || data.equalsIgnoreCase("MyTrade") || data.equalsIgnoreCase("TodayTrade")) {
            String vObjTradeData=Constants.B2BOR.getProperty("B2B_TradingDashboard_Trade_count");
            Assert.assertNotEquals("PASS", vObjTradeData, "0");
        }
        if (data.equalsIgnoreCase("PotentialDuplicateQueue")) {

            String vObjBankingMenu_DuplicateQueue=Constants.BankingOR.getProperty("BankingMenu_DuplicateQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_DuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBankingMenu_DuplicateQueue, "Duplicate Queue"));


        }
        if (data.equalsIgnoreCase("ROF Queue")) {
            LogCapture.info("User Click on ROF Queue ......");
            String vObjBankingMenu_ROFQueue=Constants.BankingOR.getProperty("BankingMenu_ROFQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_ROFQueue, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBankingMenu_ROFQueue, "ROF Queue"));
            LogCapture.info("User Clicked on ROF Queue and ROF Queue is opened......");

        }
        if (data.equalsIgnoreCase("Account Balance")) {

            String vPageLoader=Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjBnkOpeningAccBalance=Constants.BankingOR.getProperty("BNK_AccountBalance_OpeningBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBnkOpeningAccBalance, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBnkOpeningAccBalance, "OpeningBalance"));
            String vObjBnkClosingAccBalance=Constants.BankingOR.getProperty("BNK_AccountBalance_ClosingBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBnkClosingAccBalance, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBnkClosingAccBalance, "ClosingBalance"));

        }
        if (data.equalsIgnoreCase("Balance Exception")) {

            String vObjBnkOpeningAccBalance=Constants.BankingOR.getProperty("BNK_BalanceException_OpeningBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBnkOpeningAccBalance, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBnkOpeningAccBalance, "OpeningBalance"));
            String vObjBnkClosingAccBalance=Constants.BankingOR.getProperty("BNK_BalanceException_ClosingBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBnkClosingAccBalance, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBnkClosingAccBalance, "ClosingBalance"));

        }
        if (data.equalsIgnoreCase("Balance Entry")) {

            String vObjBalanceEntry_Table=Constants.BankingOR.getProperty("BalanceEntry_Table");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBalanceEntry_Table, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjBalanceEntry_Table, ""));

        }

        if (data.equalsIgnoreCase("Bank Account")) {
            LogCapture.info("Bank Account Page loading ......");

            String vObjBankAccountTable=Constants.BankingOR.getProperty("BNK_BankAccountTableID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankAccountTable, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjBankAccountTable, ""));

        }
        if (data.equalsIgnoreCase("FXConfirmation Entries")) {
            LogCapture.info("FXConfirmation Entries Page loading ......");

            String vObjInstitutionColumnHeader=Constants.FXConfirmationOR.getProperty("InstitutionColumnHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInstitutionColumnHeader, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjInstitutionColumnHeader, ""));
            String vObjSendersReferenceColumnHeader=Constants.FXConfirmationOR.getProperty("SendersReferenceColumnHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSendersReferenceColumnHeader, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjSendersReferenceColumnHeader, ""));
            String URL=Constants.key.getPageURL("", "");
            String vObjFXConfirmationEntriesPage=Constants.FXConfirmationOR.getProperty("FXCorimationPage");
            Assert.assertEquals("PASS", Constants.key.VerifySubstring(URL, vObjFXConfirmationEntriesPage));

        }
        if (data.equalsIgnoreCase("Limit Deal")) {
            LogCapture.info("Dashboard loading ......");

            String vB2B_LimitDealText=Constants.B2BOR.getProperty("B2B_LimitDealText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2B_LimitDealText, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vB2B_LimitDealText, "Limit deal booking"));

        }
    }

    @When("^User click on (Reset Filter1|FXConfirmation Entries|FXConfirmation|B2B|Dashboard|Spot Forward Deal|TradingDashBoardReport|BlotterReport|Swap Deal|Banking|Potential Duplicate Queue|RFQ|Event Log|Organization Details|Opening Closing|OrgCurrency Details|One Time Configurable|Rule Engine|Pending B2B Deals|CounterParty|Account Balance|Balance Exception|Balance Entry|Payment Monitoring|Payment Approval|Rejected Payment List|Bank Account|Message|Message Out|Failed Payment Out|Query Management|Queries|Manual Payment Upload|Manual PSR Upload|FX Confirmation|Limit Deal|ROF Queue) Menu from (Dashboard|B2B|Banking|RFQ|Payment Monitoring|Message|Query Management|FXConfirmation)$")
    public void userClickOnBBMenuFromDashboard(String MainMenu, String SubMenu) throws Exception {
        key.pause("10", "");
        if (MainMenu.equalsIgnoreCase("B2B") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on B2B Menu ......");

            //String vPageLoader=Constants.BankingOR.getProperty("Banking_PageLoader");
            //Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjectB2BMenu=Constants.B2BOR.getProperty("B2BMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectB2BMenu, ""));
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vObjectB2BMenu,""));
            key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjectB2BMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Dashboard") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Dashboard Menu from B2B ......");

            String vObjectB2B_Dashboard=Constants.B2BOR.getProperty("B2B_Dashboard");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectB2B_Dashboard, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjectB2B_Dashboard, ""));


        } else if (MainMenu.equalsIgnoreCase("Spot Forward Deal") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Spot Forward Deal Menu from B2B ......");

            String vObjSpotForwadDeal=Constants.B2BOR.getProperty("SpotForwadDeal");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSpotForwadDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSpotForwadDeal, ""));


        } else if (MainMenu.equalsIgnoreCase("Swap Deal") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Swap Deal Menu from B2B ......");

            String vObjSwapDeal=Constants.B2BOR.getProperty("SwapDeal");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSwapDeal, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSwapDeal, ""));

        } else if (MainMenu.equalsIgnoreCase("TradingDashBoardReport") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Trading dashboard report Menu from B2B ......");

            String vObjTradingDashboardReport=Constants.B2BOR.getProperty("B2B_TradingDashboard");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjTradingDashboardReport, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjTradingDashboardReport, ""));


        } else if (MainMenu.equalsIgnoreCase("BlotterReport") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Blotter report Menu from B2B ......");

            String vObjBlotterReport=Constants.B2BOR.getProperty("B2B_BlotterReport");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBlotterReport, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBlotterReport, ""));


        } else if (MainMenu.equalsIgnoreCase("Trading Dash Board Report") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Trading Dash Board Report Menu from B2B ......");

            String vObjBlotterReport=Constants.B2BOR.getProperty("B2B_TrandingDashboardReport");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlotterReport, ""));


        } else if (MainMenu.equalsIgnoreCase("Banking") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Banking Menu from Dashboard ......");

            String vPageLoader=Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            String vObjBanking_BankingMenu=Constants.BankingOR.getProperty("Banking_BankingMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBanking_BankingMenu, ""));
            key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjBanking_BankingMenu, ""));


        } else if (MainMenu.equalsIgnoreCase("Potential Duplicate Queue") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Potential Duplicate Queue Menu from Dashboard ......");

            String vObjBankingMenu_PotentialDuplicateQueue=Constants.BankingOR.getProperty("BankingMenu_PotentialDuplicateQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_PotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBankingMenu_PotentialDuplicateQueue, ""));


        } else if (MainMenu.equalsIgnoreCase("ROF Queue") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on ROF Queue Menu from Dashboard ......");

            String vObjBankingMenu_ROF_Queue=Constants.BankingOR.getProperty("BankingMenu_ROF_Queue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_ROF_Queue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBankingMenu_ROF_Queue, ""));
            LogCapture.info("User Clicked on ROF Queue Menu from Dashboard ......");

        } else if (MainMenu.equalsIgnoreCase("RFQ") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on RFQ Menu ......");

            String vObjectRFQMenu=Constants.RFQOR.getProperty("RFQMenu");
            String vPageLoader=Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjectRFQMenu, ""));
            key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjectRFQMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Event Log") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Event Log Menu from RFQ ......");

            String vObjEventLog=Constants.RFQOR.getProperty("RFQ_EventLog");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEventLog, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjEventLog, ""));
        } else if (MainMenu.equalsIgnoreCase("Organization Details") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Organization details Menu from RFQ ......");

            String vObjOrganizationDetails=Constants.RFQOR.getProperty("RFQ_OrganizationDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganizationDetails, ""));

            Assert.assertEquals("PASS", Constants.key.ClickableConditionWait(vObjOrganizationDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrganizationDetails, ""));
        } else if (MainMenu.equalsIgnoreCase("Opening Closing") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Opening Closing Menu from RFQ ......");

            String vObjOpeningClosing=Constants.RFQOR.getProperty("RFQ_OpeningClosingDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOpeningClosing, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOpeningClosing, ""));
        } else if (MainMenu.equalsIgnoreCase("OrgCurrency Details") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on OrgCurrency Details Menu from RFQ ......");

            String vObjOrgCurrencyDetails=Constants.RFQOR.getProperty("RFQ_OrgCurrencyDetails");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrgCurrencyDetails, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOrgCurrencyDetails, ""));
        } else if (MainMenu.equalsIgnoreCase("One Time Configurable") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on One Time Configurable Menu from RFQ ......");

            String vObjOneTimeConfigurable=Constants.RFQOR.getProperty("RFQ_OneTimeConfigurableScheduler");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOneTimeConfigurable, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOneTimeConfigurable, ""));
        } else if (MainMenu.equalsIgnoreCase("Pending B2B Deals") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Pending B2B Deals Menu from RFQ ......");

            String vObjOPendingB2B=Constants.RFQOR.getProperty("RFQ_PendingB2BDeals");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOPendingB2B, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjOPendingB2B, ""));
        }
        // CounterParty
        else if (MainMenu.equalsIgnoreCase("CounterParty") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on CounterParty Menu from RFQ ......");

            String vObjCounterParty=RFQOR.getProperty("RFQ_CounterParty");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCounterParty, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCounterParty, ""));
        }
        // CounterParty
        else if (MainMenu.equalsIgnoreCase("Rule Engine") && SubMenu.equalsIgnoreCase("RFQ")) {
            LogCapture.info("User Click on Rule Engine Menu from RFQ ......");
            key.pause("7","");
            String vObjRuleEngine=Constants.RFQOR.getProperty("RFQ_RuleEngine");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRuleEngine, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjRuleEngine, ""));
        } else if (MainMenu.equalsIgnoreCase("Account Balance") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Account Balance Menu from Dashboard ......");

            String vObjBNKAccountBalance=Constants.BankingOR.getProperty("BNK_AccountBalance");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNKAccountBalance, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBNKAccountBalance, ""));

        } else if (MainMenu.equalsIgnoreCase("Balance Exception") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Balance Exception Menu from Dashboard ......");

            String vObjBNKBalException=Constants.BankingOR.getProperty("BNK_BalanceException");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNKBalException, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBNKBalException, ""));

        } else if (MainMenu.equalsIgnoreCase("Balance Entry") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Balance Entry ......");

            String vObjBankingMenu_BalanceEntries=Constants.BankingOR.getProperty("BankingMenu_BalanceEntries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBankingMenu_BalanceEntries, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBankingMenu_BalanceEntries, ""));


        } else if (MainMenu.equalsIgnoreCase("Payment Monitoring") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Payment Monitoring Menu ......");

            String vObjectPaymentMonitoringMenu=Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring");
            String vPageLoader=Constants.BankingOR.getProperty("Banking_PageLoader");
            Assert.assertEquals("PASS", Constants.key.invisibleConditionWait(vPageLoader, ""));

            Assert.assertEquals("PASS", Constants.key.click(vObjectPaymentMonitoringMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Payment Approval") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Payment Approval ......");

            String vBanking_PaymentMonitoring_PaymentApproval=Constants.PaymentMonitoringOR.getProperty("Banking_PaymentMonitoring_PaymentApproval");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_PaymentMonitoring_PaymentApproval, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_PaymentMonitoring_PaymentApproval, ""));

        } else if (MainMenu.equalsIgnoreCase("Payment Approval") && SubMenu.equalsIgnoreCase("Payment Monitoring")) {
            LogCapture.info("User Click on Payment Approval ......");

            String vBanking_RejectedPayment=Constants.PaymentMonitoringOR.getProperty("Banking_RejectedPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_RejectedPayment, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_RejectedPayment, ""));
        } else if (MainMenu.equalsIgnoreCase("Bank Account") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Bank Account Menu from Dashboard ......");

            String vObjBNKBankAccount=Constants.BankingOR.getProperty("BNK_BankAccount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBNKBankAccount, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBNKBankAccount, ""));

        } else if (MainMenu.equalsIgnoreCase("Message") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Message Menu from Dashboard ......");

            String vBanking_Message=Constants.MessageOR.getProperty("Banking_Message");
            key.pause("6", "");
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vBanking_Message, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_Message, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_Message, ""));

        } else if (MainMenu.equalsIgnoreCase("Message Out") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Message Out Menu from Message ......");

            String vBanking_Message_MessageOut=Constants.MessageOR.getProperty("Banking_Message_MessageOut");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_Message_MessageOut, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_Message_MessageOut, ""));

        } else if (MainMenu.equalsIgnoreCase("Failed Payment Out") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Failed Payment Out from Dashboard ......");
            key.pause("4", "");
            String vBanking_Message_FailedPaymentOut=Constants.MessageOR.getProperty("Banking_Message_FailedPaymentOut");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_Message_FailedPaymentOut, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_Message_FailedPaymentOut, ""));

        } else if (MainMenu.equalsIgnoreCase("Payment Monitoring") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Payment Monitoring Menu from Dashboard ......");

            String vObjBanking_BankingMenu=Constants.BankingOR.getProperty("BNK_PaymentMonitoring");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBanking_BankingMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjBanking_BankingMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Query Management") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Query Management Menu from Dashboard ......");

            String vQueryMgmt=Constants.QueryManagementOR.getProperty("BNK_QM");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueryMgmt, ""));
            key.pause("7","");
            Assert.assertEquals("PASS", Constants.key.click(vQueryMgmt, ""));


        } else if (MainMenu.equalsIgnoreCase("Queries") && SubMenu.equalsIgnoreCase("Query Management")) {
            LogCapture.info("User Click on Queries Menu from Query Management ......");

            String vQueryMgmt_Queries=Constants.QueryManagementOR.getProperty("BNK_QM_Queries");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueryMgmt_Queries, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQueryMgmt_Queries, ""));

        } else if (MainMenu.equalsIgnoreCase("Manual Payment Upload") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Manual Payment Upload from Message ......");

            String vBanking_ManualPaymentUpload=Constants.MessageOR.getProperty("Banking_ManualPaymentUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPaymentUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUpload, ""));
        } else if (MainMenu.equalsIgnoreCase("Manual PSR Upload") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Manual PSR Upload from Message ......");

            String vBanking_ManualPSRUpload=Constants.MessageOR.getProperty("Banking_ManualPSRUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPSRUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPSRUpload, ""));
        } else if (MainMenu.equalsIgnoreCase("FXConfirmation") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on FXConfirmation from Dashboard ......");

            String vObjFXConfirmationMenu=Constants.FXConfirmationOR.getProperty("FXConfirmationMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXConfirmationMenu, ""));
            key.pause("6", "");
            Assert.assertEquals("PASS", Constants.key.click(vObjFXConfirmationMenu, ""));

        } else if (MainMenu.equalsIgnoreCase("FXConfirmation Entries") && SubMenu.equalsIgnoreCase("FXConfirmation")) {
            LogCapture.info("User Click on FXConfirmation Entries Menu from FXConfirmation ......");

            String vObjFXConfirmationEntriesSubmenu=Constants.FXConfirmationOR.getProperty("FXConfirmationEntriesSubmenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXConfirmationEntriesSubmenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFXConfirmationEntriesSubmenu, ""));

        } else if (MainMenu.equalsIgnoreCase("Message") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on Message Menu from Dashboard ......");

            String vMessage=Constants.MessageOR.getProperty("BNK_Message");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMessage, ""));
            Assert.assertEquals("PASS", Constants.key.click(vMessage, ""));
        } else if (MainMenu.equalsIgnoreCase("Failed Payment Out") && SubMenu.equalsIgnoreCase("Message")) {
            LogCapture.info("User Click on Failed Payment Out Sub Menu from Message ......");

            String vMessage_FPO=Constants.MessageOR.getProperty("BNK_Message_FPO");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMessage_FPO, ""));
            Assert.assertEquals("PASS", Constants.key.click(vMessage_FPO, ""));

        } else if (MainMenu.equalsIgnoreCase("FX Confirmation") && SubMenu.equalsIgnoreCase("Dashboard")) {
            LogCapture.info("User Click on FX Confirmation Menu ......");

            String vFXConfirmation=Constants.FXConfirmationOR.getProperty("BNK_FXConfirmation");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFXConfirmation, ""));
            Assert.assertEquals("PASS", Constants.key.javascrpiptScroll(vFXConfirmation, ""));
            key.pause("6", "");
            Assert.assertEquals("PASS", Constants.key.click(vFXConfirmation, ""));

        } else if (MainMenu.equalsIgnoreCase("Limit Deal") && SubMenu.equalsIgnoreCase("B2B")) {
            LogCapture.info("User Click on Limit Deal Menu ......");

            String vB2B_LimitDealMenu=Constants.B2BOR.getProperty("B2B_LimitDealMenu");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vB2B_LimitDealMenu, ""));
            Assert.assertEquals("PASS", Constants.key.click(vB2B_LimitDealMenu, ""));


        }

    }

    @Then("^User successfully landed on (Potential Duplicate Queue) page in Banking PDQ$")
    public void userSuccessfullyLandedOnPotentialDuplicateQueuePageInBankingPDQ(String Menu) throws Throwable {
        if (Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Successfully Landed On Potential Duplicate Queue Page......");

            String vBNK_PDQ_TableID = Constants.BankingOR.getProperty("BNK_PDQ_TableID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PDQ_TableID, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_PDQ_TableID, ""));
        }
    }

    @Then("^User search the (IntradayStatementLineID|StatementLineID) and Accept the Record for (PDQ|ROF)$")
    public void userSearchTheIntradayStatementLineIDAndAcceptTheRecordFor(String ID,String Menu) throws Throwable{
        key.pause("4", "");
        if (Menu.equalsIgnoreCase("PDQ")) {
            String CDPDQ_ItraStmID= Constants.BankingOR.getProperty("PDQ_ItraStmID");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CDPDQ_ItraStmID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(CDPDQ_ItraStmID, IntradayStatementLineID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CDPDQ_ItraStmID, "enter"));
            key.pause("4", "");
            String vObjPDQRecord = Constants.BankingOR.getProperty("BNK_PDQ_FirstRowInput");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPDQRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPDQRecord, ""));

            String vBNK_DuplicatePaymentQueue_AcceptPayment = Constants.BankingOR.getProperty("BNK_DuplicatePaymentQueue_AcceptPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_DuplicatePaymentQueue_AcceptPayment, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vBNK_DuplicatePaymentQueue_AcceptPayment, ""));

        }if (Menu.equalsIgnoreCase("ROF")) {
            String CDROF_ID= Constants.BankingOR.getProperty(ID);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CDROF_ID, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(CDROF_ID, ID));
            Assert.assertEquals("PASS", Constants.key.KeyboardAction(CDROF_ID, "enter"));
            key.pause("4", "");
            String vROFQueueCheckbox = Constants.BankingOR.getProperty("BNKROFQueueCheckbox");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.click(vROFQueueCheckbox, ""));
            Assert.assertEquals("PASS", Constants.key.MouseFunctions(vROFQueueCheckbox, "RightClick"));
            String vROFQueueAccept = Constants.BankingOR.getProperty("BNKROFQueueAccept");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueAccept, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vROFQueueAccept, ""));
            Alert alert = driver.switchTo().alert();
            alert.accept();
            Constants.key.pause("2", "");
            String vROFQueueLegalEntity = Constants.BankingOR.getProperty("BNKROFQueueLegalEntity");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueLegalEntity, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueLegalEntity, Legal_Entity));
            LogCapture.info(Legal_Entity+" is entered on UI");
            Constants.key.pause("2", "");
            String vROFQueueClientReference = Constants.BankingOR.getProperty("BNKROFQueueClientReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueClientReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueClientReference, "Test 123"));
            LogCapture.info(" ROF Queue Client Reference = Test 123 is entered on UI");
            String BNKROFQueuePaymentReference = Constants.BankingOR.getProperty("BNKROFQueuePaymentReference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(BNKROFQueuePaymentReference, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(BNKROFQueuePaymentReference, "Test 123"));
            LogCapture.info(" ROF Queue Payment Reference = Test 123 is entered on UI");
            Constants.key.pause("2", "");
            String vROFQueueReasonOfROF = Constants.BankingOR.getProperty("BNKROFQueueReasonOfROF");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueReasonOfROF, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vROFQueueReasonOfROF, "Test ROF"));
            LogCapture.info(" ROF Queue Reason Of ROF = Test ROF is entered on UI");
            Constants.key.pause("2", "");
            String vROFQueueSubmit = Constants.BankingOR.getProperty("BNKROFQueueSubmit");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vROFQueueSubmit, ""));
            Assert.assertEquals("PASS", Constants.key.clickAndHandleAlert(vROFQueueSubmit,""));
            Constants.key.pause("2", "");
            Alert alert1 = driver.switchTo().alert();
            alert1.accept();
            LogCapture.info(" User click on ROF Queue Submit Button");
        }
    }

    @Then("^User should successfully see alert messages \"([^\"]*)\" on (Duplicate Payment Queue|Change Properties|Potential Duplicate Queue|Account Balance|Failed Payment Out|Payment Approval) Page$")
    public void userShouldSuccessfullySeeAlertMessagesOnDuplicatePaymentQueuePage(String Alert, String Menu) throws Throwable {
        key.pause("6", "");
        if (Menu.equalsIgnoreCase("Duplicate Payment Queue") || Menu.equalsIgnoreCase("Change Properties") || Menu.equalsIgnoreCase("Potential Duplicate Queue") || Menu.equalsIgnoreCase("Account Balance") || Menu.equalsIgnoreCase("Failed Payment Out") || Menu.equalsIgnoreCase("Payment Approval")) {
            LogCapture.info("User see alert message respective page......");

            String alertMessage = Constants.key.removeSpaces(Constants.key.getAlertText());
            System.out.println("Value is " + Alert);
            System.out.println("Alert message is " + alertMessage);
            Assert.assertTrue(alertMessage.contains(Alert));

        }
    }

    @And("^User gets Legal Entity for Indraday from \"([^\"]*)\" DB$")
    public void userGetsAccountNumberAndLegalEntityForIndradayFromDB(String Environment) throws Throwable {
        String LegalEntity=Constants.key.VerifyDBDetails(Environment, IntradayStatementLineID, "Find Legal Entity for IntradayStatmentLineID");
        Constants.Legal_Entity=LegalEntity;
        LogCapture.info("Legal Entity is : " + LegalEntity);
    }

    @And("^User click on (PotentialDuplicateQueue|Manual Balance Upload|Manual Entries Upload) Menu from (Banking)$")
    public void userClickOnPotentialDuplicateQueueMenuFromDashboard(String MainMenu, String SubMenu) throws Exception {
        if (MainMenu.equalsIgnoreCase("PotentialDuplicateQueue") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Potential Duplicate Queue ......");

            String vPotentialDuplicateQueue=Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPotentialDuplicateQueue, ""));

        }
        if (MainMenu.equalsIgnoreCase("Manual Balance Upload") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Manual Balance Upload ......");

            String vPotentialDuplicateQueue=Constants.BankingOR.getProperty("BNK_ManualBalanceUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPotentialDuplicateQueue, ""));

        }
        if (MainMenu.equalsIgnoreCase("Manual Entries Upload") && SubMenu.equalsIgnoreCase("Banking")) {
            LogCapture.info("User Click on Manual Entries Upload ......");

            String vPotentialDuplicateQueue=Constants.BankingOR.getProperty("BNK_ManualEntriesUpload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPotentialDuplicateQueue, ""));
            Assert.assertEquals("PASS", Constants.key.click(vPotentialDuplicateQueue, ""));

        }
    }

    @Then("^User successfully landed on (Potential Duplicate Queue|Manual Balance Upload|Manual Entries Upload|Queries|Incoming Queries|Pending Authorise|Failed Payment Out|FX Confirmation|Query Exception) page$")
    public void userShouldNavigateToPotentialDuplicateQueue(String data) throws Exception {
        if (data.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("Potential Duplicate Queue screen loading ......");

            String vDuplicateQueue=Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue_DuplicateQueue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDuplicateQueue, "Duplicate Queue"));
        }
        if (data.equalsIgnoreCase("Manual Balance Upload")) {
            LogCapture.info("Manual Balance Upload screen loading ......");

            String vDuplicateQueue=Constants.BankingOR.getProperty("BNK_ManualBalanceUpload_SelectExcelFile");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDuplicateQueue, "Please select a excel file for process:"));

        }
        if (data.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info("Manual Entries Upload screen loading ......");

            String vDuplicateQueue=Constants.BankingOR.getProperty("BNK_ManualEntriesUpload_Tab");
            Assert.assertEquals("PASS", Constants.key.verifyText(vDuplicateQueue, "Manual Entries Upload"));

        }
        if (data.equalsIgnoreCase("Queries")) {
            LogCapture.info("Queries screen loading ......");

            String vQMQueriesTable=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_Table");
            //Assert.assertEquals("PASS", Constants.key.verifyText(vQMQueriesTable, "Manual Entries Upload"));
            Assert.assertEquals("PASS", Constants.key.exist(vQMQueriesTable, ""));

        }
        if (data.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("Incoming Queries screen loading ......");

            String vQMIncomingQueriesTable=Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_Table");
            //Assert.assertEquals("PASS", Constants.key.verifyText(vQMQueriesTable, "Manual Entries Upload"));
            Assert.assertEquals("PASS", Constants.key.exist(vQMIncomingQueriesTable, ""));

        }
        if (data.equalsIgnoreCase("Query Exception")) {
            LogCapture.info("Query Exception screen loading ......");

            String vBNK_QM_QueryException_Table=Constants.QueryManagementOR.getProperty("BNK_QM_QueryException_Table");
            //Assert.assertEquals("PASS", Constants.key.verifyText(vQMQueriesTable, "Manual Entries Upload"));
            Assert.assertEquals("PASS", Constants.key.exist(vBNK_QM_QueryException_Table, ""));
        }
        if (data.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("Pending Authorise screen loading ......");

            String vQMPendingAuthoriseTable=Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_PendingAuthoriseTable");
            Assert.assertEquals("PASS", Constants.key.exist(vQMPendingAuthoriseTable, ""));
        }
        if (data.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("Failed Payment Out screen loading ......");

            String vMessageFPOTable=Constants.MessageOR.getProperty("BNK_Message_FPOTable");
            Assert.assertEquals("PASS", Constants.key.exist(vMessageFPOTable, ""));

        }
        if (data.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("FX Confirmation screen loading ......");

            String vFXC_Organization=Constants.FXConfirmationOR.getProperty("BNK_FXC_Organization");
            Assert.assertEquals("PASS", Constants.key.exist(vFXC_Organization, ""));

        }
    }

    @And("^User click on (Select Institution|FCG|Reset Filter|Choose File|PotentialDuplicateQueueRecord|Upload Button|Reference|OrganizationName|Rename File) from (Potential Duplicate Queue|Manual Balance Upload|Manual Entries Upload|Pending Authorise|Queries|TradingDashboardReport|Lacaxia Upload|Manual Payment Upload_JPMG|Manual Payment Upload_CITI) page$")
    public void userClickOnSelectInstitutionFromPotentialDuplicateQueuePage(String Value, String Menu) throws Throwable {
        key.pause("2","");
        if (Value.equalsIgnoreCase("Select Institution") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on Select Institution ......");

            String vSelectInstitution = Constants.BankingOR.getProperty("BNK_BankAccount_Institution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectInstitution, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectInstitution, ""));
        }
        if (Value.equalsIgnoreCase("FCG") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on FCG ......");

            String vSelectInstitutionFCG = Constants.BankingOR.getProperty("BNK_BankAccount_InstituteValue_FCG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectInstitutionFCG, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectInstitutionFCG, ""));
        }
        if (Value.equalsIgnoreCase("Reset Filter") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on reset filter at top right corner.....");

            String vResetFilter = Constants.BankingOR.getProperty("BNK_AccountBalance_ResetFilter");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vResetFilter, ""));
            Assert.assertEquals("PASS", Constants.key.click(vResetFilter, ""));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Balance Upload")) {
            LogCapture.info("User Click on Choose file.....");

            String pathtoUpload=System.getProperty("user.dir") + "/files/ManualBalanceUpload.xlsx";
            String vBanking_ManualBalanceUploadFile=Constants.BankingOR.getProperty("BNK_ManualBalanceUpload_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualBalanceUploadFile, pathtoUpload));

        }
        if (Value.equalsIgnoreCase("Upload Button") && Menu.equalsIgnoreCase("Manual Balance Upload")) {
            LogCapture.info("User Click on Upload.....");

            String vFileUpload = Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_Upload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFileUpload, ""));
        }
        if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info("User Click on Choose file.....");
            Constants.key.pause("5", "");
            String vBNK_ChooseFile=Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            //String pathtoUpload=System.getProperty("user.dir") + "/Files/ManualEnteriesUpload_2022-07-28-18-08-07.xlsx";

//            Assert.assertEquals("PASS", Constants.key.click(vBNK_ChooseFile, ""));    // already commented

            DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now=LocalDateTime.now();
            String currentDate=dtf.format(now);

            File camtFile=null;
            File directoryPath=new File("Files/");

            String contents[]=directoryPath.list();

            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i=0; i < contents.length; i++) {
                if (contents[i].contains("ManualEnteriesUpload")) {
                    camtFile=new File("Files/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            File Rename=new File("Files/ManualEnteriesUpload_" + currentDate + ".xlsx" );
            camtFile.renameTo(Rename);

            String newFileName=System.getProperty("user.dir") + "/Files/"+Rename.getName();
            String vBanking_ManualBalanceUploadFile=Constants.BankingOR.getProperty("BNK_ManualBalanceUpload_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualBalanceUploadFile, newFileName));
        }if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Lacaxia Upload")) {
            LogCapture.info("User Click on Choose file.....");
            Constants.key.pause("5", "");
            String vBNK_ChooseFile=Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            //String pathtoUpload=System.getProperty("user.dir") + "/Files/ManualEnteriesUpload_2022-07-28-18-08-07.xlsx";

//            Assert.assertEquals("PASS", Constants.key.click(vBNK_ChooseFile, ""));    // already commented

            DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now=LocalDateTime.now();
            String currentDate=dtf.format(now);

            File camtFile=null;
            File directoryPath=new File("Files/Manual Entries/");

            String contents[]=directoryPath.list();

            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i=0; i < contents.length; i++) {
                if (contents[i].contains("ManualEnteriesUpload")) {
                    camtFile=new File("Files/Manual Entries/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename=new File("Files/Manual Entries/ManualEnteriesUpload_" + currentDate + ".xlsx" );
            camtFile.renameTo(Rename);

//            String newFileName=System.getProperty("user.dir") + "/Files/Manual Entries/"+Rename.getName();
//            String vBanking_ManualBalanceUploadFile=Constants.BankingOR.getProperty("BNK_ManualBalanceUpload_ChooseFile");
//            Assert.assertEquals("PASS", Constants.key.UploadFile(vBanking_ManualBalanceUploadFile, newFileName));
        }if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Payment Upload_JPMG")) {
            LogCapture.info("User verify file upload ......");
            String vBNK_ChooseFile=Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now=LocalDateTime.now();
            String currentDate=dtf.format(now);
            File camtFile=null;
            File directoryPath=new File("Files/Manual_Payment/");
            String contents[]=directoryPath.list();
            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i=0; i < contents.length; i++) {
                if (contents[i].contains("Manual_Payment_Upload_USD")) {
                    camtFile=new File("Files/Manual_Payment/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename=new File("Files/Manual_Payment/Manual_Payment_Upload_USD" + currentDate + ".xlsx" );
            camtFile.renameTo(Rename);
//            String newFileName = System.getProperty("user.dir") + "/Files/Manual_Payment/" + Rename.getName();
//            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
//            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        }if (Value.equalsIgnoreCase("Choose File") && Menu.equalsIgnoreCase("Manual Payment Upload_CITI")) {
            LogCapture.info("User verify file upload ......");
            String vBNK_ChooseFile=Constants.BankingOR.getProperty("BNK_ChooseFile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_ChooseFile, ""));
            DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd-hh-mm-ss");
            LocalDateTime now=LocalDateTime.now();
            String currentDate=dtf.format(now);
            File camtFile=null;
            File directoryPath=new File("Files/Manual_Payment/");
            String contents[]=directoryPath.list();
            LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
            for (int i=0; i < contents.length; i++) {
                if (contents[i].contains("Manual_Payment_Upload_SEK")) {
                    camtFile=new File("Files/Manual_Payment/" + contents[i]);
                    LogCapture.info("old file name " + camtFile.getName());
                    break;
                }
            }
            Rename=new File("Files/Manual_Payment/Manual_Payment_Upload_CITI" + currentDate + ".xlsx" );
            camtFile.renameTo(Rename);
        }if (Value.equalsIgnoreCase("Upload Button") && Menu.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info("User Click on Upload.....");

            String vFileUpload=Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_Upload");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFileUpload, ""));
            Assert.assertEquals("PASS", Constants.key.click(vFileUpload, ""));

        }
        if (Value.equalsIgnoreCase("Rename File") && Menu.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info("File is renamed.....");
            String FolderPath1=System.getProperty("user.dir") + "/files/";
            File f1=new File(FilePath);
            f1.renameTo(new File(FolderPath1 + "ManualEnteriesUpload.xlsx"));
            System.out.println(f1.getName() + "File Renamed");
        }
        if (Value.equalsIgnoreCase("PotentialDuplicateQueueRecord") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("User Click on Potential Duplicate Queue record.....");

            String vBNK_PotentialDuplicateQueue_FirstRecord=Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue_FirstRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBNK_PotentialDuplicateQueue_FirstRecord, ""));

            Assert.assertEquals("PASS", Constants.key.click(vBNK_PotentialDuplicateQueue_FirstRecord, ""));

        }
        if (Value.equalsIgnoreCase("Select Institution") && Menu.equalsIgnoreCase("Pending Authorise")) {
            LogCapture.info("User Click on Select Institution ......");

            String vMessage_SelectInstitution1=Constants.QueryManagementOR.getProperty("BNK_QM_PendingAuthorise_AuthoriseQuery_SelectInstitution");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vMessage_SelectInstitution1, ""));
            Assert.assertEquals("PASS", Constants.key.click(vMessage_SelectInstitution1, ""));
        }
        if (Value.equalsIgnoreCase("Reference") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("User Click on Reference ......");

            String vQueries_RaiseQuery_Reference=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_Reference");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vQueries_RaiseQuery_Reference, ""));
            Assert.assertEquals("PASS", Constants.key.click(vQueries_RaiseQuery_Reference, ""));
        }
        if (Value.equalsIgnoreCase("OrganizationName") && Menu.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("User Click on OrgName ......");

            String vSelectORgName=Constants.B2BOR.getProperty("B2B_TrandingDashboardReport_OrgName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSelectORgName, ""));
            Assert.assertEquals("PASS", Constants.key.click(vSelectORgName, ""));
        }
    }

    @When("^Update the Excel file and Upload (ManualEntries|ManualPayment_JPMG|ManualPayment_CITI)$")
    public void updateTheExcelFileAndUploadAndReference(String Menu) throws Exception {
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
//        LocalDateTime now = LocalDateTime.now();
//        LocalDateTime currentDate = LocalDateTime.parse(dtf.format(now));
        RandomNumber = RandomStringUtils.randomNumeric(8);
        RandomNumber = RandomNumber.startsWith("0") ? RandomNumber.substring(1) : RandomNumber;
//     double newAmount=Double.parseDouble(RandomNumber);
//    String newAmount=RandomNumber;
//        LogCapture.info("New Trade Amount : " + newAmount);
        if (Menu.equalsIgnoreCase("ManualEntries")) {
            BankRef = "LACAXIALIVE" + RandomNumber;
            LogCapture.info("New Reference : " + BankRef);
            Reusables.writeDataFromExcel(1, 1, Rename, "Sheet1", BankRef);
//        Reusables.writeAmountFromExcel(1,4,Rename,"Sheet1",newAmount);
//        Reusables.writeDateFromExcel(1,5,Rename,"Sheet1",currentDate);
            String newFileName = System.getProperty("user.dir") + "/Files/Manual Entries/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        }if (Menu.equalsIgnoreCase("ManualPayment_JPMG")) {
            Transaction_Reference = "JPMG" + RandomNumber;
            LogCapture.info("New BankRef : " + Transaction_Reference);
            Reusables.writeDataFromExcel(1, 0, Rename, "Sheet2", Transaction_Reference);
            String newFileName = System.getProperty("user.dir") + "/Files/Manual_Payment/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        }if(Menu.equalsIgnoreCase("ManualPayment_CITI")) {
            Transaction_Reference = "CITI" + RandomNumber;
            LogCapture.info("New BankRef : " + Transaction_Reference);
            Reusables.writeDataFromExcel(1, 0, Rename, "Sheet2", Transaction_Reference);
            String newFileName = System.getProperty("user.dir") + "/Files/Manual_Payment/" + Rename.getName();
            String vBanking_ManualPaymentUploadFile = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadFile");
            Assert.assertEquals("PASS", key.UploadFile(vBanking_ManualPaymentUploadFile, newFileName));
        }
    }

    @Then("^User should successfully see (FCG Details|Potential Duplicate Queue Present Records|File Uploaded Successfully|State and Status|Amendment Type|Cancellation Type|Recall Type|BCNR Type|Additional Information Type|State and Status for closed Query|State and Status for Re-Opened Query|Miscellaneous Type|Message No|Details of selected Entry|Message Details|All the Deals|State and Status for Rejected Query|TorFx Details) on (Potential Duplicate Queue|Manual Balance Upload|Manual Entries Upload|Incoming Queries|Queries|Failed Payment Out|FX Confirmation|Payment Entries|TradingDashboardReport) page$")
    public void userShouldSuccessfullySeeFCGDetailsOnPotentialDuplicateQueuePage(String Data, String Menu) throws Throwable {
        key.pause("7", "");
        if (Data.equalsIgnoreCase("FCG Details") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("FCG data loading ......");
            String vObjBlotterTotal=Constants.BankingOR.getProperty("BNK_BankAccount_FCG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlotterTotal, "FCG"));

        }
        if (Data.equalsIgnoreCase("Potential Duplicate Queue Present Records") && Menu.equalsIgnoreCase("Potential Duplicate Queue")) {
            LogCapture.info("Potential Duplicate Queue Records data loading ......");

            String vPagerInformation=Constants.BankingOR.getProperty("BNK_PotentialDuplicateQueue_NoOfRecords");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vPagerInformation, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vPagerInformation, ""));

        }
        if (Data.equalsIgnoreCase("File Uploaded Successfully") && Menu.equalsIgnoreCase("Manual Balance Upload")) {
            LogCapture.info(" File Successfully Uploaded ......");
            String vFileUploadSuccessMsg=Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_SuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFileUploadSuccessMsg, "\"File uploaded successfully\""));
            //Assert.assertEquals("PASS", Constants.key.exist(vFileUploadSuccessMsg, ""));

        }
        if (Data.equalsIgnoreCase("File Uploaded Successfully") && Menu.equalsIgnoreCase("Manual Entries Upload")) {
            LogCapture.info(" File Successfully Uploaded ......");
            String vFileUploadSuccessMsg=Constants.BankingOR.getProperty("BNK_PaymentMonitoring_PymtEntries_SuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFileUploadSuccessMsg, "\"File uploaded successfully\""));
            //Assert.assertEquals("PASS", Constants.key.exist(vFileUploadSuccessMsg, ""));


            //Constants.filerename.renameToOriginal(Constants.latestFile);


        }
        if (Data.equalsIgnoreCase("State and Status") && Menu.equalsIgnoreCase("Incoming Queries")) {
            LogCapture.info("Incoming Queries data loading ......");

            String vQMIncomingQueriesStatus=Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_Status");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMIncomingQueriesStatus, "Initiated"));


            String vQMIncomingQueriesState=Constants.QueryManagementOR.getProperty("BNK_QM_IncomingQueries_State");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMIncomingQueriesState, "Import"));

        }
        if (Data.equalsIgnoreCase("State and Status") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("State Status data loading ......");

            String vQMStatusValue=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStatusValue, "Open"));

            String vQMStateValue=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStateValue, "Raised"));

        }
        if (Data.equalsIgnoreCase("State and Status") && Menu.equalsIgnoreCase("Payment Entries")) {
            LogCapture.info("State Status data loading ......");

            String vPaymentEntriesStatusValue=Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_StatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentEntriesStatusValue, "Processing"));

            String vPaymentEntriesStateValue=Constants.PaymentMonitoringOR.getProperty("BNK_PaymentEntries_StateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentEntriesStateValue, "Confirmed"));

        }
        if (Data.equalsIgnoreCase("Amendment Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Amendment Type data loading ......");

            String vQMTypeValueAmendment=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueAmendment, "Amendment"));

        }
        if (Data.equalsIgnoreCase("Cancellation Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Cancellation Type data loading ......");

            String vQMTypeValueCancellation=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueCancellation, "Cancellation"));

        }
        if (Data.equalsIgnoreCase("Recall Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Recall Type data loading ......");

            String vQMTypeValueRecall=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "Recall"));
        }
        if (Data.equalsIgnoreCase("Additional Information Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Additional Information Type data loading ......");

            String vQMTypeValueRecall=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "Additional Information"));

        }
        if (Data.equalsIgnoreCase("State and Status for closed Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("State Status data loading ......");

            String vQMStatusValue=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStatusValue, "Complete"));

            String vQMStateValue=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStateValue, "Closed"));
        }
        if (Data.equalsIgnoreCase("State and Status for Rejected Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("State Status data loading ......");

            String vQMStatusValue=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStatusValue, "Complete"));

            String vQMStateValue=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStateValue, "Closed"));
        }
        if (Data.equalsIgnoreCase("State and Status for Re-Opened Query") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("State Status data loading ......");

            String vQMStatusValue=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStatusValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStatusValue, "Open"));

            String vQMStateValue=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstStateValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMStateValue, "Re-open"));

        }
        if (Data.equalsIgnoreCase("BCNR Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" BCNR Type data loading ......");

            String vQMTypeValueRecall=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "BCNR"));

        }
        if (Data.equalsIgnoreCase("Miscellaneous Type") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info(" Miscellaneous Type data loading ......");

            String vQMTypeValueRecall=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_FirstTypeValue");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "Miscellaneous"));

        }
        if (Data.equalsIgnoreCase("Message No") && Menu.equalsIgnoreCase("Queries")) {
            LogCapture.info("Message No data loading ......");

            String vQMTypeValueRecall=Constants.QueryManagementOR.getProperty("BNK_QM_Queries_RaiseQuery_MessageNo");
            Assert.assertEquals("PASS", Constants.key.verifyText(vQMTypeValueRecall, "MT199"));
        }
        if (Data.equalsIgnoreCase("Details of selected Entry") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("Details of selected Entry data loading ......");

            String vMessage_FPO_DetailsOfSelectedRecord=Constants.MessageOR.getProperty("BNK_Message_FPO_DetailsOfSelectedRecord");
            Assert.assertEquals("PASS", Constants.key.verifyText(vMessage_FPO_DetailsOfSelectedRecord, "Details of selected Entry"));

        }
        if (Data.equalsIgnoreCase("Message Details") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("Message data loading ......");

            String vMessage_FPO_MessageDetails=Constants.MessageOR.getProperty("BNK_Message_FPO_MessageDetails");
            Assert.assertEquals("PASS", Constants.key.exist(vMessage_FPO_MessageDetails, ""));
        }
        if (Data.equalsIgnoreCase("All the Deals") && Menu.equalsIgnoreCase("FX Confirmation")) {
            LogCapture.info("All the Deals Tital Against MT300 data loading ......");

            String vFXC_AllTheDealsTitanAgainstMt300=Constants.FXConfirmationOR.getProperty("BNK_FXC_AllTheDealsTitalAgainstMT300");
            Assert.assertEquals("PASS", Constants.key.exist(vFXC_AllTheDealsTitanAgainstMt300, ""));
        }
        if (Data.equalsIgnoreCase("TorFx") && Menu.equalsIgnoreCase("TradingDashboardReport")) {
            LogCapture.info("TorFX data loading ......");
            String vObjBlotterTotal=Constants.BankingOR.getProperty("B2B_TrandingDashboardReport_TorFX");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjBlotterTotal, "TorFX"));

        }

    }

    @Then("^User Search the bank Reference to get the MSL_ID from \"([^\"]*)\" DB$")
    public void userSearchTheBankReferenceToGetTheMSL_IDFromDB(String Environment) throws Throwable {
        key.pause("20", "");
        String MSL=Constants.key.VerifyDBDetails(Environment, BankRef, "Find the MSL_ID for Manual Entry");
        Constants.EODMSL_ID=MSL;
        Constants.KafkaMessageCDID =MSL;
        LogCapture.info("MSL_ID : " + EODMSL_ID);
    }

    @And("^User fetches the Latest TitanTransactionReference using ClientAccountKey \"([^\"]*)\"\"([^\"]*)\" and (Current Date|MoreThan 10 Date)$")
    public void userFetchesTheLatestTitanTransactionReferenceUsingClientAccountKey(String ClientAccountKey, String Environment, String Data) throws Throwable {
        if(Data.equalsIgnoreCase("Current Date")){
            String TransactionReference=Constants.key.VerifyDBDetails(Environment, ClientAccountKey, "Fetch Latest Payment Titan Transaction Reference Number");
            LogCapture.info("Latest Trade Account Number : " + TransactionReference);
            String vFirst=TransactionReference.split("-")[0].trim();
            int vLast=Integer.parseInt(TransactionReference.split("-")[1].trim()) + 1;
            String vLastest=Integer.toString(vLast);
            String newTransactionReference=vFirst + "-" + vLastest;
            Constants.TransactionReferenceNumber=newTransactionReference;
            DynamicValue.put("<TransactionReferenceNumber>",TransactionReferenceNumber);
            LogCapture.info("New Transaction Reference Number : " + newTransactionReference);

            DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime now=LocalDateTime.now();
            String currentDate=dtf.format(now);
            DynamicValue.put("<currentDate>",currentDate);
            DynamicValue.put("<ClientAccountKey>",ClientAccountKey);
        }else if (Data.equalsIgnoreCase("MoreThan 10 Date")) {
            String TransactionReference=Constants.key.VerifyDBDetails(Environment, ClientAccountKey, "Fetch Latest Payment Titan Transaction Reference Number");
            LogCapture.info("Latest Trade Account Number : " + TransactionReference);
            String vFirst=TransactionReference.split("-")[0].trim();
            int vLast=Integer.parseInt(TransactionReference.split("-")[1].trim()) + 1;
            String vLastest=Integer.toString(vLast);
            String newTransactionReference=vFirst + "-" + vLastest;
            Constants.TransactionReferenceNumber=newTransactionReference;
            DynamicValue.put("<TransactionReferenceNumber>",TransactionReferenceNumber);
            LogCapture.info("New Transaction Reference Number : " + newTransactionReference);
            DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime now=LocalDateTime.now();
            LocalDateTime morethan10Days = now.plusDays(11);
            String currentDate=dtf.format(morethan10Days);
            DynamicValue.put("<currentDate>",currentDate);
            DynamicValue.put("<ClientAccountKey>",ClientAccountKey);
        }
    }

    @When("^User Select (normal|Large|OneApproval|ThreeApproval) payment out Amount$")
    public void userSelectNormalPaymentOutAmount(String data) {
        if(data.equalsIgnoreCase("normal")){
            RandomNumber=RandomStringUtils.randomNumeric(2);
        } else if (data.equalsIgnoreCase("Large")) {
            RandomNumber=RandomStringUtils.randomNumeric(5);
        }else if (data.equalsIgnoreCase("OneApproval")) {
            RandomNumber=RandomStringUtils.randomNumeric(6);
        }else if (data.equalsIgnoreCase("ThreeApproval")) {
            RandomNumber=RandomStringUtils.randomNumeric(7);
        }
        RandomNumber=RandomNumber.startsWith("0")? RandomNumber.substring(1):RandomNumber;
// double newAmount=Double.parseDouble(RandomNumber);
        String newAmount=RandomNumber+".00";
        LogCapture.info("New Trade Amount : " + newAmount);
        Constants.Amount=newAmount;
        DynamicValue.put("<Amount>",Amount);
    }

    @And("^Check (BARC|RBS|Yes|JPMG|CITI|AIP) for Extra Values \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void checkForExtraValues(String Data,String Organization, String customer_country_code, String sub_category, String charge_type, String Priority, String BIC_CODE) throws Throwable {
        DynamicValue.put("<BIC_CODE>", BIC_CODE);
        Map<String, String> result = Reusables.getSqlQueryResult("TIPaymentDetail_GlobalRef");
        int value = Integer.parseInt(result.get("global_reference_id"));
        value += 1;
        globalreferenceid = String.valueOf(value);
        DynamicValue.put("<globalreferenceid>", globalreferenceid);
        if (Data.equalsIgnoreCase("BARC")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<customer_country_code>", customer_country_code);
            DynamicValue.put("<sub_category>", sub_category);
            DynamicValue.put("<charge_type>", charge_type);
            DynamicValue.put("<Priority>", Priority);
        }
        if (Data.equalsIgnoreCase("RBS")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("Yes")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("CITI")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("AIP")) {
            DynamicValue.put("<Organization>", Organization);
        }
        if (Data.equalsIgnoreCase("JPMG")) {
            DynamicValue.put("<Organization>", Organization);
            DynamicValue.put("<Priority>", Priority);
        }
    }

    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Banking \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForBanking(String methodType, String statCode, String testCaseID, String Environment, String customerType, String Currency, String legal_entity, String BeneAccount_no, String country_code, String BenefType, String PreferredPaymentType) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = Environment;
        DynamicValue.put("<customerType>",customerType);
        DynamicValue.put("<Currency>",Currency);
        DynamicValue.put("<legal_entity>",legal_entity);
        DynamicValue.put("<BeneAccount_no>",BeneAccount_no);
        DynamicValue.put("<country_code>",country_code);
        DynamicValue.put("<BenefType>",BenefType);
        DynamicValue.put("<PreferredPaymentType>",PreferredPaymentType);

//      DynamicValue.put("<methodType>",methodType);
        LogCapture.info("----------------Started API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info(jp+"---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + Environment + " Environment for testcase ID " + testCaseID + "---------------------");
        Assert.assertFalse(RESPONSE.contains("null"));
        String external_reference_id=RESPONSE.split(":")[3].split("}")[0];
        LogCapture.info("ID =" + external_reference_id);
        Constants.ID=external_reference_id;
        Constants.KafkaMessageCDID =external_reference_id;
    }

    @Then("^User validate response code \"([^\"]*)\"$")
    public void userValidateResponseCode(String arg0) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        System.out.println(jp);
        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @Then("^Verify kafka message for (PaymentIn|TIPaymentInstruction|TIPayInstructionDetails|PaymentID|MessageOut|AuditTrail) \"([^\"]*)\"$")
    public void verify_kafka_message_for_offline_presentment(String data,String Environment) throws Exception {
        JsonPath actualKafkaMsgJsonObj = Reusables.waitForKafkaMessage(KafkaMessageCDID);
        ExpectedKafkaKeyValues = Reusables.getSqlQueryResult("PaymentIn.Kafka", KafkaMessageCDID);
        System.out.println(ExpectedKafkaKeyValues);
        ReusableMethod.verifyKafkaMessage(ExpectedKafkaKeyValues,actualKafkaMsgJsonObj);
        Constants.driver.navigate().refresh();
    }

    @And("^User validate (Transaction Reference|TIPaymentDetails|PaymentID|MessageOut|AuditTrail|ROF Transaction Reference|PaymentID_For_MT|Transaction Reference PaymentID) in DB for \"([^\"]*)\"$")
    public void userValidateTransactionReferenceInDBFor(String Menu, String Environment) throws Throwable {
        if (Menu.equalsIgnoreCase("Transaction Reference")){
            String Transaction_Reference=Constants.key.VerifyDBDetails(Environment, ID, "Transaction Reference for Paymentout");
            LogCapture.info("Transaction Reference is " + Transaction_Reference);
            Constants.Transaction_Reference=Transaction_Reference;
        }if (Menu.equalsIgnoreCase("Transaction Reference PaymentID")){
            String Transaction_Reference=Constants.key.VerifyDBDetails(Environment, ID, "Transaction Reference");
            LogCapture.info("Transaction Reference is " + Transaction_Reference);
            Constants.Transaction_Reference=Transaction_Reference;
        }if (Menu.equalsIgnoreCase("ROF Transaction Reference")){
            String PayRef="ROF "+ KafkaMessageCDID;
            Constants.Transaction_Reference=PayRef;
            String ROF_Transaction_Reference=Constants.key.VerifyDBDetails(Environment, PayRef, "ROF Transaction Reference for Paymentout");
        }
        if (Menu.equalsIgnoreCase("TIPaymentDetails")){
            String TI_PaymentInstructionsDetails_ID=Constants.key.VerifyDBDetails(Environment, ID, "TIPaymentDetails");
            LogCapture.info("TIPaymentDetails is " + TI_PaymentInstructionsDetails_ID);
            Constants.KafkaMessageCDID =TI_PaymentInstructionsDetails_ID;
        }if (Menu.equalsIgnoreCase("PaymentID")){
            String Payment_ID=Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "PaymentID");
            LogCapture.info("PaymentID is " + Payment_ID);
            Constants.KafkaMessageCDID =Payment_ID;
        }if (Menu.equalsIgnoreCase("PaymentID_For_MT")){
            key.pause("60","");
            String Payment_ID=Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "PaymentID_For_MT");
            LogCapture.info("PaymentID is " + Payment_ID);
            Constants.KafkaMessageCDID =Payment_ID;
        }if (Menu.equalsIgnoreCase("MessageOut")){
            String MessageOut=Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "MessageOut");
            LogCapture.info("MessageOut is " + MessageOut);
            Constants.KafkaMessageCDID =MessageOut;
        }
    }

    @Then("^User verify the status of the payment$")
    public void userVerifyTheStatusOfThePayment() throws Throwable{
        Map<String, String> result1 = Reusables.getSqlQueryResult("PaymentID",Transaction_Reference);
        String PaymentStatus = result1.get("Status");
        LogCapture.info("Payment out Status is: " + PaymentStatus);
        Assert.assertFalse(false, valueOf(Transaction_Reference.contains("null")));
        if(PaymentStatus.equalsIgnoreCase("Processing")){
            String vObjPendingMX = Constants.KafkaUI.getProperty("PendingMXstatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPendingMX, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjPendingMX,""));
            String vObjApproved = Constants.KafkaUI.getProperty("Approvedstatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjApproved, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjApproved,""));
            String vObjReady = Constants.KafkaUI.getProperty("Readystatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjReady, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjReady,""));
        }if(PaymentStatus.equalsIgnoreCase("Approved")){
            String vObjPendingMX = Constants.KafkaUI.getProperty("PendingMXstatus");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPendingMX, ""));
            Assert.assertEquals("PASS", Constants.key.exist(vObjPendingMX,""));
        }
    }

    @And("^User validate AuditTrailID in DB for (Record1|Record2|Record3|Record4|Record5|Record6|Record7|Record8)$")
    public void userValidateAuditTrailIDInDBForRecord(String REC) throws Exception{
        List<Map<String, String>> result = Reusables.getSqlQueryResultForMultiRows("PayRefAuditTrail",Transaction_Reference);
        for (int i = 0; i < result.size(); i++) {
            Map<String, String> record = new HashMap<>();
            record.put("ID", result.get(i).get("ID"));
            AuditTable.add(record);
        }
        if (REC.equalsIgnoreCase("Record1")){
            Map<String, String> selectedRecord = AuditTable.get(0);
            idValue = selectedRecord.get("ID");
        }if (REC.equalsIgnoreCase("Record2")){
            Map<String, String> selectedRecord = AuditTable.get(1);
            idValue = selectedRecord.get("ID");
        }if (REC.equalsIgnoreCase("Record3")){
            Map<String, String> selectedRecord = AuditTable.get(2);
            idValue = selectedRecord.get("ID");
        }if (REC.equalsIgnoreCase("Record4")){
            Map<String, String> selectedRecord = AuditTable.get(3);
            idValue = selectedRecord.get("ID");
        }if (REC.equalsIgnoreCase("Record5")){
            Map<String, String> selectedRecord = AuditTable.get(4);
            idValue = selectedRecord.get("ID");
        }if (REC.equalsIgnoreCase("Record6")){
            Map<String, String> selectedRecord = AuditTable.get(5);
            idValue = selectedRecord.get("ID");
        }if (REC.equalsIgnoreCase("Record7")){
            Map<String, String> selectedRecord = AuditTable.get(6);
            idValue = selectedRecord.get("ID");
        }if (REC.equalsIgnoreCase("Record8")){
            Map<String, String> selectedRecord = AuditTable.get(7);
            idValue = selectedRecord.get("ID");
        }
        LogCapture.info("AuditTrailID is " + idValue);
        Constants.KafkaMessageCDID =idValue;
    }

    @And("^User should successfully see (UI Parameters|Payment Details) on (Message Out|Failed Payment Out|Manual Payment Upload|Manual PSR Upload) page$")
    public void userShouldSuccessfullySeeUIParametersOnMessageOutPage(String Data, String Menu) throws Throwable {
        key.pause("6", "");
        if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Message Out")) {
            LogCapture.info("User verify data on Message Out page....");

            String vBanking_MessageOut_ID=Constants.MessageOR.getProperty("Banking_MessageOut_ID");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_ID, ""));
            String vBanking_MessageOut_Institution = Constants.MessageOR.getProperty("Banking_MessageOut_Institution");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_Institution, ""));
            String vBanking_MessageOut_QueryName = Constants.MessageOR.getProperty("Banking_MessageOut_QueryName");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_QueryName, ""));
            String vBanking_MessageOut_MessageType=Constants.MessageOR.getProperty("Banking_MessageOut_MessageType");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_MessageType, ""));
            String vBanking_MessageOut_MessageNo=Constants.MessageOR.getProperty("Banking_MessageOut_MessageNo");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_MessageNo, ""));
        } else if (Data.equalsIgnoreCase("Payment Details") && Menu.equalsIgnoreCase("Message Out")) {
            LogCapture.info("User verify Payment Details on Message Out page....");

            String vBanking_MessageOut_DetailsofEntry=Constants.MessageOR.getProperty("Banking_MessageOut_DetailsofEntry");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_DetailsofEntry, ""));
            String vBanking_MessageOut_MessageDescription=Constants.MessageOR.getProperty("Banking_MessageOut_MessageDescription");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_MessageOut_MessageDescription, ""));
        } else if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Failed Payment Out")) {
            LogCapture.info("User verify Payment Details on Failed Payment Out page....");

            String vBanking_FailedPaymentOut_StatusData = Constants.MessageOR.getProperty("Banking_FailedPaymentOut_StatusData");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_FailedPaymentOut_StatusData, "Rejected"));
            String vBanking_FailedPaymentOut_SourceData = Constants.MessageOR.getProperty("Banking_FailedPaymentOut_SourceData");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_FailedPaymentOut_SourceData, "Titan"));
        } else if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User verify Payment Details on Manual Payment Upload page....");

            String vBanking_ManualPaymentUploadText=Constants.MessageOR.getProperty("Banking_ManualPaymentUploadText");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ManualPaymentUploadText, "Manual Payment Upload"));
            String vBanking_ProcessedManualPaymentText = Constants.MessageOR.getProperty("Banking_ProcessedManualPaymentText");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ProcessedManualPaymentText, "Processed Manual Payments"));
        } else if (Data.equalsIgnoreCase("UI Parameters") && Menu.equalsIgnoreCase("Manual PSR Upload")) {
            LogCapture.info("User verify Payment Details on Manual PSR Upload page....");

            String vBanking_ManualPSRUploadText = Constants.MessageOR.getProperty("Banking_ManualPSRUploadText");
            Assert.assertEquals("PASS", Constants.key.exist(vBanking_ManualPSRUploadText, ""));
        }
    }

    @And("^User select (Message Type|Organization) \"([^\"]*)\" from Manual Payment Upload page$")
    public void userSelectMessageTypeFromManualPaymentUploadPage(String Data, String Value) throws Throwable {
        key.pause("4", "");
        if (Data.equalsIgnoreCase("Message Type")) {
            LogCapture.info("User select Message Type from Manual Payment Upload page ......");

            String vBanking_ManualPaymentMessageType = Constants.MessageOR.getProperty("Banking_ManualPaymentMessageType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPaymentMessageType, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBanking_ManualPaymentMessageType, Value));
        } else if (Data.equalsIgnoreCase("Organization")) {
            LogCapture.info("User select Organization from Manual Payment Upload page ......");

            String vBanking_ManualPaymentSelectOrganization = Constants.MessageOR.getProperty("Banking_ManualPaymentSelectOrganization");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPaymentSelectOrganization, ""));
            Assert.assertEquals("PASS", Constants.key.SelectDropDownValue(vBanking_ManualPaymentSelectOrganization, Value));
        }
    }

    @And("^User click on (Upload File|Process Manual Payment|Process Manual Payment Record) from (Manual Payment Upload|Manual PSR Upload) page$")
    public void userClickOnUploadFileFromManualPaymentUploadPage(String Data, String Menu) throws Throwable {
        key.pause("4", "");
        if (Data.equalsIgnoreCase("Upload file") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User Click on Upload file ......");

            String vBanking_ManualPaymentUploadButton = Constants.MessageOR.getProperty("Banking_ManualPaymentUploadButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPaymentUploadButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPaymentUploadButton, ""));
        } else if (Data.equalsIgnoreCase("Process Manual Payment") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User Click on Process Manual Payment ......");

            String vBanking_ProcessedManualPaymentText = Constants.MessageOR.getProperty("Banking_ProcessedManualPaymentText");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ProcessedManualPaymentText, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ProcessedManualPaymentText, ""));
        } else if (Data.equalsIgnoreCase("Process Manual Payment Record") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User Click on Process Manual Payment Record ......");

            String vBanking_ProcessedManualPaymentRecord = Constants.MessageOR.getProperty("Banking_ProcessedManualPaymentRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ProcessedManualPaymentRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ProcessedManualPaymentRecord, ""));
        } else if (Data.equalsIgnoreCase("Upload file") && Menu.equalsIgnoreCase("Manual PSR Upload")) {
            LogCapture.info("User Click on Upload file ......");

            String vBanking_ManualPSRUploadButton = Constants.MessageOR.getProperty("Banking_ManualPSRUploadButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBanking_ManualPSRUploadButton, ""));
            Assert.assertEquals("PASS", Constants.key.click(vBanking_ManualPSRUploadButton, ""));
        }
    }

    @And("^User verify (file Successfully uploaded) on (Manual PSR Upload|Manual Payment Upload) page$")
    public void userVerifyFileSuccessfullyUploadedOnManualPSRUploadPage(String Data, String Menu) throws Throwable {
        key.pause("8", "");
        if (Data.equalsIgnoreCase("file Successfully uploaded") && Menu.equalsIgnoreCase("Manual Payment Upload")) {
            LogCapture.info("User verify file upload ......");

            String vBanking_ManualPaymentSuccessfulUpload = Constants.MessageOR.getProperty("Banking_ManualPaymentSuccessfulUpload");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ManualPaymentSuccessfulUpload, "File uploaded successfully"));
        } else if (Data.equalsIgnoreCase("file Successfully uploaded") && Menu.equalsIgnoreCase("Manual PSR Upload")) {
            LogCapture.info("User verify file upload ......");

            String vBanking_ManualPaymentSuccessfulUpload = Constants.MessageOR.getProperty("Banking_ManualPaymentSuccessfulUpload");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBanking_ManualPaymentSuccessfulUpload, "File uploaded successfully"));
        }
    }

    @And("^User get Transaction Reference From Message Out table DB for \"([^\"]*)\"$")
    public void userGetTransactionReferenceFromMessageOutTableDBFor(String Environment) throws Throwable {
        String Transaction_Reference_MessageOut=Constants.key.VerifyDBDetails(Environment, Transaction_Reference, "Transaction Reference From Message Out table");
        LogCapture.info("MessageOut Transaction Reference is " + Transaction_Reference_MessageOut);
        Constants.Transaction_Reference_MessageOut=Transaction_Reference_MessageOut;
    }

    @Given("^Change the \"([^\"]*)\" file name and update for \"([^\"]*)\"$")
    public void changeTheFileNameAndUpdateFor(String FileType, String Bank) throws Exception {
        Constants.Bank=Bank;
        Constants.FileType=FileType;
        DateTimeFormatter date=DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now=LocalDateTime.now();
        String currentDate=dtf.format(now);
        LocalDateTime today=LocalDateTime.now();
        String nameDate=date.format(today);

        String RandomNumber=RandomStringUtils.randomNumeric(5);
        String number=RandomNumber;

        File camtFile=null;
        File Rename =null;
        File directoryPath=new File("Files/"+Bank+"/");

        String[] contents =directoryPath.list(); //List of all files and directories
        // key.pause("2","");
        LogCapture.info("List of files and directories in the specified directory:"+directoryPath);
        for(int i=0; i<contents.length;i++) {
            if(contents[i].contains(FileType)){
                camtFile=new File("Files/"+Bank+"/"+contents[i]);
                LogCapture.info("old file name "+camtFile.getName());
                break;
            }
        }
        if(FileType.contains("pain.002")){
            Rename = new File("Files/" + Bank + "/" + FileType + ".001.03.D" + nameDate + "_R667" + number + ".F020002.SNL35343D23678530057799989S");
        }
        camtFile.renameTo(Rename);

        String newFileName = Rename.getName();
        Constants.NewFileName=newFileName;
        LogCapture.info(Rename.getName());

        File NewCamtFile=new File("Files/"+Bank+"/" + NewFileName);

        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();  // Using XML classes to modify file content
        DocumentBuilder builder=factory.newDocumentBuilder();
        Document doc=builder.parse(NewCamtFile);
        Constants.doc1=doc;
        LogCapture.info(" Selected Document/File for updates is "+NewFileName);
        //PSR file updates

        Reusables.updateXmlFile("CreDtTm", String.valueOf(now));
        Reusables.updateXmlFile("MsgId",Transaction_Reference_MessageOut);
        Reusables.updateXmlFile("OrgnlMsgId",Transaction_Reference_MessageOut);
        Reusables.updateXmlFile("OrgnlPmtInfId",Transaction_Reference);
        Reusables.updateXmlFile("OrgnlEndToEndId",Transaction_Reference);
        Reusables.updateXmlFile("OrgnlCtrlSum",Amount);
        Reusables.updateXmlFile("InstdAmt",Amount);
        Reusables.updateXmlFile("ReqdExctnDt", currentDate);

        TransformerFactory transformerFactory=TransformerFactory.newInstance(); //Updated information send to local NewCamtFile
        Transformer transformer=transformerFactory.newTransformer();
        DOMSource source=new DOMSource(doc1);
        StreamResult result=new StreamResult(NewCamtFile);
        transformer.transform(source, result);
        LogCapture.info(" Updates are saved in document/file: "+NewFileName);

    }

    @And("^User check PSR file is parsed and deal went to PaymentStatusReport \"([^\"]*)\"$")
    public void userCheckPSRFileIsParsedAndDealWentToPaymentStatusReport(String Environment) throws Throwable {
        String MessageInId=MessageInIdMap.get("MessageInId for 2");
        String PaymentStatus=Constants.key.VerifyDBDetails(Environment, MessageInId, "PSR Payment Status");
        LogCapture.info("After Uploading PSR Payment Status is" + PaymentStatus);
        Constants.PaymentStatusIs=PaymentStatus;
        Assert.assertTrue(PaymentStatus.equalsIgnoreCase("Approved"));

    }
}
