package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;
import com.utility.LogCapture;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.Constants.TradePaymentID;


public class AtlasStepDefination {
    public static String Comments;
    @Given("^User Generate Token for API Validation from \"([^\"]*)\" for Atlas Application$")
    public void userGenerateTokenForAPIValidationFromForAtlasApplication(String tcID) throws Throwable {
        LogCapture.info("--------------Token Generation started for testcase ID " + tcID + "---------------");
        //
        Constants.RESPONSE = ServiceMethod.postAdvance(tcID, "200", Constants.DynamicValue);
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        Constants.ACCESS_TOKEN = jp.get("access_token");
        LogCapture.info("--------------Token Generation ended--------------");
        LogCapture.info("--------------Token Generation ended for testcase ID " + tcID + "--------------");

    }

    @Given("^User connects to UAT DB and fetches the Latest (CDLGB TradeAccountNumber|CDLEU TradeAccountNumber)$")
    public void userConnectsToUATDBAndFetchesTheLatestCDLGBTradeAccountNumber(String LegalEntity) throws Exception {
        LogCapture.info("--------------User fetch TAN from DB-------------------");
        if (LegalEntity.equalsIgnoreCase("CDLGB TradeAccountNumber")) {
            LogCapture.info("--------------User fetch TAN from DB for CDLGB-------------------");
            TradeAccountNumber = Constants.key.VerifyDBDetails("UAT", "", "Fetch TAN CDLGB");
            DynamicValue.put("<TAN>", TradeAccountNumber);
            System.out.println("Latest Trade Account Number : " + TradeAccountNumber);
        }
        TradeContactID = Constants.key.VerifyDBDetails("UAT", TradeAccountNumber, "Fetch TradeContactID");
        System.out.println("Latest TradeContactID : " + TradeContactID);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String currentDate = dtf.format(now);
        DynamicValue.put("<PaymentDateTime>", currentDate);
        DynamicValue.put("<trade_contact_id>", TradeContactID);
        LogCapture.info("--------------User fetched TAN from DB-------------------");
    }

    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Atlas$")
    public void forACallUserCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {
        //Constants.APIkey.checkNotEnabled(testCaseID);
        Constants.TCCaseID = testCaseID;
        Constants.JenkinsEnvironment = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);

            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        } else if (methodType.equalsIgnoreCase("Put")) {
            LogCapture.info("---------------Put call started----------------");
            Constants.RESPONSE = ServiceMethod.putAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info("---------------Put call started----------------");
        }  else if (methodType.equalsIgnoreCase("Put")) {
            LogCapture.info("---------------Put call started----------------");
            Constants.RESPONSE = ServiceMethod.putAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            LogCapture.info("---------------Put call started----------------");
        }

        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

//    @Then("^User validate response code \"([^\"]*)\"$")
//        public void userValidateResponseCode() throws Throwable {
//            LogCapture.info("----------------Response Validations Started-------------------");
//            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
//            System.out.println(jp);
//            LogCapture.info("----------------Response Validations Ended-------------------");
//
//        }

//    @Then("^Verify kafka message using \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void verifyKafkaMessageUsingAnd(String expectedMsgFieldsSqlQueryProperty, String OperationType) throws Throwable {
//        JsonPath actualKafkaMsgJsonObj = waitForFundaInKafkaMessage(Constants.DynamicValue.get("<dynamic>"),OperationType);
//        LogCapture.info("--------------User fetch Fund IN details from DB for kafka -------------------");
//        String Enviroment = Constants.CONFIG.getProperty("Environment");
//        kafkaExpectedKeyValues = ReusableMethod.verifyDBDetailsEnhanced(Enviroment, Constants.DynamicValue.get("<dynamic>"),expectedMsgFieldsSqlQueryProperty);
////        kafkaExpectedKeyValues = ReusableMethod.getSqlQueryResult(expectedMsgFieldsSqlQueryProperty, Constants.DynamicValue.get("<dynamic>"),);
//        ReusableMethod.verifyKafkaMessage(kafkaExpectedKeyValues, actualKafkaMsgJsonObj);
//    }

    private JsonPath waitForFundaInKafkaMessage(String uniqueIdentifier, String OperationType) throws Exception {
        LogCapture.info("Waiting for Kafka message to populate on UI.....");
        LocalDateTime localDateTime = LocalDateTime.now();
        String kafkaJsonMessage;

        boolean isMessageLineDisplayed = false;

        String messageFieldXpath=Constants.KafkaPropertiesOR.getProperty("MessageFieldFundsIn");

        messageFieldXpath = messageFieldXpath.replace("{Operation}",OperationType).replace("{uniqueMessageId}", DynamicValue.get("<dynamic>"));
        System.out.println(uniqueIdentifier);

        while(!isMessageLineDisplayed && ReusableMethod.getTimeLapsedInSeconds(localDateTime) < 200) {
            isMessageLineDisplayed = Constants.key.isElementDisplayed(messageFieldXpath, 10);
        }

        kafkaJsonMessage = Constants.key.getText(messageFieldXpath,"");
        Assert.assertTrue(isMessageLineDisplayed, "Message is not found within 3 minutes");
        JsonPath jsonPath = JsonPath.from(kafkaJsonMessage);
        return jsonPath;
    }
    @Then("^User gets the funds In transaction ID$")
    public void userGetsTheFundsInTransactionID() {
        Constants.FundsInTransactionID = Constants.CONFIG.getProperty("FundsInID");
        Constants.FundsInTransactionID=  Constants.FundsInTransactionID.replace("{TAN}", TradeAccountNumber).replace("{DynamicValue}", Constants.DynamicValue.get("<dynamic>"));
        System.out.println(Constants.FundsInTransactionID);
    }
    @When("^User click on filter criteria$")
    public void userClickOnFilterCriteria() throws Exception {
        LogCapture.info("----------------User click on Filter-------------------");
        String vFilterButton = Constants.AtlasPaymentInOR.getProperty("Atlas_selectFirstRecordAtlas_filter");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vFilterButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vFilterButton, ""));
    }
    @And("^User enter valid ClientId in keyword section$")
    public void userEnterValidClientIdInKeywordSection() throws Exception {
        String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
//      String FundsInTransID = Constants.FundsInTransactionID;
        Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, Constants.FundsInTransactionID));

    }
    @And("^user hits Enter on Keyboard$")
    public void userHitsEnterOnKeyboard() throws Exception {
        System.out.println("user hits Enter on Keyboard");
        String vObjKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjKeyword, "enter"));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
    }
    @Then("^(Payment In|Registration|Payment Out|Registration CFX|Payment In CFX|Payment Out CFX|Payment In PFX|Payment Out PFX|Payment Out CFX-Etailer|Payment In CFX-Etailer|) Status to be Observed as (CLEAR|ACTIVE|INACTIVE|REJECT|SEIZE|HOLD) with success message$")
    public void paymentInStatusToBeObservedAsCLEARWthSuccessMessage(String Value, String Action) throws Exception {
        if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("ACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "ACTIVE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("INACTIVE")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "INACTIVE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration") && Action.equalsIgnoreCase("REJECT")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "REJECTED"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In") && Action.equalsIgnoreCase("HOLD")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            // String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            // Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "HOLD"));
            // Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration CFX") && Action.equalsIgnoreCase("ACTIVE")) {
            String vSuccessMessage = Constants.AtlasRegistrationOR.getProperty("SuccessMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[contains(text(),'Sanction Repeat Check Successfully done for contact') or contains(text(),'Updated successfully')]")));
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");


            String actual = Constants.driver.findElement(By.xpath(vSuccessMessage)).getText();

            if (actual.contains("Updated successfully") || actual.contains("Sanction Repeat Check Successfully done for contact")) {
                LogCapture.info("Sanction Repeat Check Successfully done for contact::" + actual);
            } else {
                LogCapture.info("Not updated Successfully" + actual);
                Assert.fail();
            }

            //Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));

            String vObjStatus1 = Constants.AtlasRegistrationOR.getProperty("Status1");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus1, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus1, "ACTIVE"));

        } else if (Value.equalsIgnoreCase("Registration CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vObjStatus = Constants.AtlasRegistrationOR.getProperty("Status1");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus, "REJECTED"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Registration CFX") && Action.equalsIgnoreCase("INACTIVE")) {
            String vSuccessMessage = Constants.AtlasRegistrationOR.getProperty("SuccessMsg");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            JavascriptExecutor je = ((JavascriptExecutor) Constants.driver);
            je.executeScript("arguments[0].scrollIntoView(true);", Constants.driver.findElement(By.xpath("//*[contains(text(),'Sanction Repeat Check Successfully done for contact') or contains(text(),'Updated successfully')]")));
            //((JavascriptExecutor) Constants.driver).executeScript("javascript:window.scrollBy(1000,0)");

            String actual = Constants.driver.findElement(By.xpath(vSuccessMessage)).getText();

            if (actual.contains("Updated successfully") || actual.contains("Sanction Repeat Check Successfully done for contact")) {
                LogCapture.info("Sanction Repeat Check Successfully done for contact::" + actual);
            } else {
                LogCapture.info("Not updated Successfully" + actual);
                Assert.fail();
            }

            //Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));

            String vObjStatus1 = Constants.AtlasRegistrationOR.getProperty("Status1");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjStatus1, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vObjStatus1, "INACTIVE"));

        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In PFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));

        } else if (Value.equalsIgnoreCase("Payment Out PFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user shows update msg....");
            String vPaymenthold = AtlasPaymentOutOR.getProperty("Atlas_hold");
            String vSuccessMessage = AtlasPaymentOutOR.getProperty("Atlas_success_msg");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymenthold, "HOLD"));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
            Constants.key.pause("4", "");

        } else if (Value.equalsIgnoreCase("Payment Out CFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user shows update msg....");
            String vPaymentholdcfx = AtlasPaymentOutOR.getProperty("Atlas_hold");
            String vSuccessMessage = AtlasPaymentOutOR.getProperty("Atlas_success_msg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentholdcfx, "HOLD"));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
            Constants.key.pause("4", "");
        } else if (Value.equalsIgnoreCase("Payment Out CFX-Etailer") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user shows update msg....");
            String vPaymentholdcfx = AtlasPaymentOutOR.getProperty("Atlas_hold");
            String vSuccessMessage = AtlasPaymentOutOR.getProperty("Atlas_success_msg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentholdcfx, "HOLD"));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
            Constants.key.pause("4", "");
        } else if (Value.equalsIgnoreCase("Payment In CFX") && Action.equalsIgnoreCase("HOLD")) {
            LogCapture.info("user shows update msg....");
            String vPaymentholdincfx = AtlasPaymentOutOR.getProperty("Atlas_hold");
            String vSuccessMessage = AtlasPaymentOutOR.getProperty("Atlas_success_msg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentholdincfx, "HOLD"));
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
            Constants.key.pause("4", "");
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("CLEAR")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "CLEAR"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("REJECT")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentrejectStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "REJECT"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("SEIZE")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentComplianceSeizeStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "SEIZE"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        } else if (Value.equalsIgnoreCase("Payment In CFX-Etailer") && Action.equalsIgnoreCase("HOLD")) {
            String vPaymentCompStatus = Constants.AtlasPaymentInOR.getProperty("Atlas_paymentholdStatus");
            String vSuccessMessage = Constants.AtlasPaymentInOR.getProperty("Atlas_ComplianceStatusSuccessMessage");
            Constants.key.pause("4", "");
            Assert.assertEquals("PASS", Constants.key.verifyText(vPaymentCompStatus, "HOLD"));
            Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMessage, "Updated successfully"));
        }
    }
    @And("^User selects reason \"([^\"]*)\" from drop down$")
    public void userSelectsReasonFromDropDown(String reason) throws Throwable {
        LogCapture.info("user select reason from dropdown....");
        String vArrowDDClick = Constants.AtlasPaymentOutOR.getProperty("Atlas_ReasonArrowDropDown");
        String vReason = Constants.AtlasPaymentOutOR.getProperty("Atlas_reason");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vArrowDDClick, ""));
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        Assert.assertEquals("PASS", Constants.key.click(vReason, ""));
    }
    @Then("^User Provide TAN and Trade payment ID$")
    public void userProvideTANAndTradePaymentID() throws Exception {
        TradePaymentID= Constants.key.VerifyDBDetails("UAT", TradeAccountNumber, "Fetch TradePaymentInID");
        System.out.println("Latest TradePaymentID : " + TradePaymentID);
        DynamicValue.put("<TradePaymentID>",TradePaymentID);
        DynamicValue.put("<TradeAccountNumber>",TradeAccountNumber);
    }
    @Then("^User replace trade payment ID with dynamic value$")
    public void userReplaceTradePaymentIDWithDynamicValue() {
        DynamicValue.put("<dynamic>",TradePaymentID);
        LogCapture.info("--------------User replace trade payment ID with dynamic value for kafka -------------------");
    }
    @Then("^User Provide latest generated TAN and Trade payment ID$")
    public void userProvideLatestGeneratedTANAndTradePaymentID() {
        DynamicValue.put("<TradePaymentID>",Constants.DynamicValue.get("<dynamic>"));
        DynamicValue.put("<TradeAccountNumber>",TradeAccountNumber);
    }
    @Then("^User clicks on (blacklist|Custom|Sanctions|BlacklistBeneficiary|Reference|CustomCheck|SanContact|SanBeneficiary|SanBank|FraudPredict) checks tab and perform Repeat check$")

    public void userClicksOnBlacklistChecksTabAndPerformRepeatCheck(String Checks) throws Exception {
        if (Checks.equalsIgnoreCase("Blacklist")) {
            String vObjBlacklistTab = AtlasPaymentInOR.getProperty("BlacklistTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistTab, ""));
            LogCapture.info("User is clicking on Blacklist check");

            String vObjBlacklistRepeatCheckButton = AtlasPaymentInOR.getProperty("BlacklistRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vBlackistRepeatcheck = AtlasPaymentInOR.getProperty("BlacklistRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlackistRepeatcheck, "Blacklist Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("Custom")) {
            String vObjCustomTab = AtlasPaymentInOR.getProperty("CustomTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomTab, ""));
            LogCapture.info("User is clicking on Custom check");

            String vObjCustomRepeatCheckButton = AtlasPaymentInOR.getProperty("CustomRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vCustomRepeatcheck = AtlasPaymentInOR.getProperty("CustomRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCustomRepeatcheck, "Custom Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("Sanctions")) {
            String vObjSanctionsTab = AtlasPaymentInOR.getProperty("SanctionsTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsTab, ""));
            LogCapture.info("User is clicking on Sanction check");

            String vObjSanctionRepeatCheckButton = AtlasPaymentInOR.getProperty("SanctionRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanctionRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("7", ""));
            String vSanctionRepeatcheck = AtlasPaymentInOR.getProperty("SanctionRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionRepeatcheck, "Sanction Repeat Check Successfully done"));

        } else if (Checks.equalsIgnoreCase("BlacklistBeneficiary")) {
            String vObjBlackChecklistTab = AtlasPaymentOutOR.getProperty("BlacklistBeneficiary");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlackChecklistTab, ""));
            LogCapture.info("User is clicking on Blacklist check");

            String vObjBlacklistCheckRepeatCheckButton = AtlasPaymentOutOR.getProperty("BlacklistBeneficiaryRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjBlacklistCheckRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vBlacklistBeneficiaryMSG = AtlasPaymentOutOR.getProperty("BlacklistBeneficiaryRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlacklistBeneficiaryMSG, "Blacklist Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("SanContact")) {
            String vObjSanBeneficiaryTab = AtlasPaymentOutOR.getProperty("SanContactTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBeneficiaryTab, ""));
            LogCapture.info("User is clicking on SanContact check");

            String vObjSanContactRepeatCheckButton = AtlasPaymentOutOR.getProperty("SanContactRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanContactRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vSanContactCheckRepeatcheck = AtlasPaymentOutOR.getProperty("SanContactRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanContactCheckRepeatcheck, "Sanction Repeat Check Successfully done for contact"));
        } else if (Checks.equalsIgnoreCase("SanBeneficiary")) {
            String vObjSanBeneficiaryTab = AtlasPaymentOutOR.getProperty("SanBeneficiaryTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBeneficiaryTab, ""));
            LogCapture.info("User is clicking on SanBeneficiary check");

            String vObjSanBeneficiaryRepeatCheckButton = AtlasPaymentOutOR.getProperty("SanBeneficiaryRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBeneficiaryRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vBlackistCheckRepeatcheck = AtlasPaymentOutOR.getProperty("SanBeneficiaryRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlackistCheckRepeatcheck, "Sanction Repeat Check Successfully done for beneficiary"));
        } else if (Checks.equalsIgnoreCase("SanBank")) {
            String vObjSanBankTab = AtlasPaymentOutOR.getProperty("SanBankTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBankTab, ""));
            LogCapture.info("User is clicking on SanBank check");

            String vObjSanBankRepeatCheckButton = AtlasPaymentOutOR.getProperty("SanBankRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjSanBankRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vSanBankRepeatCheckSuccessMSG = AtlasPaymentOutOR.getProperty("SanBankRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vSanBankRepeatCheckSuccessMSG, "Sanction Repeat Check Successfully done for bank"));
        } else if (Checks.equalsIgnoreCase("FraudPredict")) {
            String vObjFraudPredictTab = AtlasPaymentOutOR.getProperty("FraudPredictTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjFraudPredictTab, ""));
            LogCapture.info("User is clicking on SanBank check");

            String vObjFraudPredictRepeatCheckButton = AtlasPaymentOutOR.getProperty("FraudPredictRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjFraudPredictRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vFraudPredictRepeatCheckSuccessMSG = AtlasPaymentOutOR.getProperty("FraudPredictRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFraudPredictRepeatCheckSuccessMSG, "Fraugster Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("Reference")) {
            String vObjReferenceTab = AtlasPaymentOutOR.getProperty("ReferenceTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjReferenceTab, ""));
            LogCapture.info("User is clicking on ReferenceTab check");

            String vObjReferenceRepeatCheckButton = AtlasPaymentOutOR.getProperty("ReferenceRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjReferenceRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vReferenceRepeatCheckSuccessMSG = AtlasPaymentOutOR.getProperty("ReferenceRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vReferenceRepeatCheckSuccessMSG, "Payment Reference Repeat Check Successfully done"));
        } else if (Checks.equalsIgnoreCase("CustomCheck")) {
            String vObjCustomCheckTab = AtlasPaymentOutOR.getProperty("CustomCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomCheckTab, ""));
            LogCapture.info("User is clicking on CustomCheck");

            String vObjCustomCheckRepeatCheckButton = AtlasPaymentOutOR.getProperty("CustomCheckRepeatCheckButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomCheckRepeatCheckButton, ""));
            LogCapture.info("User is clicking on Repeat check button");
            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
            String vCustomCheckRepeatCheckSuccessMSG = AtlasPaymentOutOR.getProperty("CustomCheckRepeatCheckSuccessMSG");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCustomCheckRepeatCheckSuccessMSG, "Custom repeat check Successfully done"));
        }
    }

    @And("^User clicks on (Blacklist|Custom|Sanction|FraudPredict) check under checks tab$")
    public void userClicksOnBlacklistCheckUnderChecksTab(String Check) throws Exception {
        if (Check.equalsIgnoreCase("Blacklist")) {
            String vBlacklistCheck = Constants.AtlasPaymentInOR.getProperty("BlacklistCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vBlacklistCheck, ""));
            LogCapture.info("User clicks on blacklist check");
        } else if (Check.equalsIgnoreCase("Custom")) {
            String vCustomCheck = Constants.AtlasPaymentInOR.getProperty("CustomCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vCustomCheck, ""));
            LogCapture.info("User clicks on Custom check");
        } else if (Check.equalsIgnoreCase("Sanction")) {
            String vSanctionCheck = Constants.AtlasPaymentInOR.getProperty("SanctionCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vSanctionCheck, ""));
            LogCapture.info("User clicks on Sanction check");
        } else if (Check.equalsIgnoreCase("FraudPredict")) {
            String vFraudPredictCheck = Constants.AtlasPaymentInOR.getProperty("FraudPredictCheckTab");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictCheck, ""));
            LogCapture.info("User clicks on FraudPredict check");
        }

    }
    @Then("^User manually update Sanction check for PaymentIn$")
    public void userManuallyUpdateSanctionCheckForPaymentIn() throws Exception {

        LogCapture.info("User is clicking on the Sanction check Tab...");
        String vObjSanctions = AtlasPaymentInOR.getProperty("Sanctions");
        Assert.assertEquals("PASS", Constants.key.click(vObjSanctions, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
        String vObjStatus = AtlasPaymentInOR.getProperty("SanctionsStatus");
        if (Constants.driver.findElement(By.xpath(vObjStatus)).getText().contains("Not Required")) {
            LogCapture.info("Sanction Check not required");
        } else {
            String vObjSanctiondropdown1 = Constants.AtlasPaymentInOR.getProperty("Sanctiondropdown1");
            String vObjSanctiondropdown2 = Constants.AtlasPaymentInOR.getProperty("Sanctiondropdown2");
            String vObjSafe = Constants.AtlasPaymentInOR.getProperty("Safe");
            String vObjOFACStatus = AtlasPaymentInOR.getProperty("OFACStatus");
            if (Constants.driver.findElement(By.xpath(vObjOFACStatus)).getText().contains("Safe")) {
                LogCapture.info("OFAC field is already safe");
            } else {
                LogCapture.info("User is clicking on the dropdown button for selecting field");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctiondropdown1, ""));

                LogCapture.info("User is clicking on OFAC field");
                String vObjSanctionsOFAC = Constants.AtlasPaymentInOR.getProperty("SanctionsOFAC");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsOFAC, ""));

                Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                LogCapture.info("User is clicking on the dropdown button for setting field");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctiondropdown2, ""));

                Assert.assertEquals("PASS", Constants.key.click(vObjSafe, ""));
                String vObjSanctionApplyButton = Constants.AtlasPaymentInOR.getProperty("SanctionApplyButton");
                LogCapture.info("User is clicking on Apply button ");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctionApplyButton, ""));

            }

            String vObjWorldcheckstatus = AtlasPaymentInOR.getProperty("Worldcheckstatus");
            if (Constants.driver.findElement(By.xpath(vObjWorldcheckstatus)).getText().contains("Safe")) {
                LogCapture.info("Worldcheck field is already safe");
            } else {
                LogCapture.info("User is clicking on worldcheck field");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctiondropdown1, ""));
                String vObjSanctionsWorldCheck = Constants.AtlasPaymentInOR.getProperty("SanctionsWorldCheck");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctionsWorldCheck, ""));
                Assert.assertEquals("PASS", Constants.key.pause("5", ""));
                LogCapture.info("User is clicking on the dropdown button for setting field");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctiondropdown2, ""));
                Assert.assertEquals("PASS", Constants.key.click(vObjSafe, ""));

                String vObjSanctionApplyButton = Constants.AtlasPaymentInOR.getProperty("SanctionApplyButton");
                LogCapture.info("User is clicking on Apply button ");
                Assert.assertEquals("PASS", Constants.key.click(vObjSanctionApplyButton, ""));

                Assert.assertEquals("PASS", Constants.key.pause("10", ""));
                String vSuccessMSG = AtlasPaymentInOR.getProperty("Sanctionupdationsuccessmsg");
                Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMSG, "Updatin sanction Successfully done"));
            }

            LogCapture.info("Sanction for this user is safe");
        }
    }
    @Then("^User clicks on RepeatCheck button for (Blacklist|Custom|Sanction|FraudPredict)$")
    public void userClicksOnRepeatCheckButtonForBlacklist(String Check) throws Exception {
        if (Check.equalsIgnoreCase("Blacklist")) {
            String vBlacklistRepeatCheck = Constants.AtlasPaymentInOR.getProperty("BlacklistRepeatCheck");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vBlacklistRepeatCheck, ""));
            LogCapture.info("User performing Blacklist repeat check");
            Constants.key.pause("10", "");
            String vBlacklistSuccessMsg = Constants.AtlasPaymentInOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vBlacklistSuccessMsg, "Blacklist Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("Custom")) {
            String vCustomRepeatCheck = Constants.AtlasPaymentInOR.getProperty("CustomRepeatCheck");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vCustomRepeatCheck, ""));
            LogCapture.info("User performing Custom repeat check");
            Constants.key.pause("10", "");
            String vCustomSuccessMsg = Constants.AtlasPaymentInOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vCustomSuccessMsg, "Custom Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        } else if (Check.equalsIgnoreCase("Sanction")) {
            String Status = Constants.driver.findElement(By.xpath("//*[@id=\"sanctions_contact\"]/tr/td[9]")).getText();
            if (Status.equalsIgnoreCase("Not Required")){
                LogCapture.info("Sanction repeat check not required");
                driver.quit();
            }
            else{
                String vSanctionRepeatCheck = Constants.AtlasPaymentInOR.getProperty("SanctionRepeatCheck");
                Constants.key.pause("5", "");
                Assert.assertEquals("PASS", Constants.key.click(vSanctionRepeatCheck, ""));
                LogCapture.info("User performing Sanction repeat check");
                Constants.key.pause("10", "");
                String vSanctionSuccessMsg = Constants.AtlasPaymentInOR.getProperty("RepeatCheckSuccessMsg");
                Assert.assertEquals("PASS", Constants.key.verifyText(vSanctionSuccessMsg, "Sanction Repeat Check Successfully done"));
                LogCapture.info("User is able to successfully perform Repeat check");
            }
        } else if (Check.equalsIgnoreCase("FraudPredict")) {
            String vFraudPredictRepeatCheck = Constants.AtlasPaymentInOR.getProperty("FraudPredictRepeatCheck");
            Constants.key.pause("5", "");
            Assert.assertEquals("PASS", Constants.key.click(vFraudPredictRepeatCheck, ""));
            LogCapture.info("User performing FraudPredict repeat check");
            Constants.key.pause("10", "");
            String vFraudPredictSuccessMsg = Constants.AtlasPaymentInOR.getProperty("RepeatCheckSuccessMsg");
            Assert.assertEquals("PASS", Constants.key.verifyText(vFraudPredictSuccessMsg, "Fraugster Repeat Check Successfully done"));
            LogCapture.info("User is able to successfully perform Repeat check");
        }
    }
    @Then("^User clicks on the search box and adds the Watchlist \"([^\"]*)\" that needs to be added for PaymentIn$")
    public void userClicksOnTheSearchBoxAndAddsTheWatchlistThatNeedsToBeAddedForPaymentIn(String Watchlists) throws Throwable {
        LogCapture.info("User is clicking on the search box for Watchlists...");
        String Vsearchwatchlist = Constants.AtlasPaymentInOR.getProperty("searchBoxWatchlistdropdown");
        Assert.assertEquals("PASS", Constants.key.click(Vsearchwatchlist, ""));

        String Vsearchlist = Constants.AtlasPaymentInOR.getProperty("searchlist");
        LogCapture.info("User is adding the Watchlist that needs to be added in the search box...");
        Assert.assertEquals("PASS", Constants.key.writeInInput(Vsearchlist, Watchlists));
        Assert.assertEquals("PASS", Constants.key.click(Vsearchwatchlist, ""));
        Assert.assertEquals("PASS", Constants.key.click(Vsearchwatchlist, ""));
        //Add comment
        String vTextInput = Constants.AtlasPaymentOutOR.getProperty("Atlas_CommentsTextInput");
        Constants.key.pause("5", "");
        Assert.assertEquals("PASS", Constants.key.click(vTextInput, ""));
        Comments = RandomStringUtils.randomAlphabetic(10);
        Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));
    }
    @Then("^user add comments for updating watchlist$")
    public void userAddCommentsForUpdatingWatchlist() throws Exception {
        Comments = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(10);
        System.out.println(Comments);
        String vTextInput = Constants.AtlasPaymentInOR.getProperty("Atlas_CommentsTextInput");
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vTextInput, Comments));

    }
    @Then("^User validates watchlist is been successfully updated$")
    public void userValidatesWatchlistIsBeenSuccessfullyUpdated() throws Exception {
        LogCapture.info("User validating watchlist is been updated successfully updated");
        String vSuccessMSG = AtlasPaymentInOR.getProperty("WatchlistupdationMSG");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vSuccessMSG, "Updated successfully"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vSuccessMSG, "Updated successfully"));
    }
    @And("^User select (Record|Client Type) as \"([^\"]*)\"$")
    public void userSelectRecordAs(String Value, String NewOrUpdate) throws Throwable {
        if (NewOrUpdate.equalsIgnoreCase("New") && Value.equalsIgnoreCase("Record")) {
            String vObjNewRecord = AtlasRegistrationOR.getProperty("NewRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNewRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjNewRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("Updated") && Value.equalsIgnoreCase("Record")) {
            String vObjUpdateRecord = AtlasRegistrationOR.getProperty("UpdateRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUpdateRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjUpdateRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("Inactive") && Value.equalsIgnoreCase("Record")) {
            String vObjInactiveRecord = Constants.AtlasRegistrationOR.getProperty("InactiveRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInactiveRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjInactiveRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("Active") && Value.equalsIgnoreCase("Record")) {
            String vObjActiveRecord = Constants.AtlasRegistrationOR.getProperty("ActiveRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjActiveRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjActiveRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("CFX") && Value.equalsIgnoreCase("Client Type")) {
            String vObjCFXRecord = Constants.AtlasRegistrationOR.getProperty("CFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCFXRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("PFX") && Value.equalsIgnoreCase("Client Type")) {
            String vObjPFXRecord = Constants.AtlasRegistrationOR.getProperty("PFXRecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPFXRecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPFXRecord, ""));
        } else if (NewOrUpdate.equalsIgnoreCase("CFX-Etailer") && Value.equalsIgnoreCase("Client Type")) {
            String vObjCFXERecord = Constants.AtlasRegistrationOR.getProperty("CFXERecord");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCFXERecord, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjCFXERecord, ""));

        }
    }
    @And("^User clicks on Organization dropdown and selects the organization as \"([^\"]*)\"$")
    public void userClicksOnOrganizationDropdownAndSelectsTheOrganizationAs(String Org) throws Throwable {
        String vObjOrgDropDown = Constants.AtlasPaymentOutOR.getProperty("OrganizationDropDown");
        Assert.assertEquals("PASS", Constants.key.click(vObjOrgDropDown, ""));
        String vObjOrgValue = "";

        if (Org.equalsIgnoreCase("CD")) {
            vObjOrgValue = Constants.AtlasPaymentOutOR.getProperty("CD_OrgValue");
        } else if (Org.equalsIgnoreCase("FCG")) {
            vObjOrgValue = Constants.AtlasPaymentOutOR.getProperty("FCG_OrgValue");
        } else if (Org.equalsIgnoreCase("TORFX")) {
            vObjOrgValue = Constants.AtlasPaymentOutOR.getProperty("TorFX_OrgValue");
        } else if (Org.equalsIgnoreCase("TORAU")) {
            vObjOrgValue = Constants.AtlasPaymentOutOR.getProperty("TorAU_OrgValue");
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjOrgValue, ""));
        LogCapture.info(Org + " is selected as oragnization from dropdown");
    }
    @Then("^User Map this values with delete funds Out API$")
    public void userMapThisValuesWithDeleteFundsOutAPI() throws Exception {
        DynamicValue.put("<TradePaymentID>",DynamicValue.get("<dynamic>"));
        String vTradeAccountNumber= AtlasPaymentOutOR.getProperty("FundsOutTradeAccountNum");
        String TradeAccountNumber = Constants.key.getText(vTradeAccountNumber);
        DynamicValue.put("<TradeAccountNumber>",TradeAccountNumber );
    }
    @Then("^User validate response code \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userValidateResponseCodeAnd(String responseCode, String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(responseCode, jp.get("responseCode")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }
    @Then("^User enters fundsIn transaction number in keyword Section$")
    public void userEntersFundsInTransactionNumberInKeywordSection(String FundsInID) throws Exception {
        FundsInID=TradeAccountNumber+"-"+Constants.DynamicValue.get("<dynamic>");
        String vKeyword = Constants.AtlasPaymentInOR.getProperty("Atlas_enterSearchCriteriaKeyword");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vKeyword, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vKeyword, FundsInID));
    }

}

