package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.service.utillity.*;
import com.utility.LogCapture;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Objects;

import static com.selenium.utillity.Constants.*;
import static com.service.utillity.ReusableMethod.*;

/**
 * @author sunny.goyal
 */
public class CommonStepDefinitionCards {

    static boolean isKafkaLaunched;

    private CommonStep commonStep = new CommonStep();
    private TransactionType transactionType;
    private TransactionType previousTxnType;
    private String publicToken;
    private Currency currency;
    private CustomerDetails customerDetails = new CustomerDetails();
    private GPSGetTxnReqDetails gpsGetTxnReqDetails = new GPSGetTxnReqDetails();
//    private Map<String, Double> balancesBeforeTnx;
    private Map<String, Double> balancesBeforeIncTnx;
    private Map<String, Double> balancesAfterTnx;
    static int titanOutboxRecordCount,testDataRow;
    private double Bill_Amt_Approved, AvlBalance_GPS_STIP, CurBalance_GPS_STIP, authAmt, reversalAmt, FX_Rate;
    private String gpsGetTxnReqBody, Additional_Amt_DE54;

    @Given("^GPS wants to perform a \"([^\"]*)\" on behalf of user with public token \"([^\"]*)\"$")
    public void given_GPS_wants_to_perform_a_transaction_on_behalf_of_user_with_public_token(TransactionType txnType, String publicToken) {
        previousTxnType = this.transactionType;
        this.transactionType = txnType;
        this.publicToken = publicToken;

        Map<String, String> custDetails = ReusableMethod.getSqlQueryResult("CPCardAdmin.CardDetails.UsingToken.Query", publicToken);
        Assert.assertNotNull(custDetails, "Could not fetch Card Details from DB for public token " + publicToken +
                "Please check if Environment variable OR Test data is set correctly");

        customerDetails.setPublicToken(publicToken);
        customerDetails.setCustRef(custDetails.get("cd_customer_ref"));
        customerDetails.setContactId(custDetails.get("contact_id"));
        Assert.assertNotNull(custDetails.get("base_currency"), "No record found for the card with public token " + publicToken);
        customerDetails.setBaseCurrency(TitanCurrency.valueOf(custDetails.get("base_currency")));
    }

    @Given("^GPS sends offline presentment request for \"([^\"]*)\" currency and \"([^\"]*)\" amount using data from row \"(\\d)\"$")
    public void given_GPS_sends_offline_presentment_request_for_x_currency_and_x_amount(Currency currency, double transactionAmount, int testDataRow) {
        LogCapture.info("Starting to send Offline Presentment request........");
        if(gpsGetTxnReqDetails.getTXn_ID() == null) {
            gpsGetTxnReqDetails = commonStep.setAuthReqDetails(publicToken);
            gpsGetTxnReqDetails.setCust_Ref(customerDetails.getCustRef());
        }
        commonStep.setOfflinePresentmentReqDetails(gpsGetTxnReqDetails);
        setTxnAndBillDetails(currency, transactionAmount);
        paymentLifeCycleID = gpsGetTxnReqDetails.getTraceid_lifecycle();
        KafkaMessageCDID = paymentLifeCycleID;

        String presentmentRequestBody = testDataRows.get(testDataRow - 1).get("Body");
        gpsGetTxnReqBody = ReusableMethod.replaceFieldsUsingXpath(presentmentRequestBody, gpsGetTxnReqDetails);
        //commonStep.saveAmtDetails(gpsGetTxnReqBody, gpsGetTxnReqDetails);
        testDataRows.get(testDataRow - 1).replace("Body", gpsGetTxnReqBody);

        Constants.RESPONSE = ServiceMethod.postAdvance(testDataRow - 1, "200");
        LogCapture.info(Constants.RESPONSE);
    }

    @Then("^Verify the presentment response$")
    public void then_verify_the_presentment_response() {
        Assert.assertEquals(ReusableMethod.getXpathValue(Constants.RESPONSE, "//Acknowledgement"), "1");
    }

    private void setTxnAndBillDetails(Currency currency, double txnAmtValue) {
        BigDecimal billAmt, rate = null;
        BigDecimal txnAmt = BigDecimal.valueOf(txnAmtValue).setScale(4);
        gpsGetTxnReqDetails.setCust_Ref(customerDetails.getCustRef());

        gpsGetTxnReqDetails.setTxn_CCy(currency.getCode());
        gpsGetTxnReqDetails.setTxn_Amt(txnAmt.doubleValue());
        gpsGetTxnReqDetails.setBill_Ccy(customerDetails.getBaseCurrency().toCurrency().getCode());
        gpsGetTxnReqDetails.setSettle_Ccy(gpsGetTxnReqDetails.getBill_Ccy());
        gpsGetTxnReqDetails.setSettle_Amt(BigDecimal.valueOf(0.0000).setScale(4).doubleValue());

        if (gpsGetTxnReqDetails.getTxnCurrency() == gpsGetTxnReqDetails.getBillCurrency()) {
            billAmt = txnAmt;
        } else {
            Currency txnCCy = gpsGetTxnReqDetails.getTxnCurrency();
            //TODO use getPreCalculatedRate API
            switch (gpsGetTxnReqDetails.getBillCurrency()) {
                case EUR:
                    rate = BigDecimal.valueOf(txnCCy.getToEurRate());
                    break;
                case GBP:
                    rate = BigDecimal.valueOf(txnCCy.getToGbpRate());
                    break;
            }
            rate.setScale(4, RoundingMode.CEILING);
            billAmt = txnAmt.multiply(rate).setScale(4);
        }

        // Depending on requestType / transaction Type, setting bill amt sign
        // TODO Need to optimise to use one type instead of two types

        switch (transactionType) {
            case REFUND:
            case REVERSAL_POS:
            case AFD_TYPE1:
            case AFD_TYPE2:
                gpsGetTxnReqDetails.setBill_Amt(billAmt.doubleValue());
                break;
            default:
                gpsGetTxnReqDetails.setBill_Amt(-billAmt.doubleValue());
        }
    }

    @Then("^Verify kafka message using \"([^\"]*)\"$")
    public void then_verify_kafka_message_using_sql_query_property(String expectedMsgFieldsSqlQueryProperty) throws Exception {
//        String kafkaMsg = ConsumerExample.KafkaSearch(gpsGetTxnReqDetails.getTraceid_lifecycle());
//        JsonPath jsonPath = JsonPath.from(kafkaMsg);
        String messageFieldXpath = Constants.KafkaUI.getProperty("MessageFieldContainsAnyText");
        messageFieldXpath = messageFieldXpath.replace("{uniqueMessageId}", gpsGetTxnReqDetails.getTraceid_Message());

        JsonPath actualKafkaMsgJsonObj = waitForKafkaMessage(messageFieldXpath);
        kafkaExpectedKeyValues = ReusableMethod.getSqlQueryResult(expectedMsgFieldsSqlQueryProperty, gpsGetTxnReqDetails.getTraceid_lifecycle());
        ReusableMethod.verifyKafkaMessage(kafkaExpectedKeyValues, actualKafkaMsgJsonObj);

        softAssert.assertEquals(actualKafkaMsgJsonObj.getString("MessageData.DeviceId"), getXpathValue(gpsGetTxnReqBody, "//PaymentToken_deviceId"));
        softAssert.assertEquals(Double.parseDouble(kafkaExpectedKeyValues.get("amountToDebit")), -Double.parseDouble(ReusableMethod.cleanJsonPathValue(actualKafkaMsgJsonObj.getString("amountToDebit"))));
        //MessageData.IpAddress=PaymentToken_deviceIp
        //MessageData.interchangeDirection
        //MessageData.masterCardSettlementDate=Settlement_Date
        //MessageData.merchantNameOther=Merch_Name_Other
//        Map<String, String> headersMap = kafkaMessageJson.getMap(Constants.CONFIG.getProperty("KafkaMessageHeaderFieldName"), String.class, String.class);
//        Map<String, String> messageDataMap = kafkaMessageJson.getMap(Constants.CONFIG.getProperty("KafkaMessageDataFieldName"), String.class, String.class);
    }
//
//    @Then("^Verify Kafka message audit logs for \"([^\"]*)\"$")
//    public void verify_kafka_message_audit_logs_for_mappings_file(String auditLogSqlQueryProperty) {
//
//        Map<String, String> actualAuditRecord = ReusableMethod.getSqlQueryResult(auditLogSqlQueryProperty, gpsGetTxnReqDetails.getTraceid_Message());
//        System.out.println("Actual Audit Log for '" + gpsGetTxnReqDetails.getTraceid_lifecycle() + "' :: " + actualAuditRecord);
//        ReusableMethod.verifyKafkaAuditLog(kafkaExpectedKeyValues, actualAuditRecord);
////        Gson gson = new Gson();
////        String json = gson.toJson(auditRecord);
////        JsonPath jsonPath = JsonPath.from(json);
////        commonStep.compareJsonAgainstGetTxnMappings(gpsGetTxnReqBody, jsonPath, mappingFilePath, true);
//    }


    @Then("^Verify fullUnblockAndDebit kafka message using \"([^\"]*)\"$")
    public void verify_fullUnblockAndDebit_kafka_message_using(String expectedMsgFieldsSqlQueryProperty) throws Exception {
//        JsonPath jsonPath = waitForKafkaMessage(gpsGetTxnReqDetails.getTraceid_Message());
//        String kafkaMsg = ConsumerExample.KafkaSearch(gpsGetTxnReqDetails.getTraceid_lifecycle());
//        JsonPath jsonPath = JsonPath.from(kafkaMsg);
//        commonStep.compareJsonAgainstGetTxnMappings(gpsGetTxnReqBody, jsonPath, mappingFilePath, false);

        String messageFieldXpath = Constants.KafkaUI.getProperty("MessageFieldContainsAnyText");
        messageFieldXpath = messageFieldXpath.replace("{uniqueMessageId}", gpsGetTxnReqDetails.getTraceid_Message());

        JsonPath actualKafkaMsgJsonObj = waitForKafkaMessage(messageFieldXpath);
        kafkaExpectedKeyValues = ReusableMethod.getSqlQueryResult(expectedMsgFieldsSqlQueryProperty, gpsGetTxnReqDetails.getTraceid_lifecycle());
        ReusableMethod.verifyKafkaMessage(kafkaExpectedKeyValues, actualKafkaMsgJsonObj);

        commonStep.getAtmFee(gpsGetTxnReqDetails.getTxnCurrency(), gpsGetTxnReqDetails.getBillCurrency());
        double actualAtmFee = Double.parseDouble(ReusableMethod.cleanJsonPathValue(actualKafkaMsgJsonObj.getString("MessageData.atmFee")));
        softAssert.assertEquals(actualAtmFee, commonStep.getAtmFee(gpsGetTxnReqDetails.getTxnCurrency(), gpsGetTxnReqDetails.getBillCurrency()), "Assertion for fullUnblockAndDebit > 'MessageData.atmFee' failed");
        softAssert.assertEquals(ReusableMethod.cleanJsonPathValue(actualKafkaMsgJsonObj.getString("MessageData.atmFeeCurrency")), commonStep.getAtmFeeCcy(gpsGetTxnReqDetails.getBillCurrency(), gpsGetTxnReqDetails.getTxnCurrency()).name(), "Assertion for fullUnblockAndDebit > 'MessageData.atmFeeCurrency' failed");

        double actualAmountToDebit = Double.parseDouble(ReusableMethod.cleanJsonPathValue(actualKafkaMsgJsonObj.getString("MessageData.amountToDebit")));
        softAssert.assertEquals(actualAmountToDebit, commonStep.getAmountToDebit(transactionType, gpsGetTxnReqDetails), "Assertion for fullUnblockAndDebit > 'MessageData.amountToDebit' failed");
        softAssert.assertEquals(ReusableMethod.cleanJsonPathValue(actualKafkaMsgJsonObj.getString("MessageData.amountToDebitCurrency")), commonStep.getAmountToDebitCcy(gpsGetTxnReqDetails).name(), "Assertion for fullUnblockAndDebit > 'MessageData.amountToDebitCurrency' failed");

    }

    @Then("^Verify fullUnblockAndDebit Kafka message audit logs for \"([^\"]*)\"$")
    public void verify_fullUnblockAndDebit_kafka_message_audit_for(String auditLogSqlQueryProperty) throws Exception {
//        Map<String, String> auditRecord = ReusableMethod.getSqlQueryResult("Kafka.Audit.PaymentLifeCycleId", gpsGetTxnReqDetails.getTraceid_Message());
//        Gson gson = new Gson();
//        String json = gson.toJson(auditRecord);
//        JsonPath jsonPath = JsonPath.from(json);
        //commonStep.compareJsonAgainstGetTxnMappings(gpsGetTxnReqBody, jsonPath, mappingFilePath, true);

        Map<String, String> actualAuditRecord = ReusableMethod.getSqlQueryResult(auditLogSqlQueryProperty, gpsGetTxnReqDetails.getTraceid_Message());
        System.out.println("Actual Audit Log for '" + gpsGetTxnReqDetails.getTraceid_lifecycle() + "' :: " + actualAuditRecord);
        ReusableMethod.verifyKafkaAuditLog(kafkaExpectedKeyValues, actualAuditRecord);

        commonStep.getAtmFee(gpsGetTxnReqDetails.getTxnCurrency(), gpsGetTxnReqDetails.getBillCurrency());
        double actualAtmFee = Double.parseDouble(Objects.requireNonNull(cleanJsonPathValue(actualAuditRecord.get("atmfee"))));
        softAssert.assertEquals(actualAtmFee, commonStep.getAtmFee(gpsGetTxnReqDetails.getTxnCurrency(), gpsGetTxnReqDetails.getBillCurrency()), "Assertion for audit logs > fullUnblockAndDebit > 'atmfee' failed");
        softAssert.assertEquals(ReusableMethod.cleanJsonPathValue(actualAuditRecord.get("atmfeecurrency")), commonStep.getAtmFeeCcy(gpsGetTxnReqDetails.getBillCurrency(), gpsGetTxnReqDetails.getTxnCurrency()).name(), "Assertion for audit logs > fullUnblockAndDebit > 'atmfeecurrency' failed");

        double actualAmountToDebit = Double.parseDouble(Objects.requireNonNull(cleanJsonPathValue(actualAuditRecord.get("amounttodebit"))));
        softAssert.assertEquals(actualAmountToDebit, commonStep.getAmountToDebit(transactionType, gpsGetTxnReqDetails), "Assertion for audit logs > fullUnblockAndDebit > 'amounttodebit' failed");
        softAssert.assertEquals(ReusableMethod.cleanJsonPathValue(actualAuditRecord.get("amounttodebitcurrency")), commonStep.getAmountToDebitCcy(gpsGetTxnReqDetails).name(), "Assertion for audit logs > fullUnblockAndDebit > 'amounttodebitcurrency' failed");

    }

    @Given("^GPS sends (authorisation|reversal|CASHBACK_AUTHORISATION|reversal-afd|wallet-authorisation|authorisation-advice|authorisation-advice-afd|advice) request for \"([^\"]*)\" currency and \"([^\"]*)\" amount using data from row \"(\\d)\"$")
    public void given_GPS_sends_authorisation_request_for_x_currency_and_x_amount(String txnType, Currency currency, double txnAmt, int testDataRow) throws IOException {
        LogCapture.info("Starting to send Authorisation request........");
        switch (txnType.toUpperCase()) {
            case "REVERSAL":
                commonStep.setReversalReqDetails(gpsGetTxnReqDetails);
                reversalAmt=txnAmt;
                break;
            case "WALLET-AUTHORISATION":
                gpsGetTxnReqDetails = commonStep.setAuthReqDetails(publicToken, customerDetails);
                break;
            case "AUTHORISATION-ADVICE":
                gpsGetTxnReqDetails.setAuthorised_by_GPS("Y");
                break;
            case "ADVICE":
                gpsGetTxnReqDetails = commonStep.setAuthReqDetails(publicToken);
                gpsGetTxnReqDetails.setAuthorised_by_GPS("Y");
                break;
            case "AUTHORISATION-ADVICE-AFD":
                //gpsGetTxnReqDetails.setAuthorised_by_GPS("Y");
                gpsGetTxnReqDetails.setTraceid_Original(gpsGetTxnReqDetails.getTraceid_lifecycle());
                gpsGetTxnReqDetails.setTraceid_lifecycle(gpsGetTxnReqDetails.getTraceid_lifecycle());
                // uses new Traceid_Message for Auth-Advice-Afd
                gpsGetTxnReqDetails.setTraceid_Message(gpsGetTxnReqDetails.getTraceid_lifecycle().replace("AUTO", "AFD "));
                break;
            case "REVERSAL-AFD":
                commonStep.setReversalReqDetails(gpsGetTxnReqDetails);
                gpsGetTxnReqDetails.setTraceid_Original(gpsGetTxnReqDetails.getTraceid_lifecycle());
                gpsGetTxnReqDetails.setTraceid_lifecycle(gpsGetTxnReqDetails.getTraceid_lifecycle());
                // uses same Traceid_Message as Auth-Advice-Afd
                break;
            case "CASHBACK_AUTHORISATION":
                gpsGetTxnReqDetails = commonStep.setAuthReqDetails(publicToken);
                gpsGetTxnReqDetails.setProc_Code(TransactionType.CASHBACK);
                gpsGetTxnReqDetails.setAdditional_Amt_DE54(this.Additional_Amt_DE54);
                break;
            default:
                gpsGetTxnReqDetails = commonStep.setAuthReqDetails(publicToken);
                if(this.Additional_Amt_DE54 != null) {
                    gpsGetTxnReqDetails.setAdditional_Amt_DE54(this.Additional_Amt_DE54);
                }
        }
        paymentLifeCycleID = gpsGetTxnReqDetails.getTraceid_lifecycle();
        Constants.KafkaMessageCDID = Constants.paymentLifeCycleID;
        GPS_sends_authorisation_request_for_x_currency_and_x_amount(currency, txnAmt, testDataRow);
//        balancesBeforeIncTnx = new HashMap<>(balancesBeforeTnx);//this is to create a copy only & used only for incremental/pre/final auth scenario
    }

    @Then("^Verify the authorisation response$")
    public void then_verify_the_authorisation_response() {
        Assert.assertEquals(ReusableMethod.getXpathValue(Constants.RESPONSE, "//Responsestatus"), "00");
        // For all currencies including GBP
        Assert.assertEquals(ReusableMethod.getXpathValue(Constants.RESPONSE, "//Acknowledgement"), "1");
        try {
            String billAmtApproved = ReusableMethod.getXpathValue(Constants.RESPONSE, "//Bill_Amt_Approved");
            Bill_Amt_Approved = Double.parseDouble(billAmtApproved);
        } catch (Exception e) {

        }
    }

    @Given("^GPS sends presentment request for \"([^\"]*)\" currency and \"([^\"]*)\" amount using data from row \"(\\d)\"$")
    public void given_GPS_sends_presentment_request_for_x_currency_and_x_amount(Currency currency, double transactionAmount, int testDataRow) {
        LogCapture.info("Starting to send Presentment request........");
//        if(transactionType.name()=="REVERSAL_POS") {
//            requestType=RequestType.PRESENTMENT;
//        }else{
//            requestType=null;
//        }
        setTxnAndBillDetails(currency, transactionAmount);
        commonStep.setPresentmentReqDetails(gpsGetTxnReqDetails, null);
        String presentmentRequestBody = Constants.testDataRows.get(testDataRow - 1).get("Body");

        gpsGetTxnReqBody = ReusableMethod.replaceFieldsUsingXpath(presentmentRequestBody, gpsGetTxnReqDetails);
        //commonStep.saveAmtDetails(gpsGetTxnReqBody, gpsGetTxnReqDetails);
        Constants.testDataRows.get(testDataRow - 1).replace("Body", gpsGetTxnReqBody);

        Constants.RESPONSE = ServiceMethod.postAdvance(testDataRow - 1, "200");
        LogCapture.info(Constants.RESPONSE);
    }


    private void GPS_sends_authorisation_request_for_x_currency_and_x_amount(Currency currency, double txnAmtVal, int testDataRow) {
        this.testDataRow= testDataRow - 1;
        setTxnAndBillDetails(currency, txnAmtVal);
        String authRequestBody = Constants.testDataRows.get(testDataRow - 1).get("Body");

        gpsGetTxnReqBody = ReusableMethod.replaceFieldsUsingXpath(authRequestBody, gpsGetTxnReqDetails);
        Constants.testDataRows.get(testDataRow - 1).replace("Body", gpsGetTxnReqBody); //update the body saved in Map

        switch (transactionType) {
            case TCN:
            case TAR:
            case TAR_00:
            case ACN: // Do nothing
            case TVN:
                break;
//            default:
//                setTitanWallet();
        }

        Constants.RESPONSE = ServiceMethod.postAdvance(testDataRow - 1, "200");
        LogCapture.info(Constants.RESPONSE);
    }


    public void setTitanWallet() {
        Currency ccy = Currency.getCurrency(gpsGetTxnReqDetails.getTxn_CCy());
        if (commonStep.isSupportedCcy(ccy))
            this.currency = gpsGetTxnReqDetails.getTxnCurrency();
        else
            this.currency = gpsGetTxnReqDetails.getBillCurrency();

        assert currency.toTitanCurrency() != null;
//        Map<String, String> walletIdMap = ReusableMethod.getSqlQueryResult("Titan.WalletId.Query", customerDetails.getCustRef(), String.valueOf(currency.toTitanCurrency().getId()));
//        customerDetails.setWalletId(walletIdMap.get("ID"));
//        balancesBeforeTnx = ReusableMethod.getWalletBalances(walletIdMap.get("ID"));

    }
}
