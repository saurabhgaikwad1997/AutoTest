package com.service.utillity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class GPSGetTxnReqDetails {

    String Cust_Ref;
    String Token;
    String Bill_Ccy;
    double Bill_Amt;
    double Settle_Amt;
    String Settle_Ccy;
    double Txn_Amt;
    String Txn_CCy;
    String Txn_Ctry;
    String traceid_lifecycle;
    String Traceid_Message;
    String Trans_link;
    String TXn_ID;
    String auth_type;
    String Matching_Txn_ID;
    String Txn_GPS_Date; //2023-01-24 10:31:48.110
    String Clearing_Process_Date; //2023-01-24
    String Settlement_Date;//2023-01-24
    String POS_Date_DE13;//20230124
    String POS_Time_DE12; //YYMMDDhhmmss 230127114244 in Presentment and hhmmss in auth// TODO
    String PaymentToken_id;
    String PaymentToken_wallet;
    String Authorised_by_GPS;
    String GPS_POS_Data;
    String Proc_Code;
    String Resp_Code_DE39;
    String PaymentToken_creatorStatus;
    String Note;
    String Traceid_Original;
    String Additional_Amt_DE54;

    public Currency getBillCurrency() {
        return Currency.getCurrency(Bill_Ccy);
    }

    public Currency getTxnCurrency() {
        return Currency.getCurrency(Txn_CCy);
    }

    public void setProc_Code(TransactionType transactionType) {
        Proc_Code = transactionType.Proc_Code;
    }

    public void setResp_Code_DE39(TransactionType transactionType) {
        switch (transactionType) {
            case TAR:
                Resp_Code_DE39 = "85";
                break;
            default:
                Resp_Code_DE39 = "00";
        }
    }

    public void setResp_Code_DE39(String Resp_Code_DE39) {
        this.Resp_Code_DE39 = Resp_Code_DE39;
    }

    public void setAdditional_Amt_DE54(String Additional_Amt_DE54) {
        this.Additional_Amt_DE54 = Additional_Amt_DE54;
    }
}
