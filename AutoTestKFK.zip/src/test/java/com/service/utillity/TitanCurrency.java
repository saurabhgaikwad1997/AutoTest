package com.service.utillity;

public enum TitanCurrency {

    AED(1),
    AUD(2),
    CAD(7),
    CHF(8),
    CZK(10),
    DKK(11),
    EUR(14),
    GBP(16),
    HKD(18),
    ILS(21),
    INR(22),
    JPY(23),
    NOK(33),
    NZD(34),
    PLN(37),
    SAR(41),
    SEK(42),
    SGD(43),
    THB(44),
    USD(48),
    ZAR(49),
    CNH(9);
    private int id;
    TitanCurrency(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public Currency toCurrency() {
       return Currency.valueOf(this.name());
    }
}
