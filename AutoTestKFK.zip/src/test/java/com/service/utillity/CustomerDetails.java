package com.service.utillity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomerDetails {
    private String custRef;
    private String contactId;
    private String walletId;
    private double totalBalance;
    private double availableBalance;
    private TitanCurrency baseCurrency;
    private int CardId;
    private String publicToken;
    private int cVC2;
    private String paymentTokenId;
    private String paymentWallet;
    private String firstTransactionDate;
    private int latestCardId;
    private String countryCode;
    private int pricePlanId;
}
