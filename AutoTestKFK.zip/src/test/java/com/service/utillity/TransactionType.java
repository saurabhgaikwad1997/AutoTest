package com.service.utillity;

public enum TransactionType {

    ATM_CASH_WITHDRAWAL("ATM", "010000"),
    POS("POS", "000000"),
    AFD_TYPE1("AFD", "000000"),
    AFD_TYPE2("AFD WITH NEG REVERSAL", "000000"),
    REMOTE("REMOTE", "000000"),
    REFUND("REFUND", "200000"),
    REVERSAL_POS("REVERSAL POS", "000000"),
    NEG_REVERSAL("NEGATIVE REVERSAL", "000000"),
    OFFLINE_PRESENTMENT("OFFLINE PRESENTMENT", "000000"),
    ECOMMERCE("ECOMMERCE", "000000"),
    TAR("TAR", "330000"),
    TAR_00("TAR", "330000"),
    ACN("ACN", "340000"),
    TCN("TCN", "350000"),
    TVN("TVN", "360000"),
    CASHBACK("CASHBACK","090000");
    public final String name;
    public final String Proc_Code;

    TransactionType(String name, String Proc_Code) {
        this.name = name;
        this.Proc_Code = Proc_Code;
    }
}
