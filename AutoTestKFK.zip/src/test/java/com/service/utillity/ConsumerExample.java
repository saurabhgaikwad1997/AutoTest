/*
package com.service.utillity;

*/
/**
 * @author sunny.goyal
 *//*


import com.currenciesdirect.kafka.transaction.CDTransaction;
import com.restAssured.utillity.Constants;
import com.utility.LogCapture;
import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaMetadata;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.RecordDeserializationException;

import java.time.Duration;
import java.util.*;

public class ConsumerExample {

    public static String KafkaSearch(String uniqueID) throws Exception {
//        if (args.length != 1) {
//            System.out.println("Please provide the configuration file path as a command line argument");
//            System.exit(1);
//        }
        String kafkaMsg = null;
        final String topic = "cards-transaction";

        // Load consumer configuration settings from a local file
        // Reusing the loadConfig method from the ProducerExample class
        final Properties props = ProducerExample.loadConfig("src/main/resources/application_" + Constants.JenkinsEnvironment.toLowerCase() + ".properties");

        // Add additional properties. // If we want to override
//        props.put(ConsumerConfig.GROUP_ID_CONFIG, "consumer_group_id");
//        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG, 30000);
        int retryCount = 2;
        boolean isFound = false;

//        SchemaRegistryClient schemaRegistryClient = new CachedSchemaRegistryClient(props.getProperty("schema.registry.url"), 10000);
//        SchemaMetadata schema = schemaRegistryClient.getLatestSchemaMetadata("cards-transaction-value");//.getBySubjectAndId("cards-transaction-value", 57);
//        String schema1 = schema.getSchema();
//        Schema.Parser parser = new Schema.Parser();
//        Schema schema2 = parser.parse(schema1);
//        schema2.getFields().get(0); // Header
//        schema2.getFields().get(1); // Data
//        schema2.getFields().get(1).schema().getFields().get(1).doc();
//        schema2.getFields().get(1).schema().getFields().get(1); //name
//        schema2.getFields().get(1).schema().getField("fieldName").doc();
//        schema2.getFields().get(1).schema().getFields().get(1).doc(); // doc
        try (final Consumer<String, CDTransaction> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Arrays.asList(topic));

            while (retryCount-- > 0) {

//                TopicPartition topicPartition1 = new TopicPartition(topic, 0);
//                TopicPartition topicPartition2 = new TopicPartition(topic, 1);
//                Collection<TopicPartition> coll = new ArrayList<>(2);
//                coll.add(topicPartition1); coll.add(topicPartition2);
//                Map<TopicPartition, Long> offsets = consumer.endOffsets(coll);
//                long offset1 = offsets.get(topicPartition1);
//                long offset2 = offsets.get(topicPartition2);
//                consumer.seekToEnd(coll);
                try {
                    ConsumerRecords<String, CDTransaction> records = consumer.poll(Duration.ofSeconds(10));
                    for (ConsumerRecord<String, CDTransaction> record : records) {
                        String key = record.key();
                        GenericRecord value = record.value();

                        if(value.toString().contains(uniqueID)) {
                            kafkaMsg = value.toString();
                            System.out.println(String.format("Consumed event from topic %s: key = %-10s value = %s", topic, key, value));
                            isFound = true;
                            break;
                        }
                    }
                    if(isFound) break;

                } catch (RecordDeserializationException ex) {
                    LogCapture.error("Error occurred searching for message with unique Id " + uniqueID + ": " + ex.getLocalizedMessage());
                }

            }
        }
        return kafkaMsg;
    }

}
*/
