package com.service.utillity;

import java.util.Arrays;
import java.util.stream.Collectors;

public enum Currency {

    AED("784", 0.21, 0.24, 2),
    AUD("036", 0.52, 0.61, 2),
    BHD("048", 2.08, 2.41, 3),
    BGN("975", 0.44, 0.511, 2),
    CAD("124", 0.58, 0.67, 2),
    CHF("756", 0.89, 1.05, 2),
    CLF("990", 33.02, 38.23, 4),
    CZK("203", 0.035, 0.041, 2),
    DKK("208", 0.11, 0.13, 2),
    EUR("978", 0.86, 1, 2),
    GBP("826", 1.0, 1.16, 2),
    HKD("344", 0.1, 0.12, 2),
    HUF("348", 0.0023, 0.0027, 2),
    ILS("376", 0.21, 0.24, 2),
    INR("356", 0.0093, 0.011, 2),
    JPY("392", 0.0055, 0.0064, 0),
    NOK("578", 0.074, 0.087, 2),
    NZD("554", 0.49, 0.57, 2),
    PLN("985", 0.19, 0.22, 2),
    RON("946", 0.17, 0.2, 2),
    SAR("682", 0.21, 0.25, 2),
    SEK("752", 0.072, 0.084, 2),
    SGD("702", 0.58, 0.67, 2),
    THB("764", 0.022, 0.026, 2),
    USD("840", 0.76, 0.89, 2),
    ZAR("710", 0.041, 0.048, 2),
    CNH("157",0.112,0.129,2);

    private final String code;
    private final double toGbpRate;
    private final double toEurRate;
    private final int exponent;

    Currency(final String code, double toGbpRate, double toEurRate, int exponent) {
        this.code = code;
        this.toGbpRate = toGbpRate;
        this.toEurRate = toEurRate;
        this.exponent = exponent;
    }

    public TitanCurrency toTitanCurrency() {
        return TitanCurrency.valueOf(this.name());
    }

    public static Currency getCurrency(String code) {
        return Arrays.stream(values()).filter(currency -> currency.code.equals(code) ).collect(Collectors.toList()).get(0);
    }

    public String getCode() {
        return this.code;
    }

    public double getToGbpRate() { return this.toGbpRate; }

    public double getToEurRate() { return this.toEurRate; }

    public int getExponent(){
        return exponent;
    }
}
