package com.selenium.utillity;

import com.cucumber.listener.Reporter;
import com.cucumber.stepdefinition.BaseStep;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotCapture {


    public static void takeSnapShot() throws Exception {
        if (Constants.CONFIG.getProperty("ScreenshotCaptureOnFailure").equalsIgnoreCase("False")) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
            String dateString = format.format(new Date());
            String vScenarioN = BaseStep.scenarioName;
            if (Constants.CONFIG.getProperty("Headless").equalsIgnoreCase("True")) {
                String fileWithPath = "/var/jenkins_home/Screenshot-"+System.getenv("JOB_NAME") +"-"+ System.getenv("BUILD_ID") + "/SC_" + vScenarioN + "_" + dateString + ".png";
                TakesScreenshot scrShot = ((TakesScreenshot) Constants.driver);
                File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
                File DestFile = new File(fileWithPath);
                FileUtils.copyFile(SrcFile, DestFile);
                //Reporter.addScreenCaptureFromPath(fileWithPath);

            } else if (Constants.CONFIG.getProperty("Headless").equalsIgnoreCase("False")) {
                String fileWithPath = System.getProperty("user.dir") + "\\Screenshot\\SC" + "_" + vScenarioN + "_" + dateString + ".png";
                Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(Constants.driver);
                ImageIO.write(screenshot.getImage(), "PNG", new File(fileWithPath));
                Reporter.addScreenCaptureFromPath(fileWithPath);
            }
        }
    }

    public static void takeSnapShotOnFailure() throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String dateString = format.format(new Date());
        String vScenarioN = BaseStep.scenarioName;
        if (Constants.CONFIG.getProperty("Headless").equalsIgnoreCase("True")) {
            String fileWithPath = "/var/jenkins_home/Screenshot-"+System.getenv("JOB_NAME") +"-"+ System.getenv("BUILD_ID") + "/SC_" + vScenarioN + "_" + dateString + ".png";
            TakesScreenshot scrShot = ((TakesScreenshot) Constants.driver);
            File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
            File DestFile = new File(fileWithPath);
            FileUtils.copyFile(SrcFile, DestFile);
            //Reporter.addScreenCaptureFromPath(fileWithPath);

        } else if (Constants.CONFIG.getProperty("Headless").equalsIgnoreCase("False")) {
            String fileWithPath = System.getProperty("user.dir") + "\\Screenshot\\SC" + "_" + vScenarioN + "_" + dateString + ".png";
            Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(Constants.driver);
            ImageIO.write(screenshot.getImage(), "PNG", new File(fileWithPath));
            Reporter.addScreenCaptureFromPath(fileWithPath);
        }
    }
}

