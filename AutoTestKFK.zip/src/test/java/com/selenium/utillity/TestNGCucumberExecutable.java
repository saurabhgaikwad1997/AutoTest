//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.selenium.utillity;

import com.service.utillity.ReusableMethod;
import cucumber.api.java.Before;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestNGCucumberExecutable {

    private TestNGCucumberRunner testNGCucumberRunner;


    public TestNGCucumberExecutable() {
    }

    @BeforeClass(
            alwaysRun = true
    )
    public void setUpClass() throws Exception {
        this.testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String dateString = format.format(new Date());
        String fileWithPath = System.getProperty("user.dir") + "\\Screenshot\\";
        String archiveScreenshotPath = System.getProperty("user.dir") + "\\Archive Screenshots\\" + "\\Screenshot_" + dateString;
        File destDir = new File(archiveScreenshotPath);
        File file = new File(fileWithPath);
        if (file.isDirectory()) {
            String[] files = file.list();
            if (files.length != 0) {
                FileUtils.copyDirectory(file, destDir);
                FileUtils.cleanDirectory(new File(fileWithPath));
            }
        }
    }

    @Test(
            groups = {"cucumber"},
            description = "Runs Cucumber Feature",
            dataProvider = "features"
    )
    public void feature(CucumberFeatureWrapper cucumberFeature) throws IOException {
        this.testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
    }

    @DataProvider
    public Object[][] features() {
        return this.testNGCucumberRunner.provideFeatures();
    }

    @AfterClass(
            alwaysRun = true
    )
    public void tearDownClass() throws Exception {
        ReusableMethod.pause(3);
        if(Constants.driver != null) {
            Constants.driver.close();
            Constants.driver.quit();
        }
        this.testNGCucumberRunner.finish();
    }
}
