package com.selenium.utillity.drivers;

import com.selenium.utillity.Constants;
import com.selenium.utillity.OSType;
import com.selenium.utillity.WebDriverManagerCustom;
import com.utility.LogCapture;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.util.HashMap;
import java.util.Map;

import static com.selenium.utillity.Constants.OnTheFlyValue;
import static com.selenium.utillity.Constants.downloadFilesPath;

public class ChromeDriverManager extends WebDriverManagerCustom {
    private WebDriver driver;
    private OSType osType;

    public ChromeDriverManager(OSType osType) {
        this.osType = osType;
    }

    @Override
    public WebDriver getDriver(String object) {
        if (driver == null) {
            setupDriver(object);
        }
        return driver;
    }

    @Override
    public void setupDriver(String object) {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        // Add the additional options
        options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
        options.addArguments("--no-sandbox"); // Bypass OS security model
        // Common preferences
        Map<String, Object> prefsMap = new HashMap<>();
        prefsMap.put("profile.default_content_settings.popups", 0);
        prefsMap.put("download.default_directory", downloadFilesPath);
        /*String lang = OnTheFlyValue.getProperty("BrowserLanguage");
        if (lang.length() != 0 || !lang.equals("")) {
            prefsMap.put("intl.accept_languages", lang);
            LogCapture.info("Clearing the languages in dynamic config");
            ReusableMethod.updateConfig("BrowserLanguage", "");
            LogCapture.info("Successfully cleared the languages in dynamic config");
        }*/
        options.setExperimentalOption("prefs", prefsMap);

        switch (osType) {
            case WINDOWS:
                setupWindowsOptions(options, object);
                break;
            case LINUX:
                setupLinuxOptions(options, object);
                break;
            case MAC:
                setupMacOptions(options, object);
                break;
            default:
                throw new UnsupportedOperationException("Unsupported operating system");
        }

        driver = new ChromeDriver(options);
        Constants.driver = driver; // Initializing Constants.driver with the ChromeDriver instance
    }

    private void setupWindowsOptions(ChromeOptions options, String object) {
        // Set options specific to Windows
        if (object.equalsIgnoreCase("Mobile") || object.equalsIgnoreCase("Tablet") || object.equalsIgnoreCase("Desktop")) {
            Map<String, Object> deviceMetrics = new HashMap<>();
            Map<String, Object> mobileEmulation = new HashMap<>();
            if (object.equalsIgnoreCase("Mobile")) {
                deviceMetrics.put("width", 375);
                deviceMetrics.put("height", 875);
            } else if (object.equalsIgnoreCase("Tablet")) {
                deviceMetrics.put("width", 1194);
                deviceMetrics.put("height", 990);
            } else if (object.equalsIgnoreCase("Desktop")) {
                deviceMetrics.put("width", 1920);
                deviceMetrics.put("height", 1080);
            }
            mobileEmulation.put("deviceMetrics", deviceMetrics);
            options.setExperimentalOption("mobileEmulation", mobileEmulation);
            options.addArguments("start-maximized");
        } else if (object.equalsIgnoreCase("")) {
            options.addArguments("start-maximized");
        }
    }

    private void setupLinuxOptions(ChromeOptions options, String object) {
        // Set options specific to Linux
        options.setHeadless(true);
        options.addArguments("--disable-gpu");
        options.addArguments("--disable-extensions");
        options.setExperimentalOption("useAutomationExtension", false);
        options.addArguments("--proxy-server='direct://'");
        options.addArguments("--proxy-bypass-list=*");
        options.addArguments("--start-maximized");
        options.addArguments("--headless");
        options.addArguments("--whitelisted-ips");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--no-sandbox");
        options.addArguments("--remote-allow-origins=*");
        if (object.equalsIgnoreCase("SalesForce")) {
            options.addArguments("--window-size=1536,753");
        } else {
            options.addArguments("--window-size=1920,1080");
        }
    }

    private void setupMacOptions(ChromeOptions options, String object) {
        // Set options specific to Mac
        if (object.equalsIgnoreCase("Mobile") || object.equalsIgnoreCase("Tablet") || object.equalsIgnoreCase("Desktop")) {
            options.addArguments("start-maximized");
        } else if (object.equalsIgnoreCase("")) {
            options.addArguments("start-maximized");
        }
    }
}
