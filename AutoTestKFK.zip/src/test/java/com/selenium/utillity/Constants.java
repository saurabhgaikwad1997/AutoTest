package com.selenium.utillity;

import com.google.common.base.Stopwatch;
import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import io.restassured.path.json.JsonPath;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.w3c.dom.Document;

import java.io.File;
import java.util.*;

public class Constants {
    public static String BIC ;
    public static String VIEW;
    public static String paymentLifeCycleID;
    public static String MSL_ID;
    public static Map<String, String> MessageInIdMap = new HashMap<>();
    public static Map<String, String> KafkaMsg =new HashMap<>();
    public static Properties KafkaUI;
    public static Map<String, String> kafkaExpectedKeyValues = null;
    public static String EODMSL_ID ;
    public static Reusables key;
    public static WebDriver driver;
    public static String KEYWORD_PASS = "PASS";
    public static String KEYWORD_FAIL = "FAIL";
    public static Properties CONFIG;
    public static String JenkinsBrowser = System.getProperty("jenkinsBrowser");
    public static Properties loginPageOR;
    public static Properties DashboardOR;
    public static Properties NewRateAlertOR;
    public static String RANDOM_VALUE = "";
    public static LogCapture logs;
    public static Properties TopupWalletOR;
    public static Properties MakeTransferOR;
    public static Properties TitanLoginOR;
    public static Properties CreateFxTicketOR;
    public static Properties AtlasloginOR;
    public static Properties AtlasDashboardOR;
    public static Properties AtlasPaymentInOR;
    public static Properties AtlasPaymentOutOR;
    public static Properties SFLoginOR;
    public static Properties LeadGenerationOR;
    public static Properties ProfileManagementOR;
    public static Properties SignUp;
    public static Properties HelpOR;
    public static Properties PaymentTrackingOR;
    public static String PTData;
    public static Properties CalypsologinPageOR;
    public static Properties FrenchDashboardOR;
    public static Properties OccupationGenericOR;
    public static Properties AtlasRegistrationOR;

    public static Properties TitanDashboardOR;
    public static Properties TitanCustomersOR;
    public static Properties TitanConflictsOR;
    public static Properties TitanQueuesOR;
    public static Properties TitanPaymentInOR;
    public static Properties TitanPaymentOutOR;
    public static Properties TitanPayeeOR;
    public static Properties TitanFXTicketsOR;
    public static Properties TitanInstructionsOR;
    public static Properties TitanTreasuryOR;
    public static Properties TitanReportsOR;
    public static Properties TitanCDSAPhase1OR;

    public static Properties PFXOR;
    public static Properties OnTheFlyValue;

    public static String parentDirPath = System.getProperty("user.dir");
    public static String downloadFilesPath = parentDirPath + File.separator + "Downloads" + File.separator;

    //-----------------Jenkins-Grafana checkpoint below-------------------------------
    public static String uniqueAlphaNumericJobID = "";
    public static long stopwatchTime = 0L;
    public static Stopwatch stopwatch=null;
    public static String grafanaApplicationName="Titan";
    public static java.sql.Connection Connection;
    //-----------------Jenkins-Grafana checkpoint above-------------------------------

    //------------------------- API Values--------------------------------------------
    public static HashMap<String, String> DynamicValue = new HashMap<>();
    public static ReusableMethod APIkey;
    public static String apiBodyValue;
    public static String TCCaseID = "";
    public static String SHEET_NAME = "";
    public static String RESPONSE = "";
    public static String ACCESS_TOKEN = "";

    public static String apiBody;

    public static String RegressionExecutionStatus = "TRUE";

    public static String Execution = "";
    public static String ApplicationName = "";
    public static String tcIDs = "";
    public static String scenrioName = "";
    public static String org_code = "";
    public static String legal_entity = "";
    public static String partner_tag = "";

    public static String excelExecutionStatus = "";

    public static Integer rowCount;
    public static XSSFWorkbook workbookRead=null;
    public static XSSFSheet sheetRead=null;

    public static Integer counter=0;
    public static String connectionUrl;
    public static String dBUsername;
    public static String dbPassword;
    public static Properties SQLQUERIES;
    public static Properties dbconfig;
    public static String RandomUUID = "";
    public static String UniquePaymentLifeCycleId = "";
    public static String RandomPtTokenID = "";
    public static String Bank;
    public static String FileType;
    public static String NewFileName;
    public static String currentDate;
    public static String OldAccountNumber;
    public static String dateReplace;
    public static String oldAmountStarting;
    public static String nameDate;
    public static String newAmount;
    public static Document doc1;
    public static String PaymentInAmount = "";
    public static String MessageInId;
    public static String RemitterNameID;
    public static String StatementLineID;
    public static String ConfirmationID;
    public static String IntradayStatementID;
    public static String IntradayStatementLineID;
    public static double InAmount=0.00;
    public static String BankPaymentEntriesID;

    public static String JsonMessageActual;
    public static String IndradayMSL_ID;
    public static String InstructionNumber;
    public static String CustomerPaymentInID;
    public static String InstructionNumber1;
    public static String CustomerInstructionID;
    public static String InstructionIdReference;
    public static String KafkaMessageCDID;
    public static String LimitOrderID;
    public static String CustomerPaymentOutID;
    public static String FullInstructionNumber;
    public static String InstructionReferenceNumber;
    public static String vBrowserName;
    public static String BankPaymentEntries_ID;
    public static String achMandateId;
    public static String external_reference_id;
    public static String FundType;
    public static String StatusEnum;
    public static String Currency_code;
    public static String bank_name;
    public static String Name;
    public static String hyperion_bank_account_reference_id;
    public static String Address;
    public static String JenkinsEnvironment = Objects.isNull(System.getProperty("jenkinsEnvironment")) ? null : System.getProperty("jenkinsEnvironment").toUpperCase();

    public static List<Map<String, String>> testDataRows;
    public static String ExcelFileName;


//    --Banking

    public static String PDQ_ID;
    public static String ROF_ID = "";
    public static Properties B2BOR;
    public static Properties BankingOR;
    public static Properties RFQOR;
    public static Properties PaymentMonitoringOR;
    public static Properties MessageOR;
    public static Properties QueryManagementOR;
    public static Properties FXConfirmationOR;
    public static String PaymentRef;
    public static String CopyofMT;
    public static JsonPath ExpectedJsonPath;
    public static Map<String, String> ExpectedKafkaKeyValues;
    public static Properties DBCONFIG;
//    public static FileRename filerename;
    public static File latestFile;


    public static String PASS = "PASSED";
    public static String FAIL = "FAILED";
    public static String UserStory = "";
    public static String ScenarioOutline="";
    public static String status="";
    public static String TransactionReferenceNumber="";
    public static String Amount = "";
    public static String vPaymentRef_no;
    public static String PendingB2BID;
    public static String DealID;
    public static String Legal_Entity;
    public static String CutOffTimeEnd;
    public static Set<String> testRemitterAccountName;
    public static Set<String> testRemitterAccountNumber;
    public static HashMap<String, List<String>> ActualRemitterMap;
    public static String filePath;
    //    public static String JenkinsBrowser = System.getProperty("jenkinsBrowser");
    public static String BankName = "";
    //    public static String SHEET_NAME = "";
    //    public static XSSFWorkbook workbookRead=null;
//    public static XSSFSheet sheetRead=null;
//    public static Integer counter=0;

    public static Properties SQL_Queries;

    public static String camtFile;
    public static File Rename;
    public static String QueryIdValue;
    public static String NewName;
    public static String profileName;
    public static String ID;
    public static String NewAccountNumber;

    public static String messageInQuery;
    public static String CreditAdviceID;
    public static String ROFQeueueID;
    public static String ROFQueueAccountNumber;
    public static String ROFQueueAmount;
    public static String ROFQueueCurrency;
    public static String ROFPaymentReference;
    public static String Transaction_Reference;
    public static String Transaction_Reference_MessageOut;
    public static String Routing_Rule;
    public static String PaymentStatusIs;


    public static String message_No;
    public static List<Map<String, String>> AuditTable = new ArrayList<>();
    public static String currentDate1;
    public static String Olddate;
    public static String idValue;
    public static String globalreferenceid;
    //------------------------- API Values--------------------------------------------

    public static String TradeAccountNumber="";
    public static String TradeContactID="";
    public static Properties KafkaPropertiesOR;
    public static String FundsInTransactionID="";
    public static String TradePaymentID="";
}
