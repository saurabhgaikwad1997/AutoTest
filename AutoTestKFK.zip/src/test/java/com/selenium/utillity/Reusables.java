
/*ClassName: Resuables.java
Date: 17/April/2020
Author: Saurabh Gadgil
Purpose of class: To implement generic methods, all resuable using Xpath and selenium for robust framework.*/

package com.selenium.utillity;

import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import java.sql.Connection;
import java.sql.SQLException;


import io.restassured.path.json.JsonPath;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.io.*;

import java.io.File;
import java.io.IOException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;


import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import static java.lang.String.format;
import static java.lang.String.valueOf;


public class Reusables {

    public String actual;
    public String emailID;
    public static String Email;
    public String ScreenshotFlag;
    public String PDFoutput;
    String downloadFilesPath = System.getProperty("user.dir") + "\\src\\main\\resources\\Downloads";

    public static boolean openBrowser(String object, String data) throws Exception {
        try {
            String vExpected = "Chrome, Firefox, Edge, Safari";
            String vActual = data;

            if (data.isEmpty()) {
                vActual = "No data found";
            }

            //System.out.println("expected value->>>>" + vExpected);
            System.out.println("data value->>>>" + vActual);

            // Identify the operating system
            String oSName = System.getProperty("os.name").toUpperCase();
            OSType osType;
            if (oSName.contains("WIN")) {
                osType = OSType.WINDOWS;
            } else if (oSName.contains("MAC")) {
                osType = OSType.MAC;
            } else if (oSName.contains("NUX")) {
                osType = OSType.LINUX;
            } else {
                throw new UnsupportedOperationException("Unsupported operating system: " + oSName);
            }

            // Identify the driver type
            DriverType driverType;
            switch (data.toLowerCase()) {
                case "chrome":
                    driverType = DriverType.CHROME;
                    break;
                case "firefox":
                    driverType = DriverType.FIREFOX;
                    break;
                case "edge":
                    driverType = DriverType.EDGE;
                    break;
                case "safari":
                    driverType = DriverType.SAFARI;
                    break;
                default:
                    throw new IllegalArgumentException("Invalid browser type: " + data);
            }

            // Get the driver manager
            WebDriverManagerCustom driverManager = DriverFactory.getManager(driverType, osType);

            // Setup the driver
            driverManager.setupDriver(object);

            // Get the driver
            WebDriver driver = driverManager.getDriver(object);

            // From here onwards, you can interact with the WebDriver instance (e.g., navigate to a URL, perform operations on the page, etc.)

            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            // Your log capturing and snapshot taking logic here
            return false;
        }
    }



   /* public boolean openBrowser(String object, String data) throws Exception {
        try {
            String oSName = System.getProperty("os.name");
            if (data.equalsIgnoreCase("Chrome")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/windows/Chrome/chromedriver.exe");
                    WebDriverManager.chromedriver().setup();
                    ChromeOptions options = new ChromeOptions();
                    options.addArguments("--remote-allow-origins=*");
                    //System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver_old.exe");
                    Constants.driver = new ChromeDriver(options);
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((ChromeDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                } else {
                    //System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/linux/Chrome/chromedriver");
                    //System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
                    WebDriverManager.chromedriver().setup();
                    ChromeOptions options = new ChromeOptions();
                    options.setHeadless(true);
                    options.addArguments("--window-size=1920,1080");
                    options.addArguments("--disable-gpu");
                    options.addArguments("--disable-extensions");
                    options.setExperimentalOption("useAutomationExtension", false);
                    options.addArguments("--proxy-server='direct://'");
                    options.addArguments("--proxy-bypass-list=*");
                    options.addArguments("--start-maximized");
                    options.addArguments("--headless");
                    options.addArguments("--whitelisted-ips");
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    options.addArguments("--remote-allow-origins=*");
                    Constants.driver = new ChromeDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                    //options.addArguments("--no-sandbox");
                }
            } else if (data.equalsIgnoreCase("Firefox")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/windows/Firefox/geckodriver.exe");
                    WebDriverManager.firefoxdriver().setup();
                    File pathBinary = new File(System.getProperty("user.home") + "/AppData/Local/Mozilla Firefox/firefox.exe");
                    FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
                    //DesiredCapabilities desired = DesiredCapabilities.firefox();
                    FirefoxOptions options = new FirefoxOptions();
                    options.setBinary(firefoxBinary);
                    //desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
                    WebDriverManager.firefoxdriver().setup();
                    Constants.driver = new FirefoxDriver(options);
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((FirefoxDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                } else {
                    FirefoxBinary firefoxBinary = new FirefoxBinary();
                    firefoxBinary.addCommandLineOptions("--headless");
                    WebDriverManager.firefoxdriver().setup();
                    //System.setProperty("webdriver.gecko.driver", "/usr/local/bin/geckodriver");
                    FirefoxOptions options = new FirefoxOptions();
                    options.addArguments("--no-sandbox");
                    options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
                    options.setBinary(firefoxBinary);
                    Constants.driver = new FirefoxDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                }
            } else if (data.equalsIgnoreCase("Edge")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/windows/Edge/msedgedriver.exe");
                    WebDriverManager.edgedriver().setup();
                    Constants.driver = new EdgeDriver();
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((EdgeDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                    //takeSnapShot();
                    takeSnapShot();
                } else {
//                    System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/linux/Edge/msedgedriver");
                    System.setProperty("webdriver.edge.driver", "/usr/bin/edgedriver");
                    //WebDriverManager.edgedriver().setup();
                    EdgeOptions options = new EdgeOptions();
                    options.setHeadless(true);
                    options.addArguments("--window-size=1920,1080");
                    options.addArguments("--disable-gpu");
                    options.addArguments("--disable-extensions");
                    options.setExperimentalOption("useAutomationExtension", false);
                    options.addArguments("--proxy-server='direct://'");
                    options.addArguments("--proxy-bypass-list=*");
                    options.addArguments("--start-maximized");
                    options.addArguments("--headless");
                    options.addArguments("--whitelisted-ips");
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    Constants.driver = new EdgeDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                    //options.addArguments("--no-sandbox");
                }

            }
            takeSnapShot();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found...");
            takeSnapShot();
            return false;
        }
    }*/


    public String closeBrowser(String object, String data) throws Exception {
        try {
            Constants.driver.quit();
        } catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found..." + ex);

            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;

    }

    public static String navigate(String object, String data) throws Exception {
        try {
            Constants.driver.navigate().to(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";

        }
        return KEYWORD_PASS;
    }

    public String writeInInput(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).sendKeys(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String click(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("actual value->>>>" + actual);
            }
            String expected = data;
            System.out.println("actual value ->>>>" + actual);
            System.out.println("data value   ->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String verifyInnerText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getAttribute("innerText");
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String pause(String object, String data) throws NumberFormatException, InterruptedException {
        long time = (long) Double.parseDouble(object);
        Thread.sleep(time * 1000L);
        return KEYWORD_PASS;

    }


    public String selectList(String object, String data) throws Exception {
        try {
            int attempt = 0;
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            if (!data.equals(Constants.RANDOM_VALUE)) {
                objSelect.selectByVisibleText(data);
                takeSnapShot();
            } else {
                WebElement droplist = Constants.driver.findElement(By.xpath(object));
                List<WebElement> droplist_contents = droplist.findElements(By.tagName("option"));
                Random num = new Random();
                int index = num.nextInt(droplist_contents.size());
                String selectedVal = droplist_contents.get(index).getText();
                objSelect.selectByVisibleText(selectedVal);
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "---Could not select from the List---" + e.getMessage();

        }
        return KEYWORD_PASS;
    }

    /*public String sendkeyboardStroke(String object, String data) throws Exception {
        //valid values for data = space,enter,up,tab,down,left,right
        try {
            Robot robot = new Robot();
            if (!object.equals("")) {
                WebElement browseBtn = Constants.driver.findElement(By.xpath(object));
                browseBtn.click();
                Thread.sleep(1000);
            }
            if (data.equals("space")) {
                robot.keyPress(KeyEvent.VK_SPACE);
                robot.keyRelease(KeyEvent.VK_SPACE);
            } else if (data.equals("enter")) {
                robot.keyPress(KeyEvent.VK_ENTER);
                robot.keyRelease(KeyEvent.VK_ENTER);
            } else if (data.equals("tab")) {
                robot.keyPress(KeyEvent.VK_TAB);
                robot.keyRelease(KeyEvent.VK_TAB);
            } else if (data.equals("down")) {
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Thread.sleep(1000);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "....unable to find element...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }*/

    public String getReportConfigPath() {
        String reportConfigPath = Constants.CONFIG.getProperty("reportConfigPath");
        if (reportConfigPath != null) return reportConfigPath;
        else
            throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
    }

    public String exist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String navigateSubMenu(String object, String data) throws Exception {
        try {
            WebElement ele = Constants.driver.findElement(By.xpath(object));
            //WebElement ele = driver.findElement(By.xpath("element_xpath"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", ele);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String AltasRejectDropDown(String object, String data) throws Exception {
        try {
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            //System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 0; i < dropdown_list.size(); i++) {
                //System.out.println(dropdown_list.get(i).getText());
                if (dropdown_list.get(i).getText().contains(data)) {
                    for (int j = 1; j < 10000; j++) {
                        String vdata = Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).getText();
                        if (vdata.equals(data)) {
                            Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).click();
                            break;
                        }
                    }
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }

 /*   public void ReadCookies() {
        // create file named Cookies to store Login Information
        File file = new File("C:\\POC2\\CucumberSeleniumProject\\Cookies.data");
        try {
            // Delete old file if exists
            file.delete();
            file.createNewFile();
            FileWriter fileWrite = new FileWriter(file);
            BufferedWriter Bwrite = new BufferedWriter(fileWrite);
            // loop for getting the cookie information

            // loop for getting the cookie information
            for (Cookie ck : Constants.driver.manage().getCookies()) {
                Bwrite.write((ck.getName() + ";" + ck.getValue() + ";" + ck.getDomain() + ";" + ck.getPath() + ";" + ck.getExpiry() + ";" + ck.isSecure()));
                Bwrite.newLine();
            }
            Bwrite.close();
            fileWrite.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void WriteCookies() {
        try {

            File file = new File("C:\\POC2\\CucumberSeleniumProject\\Cookies.data");
            FileReader fileReader = new FileReader(file);
            BufferedReader Buffreader = new BufferedReader(fileReader);
            String strline;
            while ((strline = Buffreader.readLine()) != null) {
                StringTokenizer token = new StringTokenizer(strline, ";");
                while (token.hasMoreTokens()) {
                    String name = token.nextToken();
                    String value = token.nextToken();
                    String domain = token.nextToken();
                    String path = token.nextToken();
                    Date expiry = null;

                    String val;
                    if (!(val = token.nextToken()).equals("null")) {
                        expiry = new Date(val);
                    }
                    Boolean isSecure = new Boolean(token.nextToken()).
                            booleanValue();
                    Cookie ck = new Cookie(name, value, domain, path, expiry, isSecure);
                    System.out.println(ck);
                    Constants.driver.manage().addCookie(ck); // This will add the stored cookie to your current session
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }*/

    public String isAlertPresent() {
        try {
            Alert alert = Constants.driver.switchTo().alert();
            System.out.println("Alert Message" + alert.getText());
            alert.accept();
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String clearText(String object) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).clear();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String SfLeadDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("2", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String VerifyTitle(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.getTitle();
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }
    //
    //        w.until(ExpectedConditions.visibilityOfAllElements( By.xpath(Constants.CreateFxTicketOR.getProperty("CloseFxSlipButton"))));

    public String VisibleConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(120));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String KeyboardAction(String object, String data) throws Exception {
        try {
            if (data.equalsIgnoreCase("enter")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("tab")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.TAB);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("space")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.SPACE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("downArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("selectall")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.chord(Keys.CONTROL, "a"));
                takeSnapShot();
            }else if (data.equalsIgnoreCase("upArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_UP);
                takeSnapShot();
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String SelectRecipient(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'Select')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String RecipientTransfer(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Transfer')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String RecipientPay(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Pay')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyElementProperties(String object, String data) throws Exception {
        try {
            if (data.contains("disabled")) {
                String buttonDisabled = Constants.driver.findElement(By.xpath(object)).getAttribute("disabled");
                if (buttonDisabled != null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not Disabled";
                }
            } else if (data.contains("enabled")) {
                String buttonEnabled = Constants.driver.findElement(By.xpath(object)).getAttribute("disabled");
                if (buttonEnabled == null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not Enabled";
                }

            } else if (data.contains("visible")) {
                if (Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Displayed";
                }
            } else if (data.contains("unselected")) {
                if (!Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("selected")) {
                if (Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("readonly")) {
                String readonly = Constants.driver.findElement(By.xpath(object)).getAttribute("readonly");
                if (readonly != null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not readonly";
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + " -  Could not find element";

        }
        return KEYWORD_PASS;
    }

    public String notexist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_PASS;
        }
        return KEYWORD_FAIL + "object exist ";
    }

    public String uniqueEmailID(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            String emailID = "AutoTestUser" + userName + "@gmail.com";
            LogCapture.info("emailID start with xyz is " + ": " + emailID);
            //System.out.println("Result......" + emailID);
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(1000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(emailID);
            // Constants.driver.findElement(By.xpath(object)).sendKeys("autotestuser213440261@gmail.com");
            Email = Constants.driver.findElement(By.xpath(object)).getText();
            System.out.println("AutoTestUser Email ID" + Email);
            Thread.sleep(1000);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String uniqueEmailAddress(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            emailID = "xyz" + userName + "@gmail.com";

            LogCapture.info("emailID is " + ": " + emailID);


        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return emailID;
    }

    public String ClickEachElementOfFrame(String object, String data) throws Exception {
        try {
            //    List<WebElement> Elements = driver.findElements(By.cssSelector(object));
            List<WebElement> Elements = Constants.driver.findElements(By.xpath(object));
            ListIterator<WebElement> ListOfElements = Elements.listIterator();
            while (ListOfElements.hasNext()) {
                WebElement elem = ListOfElements.next();
                // do something with elem
                elem.click();
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String MouseFunctions(String object, String data) throws Exception {
        try {
            WebElement Element = driver.findElement(By.xpath(object));
            Actions action = new Actions(Constants.driver);
            if (data.equalsIgnoreCase("clickAndHold")) {
                action.moveToElement(Element).build().perform();
                action.clickAndHold(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("ReleaseMouseClick")) {
                action.moveToElement(Element).build().perform();
                action.release(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("DoubleClick")) {
                action.doubleClick(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("MoveToElement")) {
                action.moveToElement(Element);
                action.perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("click")) {
                action.click(Element).build().perform();
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to clickAndHold...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    public String Mouse_Events(String Object, String data) throws Exception {
        try {
            Actions build = new Actions(Constants.driver);
            build.moveToElement(Constants.driver.findElement(By.xpath(Object))).moveByOffset(11, 11).click().build().perform();
        } catch (Exception e) {
            takeSnapShot();
            return
                    KEYWORD_FAIL;
        }
        return
                KEYWORD_PASS;
    }

    public String Enter_OTP(String object, String data) throws Exception {
        try {
            List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
            for (WebElement input : inputs) {
                input.clear();
                input.sendKeys(data);
                break;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }
//Xpath  Used for Entering OTP  EnterPinTextBox= //input[@class="pin-number"]
// input is the tag name of all the all the textfields which are in one frameand we have used it to iterate into the Loop

    public String ClickIfEnable(String object, String data) throws Exception {
        try {
            int attempts = 0;
            int maxAttempts = 10;
            Constants.key.VisibleConditionWait(object, "");
//        boolean buttonDisabled = false;
            while (attempts++ <= maxAttempts) {
                if (Constants.driver.findElement(By.xpath(object)).isEnabled()) {
                    Constants.driver.findElement(By.xpath(object)).click();
                    break;
                } else {
                    Thread.sleep(500);
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }

    public String writeInInputObO(String object, String data) throws Exception {
        try {
            String val = data;
            WebElement element = Constants.driver.findElement(By.xpath(object));
            element.clear();
            for (int i = 0; i < val.length(); i++) {
                char c = val.charAt(i);
                String s = new StringBuilder().append(c).toString();
                element.sendKeys(s);
                Thread.sleep(2000);
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write one by one " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public static String[] generateRandomWords(int numberOfWords) {
        String[] randomStrings = new String[numberOfWords];
        Random random = new Random();
        for (int i = 0; i < numberOfWords; i++) {
            char[] word = new char[random.nextInt(8) + 3]; // words of length 3 through 10. (1 and 2 letter words are boring.)
            for (int j = 0; j < word.length; j++) {
                word[j] = (char) ('a' + random.nextInt(26));
            }
            randomStrings[i] = new String(word);
        }
        return randomStrings;
    }

    public String randomWordGenerator(String object, int numberOfWords) throws Exception {
        try {
            String[] randomStrings = new String[numberOfWords];
            Random random = new Random();
            for (int i = 0; i < numberOfWords; i++) {
                char[] word = new char[random.nextInt(1) + 1]; // words of length 3 through 10. (1 and 2 letter words are boring.)
                for (int j = 0; j < word.length; j++) {
                    word[j] = (char) ('a' + random.nextInt(26));
                }
                randomStrings[i] = new String(word);

            }
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(2000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(randomStrings);
            System.out.println("Random string generated: " + randomStrings);

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String DeleteRecipient(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'x')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String selectPTRecord(String object, String innerObject, String data) throws Exception {
        try {
            List<WebElement> listElements = Constants.driver.findElements(By.xpath(object));
            for (int i = 0; i < listElements.size(); i++) {
                if (i % 5 == 0) {
                    click(Constants.PaymentTrackingOR.getProperty("ShowMoreButton"), "");
                }
                WebElement element = listElements.get(i);
                element.click();
                Thread.sleep(2000);
                try {
                    WebElement referenceElement = element.findElement(By.xpath(innerObject));
                    if (referenceElement != null) {
                        referenceElement.click();
                        LogCapture.info("Record displayed on PT dashboard =" + referenceElement.getText());
                        takeSnapShot();
                        return KEYWORD_PASS;
                    }
                } catch (Exception e) {
                    LogCapture.info(e.getMessage());
                }
            }
            return KEYWORD_FAIL + "Record is not displayed on PT dashboard";

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
    }

    public String LanguageDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("3", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String ConvertStringToCase(String word, String strcase) throws Exception {
        try {
            if (strcase.equalsIgnoreCase("lower")) {
                word = word.toLowerCase();
            } else if (strcase.equalsIgnoreCase("upper")) {
                word = word.toUpperCase();
            }
        } catch (Exception e) {
            LogCapture.info(e.getMessage());
        }
        return word;
    }

    /**
     * to get the text
     *
     * @return text from an element
     * @author Avleen
     * @since 2021-05-13
     */
    public String getText(String object) throws Exception {
        String actual = Constants.driver.findElement(By.xpath(object)).getText();
        return actual;
    }

    public String getText(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("Actual Length:->" + actual.length());
            }
//            LogCapture.info("Actual:->" + actual);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return actual;

    }

    public String ChatFileOperation(String operation, String data) throws IOException {
        try {
            String path = System.getProperty("user.home");

            path = path + "/Downloads";
            LogCapture.info(path);
            File file = new File(path);
            File files[] = file.listFiles();
            String filename, filename1;
            for (File f : files) {
                if (f.getName().contains(data)) {
                    filename = f.getName();
                    System.out.println(f.getName());
                    if (operation.equalsIgnoreCase("delete")) {
                        f.delete();
                        LogCapture.info(f.getName() + " file got deleted successfully");
                    } else if (operation.equalsIgnoreCase("exist")) {
                        if (filename.equalsIgnoreCase(data + ".txt")) {
                            LogCapture.info(f.getName() + " file downloaded successfully");
                        }
                    } else if (operation.equalsIgnoreCase("verifycontent")) {
                        FileInputStream fstream1 = new FileInputStream(path + "/" + data + ".txt");

                        DataInputStream in1 = new DataInputStream(fstream1);
                        //DataInputStream in2= new DataInputStream(fstream2);

                        BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
                        //BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));

                        String strLine1;
                        String strLine2 = "How can I help you?";


                        while ((strLine1 = br1.readLine()) != null) {
                            if (strLine1.contains(strLine2)) {
                                LogCapture.info(f.getName() + " file downloaded has chat conversation");
                                LogCapture.info(strLine1 + " file downloaded has content");
                                LogCapture.info(f.getName() + " file downloaded content has been compare with " + strLine2);

                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return KEYWORD_FAIL;

        }
        return KEYWORD_PASS;
    }


/*    HtmlUnitDriver driver = new HtmlUnitDriver(BrowserVersion.CHROME ,true);
driver.get("your web URL");
    WebDriverWait wait = new WebDriverWait(driver, 30);
wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("ppLoginForm"))));
wait.until(ExpectedConditions.elementToBeClickable(By.name("j_username")));*/


    public String navigateNewTab(String object, String data) throws Exception {
        try {
            String currentHandle = Constants.driver.getWindowHandle();

            ((JavascriptExecutor) Constants.driver).executeScript("window.open()");


            Set<String> handles = Constants.driver.getWindowHandles();
            for (String actual : handles) {

                if (!actual.equalsIgnoreCase(currentHandle)) {
                    //switching to the opened tab
                    Constants.driver.switchTo().window(actual);

                    //opening the URL saved.
                    Constants.driver.navigate().to(data);
                }
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";
        }
        return KEYWORD_PASS;
    }

    public String navigateTab(String Object, int data) throws Exception {
        try {
            ArrayList<String> tabs = new ArrayList<String>(Constants.driver.getWindowHandles());
            Constants.driver.switchTo().window(tabs.get(data));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String selectOrganisationBussinessPartner(String object, String data) throws Exception {
        WebElement element = null;
        String vObjOrganisationBussinessPartner = "";
        try {
            for (int i = 0; i <= 100; i++) {

                if (object.equals("Organisation")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisations-" + i + "']";
                } else if (object.equals("Business Partner")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisation-business-partner-" + i + "']";
                }
                //LogCapture.info(vObjOrganisation);

                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisationBussinessPartner, ""));
                String abc = Constants.key.getText(vObjOrganisationBussinessPartner, "");
                //LogCapture.info(abc);

                if (abc.equalsIgnoreCase(data)) {
                    // LogCapture.info("inside");
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "MoveToElement"));
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "click"));
                    //element.findElement(By.xpath(vObjOrganisation)).click();
                    takeSnapShot();
                    break;
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable select" + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyOrganisationIntableCustomer(String object, String data, String column) throws Exception {
        int a = 0, b = 0;
        try {
            List<WebElement> itemsfiler = driver.findElements(By.xpath("//tbody[@id='accountSummaryTableBody']/tr"));
            int trnofilter = itemsfiler.size() + 1;
            //LogCapture.info("Total rows" +trnofilter);
            for (int s = 2; s < trnofilter; s++) {
                String organization = "//tbody[@id='accountSummaryTableBody']/tr[" + s + "]/td[" + column + "]/a[1]";
                String rowdata = Constants.driver.findElement(By.xpath(organization)).getText();
                //LogCapture.info("organization" +rowdata);
                if (rowdata.equals(data)) {
                    a = a + 1;
                } else {
                    b = b + 1;
                }
            }
            //LogCapture.info("Number of match rows->" +a);
            //LogCapture.info("Number of unmatch rows->" +b);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "something went wrong while fetching data " + e.getMessage();
        }
        if (b > 0) {
            return KEYWORD_FAIL;
        } else {
            return KEYWORD_PASS;
        }
    }

    public String scrollIntoViewElement(String object, String data) throws Exception {
        try {
            WebElement vObject = Constants.driver.findElement(By.xpath(object));
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView", vObject);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String ReadPDFFile(String object, String data) throws IOException {
        try {
            String fileName = "T" + System.currentTimeMillis();
            File sourceFile = new File(System.getProperty("user.dir") + "/Downloads/" + data);
            File newFile = new File(System.getProperty("user.dir") + "/Downloads/" + fileName + ".pdf");
            if (sourceFile.exists()) {
                LogCapture.info("File name is correct: " + sourceFile.getName());
            } else {
                LogCapture.info("File name is INCORRECT: " + sourceFile.getName());
                Assert.fail();
            }

            LogCapture.info("Creating copy of file..");
            newFile.createNewFile();
            FileUtils.copyFile(sourceFile, newFile);
            String url = "file:///" + downloadFilesPath + fileName + ".pdf";
            URL pdfUrl = new URL(url);
            InputStream in = pdfUrl.openStream();
            BufferedInputStream bf = new BufferedInputStream(in);
            PDDocument doc = PDDocument.load(bf);
            if (object.equalsIgnoreCase("PageCount")) {
                int numberOfPages = doc.getNumberOfPages();
                System.out.println("The total number of pages " + numberOfPages);
            } else if (object.equalsIgnoreCase("PageText")) {
                PDFTextStripper pdfStrip = new PDFTextStripper();
                String content = pdfStrip.getPageStart();
                System.out.println("Content of the page is" + content);
            }
            doc.close();
//            LogCapture.info("Source file getting deleted with file name: " + sourceFile.getName());
//            boolean DeletSourceFile=sourceFile.delete();
//            if(DeletSourceFile){
//                LogCapture.info("Source file deleted");
//            }
//            else{
//                LogCapture.info("Source file NOT deleted");
//                Assert.fail();
//            }
            return KEYWORD_PASS;
        } catch (IOException e) {
            e.printStackTrace();
            return KEYWORD_FAIL;
        }

    }

    public String defaultDownloadFilesOperations(String object, String data) {
        try {
            if (object.equalsIgnoreCase("deleteAllFiles")) {
                try {
                    LogCapture.info("All files deleted present in directory: " + downloadFilesPath);
                    FileUtils.cleanDirectory(new File(downloadFilesPath));
                } catch (IOException e) {
                }
            } else if (object.equalsIgnoreCase("deleteSelectedFile")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        dir_contents[i].delete();
                        LogCapture.info(data + " file deleted..");
                        LogCapture.info("Number of files got deleted: " + i);
                    }
                }
            } else if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        LogCapture.info(data + " file downloaded..");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String renameDownloadedFile(String object, String data) {
        try {
            String NewfileName = "T" + System.currentTimeMillis();
            File sourceFile = new File(System.getProperty("user.dir") + "/Downloads/" + data);
            File newFile = new File(System.getProperty("user.dir") + "/Downloads/" + NewfileName + ".pdf");
            if(sourceFile.exists()) {
                LogCapture.info("File exist with name: " + sourceFile.getName());
                LogCapture.info("Creating copy of file..");
                newFile.createNewFile();
                FileUtils.copyFile(sourceFile, newFile);
                newFile.isFile();
                LogCapture.info("Created copy of file with filename: " + newFile.getName());
            }else{
                LogCapture.info("File DOES NOT exist with name: " + data);
                Assert.fail();
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public boolean openBrowserWithDefaultDownloadDirectory(String object, String data) throws Exception {
//        try {
//            String oSName = System.getProperty("os.name");
//            if (data.equals("Chrome")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/windows/chromedriver.exe");
//                    //System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
//                    ChromeOptions options = new ChromeOptions();
//                    options.addArguments("--start-maximized");
//                    Map<String, Object> prefs = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    prefs.put("download.default_directory", downloadFilesPath);
//                    prefs.put("plugins.always_open_pdf_externally", true);
//                    prefs.put("download.directory_upgrade", true);
//                    prefs.put("download.prompt_for_download", false);
//
//                    HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    DesiredCapabilities cap = DesiredCapabilities.chrome();
//                    cap.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
//                    cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//                    cap.setCapability(ChromeOptions.CAPABILITY, options);
//
//
//                    driver = new ChromeDriver(cap);
//                    // Constants.driver.manage().window().maximize();
//                    takeSnapShot();
//                } else {
//                    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/linux/chromedriver");
//                    ChromeOptions options = new ChromeOptions();
//                    options.setHeadless(true);
//                    //options.addArguments("--window-size=1920,1080")  ;
//                    //options.addArguments("--disable-gpu");
//                    //options.addArguments("--headless --disable-gpu --screenshot "+ data)   ;
//                    options.addArguments("--disable-extensions");
//                    options.setExperimentalOption("useAutomationExtension", false);
//                    options.addArguments("--proxy-server='direct://'");
//                    options.addArguments("--proxy-bypass-list=*");
//                    //options.addArguments("--start-maximized");
//                    //options.addArguments("--headless");
//                    options.addArguments("--whitelisted-ips");
//                    options.addArguments("--disable-dev-shm-usage");
//                    options.addArguments("--no-sandbox");
//
//                    options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
//                    Map<String, Object> prefs = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    prefs.put("download.default_directory", downloadFilesPath);
//                    prefs.put("plugins.always_open_pdf_externally", true);
//                    prefs.put("download.directory_upgrade", true);
//                    prefs.put("download.prompt_for_download", false);
//
//                    HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    DesiredCapabilities cap = DesiredCapabilities.chrome();
//                    cap.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
//                    cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//                    cap.setCapability(ChromeOptions.CAPABILITY, options);
//
//                    //options.addArguments("window-size=1920,1080");
//                    // options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
//
//                    driver = new ChromeDriver(cap);
//                    driver.manage().window().maximize();
//                    takeSnapShot();
//                    //options.addArguments("--no-sandbox");
//                }
//            } else if (data.equals("FF")) {
//                System.setProperty("webdriver.gecko.driver", "C:\\WhiteLabelAutomation\\Drivers\\FireFox\\geckodriver.exe");
//                File pathBinary = new File("C:\\Users\\saurabh.gadgil\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
//                FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
//                DesiredCapabilities desired = DesiredCapabilities.firefox();
//                FirefoxOptions options = new FirefoxOptions();
//                desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
//                driver = new FirefoxDriver(options);
//                driver.manage().window().maximize();
//
//
//                /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//                Constants.driver = new FirefoxDriver();
//                Constants.driver.manage().window().maximize();*/
//            } else if (data.equalsIgnoreCase("FireFox")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//                    File pathBinary = new File(System.getProperty("user.home") + "/AppData/Local/Mozilla Firefox/firefox.exe");
//                    FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
//                    DesiredCapabilities desired = DesiredCapabilities.firefox();
//                    FirefoxOptions options = new FirefoxOptions();
//                    desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
//                    driver = new FirefoxDriver(options);
//                    driver.manage().window().maximize();
//    /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//    Constants.driver = new FirefoxDriver();
//    Constants.driver.manage().window().maximize();*/
//                } else {
//                    //Firefox linux connection here
//                }
//            } else if (data.equalsIgnoreCase("Edge")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/Edge/msedgedriver.exe");
//                    driver = new EdgeDriver();
//                    driver.manage().window().maximize();
//                    //takeSnapShot();
//                    takeSnapShot();
//    /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//    Constants.driver = new FirefoxDriver();
//    Constants.driver.manage().window().maximize();*/
//                } else {
//                    //Firefox linux connection here
//                }
//            }
//
//            return true;
//        } catch (Exception ex) {
//            System.out.println(ex);
//            LogCapture.info("Webdriver not found..." + ex);
//            takeSnapShot();
//            LogCapture.info("Snapshot Captured..");
//            return false;
//        }
        return false;
    }
    public String fileDownload(String object, String data) throws Exception {
        try {
            Screen src = new Screen();
            Pattern fileInputTextBox = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "filedownload.png");
            LogCapture.info(String.valueOf(fileInputTextBox));
            src.type(Key.BACKSPACE);
            // src.type(fileInputTextBox,System.getProperty("user.dir") +File.separator+ "DownloadedFiles"+File.separator+data);
            src.type(fileInputTextBox, data);

            Pattern saveButton = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "save.png");
            LogCapture.info(String.valueOf(saveButton));
            src.click(saveButton);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String fileDownloadOperations(String object, String data) {
        File file = new File(System.getProperty("user.dir") + File.separator + "DownloadedFiles" + File.separator + data);
        try {
            if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                if (file.exists())
                    System.out.println("File Exists on given path : " + data);
                else
                    System.out.println("File Does not Exists on given path");
            } else if (object.equalsIgnoreCase("deleteDownloadedFile")) {
                if (file.delete())
                    System.out.println("File deleted : " + data);
                else
                    System.out.println("File was not deleted");
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    //------------------------- API Values--------------------------------------------

    public static Map<String, String> getSqlQueryResult(String sqlQueryProperty, String... values) {
        String query = SQLQUERIES.getProperty(sqlQueryProperty);
        query = String.format(query, (Object[]) values);
        LogCapture.info("Query is :"+query);
        return executeQuery(Constants.connectionUrl,Constants.dBUsername,Constants.dbPassword,query);
    }
    public static Map<String, String> getSqlQueryResult1(String sqlQueryProperty,String Environment, String values) throws ClassNotFoundException {
        String queryInfo = SQLQUERIES.getProperty(sqlQueryProperty);
        String db = queryInfo.split("\\|")[0];
        String query = queryInfo.split("\\|")[1];
        if(Objects.nonNull(values)) {
//            query = String.format(query, (Object[]) values);
            query=query.replace("%s",values);
            System.out.println(query);
        }
        return executeQuery1(db + Environment, query);
    }

//    private static Connection getConnection(String databaseName) throws InterruptedException {
//        int retry = 10;
//        Connection connection = null;
//        String connectionUrl = Constants.dbconfig.getProperty(databaseName);
//        while (retry-- > 0 && Objects.isNull(connection)) {
//            try {
//                String dbClass = CONFIG.getProperty("dbClass");
//                Class.forName(dbClass);
//                DriverManager.setLoginTimeout(15);
//                connection = DriverManager.getConnection(connectionUrl);
//            } catch (SQLException e) {
//                LogCapture.error("Could not connect to database. Retrying again!!");
//                key.pause("2","");
//            }
//        }
//        return connection;
//    }

    public static Map<String, String> executeQuery1(String databaseName, String query) throws ClassNotFoundException {
        Map<String, String> trnDetails = new HashMap<>();
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String dbUrl=Constants.dbconfig.getProperty(databaseName);
        try (Connection connection = java.sql.DriverManager.getConnection(dbUrl)) {
            PreparedStatement ps = connection.prepareStatement(query);
            boolean retry = true;
            int retryCount = 5;
            while (retry && retryCount-- > 0) {
                try (ResultSet rs = ps.executeQuery()) {
                    ResultSetMetaData rsMD = rs.getMetaData();
                    while (rs.next()) {
                        retry = false;
                        for (int i = 1; i <= rsMD.getColumnCount(); i++) {
                            trnDetails.put(rsMD.getColumnName(i), rs.getString(rsMD.getColumnName(i)));
                        }
                        break;
                    }
                    key.pause("1","");
                } catch (Exception e) {
                    LogCapture.error("Exception occurred while fetching the result set: " + e.getLocalizedMessage());
                }
            }
        } catch (Exception e) {
            LogCapture.error("Exception occurred while querying the " + databaseName + " database: " + e.getLocalizedMessage());
        }
        return trnDetails;
    }
    public static Map<String, String> executeQuery(String connectionUrl,String DB_USER,String DB_PASSWORD,String query) {
        Map<String, String> result = new HashMap<>();
        try (Connection connection = java.sql.DriverManager.getConnection(connectionUrl, DB_USER, DB_PASSWORD)) {
            if (connection != null) {
                LogCapture.info("Connected to DB");
            }
            PreparedStatement ps = connection.prepareStatement(query);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData rsMD = rs.getMetaData();
                while (rs.next()) {
                    for (int i = 1; i <= rsMD.getColumnCount(); i++) {
                        result.put(rsMD.getColumnName(i), rs.getString(rsMD.getColumnName(i)));
                    }
                }

            } catch (Exception e) {
                LogCapture.error("Exception occurred while fetching the result set: " + e.getLocalizedMessage());
            }
        } catch (SQLException e) {
            LogCapture.error("Exception occurred while querying the database: " + e.getLocalizedMessage());
        }
        return result;
    }

    public String VerifyDBDetails(String environment, String data, String operationType) throws Exception {
        //For connection
        java.sql.Connection connection = null;
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String query = null;
        String value = null;
        String AccountNumber =null;
        int Count=0;
        String vTitanTransactionReference = null;
        String vTradeAmount = null;
        String StatementID=null;
        String StatementLineID=null;
        String MSL_ID=null;
        String Account_ID=null;
        String Legal_Entity_ID=null;
        String Legal_Entity=null;
        String ROF_ID=null;
        String ConfirmationID=null;
        String IntradayStatement=null;
//        String IntradayStatementLineID=null;
        String ActualRemitterAccountNumber =null;
        String ActualRemitterAccountName =null;
        String vIsParsed = null, vParsedStatus = null;
        List<String> list=new ArrayList<String>();
        HashMap<String,List<String>>ActualRemitter = new HashMap<>();
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("SITDB_URL") + ":" + Constants.dbconfig.getProperty("SITDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("SITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("UATDB_URL") + ":" + Constants.dbconfig.getProperty("UATDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("UATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("UATDB_Password");

        }else if (environment.equalsIgnoreCase("SIT_Titan")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanSITDB_URL") + ":" + Constants.dbconfig.getProperty("TitanSITDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanSITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanSITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT_Titan")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanUATDB_URL") + ":" + Constants.dbconfig.getProperty("TitanUATDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanUATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanUATDB_Password");

        }
        else if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("SITDB_URL") + ":" + Constants.dbconfig.getProperty("SITDB_PORT") + ";trustServerCertificate=true";
            DB_USER = Constants.dbconfig.getProperty("SITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("UATDB_URL") + ":" + Constants.dbconfig.getProperty("UATDB_PORT") + ";trustServerCertificate=true";
//            + ";integratedSecurity=true;trustServerCertificate=true";
            DB_USER = Constants.dbconfig.getProperty("UATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("UATDB_Password");

        }
        Constants.connectionUrl = DB_URL;
        Constants.dBUsername = DB_USER;
        Constants.dbPassword = DB_PASSWORD;


//        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//        Class.forName(dbClass).newInstance();

        LogCapture.info("Get connection to DB");

         if(operationType.equalsIgnoreCase("FetchTANforCDLGBPFX"))
        {
            query = "Select Top 50 CustomerWallet From Titan.Titan.CustomerwalletBalance where TotalBalance ='0.00' order by CreatedOn desc";
            Statement stmt = connection.createStatement();
            ps = connection.prepareStatement(query);
            //ps.setNString(1, data);
            ResultSet res = stmt.executeQuery(query);
            while (res.next()) {
                 String CustWallet = res.getString("CustomerWallet");

                String QuerruAccountnumber="Select Account from Titan.Titan.CustomerWallet where ID='"+CustWallet+"'";
                ResultSet res1 = connection.createStatement().executeQuery(QuerruAccountnumber);

                while (res1.next()) {
                    String AccountNo = res1.getString("Account");

                    String QuerruCDLGBPFXCust ="Select Organization,LegalEntity,AccountNumber,CustomerAccountType,AccountStatus From Titan.Titan.Account where ID ='"+AccountNo+"'";
                    ResultSet re2 = connection.createStatement().executeQuery(QuerruCDLGBPFXCust);

                    while (re2.next()) {
                         AccountNumber = re2.getString("AccountNumber");
                        String Organization = re2.getString("Organization");
                        String LegalEntity = re2.getString("LegalEntity");
                        String CustomerAccountType = re2.getString("CustomerAccountType");
                        String AccountStatus = re2.getString("AccountStatus");
                        if(Organization.equals("2")&&LegalEntity.equals("3")&&CustomerAccountType.equals("1")&&AccountStatus.equals("2"))
                        {
                            Count++;
                            value = AccountNumber;
                            System.out.println("CDLGB PFX Customer TAN is >>>>>>>>>>>>>>>>>>>>>>>>>>> " + value);
                            break;
                        }
                    }
                }
            }
        }
        else if(operationType.equalsIgnoreCase("Verify Deal Details")) {

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN_Order", "");
            String Dealid = result.get("ID");
            value = Dealid;
            LogCapture.info("deal id is" + value);
        } else if (operationType.equalsIgnoreCase("Fetch Latest Payment Titan Transaction Reference Number")) {
            Map<String, String> result = Reusables.getSqlQueryResult("TI_PaymentInstructionsDetails", data);
            value = result.get("Td_txn_ref_number");
            LogCapture.info("Latest Payment Titan Transaction Reference Number is" + value);

        }else if (operationType.equalsIgnoreCase("Find the StatementLineID")) {
            Constants.key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus=result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);

//            Assert.assertEquals("PASS", vIsParsed.equals("1"));
//            Assert.assertEquals("PASS", vIsParsed.equalsIgnoreCase(vParsedStatus));
//            if(vIsParsed.equalsIgnoreCase("1")){
//                if(vIsParsed.equalsIgnoreCase(vParsedStatus)){}}
            Assert.assertTrue( vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));

            Map<String, String> result1 = Reusables.getSqlQueryResult("Statement_940", data);
            StatementID = result1.get("ID");
            LogCapture.info("Value of StatementID: " + StatementID);
            Assert.assertFalse(false, String.valueOf(StatementID.contains("null")));
            Constants.RemitterNameID=StatementID;
            Map<String, String> result2 = Reusables.getSqlQueryResult("StatementLine_940", StatementID);
            StatementLineID = result2.get("ID");
            LogCapture.info("Value of StatementLineID: " + StatementLineID);
            Assert.assertFalse(false, String.valueOf(StatementLineID.contains("null")));
            value = StatementLineID;
            LogCapture.info("StatementLineID is " + value);

        }else if (operationType.equalsIgnoreCase("Find the MSL_ID")) {
            String StatementID1 = Constants.StatementLineID;
            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine53", StatementID1);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, String.valueOf(MSL_ID.contains("null")));
            value = MSL_ID;
        }else if (operationType.equalsIgnoreCase("ConfirmationPaymentAdvice ID")) {
//                Constants.key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus=result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);
            Assert.assertTrue( vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));


            Map<String, String> result1 = Reusables.getSqlQueryResult("ConfirmationPaymentAdvice", data);
            ConfirmationID = result1.get("ID");
            LogCapture.info("Value of ConfirmationID: " + ConfirmationID);
            Assert.assertFalse(false, String.valueOf(ConfirmationID.contains("null")));
            value = ConfirmationID;
        }else if (operationType.equalsIgnoreCase("Find the MSL_ID for CAMT54")) {
            String ConfirmationID1 = Constants.ConfirmationID;
            key.pause("2", "");
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine54", ConfirmationID1);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, String.valueOf(MSL_ID.contains("null")));
            value = MSL_ID;
        }else if (operationType.equalsIgnoreCase("Find the StatementLineID for Indraday")) {

//            Constants.key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus=result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);
            Assert.assertTrue(vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));


            Map<String, String> result1 = Reusables.getSqlQueryResult("IntradayStatement", data);
            IntradayStatement = result1.get("ID");
            LogCapture.info("Value of IntradayStatement: " + IntradayStatement);
            Assert.assertFalse(false, String.valueOf(IntradayStatement.contains("null")));
            Constants.IntradayStatementID=IntradayStatement;

            Map<String, String> result2 = Reusables.getSqlQueryResult("IntradayStatementLine", IntradayStatement);
            IntradayStatementLineID = result2.get("ID");

            value = IntradayStatementLineID;
            LogCapture.info("IntradayStatementLineID is " + IntradayStatementLineID);

        }else if (operationType.equalsIgnoreCase("Find the MSL_ID for Indraday")) {

//            String StatementID1 = IntradayStatementLineID;
            LogCapture.info("IntradayStatementLineID : " + IntradayStatementLineID);
//            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine52", IntradayStatementLineID);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, String.valueOf(MSL_ID.contains("null")));
            value = MSL_ID;

        } else if (operationType.equalsIgnoreCase("Checking Description")) {
//            String Pendingid = Constants.PendingB2BID;
            Map<String, String> result = Reusables.getSqlQueryResult("RFQ_Contract_Detail", data);
            value = result.get("Description");
            LogCapture.info("Description is : " + value);
        }else if (operationType.equalsIgnoreCase("Fetch latest message out BACS file name")) {

            Map<String, String> result = Reusables.getSqlQueryResult("LatestBACSMessageOutFile", "");
            String MessageText = result.get("Message");

            LogCapture.info("Message string is: " + MessageText);
            value = MessageText;

        }else if (operationType.equalsIgnoreCase("Find the CreditAdviceID")) {
//            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("CustomerCreditTransfer",MessageInId);
            String CreditAdviceID = result.get("ID");
            LogCapture.info("Value of Credit Advice ID is: " + CreditAdviceID);
            Assert.assertFalse(false, String.valueOf(CreditAdviceID.contains("null")));

            value = CreditAdviceID;

        }else if (operationType.equalsIgnoreCase("Transaction Reference From Message Out table")) {

            String ID = Constants.StatementLineID;
            LogCapture.info("StatementLineID : " + ID);
            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("StatementLineIDLegalEntity", ID);
            Legal_Entity = result.get("LegalEntityCode");
            LogCapture.info("Legal Entity : " + Legal_Entity);
            Assert.assertFalse(false, String.valueOf(Legal_Entity.contains("null")));
            value = Legal_Entity;

        }else if (operationType.equalsIgnoreCase("Find the BankPaymentEntriesID")) {
            key.pause("60","");
             Constants.key.pauseforSchedular();
             Map<String, String> result = Reusables.getSqlQueryResult("BankPaymentEntries", data);
             String BankPaymentEntries = result.get("ID");
             LogCapture.info("BankPaymentEntriesID : " + BankPaymentEntries);
             Assert.assertFalse(false, String.valueOf(BankPaymentEntries.contains("null")));
             value = BankPaymentEntries;

         }else if (operationType.equalsIgnoreCase("Find CustomerInstructionID")) {

//             Constants.key.pauseforSchedular();
             key.pause("2","");
             Map<String, String> result = Reusables.getSqlQueryResult("CustomerInstructionID", data);
             String CustomerInstructionID = result.get("ID");
             LogCapture.info("CustomerInstructionID : " + CustomerInstructionID);
             Assert.assertFalse(false, String.valueOf(CustomerInstructionID.contains("null")));

             value = CustomerInstructionID;

         }else if (operationType.equalsIgnoreCase("Find CustomerPaymentInID")) {

//             Constants.key.pauseforSchedular();
             key.pause("30","");
             Map<String, String> result1 = Reusables.getSqlQueryResult("CustomerPaymentInID", CustomerInstructionID);
             String CustomerPaymentInID = result1.get("ID");
             LogCapture.info("CustomerPaymentInID : " + CustomerPaymentInID);
             Assert.assertFalse(false, String.valueOf(CustomerPaymentInID.contains("null")));
             value = CustomerPaymentInID;

         }else if (operationType.equalsIgnoreCase("Find InstructionIdReference")) {

////             Constants.key.pauseforSchedular();
             key.pause("60","");
             Map<String, String> result = Reusables.getSqlQueryResult("InstructionIdReference", data);
             String InstructionIdReference = result.get("ID");
             LogCapture.info("InstructionIdReference : " + InstructionIdReference);
             Assert.assertFalse(false, String.valueOf(InstructionIdReference.contains("null")));
             value = InstructionIdReference;

         }else if (operationType.equalsIgnoreCase("Find CustomerPaymentInID using InstructionIdReference")) {

////             Constants.key.pauseforSchedular();
//             key.pause("30","");
             Map<String, String> result = Reusables.getSqlQueryResult("CustomerPaymentInIDUsingInstructionIdReference", data);
             String CustomerPaymentInID = result.get("ID");
             LogCapture.info("CustomerPaymentInID : " + CustomerPaymentInID);
             Assert.assertFalse(false, String.valueOf(CustomerPaymentInID.contains("null")));
             value = CustomerPaymentInID;

         }else if (operationType.equalsIgnoreCase("VerifyPtTokenID"))
         {
             Map<String, String> result = Reusables.getSqlQueryResult("Fetch_PtTokenID", data);
             value = result.get("ptToken");
             LogCapture.info("PtToken ID is : " + value);

         }else if (operationType.equalsIgnoreCase("VerifyPtTokenWallet"))
         {
             Map<String, String> result = Reusables.getSqlQueryResult("Fetch_PtTokenWallet", data);
             value = result.get("ptWallet");
             LogCapture.info("PtToken Wallet is : " + value);
         } else if (operationType.equalsIgnoreCase("VerifyConsolidatedWalletBalances"))
         {
             Map<String, String> result = Reusables.getSqlQueryResult("Fetch_ConsolidatedWalletBalances", data);
             value = result.get("ConsolidatedWalletBalances");
             LogCapture.info("Consolidated Wallet Balances is : " + value);
         }else if (operationType.equalsIgnoreCase("Find LimitOrderID")) {

//             Constants.key.pauseforSchedular();
//             key.pause("50","");
             Map<String, String> result = Reusables.getSqlQueryResult("LimitOrder", data);
             String ID = result.get("ID");
             LogCapture.info("Limit order ID : " + ID);
             Assert.assertFalse(false, String.valueOf(ID.contains("null")));

             value = ID;

         }else if (operationType.equalsIgnoreCase("Find CustomerPaymentOutID")) {

//             Constants.key.pauseforSchedular();
             key.pause("64","");
             Map<String, String> result1 = Reusables.getSqlQueryResult("CustomerPaymentOutID", CustomerInstructionID);
             String CustomerPaymentOutID = result1.get("ID");
             Constants.InstructionNumber1=result1.get("InstructionNumber");
             LogCapture.info("CustomerPaymentOutID : " + CustomerPaymentOutID);
             Assert.assertFalse(false, String.valueOf(CustomerPaymentOutID.contains("null")));
             value = CustomerPaymentOutID;

         }else if (operationType.equalsIgnoreCase("Find achMandateId")) {

//             Constants.key.pauseforSchedular();
             Map<String, String> result = Reusables.getSqlQueryResult("achMandateId", InstructionNumber1);
             String achMandateId = result.get("achMandateId");
             LogCapture.info("achMandateId : " + achMandateId);
             Assert.assertFalse(false, String.valueOf(achMandateId.contains("null")));
             value = achMandateId;

         }else if (operationType.equalsIgnoreCase("Find FundType and StatusEnum")) {

             Map<String, String> result = Reusables.getSqlQueryResult("BankPaymentEntries", external_reference_id);
             Constants.FundType = result.get("FundType");
             Constants.StatusEnum = result.get("StatusEnum");
             LogCapture.info("FundType is : "+FundType+"StatusEnum : " + StatusEnum);
             Assert.assertFalse(false, String.valueOf(FundType.contains("null")));
             value = FundType;

         }else if (operationType.equalsIgnoreCase("Find AccountNumber Details")) {
             query = SQLQUERIES.getProperty("BankDetails1");
             query=query.replace("%s",data);
             System.out.println(query);
             Map<String, String> result =executeQuery(Constants.connectionUrl,Constants.dBUsername,Constants.dbPassword,query);

             Constants.Currency_code = result.get("Currency_code");
             Constants.bank_name = result.get("bank_name");
             Constants.BIC = result.get("BIC");
             Constants.Address = result.get("Address");
             Constants.Name = result.get("Name");
             Constants.org_code = result.get("org_code");
             Constants.legal_entity = result.get("legal_entity");
             Constants.hyperion_bank_account_reference_id = result.get("External_BankAccount_Reference_Id");
             LogCapture.info("Currency_code is : "+Currency_code);
//             Assert.assertFalse(false, String.valueOf(Currency_code.contains("null")));
             value = Currency_code;

         }
         else if (operationType.equalsIgnoreCase("Fetch TAN CDLGB")) {
             LogCapture.info("--------------User Fetch TAN for CDLEU TAN no from DB-------------------");
             Map<String, String> result = Reusables.getSqlQueryResult("Fetch_TAN_CDLGB", data);
             value = result.get("TradeAccountNumber");
             System.out.println("Fetch_TAN_CDLEU  fetched is" + value);
             LogCapture.info("--------------User Fetched TAN for CDLEU no from DB-------------------");
         }
         else if (operationType.equalsIgnoreCase("Fetch TradeContactID")) {
             LogCapture.info("--------------User Fetch TradeContactID from DB-------------------");
             Map<String, String> result = Reusables.getSqlQueryResult("Fetch_TradeContactID", data);
             value = result.get("TradeContactID");
             System.out.println("TradeContactID fetched is: " + value);
             LogCapture.info("--------------User Fetched TradeContactID from DB-------------------");
         }
        return value;
       /* } catch (Exception e) {
            System.out.println("Unable to do operation"+operationType+ "--"+ e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        } finally {
            // Close DB connection
            if (connection != null) {
                connection.close();
            }*/
        //}


    }

    // Pricing Enginee Reusables
    public static File RenameCAMTFile(String FileType, String Bank,String AccountNumber) throws Exception {
        DateTimeFormatter date=DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime now=LocalDateTime.now();
        Constants.nameDate=date.format(now);

        String RandomNumber= RandomStringUtils.randomNumeric(5);
        String number=RandomNumber;

        File camtFile=null;
        File Rename =null;
        File directoryPath=new File("Files/"+Bank+"/");

        String contents[]=directoryPath.list(); //List of all files and directories
        // key.pause("2","");
        LogCapture.info("List of files and directories in the specified directory:"+directoryPath);
        for(int i=0; i<contents.length;i++) {
            if(contents[i].contains(FileType)){
                camtFile=new File("Files/"+Bank+"/"+contents[i]);
                LogCapture.info("old file name "+camtFile.getName());
                break;
            }
        }
        if (FileType.contains("camt.")) {
            Rename = new File("Files/" + Bank + "/" + FileType + "001.02.stm_D" + nameDate + "_R667" + number + ".F020002");
        }else if(FileType.contains("pain.002")){
            Rename = new File("Files/" + Bank + "/" + FileType + "001.03.D" + nameDate + "_R667" + number + ".F020002.SNL35343D23678530057799989S");
        }
        else {
            LogCapture.info("old Amount is "+oldAmountStarting);

            Constants.oldAmountStarting=camtFile.getName().split("%")[1];

            LogCapture.info("Old Amount was starts with "+oldAmountStarting);
            RandomNumber= String.valueOf(RandomNumber(1000));
            if(newAmount==null) {
                Constants.newAmount=RandomNumber;
            }

            LogCapture.info("New Amount starts with"+newAmount);
            Constants.dateReplace=camtFile.getName().split("%")[2];
            LogCapture.info("Old date was "+dateReplace);
            Constants.OldAccountNumber=camtFile.getName().split("%")[3];
            LogCapture.info("Old Account Number was "+OldAccountNumber);

            if (FileType.contains("BMO")) {
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyMMdd");
                Constants.currentDate=dtf.format(now);
                Rename = new File("Files/" + Bank + "/" + FileType + "%" + newAmount + "%" + currentDate + "%58gcnn00ingulkar7k002dar.txt");
            }else if (FileType.contains("JPM")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
                Constants.currentDate=dtf.format(now);
                Rename=new File("Files/" + Bank + "/" + FileType + "%" + newAmount +"%"+currentDate+"%"+AccountNumber+"%45_132_00_01_436.json");
            }else if (FileType.contains("MT940")||FileType.contains("MT942")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyMMddMMdd");
                Constants.currentDate=dtf.format(now);
                Rename=new File("Files/" + Bank + "/" + FileType + "%" + newAmount +"%"+currentDate+"%"+AccountNumber+"%45_132_00_01_436.text");
            }else if (FileType.contains("MT103") || FileType.contains("MT103ROF")){
                DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyMMdd");
                Constants.currentDate=dtf.format(now);
                Rename=new File("Files/" + Bank + "/" + FileType + "%" + newAmount +"%"+currentDate+"%45_132_00_01_436.text");
            }
        }

        camtFile.renameTo(Rename);
        return Rename;
    }

    public static Integer RandomNumber(Integer data) throws Exception {
        Random rand = new Random();
        int value = rand.nextInt(data);
        return value;
    }

    public static void updateXmlFile(String Tag, String NewValue){

        NodeList NodeList = doc1.getElementsByTagName(Tag); // Document object to find the tag that needs to be updated
        for (int i = 0; i < NodeList.getLength(); i++) {
            Node node = NodeList.item(i);
            node.setTextContent(NewValue);   //  Update the tag with the new value
            LogCapture.info("New value at Tag :"+Tag+" is "+NewValue);
        }

    }
    public static void updateXmlParentChild(String ParentTag, String ChildTag, String NewValue){

        NodeList parentTags = doc1.getElementsByTagName(ParentTag);

        // Iterate through parent tags
        for (int i = 0; i < parentTags.getLength(); i++) {
            Node parentTag = parentTags.item(i);

            if (parentTag.getNodeType() == Node.ELEMENT_NODE) {
                Element parentElement = (Element) parentTag;

                // Find the child tags by tag name within the parent tag
                NodeList childTags = parentElement.getElementsByTagName(ChildTag);

                // Iterate through child tags
                for (int j = 0; j < childTags.getLength(); j++) {
                    Element childTag = (Element) childTags.item(j);

                    // Update the child tag's value
                    childTag.setTextContent(NewValue);
                }
            }
        }

    }

    public static void pauseforSchedular() throws InterruptedException {
        LocalDateTime now = LocalDateTime.now();
        int seconds = now.getSecond();
        int Actualpause = 77 - seconds;
        if (Actualpause<20){

            LogCapture.info("taking pause for 20 sec for processing");
            key.pause("20","");
        }else {
            LogCapture.info("taking pause for "+Actualpause+" sec for processing");
            key.pause(String.valueOf(Actualpause),"");

//            key.pause("20","");
        }

    }
    public static void loginToKafkaUI() throws Exception {
        LogCapture.info("----------------User enters UserName and Password-------------------");
        String environment = CONFIG.getProperty("Environment");
        String username = Constants.CONFIG.getProperty("KafkaUsername" + environment);
        String password = Constants.CONFIG.getProperty("KafkaPassword" + environment);
        String vObjUser = Constants.KafkaUI.getProperty("Username");
        String vObjPass = Constants.KafkaUI.getProperty("Password");

        Assert.assertTrue(Constants.key.isElementDisplayed(vObjUser, 20), "Kafka Login page is not displayed");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, username));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, password));
        String vObjLoginButton = Constants.KafkaUI.getProperty("SignIn");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    public static String cleanJsonPathValue(String jsonPathValue) {
        try {
            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("(\\[string|double|boolean|int):(.*)(\\])");

            Matcher matcher = pattern.matcher(jsonPathValue);
            if(matcher.find()) {
                return matcher.group(2);
            } else {
                return jsonPathValue;
            }
        } catch (Exception ex) {
            //LogCapture.error("Exception occurred cleaning Kafka Message JsonPath " + jsonPathValue);
        }
        return  null;
    }
    public boolean isElementDisplayed(String object, int waitInSeconds) {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(waitInSeconds));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            return true;
        } catch (Exception e) {
        }
        return false;
    }
    //------------------------- API Values--------------------------------------------
    public static int getTimeLapsedInSeconds(LocalDateTime localDateTime) {
        return (int) ChronoUnit.SECONDS.between(LocalDateTime.now(), localDateTime);
    }
    public static Map<String,String> getSqlQueryResult(String environment, String data, String operationType) throws Exception {
        String DB_URL = null;
        String DB_USER = null;
        String DB_PASSWORD = null;
        //String value = null;
        Map<String, String> result = new HashMap<>();

        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("SITDB_URL") + ":" + Constants.dbconfig.getProperty("SITDB_PORT") + ";trustServerCertificate=true";
            DB_USER = Constants.dbconfig.getProperty("SITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("UATDB_URL") + ":" + Constants.dbconfig.getProperty("UATDB_PORT") + ";trustServerCertificate=true";
//            + ";integratedSecurity=true;trustServerCertificate=true";
            DB_USER = Constants.dbconfig.getProperty("UATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("UATDB_Password");

        } else if (environment.equalsIgnoreCase("CardsUAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("CardsUAT_URL") + "," + Constants.dbconfig.getProperty("Cards_PORT") + ";integratedSecurity=true;trustServerCertificate=true";
//            DB_USER = Constants.dbconfig.getProperty("CardsUATDB_User");
//            DB_PASSWORD = Constants.dbconfig.getProperty("CardsUATDB_Password");
        }else if (environment.equalsIgnoreCase("SIT_Titan")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanSITDB_URL") + ":" + Constants.dbconfig.getProperty("TitanSITDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanSITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanSITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT_Titan")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanUATDB_URL") + ":" + Constants.dbconfig.getProperty("TitanUATDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanUATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanUATDB_Password");

        }
        Constants.connectionUrl = DB_URL;
        Constants.dBUsername = DB_USER;
        Constants.dbPassword = DB_PASSWORD;

        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        Class.forName(dbClass).newInstance();

        // Get connection to DB
        LogCapture.info("Get connection to DB at "+environment);

        if (operationType.equalsIgnoreCase("Fetch Latest Account Details")) {
            result = Reusables.getSqlQueryResult("Fetch_Latest_CD_PFX_TAN", data);
        }else if(operationType.equalsIgnoreCase("Fetch Latest Contact Details")){
            result = Reusables.getSqlQueryResult("Fetch_Latest_CD_PFX_Contact", data);
        }
        else if (operationType.equalsIgnoreCase("Payment In")) {
            result = Reusables.getSqlQueryResult("Fetch_FundsInDATA", data);

        }else if (operationType.equalsIgnoreCase("Find CustomerPaymentInID")) {
            result = Reusables.getSqlQueryResult("Fetch_CustomerPaymentInID", data);

        }else if (operationType.equalsIgnoreCase("Customer Instruction")) {
            String query = SQLQUERIES.getProperty("Fetch_CustomerInstruction3");
            query=query.replace("%s",data);
            System.out.println(query);
            result =executeQuery(Constants.connectionUrl,Constants.dBUsername,Constants.dbPassword,query);

        } else if (operationType.equalsIgnoreCase("Find LimitOrderID")) {
            result = Reusables.getSqlQueryResult("Fetch_LimitOrderID", data);
        }else if (operationType.equalsIgnoreCase("New Payment out")) {
            String query = SQLQUERIES.getProperty("Fetch_PaymentOutEvent2");
            query=query.replace("%s",CustomerInstructionID);
            System.out.println(query);
            result =executeQuery(Constants.connectionUrl,Constants.dBUsername,Constants.dbPassword,query);

        }
            return result;
    }
    private static Map<String, String> getAuditMappings(String mappingFilePath) {
        Properties mappings = ReusableMethod.getProperties(mappingFilePath);
        List<String> actualFieldName = new ArrayList<>(mappings.stringPropertyNames());
        Map<String, String> resultPaths = new HashMap<>();
        for(String path : actualFieldName) {
            String[] splitedPath = path.split("\\.");
            String pathPrefix = splitedPath[0];
            String auditColName = splitedPath[1].toLowerCase();
            if(pathPrefix.equalsIgnoreCase("MessageHeader")) {
                auditColName = "h" + auditColName;
            }
            resultPaths.put(auditColName, mappings.getProperty(path));
        }
        return resultPaths;
    }

    private static Map<String, String> getKafkaMappings(String mappingFilePath) {
        Properties mappings = ReusableMethod.getProperties(mappingFilePath);
        List<String> actualFieldName = new ArrayList<>(mappings.stringPropertyNames());
        Map<String, String> resultPaths = new HashMap<>();
        for(String path : actualFieldName) {
            resultPaths.put(path, mappings.getProperty(path));
        }
        return resultPaths;
    }

    public static void compareJsonAgainstGetTxnMappings(Map<String, String> DBData, JsonPath jsonPathObj, String mappingFilePath, boolean isAudit) {
        Map<String, String> fieldMappings;
        if(isAudit) {
            fieldMappings = getAuditMappings(mappingFilePath);
        } else {
            fieldMappings = getKafkaMappings(mappingFilePath);
        }
        String expectedValue;
//        boolean isCompareDouble = false;

//        Properties mappings = ReusableMethod.getProperties(mappingFilePath);
//        List<String> jsonPathList = new ArrayList<>(mappings.stringPropertyNames());
//        String expectedValue;
        for (String jsonPathStr : fieldMappings.keySet()) {
            String actualValue = jsonPathObj.getString(jsonPathStr);
            actualValue = Objects.isNull(actualValue) || actualValue.equalsIgnoreCase("null") ? "" : actualValue; //remove null pointer E
            actualValue = Reusables.cleanJsonPathValue(actualValue);
            if(actualValue.equals("f")){
                actualValue= "false";
            } else if(actualValue.equals("t")) {
                actualValue= "true";
            }
            System.out.println("actualValue is "+actualValue);
            //Assert.assertNotNull(actualValue, "Could not parse JsonPath value from the actual Json Message");
            String expectedMappingPropertyValue = fieldMappings.get(jsonPathStr);

            if (expectedMappingPropertyValue.contains("skip")) {
                continue;
            }

            if (expectedMappingPropertyValue.contains("value=")) {
                expectedValue = expectedMappingPropertyValue.split("=")[1];
                System.out.println("expectedValue is "+expectedValue);
            } else if (expectedMappingPropertyValue.contains("compareDouble")) {
                String expectedMappingPropertyVal = expectedMappingPropertyValue.split("=")[1];

                expectedValue = DBData.get(expectedMappingPropertyVal);//ReusableMethod.getXpathValue(DBData, "//" + expectedMappingPropertyVal);
                // If no value in XML, then nothing to check //TODO put this as common to all conditions
                System.out.println("expectedValue is "+expectedValue);
                if (ReusableMethod.isNotNullOrEmpty(expectedValue)) {
                    if (expectedMappingPropertyValue.contains("compareDoubleIgnoreSign")) {
                        ReusableMethod.softAssert.assertEquals(Math.abs(Double.parseDouble(actualValue.trim())), Math.abs(Double.parseDouble(expectedValue)), "Assertion for " + jsonPathStr + " failed");
                    } else {
                        ReusableMethod.softAssert.assertEquals(Double.parseDouble(actualValue.trim()), Double.parseDouble(expectedValue), "Assertion for " + jsonPathStr + " failed");
                    }

                } else {
                    ReusableMethod.softAssert.assertTrue(actualValue.isEmpty(), "No value found for " + expectedMappingPropertyVal);
                }
                continue;
            } else if (expectedMappingPropertyValue.contains("concatenateXpathValues=")) {
                String allXpaths = expectedMappingPropertyValue.split("=")[1];
                String valueFromXML = "";
                // multiple Xpath values
                String[] columnNames = allXpaths.split(" ");
                for (String columnName : columnNames) {
                    valueFromXML = String.join(" ", valueFromXML, DBData.get(columnName));// ReusableMethod.getXpathValue(DBData, "//" + columnName));
                }
                expectedValue = valueFromXML;

            } else if (expectedMappingPropertyValue.contains("method=")) {
                String methodDetails = expectedMappingPropertyValue.split("=")[1];
                String methodName = methodDetails.split("\\|")[0];
                String methodArg = methodDetails.split("\\|")[1];
                String valueFromXML = DBData.get(methodArg);//ReusableMethod.getXpathValue(DBData, "//" + methodArg);

                if (ReusableMethod.isNotNullOrEmpty(valueFromXML)) {
                    try {
                        Class<Reusables> classObj = Reusables.class;
                        Method method = classObj.getDeclaredMethod(methodName, String.class);
                        expectedValue = (String) method.invoke(null, valueFromXML);
                        System.out.println("expectedValue is "+expectedValue);
                    } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }

                } else {
                    ReusableMethod.softAssert.assertTrue(actualValue.isEmpty(), "No value found in XML for " + methodDetails);
                    continue; // If no value in XML, then nothing to check
                }

            } else if (expectedMappingPropertyValue.contains("checkValueContainsKey")) {
                expectedMappingPropertyValue = expectedMappingPropertyValue.split("=")[1];
                expectedValue = DBData.get(expectedMappingPropertyValue);//ReusableMethod.getXpathValue(DBData, "//" + expectedMappingPropertyValue);
                ReusableMethod.softAssert.assertTrue(expectedValue.trim().contains(actualValue.trim()), "Assertion for " + jsonPathStr + " failed");
                continue;

            } else if (expectedMappingPropertyValue.contains("ignoreSpaces")) {
                expectedMappingPropertyValue = expectedMappingPropertyValue.split("=")[1];
                expectedValue = DBData.get(expectedMappingPropertyValue).replaceAll(" ", "");//ReusableMethod.getXpathValue(DBData, "//" + expectedMappingPropertyValue).replaceAll(" ", "");
                actualValue = actualValue.replaceAll(" ", "");
            } else {
                expectedValue = DBData.get(expectedMappingPropertyValue);//ReusableMethod.getXpathValue(DBData, "//" + expectedMappingPropertyValue);
            }

            actualValue = Objects.isNull(actualValue) ? "" : actualValue; //make json field value empty if null
            expectedValue = Objects.isNull(expectedValue) ? "" : expectedValue;
            ReusableMethod.softAssert.assertEquals(actualValue.trim(), expectedValue.trim(), "Assertion for " + jsonPathStr + " failed");
        }
    }

    public static String intToBoolean(String str) {
        String value="";
        if(str.equals("0")){
            value= "false";
        } else if(str.equals("1")) {
            value= "true";
        }
        return value;
    }

    public String AcceptCookies() {
        try {
            //If Cookies window exist then accept the cookies and proceed or else skip
            // Waiting for cookies to load hence 10 sec pause is implemented
            String vCookies_Accept = Constants.PFXOR.getProperty("Cookies_Accept");
            if (Constants.key.dynamicvisibleConditionWait(vCookies_Accept, 20).equalsIgnoreCase("Pass")) {
                Assert.assertEquals("PASS", Constants.key.click(vCookies_Accept, ""));
                Constants.key.pause("1", "");
                LogCapture.info("Cookies Accepted");
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogCapture.info("Cookies Not Accepted");
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }
    public String dynamicvisibleConditionWait(String object, int TimeoutSec) throws Exception {
        try {

            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(TimeoutSec));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to find...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String RecipientEdit(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Edit')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String javascrpiptScroll(String object, String data) throws Exception {
        try {
            WebElement elem = Constants.driver.findElement(By.xpath(object));
            String js = "arguments[0].scrollIntoView();";
            ((JavascriptExecutor) Constants.driver).executeScript(js, elem);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public static Map<String, String> verifyDBDetailsEnhanced(String environment, String data, String operationType) throws Exception {
        String DB_URL = null;
        String DB_USER = null;
        String DB_PASSWORD = null;
        //String value = null;
        Map<String, String> result = new HashMap<>();

        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + dbconfig.getProperty("SITDB_URL") + ":" + dbconfig.getProperty("SITDB_PORT") + ";trustServerCertificate=true";
            DB_USER = dbconfig.getProperty("SITDB_User");
            DB_PASSWORD = dbconfig.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + dbconfig.getProperty("UATDB_URL") + ":" + dbconfig.getProperty("UATDB_PORT") + ";trustServerCertificate=true";
//            + ";integratedSecurity=true;trustServerCertificate=true";
            DB_USER = dbconfig.getProperty("UATDB_User");
            DB_PASSWORD = dbconfig.getProperty("UATDB_Password");

        } else if (environment.equalsIgnoreCase("CardsUAT")) {
            DB_URL = "jdbc:sqlserver://" + dbconfig.getProperty("CardsUAT_URL") + "," + dbconfig.getProperty("Cards_PORT") + ";integratedSecurity=true;trustServerCertificate=true";
//            DB_USER = dbconfig.getProperty("CardsUATDB_User");
//            DB_PASSWORD = dbconfig.getProperty("CardsUATDB_Password");
        }
        else if(environment.equalsIgnoreCase("KafkaAuditlogSIT")){
            DB_URL = Constants.CONFIG.getProperty("KafkaAuditlogSIT");
        }
        else if(environment.equalsIgnoreCase("KafkaAuditlogUAT")){
            DB_URL = Constants.CONFIG.getProperty("KafkaAuditlogSIT");
        }
        Constants.connectionUrl = DB_URL;
        Constants.dBUsername = DB_USER;
        Constants.dbPassword = DB_PASSWORD;

        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        Class.forName(dbClass).newInstance();

        // Get connection to DB
        LogCapture.info("Get connection to DB");

        if (operationType.equalsIgnoreCase("Fetch Latest Account Details")) {
            result = Reusables.getSqlQueryResult("Fetch_Latest_CD_PFX_TAN", data);
        } else if (operationType.equalsIgnoreCase("Fetch Latest Contact Details")) {
            result = Reusables.getSqlQueryResult("Fetch_Latest_CD_PFX_Contact", data);
        } else if (operationType.equalsIgnoreCase("Fetch PaymentDetails")) {
            result = Reusables.getSqlQueryResult("Fetch_TradeContractNumber", data);
        }
        else if (operationType.equalsIgnoreCase("Fetch FundsInDATA")) {
            result = Reusables.getSqlQueryResult("Fetch_FundsInDATA", data);
        }
        else if (operationType.equalsIgnoreCase("Fetch FundsOutDATA")){
            result=Reusables.getSqlQueryResult("Fetch_FundsOutDATA",data);
        }
        else if (operationType.equalsIgnoreCase("Fetch Kafka Audit FundsIN Log")){
            result=Reusables.getSqlQueryResult("Fetch_Kafka_Audit_FundsIN_Log",data);
        }
        else if (operationType.equalsIgnoreCase(" Compliance.Kafka.TxnRequest.FundsInDATA")){
            result=Reusables.getSqlQueryResult(" Compliance.Kafka.TxnRequest.FundsInDATA",data);
        }
        return result;
    }


    public static void modifyFile(String filePath, String oldString, String newString)
    {
        File fileToBeModified = new File(filePath);
        String oldContent = "";
        BufferedReader reader = null;
        FileWriter writer = null;
        try
        {
            reader = new BufferedReader(new FileReader(fileToBeModified));
            String line = reader.readLine();
            while (line != null)
            {
                oldContent = oldContent + line + System.lineSeparator();
                line = reader.readLine();
            }
            String newContent = oldContent.replaceAll(oldString, newString);
            if(filePath.contains("MT")){
                Constants.messageInQuery=newContent;
            }
            writer = new FileWriter(fileToBeModified);
            writer.write(newContent);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                reader.close();
                writer.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static List<Map<String, String>> executeQueryForMultiRows(String connectionUrl,String DB_USER,String DB_PASSWORD, String query) {
        List<Map<String, String>> records = new ArrayList<>();
        try (Connection connection = java.sql.DriverManager.getConnection(connectionUrl, DB_USER, DB_PASSWORD)) {
            PreparedStatement ps = connection.prepareStatement(query);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData rsMD = rs.getMetaData();
                while (rs.next()) {
                    Map<String, String> record = new HashMap<>();
                    for (int i = 1; i <= rsMD.getColumnCount(); i++) {
                        record.put(rsMD.getColumnName(i), rs.getString(rsMD.getColumnName(i)));
                    }
                    records.add(record);
                }

            } catch (Exception e) {
                System.out.println("Exception occurred while fetching the result set: " + e.getLocalizedMessage());
            }
        } catch (SQLException e) {
            System.out.println("Exception occurred while querying the database: " + e.getLocalizedMessage());
        }
        return records;
    }

    public static List<Map<String, String>> getSqlQueryResultForMultiRows(String sqlQueryProperty, String... values) {
        String query ="";
        if(sqlQueryProperty.equalsIgnoreCase("QueryForInsert")){
            query= messageInQuery;
            LogCapture.info("Query is "+query);

        }else {
            query = SQL_Queries.getProperty(sqlQueryProperty);
            query = format(query, (Object[]) values);
            LogCapture.info("Query is "+query);
        }
        return executeQueryForMultiRows(Constants.connectionUrl,Constants.dBUsername,Constants.dbPassword,query);
    }

    public static JsonPath waitForKafkaMessage(String uniqueIdentifier) throws Exception {

        LogCapture.info("Waiting for Kafka message to populate on UI.....");
        LocalDateTime localDateTime = LocalDateTime.now();
        String kafkaJsonMessage;
        boolean isMessageLineDisplayed = false;

        String messageFieldXpath = Constants.KafkaUI.getProperty("MessageField");
        messageFieldXpath = messageFieldXpath.replace("{uniqueMessageId}", uniqueIdentifier);

        while(!isMessageLineDisplayed && ReusableMethod.getTimeLapsedInSeconds(localDateTime) < 200) {
            isMessageLineDisplayed = Constants.key.isElementDisplayed(messageFieldXpath, 10);
        }

        kafkaJsonMessage = Constants.key.getText(messageFieldXpath,"");
        System.out.println(kafkaJsonMessage);
        Assert.assertTrue(isMessageLineDisplayed, "Message is not found within 3 minutes");
        JsonPath jsonPath = JsonPath.from(kafkaJsonMessage);
        return jsonPath;
    }

    public static Map<String,String> verifyEnhancedDBDetails(String environment, String data, String operationType) throws Exception {
        Connection connection = null;
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        Map<String, String> result = new HashMap<>();
        List<String> list = new ArrayList<String>();
        HashMap<String, List<String>> ActualRemitter = new HashMap<>();
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("SITDB_URL") + ":" + Constants.DBCONFIG.getProperty("SITDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("SITDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
        }
//        else if (environment.equalsIgnoreCase("UAT")) {
//            DB_URL = "jdbc:sqlserver://" + Constants.DBCONFIG.getProperty("UATDB_URL") + ":" + Constants.DBCONFIG.getProperty("UATDB_PORT");
//            DB_USER = Constants.DBCONFIG.getProperty("UATDB_User");
//            DB_PASSWORD = Constants.DBCONFIG.getProperty("UATDB_Password");
//        }
        Constants.connectionUrl = DB_URL;
        Constants.dBUsername = DB_USER;
        Constants.dbPassword = DB_PASSWORD;

//        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//        Class.forName(dbClass).newInstance();

        LogCapture.info("Get connection to DB");

        if (operationType.equalsIgnoreCase("PaymentIn")) {
            result = Reusables.getSqlQueryResult("PaymentIn.Kafka", KafkaMessageCDID);
        }if (operationType.equalsIgnoreCase("TIPaymentInstruction")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.TIPaymentInstructions", KafkaMessageCDID);
        }if (operationType.equalsIgnoreCase("TIPaymentInstructionDetails")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.TIPaymentInstructiondetail", ID);
        }if (operationType.equalsIgnoreCase("PaymentID")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.Payment", Transaction_Reference);
        }if (operationType.equalsIgnoreCase("MessageOut")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.Messageout", KafkaMessageCDID);
        }if (operationType.equalsIgnoreCase("AuditTrail")) {
            result = Reusables.getSqlQueryResult("PaymentOut.Kafka.AuditTrail", KafkaMessageCDID);
//            Map<String, String> AuditTrailID = result.get("ID");
//            LogCapture.info("Value of AuditTrailID is: " + AuditTrailID);
        }if (operationType.equalsIgnoreCase("Kafka.Audit.PaymentLifeCycleId")) {
            result = Reusables.getSqlQueryResult("Kafka.Audit.PaymentLifeCycleId", KafkaMessageCDID);
        }
        return result;
    }

    public String invisibleConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(300));
            w.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String getPageURL(String object, String data) throws Exception {
        String URL = "";
        try {
            Constants.key.pause("3", "");
            URL = driver.getCurrentUrl();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Unable to get URL...." + e.getMessage();
        }
        return URL;
    }

    public String VerifySubstring(String data, String data1) throws Exception {
        String match = "";
        try {
            if (data.contains(data1)) {
                match = Constants.KEYWORD_PASS;
            } else {
                match = Constants.KEYWORD_FAIL;
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + " " + data1 + " String is not in " + data + " String..." + e.getMessage();
        }
        return match;
    }

    public String ClickableConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(120));
            w.until(ExpectedConditions.elementToBeClickable(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String clickAndHandleAlert(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("5", "");
        } catch (UnhandledAlertException f) {
            try {
                Alert alert = driver.switchTo().alert();
                alert.accept();
                return KEYWORD_FAIL;
            } catch (NoAlertPresentException e) {
                e.printStackTrace();
            }
        }
        return KEYWORD_PASS;
    }

    public String removeSpaces(String data) {
        String noSpaceStr = data.replaceAll("\\s", "");
        return noSpaceStr;
    }

    public String getAlertText() {
        String alertText = "";
        try {
            Alert alert = Constants.driver.switchTo().alert();
            alertText = alert.getText();
            alert.accept();
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return alertText;
    }

    public String UploadFile(String object, String pahtToUpload) throws Exception {
        try {
            WebElement uploadElement = Constants.driver.findElement(By.xpath(object));
            uploadElement.sendKeys(pahtToUpload);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Drop Down Index Not Present...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;

    }

    public static void writeDataFromExcel(int rowcount,int columncount,File filepath,String Sheetname,String value)
    {
        try
        {
            FileInputStream input=new FileInputStream(filepath);
            XSSFWorkbook wb=new XSSFWorkbook(input);
            XSSFSheet sh=wb.getSheet(Sheetname);
            XSSFRow row=sh.getRow(rowcount);
            FileOutputStream webdata=new FileOutputStream(filepath);
            row.createCell(columncount).setCellValue(value);
            wb.write(webdata);

        }
        catch(Exception e)
        {

        }
    }

    public String SelectDropDownValue(String object, String data) throws Exception {
        try {
            System.out.println("Object:->" + object);
            System.out.println("Data:->" + data);
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            objSelect.selectByVisibleText(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }
}
