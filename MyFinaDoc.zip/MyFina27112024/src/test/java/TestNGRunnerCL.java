import com.selenium.utillity.TestNGCucumberExecutable;
import cucumber.api.CucumberOptions;

import com.selenium.utillity.TestNGCucumberExecutable;
import cucumber.api.CucumberOptions;

@CucumberOptions(features = {"src/Feature"},
        glue = {"com.cucumber.stepdefinition"}
        /*      format = {"pretty",
                      "html:target/site/cucumber-pretty","json:target/cucumber-reports/cucumber.json"*/
        ,

        tags = {"@CreateTransaction_TC_01,@CreateTransaction_TC_02"},


//@NOT_Both_Solicitor_allPresent_API1
//@NotUATAc_multi_end_to_end_Test

        plugin = {"pretty", "html:target/site/cucumber-pretty", "json:target/cucumber-reports/cucumber.json", "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/ExtentReport.html"},
        //plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/Extentreport.html", "json:target/cucumber-reports/cucumber.json"},
        monochrome = true)
//AbstractTestNGCucumberTests
public class TestNGRunnerCL extends TestNGCucumberExecutable {

}