package com.cucumber.stepdefinition;

import com.cucumber.listener.Reporter;
import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.selenium.utillity.grafanaReusables;
import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assume;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
//import static com.selenium.utillity.Reusables.takeSnapShot;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
import static com.service.utillity.ReusableMethod.writeFullExcel;
//import static com.selenium.utillity.ScreenshotCapture.takeSnapShotOnFailure;
//import com.utilities.Log;
/*import io.cucumber.java.After;
import io.cucumber.java.Before;*/


public class BaseStep {

    public static String scenarioName;
    //@BeforeClass


    @Before
    public void intialization(Scenario scenario) throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();
        scenarioName = scenario.getName();
        Constants.key = new Reusables();
        FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//config.properties");
        Constants.CONFIG = new Properties();
        Constants.CONFIG.load(fs);


        //Titan Login OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanLoginOR.properties");
        Constants.TitanLoginOR = new Properties();
        Constants.TitanLoginOR.load(fs);

        //Titan Dashboard OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanDashboardOR.properties");
        Constants.TitanDashboardOR = new Properties();
        Constants.TitanDashboardOR.load(fs);

        //Titan Customers OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanCustomersOR.properties");
        Constants.TitanCustomersOR = new Properties();
        Constants.TitanCustomersOR.load(fs);

        //Titan Conflicts OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanConflictsOR.properties");
        Constants.TitanConflictsOR = new Properties();
        Constants.TitanConflictsOR.load(fs);

        //Titan TitanQueuesOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanQueuesOR.properties");
        Constants.TitanQueuesOR = new Properties();
        Constants.TitanQueuesOR.load(fs);

        //Titan TitanPaymentInOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanPaymentInOR.properties");
        Constants.TitanPaymentInOR = new Properties();
        Constants.TitanPaymentInOR.load(fs);

        //Titan TitanPayeeOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanPayeeOR.properties");
        Constants.TitanPayeeOR = new Properties();
        Constants.TitanPayeeOR.load(fs);

        //Titan TitanPayeeOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanFXTicketsOR.properties");
        Constants.TitanFXTicketsOR = new Properties();
        Constants.TitanFXTicketsOR.load(fs);

        //Titan TitanPaymentOutOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanPaymentOutOR.properties");
        Constants.TitanPaymentOutOR = new Properties();
        Constants.TitanPaymentOutOR.load(fs);

        //Titan TitanInstructionsOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanInstructionsOR.properties");
        Constants.TitanInstructionsOR = new Properties();
        Constants.TitanInstructionsOR.load(fs);

        //Titan TitanTreasuryOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanTreasuryOR.properties");
        Constants.TitanTreasuryOR = new Properties();
        Constants.TitanTreasuryOR.load(fs);

        //PFX OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//PFXOR.properties");
        Constants.PFXOR = new Properties();
        Constants.PFXOR.load(fs);
        //Calypso OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//CalypsologinPageOR.properties");
        Constants.CalypsologinPageOR = new Properties();
        Constants.CalypsologinPageOR.load(fs);

        //Titan TitanReportsOR OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//TitanReportsOR.properties");
        Constants.TitanReportsOR = new Properties();
        Constants.TitanReportsOR.load(fs);


        //Titan_Create FX Ticket
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java//com//Pages//Titan//CreateFxTicketOR.properties");
        Constants.CreateFxTicketOR = new Properties();
        Constants.CreateFxTicketOR.load(fs);

        //TitanCDSAPhase1OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java/com//Pages//Titan//TitanCDSAPhase1OR.properties");
        Constants.TitanCDSAPhase1OR = new Properties();
        Constants.TitanCDSAPhase1OR.load(fs);

        //TitanCDSA
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java/com//Pages//Titan//TitanCDSAPhase1OR.properties");
        Constants.TitanCDSAPhase1OR = new Properties();
        Constants.TitanCDSAPhase1OR.load(fs);
        //dbconfig
        FileInputStream db = new FileInputStream(System.getProperty("user.dir") + "//src//Config//dbconfig.properties");
        System.out.println("User dir:->"+System.getProperty("user.dir"));
        Constants.dbconfig = new Properties();
        Constants.dbconfig.load(db);

        fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//SQLQUERIES.properties");
        Constants.SQLQUERIES = new Properties();
        Constants.SQLQUERIES.load(fs);

        //DynamicConfig
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//Config//dynamicConfig.properties");
        Constants.OnTheFlyValue = new Properties();
        Constants.OnTheFlyValue.load(fs);

        //TitanCDSA
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java/com//Pages//Titan//KafkaUI.properties");
        Constants.KafkaUI = new Properties();
        Constants.KafkaUI.load(fs);

        //TitanCDSAPhase1OR
        fs = new FileInputStream(System.getProperty("user.dir") + "//src//test//java/com//Pages//Notary//PropertyPayDashboardOR.properties");
        Constants.PropertyPayDashboardOR = new Properties();
        Constants.PropertyPayDashboardOR.load(fs);

        Constants.DynamicValue = ReusableMethod.OnTheFlyValues(System.getProperty("user.dir") + "//src//Config//dynamicConfig.properties");

        Reporter.loadXMLConfig(new File(System.getProperty("user.dir") + "/extent-config.xml"));
        String testCaseID = scenario.getName().split("-")[0].trim();

        if(scenario.getName().contains("-")){
            Constants.SHEET_NAME = scenario.getName().split("-")[1].trim();
        }

        Constants.ApplicationName = Constants.SHEET_NAME;
        Constants.tcIDs = testCaseID;
        String isEnabled = Constants.APIkey.readExcel(testCaseID, "Execution");

        if ((Constants.driver == null)) {
//            LogCapture.info("--------------------------------API Validation Started for testcase " + testCaseID + "-------------------------");
            if (isEnabled != null) {
                Constants.Execution = isEnabled;
                if (isEnabled.equalsIgnoreCase("N") || isEnabled.equalsIgnoreCase("")) {
                    ReusableMethod.createReportParameters(testCaseID);
                    LogCapture.info("--------------------------------Test Case " + testCaseID + " is disabled in datasheet------------------");
                    Reporter.addScenarioLog("<b style=\"color:Red;\">*THIS TEST CASE HAS BEEN MARKED AS 'N' in APIData.xls present at /src/main/resources</b>");
                    Assume.assumeTrue(testCaseID + " is skipped", false);
                }
            }
        }

        LogCapture.startLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Test Case Validation Started <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");

        //-----------------Jenkins-Grafana checkpoint below-------------------------------
        try {
            grafanaReusables.startStopwatch("Start");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        //-----------------Jenkins-Grafana checkpoint above-------------------------------


    }

    @After
    //@AfterClass
    public void finish(Scenario scenario) throws Exception {


        if (!Constants.tcIDs.equalsIgnoreCase("Regression All")) {
            String status = scenario.getStatus().toUpperCase();
            if (status.equalsIgnoreCase("pending")) {
                status = "SKIPPED";
            }
            Object[][] bookData = null;
            if (Constants.counter == 0) {
                Constants.workbookRead = new XSSFWorkbook();
                Constants.sheetRead = Constants.workbookRead.createSheet("Final Report");
                bookData = new Object[][]{
                        {"Execution", "Application Name", "Test Case ID", "Scenario Name", "Status"}
                };
                System.out.println(bookData);
                writeFullExcel(bookData, 0);
            }
            Constants.counter++;
            if(Constants.Execution!=null){
                if (Constants.Execution.equalsIgnoreCase("Y")) {
                    bookData = new Object[][]{
                            {Constants.Execution, Constants.ApplicationName, Constants.tcIDs, scenarioName, status}
                    };
                } else {

                    bookData = new Object[][]{
                            {Constants.Execution, Constants.ApplicationName, Constants.tcIDs, scenarioName, status}
                    };

                }
            }
            System.out.println(bookData);
            writeFullExcel(bookData, Constants.counter);
        }
//        try{
            ReusableMethod.softAssert.assertAll();
            if (!(Constants.driver == null)) {
                if (Constants.CONFIG.getProperty("ScreenshotCaptureOnFailure").equalsIgnoreCase("True")) {
                    if (scenario.isFailed()) {
                        takeSnapShotOnFailure();
                    }
                }
            }
//        }
//        finally {
            if (!(Constants.driver == null)) {
                Constants.driver.close();
                Constants.driver.quit();
            }
//        }
        LogCapture.endLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Test Case Validation Ended <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");

        //-----------------Jenkins-Grafana checkpoint below-------------------------------
        grafanaReusables.triggerDataPopulation(scenario);
        //-----------------Jenkins-Grafana checkpoint above-------------------------------

    }

    public static void writeExtentReport() throws IOException {
        //Constants.key.deleteScreenShotFolderOnRun();
        Reporter.loadXMLConfig(new File(Constants.key.getReportConfigPath()));

    }



}