package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;
import com.utility.LogCapture;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static com.selenium.utillity.Constants.*;

public class PropertyPayStepDefination {

    @Then("^User Stores the values captured from the above response$")
    public void userStoresTheValuesCapturedFromTheAboveResponse() {
        JsonPath jp = new JsonPath(Constants.RESPONSE);
        Constants.responseMap.put("title", jp.get("data.title"));
        Constants.responseMap.put("firstName", jp.get("data.firstName"));
        Constants.responseMap.put("middleName", jp.get("data.middleName"));
        Constants.responseMap.put("lastName", jp.get("data.lastName"));
        Constants.responseMap.put("email", jp.get("data.email"));
        Constants.responseMap.put("contactNo", jp.get("data.contactNo"));
        Constants.responseMap.put("titanCustomerNo", jp.get("data.titanCustomerNo"));

        LogCapture.info("---------- Values Fetched from API ----------- ");

        if(Constants.responseMap.size() == 0){
            Assert.assertTrue(false, "****** No Values Found ******");
        }

        for(Map.Entry<String, String> entry :Constants.responseMap.entrySet()){
            LogCapture.info(entry.getKey() + ": " + entry.getValue() );
        }

        LogCapture.info("---------------------*******----------------------------");
    }

    @When("^User Connects with Titan \"([^\"]*)\" DB and Captures the values from ContactTable$")
    public void userConnectsWithTitanDBAndCapturesTheValuesFromContactTable(String Environment ) throws Throwable {
        Constants.key.VerifyDBDetails(Environment,Constants.responseMap.get("email") , "Connection To Contact Table");

        Constants.dbCapturedValues.put("title" , sqlResult.get("Salutation")) ;
        Constants.dbCapturedValues.put("firstName" , sqlResult.get("FirstName")) ;
        Constants.dbCapturedValues.put("middleName" , sqlResult.get("MiddleName")) ;
        Constants.dbCapturedValues.put("lastName" , sqlResult.get("LastName")) ;
        Constants.dbCapturedValues.put("email" , sqlResult.get("Emailaddress")) ;
        Constants.dbCapturedValues.put("contactNo" , sqlResult.get("MobilePhoneNumber")) ;
        Constants.dbCapturedValues.put("titanCustomerNo", sqlResult.get("AccountNumber"));


        LogCapture.info("---------- Values Captured From DB ----------");
        for (Map.Entry<String, String> dbValue : Constants.dbCapturedValues.entrySet()){
            LogCapture.info(dbValue.getKey() +": " + dbValue.getValue());
        }
        LogCapture.info("---------------------*******----------------------------");
        Assert.assertTrue(Constants.responseMap.equals(Constants.dbCapturedValues));
    }

    @Then("^User landed on Homepage Dashboard to verify details$")
    public void userLandedOnHomepageDashboardToVerifyDetails() throws Exception {

        String vobjPropertyPayLogo = Constants.PropertyPayDashboardOR.getProperty("PropertyPayLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPropertyPayLogo, "visible"));
        LogCapture.info("User verified Property Pay logo is visible");

        String vobjSidebarDashboard = Constants.PropertyPayDashboardOR.getProperty("SidebarDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarDashboard, "Dashboard"));
        LogCapture.info("User verified Dashboard option is visible under Sidebar");

        String vobjSidebarContactUs = Constants.PropertyPayDashboardOR.getProperty("SidebarContactUs");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarContactUs, "Contact us"));
        LogCapture.info("User verified Contact us option is visible under Sidebar");

        String vobjSidebarSettings = Constants.PropertyPayDashboardOR.getProperty("SidebarSettings");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarSettings, "Settings"));
        LogCapture.info("User verified Settings option is visible under Sidebar");

        String vobjFooterTerms = Constants.PropertyPayDashboardOR.getProperty("FooterTerms");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterTerms, "Terms"));
        LogCapture.info("User verified Terms option is visible under footer of the Sidebar");

        String vobjFooterPrivacy = Constants.PropertyPayDashboardOR.getProperty("FooterPrivacy");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterPrivacy, "Privacy"));
        LogCapture.info("User verified Privacy option is visible under footer of the Sidebar");

        String vobjFooterCookies = Constants.PropertyPayDashboardOR.getProperty("FooterCookies");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterCookies, "Cookies"));
        LogCapture.info("User verified Cookies option is visible under footer of the Sidebar");

        String vobjFooterRegulatory = Constants.PropertyPayDashboardOR.getProperty("FooterRegulatory");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterRegulatory, "Regulatory"));
        LogCapture.info("User verified Regulatory option is visible under footer of the Sidebar");

        String vobjFooterRedpinLogo = Constants.PropertyPayDashboardOR.getProperty("FooterRedpinLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFooterRedpinLogo, "visible"));
        LogCapture.info("User verified Redpin logo is visible under footer");

        String vobjRecentTransactionsHeader = Constants.PropertyPayDashboardOR.getProperty("RecentTransactionsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRecentTransactionsHeader, "Recent transactions"));
        LogCapture.info("User verified Header as Recent transactions is visible on Dashboard");

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCreateTransactionButton, "Create transaction"));
        LogCapture.info("User verified Create transaction button is visible on Dashboard");

        String vobjUserNameDashboard = Constants.PropertyPayDashboardOR.getProperty("UserNameDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjUserNameDashboard, "Ram Gopal"));
        LogCapture.info("User verified username as Ram Gopal is visible on Dashboard");

        String vobjFirstAndLastNameInitials = Constants.PropertyPayDashboardOR.getProperty("FirstAndLastNameInitials");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFirstAndLastNameInitials, "TE"));
        LogCapture.info("User verified Initials of First name and last name as TE is visible on Dashboard");

        String vobjDashboardColumnHeaderTransactionsDetails = Constants.PropertyPayDashboardOR.getProperty("DashboardColumnHeaderTransactionsDetails");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardColumnHeaderTransactionsDetails, "Transaction details"));
        LogCapture.info("User verified column header as Transaction details is visible on Dashboard");

        String vobjDashboardColumnHeaderPartyName = Constants.PropertyPayDashboardOR.getProperty("DashboardColumnHeaderPartyName");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardColumnHeaderPartyName, "Party name"));
        LogCapture.info("User verified column header as Party name is visible on Dashboard");

        String vobjDashboardColumnHeaderStatus = Constants.PropertyPayDashboardOR.getProperty("DashboardColumnHeaderStatus");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardColumnHeaderStatus, "Status"));
        LogCapture.info("User verified column header as Status is visible on Dashboard");

        String vobjDashboardColumnHeaderCompletionDue = Constants.PropertyPayDashboardOR.getProperty("DashboardColumnHeaderCompletionDue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardColumnHeaderCompletionDue, "Completion due"));
        LogCapture.info("User verified column header as Completion due is visible on Dashboard");

        String vobjDashboardFilterAll = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterAll");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterAll, "All"));
        LogCapture.info("User verified filter for All transactions is visible on Dashboard");

        String vobjDashboardFilterOpen = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterOpen");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterOpen, "Open"));
        LogCapture.info("User verified filter for Open transactions is visible on Dashboard");

        String vobjDashboardFilterCompleted = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterCompleted");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterCompleted, "Completed"));
        LogCapture.info("User verified filter for Completed transactions is visible on Dashboard");

        String vobjDashboardFilterCancelled = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterCancelled");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterCancelled, "Cancelled"));
        LogCapture.info("User verified filter for Cancelled transactions is visible on Dashboard");

        String vobjDashboardFilterDraft = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterDraft");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterDraft, "Draft"));
        LogCapture.info("User verified filter for Draft transactions is visible on Dashboard");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String currentTime = now.format(timeFormatter);

        LocalTime GoodNightstartTime = LocalTime.of(00, 00, 01); // 00:00:01
        LocalTime GoodNightendTime = LocalTime.of(05, 59, 59);  // 05:59:59

        LocalTime GoodMorningstartTime = LocalTime.of(06, 00, 01); // 06:00:01
        LocalTime GoodMorningendTime = LocalTime.of(11, 59, 59);  // 11:59:59
        LocalTime currentLocalTime = LocalTime.parse(currentTime, timeFormatter);

        LocalTime GoodAfternoonstartTime = LocalTime.of(12, 0, 01); // 12:00:01
        LocalTime GoodAfternoonendTime = LocalTime.of(17, 59, 59);  // 17:59:59

        LocalTime GoodEveningstartTime = LocalTime.of(18, 0, 01); // 18:00:01
        LocalTime GoodEveningendTime = LocalTime.of(23, 59, 59);  // 23:59:59

        String vObjDashboardGreetingMessage = Constants.PropertyPayDashboardOR.getProperty("DashboardGreetingMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDashboardGreetingMessage, ""));
        String greetingMessage = Constants.driver.findElement(By.xpath(vObjDashboardGreetingMessage)).getText();

        // Compare current time within the range
        if (currentLocalTime.isAfter(GoodNightstartTime) && currentLocalTime.isBefore(GoodNightendTime)) {

            if(greetingMessage.contains("Good night"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Night");
                Assert.fail();
            }

        }

        if (currentLocalTime.isAfter(GoodMorningstartTime) && currentLocalTime.isBefore(GoodMorningendTime)) {

            if(greetingMessage.contains("Good morning"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Morning");
                Assert.fail();
            }
        }

        if (currentLocalTime.isAfter(GoodAfternoonstartTime) && currentLocalTime.isBefore(GoodAfternoonendTime)) {

            if(greetingMessage.contains("Good afternoon"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Afternoon");
                Assert.fail();
            }
        }

        if (currentLocalTime.isAfter(GoodEveningstartTime) && currentLocalTime.isBefore(GoodEveningendTime)) {

            if(greetingMessage.contains("Good evening"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Evening");
                Assert.fail();
            }
        }



    }

    @Then("^User landed on Homepage Dashboard to verify details in Mobile view$")
    public void userLandedOnHomepageDashboardToVerifyDetailsInMobileView() throws Exception {

        String vobjPropertyPayLogo = Constants.PropertyPayDashboardOR.getProperty("PropertyPayLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPropertyPayLogo, "visible"));
        LogCapture.info("User verified Property Pay logo is visible");

        String vobjRecentTransactionsHeader = Constants.PropertyPayDashboardOR.getProperty("RecentTransactionsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRecentTransactionsHeader, "Recent transactions"));
        LogCapture.info("User verified Header as Recent transactions is visible on Dashboard");

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCreateTransactionButton, "Create transaction"));
        LogCapture.info("User verified Create transaction button is visible on Dashboard");

        String vobjHeaderMenuIcon = Constants.PropertyPayDashboardOR.getProperty("HeaderMenuIcon");
        Assert.assertEquals("PASS", Constants.key.click(vobjHeaderMenuIcon, ""));
        LogCapture.info("User click on Header Menu Icon");

        String vobjSidebarDashboard = Constants.PropertyPayDashboardOR.getProperty("SidebarDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarDashboard, "Dashboard"));
        LogCapture.info("User verified Dashboard option is visible under Sidebar");

        String vobjSidebarContactUs = Constants.PropertyPayDashboardOR.getProperty("SidebarContactUs");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarContactUs, "Contact us"));
        LogCapture.info("User verified Contact us option is visible under Sidebar");

        String vobjSidebarSettings = Constants.PropertyPayDashboardOR.getProperty("SidebarSettings");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarSettings, "Settings"));
        LogCapture.info("User verified Settings option is visible under Sidebar");

        String vobjUserNameDashboardMobile = Constants.PropertyPayDashboardOR.getProperty("UserNameDashboardMobile");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjUserNameDashboardMobile, "Ram Gopal"));
        LogCapture.info("User verified username as Ram Gopal is visible on Dashboard");

        String vobjFirstAndLastNameInitialsMobile = Constants.PropertyPayDashboardOR.getProperty("FirstAndLastNameInitialsMobile");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFirstAndLastNameInitialsMobile, "TE"));
        LogCapture.info("User verified Initials of First name and last name as TE is visible on Dashboard");

        String vobjCloseSidebarMobile = Constants.PropertyPayDashboardOR.getProperty("CloseSidebarMobile");
        Assert.assertEquals("PASS", Constants.key.click(vobjCloseSidebarMobile, ""));
        LogCapture.info("User click on Close sidebar button");

        String vobjMobileViewFilter = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilter");
        Assert.assertEquals("PASS", Constants.key.click(vobjMobileViewFilter, ""));
        LogCapture.info("User click on Filter button");

        String vobjMobileViewFilterList = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilterList");
        List<WebElement> elements = driver.findElements(By.xpath(vobjMobileViewFilterList));
        int numberOfElements = elements.size();

        for(int i=1; i<=numberOfElements; i++)
        {
            String FilterOptions = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li["+i+"]";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();

            if(ActualFilterOptions.equals("All") || ActualFilterOptions.equals("Open") || ActualFilterOptions.equals("Completed") || ActualFilterOptions.equals("Cancelled") || ActualFilterOptions.equals("Draft"))
            {
                LogCapture.info("User verified filter "+i+" with search option "+ActualFilterOptions+" is Present");
            }else
            {
                LogCapture.info("TC FailedUser verified filter with search option "+ActualFilterOptions+" is not Present");
                Assert.fail();
            }
        }

        String vobjMobileSearchBar = Constants.PropertyPayDashboardOR.getProperty("MobileSearchBar");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjMobileSearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileSearchBar, ""));
        LogCapture.info("User click on Search bar");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjMobileSearchBar, "REF98785"));
        LogCapture.info("User entered value as REF98785 in search bar ");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileSearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vobjMobileSearchBar));
        LogCapture.info("User Cleared value from search bar ");



    }

    @Then("^User landed on Homepage Dashboard to verify details in Tablet view$")
    public void userLandedOnHomepageDashboardToVerifyDetailsInTabletView() throws Exception {

        String vobjPropertyPayLogo = Constants.PropertyPayDashboardOR.getProperty("PropertyPayLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPropertyPayLogo, "visible"));
        LogCapture.info("User verified Property Pay logo is visible");

        String vobjTabletToggleBarExpansion = Constants.PropertyPayDashboardOR.getProperty("TabletToggleBarExpansion");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTabletToggleBarExpansion, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTabletToggleBarExpansion, ""));
        LogCapture.info("User click on expand sidebar in tablet view");

        String vobjSidebarDashboard = Constants.PropertyPayDashboardOR.getProperty("SidebarDashboard");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSidebarDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarDashboard, "Dashboard"));
        LogCapture.info("User verified Dashboard option is visible under Sidebar");

        String vobjSidebarContactUs = Constants.PropertyPayDashboardOR.getProperty("SidebarContactUs");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarContactUs, "Contact us"));
        LogCapture.info("User verified Contact us option is visible under Sidebar");

        String vobjSidebarSettings = Constants.PropertyPayDashboardOR.getProperty("SidebarSettings");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarSettings, "Settings"));
        LogCapture.info("User verified Settings option is visible under Sidebar");

        String vobjFooterTerms = Constants.PropertyPayDashboardOR.getProperty("FooterTerms");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterTerms, "Terms"));
        LogCapture.info("User verified Terms option is visible under footer of the Sidebar");

        String vobjFooterPrivacy = Constants.PropertyPayDashboardOR.getProperty("FooterPrivacy");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterPrivacy, "Privacy"));
        LogCapture.info("User verified Privacy option is visible under footer of the Sidebar");

        String vobjFooterCookies = Constants.PropertyPayDashboardOR.getProperty("FooterCookies");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterCookies, "Cookies"));
        LogCapture.info("User verified Cookies option is visible under footer of the Sidebar");

        String vobjFooterRegulatory = Constants.PropertyPayDashboardOR.getProperty("FooterRegulatory");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterRegulatory, "Regulatory"));
        LogCapture.info("User verified Regulatory option is visible under footer of the Sidebar");

        String vobjFooterRedpinLogo = Constants.PropertyPayDashboardOR.getProperty("FooterRedpinLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFooterRedpinLogo, "visible"));
        LogCapture.info("User verified Redpin logo is visible under footer");

        String vobjTabletToggleBarClosure = Constants.PropertyPayDashboardOR.getProperty("TabletToggleBarClosure");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTabletToggleBarClosure, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTabletToggleBarClosure, ""));
        LogCapture.info("User click on Close sidebar in tablet view");

        String vobjRecentTransactionsHeader = Constants.PropertyPayDashboardOR.getProperty("RecentTransactionsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRecentTransactionsHeader, "Recent transactions"));
        LogCapture.info("User verified Header as Recent transactions is visible on Dashboard");

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCreateTransactionButton, "Create transaction"));
        LogCapture.info("User verified Create transaction button is visible on Dashboard");

        String vobjUserNameDashboard = Constants.PropertyPayDashboardOR.getProperty("UserNameDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjUserNameDashboard, "Ram Gopal"));
        LogCapture.info("User verified username as Ram Gopal is visible on Dashboard");

        String vobjFirstAndLastNameInitials = Constants.PropertyPayDashboardOR.getProperty("FirstAndLastNameInitials");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFirstAndLastNameInitials, "TE"));
        LogCapture.info("User verified Initials of First name and last name as TE is visible on Dashboard");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String currentTime = now.format(timeFormatter);

        LocalTime GoodNightstartTime = LocalTime.of(00, 00, 01); // 00:00:01
        LocalTime GoodNightendTime = LocalTime.of(05, 59, 59);  // 05:59:59

        LocalTime GoodMorningstartTime = LocalTime.of(06, 00, 01); // 06:00:01
        LocalTime GoodMorningendTime = LocalTime.of(11, 59, 59);  // 11:59:59
        LocalTime currentLocalTime = LocalTime.parse(currentTime, timeFormatter);

        LocalTime GoodAfternoonstartTime = LocalTime.of(12, 0, 01); // 12:00:01
        LocalTime GoodAfternoonendTime = LocalTime.of(17, 59, 59);  // 17:59:59

        LocalTime GoodEveningstartTime = LocalTime.of(18, 0, 01); // 18:00:01
        LocalTime GoodEveningendTime = LocalTime.of(23, 59, 59);  // 23:59:59

        String vObjDashboardGreetingMessage = Constants.PropertyPayDashboardOR.getProperty("DashboardGreetingMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDashboardGreetingMessage, ""));
        String greetingMessage = Constants.driver.findElement(By.xpath(vObjDashboardGreetingMessage)).getText();

        // Compare current time within the range
        if (currentLocalTime.isAfter(GoodNightstartTime) && currentLocalTime.isBefore(GoodNightendTime)) {

            if(greetingMessage.contains("Good night"))
            {
                LogCapture.info("User verified greeting message as " +greetingMessage);
            }
            else
            {
                LogCapture.info("TC Failed : User unable to verify Greeting message for Night");
                Assert.fail();
            }

        }

        if (currentLocalTime.isAfter(GoodMorningstartTime) && currentLocalTime.isBefore(GoodMorningendTime)) {

            if(greetingMessage.contains("Good morning"))
            {
                LogCapture.info("User verified greeting message as " +greetingMessage);
            }
            else
            {
                LogCapture.info("TC Failed : User unable to verify Greeting message for Morning");
                Assert.fail();
            }
        }

        if (currentLocalTime.isAfter(GoodAfternoonstartTime) && currentLocalTime.isBefore(GoodAfternoonendTime)) {

            if(greetingMessage.contains("Good afternoon"))
            {
                LogCapture.info("User verified greeting message as " +greetingMessage);
            }
            else
            {
                LogCapture.info("TC Failed : User unable to verify Greeting message for Afternoon");
                Assert.fail();
            }
        }

        if (currentLocalTime.isAfter(GoodEveningstartTime) && currentLocalTime.isBefore(GoodEveningendTime)) {

            if(greetingMessage.contains("Good evening"))
            {
                LogCapture.info("User verified greeting message as " +greetingMessage);
            }
            else
            {
                LogCapture.info("TC Failed : User unable to verify Greeting message for Evening");
                Assert.fail();
            }
        }


        String vobjMobileViewFilter = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilter");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileViewFilter, ""));
        LogCapture.info("User click on Filter button");

        String vobjMobileViewFilterList = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilterList");
        List<WebElement> elements = driver.findElements(By.xpath(vobjMobileViewFilterList));
        int numberOfElements = elements.size();

        for(int i=1; i<=numberOfElements; i++)
        {
            String FilterOptions = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li["+i+"]";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();

            if(ActualFilterOptions.equals("All") || ActualFilterOptions.equals("Open") || ActualFilterOptions.equals("Completed") || ActualFilterOptions.equals("Cancelled") || ActualFilterOptions.equals("Draft"))
            {
                LogCapture.info("User verified filter "+i+" with search option "+ActualFilterOptions+" is Present");
            }else
            {
                LogCapture.info("TC FailedUser verified filter with search option "+ActualFilterOptions+" is not Present");
                Assert.fail();
            }
        }

        String vobjMobileSearchBar = Constants.PropertyPayDashboardOR.getProperty("MobileSearchBar");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjMobileSearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileSearchBar, ""));
        LogCapture.info("User click on Search bar");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjMobileSearchBar, "REF98785"));
        LogCapture.info("User entered value as REF98785 in search bar ");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileSearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vobjMobileSearchBar));
        LogCapture.info("User Cleared value from search bar ");

    }


    @Then("^User apply filters to verify data on Homepage Dashboard in Desktop view$")
    public void userApplyFiltersToVerifyDataOnHomepageDashboardInDesktopView() throws Exception {

        String vobjPropertyPayLogo = Constants.PropertyPayDashboardOR.getProperty("PropertyPayLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPropertyPayLogo, "visible"));
        LogCapture.info("User verified Property Pay logo is visible");

        String vobjRecentTransactionsHeader = Constants.PropertyPayDashboardOR.getProperty("RecentTransactionsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRecentTransactionsHeader, "Recent transactions"));
        LogCapture.info("User verified Header as Recent transactions is visible on Dashboard");

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCreateTransactionButton, "Create transaction"));
        LogCapture.info("User verified Create transaction button is visible on Dashboard");

        String vobjUserNameDashboard = Constants.PropertyPayDashboardOR.getProperty("UserNameDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjUserNameDashboard, "Ram Gopal"));
        LogCapture.info("User verified username as Ram Gopal is visible on Dashboard");

        String vobjFirstAndLastNameInitials = Constants.PropertyPayDashboardOR.getProperty("FirstAndLastNameInitials");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFirstAndLastNameInitials, "TE"));
        LogCapture.info("User verified Initials of First name and last name as TE is visible on Dashboard");

        String vobjFilterOptionAll = Constants.PropertyPayDashboardOR.getProperty("FilterOptionAll");

        String vobjFilterOptionOpen = Constants.PropertyPayDashboardOR.getProperty("FilterOptionOpen");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjFilterOptionOpen, ""));
        LogCapture.info("User clicked on Open option from Filter on Dashboard");
        Thread.sleep(3000);

        String vobjFilterStatusListDashboard = Constants.PropertyPayDashboardOR.getProperty("FilterStatusListDashboard");
        List<WebElement> elements = driver.findElements(By.xpath(vobjFilterStatusListDashboard));
        int numberOfElements = elements.size();

        for(int i=1; i<=numberOfElements; i++)
        {
            String StatusOptions = "(//p[@class='css-1xnrui7'])["+i+"]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(StatusOptions, ""));
            String ActualStatus = Constants.driver.findElement(By.xpath(StatusOptions)).getText();

            if(ActualStatus.equals("Open"))
            {
                LogCapture.info("User verified "+i+" transactions with status as "+ActualStatus+" is Present");
            }else
            {
                LogCapture.info("TC Failed : Unable to verify transactions with status as Open");
                Assert.fail();
            }
        }

        String vobjFilterOptionCompleted = Constants.PropertyPayDashboardOR.getProperty("FilterOptionCompleted");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjFilterOptionCompleted, ""));
        LogCapture.info("User clicked on Completed option from Filter on Dashboard");
        Thread.sleep(3000);

        List<WebElement> Completedelements = driver.findElements(By.xpath(vobjFilterStatusListDashboard));
        int numberOfCompletedelements = Completedelements.size();

        for(int i=1; i<=numberOfCompletedelements; i++)
        {
            String StatusOptions = "(//p[@class='css-1xnrui7'])["+i+"]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(StatusOptions, ""));
            String ActualStatus = Constants.driver.findElement(By.xpath(StatusOptions)).getText();

            if(ActualStatus.equals("Completed"))
            {
                LogCapture.info("User verified "+i+" transactions with status as "+ActualStatus+" is Present");
            }else
            {
                LogCapture.info("TC Failed : Unable to verify transactions with status as Completed");
                Assert.fail();
            }
        }

        String vobjFilterOptionCancelled = Constants.PropertyPayDashboardOR.getProperty("FilterOptionCancelled");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjFilterOptionCancelled, ""));
        LogCapture.info("User clicked on Cancelled option from Filter on Dashboard");
        Thread.sleep(3000);

        List<WebElement> Cancelledelements = driver.findElements(By.xpath(vobjFilterStatusListDashboard));
        int numberOfCancelledelements = Cancelledelements.size();

        for(int i=1; i<=numberOfCancelledelements; i++)
        {
            String StatusOptions = "(//p[@class='css-1xnrui7'])["+i+"]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(StatusOptions, ""));
            String ActualStatus = Constants.driver.findElement(By.xpath(StatusOptions)).getText();

            if(ActualStatus.equals("Cancelled"))
            {
                LogCapture.info("User verified "+i+" transactions with status as "+ActualStatus+" is Present");
            }else
            {
                LogCapture.info("TC Failed : Unable to verify transactions with status as Cancelled");
                Assert.fail();
            }
        }


        String vobjFilterOptionDraft = Constants.PropertyPayDashboardOR.getProperty("FilterOptionDraft");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjFilterOptionDraft, ""));
        LogCapture.info("User clicked on Draft option from Filter on Dashboard");
        Thread.sleep(3000);

        List<WebElement> Draftelements = driver.findElements(By.xpath(vobjFilterStatusListDashboard));
        int numberOfDraftelements = Draftelements.size();

        for(int i=1; i<=numberOfDraftelements; i++)
        {
            String StatusOptions = "(//p[@class='css-1xnrui7'])["+i+"]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(StatusOptions, ""));
            String ActualStatus = Constants.driver.findElement(By.xpath(StatusOptions)).getText();

            if(ActualStatus.equals("Draft"))
            {
                LogCapture.info("User verified "+i+" transactions with status as "+ActualStatus+" is Present");
            }else
            {
                LogCapture.info("TC Failed : Unable to verify transactions with status as Draft");
                Assert.fail();
            }
        }



    }

    @Then("^User apply filters to verify data on Homepage Dashboard in (Tablet|Mobile) view$")
    public void userApplyFiltersToVerifyDataOnHomepageDashboardInTabletView(String Devicetype) throws Exception {

        String vobjPropertyPayLogo = Constants.PropertyPayDashboardOR.getProperty("PropertyPayLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPropertyPayLogo, "visible"));
        LogCapture.info("User verified Property Pay logo is visible");

        String vobjMobileViewFilter = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilter");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileViewFilter, ""));
        LogCapture.info("User click on Filter button");

        String vobjMobileViewFilterList = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilterList");
        List<WebElement> elements = driver.findElements(By.xpath(vobjMobileViewFilterList));
        int numberOfElements = elements.size();

        for(int i=1; i<=numberOfElements; i++)
        {
            String FilterOptions = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li["+i+"]";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();

            if(ActualFilterOptions.equals("Open"))
            {
                String OpenFilter = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li//p[text()='Open']";
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(OpenFilter, ""));
                LogCapture.info("User clicked on Open from Filter on Dashboard");
                Thread.sleep(3000);

                String vobjFilterStatusListDashboard = Constants.PropertyPayDashboardOR.getProperty("FilterStatusListDashboard");
                List<WebElement> Openelements = driver.findElements(By.xpath(vobjFilterStatusListDashboard));
                int numberOfOpenelements = Openelements.size();

                for(int j=1; j<=numberOfOpenelements; j++)
                {
                    String StatusOptions = "(//p[@class='css-1xnrui7'])["+j+"]";
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(StatusOptions, ""));
                    String ActualStatus = Constants.driver.findElement(By.xpath(StatusOptions)).getText();

                    if(ActualStatus.equals("Open"))
                    {
                        LogCapture.info("User verified "+j+" transactions with status as "+ActualStatus+" is Present");
                    }else
                    {
                        LogCapture.info("TC Failed : Unable to verify transactions with status as Open");
                        Assert.fail();
                    }
                }

                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileViewFilter, ""));
                LogCapture.info("User click on Filter button");

            }else if(ActualFilterOptions.equals("Completed"))
            {
                String OpenFilter = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li//p[text()='Completed']";
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(OpenFilter, ""));
                LogCapture.info("User clicked on Completed from Filter on Dashboard");
                Thread.sleep(3000);

                String vobjFilterStatusListDashboard = Constants.PropertyPayDashboardOR.getProperty("FilterStatusListDashboard");
                List<WebElement> Completedelements = driver.findElements(By.xpath(vobjFilterStatusListDashboard));
                int numberOfCompletedelements = Completedelements.size();

                for(int j=1; j<=numberOfCompletedelements; j++)
                {
                    String StatusOptions = "(//p[@class='css-1xnrui7'])["+j+"]";
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(StatusOptions, ""));
                    String ActualStatus = Constants.driver.findElement(By.xpath(StatusOptions)).getText();

                    if(ActualStatus.equals("Completed"))
                    {
                        LogCapture.info("User verified "+j+" transactions with status as "+ActualStatus+" is Present");
                    }else
                    {
                        LogCapture.info("TC Failed : Unable to verify transactions with status as Completed");
                        Assert.fail();
                    }
                }
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileViewFilter, ""));
                LogCapture.info("User click on Filter button");
            }
            else if(ActualFilterOptions.equals("Cancelled"))
            {
                String CancelledFilter = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li//p[text()='Cancelled']";
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CancelledFilter, ""));
                LogCapture.info("User clicked on Cancelled from Filter on Dashboard");
                Thread.sleep(3000);

                String vobjFilterStatusListDashboard = Constants.PropertyPayDashboardOR.getProperty("FilterStatusListDashboard");
                List<WebElement> Cancelledelements = driver.findElements(By.xpath(vobjFilterStatusListDashboard));
                int numberOfCancelledelements = Cancelledelements.size();

                for(int j=1; j<=numberOfCancelledelements; j++)
                {
                    String StatusOptions = "(//p[@class='css-1xnrui7'])["+j+"]";
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(StatusOptions, ""));
                    String ActualStatus = Constants.driver.findElement(By.xpath(StatusOptions)).getText();

                    if(ActualStatus.equals("Cancelled"))
                    {
                        LogCapture.info("User verified "+j+" transactions with status as "+ActualStatus+" is Present");
                    }else
                    {
                        LogCapture.info("TC Failed : Unable to verify transactions with status as Cancelled");
                        Assert.fail();
                    }
                }
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileViewFilter, ""));
                LogCapture.info("User click on Filter button");
            }
            else if(ActualFilterOptions.equals("Draft"))
            {
                String DraftFilter = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li//p[text()='Draft']";
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(DraftFilter, ""));
                LogCapture.info("User clicked on Draft from Filter on Dashboard");
                Thread.sleep(3000);

                String vobjFilterStatusListDashboard = Constants.PropertyPayDashboardOR.getProperty("FilterStatusListDashboard");
                List<WebElement> Draftelements = driver.findElements(By.xpath(vobjFilterStatusListDashboard));
                int numberOfDraftelements = Draftelements.size();

                for(int j=1; j<=numberOfDraftelements; j++)
                {
                    String StatusOptions = "(//p[@class='css-1xnrui7'])["+j+"]";
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(StatusOptions, ""));
                    String ActualStatus = Constants.driver.findElement(By.xpath(StatusOptions)).getText();

                    if(ActualStatus.equals("Draft"))
                    {
                        LogCapture.info("User verified "+j+" transactions with status as "+ActualStatus+" is Present");
                    }else
                    {
                        LogCapture.info("TC Failed : Unable to verify transactions with status as Draft");
                        Assert.fail();
                    }
                }
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileViewFilter, ""));
                LogCapture.info("User click on Filter button");
            }
        }
    }

    @Then("^User Click on create transactions button$")
    public void userClickOnCreateTransactionsButton() throws Exception {

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionButton, ""));
        LogCapture.info("User clicked on Create Transaction button from Dashboard");
        Thread.sleep(2000);

        String vobjTransactionDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("TransactionDetailsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTransactionDetailsHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjTransactionDetailsHeader, "Transaction details"));
        LogCapture.info("User verified TransactionDetails Header from dashboard");


    }

    @Then("^User Click on create transactions button for Mobile$")
    public void userClickOnCreateTransactionsButtonForMobile() throws Exception {

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionButton, ""));
        LogCapture.info("User clicked on Create Transaction button from Dashboard");
        Thread.sleep(2000);

        String vobjTransactionDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("TransactionDetailsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTransactionDetailsHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjTransactionDetailsHeader, "Transaction details"));
        LogCapture.info("User verified TransactionDetails Header from dashboard");

        String vobjMobileViewTransactionDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("MobileViewTransactionDetailsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjMobileViewTransactionDetailsHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjMobileViewTransactionDetailsHeader, "Transaction details"));
        LogCapture.info("User verified Transaction details header on create transaction page");

    }

    @And("^User enter details on create transaction, country as \"([^\"]*)\" , Currency as \"([^\"]*)\" and Address as \"([^\"]*)\" and click on Save and Continue$")
    public void userEnterDetailsOnCreateTransactionCountryAsCurrencyAsAndAddressAsAndClickOnSaveAndContinue(String ExpCountry, String ExpCurrencyOptions, String ExpAddress) throws Throwable {

        PPPropertyAddress=ExpAddress;
        String vobjCreateTransactionSaveAndContinueButtone = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionSaveAndContinueButton");
        WebElement button = driver.findElement(By.cssSelector(vobjCreateTransactionSaveAndContinueButtone));
        boolean isDisabled = !button.isEnabled();
        if (isDisabled) {
            LogCapture.info("User verify Save and Continue button is Disabled before entering details.");
        } else {
            LogCapture.info("TC Failed : Save and continue Button is Enable");
            Assert.fail();
        }

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("ddMMyyyyHHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        String vobjFileReference = Constants.PropertyPayDashboardOR.getProperty("FileReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFileReference, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFileReference, ""));
        PPFileReference="AUTOS4UR48H"+CurrentTimeTimeHHMM;
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjFileReference, PPFileReference));
        LogCapture.info("User entered Reference as" + "AUTOS4UR48H"+CurrentTimeTimeHHMM);

            String Valuedate;
            String vObjCalendar = "//button[@aria-label='Choose date']//*[name()='svg']";
            String calender= key.notexist(vObjCalendar, "");
            if(calender.equalsIgnoreCase("PASS")){
                String vObjCalendar2 = "//input[@id='completionDate']";
                Assert.assertEquals("PASS", key.VisibleConditionWait(vObjCalendar2, ""));
                Assert.assertEquals("PASS", key.Mouse_Events(vObjCalendar2, ""));
                Assert.assertEquals("PASS", key.pause("2", ""));
            }
            else{
                Assert.assertEquals("PASS", key.VisibleConditionWait(vObjCalendar, ""));
                Assert.assertEquals("PASS", key.Mouse_Events(vObjCalendar, ""));
                Assert.assertEquals("PASS", key.pause("2", ""));
            }

            DateFormat dayFormat = new SimpleDateFormat("d"); // 'd' removes leading zero
            DateFormat monthFormat = new SimpleDateFormat("MM");

            Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            cal.add(Calendar.DATE, 5);

            Valuedate = dayFormat.format(cal.getTime());
            String targetMonth = monthFormat.format(cal.getTime());
            String currentMonth = monthFormat.format(new Date());

            if (!targetMonth.equals(currentMonth)) {
                String vObjNextMonthButton = "//button[@title='Next month']";
                Assert.assertEquals("PASS", key.VisibleConditionWait(vObjNextMonthButton, ""));
                Assert.assertEquals("PASS", key.Mouse_Events(vObjNextMonthButton, ""));
                Assert.assertEquals("PASS", key.pause("2", ""));
            }

            String vObjCompletionDate = "//button[text()='" + Valuedate + "' and @class='MuiButtonBase-root MuiPickersDay-root MuiPickersDay-dayWithMargin css-kbsjfq']";
            Assert.assertEquals("PASS", key.navigateSubMenu(vObjCompletionDate, ""));

            DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Calendar Calender1 = Calendar.getInstance();
            Calender1.setTime(new Date());
            Calender1.add(Calendar.DATE, 5);
            String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
            LogCapture.info("User select completion date as " + CompletionDate);


            String calenderOk= key.notexist(vObjCalendar, "");
            if(calender.equalsIgnoreCase("PASS")){
                String vObjOk = "//button[@type='button' and text()='OK']";
                Assert.assertEquals("PASS", key.VisibleConditionWait(vObjOk, ""));
                Assert.assertEquals("PASS", key.Mouse_Events(vObjOk, ""));
                Assert.assertEquals("PASS", key.pause("2", ""));
            }

//        String Valuedate;
//        String vObjCalendar = Constants.PropertyPayDashboardOR.getProperty("CalenderButton");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCalendar, ""));
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCalendar, ""));
//        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//        DateFormat dateFormat = new SimpleDateFormat("dd");
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(new Date());
//        cal.add(Calendar.DATE, 2);
//        Valuedate = dateFormat.format(cal.getTime());
//        String vObjComplectionDate1="";
//        String vObjComplectionDate2="";
//        String ComplectionDate = "//button[text()='"+Valuedate+"']";
//
//        List<WebElement> Dateelements = driver.findElements(By.xpath(ComplectionDate));
//        int numberOfDateElements = Dateelements.size();
//        if(numberOfDateElements==2)
//        {
//            vObjComplectionDate1 ="(//button[text()='"+Valuedate+"'])[1]";
//            vObjComplectionDate2 ="(//button[text()='"+Valuedate+"'])[2]";
//
//            String DateAttribute1 = driver.findElement(By.xpath(vObjComplectionDate1)).getAttribute("class");
//            String DateAttribute2 = driver.findElement(By.xpath(vObjComplectionDate2)).getAttribute("class");
//
//            if (!DateAttribute1.contains("disabled"))
//            {
//                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate1, ""));
//                DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
//                Calendar Calender1 = Calendar.getInstance();
//                Calender1.setTime(new Date());
//                Calender1.add(Calendar.DATE, 2);
//                String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
//                LogCapture.info("User select completion date as " + CompletionDate);
//            }
//
//            if (!DateAttribute2.contains("disabled"))
//            {
//                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate2, ""));
//                DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
//                Calendar Calender1 = Calendar.getInstance();
//                Calender1.setTime(new Date());
//                Calender1.add(Calendar.DATE, 2);
//                String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
//                LogCapture.info("User select completion date as " + CompletionDate);
//            }
//        }else
//        {
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate1, ""));
//            DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
//            Calendar Calender1 = Calendar.getInstance();
//            Calender1.setTime(new Date());
//            Calender1.add(Calendar.DATE, 2);
//            String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
//            LogCapture.info("User select completion date as " + CompletionDate);
//        }

        String vobjCreateTransactionCountry = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionCountry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionCountry, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionCountry, ""));

        String vobjCreateTransactionListOfCountries = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionListOfCountries");
        List<WebElement> elements = driver.findElements(By.xpath(vobjCreateTransactionListOfCountries));
        int numberOfElements = elements.size();
        if(numberOfElements==207)
        {
            LogCapture.info("User verified Total 207 countries are present in the list");
            System.out.println("Below is a list of 207 currencies.");

        }else
        {
            LogCapture.info("TC Failed : User unable to verify 207 countries in the list");
            Assert.fail();
        }

//        for(int i=1; i<=numberOfElements; i++)
//        {
//            String FilterOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//div//p";
//            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
//            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();
//            System.out.println(ActualFilterOptions);
//        }

        for(int i=1; i<=numberOfElements; i++)
        {
            String FilterOptions = "(//ul[@id='bb-select-country-listbox']//li)["+i+"]//div//p";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();
            if(ActualFilterOptions.equalsIgnoreCase(ExpCountry))
            {
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(FilterOptions, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(FilterOptions, ""));
                LogCapture.info("User Select country as "+ExpCountry+" from the list");
                break;
            }
            else if(i== numberOfElements)
            {
                LogCapture.info("TC Failed : User unable to select country as "+ExpCountry+" from the List");
                Assert.fail();
            }
        }

        String vobjCreateTransactionAddress = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionAddress, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionAddress, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjCreateTransactionAddress, ExpAddress));

        String vobjCreateTransactionFirstAddressfromList = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionFirstAddressfromList");
        Thread.sleep(2000);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionFirstAddressfromList, ""));
        String FirstAddressfromList = Constants.driver.findElement(By.xpath(vobjCreateTransactionFirstAddressfromList)).getText();
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionFirstAddressfromList, ""));
        LogCapture.info("User entered Address as " + FirstAddressfromList);
        Thread.sleep(2000);

        PPPurchaseValue = Integer.toString(ThreadLocalRandom.current().nextInt(2000, 2500));
        String vobjCreateTransactionPurchaseValue = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionPurchaseValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionPurchaseValue, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionPurchaseValue, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjCreateTransactionPurchaseValue, PPPurchaseValue));
        LogCapture.info("User entered purchase value as " + PPPurchaseValue);

        String vobjCreateTransactionCurrency = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionCurrency");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionCurrency, ""));

        String vobjCreateTransactionListOfCurrencies = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionListOfCurrencies");
        List<WebElement> CCYelements = driver.findElements(By.xpath(vobjCreateTransactionListOfCurrencies));
        int numberOfCurrencies = CCYelements.size();
        if(numberOfCurrencies==26)
        {
            LogCapture.info("User verified Total 26 Currencies are present in the list");
            System.out.println("Below is a list of 26 Currencies.");

        }else
        {
            LogCapture.info("TC Failed : User unable to verify 26 Currencies in the list");
            Assert.fail();
        }

//        for(int i=1; i<=numberOfCurrencies; i++)
//        {
//            String CurrencyOptions = "//ul[@class='MuiAutocomplete-listbox css-10danr5']//li["+i+"]//div//p";
//            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CurrencyOptions, ""));
//            String ActualCurrencyOptions = Constants.driver.findElement(By.xpath(CurrencyOptions)).getText();
//            System.out.println(ActualCurrencyOptions);
//        }

        for(int i=1; i<=numberOfCurrencies; i++)
        {
            String CurrencyOptions = "//ul[@class='MuiAutocomplete-listbox css-10danr5']//li["+i+"]//div//p";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CurrencyOptions, ""));
            String ActualCurrencyOptions = Constants.driver.findElement(By.xpath(CurrencyOptions)).getText();

            if(ActualCurrencyOptions.equalsIgnoreCase(ExpCurrencyOptions))
            {
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CurrencyOptions, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CurrencyOptions, ""));
                LogCapture.info("User Select Currency as "+ActualCurrencyOptions+" from the list");
                break;
            }
            else if(i== numberOfCurrencies)
            {
                LogCapture.info("TC Failed : User unable to select Currency as "+ExpCountry+" from the List");
                Assert.fail();
            }
        }

        String vobjSaveAndContinueButton = Constants.PropertyPayDashboardOR.getProperty("SaveAndContinueButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSaveAndContinueButton, ""));
        String SaveAndContButton = Constants.driver.findElement(By.xpath(vobjSaveAndContinueButton)).getText();
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjSaveAndContinueButton, ""));
        LogCapture.info("User Click on "+SaveAndContButton+" Button");

    }

    @And("^User landed on the Party Details page, enters the details for \"([^\"]*)\" party, (and|Select TPA and) clicks the Continue button$")
    public void userLandedOnThePartyDetailsPageEntersTheDetailsForPartyAndClicksTheContinueButton(String NoOfParty, String TPA) throws Throwable {

        NoOfParties=NoOfParty;
        if(NoOfParties.equals("1"))
        {
            String vobjPartyDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyDetailsHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPartyDetailsHeader, "Party details"));
            LogCapture.info("User verified its landed on Party details page");

            String vobjCreatePartyDetailsContinueButton = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsContinueButton");
            WebElement button = driver.findElement(By.xpath(vobjCreatePartyDetailsContinueButton));
            boolean isDisabled = !button.isEnabled();
            if (isDisabled) {
                LogCapture.info("User verify Continue button is Disabled before entering details.");
            } else {
                LogCapture.info("TC Failed : User verify continue Button is Enable");
                Assert.fail();
            }

            String vobjParty1Header = Constants.PropertyPayDashboardOR.getProperty("Party1Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty1Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty1Header, "Party 1"));
            LogCapture.info("User verify Party1 Header on Party details page");

            String RandomFirstname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            String RandomLastname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            PPPartyFullName = "Donald" + RandomFirstname + " " + "Biden" + RandomLastname;


            String vobjPartyFullName = Constants.PropertyPayDashboardOR.getProperty("PartyFullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyFullName, PPPartyFullName));
            LogCapture.info("User enter Party Full Name as" + PPPartyFullName);

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
            String CurrentTimeTimeHHMM = TimeHHMM.format(now);
            Constants.PPPartyEmail = "saurabhpropertypay" + CurrentTimeTimeHHMM + "@mailinator.com";

            String vobjPartyEmail = Constants.PropertyPayDashboardOR.getProperty("PartyEmail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyEmail, PPPartyEmail));
            LogCapture.info("User enter Party Email as " + PPPartyEmail);

            String CountryCode= "+91";
            String vobjPartyCountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("PartyCountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyCountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyCountryCodeDropdown, ""));

            String vobjPartyDetailsCountryCodeList = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsCountryCodeList");
            List<WebElement> CountryCodeElements = driver.findElements(By.xpath(vobjPartyDetailsCountryCodeList));
            int numberOfCountryCodes = CountryCodeElements.size();
            if(numberOfCountryCodes==168)
            {
                LogCapture.info("User verified Total 168 country codes are present in the list");
                System.out.println("Below is a list of 168 country code.");

            }else
            {
                LogCapture.info("TC Failed : User unable to verify 18 country codes in the list");
                Assert.fail();
            }

//            for(int i=1; i<=numberOfCountryCodes; i++)
//            {
//                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]";
//                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
//                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();
//                System.out.println(ActualCountryCodeOptions);
//            }

            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPPartyMobileNo="9000012345";
            String vobjPartyMobile = Constants.PropertyPayDashboardOR.getProperty("PartyMobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyMobile, PPPartyMobileNo));
            LogCapture.info("User enter Party Mobile Number as " + PPPartyMobileNo);

            String vobjTPAHeader = Constants.PropertyPayDashboardOR.getProperty("TPAHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAHeader, "Third-Party Authorisation"));
            LogCapture.info("User verified Header as Third-Party Authorisation on Party details page");

            String vobjTPAHeaderMesssage = Constants.PropertyPayDashboardOR.getProperty("TPAHeaderMesssage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAHeaderMesssage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAHeaderMesssage, "To disburse funds from a client’s Currencies Direct Wallet for completion, you’ll need their Third-Party Authorisation."));
            LogCapture.info("User verified TPA Header Message as To disburse funds from a client’s Currencies Direct Wallet for completion, you’ll need their Third-Party Authorisation. on Party details page");

            String vobjTPAConfirmationMSG = Constants.PropertyPayDashboardOR.getProperty("TPAConfirmationMSG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAConfirmationMSG, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAConfirmationMSG, "Confirm if you plan to use the completion schedule feature in Property Pay for this transaction. We will request authorisation once the client joins the transaction in PropertyPay."));
            LogCapture.info("User verified TPA Message as Confirm if you plan to use the completion schedule feature in Property Pay for this transaction. We will request authorisation once the client joins the transaction in PropertyPay. on Party details page");

            if(TPA.equalsIgnoreCase("Select TPA and"))
            {
                String vobjTPACheckBox = Constants.PropertyPayDashboardOR.getProperty("TPACheckBox");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPACheckBox, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTPACheckBox, ""));
                LogCapture.info("User Select Third-Party Authorisation Check box");
            }

            Thread.sleep(2000);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreatePartyDetailsContinueButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreatePartyDetailsContinueButton, ""));

        } else if (NoOfParties.equals("2"))
        {
            String vobjPartyDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyDetailsHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPartyDetailsHeader, "Party details"));
            LogCapture.info("User verified its landed on Party details page");

            String vobjCreatePartyDetailsContinueButton = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsContinueButton");
            WebElement button = driver.findElement(By.xpath(vobjCreatePartyDetailsContinueButton));
            boolean isDisabled = !button.isEnabled();
            if (isDisabled) {
                LogCapture.info("User verify Continue button is Disabled before entering details.");
            } else {
                LogCapture.info("TC Failed : User verify continue Button is Enable");
                Assert.fail();
            }

            String vobjParty1Header = Constants.PropertyPayDashboardOR.getProperty("Party1Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty1Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty1Header, "Party 1"));
            LogCapture.info("User verify Party1 Header on Party details page");

            String RandomFirstname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            String RandomLastname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            PPPartyFullName = "Donald" + RandomFirstname + " " + "Biden" + RandomLastname;


            String vobjPartyFullName = Constants.PropertyPayDashboardOR.getProperty("PartyFullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyFullName, PPPartyFullName));
            LogCapture.info("User enter Party Full Name as" + PPPartyFullName);

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
            String CurrentTimeTimeHHMM = TimeHHMM.format(now);
            Constants.PPPartyEmail = "saurabhpropertypay" +RandomStringUtils.randomAlphabetic(5).toLowerCase()+ CurrentTimeTimeHHMM + "1@mailinator.com";

            String vobjPartyEmail = Constants.PropertyPayDashboardOR.getProperty("PartyEmail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyEmail, PPPartyEmail));
            LogCapture.info("User enter Party Email as " + PPPartyEmail);

            String CountryCode= "+91";
            String vobjPartyCountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("PartyCountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyCountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyCountryCodeDropdown, ""));

            String vobjPartyDetailsCountryCodeList = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsCountryCodeList");
            List<WebElement> CountryCodeElements = driver.findElements(By.xpath(vobjPartyDetailsCountryCodeList));
            int numberOfCountryCodes = CountryCodeElements.size();
            if(numberOfCountryCodes==168)
            {
                LogCapture.info("User verified Total 168 country codes are present in the list");
                System.out.println("Below is a list of 168 country code.");

            }else
            {
                LogCapture.info("TC Failed : User unable to verify 18 country codes in the list");
                Assert.fail();
            }

//            for(int i=1; i<=numberOfCountryCodes; i++)
//            {
//                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]";
//                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
//                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();
//                System.out.println(ActualCountryCodeOptions);
//            }

            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPPartyMobileNo="9000012345";
            String vobjPartyMobile = Constants.PropertyPayDashboardOR.getProperty("PartyMobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyMobile, PPPartyMobileNo));
            LogCapture.info("User enter Party Mobile Number as " + PPPartyMobileNo);

            String vobjAddAnotherParty = Constants.PropertyPayDashboardOR.getProperty("AddAnotherParty");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAddAnotherParty, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjAddAnotherParty, ""));
            LogCapture.info("User click on Add another party to add Second Party");


            String vobjParty2Header = Constants.PropertyPayDashboardOR.getProperty("Party2Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty2Header, "Party 2"));
            LogCapture.info("User verify Party 2 Header on Party details page");

            PPParty2FullName = "Justin" + RandomStringUtils.randomAlphabetic(6).toLowerCase() + " " + "Trudeau" + RandomStringUtils.randomAlphabetic(6).toLowerCase();
            String vobjParty2FullName = Constants.PropertyPayDashboardOR.getProperty("Party2FullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2FullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2FullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2FullName, PPParty2FullName));
            LogCapture.info("User enter Party2 Full Name as" + PPParty2FullName);
            Thread.sleep(2000);

            Constants.PPParty2Email = "saurabhpropertypay" +RandomStringUtils.randomAlphabetic(5).toLowerCase()+ CurrentTimeTimeHHMM + "2@mailinator.com";
            String vobjParty2Email = Constants.PropertyPayDashboardOR.getProperty("Party2Email");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Email, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2Email, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2Email, PPParty2Email));
            LogCapture.info("User enter Party Email as " + PPParty2Email);


            String vobjParty2CountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("Party2CountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2CountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2CountryCodeDropdown, ""));


            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPParty2MobileNo="9000012345";
            String vobjParty2Mobile = Constants.PropertyPayDashboardOR.getProperty("Party2Mobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Mobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2Mobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2Mobile, PPParty2MobileNo));
            LogCapture.info("User enter Party 2 Mobile Number as" + PPParty2MobileNo);

            String vobjTPAHeader = Constants.PropertyPayDashboardOR.getProperty("TPAHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAHeader, "Third-Party Authorisation"));
            LogCapture.info("User verified Header as Third-Party Authorisation on Party details page");

            String vobjTPAHeaderMesssage = Constants.PropertyPayDashboardOR.getProperty("TPAHeaderMesssage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAHeaderMesssage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAHeaderMesssage, "To disburse funds from a client’s Currencies Direct Wallet for completion, you’ll need their Third-Party Authorisation."));
            LogCapture.info("User verified TPA Header Message as To disburse funds from a client’s Currencies Direct Wallet for completion, you’ll need their Third-Party Authorisation. on Party details page");

            String vobjTPAConfirmationMSG = Constants.PropertyPayDashboardOR.getProperty("TPAConfirmationMSG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAConfirmationMSG, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAConfirmationMSG, "Confirm if you plan to use the completion schedule feature in Property Pay for this transaction. We will request authorisation once the client joins the transaction in PropertyPay."));
            LogCapture.info("User verified TPA Message as Confirm if you plan to use the completion schedule feature in Property Pay for this transaction. We will request authorisation once the client joins the transaction in PropertyPay. on Party details page");

            if(TPA.equalsIgnoreCase("Select TPA and"))
            {
                String vobjTPACheckBox = Constants.PropertyPayDashboardOR.getProperty("TPACheckBox");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPACheckBox, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTPACheckBox, ""));
                LogCapture.info("User Select Third-Party Authorisation Check box");
            }

            Thread.sleep(2000);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreatePartyDetailsContinueButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreatePartyDetailsContinueButton, ""));

        }


    }

    @Then("^User landed on the Confirmation page to review the transaction and party details, then clicks the Continue button\\.$")
    public void userLandedOnTheConfirmationPageToReviewTheTransactionAndPartyDetailsThenClicksTheContinueButton() throws Exception {

        String vobjConfTransactionDetails = Constants.PropertyPayDashboardOR.getProperty("ConfTransactionDetails");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfTransactionDetails, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfTransactionDetails, "Transaction details"));
        LogCapture.info("User verify Create transaction Header on confirmation page");

        String vobjConfirmationHeader = Constants.PropertyPayDashboardOR.getProperty("ConfirmationHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfirmationHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfirmationHeader, "Confirmation"));
        LogCapture.info("User verify Create Confirmation Header on confirmation page");


        String vobjConfPPTransactionRefereneID = Constants.PropertyPayDashboardOR.getProperty("ConfPPTransactionRefereneID");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vobjConfPPTransactionRefereneID, ""));
        PPTransactionRefereneID = Constants.driver.findElement(By.xpath(vobjConfPPTransactionRefereneID)).getText();
        if(!PPTransactionRefereneID.equals("") || !(PPTransactionRefereneID == null))
        {
            LogCapture.info("User Captured Property Pay Transaction Reference ID as "+PPTransactionRefereneID);
        }else
        {
            LogCapture.info("User unable to captured Property Pay Transaction Reference ID");
            Assert.fail();
        }

        String vobjConfFileReference = Constants.PropertyPayDashboardOR.getProperty("ConfFileReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfFileReference, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfFileReference, PPFileReference));
        LogCapture.info("User verify File Reference Under Transaction Details section on confirmation page");


        String vobjConfPurchaseValue = Constants.PropertyPayDashboardOR.getProperty("ConfPurchaseValue");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vobjConfPurchaseValue, ""));
        String ActPurchasevalue = Constants.driver.findElement(By.xpath(vobjConfPurchaseValue)).getText();
        String TrimmedValue = ActPurchasevalue.replace(",","");

        if(TrimmedValue.contains(PPPurchaseValue))
        {
            LogCapture.info("User Verified Purchase value as "+ActPurchasevalue+" Under Transaction Details section on confirmation page");
        }else
        {
            LogCapture.info("User unable to verify Purchase value Under Transaction Details section on confirmation page");
            Assert.fail();
        }


        DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar Calender1 = Calendar.getInstance();
        Calender1.setTime(new Date());
        Calender1.add(Calendar.DATE, 5);
        String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
        String vobjConfSettlementDate = Constants.PropertyPayDashboardOR.getProperty("ConfSettlementDate");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfSettlementDate, ""));
        String ActCompDate = Constants.driver.findElement(By.xpath(vobjConfSettlementDate)).getText();

        StringBuilder modifiedDate = new StringBuilder(CompletionDate);
        if (modifiedDate.charAt(0) == '0')
        {
            modifiedDate.replace(0, 1, "");
        }
        String modifiedDateWithoutZero="";

        if (modifiedDate.toString().contains("/0"))
        {
            modifiedDateWithoutZero = modifiedDate.toString().replace("/0","/");
        }else
        {
            modifiedDateWithoutZero =modifiedDate.toString();
        }

        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfSettlementDate, CompletionDate));
        LogCapture.info("User verify Completion Date Under Transaction Details section on confirmation page");

        String vobjConfPropertyAddress = Constants.PropertyPayDashboardOR.getProperty("ConfPropertyAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfPropertyAddress, ""));
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vobjConfPropertyAddress, ""));
        String PPActualAddress = Constants.driver.findElement(By.xpath(vobjConfPropertyAddress)).getText();
        if(!PPActualAddress.equals("") || !(PPActualAddress == null))
        {
            LogCapture.info("User verified address as "+PPActualAddress + "Under Transaction Details section on confirmation page");
        }else
        {
            LogCapture.info("User unable to verify address Under Transaction Details section on confirmation page");
            Assert.fail();
        }

        String vobjConfEditTransactionDetailsOption = Constants.PropertyPayDashboardOR.getProperty("ConfEditTransactionDetailsOption");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfEditTransactionDetailsOption, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfEditTransactionDetailsOption, "Edit"));
        LogCapture.info("User verify Edit Transaction Details option on confirmation page");


        if(NoOfParties.equals("1"))
        {
            String vobjConfBuyer1Name = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer1Name");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer1Name, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfBuyer1Name, PPPartyFullName));
            LogCapture.info("User verified Party Full name Under Party Details section on confirmation page");

            String vobjConfBuyer1Email = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer1Email");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer1Email, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfBuyer1Email, PPPartyEmail));
            LogCapture.info("User verified Party Email Under Party Details section on confirmation page");

            String vobjConfBuyer1MobileNumber = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer1MobileNumber");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer1MobileNumber, ""));
            String PartyEmail = Constants.driver.findElement(By.xpath(vobjConfBuyer1MobileNumber)).getText();
            if(PartyEmail.contains(PPPartyMobileNo))
            {
                LogCapture.info("User verified Party Mobile Number as "+PartyEmail + " Under Party Details section on confirmation page");
            }else
            {
                LogCapture.info("User unable to verify Party Mobile Number Under Party Details section on confirmation page");
                Assert.fail();
            }

            if(NoOfParties.equals("2"))
            {
                String vobjConfRemoveParty1 = Constants.PropertyPayDashboardOR.getProperty("ConfRemoveParty1");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfRemoveParty1, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfRemoveParty1, "Remove"));
                LogCapture.info("User verify Remove Party option on confirmation page");
            }

            String vobjConfEditPartyDetailsOption = Constants.PropertyPayDashboardOR.getProperty("ConfEditPartyDetailsOption");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfEditPartyDetailsOption, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfEditPartyDetailsOption, "Edit"));
            LogCapture.info("User verify Edit Party option on confirmation page");

            String vobjConfTransactionDetailsStepper = Constants.PropertyPayDashboardOR.getProperty("ConfTransactionDetailsStepper");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfTransactionDetailsStepper, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfTransactionDetailsStepper, "Transaction details"));
            LogCapture.info("User verify Transaction details Stepper option on confirmation page");

            String vobjConfPartyDetailsStepper = Constants.PropertyPayDashboardOR.getProperty("ConfPartyDetailsStepper");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfPartyDetailsStepper, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfPartyDetailsStepper, "Party details"));
            LogCapture.info("User verify Party details Stepper option on confirmation page");

            String vobjConfBackButton = Constants.PropertyPayDashboardOR.getProperty("ConfBackButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBackButton, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfBackButton, "Back"));
            LogCapture.info("User verify Back button on confirmation page");

            String vobjConfContinueButton = Constants.PropertyPayDashboardOR.getProperty("ConfContinueButton");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfContinueButton, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfContinueButton, "Confirm"));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjConfContinueButton, ""));
            LogCapture.info("User verify Continue button on confirmation page and then click on Continue Button");

        }
        else if(NoOfParties.equals("2"))
        {
            String vobjConfBuyer1Name = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer1Name");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer1Name, ""));
            String ACtfBuyer1Name = Constants.driver.findElement(By.xpath(vobjConfBuyer1Name)).getText();
            LogCapture.info("Actual Name "+ACtfBuyer1Name);
            LogCapture.info("Actual Name "+PPParty2FullName);

            Assert.assertEquals("PASS", Constants.key.verifyText1OrText2(vobjConfBuyer1Name, PPPartyFullName, PPParty2FullName));
            LogCapture.info("User verified Party1 Full name Under Party Details section on confirmation page");

            String vobjConfBuyer1Email = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer1Email");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer1Email, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText1OrText2(vobjConfBuyer1Email, PPPartyEmail, PPParty2Email));
            LogCapture.info("User verified Party1 Email Under Party Details section on confirmation page");

            String vobjConfBuyer1MobileNumber = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer1MobileNumber");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer1MobileNumber, ""));
            String PartyMobileNumber = Constants.driver.findElement(By.xpath(vobjConfBuyer1MobileNumber)).getText();
            if(PartyMobileNumber.contains(PPPartyMobileNo) || PartyMobileNumber.contains(PPParty2MobileNo))
            {
                LogCapture.info("User verified Party1 Mobile Number as "+PartyMobileNumber + "Under Party Details section on confirmation page");
            }else
            {
                LogCapture.info("User unable to verify Party1 Mobile Number Under Party Details section on confirmation page");
                Assert.fail();
            }

            String vobjConfParty2Header = Constants.PropertyPayDashboardOR.getProperty("ConfParty2Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfParty2Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfParty2Header, "Party 2"));
            LogCapture.info("User verified Party 2 Header on confirmation page");


            String vobjConfBuyer2Name = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer2Name");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer2Name, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText1OrText2(vobjConfBuyer2Name, PPPartyFullName, PPParty2FullName));
            LogCapture.info("User verified Party2 Full name Under Party Details section on confirmation page");

            String vobjConfBuyer2Email = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer2Email");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer2Email, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText1OrText2(vobjConfBuyer2Email, PPPartyEmail, PPParty2Email));
            LogCapture.info("User verified Party2 Email Under Party Details section on confirmation page");

            String vobjConfBuyer2MobileNumber = Constants.PropertyPayDashboardOR.getProperty("ConfBuyer2MobileNumber");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBuyer2MobileNumber, ""));
            String Party2Mobile = Constants.driver.findElement(By.xpath(vobjConfBuyer2MobileNumber)).getText();
            if(Party2Mobile.contains(PPPartyMobileNo) || Party2Mobile.contains(PPParty2MobileNo))
            {
                LogCapture.info("User verified Party2 Mobile Number as "+Party2Mobile + "Under Party Details section on confirmation page");
            }else
            {
                LogCapture.info("User unable to verify Party2 Mobile Number Under Party Details section on confirmation page");
                Assert.fail();
            }

            String vobjConfRemoveParty1 = Constants.PropertyPayDashboardOR.getProperty("ConfRemoveParty1");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfRemoveParty1, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfRemoveParty1, "Remove"));
            LogCapture.info("User verify Remove Party1 option on confirmation page");

            String vobjConfRemoveParty2 = Constants.PropertyPayDashboardOR.getProperty("ConfRemoveParty2");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfRemoveParty2, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfRemoveParty2, "Remove"));
            LogCapture.info("User verify Remove Party2 option on confirmation page");

        }

        String vobjConfEditPartyDetailsOption = Constants.PropertyPayDashboardOR.getProperty("ConfEditPartyDetailsOption");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfEditPartyDetailsOption, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfEditPartyDetailsOption, "Edit"));
        LogCapture.info("User verify Edit Party option on confirmation page");

        String vobjConfTransactionDetailsStepper = Constants.PropertyPayDashboardOR.getProperty("ConfTransactionDetailsStepper");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfTransactionDetailsStepper, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfTransactionDetailsStepper, "Transaction details"));
        LogCapture.info("User verify Transaction details Stepper option on confirmation page");

        String vobjConfPartyDetailsStepper = Constants.PropertyPayDashboardOR.getProperty("ConfPartyDetailsStepper");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfPartyDetailsStepper, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfPartyDetailsStepper, "Party details"));
        LogCapture.info("User verify Party details Stepper option on confirmation page");

        String vobjConfirmationStepper = Constants.PropertyPayDashboardOR.getProperty("ConfirmationStepper");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfirmationStepper, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfirmationStepper, "Confirmation"));
        LogCapture.info("User verify Confirmation Stepper option on confirmation page");

        String vobjConfBackButton = Constants.PropertyPayDashboardOR.getProperty("ConfBackButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfBackButton, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfBackButton, "Back"));
        LogCapture.info("User verify Back button on confirmation page");

        String vobjConfContinueButton = Constants.PropertyPayDashboardOR.getProperty("ConfContinueButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfContinueButton, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfContinueButton, "Confirm"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjConfContinueButton, ""));
        LogCapture.info("User verify Continue button on confirmation page and then click on Continue Button");

    }

    @Then("^User verify Transaction has been created Successfully and Click on Go to transaction button$")
    public void userVerifyTransactionHasBeenCreatedSuccessfullyAndClickOnGoToTransactionButton() throws Exception {

        String vobjTransactionCreatedMessage = Constants.PropertyPayDashboardOR.getProperty("TransactionCreatedMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTransactionCreatedMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjTransactionCreatedMessage, "Property transaction created"));
        LogCapture.info("User verify Property transaction has been created successfully");

        String vobjReadyTocreateFirstPaymentMessage = Constants.PropertyPayDashboardOR.getProperty("ReadyTocreateFirstPaymentMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjReadyTocreateFirstPaymentMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjReadyTocreateFirstPaymentMessage, "You’re ready to create your first payment request."));
        LogCapture.info("User verify Text Message as 'You are ready to create your first payment request.'");

        String vobjGoToTransactionButton = Constants.PropertyPayDashboardOR.getProperty("GoToTransactionButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjGoToTransactionButton, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjGoToTransactionButton, "Go to transaction"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjGoToTransactionButton, ""));
        LogCapture.info("User verify Go to Transaction Button and then click on the same");

    }

    @Then("^user landed on the Dashboard, searched for the recently created transaction, verified the status as \"([^\"]*)\" and then clicked on the View button$")
    public void userLandedOnTheDashboardSearchedForTheRecentlyCreatedTransactionVerifiedTheStatusAsAndThenClickedOnTheViewButton(String TransactionStatus) throws Throwable {

        PPTransactionStatus=TransactionStatus;
        String vobjDashSearchBarDesktop = Constants.PropertyPayDashboardOR.getProperty("DashSearchBarDesktop");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjDashSearchBarDesktop, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjDashSearchBarDesktop, ""));
        LogCapture.info("User click on Search bar");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjDashSearchBarDesktop, PPFileReference));
        LogCapture.info("User entered File Reference as "+PPFileReference+" in search bar ");
        Thread.sleep(3000);

        String vobjDashDesktopStatus = Constants.PropertyPayDashboardOR.getProperty("DashDesktopStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjDashDesktopStatus, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashDesktopStatus, TransactionStatus));
        LogCapture.info("User verify Status as "+TransactionStatus+" on Dashboard for recently created transaction");

        String vobjDashDesktopViewButton = Constants.PropertyPayDashboardOR.getProperty("DashDesktopViewButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjDashDesktopViewButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjDashDesktopViewButton, ""));
        LogCapture.info("User clicked on View Button for recently created Transaction");

    }

    @Then("^user landed on the Transaction Details page, verified the details, and then clicked on the Add Payment button$")
    public void userLandedOnTheTransactionDetailsPageVerifiedTheDetailsAndThenClickedOnTheAddPaymentButton() throws Exception {

        String vobjPPTransactionID = Constants.PropertyPayDashboardOR.getProperty("PPTransactionID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPTransactionID, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPPTransactionID, PPTransactionRefereneID));
        LogCapture.info("User verify Transaction Reference ID as "+PPTransactionRefereneID);

        DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar Calender1 = Calendar.getInstance();
        Calender1.setTime(new Date());
        Calender1.add(Calendar.DATE, 5);
        String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
        StringBuilder modifiedDate = new StringBuilder(CompletionDate);
        if (modifiedDate.charAt(0) == '0')
        {
            modifiedDate.replace(0, 1, "");
        }

        String modifiedDateWithoutZero = modifiedDate.toString();
        if (modifiedDate.toString().contains("/0"))
        {
            modifiedDateWithoutZero =  modifiedDate.toString().replace("/0","/");
        }

        String vobjPPTransactionCompletionDate = Constants.PropertyPayDashboardOR.getProperty("PPTransactionCompletionDate");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPTransactionCompletionDate, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPPTransactionCompletionDate, CompletionDate));
        LogCapture.info("User verify Completion date as "+modifiedDate.toString());

        Thread.sleep(2000);
        String vobjPPTransactionStatus = Constants.PropertyPayDashboardOR.getProperty("PPTransactionStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPTransactionStatus, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPPTransactionStatus, "Open"));
        LogCapture.info("User verify Transaction Status as Open");

        String vobjNothingRightNowMessage = Constants.PropertyPayDashboardOR.getProperty("NothingRightNowMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjNothingRightNowMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjNothingRightNowMessage, "Nothing to see here right now"));
        LogCapture.info("User verify Message as 'Nothing to see here right now'");

        String vobjAddYourFirstPayment = Constants.PropertyPayDashboardOR.getProperty("AddYourFirstPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAddYourFirstPayment, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjAddYourFirstPayment, "Add your first payment to get started."));
        LogCapture.info("User verify Message as 'Add your first payment to get started.'");

        String vobjAddPaymentButton = Constants.PropertyPayDashboardOR.getProperty("AddPaymentButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAddPaymentButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjAddPaymentButton, ""));
        LogCapture.info("User Clicked on Add Payment Button");
        Thread.sleep(3000);

    }


    @And("^User landed on the 'Add Payment Request' page, selects a client from the list, chooses the payment type as \"([^\"]*)\", the currency as \"([^\"]*)\", enters the amount and payment date, and clicks on Continue$")
    public void userLandedOnTheAddPaymentRequestPageSelectsAClientFromTheListChoosesThePaymentTypeAsTheCurrencyAsEntersTheAmountAndPaymentDateAndClicksOnContinue(String PaymentType, String ExpCurrency) throws Throwable {

        String vobjAddNewPaymentHeader = Constants.PropertyPayDashboardOR.getProperty("AddNewPaymentHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAddNewPaymentHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjAddNewPaymentHeader, "Add payment instruction"));
        LogCapture.info("User verify Header as 'Add payment instruction' on Add payment Request page");

        String vobjRequestDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("RequestDetailsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjRequestDetailsHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRequestDetailsHeader, "Request details"));
        LogCapture.info("User verify Header as 'Request details' on Add payment Request page");

        String vobjRequestFormHeader = Constants.PropertyPayDashboardOR.getProperty("RequestFormHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjRequestFormHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRequestFormHeader, "Send payment instruction to:"));
        LogCapture.info("User verify Transaction Header as 'Send payment instruction to:' on Add payment Request page");

        String vobjAddpaymentContinueButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionSaveAndContinueButton");
        WebElement button = driver.findElement(By.cssSelector(vobjAddpaymentContinueButton));
        boolean isDisabled = !button.isEnabled();
        if (isDisabled) {
            LogCapture.info("User verify Continue button is Disabled before entering details.");
        } else {
            LogCapture.info("TC Failed : continue Button is Enable before entering details.");
            Assert.fail();
        }

        if(NoOfParties.equals("1"))
        {
            String vobjSelectFirstClient = "((//div[@class='MuiBox-root css-1qs18qg']//label)[1]//span)[2]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSelectFirstClient, ""));
            String FirstClientname = Constants.driver.findElement(By.xpath(vobjSelectFirstClient)).getText();
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjSelectFirstClient, ""));
            LogCapture.info("User Select client "+FirstClientname+" from the List");


        }
        else if(NoOfParties.equals("2"))
        {
            String vobjSelectFirstClient = "((//div[@class='MuiBox-root css-1qs18qg']//label)[1]//span)[2]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSelectFirstClient, ""));
            String FirstClientname = Constants.driver.findElement(By.xpath(vobjSelectFirstClient)).getText();
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjSelectFirstClient, ""));
            LogCapture.info("User Select first client "+FirstClientname+" from the List");

            String vobjSelectSecondClient = "((//div[@class='MuiBox-root css-1qs18qg']//label)[2]//span)[2]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSelectSecondClient, ""));
            String SecondClientname = Constants.driver.findElement(By.xpath(vobjSelectSecondClient)).getText();
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjSelectSecondClient, ""));
            LogCapture.info("User Select second client "+SecondClientname+" from the List");
        }

        String vobjPaymentTypeDropdown = Constants.PropertyPayDashboardOR.getProperty("PaymentTypeDropdown");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentTypeDropdown, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPaymentTypeDropdown, ""));
        LogCapture.info("User clicked on Payment type Dropdown");

        String vobjListOfPaymentType = Constants.PropertyPayDashboardOR.getProperty("ListOfPaymentType");
        List<WebElement> CCYelements = driver.findElements(By.xpath(vobjListOfPaymentType));
        int numbersOfPaymentTypes = CCYelements.size();
        if(numbersOfPaymentTypes==4)
        {
            LogCapture.info("User verified Total 4 Payment types are present in the list");
            System.out.println("Below is a list of 4 Payment types");

        }else
        {
            LogCapture.info("TC Failed : User unable to verify 4 Payment types in the list");
            Assert.fail();
        }

        for(int i=1; i<=numbersOfPaymentTypes; i++)
        {
            String PaymentTypesOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(PaymentTypesOptions, ""));
            String ActualPaymentTypesOptions = Constants.driver.findElement(By.xpath(PaymentTypesOptions)).getText();
            System.out.println(ActualPaymentTypesOptions);
        }

        for(int i=1; i<=numbersOfPaymentTypes; i++)
        {
            String PaymetTypesOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(PaymetTypesOptions, ""));
            String ActualPaymentTypesOptions = Constants.driver.findElement(By.xpath(PaymetTypesOptions)).getText();

            if(ActualPaymentTypesOptions.equalsIgnoreCase(PaymentType))
            {
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(PaymetTypesOptions, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(PaymetTypesOptions, ""));
                LogCapture.info("User Select Payment Type as "+ActualPaymentTypesOptions+" from the list");
                PaymentTypesOption = ActualPaymentTypesOptions;

                if(ActualPaymentTypesOptions.equalsIgnoreCase("Other"))
                {
                    String vobjOtherPaymentTypeDescription = Constants.PropertyPayDashboardOR.getProperty("OtherPaymentTypeDescription");
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjOtherPaymentTypeDescription, ""));
                    Assert.assertEquals("PASS", Constants.key.writeInInput(vobjOtherPaymentTypeDescription, "Funds for PropertyPay"));
                    PaymentTypesOption = "Funds for PropertyPay";
                    LogCapture.info("User entered Payment Type description as 'Funds for PropertyPay Transaction'");
                }
                break;
            }
            else if(i== numbersOfPaymentTypes)
            {
                LogCapture.info("TC Failed : User unable to select Payment Type as "+PaymentType+" from the List");
                Assert.fail();
            }

        }

        String vobjPaymentDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("PaymentDetailsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentDetailsHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentDetailsHeader, "Payment details"));
        LogCapture.info("User Header as Payment details after selecting Payment Type'");

        String PaymentValueRequested = Integer.toString(ThreadLocalRandom.current().nextInt(500, 900));
        PaymentRequestsValue = PaymentValueRequested;
        String vobjPaymentRequestValue = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentRequestValue, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPaymentRequestValue, PaymentValueRequested));
        LogCapture.info("User entered Payment request value as "+ PaymentValueRequested);

        String vobjCCYDropdownAddPayment = Constants.PropertyPayDashboardOR.getProperty("CCYDropdownAddPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCCYDropdownAddPayment, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCCYDropdownAddPayment, ""));

        String vobjAddPaymemtRequestCCY = Constants.PropertyPayDashboardOR.getProperty("AddPaymemtRequestCCY");
        List<WebElement> AddPaymentCCYelements = driver.findElements(By.xpath(vobjAddPaymemtRequestCCY));
        int numberOfCurrencies = AddPaymentCCYelements.size();
        if(numberOfCurrencies==26)
        {
            LogCapture.info("User verified Total 26 Currencies are present in the list on Add Payment Request page");
            System.out.println("Below is a list of 26 Currencies.");

        }else
        {
            LogCapture.info("TC Failed : User unable to verify 26 Currencies in the list");
            Assert.fail();
        }

//        for(int i=1; i<=numberOfCurrencies; i++)
//        {
//            String CurrencyOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//p";
//            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CurrencyOptions, ""));
//            String ActualCurrencyOptions = Constants.driver.findElement(By.xpath(CurrencyOptions)).getText();
//            System.out.println(ActualCurrencyOptions);
//        }

        for(int i=1; i<=numberOfCurrencies; i++)
        {
            String CurrencyOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//p";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CurrencyOptions, ""));
            String ActualCurrencyOptions = Constants.driver.findElement(By.xpath(CurrencyOptions)).getText();

            if(ActualCurrencyOptions.equalsIgnoreCase(ExpCurrency))
            {
                PaymentRequestsCurrency = ActualCurrencyOptions;
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CurrencyOptions, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CurrencyOptions, ""));
                LogCapture.info("User Select Currency as "+ActualCurrencyOptions+" from the list on Add Payment button");
                break;
            }
            else if(i== numberOfCurrencies)
            {
                LogCapture.info("TC Failed : User unable to select Currency as "+ExpCurrency+" from the List");
                Assert.fail();
            }
        }

        String Valuedate;
        String vObjCalendar = "//button[@aria-label='Choose date']//*[name()='svg']";
        String calender= key.notexist(vObjCalendar, "");
        if(calender.equalsIgnoreCase("PASS")){
            String vObjCalendar2 = "//input[@id='completionDate']";
            Assert.assertEquals("PASS", key.VisibleConditionWait(vObjCalendar2, ""));
            Assert.assertEquals("PASS", key.Mouse_Events(vObjCalendar2, ""));
            Assert.assertEquals("PASS", key.pause("2", ""));
        }
        else{
            Assert.assertEquals("PASS", key.VisibleConditionWait(vObjCalendar, ""));
            Assert.assertEquals("PASS", key.MouseFunctions(vObjCalendar, "MoveToElement"));
            Assert.assertEquals("PASS", key.MouseFunctions(vObjCalendar, "click"));
            Assert.assertEquals("PASS", key.pause("2", ""));
        }

        DateFormat dayFormat = new SimpleDateFormat("d"); // 'd' removes leading zero
        DateFormat monthFormat = new SimpleDateFormat("MM");

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 5);

        Valuedate = dayFormat.format(cal.getTime());
        String targetMonth = monthFormat.format(cal.getTime());
        String currentMonth = monthFormat.format(new Date());

        if (!targetMonth.equals(currentMonth)) {
            String vObjNextMonthButton = "//button[@title='Next month']";
            Assert.assertEquals("PASS", key.VisibleConditionWait(vObjNextMonthButton, ""));
            Assert.assertEquals("PASS", key.Mouse_Events(vObjNextMonthButton, ""));
            Assert.assertEquals("PASS", key.pause("2", ""));
        }

        String vObjCompletionDate = "//button[text()='" + Valuedate + "' and @class='MuiButtonBase-root MuiPickersDay-root MuiPickersDay-dayWithMargin css-kbsjfq']";
        Assert.assertEquals("PASS", key.VisibleConditionWait(vObjCompletionDate, ""));
        Assert.assertEquals("PASS", key.navigateSubMenu(vObjCompletionDate, ""));

        DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar Calender1 = Calendar.getInstance();
        Calender1.setTime(new Date());
        Calender1.add(Calendar.DATE, 5);
        String PaymentDueDateDate = SelectedDateFormat.format(Calender1.getTime());
        PaymentRequestsDueDate = PaymentDueDateDate;
        LogCapture.info("User select Payment Due Date date as " + PaymentRequestsDueDate);

//        String vObjOk = "//button[@type='button' and text()='OK']";
//        String calenderOk= key.notexist(vObjOk, "");
//        if(calenderOk.equalsIgnoreCase("PASS")){
//            Assert.assertEquals("PASS", key.VisibleConditionWait(vObjOk, ""));
//            Assert.assertEquals("PASS", key.Mouse_Events(vObjOk, ""));
//            Assert.assertEquals("PASS", key.pause("2", ""));
//        }

//        String Valuedate;
//        String vObjCalendar = Constants.PropertyPayDashboardOR.getProperty("CalenderButton");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCalendar, ""));
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCalendar, ""));
//        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//        DateFormat dateFormat = new SimpleDateFormat("dd");
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(new Date());
//        cal.add(Calendar.DATE, 1);
//        Valuedate = dateFormat.format(cal.getTime());
//        String vObjComplectionDate1="";
//        String vObjComplectionDate2="";
//        String ComplectionDate = "//button[text()='"+Valuedate+"']";
//
//        List<WebElement> Dateelements = driver.findElements(By.xpath(ComplectionDate));
//        int numberOfDateElements = Dateelements.size();
//        if(numberOfDateElements==2)
//        {
//            vObjComplectionDate1 ="(//button[text()='"+Valuedate+"'])[1]";
//            vObjComplectionDate2 ="(//button[text()='"+Valuedate+"'])[2]";
//
//            String DateAttribute1 = driver.findElement(By.xpath(vObjComplectionDate1)).getAttribute("class");
//            String DateAttribute2 = driver.findElement(By.xpath(vObjComplectionDate2)).getAttribute("class");
//
//            LogCapture.info("DateAttribute1 >>>>>> " + DateAttribute1);
//            LogCapture.info("DateAttribute2 >>>>>> " + DateAttribute2);
//
//            if (!DateAttribute1.contains("dayOutsideMonth"))
//            {
//                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate1, ""));
//                DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
//                Calendar Calender1 = Calendar.getInstance();
//                Calender1.setTime(new Date());
//                Calender1.add(Calendar.DATE, 2);
//                String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
//                LogCapture.info("User select Due date as " + CompletionDate);
//            }
//
//            if (!DateAttribute2.contains("dayOutsideMonth"))
//            {
//                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate2, ""));
//                DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
//                Calendar Calender1 = Calendar.getInstance();
//                Calender1.setTime(new Date());
//                Calender1.add(Calendar.DATE, 2);
//                String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
//                LogCapture.info("User select Due date as " + CompletionDate);
//            }
//        }else
//        {
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate1, ""));
//            DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
//            Calendar Calender1 = Calendar.getInstance();
//            Calender1.setTime(new Date());
//            Calender1.add(Calendar.DATE, 2);
//            String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
//            LogCapture.info("User select Due date as " + CompletionDate);
//        }

        String vObjContinueButtonAddNewPayment = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonAddNewPayment");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContinueButtonAddNewPayment, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContinueButtonAddNewPayment, ""));
        LogCapture.info("User clicked on Continue Button");
    }


    @Then("^The User landed on the Account to be Funded page, verifies the details, selects the (Currencies Direct Wallet|Saved recipients|Add new recipient) option, Use the details \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" and clicks on Continue button$")
    public void theUserLandedOnTheAccountToBeFundedPageVerifiesTheDetailsSelectsTheCurrenciesDirectWalletOptionUseTheDetailsAndClicksOnContinueButton(String Option, String ExistingPayeeName, String PayeeType, String PayeeFName, String PayeeLName, String CompanyName, String Country) throws Throwable {

        String vobjAccountToBeFundedHeader = Constants.PropertyPayDashboardOR.getProperty("AccountToBeFundedHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAccountToBeFundedHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjAccountToBeFundedHeader, "Account to fund"));
        LogCapture.info("User verify Header as Account to fund on add Payment request page");

        String vobjCurrenciesDirectWalletHeader = Constants.PropertyPayDashboardOR.getProperty("CurrenciesDirectWalletHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCurrenciesDirectWalletHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCurrenciesDirectWalletHeader, "Currencies Direct wallet"));
        LogCapture.info("User verify Header as Currencies Direct wallet on add Payment request page");

        String vobjrequestFundMessage = Constants.PropertyPayDashboardOR.getProperty("requestFundMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjrequestFundMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjrequestFundMessage, "Request that your client adds funds to their wallet."));
        LogCapture.info("User verify Message as 'Request that your client adds funds to their wallet.' on add Payment request page");

        String vobjSavedRecipientsHeader = Constants.PropertyPayDashboardOR.getProperty("SavedRecipientsHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSavedRecipientsHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSavedRecipientsHeader, "Frequently used recipients"));
        LogCapture.info("User verify Header as Frequently used recipients on add Payment request page");

        String vobjSelectExistingRecipientMessage = Constants.PropertyPayDashboardOR.getProperty("SelectExistingRecipientMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSelectExistingRecipientMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSelectExistingRecipientMessage, "Select from a list of previous recipients."));
        LogCapture.info("User verify Message as as 'Select from a list of previous recipients.' on add Payment request page");

        String vobjAddNewRecipientHeader = Constants.PropertyPayDashboardOR.getProperty("AddNewRecipientHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAddNewRecipientHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjAddNewRecipientHeader, "Add new recipient"));
        LogCapture.info("User verify Header as Add new recipient on add Payment request page");

        String vobjEnterAccountDetailsMessage = Constants.PropertyPayDashboardOR.getProperty("EnterAccountDetailsMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjEnterAccountDetailsMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjEnterAccountDetailsMessage, "Enter account details to set up a new recipient."));
        LogCapture.info("User verify Message as Enter account details to set up a new recipient. on add Payment request page");

        String vobjRequestDetailsStepper = Constants.PropertyPayDashboardOR.getProperty("RequestDetailsStepper");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjRequestDetailsStepper, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRequestDetailsStepper, "Request details"));
        LogCapture.info("User verify Stepper as 'Request details' on add Payment request page");

        String vobjAccountToBEFundedsStepper = Constants.PropertyPayDashboardOR.getProperty("AccountToBEFundedsStepper");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAccountToBEFundedsStepper, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjAccountToBEFundedsStepper, "Account to fund"));
        LogCapture.info("User verify Stepper as 'Account to fund' on add Payment request page");

        String vobjConfirmationStepper = Constants.PropertyPayDashboardOR.getProperty("ConfirmationStepper");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfirmationStepper, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfirmationStepper, "Confirmation"));
        LogCapture.info("User verify Stepper as 'Confirmation' on add Payment request page");

        String vobjBackButtonAccountToBeFunded = Constants.PropertyPayDashboardOR.getProperty("BackButtonAccountToBeFunded");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBackButtonAccountToBeFunded, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBackButtonAccountToBeFunded, "Back"));
        LogCapture.info("User verify Back Button available on Add Account to be funded page");

        if(Option.equalsIgnoreCase("Currencies Direct Wallet"))
        {
            String vobjContinueButtonAmountToBeFunded = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonAmountToBeFunded");
            String button = driver.findElement(By.xpath(vobjContinueButtonAmountToBeFunded)).getAttribute("class");
            if (button.contains("disabled")) {
                LogCapture.info("User verify Continue button is Disabled before selecting Currencies Direct Wallet option.");
            } else {
                LogCapture.info("TC Failed : User verify continue Button is Enable before selecting Currencies Direct Wallet option.");
                Assert.fail();
            }

            String vobjCDWalletOption = Constants.PropertyPayDashboardOR.getProperty("CDWalletOption");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCDWalletOption, ""));
            Assert.assertEquals("PASS", Constants.key.click(vobjCDWalletOption, ""));
            LogCapture.info("User Select Currencies Direct Wallet option");

            String vObjContinueButtonAddNewPayment = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonAddNewPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContinueButtonAddNewPayment, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContinueButtonAddNewPayment, ""));
            LogCapture.info("User clicked on Continue Button");
        }
        else if(Option.equalsIgnoreCase("Add new recipient"))
        {
            String vobjContinueButtonAmountToBeFunded = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonAmountToBeFunded");
            String AccountToBeFundedbutton = driver.findElement(By.xpath(vobjContinueButtonAmountToBeFunded)).getAttribute("class");
            if (AccountToBeFundedbutton.contains("disabled")) {
                LogCapture.info("User verify Continue button is Disabled before selecting Add new recipient option.");
            } else {
                LogCapture.info("TC Failed : User verify continue Button is Enable before selecting Add new recipient option.");
                Assert.fail();
            }

            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAddNewRecipientHeader, ""));
            Assert.assertEquals("PASS", Constants.key.click(vobjAddNewRecipientHeader, ""));
            LogCapture.info("User Select Add New Payment option");

            if(PayeeType.equalsIgnoreCase("Individual"))
            {
                String vObjPayeetype = "//span[normalize-space()='Individual']";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeetype, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeetype, ""));
                LogCapture.info("User Select Individual Payee Type");

                String vobjCPPPayeeFirstName = Constants.PropertyPayDashboardOR.getProperty("PPPayeeFirstName");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCPPPayeeFirstName, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCPPPayeeFirstName, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vobjCPPPayeeFirstName, PayeeFName));
                LogCapture.info("User entered Payee First Name as "+PayeeFName);

                String vobjPPPayeeLastName = Constants.PropertyPayDashboardOR.getProperty("PPPayeeLastName");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPPayeeLastName, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPPPayeeLastName, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPPPayeeLastName, PayeeLName));
                LogCapture.info("User entered Payee Last Name as "+PayeeLName);

                String vobjChooseCountryDropDown = Constants.PropertyPayDashboardOR.getProperty("ChooseCountryDropDown");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjChooseCountryDropDown, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjChooseCountryDropDown, ""));

                String vobjNoOfCountriesAddPayee = Constants.PropertyPayDashboardOR.getProperty("NoOfCountriesAddPayee");
                List<WebElement> elements = driver.findElements(By.xpath(vobjNoOfCountriesAddPayee));
                int numberOfElements = elements.size();
                if(numberOfElements==206)
                {
                    LogCapture.info("User verified Total 206 countries are present in the list");
                    System.out.println("Below is a list of 206 currencies.");

                }else
                {
                    LogCapture.info("TC Failed : User unable to verify 206 countries in the list");
                    Assert.fail();
                }

//        for(int i=1; i<=numberOfElements; i++)
//        {
//            String FilterOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//div//p";
//            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
//            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();
//            System.out.println(ActualFilterOptions);
//        }

                for(int i=1; i<=numberOfElements; i++)
                {
                    String CountryOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//div//p";
                    Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryOptions, ""));
                    String ActualCountryOptions = Constants.driver.findElement(By.xpath(CountryOptions)).getText();
                    if(ActualCountryOptions.equalsIgnoreCase(Country))
                    {
                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryOptions, ""));
                        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryOptions, ""));
                        LogCapture.info("User Select country as "+ActualCountryOptions+" from the list");
                        break;
                    }
                    else if(i== numberOfElements)
                    {
                        LogCapture.info("TC Failed : User unable to select country as "+Country+" from the List");
                        Assert.fail();
                    }
                }

                String vobjBankDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("BankDetailsHeader");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBankDetailsHeader, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vobjBankDetailsHeader, "Bank details"));
                LogCapture.info("User verify Bank details header on add New payee page");

                String vobjIBANNO = Constants.PropertyPayDashboardOR.getProperty("IBANNO");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIBANNO, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjIBANNO, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vobjIBANNO, "ES9121000418450200051332"));
                LogCapture.info("User entered IBAN as ES9121000418450200051332");

                String vobjswiftCode = Constants.PropertyPayDashboardOR.getProperty("swiftCode");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjswiftCode, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjswiftCode, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vobjswiftCode, "CAIXESBBXXX"));
                LogCapture.info("User entered swiftCode as CAIXESBBXXX");

                String vObjContinueButtonAddNewPayment = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonAddNewPayment");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContinueButtonAddNewPayment, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContinueButtonAddNewPayment, ""));
                LogCapture.info("User clicked on Continue Button");

                String vobjFraudWarning = Constants.PropertyPayDashboardOR.getProperty("FraudWarning");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudWarning, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vobjFraudWarning, "Protecting yourself from fraud"));
                LogCapture.info("User verify Protecting yourself from fraud header");

                String vobjFraudMessagePara1 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara1");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara1, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara1, "Before making this payment, ask yourself whether you have:"));
                LogCapture.info("User verify Fraud Message as as Below ");
                System.out.println("'Before making this payment, ask yourself whether you have:'");

                String vobjFraudMessagePara2 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara2");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara2, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara2, "been put under time pressure to make the payment?"));
                System.out.println("'been put under time pressure to make the payment?'");

                String vobjFraudMessagePara3 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara3");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara3, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara3, "been approached about your sale over social media?"));
                System.out.println("'been approached about your sale over social media?'");

                String vobjFraudMessagePara4 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara4");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara4, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara4, "been asked to pay up-front deposits or fees?"));
                System.out.println("'been asked to pay up-front deposits or fees?'");

                String vobjFraudMessagePara5 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara5");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara5, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara5, "been given vague or incomplete contact details?"));
                System.out.println("'been given vague or incomplete contact details?'");

                String vobjFraudMessagePara6 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara6");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara6, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara6, "spotted spelling mistakes or grammatical errors in any of the messages you've received?"));
                System.out.println("'spotted spelling mistakes or grammatical errors in any of the messages you've received?'");

                String vobjFraudMessagePara7 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara7");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara7, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara7, "been contacted with new account details?"));
                System.out.println("'been contacted with new account details?'");

                String vobjFraudMessagePara8 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara8");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara8, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara8, "If you answered yes to any of these questions, please"));
                System.out.println("'If you answered yes to any of these questions, please'");

                String vobjFraudMessagePara11 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara11");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara11, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara11, "Always verify that any bank account or payment details you’ve received by email are genuine using a trusted source, or by verbally verifying them with your payee."));
                System.out.println("'Always verify that any bank account or payment details you’ve received by email are genuine using a trusted source, or by verbally verifying them with your payee.'");

                String vobjFraudMessagePara12 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara12");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara12, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara12, "Remember that the safest way to retrieve or provide bank details is through our online service or app."));
                System.out.println("'Remember that the safest way to retrieve or provide bank details is through our online service or app.'");

                String vobjFraudMessagePara13 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara13");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara13, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara13, "Keeping your funds secure is our priority. Find out how you can protect your international payments and"));
                System.out.println("'Keeping your funds secure is our priority. Find out how you can protect your international payments and'");

                String vobjIHaveUnderstoodMessage = Constants.PropertyPayDashboardOR.getProperty("IHaveUnderstoodMessage");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIHaveUnderstoodMessage, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vobjIHaveUnderstoodMessage, "I've understood the warnings and am comfortable making this payment."));
                System.out.println("'I've understood the warnings and am comfortable making this payment.'");

                String vobjContinueButton = Constants.PropertyPayDashboardOR.getProperty("ContinueButton");
                String button = driver.findElement(By.xpath(vobjContinueButton)).getAttribute("class");
                if (button.contains("disabled")) {
                    LogCapture.info("User verify Continue button is Disabled before selecting checkBox details.");
                } else {
                    LogCapture.info("TC Failed : User verify continue Button is Enable");
                    Assert.fail();
                }

                Thread.sleep(2000);
                String vObjAgreeCheckBox = Constants.PropertyPayDashboardOR.getProperty("AgreeCheckBox");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAgreeCheckBox, ""));
                Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjAgreeCheckBox, ""));
                LogCapture.info("User clicked on CheckBox");

                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContinueButtonAddNewPayment, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContinueButtonAddNewPayment, ""));
                LogCapture.info("User clicked on Continue Button");



            } else if (PayeeType.equalsIgnoreCase("Company"))
            {
                String vObjPayeetype = "(//span[@class='MuiTypography-root MuiTypography-body1 MuiFormControlLabel-label css-1ruxavh'])[2]";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeetype, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPayeetype, ""));
                LogCapture.info("User Select Payee type as Company");

                String vobjPPCompanyName = Constants.PropertyPayDashboardOR.getProperty("PPCompanyName");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPCompanyName, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPPCompanyName, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPPCompanyName, CompanyName));
                LogCapture.info("User entered Company Name as "+CompanyName);

                String vobjChooseCountryDropDown = Constants.PropertyPayDashboardOR.getProperty("ChooseCountryDropDown");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjChooseCountryDropDown, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjChooseCountryDropDown, ""));

                String vobjNoOfCountriesAddPayee = Constants.PropertyPayDashboardOR.getProperty("NoOfCountriesAddPayee");
                List<WebElement> elements = driver.findElements(By.xpath(vobjNoOfCountriesAddPayee));
                int numberOfElements = elements.size();
                if(numberOfElements==206)
                {
                    LogCapture.info("User verified Total 206 countries are present in the list");
                    System.out.println("Below is a list of 206 currencies.");

                }else
                {
                    LogCapture.info("TC Failed : User unable to verify 206 countries in the list");
                    Assert.fail();
                }

//        for(int i=1; i<=numberOfElements; i++)
//        {
//            String FilterOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//div//p";
//            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
//            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();
//            System.out.println(ActualFilterOptions);
//        }

                for(int i=1; i<=numberOfElements; i++)
                {
                    String CurrencyOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//div//p";
                    Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CurrencyOptions, ""));
                    String ActualCurrencyOptions = Constants.driver.findElement(By.xpath(CurrencyOptions)).getText();
                    if(ActualCurrencyOptions.equalsIgnoreCase(Country))
                    {
                        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CurrencyOptions, ""));
                        Assert.assertEquals("PASS", Constants.key.click(CurrencyOptions, ""));
                        LogCapture.info("User Select country as "+ActualCurrencyOptions+" from the list");
                        break;
                    }
                    else if(i== numberOfElements)
                    {
                        LogCapture.info("TC Failed : User unable to select country as "+Country+" from the List");
                        Assert.fail();
                    }
                }

                String vobjBankDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("BankDetailsHeader");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBankDetailsHeader, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vobjBankDetailsHeader, "Bank details"));
                LogCapture.info("User verify Bank details header on add New payee page");

                String vobjIBANNO = Constants.PropertyPayDashboardOR.getProperty("IBANNO");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjIBANNO, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjIBANNO, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vobjIBANNO, "ES9121000418450200051332"));
                LogCapture.info("User entered IBAN as ES9121000418450200051332");

                String vobjswiftCode = Constants.PropertyPayDashboardOR.getProperty("swiftCode");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjswiftCode, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjswiftCode, ""));
                Assert.assertEquals("PASS", Constants.key.writeInInput(vobjswiftCode, "CAIXESBBXXX"));
                LogCapture.info("User entered swiftCode as CAIXESBBXXX");

                String vObjContinueButtonAddNewPayment = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonAddNewPayment");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContinueButtonAddNewPayment, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContinueButtonAddNewPayment, ""));
                LogCapture.info("User clicked on Continue Button");

                String vobjFraudWarning = Constants.PropertyPayDashboardOR.getProperty("FraudWarning");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudWarning, ""));
                Assert.assertEquals("PASS", Constants.key.verifyText(vobjFraudWarning, "Protecting yourself from fraud"));
                LogCapture.info("User verify Protecting yourself from fraud header");

                String vobjFraudMessagePara1 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara1");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara1, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara1, "Before making this payment, ask yourself whether you have:"));
                LogCapture.info("User verify Fraud Message as as Below ");
                System.out.println("'Before making this payment, ask yourself whether you have:'");

                String vobjFraudMessagePara2 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara2");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara2, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara2, "been put under time pressure to make the payment?"));
                System.out.println("'been put under time pressure to make the payment?'");

                String vobjFraudMessagePara3 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara3");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara3, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara3, "been approached about your sale over social media?"));
                System.out.println("'been approached about your sale over social media?'");

                String vobjFraudMessagePara4 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara4");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara4, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara4, "been asked to pay up-front deposits or fees?"));
                System.out.println("'been asked to pay up-front deposits or fees?'");

                String vobjFraudMessagePara5 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara5");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara5, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara5, "been given vague or incomplete contact details?"));
                System.out.println("'been given vague or incomplete contact details?'");

                String vobjFraudMessagePara6 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara6");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara6, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara6, "spotted spelling mistakes or grammatical errors in any of the messages you've received?"));
                System.out.println("'spotted spelling mistakes or grammatical errors in any of the messages you've received?'");

                String vobjFraudMessagePara7 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara7");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara7, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara7, "been contacted with new account details?"));
                System.out.println("'been contacted with new account details?'");

                String vobjFraudMessagePara8 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara8");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara8, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara8, "If you answered yes to any of these questions, please"));
                System.out.println("'If you answered yes to any of these questions, please'");

                String vobjFraudMessagePara11 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara11");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara11, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara11, "Always verify that any bank account or payment details you’ve received by email are genuine using a trusted source, or by verbally verifying them with your payee."));
                System.out.println("'Always verify that any bank account or payment details you’ve received by email are genuine using a trusted source, or by verbally verifying them with your payee.'");

                String vobjFraudMessagePara12 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara12");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara12, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara12, "Remember that the safest way to retrieve or provide bank details is through our online service or app."));
                System.out.println("'Remember that the safest way to retrieve or provide bank details is through our online service or app.'");

                String vobjFraudMessagePara13 = Constants.PropertyPayDashboardOR.getProperty("FraudMessagePara13");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFraudMessagePara13, ""));
                Assert.assertEquals("PASS", Constants.key.verifyTextNew(vobjFraudMessagePara13, "Keeping your funds secure is our priority. Find out how you can protect your international payments and"));
                System.out.println("'Keeping your funds secure is our priority. Find out how you can protect your international payments and'");

                String vobjContinueButton = Constants.PropertyPayDashboardOR.getProperty("ContinueButton");
                String button = driver.findElement(By.xpath(vobjContinueButton)).getAttribute("class");
                if (button.contains("disabled")) {
                    LogCapture.info("User verify Continue button is Disabled before selecting checkBox details.");
                } else {
                    LogCapture.info("TC Failed : User verify continue Button is Enable");
                    Assert.fail();
                }

                Thread.sleep(2000);
                String vObjAgreeCheckBox = Constants.PropertyPayDashboardOR.getProperty("AgreeCheckBox");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAgreeCheckBox, ""));
                Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjAgreeCheckBox, ""));
                LogCapture.info("User clicked on CheckBox");

                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContinueButtonAddNewPayment, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContinueButtonAddNewPayment, ""));
                LogCapture.info("User clicked on Continue Button");

            }


        }
        else if(Option.equalsIgnoreCase("Saved recipients"))
        {
            String vobjContinueButtonAmountToBeFunded = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonAmountToBeFunded");
            String button = driver.findElement(By.xpath(vobjContinueButtonAmountToBeFunded)).getAttribute("class");
            if (button.contains("disabled")) {
                LogCapture.info("User verify Continue button is Disabled before selecting Saved recipients option.");
            } else {
                LogCapture.info("TC Failed : User verify continue Button is Enable before selecting Saved recipients option.");
                Assert.fail();
            }

            String vobjSavedPayee = Constants.PropertyPayDashboardOR.getProperty("SavedPayee");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSavedPayee, ""));
            Assert.assertEquals("PASS", Constants.key.click(vobjSavedPayee, ""));
            LogCapture.info("User Select Saved recipients option");

            String vObjSearchRecipient = Constants.PropertyPayDashboardOR.getProperty("SearchRecipient");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSearchRecipient, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjSearchRecipient, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSearchRecipient, ExistingPayeeName));
            LogCapture.info("User search for payee as Jack");

            String vObjFirstRecipientSearched = Constants.PropertyPayDashboardOR.getProperty("FirstRecipientSearched");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirstRecipientSearched, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjFirstRecipientSearched, ""));
            String PayeeSelected = Constants.key.getText(vObjFirstRecipientSearched, "");
            LogCapture.info("User select payee as "+ PayeeSelected + " From the list");

            String vObjContinueButtonAddNewPayment = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonAddNewPayment");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjContinueButtonAddNewPayment, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjContinueButtonAddNewPayment, ""));
            LogCapture.info("User clicked on Continue Button");


        }



    }

    @And("^User enter details on create transaction, country as \"([^\"]*)\" , Currency as \"([^\"]*)\" and Address as \"([^\"]*)\" and click on Save and Continue for tablet view$")
    public void userEnterDetailsOnCreateTransactionCountryAsCurrencyAsAndAddressAsAndClickOnSaveAndContinueForTabletView(String ExpCountry, String ExpCurrencyOptions, String ExpAddress) throws Throwable {

        PPPropertyAddress=ExpAddress;
        String vobjCreateTransactionSaveAndContinueButtone = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionSaveAndContinueButton");
        WebElement button = driver.findElement(By.cssSelector(vobjCreateTransactionSaveAndContinueButtone));
        boolean isDisabled = !button.isEnabled();
        if (isDisabled) {
            LogCapture.info("User verify Save and Continue button is Disabled before entering details.");
        } else {
            LogCapture.info("TC Failed : Save and continue Button is Enable");
            Assert.fail();
        }

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("ddMMyyyyHHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        String vobjFileReference = Constants.PropertyPayDashboardOR.getProperty("FileReference");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFileReference, ""));
        Assert.assertEquals("PASS", Constants.key.click(vobjFileReference, ""));
        PPFileReference="AUTOS4UR48H"+CurrentTimeTimeHHMM;
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjFileReference, PPFileReference));
        LogCapture.info("User entered Reference as" + "AUTOS4UR48H"+CurrentTimeTimeHHMM);

        String Valuedate;
        String vObjCalenderButtonTablet = Constants.PropertyPayDashboardOR.getProperty("CalenderButtonTablet");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCalenderButtonTablet, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCalenderButtonTablet, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        DateFormat dateFormat = new SimpleDateFormat("dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 2);
        Valuedate = dateFormat.format(cal.getTime());
        String vObjComplectionDate1="";
        String vObjComplectionDate2="";
        String ComplectionDate = "//button[text()='"+Valuedate+"']";

        List<WebElement> Dateelements = driver.findElements(By.xpath(ComplectionDate));
        int numberOfDateElements = Dateelements.size();
        if(numberOfDateElements==2)
        {
            vObjComplectionDate1 ="(//button[text()='"+Valuedate+"'])[1]";
            vObjComplectionDate2 ="(//button[text()='"+Valuedate+"'])[2]";

            String DateAttribute1 = driver.findElement(By.xpath(vObjComplectionDate1)).getAttribute("class");
            String DateAttribute2 = driver.findElement(By.xpath(vObjComplectionDate2)).getAttribute("class");

            if (!DateAttribute1.contains("disabled"))
            {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate1, ""));
                DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                Calendar Calender1 = Calendar.getInstance();
                Calender1.setTime(new Date());
                Calender1.add(Calendar.DATE, 2);
                String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
                LogCapture.info("User select completion date as " + CompletionDate);
            }

            if (!DateAttribute2.contains("disabled"))
            {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate2, ""));
                DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                Calendar Calender1 = Calendar.getInstance();
                Calender1.setTime(new Date());
                Calender1.add(Calendar.DATE, 2);
                String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
                LogCapture.info("User select completion date as " + CompletionDate);
            }
        }else
        {
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjComplectionDate1, ""));
            DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Calendar Calender1 = Calendar.getInstance();
            Calender1.setTime(new Date());
            Calender1.add(Calendar.DATE, 2);
            String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
            LogCapture.info("User select completion date as " + CompletionDate);
        }

        String vobjTabDateOKButton = Constants.PropertyPayDashboardOR.getProperty("TabDateOKButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTabDateOKButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTabDateOKButton, ""));

        String vobjCreateTransactionCountry = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionCountry");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionCountry, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionCountry, ""));

        String vobjCreateTransactionListOfCountries = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionListOfCountries");
        List<WebElement> elements = driver.findElements(By.xpath(vobjCreateTransactionListOfCountries));
        int numberOfElements = elements.size();
        if(numberOfElements==207)
        {
            LogCapture.info("User verified Total 207 countries are present in the list");
            System.out.println("Below is a list of 207 currencies.");

        }else
        {
            LogCapture.info("TC Failed : User unable to verify 207 countries in the list");
            Assert.fail();
        }

//        for(int i=1; i<=numberOfElements; i++)
//        {
//            String FilterOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//div//p";
//            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
//            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();
//            System.out.println(ActualFilterOptions);
//        }

        for(int i=1; i<=numberOfElements; i++)
        {
            String FilterOptions = "(//ul[@class='MuiAutocomplete-listbox css-10danr5']//li)["+i+"]//div//p";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();
            if(ActualFilterOptions.equalsIgnoreCase(ExpCountry))
            {
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(FilterOptions, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(FilterOptions, ""));
                LogCapture.info("User Select country as "+ExpCountry+" from the list");
                break;
            }
            else if(i== numberOfElements)
            {
                LogCapture.info("TC Failed : User unable to select country as "+ExpCountry+" from the List");
                Assert.fail();
            }
        }

        String vobjCreateTransactionAddress = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionAddress, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionAddress, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjCreateTransactionAddress, ExpAddress));

        String vobjCreateTransactionFirstAddressfromList = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionFirstAddressfromList");
        Thread.sleep(3000);
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionFirstAddressfromList, ""));
        String FirstAddressfromList = Constants.driver.findElement(By.xpath(vobjCreateTransactionFirstAddressfromList)).getText();
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionFirstAddressfromList, ""));
        LogCapture.info("User entered Address as " + FirstAddressfromList);
        Thread.sleep(3000);

        PPPurchaseValue = Integer.toString(ThreadLocalRandom.current().nextInt(1000, 1500));
        String vobjCreateTransactionPurchaseValue = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionPurchaseValue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionPurchaseValue, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionPurchaseValue, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjCreateTransactionPurchaseValue, PPPurchaseValue));
        LogCapture.info("User entered purchase value as " + PPPurchaseValue);

        String vobjCreateTransactionCurrency = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionCurrency");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreateTransactionCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreateTransactionCurrency, ""));

        String vobjCreateTransactionListOfCurrencies = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionListOfCurrencies");
        List<WebElement> CCYelements = driver.findElements(By.xpath(vobjCreateTransactionListOfCurrencies));
        int numberOfCurrencies = CCYelements.size();
        if(numberOfCurrencies==26)
        {
            LogCapture.info("User verified Total 26 Currencies are present in the list");
            System.out.println("Below is a list of 26 Currencies.");

        }else
        {
            LogCapture.info("TC Failed : User unable to verify 26 Currencies in the list");
            Assert.fail();
        }

//        for(int i=1; i<=numberOfCurrencies; i++)
//        {
//            String CurrencyOptions = "//ul[@class='MuiAutocomplete-listbox css-10danr5']//li["+i+"]//div//p";
//            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CurrencyOptions, ""));
//            String ActualCurrencyOptions = Constants.driver.findElement(By.xpath(CurrencyOptions)).getText();
//            System.out.println(ActualCurrencyOptions);
//        }

        for(int i=1; i<=numberOfCurrencies; i++)
        {
            String CurrencyOptions = "//ul[@class='MuiAutocomplete-listbox css-10danr5']//li["+i+"]//div//p";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CurrencyOptions, ""));
            String ActualCurrencyOptions = Constants.driver.findElement(By.xpath(CurrencyOptions)).getText();

            if(ActualCurrencyOptions.equalsIgnoreCase(ExpCurrencyOptions))
            {
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CurrencyOptions, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CurrencyOptions, ""));
                LogCapture.info("User Select Currency as "+ActualCurrencyOptions+" from the list");
                break;
            }
            else if(i== numberOfCurrencies)
            {
                LogCapture.info("TC Failed : User unable to select Currency as "+ExpCountry+" from the List");
                Assert.fail();
            }
        }

        String vobjSaveAndContinueButton = Constants.PropertyPayDashboardOR.getProperty("SaveAndContinueButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSaveAndContinueButton, ""));
        String SaveAndContButton = Constants.driver.findElement(By.xpath(vobjSaveAndContinueButton)).getText();
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjSaveAndContinueButton, ""));
        LogCapture.info("User Click on "+SaveAndContButton+" Button");

    }


    @When("^For a \"([^\"]*)\" call Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for PropertyPay$")
    public void forACallCheckStatusCodeAsForOnEnvironmentForPropertyPay(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("POST")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate the response for create transaction API$")
    public void userValidateTheResponseForCreateTransactionAPI() {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        PPTransactionRefereneID = Integer.toString(jp.get("data.id"));
        LogCapture.info("User verified Transaction ID as >> " + PPTransactionRefereneID);

        Assert.assertEquals("PASS", ReusableMethod.compareString(PPFileReference, jp.get("data.fileReference")));
        LogCapture.info("User verified file Reference as >> " + jp.get("data.fileReference"));

        String purchaseValue = Float.toString(jp.get("data.purchaseValue"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(PPPurchaseValue+".0", purchaseValue));
        LogCapture.info("User verified purchase Value as >> " + jp.get("data.purchaseValue"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("EUR", jp.get("data.currency")));
        LogCapture.info("User verified Currency as >> " + jp.get("data.currency"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Open", jp.get("data.transactionStatus")));
        LogCapture.info("User verified transaction Status as >> " + jp.get("data.transactionStatus"));

        String leftToPay = Float.toString(jp.get("data.leftToPay"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(PPPurchaseValue+".0", leftToPay));
        LogCapture.info("User verified transaction Purchase Value as >> " + PPPurchaseValue);

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @When("^User enter UserName \"([^\"]*)\" password \"([^\"]*)\" and click log In button for PropertyPay$")
    public void userEnterUserNamePasswordAndClickLogInButtonForPropertyPay(String userName, String password) throws Throwable {

//        String vUserName = Constants.CONFIG.getProperty(userName);
//        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.PropertyPayDashboardOR.getProperty("PPUserName");
        String vObjPass = Constants.PropertyPayDashboardOR.getProperty("PPPassword");
        LogCapture.info("User Name [" + userName + "], and Password ["+password+"] is validated ....");
        Constants.key.VisibleConditionWait(vObjUser, "");
        Assert.assertEquals("PASS", Constants.key.click(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, userName));
        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, password));
        Constants.key.pause("2", "");
        String vObjLoginButton = Constants.PropertyPayDashboardOR.getProperty("LoginContinueButton");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjLoginButton, ""));

    }

    @Then("^User verify the details present on Property Pay Login page$")
    public void userVerifyTheDetailsPresentOnPropertyPayLoginPage() throws Exception {

        Thread.sleep(3000);
        String vobjLoginToYourAccount = Constants.PropertyPayDashboardOR.getProperty("LoginToYourAccount");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjLoginToYourAccount, "Log in to your account"));
        LogCapture.info("User verified Log in to your account header is visible on Login Page");

        String vobjUseYourCDAccountMessage = Constants.PropertyPayDashboardOR.getProperty("UseYourCDAccountMessage");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjUseYourCDAccountMessage, "Use your Currencies Direct account login if you have one."));
        LogCapture.info("User verified message as [Use your Currencies Direct account login if you have one.] on Login Page");


        String vobjEmailTabel = Constants.PropertyPayDashboardOR.getProperty("EmailTabel");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjEmailTabel, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjEmailTabel, "Email address"));
        LogCapture.info("User verified label as Email address on Login Page");

        String vobjPasswordLabel = Constants.PropertyPayDashboardOR.getProperty("PasswordLabel");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPasswordLabel, "Password"));
        LogCapture.info("User verified label as Password on Login Page");

        String vobjForgotYourPassword = Constants.PropertyPayDashboardOR.getProperty("ForgotYourPassword");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjForgotYourPassword, "Forgot your password?"));
        LogCapture.info("User verified Forgot your password? text on Login Page");

        String vobjDontHaveAccount = Constants.PropertyPayDashboardOR.getProperty("DontHaveAccount");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDontHaveAccount, "create an account"));
        LogCapture.info("User verified Don’t have an account? text on Login Page");

        String vobjResetPasswordLink = Constants.PropertyPayDashboardOR.getProperty("ResetPasswordLink");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjResetPasswordLink, "Reset it"));
        LogCapture.info("User verified  Reset it link on Login Page");

        String vobjCreateAccountLink = Constants.PropertyPayDashboardOR.getProperty("CreateAccountLink");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCreateAccountLink, "create an account"));
        LogCapture.info("User verified Create an account link on Login Page");

        String vobjTermsLinkOnLogin = Constants.PropertyPayDashboardOR.getProperty("TermsLinkOnLogin");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjTermsLinkOnLogin, "Terms"));
        LogCapture.info("User verified Terms link on Login Page");

        String vobjPrivacyLinkOnLogin = Constants.PropertyPayDashboardOR.getProperty("PrivacyLinkOnLogin");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPrivacyLinkOnLogin, "Privacy"));
        LogCapture.info("User verified Privacy link on Login Page");

        String vobjCookiesLinkOnLogin = Constants.PropertyPayDashboardOR.getProperty("CookiesLinkOnLogin");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCookiesLinkOnLogin, "Cookies"));
        LogCapture.info("User verified Cookies link on Login Page");

        String vobjRegulatoryLinkOnLogin = Constants.PropertyPayDashboardOR.getProperty("RegulatoryLinkOnLogin");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRegulatoryLinkOnLogin, "Regulatory"));
        LogCapture.info("User verified Regulatory link on Login Page");

    }

    @And("^User landed on the Party Details page, verify the Settlement agent's details then enters the details for \"([^\"]*)\" party, and clicks the Continue button$")
    public void userLandedOnThePartyDetailsPageVerifyTheSettlementAgentSDetailsThenEntersTheDetailsForPartyAndClicksTheContinueButton(String NoOfParty) throws Throwable {

        NoOfParties=NoOfParty;
        if(NoOfParties.equals("1"))
        {
            String vobjPartyDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyDetailsHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPartyDetailsHeader, "Party details"));
            LogCapture.info("User verified its landed on Party details page");

            String vobjCreatePartyDetailsContinueButton = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsContinueButton");
//            WebElement button = driver.findElement(By.xpath(vobjCreatePartyDetailsContinueButton));
//            boolean isDisabled = !button.isEnabled();
//            if (isDisabled) {
//                LogCapture.info("User verify Continue button is Disabled before entering details.");
//            } else {
//                LogCapture.info("TC Failed : User verify continue Button is Enable");
//                Assert.fail();
//            }

            String vobjParty1Header = Constants.PropertyPayDashboardOR.getProperty("Party1Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty1Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty1Header, "Party 1"));
            LogCapture.info("User verify Party1 Header on Party details page");

            String RandomFirstname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            String RandomLastname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            PPPartyFullName = "Donald" + RandomFirstname + " " + "Biden" + RandomLastname;


            String vobjPartyFullName = Constants.PropertyPayDashboardOR.getProperty("PartyFullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyFullName, PPPartyFullName));
            LogCapture.info("User enter Party Full Name as" + PPPartyFullName);

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
            String CurrentTimeTimeHHMM = TimeHHMM.format(now);
            Constants.PPPartyEmail = "saurabhpropertypay" + CurrentTimeTimeHHMM + "@mailinator.com";

            String vobjPartyEmail = Constants.PropertyPayDashboardOR.getProperty("PartyEmail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyEmail, PPPartyEmail));
            LogCapture.info("User enter Party Email as " + PPPartyEmail);

            String CountryCode= "+91";
            String vobjPartyCountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("PartyCountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyCountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyCountryCodeDropdown, ""));

            String vobjPartyDetailsCountryCodeList = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsCountryCodeList");
            List<WebElement> CountryCodeElements = driver.findElements(By.xpath(vobjPartyDetailsCountryCodeList));
            int numberOfCountryCodes = CountryCodeElements.size();
            if(numberOfCountryCodes==168)
            {
                LogCapture.info("User verified Total 168 country codes are present in the list");
                System.out.println("Below is a list of 168 country code.");

            }else
            {
                LogCapture.info("TC Failed : User unable to verify 18 country codes in the list");
                Assert.fail();
            }

//            for(int i=1; i<=numberOfCountryCodes; i++)
//            {
//                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]";
//                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
//                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();
//                System.out.println(ActualCountryCodeOptions);
//            }

            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPPartyMobileNo="9000012345";
            String vobjPartyMobile = Constants.PropertyPayDashboardOR.getProperty("PartyMobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyMobile, PPPartyMobileNo));
            LogCapture.info("User enter Party Mobile Number as " + PPPartyMobileNo);

            Thread.sleep(2000);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreatePartyDetailsContinueButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreatePartyDetailsContinueButton, ""));

        } else if (NoOfParties.equals("2"))
        {
            String vobjPartyDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyDetailsHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPartyDetailsHeader, "Party details"));
            LogCapture.info("User verified its landed on Party details page");

            String vobjCreatePartyDetailsContinueButton = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsContinueButton");
            WebElement button = driver.findElement(By.xpath(vobjCreatePartyDetailsContinueButton));
            boolean isDisabled = !button.isEnabled();
            if (isDisabled) {
                LogCapture.info("User verify Continue button is Disabled before entering details.");
            } else {
                LogCapture.info("TC Failed : User verify continue Button is Enable");
                Assert.fail();
            }

            String vobjParty1Header = Constants.PropertyPayDashboardOR.getProperty("Party1Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty1Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty1Header, "Party 1"));
            LogCapture.info("User verify Party1 Header on Party details page");

            String RandomFirstname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            String RandomLastname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            PPPartyFullName = "Donald" + RandomFirstname + " " + "Biden" + RandomLastname;


            String vobjPartyFullName = Constants.PropertyPayDashboardOR.getProperty("PartyFullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyFullName, PPPartyFullName));
            LogCapture.info("User enter Party Full Name as" + PPPartyFullName);

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
            String CurrentTimeTimeHHMM = TimeHHMM.format(now);
            Constants.PPPartyEmail = "saurabhpropertypay" +RandomStringUtils.randomAlphabetic(5).toLowerCase()+ CurrentTimeTimeHHMM + "1@mailinator.com";

            String vobjPartyEmail = Constants.PropertyPayDashboardOR.getProperty("PartyEmail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyEmail, PPPartyEmail));
            LogCapture.info("User enter Party Email as " + PPPartyEmail);

            String CountryCode= "+91";
            String vobjPartyCountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("PartyCountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyCountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyCountryCodeDropdown, ""));

            String vobjPartyDetailsCountryCodeList = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsCountryCodeList");
            List<WebElement> CountryCodeElements = driver.findElements(By.xpath(vobjPartyDetailsCountryCodeList));
            int numberOfCountryCodes = CountryCodeElements.size();
            if(numberOfCountryCodes==168)
            {
                LogCapture.info("User verified Total 168 country codes are present in the list");
                System.out.println("Below is a list of 168 country code.");

            }else
            {
                LogCapture.info("TC Failed : User unable to verify 18 country codes in the list");
                Assert.fail();
            }

//            for(int i=1; i<=numberOfCountryCodes; i++)
//            {
//                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]";
//                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
//                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();
//                System.out.println(ActualCountryCodeOptions);
//            }

            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPPartyMobileNo="9000012345";
            String vobjPartyMobile = Constants.PropertyPayDashboardOR.getProperty("PartyMobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyMobile, PPPartyMobileNo));
            LogCapture.info("User enter Party Mobile Number as " + PPPartyMobileNo);

            String vobjAddAnotherParty = Constants.PropertyPayDashboardOR.getProperty("AddAnotherParty");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAddAnotherParty, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjAddAnotherParty, ""));
            LogCapture.info("User click on Add another party to add Second Party");


            String vobjParty2Header = Constants.PropertyPayDashboardOR.getProperty("Party2Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty2Header, "Party 2"));
            LogCapture.info("User verify Party 2 Header on Party details page");

            PPParty2FullName = "Justin" + RandomStringUtils.randomAlphabetic(6).toLowerCase() + " " + "Trudeau" + RandomStringUtils.randomAlphabetic(6).toLowerCase();
            String vobjParty2FullName = Constants.PropertyPayDashboardOR.getProperty("Party2FullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2FullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2FullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2FullName, PPParty2FullName));
            LogCapture.info("User enter Party2 Full Name as" + PPParty2FullName);
            Thread.sleep(2000);

            Constants.PPParty2Email = "saurabhpropertypay" +RandomStringUtils.randomAlphabetic(5).toLowerCase()+ CurrentTimeTimeHHMM + "2@mailinator.com";
            String vobjParty2Email = Constants.PropertyPayDashboardOR.getProperty("Party2Email");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Email, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2Email, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2Email, PPParty2Email));
            LogCapture.info("User enter Party Email as " + PPParty2Email);


            String vobjParty2CountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("Party2CountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2CountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2CountryCodeDropdown, ""));


            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPParty2MobileNo="9000012345";
            String vobjParty2Mobile = Constants.PropertyPayDashboardOR.getProperty("Party2Mobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Mobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2Mobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2Mobile, PPParty2MobileNo));
            LogCapture.info("User enter Party 2 Mobile Number as" + PPParty2MobileNo);

            Thread.sleep(2000);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreatePartyDetailsContinueButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreatePartyDetailsContinueButton, ""));

        }


    }

    @When("^For a \"([^\"]*)\" call User Generate PreData for transaction creation and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for PropertyPay$")
    public void forACallUserGeneratePreDataForTransactionCreationAndCheckStatusCodeAsForOnEnvironmentForPropertyPay(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {

        PPPurchaseValue = Integer.toString(ThreadLocalRandom.current().nextInt(1000, 1500));
        DynamicValue.put("<PPPurchaseValue>", PPPurchaseValue);

        DateFormat SelectedDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Calendar Calender1 = Calendar.getInstance();
        Calender1.setTime(new Date());
        Calender1.add(Calendar.DATE, 5);
        String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
        DynamicValue.put("<CompletionDate>", CompletionDate);
        LogCapture.info("User select completion date as " + CompletionDate);

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("ddMMyyyyHHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);
        PPFileReference="APIAUTOS4UR48H"+CurrentTimeTimeHHMM;
        DynamicValue.put("<PPFileReference>", PPFileReference);
        LogCapture.info("User entered Reference as " + PPFileReference);

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("POST")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else{
            LogCapture.info("User entered wrong method type");
            Assert.fail();
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @When("^For a \"([^\"]*)\" call User create address and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for PropertyPay$")
    public void forACallUserCreateAddressAndCheckStatusCodeAsForOnEnvironmentForPropertyPay(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {

        DynamicValue.put("<PPTransactionRefereneID>", PPTransactionRefereneID);

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("POST")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else{
            LogCapture.info("User entered wrong method type");
            Assert.fail();
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");


    }

    @Then("^User Validate the response for create Address API$")
    public void userValidateTheResponseForCreateAddressAPI() {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        PPCreateAddressID = Integer.toString(jp.get("data.transactionId"));
        LogCapture.info("User verified Create Address ID as >> " + PPCreateAddressID);

        Assert.assertEquals("PASS", ReusableMethod.compareString(PPTransactionRefereneID, Integer.toString(jp.get("data.transactionId"))));
        LogCapture.info("User verified Transaction ID as >> " + PPTransactionRefereneID);

        Assert.assertEquals("PASS", ReusableMethod.compareString("ESP", jp.get("data.countryCode")));
        LogCapture.info("User verified country Code as >> " + jp.get("data.countryCode"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("C/ Rosa de los", jp.get("data.addressLine1")));
        LogCapture.info("User verified address Line1 as >> " + jp.get("data.addressLine1"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Vientos 56", jp.get("data.addressLine2")));
        LogCapture.info("User verified address Line2 as >> " + jp.get("data.addressLine2"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Ogden Lane", jp.get("data.addressLine3")));
        LogCapture.info("User verified address Line3 as >> " + jp.get("data.addressLine3"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Downtown", jp.get("data.suburbCity")));
        LogCapture.info("User verified suburb City as >> " + jp.get("data.suburbCity"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Cádiz", jp.get("data.province")));
        LogCapture.info("User verified province as >> " + jp.get("data.province"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Puerto Real", jp.get("data.townCity")));
        LogCapture.info("User verified town City as >> " + jp.get("data.townCity"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Spain", jp.get("data.county")));
        LogCapture.info("User verified county as >> " + jp.get("data.county"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("11510", jp.get("data.postcode")));
        LogCapture.info("User verified postcode as >> " + jp.get("data.postcode"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Cádiz", jp.get("data.state")));
        LogCapture.info("User verified state as >> " + jp.get("data.state"));

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }


    @When("^For a \"([^\"]*)\" call User Generate PreData for add party and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for PropertyPay$")
    public void forACallUserGeneratePreDataForAddPartyAndCheckStatusCodeAsForOnEnvironmentForPropertyPay(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {

        DynamicValue.put("<PPTransactionRefereneID>", PPTransactionRefereneID);

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("ddMMyyyyHHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);
        PPPartyFullName="SaurabhProp Party"+CurrentTimeTimeHHMM;
        DynamicValue.put("<PPPartyFullName>", PPPartyFullName);
        LogCapture.info("User entered Party Full Name as " + PPPartyFullName);

        PPPartyEmail="SaurabhPropParty"+CurrentTimeTimeHHMM+"@gmail.com";
        DynamicValue.put("<PPPartyEmail>", PPPartyEmail);
        LogCapture.info("User entered Party Email as " + PPPartyEmail);

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("POST")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else{
            LogCapture.info("User entered wrong method type");
            Assert.fail();
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");


    }

    @Then("^User Validate the response for create party API$")
    public void userValidateTheResponseForCreatePartyAPI() {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        PPCreateAddressID = Integer.toString(jp.get("data.id"));
        LogCapture.info("User verified Create Address ID as >> " + PPCreateAddressID);

        Assert.assertEquals("PASS", ReusableMethod.compareString(PPTransactionRefereneID, Integer.toString(jp.get("data.transactionId"))));
        LogCapture.info("User verified Transaction ID as >> " + PPTransactionRefereneID);

        Assert.assertEquals("PASS", ReusableMethod.compareString("ESP", jp.get("data.countryCode")));
        LogCapture.info("User verified country Code as >> " + jp.get("data.countryCode"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("C/ Rosa de los", jp.get("data.addressLine1")));
        LogCapture.info("User verified address Line1 as >> " + jp.get("data.addressLine1"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Vientos 56", jp.get("data.addressLine2")));
        LogCapture.info("User verified address Line2 as >> " + jp.get("data.addressLine2"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Ogden Lane", jp.get("data.addressLine3")));
        LogCapture.info("User verified address Line3 as >> " + jp.get("data.addressLine3"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Downtown", jp.get("data.suburbCity")));
        LogCapture.info("User verified suburb City as >> " + jp.get("data.suburbCity"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Cádiz", jp.get("data.province")));
        LogCapture.info("User verified province as >> " + jp.get("data.province"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Puerto Real", jp.get("data.townCity")));
        LogCapture.info("User verified town City as >> " + jp.get("data.townCity"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Spain", jp.get("data.county")));
        LogCapture.info("User verified county as >> " + jp.get("data.county"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("11510", jp.get("data.postcode")));
        LogCapture.info("User verified postcode as >> " + jp.get("data.postcode"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Cádiz", jp.get("data.state")));
        LogCapture.info("User verified state as >> " + jp.get("data.state"));

        LogCapture.info("======================================= Response Validations Ended =======================================");


    }

    @And("^User Verify the payment request details and the account to be funded details on the confirmation page, then clicks the Continue button$")
    public void userVerifyThePaymentRequestDetailsAndTheAccountToBeFundedDetailsOnTheConfirmationPageThenClicksTheContinueButton() throws Exception {

        String vobjConfirmationHeaderOnPaymentRequestConf = Constants.PropertyPayDashboardOR.getProperty("ConfirmationHeaderOnPaymentRequestConf");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfirmationHeaderOnPaymentRequestConf, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfirmationHeaderOnPaymentRequestConf, "Confirmation"));
        LogCapture.info("User verify Header as Confirmation on add Payment request page");

        String vobjRequestDetailsHeaderOnPaymentRequestConf = Constants.PropertyPayDashboardOR.getProperty("RequestDetailsHeaderOnPaymentRequestConf");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjRequestDetailsHeaderOnPaymentRequestConf, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRequestDetailsHeaderOnPaymentRequestConf, "Request details"));
        LogCapture.info("User verify Header as Request details on add Payment request page");

        String vobjPayeeNameHeader = Constants.PropertyPayDashboardOR.getProperty("PayeeNameHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPayeeNameHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPayeeNameHeader, "Payee name(s)"));
        LogCapture.info("User verify Header as Payee name(s) under Payment Request detail on add Payment request page");

        String vobjRequestTypeHeader = Constants.PropertyPayDashboardOR.getProperty("RequestTypeHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjRequestTypeHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRequestTypeHeader, "Request type"));
        LogCapture.info("User verify Header as Request type under Payment Request detail on add Payment request page");

        String vobjPaymentRequestValueHeader = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestValueHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentRequestValueHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentRequestValueHeader, "Payment request value"));
        LogCapture.info("User verify Header as Payment request value under Payment Request detail on add Payment request page");

        String vobjPaymentDueDateHeader = Constants.PropertyPayDashboardOR.getProperty("PaymentDueDateHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentDueDateHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentDueDateHeader, "Payment due date"));
        LogCapture.info("User verify Header as PPayment due date under Payment Request detail on add Payment request page");

        String vobjEditPaymentRequestOption = Constants.PropertyPayDashboardOR.getProperty("EditPaymentRequestOption");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjEditPaymentRequestOption, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjEditPaymentRequestOption, "Edit"));
        LogCapture.info("User verify Edit Payment Request option on add Payment request page");

        String vobjEditAccountToBeFunded = Constants.PropertyPayDashboardOR.getProperty("EditAccountToBeFunded");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjEditAccountToBeFunded, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjEditAccountToBeFunded, "Edit"));
        LogCapture.info("User verify Edit Account to be funded option on add Payment request page");

        if(NoOfParties.equals("1"))
        {
            String vObjPartyName = Constants.PropertyPayDashboardOR.getProperty("PartyName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPartyName, ""));
            String PartyName = Constants.driver.findElement(By.xpath(vObjPartyName)).getText();
            if(PartyName.contains(PPPartyFullName))
            {
                LogCapture.info("User verified Party Name as " +PPPartyFullName+ " Under Payment Request Details on confirmation page");
            }
            else
            {
                LogCapture.info("TC Failed : User Unable to verify Party Name as " +PPPartyFullName+ " Under Payment Request Details on confirmation page");
                Assert.fail();
            }

            String vObjRequestType = Constants.PropertyPayDashboardOR.getProperty("RequestType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRequestType, ""));
            String RequestType = Constants.driver.findElement(By.xpath(vObjRequestType)).getText();
            if(RequestType.equals(PaymentTypesOption))
            {
                LogCapture.info("User verified Payment Types as " +PaymentTypesOption+ " Under Payment Request Details on confirmation page");
            }
            else
            {
                LogCapture.info("TC Failed : User Unable to verify Payment Types as " +PaymentTypesOption+ " Under Payment Request Details on confirmation page");
                Assert.fail();
            }

            String vObjPaymentRequestAmount = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestAmount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentRequestAmount, ""));
            String ActualPaymentrequestAmount = Constants.driver.findElement(By.xpath(vObjPaymentRequestAmount)).getText();
            if(ActualPaymentrequestAmount.contains(PaymentRequestsCurrency))
            {
                LogCapture.info("User verified Payment request Amount as " +ActualPaymentrequestAmount+ " Under Payment Request Details on confirmation page");
            }
            else
            {
                LogCapture.info("TC Failed : User Unable to verify Payment request Amount as " +ActualPaymentrequestAmount+ " Under Payment Request Details on confirmation page");
                Assert.fail();
            }

            String vObjPaymentrequestDueDate = Constants.PropertyPayDashboardOR.getProperty("PaymentrequestDueDate");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentrequestDueDate, ""));
            String ActualPaymentrequestDueDate = Constants.driver.findElement(By.xpath(vObjPaymentrequestDueDate)).getText();
            DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Calendar Calender1 = Calendar.getInstance();
            Calender1.setTime(new Date());
            Calender1.add(Calendar.DATE, 5);
            String PaymentDueDateDate = SelectedDateFormat.format(Calender1.getTime());

            if (PaymentDueDateDate.charAt(0) == '0')
            {
                PaymentDueDateDate.replace("0", "");
            }

            if (PaymentDueDateDate.toString().contains("/0"))
            {
                PaymentDueDateDate = PaymentDueDateDate.toString().replace("/0","/");
            }else
            {
                PaymentDueDateDate =PaymentDueDateDate.toString();
            }

            if(ActualPaymentrequestDueDate.equals(PaymentDueDateDate))
            {
                LogCapture.info("User verified Payment Due Date as " +ActualPaymentrequestDueDate+ " Under Payment Request Details on confirmation page");
            }
            else
            {
                LogCapture.info("TC Failed : User Unable to verify Payment Due Date as " +ActualPaymentrequestDueDate+ " Under Payment Request Details on confirmation page");
//                Assert.fail();
            }

        }
        if(NoOfParties.equals("2"))
        {
            String vObjPartyName = Constants.PropertyPayDashboardOR.getProperty("PartyName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPartyName, ""));
            String PartyName = Constants.driver.findElement(By.xpath(vObjPartyName)).getText();
            if(PartyName.contains(PPPartyFullName) && PartyName.contains(PPParty2FullName))
            {
                LogCapture.info("User verified Party Names " +PPPartyFullName + "& " +PPParty2FullName+ " Under Payment Request Details on confirmation page");
            }
            else
            {
                LogCapture.info("TC Failed : User Unable to verify Party Names "+ PPPartyFullName + " & " + PPParty2FullName + " Under Payment Request Details on confirmation page");
                Assert.fail();
            }

            String vObjRequestType = Constants.PropertyPayDashboardOR.getProperty("RequestType");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjRequestType, ""));
            String RequestType = Constants.driver.findElement(By.xpath(vObjRequestType)).getText();
            if(RequestType.equals(PaymentTypesOption))
            {
                LogCapture.info("User verified Payment Types as " +PaymentTypesOption+ " Under Payment Request Details on confirmation page");
            }
            else
            {
                LogCapture.info("TC Failed : User Unable to verify Payment Types as " +PaymentTypesOption+ " Under Payment Request Details on confirmation page");
                Assert.fail();
            }

            String vObjPaymentRequestAmount = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestAmount");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentRequestAmount, ""));
            String ActualPaymentrequestAmount = Constants.driver.findElement(By.xpath(vObjPaymentRequestAmount)).getText();
            if(ActualPaymentrequestAmount.contains(PaymentRequestsCurrency))
            {
                LogCapture.info("User verified Payment request Amount as " +ActualPaymentrequestAmount+ " Under Payment Request Details on confirmation page");
            }
            else
            {
                LogCapture.info("TC Failed : User Unable to verify Payment request Amount as " +ActualPaymentrequestAmount+ " Under Payment Request Details on confirmation page");
                Assert.fail();
            }

            String vObjPaymentrequestDueDate = Constants.PropertyPayDashboardOR.getProperty("PaymentrequestDueDate");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentrequestDueDate, ""));
            String ActualPaymentrequestDueDate = Constants.driver.findElement(By.xpath(vObjPaymentrequestDueDate)).getText();
            DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Calendar Calender1 = Calendar.getInstance();
            Calender1.setTime(new Date());
            Calender1.add(Calendar.DATE, 5);
            String PaymentDueDateDate = SelectedDateFormat.format(Calender1.getTime());

            if (PaymentDueDateDate.charAt(0) == '0')
            {
                PaymentDueDateDate.replace("0", "");
            }

            if (PaymentDueDateDate.toString().contains("/0"))
            {
                PaymentDueDateDate = PaymentDueDateDate.toString().replace("/0","/");
            }else
            {
                PaymentDueDateDate =PaymentDueDateDate.toString();
            }
            LogCapture.info("User verified Payment >>>>>>>>>>>>> " +ActualPaymentrequestDueDate);
            LogCapture.info("User verified Payment +++++++++++++ " +PaymentDueDateDate);

            if(ActualPaymentrequestDueDate.equals(PaymentDueDateDate))
            {
                LogCapture.info("User verified Payment Due Date as " +ActualPaymentrequestDueDate+ " Under Payment Request Details on confirmation page");
            }
            else
            {
                LogCapture.info("TC Failed : User Unable to verify Payment Due Date as " +ActualPaymentrequestDueDate+ " Under Payment Request Details on confirmation page");
//                Assert.fail();
            }
        }
        else
        {
            LogCapture.info("TC Failed : User entered wrong No of parties");
            Assert.fail();
        }

    }

    @When("^User lands on the Enter OTP page, enters the OTP, and clicks on Continue\\.$")
    public void userLandsOnTheEnterOTPPageEntersTheOTPAndClicksOnContinue() throws Exception {

        String vobjPPOTPHearder = Constants.PropertyPayDashboardOR.getProperty("PPOTPHearder");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPOTPHearder, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPPOTPHearder, "We've sent your security code"));
        LogCapture.info("User verified Header We've sent your security code is visible");

        String vobjPPOTPHeaderMessage = Constants.PropertyPayDashboardOR.getProperty("PPOTPHeaderMessage");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPPOTPHeaderMessage, "If you haven’t received it within a minute, please go back and retry."));
        LogCapture.info("User verified Header message as If you haven’t received it within a minute, please go back and retry. is visible");

        String vobjContinueButtonOTP = Constants.PropertyPayDashboardOR.getProperty("ContinueButtonOTP");
        List<WebElement> buttons = driver.findElements(By.cssSelector(vobjContinueButtonOTP));
        WebElement Continuebutton = buttons.get(0);
        boolean isDisabled = !Continuebutton.isEnabled();
        if (isDisabled) {
            LogCapture.info("User verify Continue button is Disabled before entering details.");
        } else {
            LogCapture.info("TC Failed : continue Button is Enable");
            Assert.fail();
        }

        String vobjEnterOTP1 = Constants.PropertyPayDashboardOR.getProperty("EnterOTP1");
        Assert.assertEquals("PASS", key.writeInInput(vobjEnterOTP1,"5"));
        String vobjEnterOTP2 = Constants.PropertyPayDashboardOR.getProperty("EnterOTP2");
        Assert.assertEquals("PASS", key.writeInInput(vobjEnterOTP2,"4"));
        String vobjEnterOTP3 = Constants.PropertyPayDashboardOR.getProperty("EnterOTP3");
        Assert.assertEquals("PASS", key.writeInInput(vobjEnterOTP3,"3"));
        String vobjEnterOTP4 = Constants.PropertyPayDashboardOR.getProperty("EnterOTP4");
        Assert.assertEquals("PASS", key.writeInInput(vobjEnterOTP4,"2"));
        String vobjEnterOTP5 = Constants.PropertyPayDashboardOR.getProperty("EnterOTP5");
        Assert.assertEquals("PASS", key.writeInInput(vobjEnterOTP5,"1"));
        System.out.println("User Enters OTP As 5 4 3 2 1");

        WebElement Backbutton = buttons.get(1);
        boolean isEnabled = Backbutton.isEnabled();
        if (isEnabled) {
            LogCapture.info("User verify Back button is Enabled before entering details.");
        } else {
            LogCapture.info("TC Failed : Back Button is Disabled");
            Assert.fail();
        }

        String vobjContinueButOTP = Constants.PropertyPayDashboardOR.getProperty("ContinueButOTP");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjContinueButOTP, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjContinueButOTP, ""));
        LogCapture.info("User click on continue Button");

    }

    @Then("^User verify the payment request details on confirmation page for (Currencies Direct Wallet|Saved recipients|Add new recipient) method$")
    public void userVerifyThePaymentRequestDetailsOnConfirmationPageForCurrenciesDirectWalletMethod(String method) throws Exception {

        String vobjConfirmationHeader = Constants.PropertyPayDashboardOR.getProperty("ConfirmationHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfirmationHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfirmationHeader, "Confirmation"));
        LogCapture.info("User verify Header as Confirmation Payment request confirmation page");

        String vobjRequestDetailsStepper = Constants.PropertyPayDashboardOR.getProperty("RequestDetailsStepper");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjRequestDetailsStepper, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRequestDetailsStepper, "Request details"));
        LogCapture.info("User verify Stepper as 'Request details' on Payment request confirmation page");

        String vobjAccountToBEFundedsStepper = Constants.PropertyPayDashboardOR.getProperty("AccountToBEFundedsStepper");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAccountToBEFundedsStepper, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjAccountToBEFundedsStepper, "Account to fund"));
        LogCapture.info("User verify Stepper as 'Account to fund' on Payment request confirmation page");

        String vobjRequestDetails = Constants.PropertyPayDashboardOR.getProperty("RequestDetails");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjRequestDetails, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRequestDetails, "Request details"));
        LogCapture.info("User verify Header as 'Request details' on Payment request confirmation page");

        String vobjPayeesHeader = Constants.PropertyPayDashboardOR.getProperty("PayeesHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPayeesHeader, ""));
        if(NoOfParties.equals("1"))
        {
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPayeesHeader, "Payee"));
            LogCapture.info("User verify Header as Payee on Payment request confirmation page");
        }
        else if(NoOfParties.equals("2"))
        {
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPayeesHeader, "Payees"));
            LogCapture.info("User verify Header as Payees on Payment request confirmation page");
        }

        String vobjPayeesName = Constants.PropertyPayDashboardOR.getProperty("PayeesName");
        String Payeename = Constants.key.isNotNull(vobjPayeesName, "Payee");
        LogCapture.info("User verify Payee Name as " +Payeename+ " on Payment request confirmation page");

        String vobjPaymentTypeHeader = Constants.PropertyPayDashboardOR.getProperty("PaymentTypeHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentTypeHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentTypeHeader, "Payment type"));
        LogCapture.info("User verify Header as Payment type on Payment request confirmation page");

        String vobjPaymentType = Constants.PropertyPayDashboardOR.getProperty("PaymentType");
        String PaymentType = Constants.key.isNotNull(vobjPaymentType, "PaymentType");
        LogCapture.info("User verify Payment Type as " +PaymentType+ " on Payment request confirmation page");

        String vobjPaymentInstructionValueHeader = Constants.PropertyPayDashboardOR.getProperty("PaymentInstructionValueHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentInstructionValueHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentInstructionValueHeader, "Payment instruction value"));
        LogCapture.info("User verify Header as Payment instruction value on Payment request confirmation page");

        String vobjPaymentInstructionValue = Constants.PropertyPayDashboardOR.getProperty("PaymentInstructionValue");
        String PaymentInstructionValue = Constants.key.isNotNull(vobjPaymentInstructionValue, "Payment Instruction Value");
        LogCapture.info("User verify Payment Instruction Value as " +PaymentInstructionValue+ " on Payment request confirmation page");

        String vobjConfPaymentDueDateHeader = Constants.PropertyPayDashboardOR.getProperty("ConfPaymentDueDateHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfPaymentDueDateHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjConfPaymentDueDateHeader, "Payment due date"));
        LogCapture.info("User verify Header as Payment due date on Payment request confirmation page");

        String vobjConfPaymentDueDate = Constants.PropertyPayDashboardOR.getProperty("ConfPaymentDueDate");
        String PaymentDueDateConf = Constants.key.isNotNull(vobjConfPaymentDueDate, "Payment Due Date");
        LogCapture.info("User verify Payment Due Date as " + PaymentDueDateConf + " on Payment request confirmation page");

        String vobjEditRequestDetails = Constants.PropertyPayDashboardOR.getProperty("EditRequestDetails");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjEditRequestDetails, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjEditRequestDetails, "Edit"));
        LogCapture.info("User verify Edit option on Payment request confirmation page");

        if(method.equals("Currencies Direct Wallet"))
        {
            String vobjAccountToFund = Constants.PropertyPayDashboardOR.getProperty("AccountToFund");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAccountToFund, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjAccountToFund, "Account to fund"));
            LogCapture.info("User verify Header as AccountToFund on Payment request confirmation page");

            String vobjClientWillFundTheirWalletMessage = Constants.PropertyPayDashboardOR.getProperty("ClientWillFundTheirWalletMessage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjClientWillFundTheirWalletMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjClientWillFundTheirWalletMessage, "The client will fund their Currencies Direct Wallet."));
            LogCapture.info("User verify Message as  option on Payment request confirmation page");


        } else if (method.equals("Saved recipients") || method.equals("Add new recipient")) {

            String vobjAccountToFund = Constants.PropertyPayDashboardOR.getProperty("AccountToFund");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAccountToFund, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjAccountToFund, "Account to fund"));
            LogCapture.info("User verify Header as AccountToFund on Payment request confirmation page");

            String vobjClientWillSendFundToAccountMessage = Constants.PropertyPayDashboardOR.getProperty("ClientWillSendFundToAccountMessage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjClientWillSendFundToAccountMessage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjClientWillSendFundToAccountMessage, "The client will send funds to this account for this payment."));
            LogCapture.info("User verify Message as 'The client will send funds to this account for this payment.' on Payment request confirmation page");

            String vobjPayeeNameConf = Constants.PropertyPayDashboardOR.getProperty("PayeeNameConf");
            String PayeeName = Constants.key.isNotNull(vobjPayeeNameConf, "Payee Name");
            LogCapture.info("User verify Payee Name as " + PayeeName + " on Payment request confirmation page");

            String vobjPayeeCountryConf = Constants.PropertyPayDashboardOR.getProperty("PayeeCountryConf");
            String PayeeCountry = Constants.key.isNotNull(vobjPayeeCountryConf, "Payee Country");
            LogCapture.info("User verify Payee Country as " + PayeeCountry + " on Payment request confirmation page");

            String vobjPayeeCurrencyHeader = Constants.PropertyPayDashboardOR.getProperty("PayeeCurrencyHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPayeeCurrencyHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPayeeCurrencyHeader, "Currency"));
            LogCapture.info("User verify Header as Currency on Payment request confirmation page");

            String vobjPayeeCurrency1 = Constants.PropertyPayDashboardOR.getProperty("PayeeCurrency1");
            String PayeeCurrency = Constants.key.isNotNull(vobjPayeeCurrency1, "Payee Currency");
            LogCapture.info("User verify Payee Currency as " + PayeeCurrency + " on Payment request confirmation page");

            String vobjPayeeIBANHeader = Constants.PropertyPayDashboardOR.getProperty("PayeeIBANHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPayeeIBANHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPayeeIBANHeader, "IBAN"));
            LogCapture.info("User verify Header as IBAN on Payment request confirmation page");

            String vobjPayeeIBAN = Constants.PropertyPayDashboardOR.getProperty("PayeeIBAN");
            String PayeeIBAN = Constants.key.isNotNull(vobjPayeeIBAN, "Payee IBAN");
            LogCapture.info("User verify Payee IBAN as " + PayeeIBAN + " on Payment request confirmation page");

            String vobjSwiftCodeHeader = Constants.PropertyPayDashboardOR.getProperty("SwiftCodeHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSwiftCodeHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjSwiftCodeHeader, "SWIFT code"));
            LogCapture.info("User verify Header as SWIFT code on Payment request confirmation page");

            String vobjSwiftCode1 = Constants.PropertyPayDashboardOR.getProperty("SwiftCode1");
            String PayeeSwiftCode= Constants.key.isNotNull(vobjSwiftCode1, "Payee SWIFT Code");
            LogCapture.info("User verify Payee Swift Code as " + PayeeSwiftCode + " on Payment request confirmation page");

            String vobjEditAccountToFund = Constants.PropertyPayDashboardOR.getProperty("EditAccountToFund");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjEditAccountToFund, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjEditAccountToFund, "Edit"));
            LogCapture.info("User verify Header as Edit on Payment request confirmation page");

        }

        String vobjBackButton = Constants.PropertyPayDashboardOR.getProperty("BackButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBackButton, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBackButton, "Back"));
        LogCapture.info("User verify Back button on Payment request confirmation page");

        String vobjConfirmButton = Constants.PropertyPayDashboardOR.getProperty("ConfirmButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjConfirmButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjConfirmButton, ""));
        LogCapture.info("User Clicked on Confirm Button on Payment request confirmation page");

    }


    @Then("^User verify Payment Request has been created Successfully and Click on Go to transaction button$")
    public void userVerifyPaymentRequestHasBeenCreatedSuccessfullyAndClickOnGoToTransactionButton() throws Exception {


        String vobjPaymentRequestAdded = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestAdded");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentRequestAdded, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentRequestAdded, "Payment request added"));
        LogCapture.info("User verify Payment request added has been created successfully");

        String vobjWillSendEmailMSG = Constants.PropertyPayDashboardOR.getProperty("WillSendEmailMSG");
        String Message = Constants.key.isNotNull(vobjWillSendEmailMSG, "Will Send an Email to Buyer message");
        LogCapture.info("User verify Text Message as '"+ Message +"'");

        String vobjbackToTransactionButton = Constants.PropertyPayDashboardOR.getProperty("backToTransactionButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjbackToTransactionButton, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjbackToTransactionButton, "Back to transaction"));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjbackToTransactionButton, ""));
        LogCapture.info("User verify Back to transaction Button and then click on the same");

    }

    @Then("^user landed on the Transaction Details page, verified the payment request details, and then clicked on the view button$")
    public void userLandedOnTheTransactionDetailsPageVerifiedThePaymentRequestDetailsAndThenClickedOnTheViewButton() throws Exception {

        String vobjPPTransactionID = Constants.PropertyPayDashboardOR.getProperty("PPTransactionID");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPTransactionID, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPPTransactionID, PPTransactionRefereneID));
        LogCapture.info("User verify Transaction Reference ID as "+PPTransactionRefereneID);

        DateFormat SelectedDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar Calender1 = Calendar.getInstance();
        Calender1.setTime(new Date());
        Calender1.add(Calendar.DATE, 5);
        String CompletionDate = SelectedDateFormat.format(Calender1.getTime());
        StringBuilder modifiedDate = new StringBuilder(CompletionDate);
        if (modifiedDate.charAt(0) == '0')
        {
            modifiedDate.replace(0, 1, "");
        }

        String modifiedDateWithoutZero = modifiedDate.toString();
        if (modifiedDate.toString().contains("/0"))
        {
            modifiedDateWithoutZero =  modifiedDate.toString().replace("/0","/");
        }

        String vobjPPTransactionCompletionDate = Constants.PropertyPayDashboardOR.getProperty("PPTransactionCompletionDate");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPTransactionCompletionDate, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPPTransactionCompletionDate, CompletionDate));
        LogCapture.info("User verify Completion date as "+modifiedDate.toString());

        Thread.sleep(2000);
        String vobjPPTransactionStatus = Constants.PropertyPayDashboardOR.getProperty("PPTransactionStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPPTransactionStatus, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPPTransactionStatus, "Open"));
        LogCapture.info("User verify Transaction Status as Open");

        String vobjPaymentRequestType = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestType");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentRequestType, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentRequestType, PaymentTypesOption));
        LogCapture.info("User verify Payment Type as "+ PaymentTypesOption);

        String vobjPaymentRequestAmountAndCCY = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestAmountAndCCY");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentRequestAmountAndCCY, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentRequestAmountAndCCY, PaymentRequestsValue + ".00 " + PaymentRequestsCurrency));
        LogCapture.info("User verify Payment Request Amount as " + PaymentRequestsValue + " " + PaymentRequestsCurrency);

        String vobjPaymentRequestStatus = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestStatus");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentRequestStatus, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentRequestStatus, "Sent"));
        LogCapture.info("User verify Status as Sent");

        String vobjPaymentRequestDate = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestDate");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentRequestDate, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentRequestDate, PaymentRequestsDueDate));
        LogCapture.info("User verify Payment request Due date as " + PaymentRequestsDueDate);

        String vobjPaymentRequestViewButton = Constants.PropertyPayDashboardOR.getProperty("PaymentRequestViewButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentRequestViewButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPaymentRequestViewButton, ""));
        LogCapture.info("User clicked on View button on Payment transaction details page ");

    }

    @Then("^User lands on the Payment Request Details page and verifies the payment details for the (Currencies Direct Wallet|Saved recipients|Add new recipient) Method$")
    public void userLandsOnThePaymentRequestDetailsPageAndVerifiesThePaymentDetailsForTheCurrenciesDirectWalletMethod(String Method) throws Exception {

        String vobjFundsForPropertyPayHeader = Constants.PropertyPayDashboardOR.getProperty("FundsForPropertyPayHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjFundsForPropertyPayHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFundsForPropertyPayHeader, "Funds for PropertyPay"));
        LogCapture.info("User verify Header as 'Funds for PropertyPay' on Payment request detail page");

        String vobjAddressOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("AddressOnFundsForPropertyPay");
        String Address = Constants.key.isNotNull(vobjAddressOnFundsForPropertyPay, "Address");
        LogCapture.info("User verify Address as " + Address + " on Payment request details page");

        String vobjRequestDetailsHeaders = Constants.PropertyPayDashboardOR.getProperty("RequestDetailsHeaders");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjRequestDetailsHeaders, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRequestDetailsHeaders, "Request details"));
        LogCapture.info("User verify Header as 'Request details' on Payment request detail page");

        String vobjPayeeHeaderOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("PayeeHeaderOnFundsForPropertyPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPayeeHeaderOnFundsForPropertyPay, ""));
        if(NoOfParties.equals("1"))
        {
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPayeeHeaderOnFundsForPropertyPay, "Payee"));
            LogCapture.info("User verify Header as 'Payee' on Payment request detail page");
        }
        else if(NoOfParties.equals("2"))
        {
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPayeeHeaderOnFundsForPropertyPay, "Payees"));
            LogCapture.info("User verify Header as 'Payees' on Payment request detail page");
        }

        String vobjPayeeNameOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("PayeeNameOnFundsForPropertyPay");
        String PayeeName = Constants.key.isNotNull(vobjPayeeNameOnFundsForPropertyPay, "Payee Name");
        LogCapture.info("User verify Payee Name as " + PayeeName + " on Payment request details page");

        String vobjPaymentTypeHeaderOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("PaymentTypeHeaderOnFundsForPropertyPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentTypeHeaderOnFundsForPropertyPay, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentTypeHeaderOnFundsForPropertyPay, "Payment type"));
        LogCapture.info("User verify Header as 'Payment type' on Payment request detail page");

        String vobjPaymentTypeOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("PaymentTypeOnFundsForPropertyPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentTypeOnFundsForPropertyPay, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentTypeOnFundsForPropertyPay, PaymentTypesOption));
        LogCapture.info("User verify Payment Types Option as '" + PaymentTypesOption + "' on Payment request detail page");

        String vobjPaymentInstructionValueHeaderOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("PaymentInstructionValueHeaderOnFundsForPropertyPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentInstructionValueHeaderOnFundsForPropertyPay, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentInstructionValueHeaderOnFundsForPropertyPay, "Payment instruction value"));
        LogCapture.info("User verify Header as 'Payment instruction value' on Payment request detail page");

        String vobjPaymentInstructionValueOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("PaymentInstructionValueOnFundsForPropertyPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentInstructionValueOnFundsForPropertyPay, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentInstructionValueOnFundsForPropertyPay, PaymentRequestsValue + ".00 " + PaymentRequestsCurrency));
        LogCapture.info("User verify Payment instruction value as '" + PaymentRequestsValue + ".00 " + PaymentRequestsCurrency + "' on Payment request detail page");

        String vobjPaymentDueDateHeaderOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("PaymentDueDateHeaderOnFundsForPropertyPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentDueDateHeaderOnFundsForPropertyPay, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentDueDateHeaderOnFundsForPropertyPay, "Payment due date"));
        LogCapture.info("User verify Header as 'Payment due date' on Payment request detail page");

        String vobjPaymentDueDateOnFundsForPropertyPay = Constants.PropertyPayDashboardOR.getProperty("PaymentDueDateOnFundsForPropertyPay");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPaymentDueDateOnFundsForPropertyPay, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPaymentDueDateOnFundsForPropertyPay, PaymentRequestsDueDate));
        LogCapture.info("User verify Payment due date as '" + PaymentRequestsDueDate + "' on Payment request detail page");

        if(Method.equals("Currencies Direct Wallet"))
        {
            String vobjAccountToFundHeader = Constants.PropertyPayDashboardOR.getProperty("AccountToFundHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAccountToFundHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjAccountToFundHeader, "Account to fund"));
            LogCapture.info("User verify Header as 'Account to fund' on Payment request detail page");

            String vobjClientWillFundTheirWallet = Constants.PropertyPayDashboardOR.getProperty("ClientWillFundTheirWallet");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjClientWillFundTheirWallet, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjClientWillFundTheirWallet, "The client will fund their Currencies Direct Wallet."));
            LogCapture.info("User verify Message as 'The client will fund their Currencies Direct Wallet.' on Payment request detail page");
        }
        else if(Method.equals("Saved recipients"))
        {
            String vobjAccountToFundHeader = Constants.PropertyPayDashboardOR.getProperty("AccountToFundHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAccountToFundHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjAccountToFundHeader, "Account to fund"));
            LogCapture.info("User verify Header as 'Account to fund' on Payment request detail page");

            String vobjClientWillSendTheFund = Constants.PropertyPayDashboardOR.getProperty("ClientWillSendTheFund");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjClientWillSendTheFund, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjClientWillSendTheFund, "The client/s will send funds to the account below:"));
            LogCapture.info("User verify Message as 'The client/s will send funds to the account below:' on Payment request detail page");

            String vobjPayeeNamePaymentRequest = Constants.PropertyPayDashboardOR.getProperty("PayeeNamePaymentRequest");
            String PayeeNameOnPaymentRequestDetailsPage= Constants.key.isNotNull(vobjPayeeNamePaymentRequest, "Payee Name on Payment Request Details Page");

            String vObjPayeeCountryAndIBANPaymentRequest = Constants.PropertyPayDashboardOR.getProperty("PayeeCountryAndIBANPaymentRequest");
            String PayeeCountry = Constants.key.isNotNull(vObjPayeeCountryAndIBANPaymentRequest, "Payee Country on Payment Request Details Page");
        }
        else if(Method.equals("Add new recipient"))
        {
            String vobjAccountToFundHeader = Constants.PropertyPayDashboardOR.getProperty("AccountToFundHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAccountToFundHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjAccountToFundHeader, "Account to fund"));
            LogCapture.info("User verify Header as 'Account to fund' on Payment request detail page");

            String vobjClientWillSendTheFund = Constants.PropertyPayDashboardOR.getProperty("ClientWillSendTheFund");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjClientWillSendTheFund, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjClientWillSendTheFund, "The client/s will send funds to the account below:"));
            LogCapture.info("User verify Message as 'The client/s will send funds to the account below:' on Payment request detail page");

            String vobjPayeeNamePaymentRequest = Constants.PropertyPayDashboardOR.getProperty("PayeeNamePaymentRequest");
            String PayeeNameOnPaymentRequestDetailsPage= Constants.key.isNotNull(vobjPayeeNamePaymentRequest, "Payee Name on Payment Request Details Page");

            String vObjPayeeCountryAndIBANPaymentRequest = Constants.PropertyPayDashboardOR.getProperty("PayeeCountryAndIBANPaymentRequest");
            String PayeeCountry = Constants.key.isNotNull(vObjPayeeCountryAndIBANPaymentRequest, "Payee Country on Payment Request Details Page");

        }


    }

    @And("^User landed on the Party Details page, enters the details for \"([^\"]*)\" party \"([^\"]*)\" and \"([^\"]*)\", (and|Select TPA and) clicks the Continue button$")
    public void userLandedOnThePartyDetailsPageEntersTheDetailsForPartyAndSelectTPAAndClicksTheContinueButton(String NoOfParty, String Party1, String Party2, String TPA) throws Throwable {

        NoOfParties=NoOfParty;
        if(NoOfParties.equals("1"))
        {
            String vobjPartyDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyDetailsHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPartyDetailsHeader, "Party details"));
            LogCapture.info("User verified its landed on Party details page");

            String vobjCreatePartyDetailsContinueButton = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsContinueButton");
            WebElement button = driver.findElement(By.xpath(vobjCreatePartyDetailsContinueButton));
            boolean isDisabled = !button.isEnabled();
            if (isDisabled) {
                LogCapture.info("User verify Continue button is Disabled before entering details.");
            } else {
                LogCapture.info("TC Failed : User verify continue Button is Enable");
                Assert.fail();
            }

            String vobjParty1Header = Constants.PropertyPayDashboardOR.getProperty("Party1Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty1Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty1Header, "Party 1"));
            LogCapture.info("User verify Party1 Header on Party details page");

            String RandomFirstname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            String RandomLastname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            PPPartyFullName = "Donald" + RandomFirstname + " " + "Trump" + RandomLastname;


            String vobjPartyFullName = Constants.PropertyPayDashboardOR.getProperty("PartyFullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyFullName, PPPartyFullName));
            LogCapture.info("User enter Party Full Name as" + PPPartyFullName);

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
            String CurrentTimeTimeHHMM = TimeHHMM.format(now);
//            Constants.PPPartyEmail = "saurabhpropertypay" + CurrentTimeTimeHHMM + "@mailinator.com";
            Constants.PPPartyEmail = Party1;

            String vobjPartyEmail = Constants.PropertyPayDashboardOR.getProperty("PartyEmail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyEmail, PPPartyEmail));
            LogCapture.info("User enter Party Email as " + PPPartyEmail);

            String CountryCode= "+91";
            String vobjPartyCountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("PartyCountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyCountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyCountryCodeDropdown, ""));

            String vobjPartyDetailsCountryCodeList = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsCountryCodeList");
            List<WebElement> CountryCodeElements = driver.findElements(By.xpath(vobjPartyDetailsCountryCodeList));
            int numberOfCountryCodes = CountryCodeElements.size();
            if(numberOfCountryCodes==168)
            {
                LogCapture.info("User verified Total 168 country codes are present in the list");
                System.out.println("Below is a list of 168 country code.");

            }else
            {
                LogCapture.info("TC Failed : User unable to verify 18 country codes in the list");
                Assert.fail();
            }

//            for(int i=1; i<=numberOfCountryCodes; i++)
//            {
//                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]";
//                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
//                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();
//                System.out.println(ActualCountryCodeOptions);
//            }

            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPPartyMobileNo="9000012345";
            String vobjPartyMobile = Constants.PropertyPayDashboardOR.getProperty("PartyMobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyMobile, PPPartyMobileNo));
            LogCapture.info("User enter Party Mobile Number as " + PPPartyMobileNo);

            String vobjTPAHeader = Constants.PropertyPayDashboardOR.getProperty("TPAHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAHeader, "Third-Party Authorisation"));
            LogCapture.info("User verified Header as Third-Party Authorisation on Party details page");

            String vobjTPAHeaderMesssage = Constants.PropertyPayDashboardOR.getProperty("TPAHeaderMesssage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAHeaderMesssage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAHeaderMesssage, "To disburse funds from a client’s Currencies Direct Wallet for completion, you’ll need their Third-Party Authorisation."));
            LogCapture.info("User verified TPA Header Message as To disburse funds from a client’s Currencies Direct Wallet for completion, you’ll need their Third-Party Authorisation. on Party details page");

            String vobjTPAConfirmationMSG = Constants.PropertyPayDashboardOR.getProperty("TPAConfirmationMSG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAConfirmationMSG, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAConfirmationMSG, "Confirm if you plan to use the completion schedule feature in Property Pay for this transaction. We will request authorisation once the client joins the transaction in PropertyPay."));
            LogCapture.info("User verified TPA Message as Confirm if you plan to use the completion schedule feature in Property Pay for this transaction. We will request authorisation once the client joins the transaction in PropertyPay. on Party details page");

            if(TPA.equalsIgnoreCase("Select TPA and"))
            {
                String vobjTPACheckBox = Constants.PropertyPayDashboardOR.getProperty("TPACheckBox");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPACheckBox, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTPACheckBox, ""));
                LogCapture.info("User Select Third-Party Authorisation Check box");
            }

            Thread.sleep(2000);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreatePartyDetailsContinueButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreatePartyDetailsContinueButton, ""));

        } else if (NoOfParties.equals("2"))
        {
            String vobjPartyDetailsHeader = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyDetailsHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjPartyDetailsHeader, "Party details"));
            LogCapture.info("User verified its landed on Party details page");

            String vobjCreatePartyDetailsContinueButton = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsContinueButton");
            WebElement button = driver.findElement(By.xpath(vobjCreatePartyDetailsContinueButton));
            boolean isDisabled = !button.isEnabled();
            if (isDisabled) {
                LogCapture.info("User verify Continue button is Disabled before entering details.");
            } else {
                LogCapture.info("TC Failed : User verify continue Button is Enable");
                Assert.fail();
            }

            String vobjParty1Header = Constants.PropertyPayDashboardOR.getProperty("Party1Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty1Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty1Header, "Party 1"));
            LogCapture.info("User verify Party1 Header on Party details page");

            String RandomFirstname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            String RandomLastname = RandomStringUtils.randomAlphabetic(5).toLowerCase();
            PPPartyFullName = "Donald" + RandomFirstname + " " + "Biden" + RandomLastname;


            String vobjPartyFullName = Constants.PropertyPayDashboardOR.getProperty("PartyFullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyFullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyFullName, PPPartyFullName));
            LogCapture.info("User enter Party Full Name as" + PPPartyFullName);

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
            String CurrentTimeTimeHHMM = TimeHHMM.format(now);
//          Constants.PPPartyEmail = "saurabhpropertypay" +RandomStringUtils.randomAlphabetic(5).toLowerCase()+ CurrentTimeTimeHHMM + "1@mailinator.com";
            Constants.PPPartyEmail = Party1;

            String vobjPartyEmail = Constants.PropertyPayDashboardOR.getProperty("PartyEmail");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyEmail, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyEmail, PPPartyEmail));
            LogCapture.info("User enter Party Email as " + PPPartyEmail);

            String CountryCode= "+91";
            String vobjPartyCountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("PartyCountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyCountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyCountryCodeDropdown, ""));

            String vobjPartyDetailsCountryCodeList = Constants.PropertyPayDashboardOR.getProperty("PartyDetailsCountryCodeList");
            List<WebElement> CountryCodeElements = driver.findElements(By.xpath(vobjPartyDetailsCountryCodeList));
            int numberOfCountryCodes = CountryCodeElements.size();
            if(numberOfCountryCodes==168)
            {
                LogCapture.info("User verified Total 168 country codes are present in the list");
                System.out.println("Below is a list of 168 country code.");

            }else
            {
                LogCapture.info("TC Failed : User unable to verify 18 country codes in the list");
                Assert.fail();
            }

//            for(int i=1; i<=numberOfCountryCodes; i++)
//            {
//                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]";
//                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
//                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();
//                System.out.println(ActualCountryCodeOptions);
//            }

            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPPartyMobileNo="9000012345";
            String vobjPartyMobile = Constants.PropertyPayDashboardOR.getProperty("PartyMobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjPartyMobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjPartyMobile, PPPartyMobileNo));
            LogCapture.info("User enter Party Mobile Number as " + PPPartyMobileNo);

            String vobjAddAnotherParty = Constants.PropertyPayDashboardOR.getProperty("AddAnotherParty");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjAddAnotherParty, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjAddAnotherParty, ""));
            LogCapture.info("User click on Add another party to add Second Party");


            String vobjParty2Header = Constants.PropertyPayDashboardOR.getProperty("Party2Header");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Header, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjParty2Header, "Party 2"));
            LogCapture.info("User verify Party 2 Header on Party details page");

            PPParty2FullName = "Justin" + RandomStringUtils.randomAlphabetic(6).toLowerCase() + " " + "Trudeau" + RandomStringUtils.randomAlphabetic(6).toLowerCase();
            String vobjParty2FullName = Constants.PropertyPayDashboardOR.getProperty("Party2FullName");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2FullName, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2FullName, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2FullName, PPParty2FullName));
            LogCapture.info("User enter Party2 Full Name as" + PPParty2FullName);
            Thread.sleep(2000);

//            Constants.PPParty2Email = "saurabhpropertypay" +RandomStringUtils.randomAlphabetic(5).toLowerCase()+ CurrentTimeTimeHHMM + "2@mailinator.com";
            Constants.PPParty2Email = Party2;
            String vobjParty2Email = Constants.PropertyPayDashboardOR.getProperty("Party2Email");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Email, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2Email, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2Email, PPParty2Email));
            LogCapture.info("User enter Party Email as " + PPParty2Email);


            String vobjParty2CountryCodeDropdown = Constants.PropertyPayDashboardOR.getProperty("Party2CountryCodeDropdown");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2CountryCodeDropdown, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2CountryCodeDropdown, ""));


            for(int i=1; i<=numberOfCountryCodes; i++)
            {
                String CountryCodeOptions = "//ul[@class='MuiAutocomplete-listbox css-1avb9pd']//li["+i+"]//div//div//p";
                Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(CountryCodeOptions, ""));
                String ActualCountryCodeOptions = Constants.driver.findElement(By.xpath(CountryCodeOptions)).getText();

                if(ActualCountryCodeOptions.equals(CountryCode))
                {
                    Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(CountryCodeOptions, ""));
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(CountryCodeOptions, ""));
                    LogCapture.info("User Select country code as "+CountryCode+" from the list");
                    break;
                }
                else if(i== numberOfCountryCodes)
                {
                    LogCapture.info("TC Failed : User unable to select country code as "+CountryCode+" from the List");
                    Assert.fail();
                }
            }

            Constants.PPParty2MobileNo="9000012345";
            String vobjParty2Mobile = Constants.PropertyPayDashboardOR.getProperty("Party2Mobile");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjParty2Mobile, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjParty2Mobile, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vobjParty2Mobile, PPParty2MobileNo));
            LogCapture.info("User enter Party 2 Mobile Number as" + PPParty2MobileNo);

            String vobjTPAHeader = Constants.PropertyPayDashboardOR.getProperty("TPAHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAHeader, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAHeader, "Third-Party Authorisation"));
            LogCapture.info("User verified Header as Third-Party Authorisation on Party details page");

            String vobjTPAHeaderMesssage = Constants.PropertyPayDashboardOR.getProperty("TPAHeaderMesssage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAHeaderMesssage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAHeaderMesssage, "To disburse funds from a client’s Currencies Direct Wallet for completion, you’ll need their Third-Party Authorisation."));
            LogCapture.info("User verified TPA Header Message as To disburse funds from a client’s Currencies Direct Wallet for completion, you’ll need their Third-Party Authorisation. on Party details page");

            String vobjTPAConfirmationMSG = Constants.PropertyPayDashboardOR.getProperty("TPAConfirmationMSG");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPAConfirmationMSG, ""));
            Assert.assertEquals("PASS", Constants.key.verifyText(vobjTPAConfirmationMSG, "Confirm if you plan to use the completion schedule feature in Property Pay for this transaction. We will request authorisation once the client joins the transaction in PropertyPay."));
            LogCapture.info("User verified TPA Message as Confirm if you plan to use the completion schedule feature in Property Pay for this transaction. We will request authorisation once the client joins the transaction in PropertyPay. on Party details page");

            if(TPA.equalsIgnoreCase("Select TPA and"))
            {
                String vobjTPACheckBox = Constants.PropertyPayDashboardOR.getProperty("TPACheckBox");
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTPACheckBox, ""));
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTPACheckBox, ""));
                LogCapture.info("User Select Third-Party Authorisation Check box");
            }

            Thread.sleep(2000);
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjCreatePartyDetailsContinueButton, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjCreatePartyDetailsContinueButton, ""));

        }

    }
}
