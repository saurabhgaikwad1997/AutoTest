package com.selenium.utillity;

import com.google.common.base.Stopwatch;
import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.InfluxDBClientFactory;
import com.influxdb.client.WriteApiBlocking;
import com.influxdb.client.domain.WritePrecision;
import com.influxdb.client.write.Point;
import com.utility.LogCapture;
import cucumber.api.Scenario;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;

public class grafanaReusables {

    //-----------------Jenkins-Grafana checkpoint below-------------------------------

    //This method is called at the end of the Testcase/Job execution (@After/@AfterClass tag)
    // to insert the relevant test data into the Grafana DB.
    public static void writeToGrafanaDB_void(String ApplicationName, String AllSourceTags, String isIndividualTCPassed, String dateTimeStamp, Long testCaseTimeinSeconds, String featureFileName, String featureFilePath, String scenarioMethodDescription, String featureDescription, StringBuilder extentReportHTML, String uniqueAlphaNumericJobID) throws SQLException {

        LogCapture.info("=========================START DATA DUMP====================================");
        LogCapture.info("ApplicationName=" + ApplicationName);
        LogCapture.info("AllSourceTags=" + AllSourceTags);
        LogCapture.info("isIndividualTCPassed=" + isIndividualTCPassed);
        LogCapture.info("dateTimeStamp=" + dateTimeStamp);
        LogCapture.info("testCaseTimeinSeconds=" + testCaseTimeinSeconds);
        LogCapture.info("featureFileName=" + featureFileName);
        LogCapture.info("featureFilePath=" + featureFilePath);
        LogCapture.info("scenarioMethodDescription=" + scenarioMethodDescription);
        LogCapture.info("featureDescription=" + featureDescription);
        LogCapture.info("extentReportHTML=" + extentReportHTML);
        LogCapture.info("uniqueAlphaNumericJobID=" + uniqueAlphaNumericJobID);
        LogCapture.info("=======================END DATA DUMP========================================");

        final String DB_URL = "jdbc:sqlserver://10.52.48.24:1501";
        final String USER = "Grafana_App_User";
        final String PASS = "Gr33kQAf@n";


        // Open a SQL connection to insert the records in DB
        PreparedStatement pstm=null;
        try {
            if(Constants.JenkinsBrowser != null){
                if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                    // pstm.setString(12,"cloud");
                    LogCapture.error("cloud bit set in DB");
                }
                else{
                    if(Constants.Connection == null){
                        Constants.Connection = DriverManager.getConnection(DB_URL, USER, PASS);
                    }
                    pstm = Constants.Connection.prepareStatement("INSERT INTO [Grafana].[dbo].[AutomationTestMaster] ([applicationName],[allSourceTags],[isIndividualTCPassed],[dateTimeStamp],[testCaseTimeinSeconds],[featureFileName],[featureFilePath],[scenarioMethodDescription],[featureDescription],[extentReportHTML],[uniqueAlphaNumericJobID],[executionType]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
                    pstm.setString(1,ApplicationName);
                    pstm.setString(2,AllSourceTags);
                    pstm.setString(3,isIndividualTCPassed);
                    pstm.setString(4,dateTimeStamp);
                    pstm.setLong(5,testCaseTimeinSeconds);
                    pstm.setString(6,featureFileName);
                    pstm.setString(7,featureFilePath);
                    pstm.setString(8,scenarioMethodDescription);
                    pstm.setString(9,featureDescription);
                    pstm.setString(10,extentReportHTML+"");
                    pstm.setString(11,uniqueAlphaNumericJobID);
                    pstm.setString(12,"localRun - "+System.getProperty("user.name"));
                    pstm.executeUpdate();
                    LogCapture.info("Test results have been pushed to the Grafana DB");
                    LogCapture.error("localRun bit set in DB");
                }
            }else{

                if(Constants.Connection == null){
                    Constants.Connection = DriverManager.getConnection(DB_URL, USER, PASS);
                }
                pstm = Constants.Connection.prepareStatement("INSERT INTO [Grafana].[dbo].[AutomationTestMaster] ([applicationName],[allSourceTags],[isIndividualTCPassed],[dateTimeStamp],[testCaseTimeinSeconds],[featureFileName],[featureFilePath],[scenarioMethodDescription],[featureDescription],[extentReportHTML],[uniqueAlphaNumericJobID],[executionType]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
                pstm.setString(1,ApplicationName);
                pstm.setString(2,AllSourceTags);
                pstm.setString(3,isIndividualTCPassed);
                pstm.setString(4,dateTimeStamp);
                pstm.setLong(5,testCaseTimeinSeconds);
                pstm.setString(6,featureFileName);
                pstm.setString(7,featureFilePath);
                pstm.setString(8,scenarioMethodDescription);
                pstm.setString(9,featureDescription);
                pstm.setString(10,extentReportHTML+"");
                pstm.setString(11,uniqueAlphaNumericJobID);
                pstm.setString(12,"localRun - "+System.getProperty("user.name"));
                pstm.executeUpdate();
                LogCapture.info("Test results have been pushed to the Grafana DB");
                LogCapture.error("localRun bit set in DB");
            }

//            pstm.close();
//            Constants.Connection.close();
        } catch (SQLException e) {
            LogCapture.error("Something went wrong while establishing a connection with the Grafana DB. Please check error -->"+e);
            throw new RuntimeException(e);
        }
    }

    public static void writeToInfluxDB1(String ApplicationName, String AllSourceTags, String isIndividualTCPassed, String dateTimeStamp, Long testCaseTimeinSeconds, String featureFileName, String featureFilePath, String scenarioMethodDescription, String featureDescription, StringBuilder extentReportHTML, String uniqueAlphaNumericJobID) throws SQLException {

        LogCapture.info("=========================START DATA DUMP====================================");
        LogCapture.info("ApplicationName=" + ApplicationName);
        LogCapture.info("AllSourceTags=" + AllSourceTags);
        LogCapture.info("isIndividualTCPassed=" + isIndividualTCPassed);
        LogCapture.info("dateTimeStamp=" + dateTimeStamp);
        LogCapture.info("testCaseTimeinSeconds=" + testCaseTimeinSeconds);
        LogCapture.info("featureFileName=" + featureFileName);
        LogCapture.info("featureFilePath=" + featureFilePath);
        LogCapture.info("scenarioMethodDescription=" + scenarioMethodDescription);
        LogCapture.info("featureDescription=" + featureDescription);
        LogCapture.info("extentReportHTML=" + extentReportHTML);
        LogCapture.info("uniqueAlphaNumericJobID=" + uniqueAlphaNumericJobID);
        LogCapture.info("=======================END DATA DUMP========================================");

        final String DB_URL = "jdbc:sqlserver://10.52.48.24:1501";
        final String USER = "Grafana_App_User";
        final String PASS = "Gr33kQAf@n";

//        String token = "OFKEINrc3PKWIrMjXChcn-zKPYVKHpNySmDp8BAOIsHk-WBdeVnD9vzzLPE0f4_k6OMVr3y7MTebueSL9WxpIw==";
        String token = "QexQQUyJGnnB_saUVIhcPXsSbVREyi_ZLeah_D9g5urduvzxRI6jgSQyyhJUyo40brb4K-1hY8qFNAg1FxWWaQ==";

        // Open an InfluxDB connection to insert the records in DB

        try {
//            InfluxDB influxDB = InfluxDBFactory.connect("http://localhost:8086", "CurrenciesDirect_268", "Welcome@cd");
//            String databaseName = "myCDdb";
//            influxDB.query(new Query("CREATE DATABASE " + databaseName));
//            influxDB.setDatabase(databaseName);
//            InfluxDBClient influxDBClient = InfluxDBClientFactory.create("http://localhost:8086", token.toCharArray(), "CD", "CDBucket");
            InfluxDBClient influxDBClient = InfluxDBClientFactory.create("https://devopsmetrices.currenciesdirect.com/", token.toCharArray(), "CD", "qa-poc");
            WriteApiBlocking writeApi = influxDBClient.getWriteApiBlocking();


            Point point_overallData = Point.measurement("ApplicationStatus1_12July")
                    .addTag("ApplicationName", ApplicationName)
                    .addTag("uniqueAlphaNumericJobID", uniqueAlphaNumericJobID)
                    .addTag("AllSourceTags", AllSourceTags)
                    .addTag("isIndividualTCPassed", isIndividualTCPassed)
                    .addField("testCaseTimeinSeconds", testCaseTimeinSeconds)
                    .addTag("featureFileName", featureFileName)
                    .addTag("featureFilePath", featureFilePath)
                    .addTag("scenarioMethodDescription", scenarioMethodDescription)
                    .addTag("executionType", "localRun - "+System.getProperty("user.name"))
                    .addTag("featureDescription", featureDescription);


            Point point_testcaseStatus = Point.measurement("TestCase_Status")
                    .addTag("testcaseTags", AllSourceTags)
                    .addField("TestCase_Status", isIndividualTCPassed);

            //Measurement for testcase time
            Point point_testcaseTime = Point.measurement("TestCase_Time")
                    .addTag("testcaseTags", AllSourceTags)
                    .addField("testCaseTimeinSeconds", testCaseTimeinSeconds);




//                    .addTag("extentReportHTML", extentReportHTML.toString())

//                    .time(Instant.now().toEpochMilli(), WritePrecision.MS);

            writeApi.writePoint(point_overallData);
            writeApi.writePoint(point_testcaseTime);
            writeApi.writePoint(point_testcaseStatus);
        } catch (Exception e) {
            LogCapture.error("Something went wrong while establishing a connection with the Grafana DB. Please check error -->"+e);
            throw new RuntimeException(e);
        }
    }

    public static void writeToInfluxDB(String ApplicationName, String TestCaseTags, String TC_Status, String dateTimeStamp, Long testCaseTimeinSeconds, String featureFileName, String featureFilePath, String scenarioMethodDescription, String featureDescription, StringBuilder extentReportHTML, String uniqueAlphaNumericJobID) throws SQLException {

        LogCapture.info("=========================START DATA DUMP====================================");
        LogCapture.info("ApplicationName=" + ApplicationName);
        LogCapture.info("AllSourceTags=" + TestCaseTags);
        LogCapture.info("isIndividualTCPassed=" + TC_Status);
        LogCapture.info("dateTimeStamp=" + dateTimeStamp);
        LogCapture.info("testCaseTimeinSeconds=" + testCaseTimeinSeconds);
        LogCapture.info("featureFileName=" + featureFileName);
        LogCapture.info("featureFilePath=" + featureFilePath);
        LogCapture.info("scenarioMethodDescription=" + scenarioMethodDescription);
        LogCapture.info("featureDescription=" + featureDescription);
        LogCapture.info("extentReportHTML=" + extentReportHTML);
        LogCapture.info("uniqueAlphaNumericJobID=" + uniqueAlphaNumericJobID);
        LogCapture.info("=======================END DATA DUMP========================================");

//        final String token = "QexQQUyJGnnB_saUVIhcPXsSbVREyi_ZLeah_D9g5urduvzxRI6jgSQyyhJUyo40brb4K-1hY8qFNAg1FxWWaQ==";
        final String token = Constants.CONFIG.getProperty("influxDB_token");


        Point pointAppData=null;

        try {
            InfluxDBClient influxDBClient = InfluxDBClientFactory.create("https://devopsmetrices.currenciesdirect.com/", token.toCharArray(), "CD", "qa-bucket");
            WriteApiBlocking writeApi = influxDBClient.getWriteApiBlocking();

            if(Constants.JenkinsBrowser != null){
                if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                    LogCapture.info("enter if 1");
                    pointAppData = Point.measurement(ApplicationName)
                            .addTag("Unique Job ID", uniqueAlphaNumericJobID)
                            .addTag("Tags", TestCaseTags)
                            .addTag("TC-Status", TC_Status)
                            .addField("TC-Time(seconds)", testCaseTimeinSeconds)
                            .addTag("Feature File Name", featureFileName)
                            .addTag("Feature File Path", featureFilePath)
                            .addTag("Scenario Name", scenarioMethodDescription)
                            .addTag("Execution Type", "cloud")
                            .addTag("Feature Description", featureDescription);
                }
                else{
                    LogCapture.info("enter else 1");
                    pointAppData = Point.measurement(ApplicationName)
                            .addTag("Unique Job ID", uniqueAlphaNumericJobID)
                            .addTag("Tags", TestCaseTags)
                            .addTag("TC-Status", TC_Status)
                            .addField("TC-Time(seconds)", testCaseTimeinSeconds)
                            .addTag("Feature File Name", featureFileName)
                            .addTag("Feature File Path", featureFilePath)
                            .addTag("Scenario Name", scenarioMethodDescription)
                            .addTag("Execution Type", "localRun - "+System.getProperty("user.name"))
                            .addTag("Feature Description", featureDescription);
                }
            }else{
                LogCapture.info("enter else 2");
                pointAppData = Point.measurement(ApplicationName)
                        .addTag("Unique Job ID", uniqueAlphaNumericJobID)
                        .addTag("Tags", TestCaseTags)
                        .addTag("TC-Status", TC_Status)
                        .addField("TC-Time(seconds)", testCaseTimeinSeconds)
                        .addTag("Feature File Name", featureFileName)
                        .addTag("Feature File Path", featureFilePath)
                        .addTag("Scenario Name", scenarioMethodDescription)
                        .addTag("Execution Type", "localRun - "+System.getProperty("user.name"))
                        .addTag("Feature Description", featureDescription);
            }
            writeApi.writePoint(pointAppData);

        } catch (Exception e) {
            LogCapture.error("Something went wrong while establishing a connection with the Grafana DB. Please check error -->"+e);
            throw new RuntimeException(e);
        }
    }

    //Method user to generate random string
    public static String generateRandomString() throws Exception {
        String randomString = "";
        try {
            int leftLimit = 97; // letter 'a'
            int rightLimit = 122; // letter 'z'
            int targetStringLength = 10;
            Random random = new Random();
            StringBuilder buffer = new StringBuilder(targetStringLength);
            for (int i = 0; i < targetStringLength; i++) {
                int randomLimitedInt = leftLimit + (int)
                        (random.nextFloat() * (rightLimit - leftLimit + 1));
                buffer.append((char) randomLimitedInt);
            }
            String generatedString = buffer.toString();
            System.out.println(generatedString);
            SimpleDateFormat insertDB = new SimpleDateFormat("ddMMMYYYYHHmmss");
            String dateStringDB = insertDB.format(new Date());
            randomString = dateStringDB+generatedString;
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return randomString;
    }

    //This method is used to initiate the stopwatch to keep track of time per testcase.
    public static Long startStopwatch(String timerAction) throws Exception {
        Long elapsedTime = 0L;
        try {
            switch (timerAction){
                case "Start":
                    Constants.stopwatch = Stopwatch.createStarted();
                    break;
                case "Stop":
                    elapsedTime = Constants.stopwatch.elapsed(TimeUnit.SECONDS);
                    break;
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return elapsedTime;
    }


    //This method will fetch the Feature file name from the TestNG Reporter object.
    // We do not have a direct method in info.cukes version of cucumber to fetch the feature file name.
    // Hence, the workaround in this method.
    public static String getCurrentFeatureName(String featureNameRequirement) throws Exception {

        String featureFilePath = "";
        Object[] paramNames = org.testng.Reporter.getCurrentTestResult().getParameters();
        for (Field field : paramNames[0].getClass().getDeclaredFields()) {
            field.setAccessible(true); // You might want to set modifier to public first.
            Object value = field.get(paramNames[0]);
            for (Field field1 : value.getClass().getDeclaredFields()) {
                field1.setAccessible(true);
                featureFilePath = field1.get(value)+"";
                break;
            }
        }
        int i = featureFilePath.split("/").length;
        String[] featureName = featureFilePath.split("/");

        if(featureNameRequirement.equalsIgnoreCase("feature name")){
            return featureName[i-1];
        }else{
            return featureFilePath;
        }
    }

    //This method is used to fetch the extent HTML report.
    // This HTML report is sent in string format using the stringbuilder object.
//    public static StringBuilder getExtentReportFile() throws Exception {
//        StringBuilder sb = new StringBuilder();
//        String st="";
//        try {
//            String extentReportFilePath = System.getProperty("user.dir")+"\\target\\cucumber-reports\\ExtentReport.html";
//            File a = new File(extentReportFilePath);
//            BufferedReader br = new BufferedReader(new FileReader(a));
//
//            while ((st = br.readLine()) != null){
//
//                sb.append(st);
//
//            }
//            System.out.println(sb);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//        return sb; //varchar(max)
//    }



    public static StringBuilder getExtentReportFile() throws Exception {
        StringBuilder sb = new StringBuilder();
        String extentReportFilePath = System.getProperty("user.dir") + "\\target\\cucumber-reports\\ExtentReport.html";



        try {
            Path path = Paths.get(extentReportFilePath);
            List<String> lines = Files.readAllLines(path);



            for (String line : lines) {
                sb.append(line).append(System.lineSeparator());
            }



            System.out.println(sb);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }



        return sb;
    }


    public static void triggerDataPopulation(Scenario scenario) throws Exception {

        Collection<String> e = scenario.getSourceTagNames();
        SimpleDateFormat dateTimeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String featureDescription = org.testng.Reporter.getCurrentTestResult().getParameters()[0]+"";
        String allSourceTags = e+"";
        String tcStatus = scenario.getStatus();
        String dateTimeStampDB = dateTimeStamp.format(new Date());
        Long timePerTestCase = grafanaReusables.startStopwatch("Stop");
        String featureFileName = grafanaReusables.getCurrentFeatureName("feature name");
        String featureFilePath = grafanaReusables.getCurrentFeatureName("feature path");
        String methodDescription = scenario.getName();

        if(Constants.uniqueAlphaNumericJobID==""){
            Constants.uniqueAlphaNumericJobID = grafanaReusables.generateRandomString();
        }
        grafanaReusables.writeToInfluxDB(Constants.grafanaApplicationName, allSourceTags, tcStatus, dateTimeStampDB, timePerTestCase, featureFileName,featureFilePath, methodDescription, featureDescription, null, Constants.uniqueAlphaNumericJobID);

    }

    //-----------------Jenkins-Grafana checkpoint above-------------------------------
}