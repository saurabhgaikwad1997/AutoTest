
/*ClassName: Resuables.java
Date: 17/April/2020
Author: Saurabh Gadgil
Purpose of class: To implement generic methods, all resuable using Xpath and selenium for robust framework.*/

package com.selenium.utillity;

import com.service.utillity.ReusableMethod;


//import com.itextpdf.kernel.pdf.PdfDocument;
//import com.itextpdf.kernel.pdf.PdfReader;
//import com.itextpdf.kernel.pdf.canvas.parser.PdfTextExtractor;
//
//import com.itextpdf.kernel.pdf.PdfDocument;
//import com.itextpdf.kernel.pdf.PdfReader;
//import com.itextpdf.kernel.pdf.canvas.parser.PdfTextExtractor;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;



import com.utility.LogCapture;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.*;




import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.commons.lang.RandomStringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;


import java.io.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Matcher;


import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.ScreenshotCapture.takeSnapShot;
import java.time.LocalDate;

//import com.sun.org.apache.bcel.internal.Const;
//import com.sun.org.apache.bcel.internal.Const;
import org.openqa.selenium.JavascriptExecutor;
import com.cybozu.labs.langdetect.DetectorFactory;
import com.cybozu.labs.langdetect.Detector;
import com.cybozu.labs.langdetect.LangDetectException;

import java.io.BufferedWriter;

public class Reusables {
    public String actual;
    public String emailID;
    public static String Email;
    public String ScreenshotFlag;
    public String PDFoutput;
    String randomName;
    String randomNumber;
    // Generate random email
    String randomEmail;

    String pastDate;

    String futureDate;
    String phone;

    String Message;
   // String SAVEDATE;

    String MsgDate;
    static String Newtxt;
    static String Newtxt1;
    static String Newtxt2;
    static String Newtxt3;
    static String Newtxt4;
    static String Newtxt5;
    String concatenatedText;
    String downloadFilesPath = System.getProperty("user.dir") + "\\src\\main\\resources\\Downloads";


// Mailinator Constants

    public static final String MAILINATOR_API_TOKEN = "2733fd41c8654883b9f9e5e3f67f140d";
    public static final String EMAIL_DOWNLOAD_DIRECTORY = "./EmailAttachments";
    public static String DOMAIN_NAME;
    public static String EMAIL_NAME;
    public static String MAILINATOR_API_URL;
    public static String MSG_ID = "";

    public static boolean openBrowser(String object, String data) throws Exception {
        try {
            String vExpected = "Chrome, Firefox, Edge, Safari";
            String vActual = data;

            if (data.isEmpty()) {
                vActual = "No data found";
            }

            //System.out.println("expected value->>>>" + vExpected);
            System.out.println("data value->>>>" + vActual);

            // Identify the operating system
            String oSName = System.getProperty("os.name").toUpperCase();
            OSType osType;
            if (oSName.contains("WIN")) {
                osType = OSType.WINDOWS;
            } else if (oSName.contains("MAC")) {
                osType = OSType.MAC;
            } else if (oSName.contains("NUX")) {
                osType = OSType.LINUX;
            } else {
                throw new UnsupportedOperationException("Unsupported operating system: " + oSName);
            }

            // Identify the driver type
            DriverType driverType;
            switch (data.toLowerCase()) {
                case "chrome":
                    driverType = DriverType.CHROME;
                    break;
                case "firefox":
                    driverType = DriverType.FIREFOX;
                    break;
                case "edge":
                    driverType = DriverType.EDGE;
                    break;
                case "safari":
                    driverType = DriverType.SAFARI;
                    break;
                default:
                    throw new IllegalArgumentException("Invalid browser type: " + data);
            }

            // Get the driver manager
            WebDriverManagerCustom driverManager = DriverFactory.getManager(driverType, osType);

            // Setup the driver
            driverManager.setupDriver(object);

            // Get the driver
            WebDriver driver = driverManager.getDriver(object);

            // From here onwards, you can interact with the WebDriver instance (e.g., navigate to a URL, perform operations on the page, etc.)

            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            // Your log capturing and snapshot taking logic here
            return false;
        }
    }



   /* public boolean openBrowser(String object, String data) throws Exception {
        try {
            String oSName = System.getProperty("os.name");
            if (data.equalsIgnoreCase("Chrome")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/windows/Chrome/chromedriver.exe");
                    WebDriverManager.chromedriver().setup();
                    ChromeOptions options = new ChromeOptions();
                    options.addArguments("--remote-allow-origins=*");
                    //System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver_old.exe");
                    Constants.driver = new ChromeDriver(options);
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((ChromeDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                } else {
                    //System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/linux/Chrome/chromedriver");
                    //System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
                    WebDriverManager.chromedriver().setup();
                    ChromeOptions options = new ChromeOptions();
                    options.setHeadless(true);
                    options.addArguments("--window-size=1920,1080");
                    options.addArguments("--disable-gpu");
                    options.addArguments("--disable-extensions");
                    options.setExperimentalOption("useAutomationExtension", false);
                    options.addArguments("--proxy-server='direct://'");
                    options.addArguments("--proxy-bypass-list=*");
                    options.addArguments("--start-maximized");
                    options.addArguments("--headless");
                    options.addArguments("--whitelisted-ips");
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    options.addArguments("--remote-allow-origins=*");
                    Constants.driver = new ChromeDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                    //options.addArguments("--no-sandbox");
                }
            } else if (data.equalsIgnoreCase("Firefox")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/windows/Firefox/geckodriver.exe");
                    WebDriverManager.firefoxdriver().setup();
                    File pathBinary = new File(System.getProperty("user.home") + "/AppData/Local/Mozilla Firefox/firefox.exe");
                    FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
                    //DesiredCapabilities desired = DesiredCapabilities.firefox();
                    FirefoxOptions options = new FirefoxOptions();
                    options.setBinary(firefoxBinary);
                    //desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
                    WebDriverManager.firefoxdriver().setup();
                    Constants.driver = new FirefoxDriver(options);
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((FirefoxDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                } else {
                    FirefoxBinary firefoxBinary = new FirefoxBinary();
                    firefoxBinary.addCommandLineOptions("--headless");
                    WebDriverManager.firefoxdriver().setup();
                    //System.setProperty("webdriver.gecko.driver", "/usr/local/bin/geckodriver");
                    FirefoxOptions options = new FirefoxOptions();
                    options.addArguments("--no-sandbox");
                    options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
                    options.setBinary(firefoxBinary);
                    Constants.driver = new FirefoxDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                }
            } else if (data.equalsIgnoreCase("Edge")) {
                if (oSName.toUpperCase().contains("WIN")) {
                    //System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/windows/Edge/msedgedriver.exe");
                    WebDriverManager.edgedriver().setup();
                    Constants.driver = new EdgeDriver();
                    LogCapture.info(data + " for windows is launching...");
                    Capabilities cap = ((EdgeDriver) Constants.driver).getCapabilities();
                    LogCapture.info("Test case is running on " + cap.getBrowserName() + " & version is " + cap.getVersion());
                    Constants.driver.manage().window().maximize();
                    //takeSnapShot();
                    takeSnapShot();
                } else {
//                    System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/linux/Edge/msedgedriver");
                    System.setProperty("webdriver.edge.driver", "/usr/bin/edgedriver");
                    //WebDriverManager.edgedriver().setup();
                    EdgeOptions options = new EdgeOptions();
                    options.setHeadless(true);
                    options.addArguments("--window-size=1920,1080");
                    options.addArguments("--disable-gpu");
                    options.addArguments("--disable-extensions");
                    options.setExperimentalOption("useAutomationExtension", false);
                    options.addArguments("--proxy-server='direct://'");
                    options.addArguments("--proxy-bypass-list=*");
                    options.addArguments("--start-maximized");
                    options.addArguments("--headless");
                    options.addArguments("--whitelisted-ips");
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    Constants.driver = new EdgeDriver(options);
                    LogCapture.info(data + " for linux is launching...");
                    Constants.driver.manage().window().maximize();
                    takeSnapShot();
                    //options.addArguments("--no-sandbox");
                }

            }
            takeSnapShot();
            return true;
        } catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found...");
            takeSnapShot();
            return false;
        }
    }*/


    public String closeBrowser(String object, String data) throws Exception {
        try {
            Constants.driver.quit();
        } catch (Exception ex) {
            System.out.println(ex);
            LogCapture.info("Webdriver not found..." + ex);

            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;

    }

    public static String navigate(String object, String data) throws Exception {
        try {
            Constants.driver.navigate().to(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";

        }
        return KEYWORD_PASS;
    }

    public static String mailinatorlink(String email, String Title) throws Exception {
        try {

//            String mailSubject = Constants.key.getEmailUsingSubject(email, "subject", Title);
            String maillink = Constants.key.getEmailUsingSubject(email, "links", Title);

            LogCapture.info(maillink);
            String urlsString = maillink;

            // Split the string into individual URLs
            String[] urls = urlsString.split(", ");

            // Iterate through each URL https://demo.docusign.net/
            for (String url : urls) {
                // Check if the URL starts with "https://demo.docusign.net/Signing"
                if (url.contains("https://demo.docusign.net/")) {
                    // Print the modified URL without the "[" character
                    String modifiedUrl1 = url.replace("[", "");
                    String modifiedUrl = modifiedUrl1.replace("]", "");
                    Constants.key.pause("2", "");
//                    Assert.assertEquals("PASS", Constants.key.navigate("", modifiedUrl));
                    Assert.assertEquals("PASS", Constants.key.navigateotpurl("", modifiedUrl));
//
                    System.out.println(modifiedUrl);
                }
            }

            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";

        }
        return KEYWORD_PASS;
    }

    public static String multilinkpaymentconfirmation(String email, String Title, int noofmail) throws Exception {
        try {

//            String mailSubject = Constants.key.getEmailUsingSubject(email, "subject", Title);
            String maillink = Constants.key.getEmailUsingSubject(email, "links", Title);

            LogCapture.info(maillink);
            String urlsString = maillink;

            // Split the string into individual URLs
            String[] urls = urlsString.split(", ");
            List<String> modifiedUrls = new ArrayList<>();

// Iterate through each URL
            for (String url : urls) {
                // Check if the URL contains "https://demo.docusign.net/"
                if (url.contains("https://demo.docusign.net/")) {
                    // Print the modified URL without the "[" character
                    String modifiedUrl1 = url.replace("[", "");
                    String modifiedUrl = modifiedUrl1.replace("]", "");
                    modifiedUrls.add(modifiedUrl); // Store the modified URL in the list
                    System.out.println(modifiedUrl);
                }
            }
            int sizeOfModifiedUrls = modifiedUrls.size();

// Now navigate to each modified URL one by one
            for (String modifiedUrl : modifiedUrls) {
                Constants.key.pause("2", "");
                Assert.assertEquals("PASS", Constants.key.navigate("", modifiedUrl));

                Constants.key.pause("2", "");
                String vObjck = "//label[@for='disclosureAccepted']";
                Constants.key.navigateSubMenu(vObjck, "");
                Constants.key.pause("2", "");
                String vObjCont = "//button[@id='action-bar-btn-continue']";
                Constants.key.navigateSubMenu(vObjCont, "");
                Constants.key.pause("2", "");

                Constants.key.pause("2", "");

                String vObjfinish = "//button[@id='end-of-document-btn-view-complete']";
                Constants.key.Mouse_Events(vObjfinish, "");
                Constants.key.pause("3", "");
                String vObjfinish2 = "//button[@id='end-of-document-btn-finish']";
                Constants.key.Mouse_Events(vObjfinish2, "");
                Constants.key.pause("4", "");
            }

            System.out.println("Size of modifiedUrls list: " + sizeOfModifiedUrls);
//            Assert.assertEquals(noofmail, sizeOfModifiedUrls, "The size of modifiedUrls is equal to noofmail.");

            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";

        }
        return KEYWORD_PASS;
    }

    //
    public String VerifyTextMailinator(String actual, String expected) throws Exception {
        try {
            LogCapture.info("Actual value ===== " + actual);
            LogCapture.info("Expected value ===== " + expected);
            if (actual.equals(expected)) {
                LogCapture.info("Actual value & Expected value are Matching.");
                return KEYWORD_PASS;
            } else {
                LogCapture.info("Actual value & Expected value are Not Matching.");
                return KEYWORD_FAIL;
            }
        } catch (Exception e) {
            LogCapture.info("Something Went Wrong on VerifyTextMailinator Reusable");
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }
    }

    public String freemailinator(String data) throws Exception {
        try {
            String url = "https://www.mailinator.com/";
            String object = "//input[@id='search']";
            String object2 = "//button[@value='Search for public inbox for free']";
            Assert.assertEquals("PASS", Constants.key.navigate("", url));
            Constants.driver.findElement(By.xpath(object)).sendKeys(data);

            Constants.key.pause("2", "");
            Constants.driver.findElement(By.xpath(object2)).click();
            Constants.key.pause("2", "");
            //button[@value='Search for public inbox for free']
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String writeInInput(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).sendKeys(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String click(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String frame(String object, String data) throws Exception {
        WebElement FrameName = driver.findElement(By.xpath(object));
        driver.switchTo().frame(FrameName);
        return KEYWORD_PASS;
    }

    public String verifyText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("actual value->>>>" + actual);
            }
            String expected = data;
            System.out.println("actual value   ->>>>" + actual);
            System.out.println("Expected value ->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }


    public String verifylang(String object, String data) throws Exception {

        String pageText = driver.findElement(By.xpath("//body//div[@class='page-image-wrapper']")).getText();

        // Initialize language detector
        Detector detector = null;
        try {
            DetectorFactory.loadProfile("path_to_profiles");
            detector = DetectorFactory.create();
        } catch (LangDetectException e) {
            e.printStackTrace();
            return KEYWORD_FAIL;
        }

        // Detect language of the page text
        detector.append(pageText);
        String detectedLanguage = detector.detect();
        System.out.println(detectedLanguage);
        // Check if English, Spanish, Norsk, or Svenska language is detected
        if ("en".equals(detectedLanguage) || "es".equals(detectedLanguage) ||
                "no".equals(detectedLanguage) || "sv".equals(detectedLanguage)) {
            return KEYWORD_PASS;
        } else {
            return KEYWORD_FAIL;
        }

    }


    public String Duplicatelines(String object, String data) throws Exception {
        try {
            List<WebElement> elements = driver.findElements(By.xpath(object));

            // Initialize a set to store unique text lines
            Set<String> uniqueTextLines = new HashSet<>();

            // Flag to indicate if any duplicate is found
            boolean duplicateFound = false;

            // Loop through each element to extract text and check for duplicates
            for (WebElement element : elements) {
                String text = element.getText().trim();

                // Check if the text line is already present in the set
                if (uniqueTextLines.contains(text)) {
                    System.out.println("Duplicate found: " + text);
                    duplicateFound = true;
                } else {
                    uniqueTextLines.add(text);
                }
            }

            // If no duplicates found, print message
            if (!duplicateFound) {
                System.out.println("No duplicates found.");
                return KEYWORD_PASS;
            } else if (duplicateFound) {
                return KEYWORD_FAIL;
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyInnerText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getAttribute("innerText");
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
            }
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String pause(String object, String data) throws NumberFormatException, InterruptedException {
        long time = (long) Double.parseDouble(object);
        Thread.sleep(time * 1000L);
        return KEYWORD_PASS;

    }


    public String selectList(String object, String data) throws Exception {
        try {
            int attempt = 0;
            Select objSelect = new Select(Constants.driver.findElement(By.xpath(object)));
            if (!data.equals(Constants.RANDOM_VALUE)) {
                objSelect.selectByVisibleText(data);
                takeSnapShot();
            } else {
                WebElement droplist = Constants.driver.findElement(By.xpath(object));
                List<WebElement> droplist_contents = droplist.findElements(By.tagName("option"));
                Random num = new Random();
                int index = num.nextInt(droplist_contents.size());
                String selectedVal = droplist_contents.get(index).getText();
                objSelect.selectByVisibleText(selectedVal);
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "---Could not select from the List---" + e.getMessage();

        }
        return KEYWORD_PASS;
    }

    /*public String sendkeyboardStroke(String object, String data) throws Exception {
        //valid values for data = space,enter,up,tab,down,left,right
        try {
            Robot robot = new Robot();
            if (!object.equals("")) {
                WebElement browseBtn = Constants.driver.findElement(By.xpath(object));
                browseBtn.click();
                Thread.sleep(1000);
            }
            if (data.equals("space")) {
                robot.keyPress(KeyEvent.VK_SPACE);
                robot.keyRelease(KeyEvent.VK_SPACE);
            } else if (data.equals("enter")) {
                robot.keyPress(KeyEvent.VK_ENTER);
                robot.keyRelease(KeyEvent.VK_ENTER);
            } else if (data.equals("tab")) {
                robot.keyPress(KeyEvent.VK_TAB);
                robot.keyRelease(KeyEvent.VK_TAB);
            } else if (data.equals("down")) {
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Thread.sleep(1000);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "....unable to find element...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }*/

    public String getReportConfigPath() {
        String reportConfigPath = Constants.CONFIG.getProperty("reportConfigPath");
        if (reportConfigPath != null) return reportConfigPath;
        else
            throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
    }

    public String exist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String navigateSubMenu(String object, String data) throws Exception {
        try {
            WebElement ele = Constants.driver.findElement(By.xpath(object));
            //WebElement ele = driver.findElement(By.xpath("element_xpath"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", ele);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "object does not exist " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String AltasRejectDropDown(String object, String data) throws Exception {
        try {
            List<WebElement> dropdown_list = Constants.driver.findElements(By.xpath(object));
            //System.out.println("The Options in the Dropdown are: " + dropdown_list.size());
            for (int i = 0; i < dropdown_list.size(); i++) {
                //System.out.println(dropdown_list.get(i).getText());
                if (dropdown_list.get(i).getText().contains(data)) {
                    for (int j = 1; j < 10000; j++) {
                        String vdata = Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).getText();
                        if (vdata.equals(data)) {
                            Constants.driver.findElement(By.xpath("//div[@id='input-more-reject-reasons']//li[" + j + "]//label[1]")).click();
                            break;
                        }
                    }
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }

    public String pdf(String object, String data) throws Exception {
        try {
            // Navigate to the webpage containing the PDF link
//            driver.get("URL_of_the_page_containing_PDF_link");
//
//            // Find the link to the PDF file
//            WebElement pdfLink = driver.findElement(By.linkText("Link_Text_of_PDF"));
//
//            // Get the URL of the PDF file
//            String pdfUrl = pdfLink.getAttribute("href");
//
//            // Download the PDF file
//            driver.get(pdfUrl);

            // Wait for the PDF to be downloaded (you may need to implement a proper wait mechanism here)

            // Specify the path to save the downloaded PDF file
            String pdfFilePath = "C:\\NOT\\src\\main\\resources\\AllPdf\\THIRD_PARTY_AUTHORISATION";

            // Rename the downloaded file if needed
            File downloadedFile = new File(pdfFilePath);

            // Extract text from the downloaded PDF
            PDDocument document = PDDocument.load(downloadedFile);

            // Create PDFTextStripper object
            PDFTextStripper pdfStripper = new PDFTextStripper();

            // Extract text from PDF
            String pdfText = pdfStripper.getText(document);

            // Save extracted text to a text file
            String textFilePath = "C:\\NOT\\src\\main\\resources\\AllPdf\\THIRD_PARTY_AUTHORISATION.txt";
            FileOutputStream fos = new FileOutputStream(textFilePath);
            fos.write(pdfText.getBytes());
            fos.close();

            // Close the PDF document
            document.close();

            // Return success status
            System.out.println("Extraction successful!");
            return KEYWORD_PASS; // Assuming KEYWORD_PASS is defined somewhere in your framework

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Close the WebDriver instance
        }

        // If extraction failed, return failure status
        System.out.println("Extraction failed!");
        return KEYWORD_FAIL; // Assuming KEYWORD_FAIL is defined somewhere in your framework
    }

 /*   public void ReadCookies() {
        // create file named Cookies to store Login Information
        File file = new File("C:\\POC2\\CucumberSeleniumProject\\Cookies.data");
        try {
            // Delete old file if exists
            file.delete();
            file.createNewFile();
            FileWriter fileWrite = new FileWriter(file);
            BufferedWriter Bwrite = new BufferedWriter(fileWrite);
            // loop for getting the cookie information

            // loop for getting the cookie information
            for (Cookie ck : Constants.driver.manage().getCookies()) {
                Bwrite.write((ck.getName() + ";" + ck.getValue() + ";" + ck.getDomain() + ";" + ck.getPath() + ";" + ck.getExpiry() + ";" + ck.isSecure()));
                Bwrite.newLine();
            }
            Bwrite.close();
            fileWrite.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void WriteCookies() {
        try {

            File file = new File("C:\\POC2\\CucumberSeleniumProject\\Cookies.data");
            FileReader fileReader = new FileReader(file);
            BufferedReader Buffreader = new BufferedReader(fileReader);
            String strline;
            while ((strline = Buffreader.readLine()) != null) {
                StringTokenizer token = new StringTokenizer(strline, ";");
                while (token.hasMoreTokens()) {
                    String name = token.nextToken();
                    String value = token.nextToken();
                    String domain = token.nextToken();
                    String path = token.nextToken();
                    Date expiry = null;

                    String val;
                    if (!(val = token.nextToken()).equals("null")) {
                        expiry = new Date(val);
                    }
                    Boolean isSecure = new Boolean(token.nextToken()).
                            booleanValue();
                    Cookie ck = new Cookie(name, value, domain, path, expiry, isSecure);
                    System.out.println(ck);
                    Constants.driver.manage().addCookie(ck); // This will add the stored cookie to your current session
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }*/

    public String isAlertPresent() {
        try {
            Alert alert = Constants.driver.switchTo().alert();
            System.out.println("Alert Message" + alert.getText());
            alert.accept();
        } catch (NoAlertPresentException e) {
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String clearText(String object) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).clear();
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String SfLeadDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("2", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String VerifyTitle(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.getTitle();
            String expected = data;
            System.out.println("actual value->>>>" + actual);
            System.out.println("data value->>>>" + data);
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }
    //
    //        w.until(ExpectedConditions.visibilityOfAllElements( By.xpath(Constants.CreateFxTicketOR.getProperty("CloseFxSlipButton"))));

    public String VisibleConditionWait(String object, String data) throws Exception {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(120));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String KeyboardAction(String object, String data) throws Exception {
        try {
            if (data.equalsIgnoreCase("enter")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ENTER);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("tab")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.TAB);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("space")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.SPACE);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("downArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_DOWN);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("selectall")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.chord(Keys.CONTROL, "a"));
                takeSnapShot();
            } else if (data.equalsIgnoreCase("upArrow")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.ARROW_UP);
                takeSnapShot();
            } else if (data.equalsIgnoreCase("delete")) {
                Constants.driver.findElement(By.xpath(object)).sendKeys(Keys.DELETE);
                takeSnapShot();
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String SelectRecipient(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'Select')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String RecipientTransfer(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Transfer')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String RecipientPay(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Pay')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyElementProperties(String object, String data) throws Exception {
        try {
            if (data.contains("disabled")) {
                String buttonDisabled = Constants.driver.findElement(By.xpath(object)).getAttribute("disabled");
                if (buttonDisabled != null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not Disabled";
                }
            } else if (data.contains("enabled")) {
                String buttonEnabled = Constants.driver.findElement(By.xpath(object)).getAttribute("disabled");
                if (buttonEnabled == null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not Enabled";
                }

            } else if (data.contains("visible")) {
                if (Constants.driver.findElement(By.xpath(object)).isDisplayed()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Displayed";
                }
            } else if (data.contains("unselected")) {
                if (!Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("selected")) {
                if (Constants.driver.findElement(By.xpath(object)).isSelected()) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " -Not Exists";
                }
            } else if (data.contains("readonly")) {
                String readonly = Constants.driver.findElement(By.xpath(object)).getAttribute("readonly");
                if (readonly != null) {
                    takeSnapShot();
                    return KEYWORD_PASS;
                } else {
                    takeSnapShot();
                    return KEYWORD_FAIL + " - Not readonly";
                }
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + " -  Could not find element";

        }
        return KEYWORD_PASS;
    }


    public String CheckDuplicayofMail(String object1, String object2) throws Exception {
        try {
            // Find all elements matching the first locator
            List<WebElement> elements1 = driver.findElements(By.xpath(object1));

            // Find all elements matching the second locator or initialize an empty list if elements2 is not present
            List<WebElement> elements2 = driver.findElements(By.xpath(object2));
            if (elements2 == null) {
                elements2 = new ArrayList<>();
            }

            // Get the sizes of the lists
            int size1 = elements1.size();
            int size2 = elements2.size();

            // Calculate the difference in sizes
            int difference = size1 - size2;

            // Check if the difference is greater than 1
            if (difference > 1) {
                System.out.println("The difference between the sizes is greater than 1. so duplicate mail");
                return KEYWORD_FAIL;
                // Perform your action here
                // For example, you can print the difference again or take some other action
            } else {
                System.out.println("no duplicate mail");

            }

            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_PASS;
        }
        return KEYWORD_FAIL + "object exist ";
    }

    public String notexist(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_PASS;
        }
        return KEYWORD_FAIL + "object exist ";
    }

    public String uniqueEmailID(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            String emailID = "AutoTestUser" + userName + "@gmail.com";
            LogCapture.info("emailID start with xyz is " + ": " + emailID);
            //System.out.println("Result......" + emailID);
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(1000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(emailID);
            // Constants.driver.findElement(By.xpath(object)).sendKeys("autotestuser213440261@gmail.com");
            Email = Constants.driver.findElement(By.xpath(object)).getText();
            System.out.println("AutoTestUser Email ID" + Email);
            Thread.sleep(1000);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String uniqueEmailAddress(String object, String data) throws Exception {
        try {
            String userName = "" + (int) (Math.random() * Integer.MAX_VALUE);
            emailID = "xyz" + userName + "@gmail.com";

            LogCapture.info("emailID is " + ": " + emailID);


        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return emailID;
    }

    public String ClickEachElementOfFrame(String object, String data) throws Exception {
        try {
            //    List<WebElement> Elements = driver.findElements(By.cssSelector(object));
            List<WebElement> Elements = Constants.driver.findElements(By.xpath(object));
            ListIterator<WebElement> ListOfElements = Elements.listIterator();
            while (ListOfElements.hasNext()) {
                WebElement elem = ListOfElements.next();
                // do something with elem
                elem.click();
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String MouseFunctions(String object, String data) throws Exception {
        try {
            WebElement Element = driver.findElement(By.xpath(object));
            Actions action = new Actions(Constants.driver);
            if (data.equalsIgnoreCase("clickAndHold")) {
                action.moveToElement(Element).build().perform();
                action.clickAndHold(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("ReleaseMouseClick")) {
                action.moveToElement(Element).build().perform();
                action.release(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("DoubleClick")) {
                action.doubleClick(Element).build().perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("MoveToElement")) {
                action.moveToElement(Element);
                action.perform();
                takeSnapShot();
            } else if (data.equalsIgnoreCase("click")) {
                action.click(Element).build().perform();
                takeSnapShot();
            }

        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL + "Not able to clickAndHold...." + e.getMessage();
        }
        return Constants.KEYWORD_PASS;
    }

    public String Mouse_Events(String Object, String data) throws Exception {
        try {

            Actions build = new Actions(Constants.driver);
            build.moveToElement(Constants.driver.findElement(By.xpath(Object))).moveByOffset(11, 11).click().build().perform();
        } catch (Exception e) {
            takeSnapShot();
            return
                    KEYWORD_FAIL;
        }
        return
                KEYWORD_PASS;
    }


    public String PdfDownload(String Object, String data) throws Exception {
        try {

            String vObjDownloadLink = "//button[@id='toolbar-download-menu-button']//span[@class='SVGInline']//*[name()='svg']";
            Constants.key.pause("2", "");
            String vObjpdf = "//span[normalize-space()='Combined PDF']";
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjDownloadLink, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjpdf, ""));
            Assert.assertEquals("PASS", Constants.key.defaultDownloadFilesOperations("isFileDownloaded", data + ".pdf"));
        } catch (Exception e) {
            takeSnapShot();
            return
                    KEYWORD_FAIL;
        }
        return
                KEYWORD_PASS;
    }


    public String defaultDownloadFilesOperations2(String object, String data) {
        try {

//            File fileToRename = new File(System.getProperty("user.dir") + "/FileUploadDocuments/");
//            File renamedFile = new File(fileToRename.getParent(), "contract.pdf");
//            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            // Set the path to your downloads folder
            String downloadFolderPath = System.getProperty("user.dir") + "/FileUploadDocuments/";
            System.out.println(downloadFolderPath);
            // Locate the downloaded file
            File downloadFolder = new File(downloadFolderPath);
            File[] dirContents = downloadFolder.listFiles();

            // Check if the directory is not empty and contains files
            if (dirContents != null) {
                for (File file : dirContents) {
                    if (file.isFile()) {
                        // Rename the file to "contract.pdf"
                        File renamedFile = new File(downloadFolder, "THIRD_PARTY_AUTHORISATION.pdf");
                        if (file.renameTo(renamedFile)) {
                            System.out.println("File renamed successfully.");
                        } else {
                            System.out.println("Failed to rename the file.");
                        }
                        break; // Assuming there is only one file to rename
                    }
                }
            } else {
                System.out.println("No files found in the download folder.");
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String Enter_OTP(String object, String data) throws Exception {
        try {
            List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
            for (WebElement input : inputs) {
                input.clear();
                input.sendKeys(data);
                break;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }
//Xpath  Used for Entering OTP  EnterPinTextBox= //input[@class="pin-number"]
// input is the tag name of all the all the textfields which are in one frameand we have used it to iterate into the Loop

    public String ClickIfEnable(String object, String data) throws Exception {
        try {
            int attempts = 0;
            int maxAttempts = 10;
            Constants.key.VisibleConditionWait(object, "");
//        boolean buttonDisabled = false;
            while (attempts++ <= maxAttempts) {
                if (Constants.driver.findElement(By.xpath(object)).isEnabled()) {
                    Constants.driver.findElement(By.xpath(object)).click();
                    break;
                } else {
                    Thread.sleep(500);
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "drop down value does not exist " + e.getMessage();
        }
        takeSnapShot();
        return KEYWORD_PASS;
    }

    public String writeInInputObO(String object, String data) throws Exception {
        try {
            String val = data;
            WebElement element = Constants.driver.findElement(By.xpath(object));
            element.clear();
            for (int i = 0; i < val.length(); i++) {
                char c = val.charAt(i);
                String s = new StringBuilder().append(c).toString();
                element.sendKeys(s);
                Thread.sleep(2000);
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write one by one " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public static String[] generateRandomWords(int numberOfWords) {
        String[] randomStrings = new String[numberOfWords];
        Random random = new Random();
        for (int i = 0; i < numberOfWords; i++) {
            char[] word = new char[random.nextInt(8) + 3]; // words of length 3 through 10. (1 and 2 letter words are boring.)
            for (int j = 0; j < word.length; j++) {
                word[j] = (char) ('a' + random.nextInt(26));
            }
            randomStrings[i] = new String(word);
        }
        return randomStrings;
    }

    public String randomWordGenerator(String object, int numberOfWords) throws Exception {
        try {
            String[] randomStrings = new String[numberOfWords];
            Random random = new Random();
            for (int i = 0; i < numberOfWords; i++) {
                char[] word = new char[random.nextInt(1) + 1]; // words of length 3 through 10. (1 and 2 letter words are boring.)
                for (int j = 0; j < word.length; j++) {
                    word[j] = (char) ('a' + random.nextInt(26));
                }
                randomStrings[i] = new String(word);

            }
            Constants.driver.findElement(By.xpath(object)).clear();
            Thread.sleep(2000);
            Constants.driver.findElement(By.xpath(object)).sendKeys(randomStrings);
            System.out.println("Random string generated: " + randomStrings);

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String DeleteRecipient(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::td[4]//span[contains(text(),'x')]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String selectPTRecord(String object, String innerObject, String data) throws Exception {
        try {
            List<WebElement> listElements = Constants.driver.findElements(By.xpath(object));
            for (int i = 0; i < listElements.size(); i++) {
                if (i % 5 == 0) {
                    click(Constants.PaymentTrackingOR.getProperty("ShowMoreButton"), "");
                }
                WebElement element = listElements.get(i);
                element.click();
                Thread.sleep(2000);
                try {
                    WebElement referenceElement = element.findElement(By.xpath(innerObject));
                    if (referenceElement != null) {
                        referenceElement.click();
                        LogCapture.info("Record displayed on PT dashboard =" + referenceElement.getText());
                        takeSnapShot();
                        return KEYWORD_PASS;
                    }
                } catch (Exception e) {
                    LogCapture.info(e.getMessage());
                }
            }
            return KEYWORD_FAIL + "Record is not displayed on PT dashboard";

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
    }

    public String LanguageDD(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).click();
            Constants.key.pause("3", "");
            Constants.driver.findElement(By.xpath(data)).click();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String ConvertStringToCase(String word, String strcase) throws Exception {
        try {
            if (strcase.equalsIgnoreCase("lower")) {
                word = word.toLowerCase();
            } else if (strcase.equalsIgnoreCase("upper")) {
                word = word.toUpperCase();
            }
        } catch (Exception e) {
            LogCapture.info(e.getMessage());
        }
        return word;
    }


    public String getText(String object, String data) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("Actual Length:->" + actual.length());
            }
            LogCapture.info("Actual:->" + actual);
        } catch (Exception e) {
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        }
        return actual;

    }

    public String ChatFileOperation(String operation, String data) throws IOException {
        try {
            String path = System.getProperty("user.home");

            path = path + "/Downloads";
            LogCapture.info(path);
            File file = new File(path);
            File files[] = file.listFiles();
            String filename, filename1;
            for (File f : files) {
                if (f.getName().contains(data)) {
                    filename = f.getName();
                    System.out.println(f.getName());
                    if (operation.equalsIgnoreCase("delete")) {
                        f.delete();
                        LogCapture.info(f.getName() + " file got deleted successfully");
                    } else if (operation.equalsIgnoreCase("exist")) {
                        if (filename.equalsIgnoreCase(data + ".txt")) {
                            LogCapture.info(f.getName() + " file downloaded successfully");
                        }
                    } else if (operation.equalsIgnoreCase("verifycontent")) {
                        FileInputStream fstream1 = new FileInputStream(path + "/" + data + ".txt");

                        DataInputStream in1 = new DataInputStream(fstream1);
                        //DataInputStream in2= new DataInputStream(fstream2);

                        BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
                        //BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));

                        String strLine1;
                        String strLine2 = "How can I help you?";


                        while ((strLine1 = br1.readLine()) != null) {
                            if (strLine1.contains(strLine2)) {
                                LogCapture.info(f.getName() + " file downloaded has chat conversation");
                                LogCapture.info(strLine1 + " file downloaded has content");
                                LogCapture.info(f.getName() + " file downloaded content has been compare with " + strLine2);

                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return KEYWORD_FAIL;

        }
        return KEYWORD_PASS;
    }


/*    HtmlUnitDriver driver = new HtmlUnitDriver(BrowserVersion.CHROME ,true);
driver.get("your web URL");
    WebDriverWait wait = new WebDriverWait(driver, 30);
wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("ppLoginForm"))));
wait.until(ExpectedConditions.elementToBeClickable(By.name("j_username")));*/


    public String navigateNewTab(String object, String data) throws Exception {
        try {
            String currentHandle = Constants.driver.getWindowHandle();

            ((JavascriptExecutor) Constants.driver).executeScript("window.open()");


            Set<String> handles = Constants.driver.getWindowHandles();
            for (String actual : handles) {

                if (!actual.equalsIgnoreCase(currentHandle)) {
                    //switching to the opened tab
                    Constants.driver.switchTo().window(actual);

                    //opening the URL saved.
                    Constants.driver.navigate().to(data);
                }
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";
        }
        return KEYWORD_PASS;
    }

    public String navigateTab(String Object, int data) throws Exception {
        try {
            ArrayList<String> tabs = new ArrayList<String>(Constants.driver.getWindowHandles());
            Constants.driver.switchTo().window(tabs.get(data));
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String selectOrganisationBussinessPartner(String object, String data) throws Exception {
        WebElement element = null;
        String vObjOrganisationBussinessPartner = "";
        try {
            for (int i = 0; i <= 100; i++) {

                if (object.equals("Organisation")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisations-" + i + "']";
                } else if (object.equals("Business Partner")) {
                    vObjOrganisationBussinessPartner = "//label[@for='chk-organisation-business-partner-" + i + "']";
                }
                //LogCapture.info(vObjOrganisation);

                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjOrganisationBussinessPartner, ""));
                String abc = Constants.key.getText(vObjOrganisationBussinessPartner, "");
                //LogCapture.info(abc);

                if (abc.equalsIgnoreCase(data)) {
                    // LogCapture.info("inside");
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "MoveToElement"));
                    Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjOrganisationBussinessPartner, "click"));
                    //element.findElement(By.xpath(vObjOrganisation)).click();
                    takeSnapShot();
                    break;
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable select" + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String verifyOrganisationIntableCustomer(String object, String data, String column) throws Exception {
        int a = 0, b = 0;
        try {
            List<WebElement> itemsfiler = driver.findElements(By.xpath("//tbody[@id='accountSummaryTableBody']/tr"));
            int trnofilter = itemsfiler.size() + 1;
            //LogCapture.info("Total rows" +trnofilter);
            for (int s = 2; s < trnofilter; s++) {
                String organization = "//tbody[@id='accountSummaryTableBody']/tr[" + s + "]/td[" + column + "]/a[1]";
                String rowdata = Constants.driver.findElement(By.xpath(organization)).getText();
                //LogCapture.info("organization" +rowdata);
                if (rowdata.equals(data)) {
                    a = a + 1;
                } else {
                    b = b + 1;
                }
            }
            //LogCapture.info("Number of match rows->" +a);
            //LogCapture.info("Number of unmatch rows->" +b);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "something went wrong while fetching data " + e.getMessage();
        }
        if (b > 0) {
            return KEYWORD_FAIL;
        } else {
            return KEYWORD_PASS;
        }
    }

    public String scrollIntoViewElement(String object, String data) throws Exception {
        try {
            WebElement vObject = Constants.driver.findElement(By.xpath(object));
            ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView", vObject);
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String ReadPDFFile(String object, String data) throws IOException {
        try {
            String fileName = "T" + System.currentTimeMillis();
            File sourceFile = new File(System.getProperty("user.dir") + "/Downloads/" + data);
            File newFile = new File(System.getProperty("user.dir") + "/Downloads/" + fileName + ".pdf");
            if (sourceFile.exists()) {
                LogCapture.info("File name is correct: " + sourceFile.getName());
            } else {
                LogCapture.info("File name is INCORRECT: " + sourceFile.getName());
                Assert.fail();
            }

            LogCapture.info("Creating copy of file..");
            newFile.createNewFile();
            FileUtils.copyFile(sourceFile, newFile);
            String url = "file:///" + downloadFilesPath + fileName + ".pdf";
            URL pdfUrl = new URL(url);
            InputStream in = pdfUrl.openStream();
            BufferedInputStream bf = new BufferedInputStream(in);
            PDDocument doc = PDDocument.load(bf);
            if (object.equalsIgnoreCase("PageCount")) {
                int numberOfPages = doc.getNumberOfPages();
                System.out.println("The total number of pages " + numberOfPages);
            } else if (object.equalsIgnoreCase("PageText")) {
                PDFTextStripper pdfStrip = new PDFTextStripper();
                String content = pdfStrip.getPageStart();
                System.out.println("Content of the page is" + content);
            }
            doc.close();
//            LogCapture.info("Source file getting deleted with file name: " + sourceFile.getName());
//            boolean DeletSourceFile=sourceFile.delete();
//            if(DeletSourceFile){
//                LogCapture.info("Source file deleted");
//            }
//            else{
//                LogCapture.info("Source file NOT deleted");
//                Assert.fail();
//            }
            return KEYWORD_PASS;
        } catch (IOException e) {
            e.printStackTrace();
            return KEYWORD_FAIL;
        }

    }

    public String defaultDownloadFilesOperations(String object, String data) {
        try {
//            if (object.equalsIgnoreCase("deleteAllFiles")) {
//                try {
//                    LogCapture.info("All files deleted present in directory: " + downloadFilesPath);
//                    FileUtils.cleanDirectory(new File(downloadFilesPath));
//                } catch (IOException e) {
//                }
//            } else

            if (object.equalsIgnoreCase("deleteSelectedFile")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        dir_contents[i].delete();
                        LogCapture.info(data + " file deleted..");
                        LogCapture.info("Number of files got deleted: " + i);
                    }
                }
            } else if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                File dir = new File(downloadFilesPath);
                File[] dir_contents = dir.listFiles();
                for (int i = 0; i < dir_contents.length; i++) {
                    if (dir_contents[i].getName().equals(data)) {
                        LogCapture.info(data + " file downloaded..");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String renameDownloadedFile(String object, String data) {
        try {
            String NewfileName = "T" + System.currentTimeMillis();
            File sourceFile = new File(System.getProperty("user.dir") + "/Downloads/" + data);
            File newFile = new File(System.getProperty("user.dir") + "/Downloads/" + NewfileName + ".pdf");
            if (sourceFile.exists()) {
                LogCapture.info("File exist with name: " + sourceFile.getName());
                LogCapture.info("Creating copy of file..");
                newFile.createNewFile();
                FileUtils.copyFile(sourceFile, newFile);
                newFile.isFile();
                LogCapture.info("Created copy of file with filename: " + newFile.getName());
            } else {
                LogCapture.info("File DOES NOT exist with name: " + data);
                Assert.fail();
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "Not able to view...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public boolean openBrowserWithDefaultDownloadDirectory(String object, String data) throws Exception {
//        try {
//            String oSName = System.getProperty("os.name");
//            if (data.equals("Chrome")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/windows/chromedriver.exe");
//                    //System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
//                    ChromeOptions options = new ChromeOptions();
//                    options.addArguments("--start-maximized");
//                    Map<String, Object> prefs = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    prefs.put("download.default_directory", downloadFilesPath);
//                    prefs.put("plugins.always_open_pdf_externally", true);
//                    prefs.put("download.directory_upgrade", true);
//                    prefs.put("download.prompt_for_download", false);
//
//                    HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    DesiredCapabilities cap = DesiredCapabilities.chrome();
//                    cap.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
//                    cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//                    cap.setCapability(ChromeOptions.CAPABILITY, options);
//
//
//                    driver = new ChromeDriver(cap);
//                    // Constants.driver.manage().window().maximize();
//                    takeSnapShot();
//                } else {
//                    System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/linux/chromedriver");
//                    ChromeOptions options = new ChromeOptions();
//                    options.setHeadless(true);
//                    //options.addArguments("--window-size=1920,1080")  ;
//                    //options.addArguments("--disable-gpu");
//                    //options.addArguments("--headless --disable-gpu --screenshot "+ data)   ;
//                    options.addArguments("--disable-extensions");
//                    options.setExperimentalOption("useAutomationExtension", false);
//                    options.addArguments("--proxy-server='direct://'");
//                    options.addArguments("--proxy-bypass-list=*");
//                    //options.addArguments("--start-maximized");
//                    //options.addArguments("--headless");
//                    options.addArguments("--whitelisted-ips");
//                    options.addArguments("--disable-dev-shm-usage");
//                    options.addArguments("--no-sandbox");
//
//                    options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
//                    Map<String, Object> prefs = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    prefs.put("download.default_directory", downloadFilesPath);
//                    prefs.put("plugins.always_open_pdf_externally", true);
//                    prefs.put("download.directory_upgrade", true);
//                    prefs.put("download.prompt_for_download", false);
//
//                    HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
//                    options.setExperimentalOption("prefs", prefs);
//                    DesiredCapabilities cap = DesiredCapabilities.chrome();
//                    cap.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
//                    cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//                    cap.setCapability(ChromeOptions.CAPABILITY, options);
//
//                    //options.addArguments("window-size=1920,1080");
//                    // options.addArguments("--headless --disable-gpu --screenshot --window-size=1920,1080 --start-maximized" + data);
//
//                    driver = new ChromeDriver(cap);
//                    driver.manage().window().maximize();
//                    takeSnapShot();
//                    //options.addArguments("--no-sandbox");
//                }
//            } else if (data.equals("FF")) {
//                System.setProperty("webdriver.gecko.driver", "C:\\WhiteLabelAutomation\\Drivers\\FireFox\\geckodriver.exe");
//                File pathBinary = new File("C:\\Users\\saurabh.gadgil\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
//                FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
//                DesiredCapabilities desired = DesiredCapabilities.firefox();
//                FirefoxOptions options = new FirefoxOptions();
//                desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
//                driver = new FirefoxDriver(options);
//                driver.manage().window().maximize();
//
//
//                /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//                Constants.driver = new FirefoxDriver();
//                Constants.driver.manage().window().maximize();*/
//            } else if (data.equalsIgnoreCase("FireFox")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//                    File pathBinary = new File(System.getProperty("user.home") + "/AppData/Local/Mozilla Firefox/firefox.exe");
//                    FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
//                    DesiredCapabilities desired = DesiredCapabilities.firefox();
//                    FirefoxOptions options = new FirefoxOptions();
//                    desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
//                    driver = new FirefoxDriver(options);
//                    driver.manage().window().maximize();
//    /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//    Constants.driver = new FirefoxDriver();
//    Constants.driver.manage().window().maximize();*/
//                } else {
//                    //Firefox linux connection here
//                }
//            } else if (data.equalsIgnoreCase("Edge")) {
//                if (oSName.toUpperCase().contains("WIN")) {
//                    System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "/Drivers/Edge/msedgedriver.exe");
//                    driver = new EdgeDriver();
//                    driver.manage().window().maximize();
//                    //takeSnapShot();
//                    takeSnapShot();
//    /*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/Drivers/FireFox/geckodriver.exe");
//    Constants.driver = new FirefoxDriver();
//    Constants.driver.manage().window().maximize();*/
//                } else {
//                    //Firefox linux connection here
//                }
//            }
//
//            return true;
//        } catch (Exception ex) {
//            System.out.println(ex);
//            LogCapture.info("Webdriver not found..." + ex);
//            takeSnapShot();
//            LogCapture.info("Snapshot Captured..");
//            return false;
//        }
        return false;
    }

    public String fileDownload(String object, String data) throws Exception {
        try {
            Screen src = new Screen();
            Pattern fileInputTextBox = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "filedownload.png");
            LogCapture.info(String.valueOf(fileInputTextBox));
            src.type(Key.BACKSPACE);
            // src.type(fileInputTextBox,System.getProperty("user.dir") +File.separator+ "DownloadedFiles"+File.separator+data);
            src.type(fileInputTextBox, data);

            Pattern saveButton = new Pattern(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "save.png");
            LogCapture.info(String.valueOf(saveButton));
            src.click(saveButton);
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String fileDownloadOperations(String object, String data) {
        File file = new File(System.getProperty("user.dir") + File.separator + "DownloadedFiles" + File.separator + data);
        try {
            if (object.equalsIgnoreCase("isFileAvailable") || object.equalsIgnoreCase("isFileDownloaded")) {
                if (file.exists())
                    System.out.println("File Exists on given path : " + data);
                else
                    System.out.println("File Does not Exists on given path");
            } else if (object.equalsIgnoreCase("deleteDownloadedFile")) {
                if (file.delete())
                    System.out.println("File deleted : " + data);
                else
                    System.out.println("File was not deleted");
            }
        } catch (Exception e) {
            return KEYWORD_FAIL + "file not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    //------------------------- API Values--------------------------------------------

    public static Map<String, String> getSqlQueryResult(String sqlQueryProperty, String... values) {
        String query = SQLQUERIES.getProperty(sqlQueryProperty);
        query = String.format(query, (Object[]) values);
        LogCapture.info("Query is :" + query);
        return executeQuery(Constants.connectionUrl, Constants.dBUsername, Constants.dbPassword, query);
    }

    public static Map<String, String> getSqlQueryResult1(String sqlQueryProperty, String Environment, String values) throws ClassNotFoundException {
        String queryInfo = SQLQUERIES.getProperty(sqlQueryProperty);
        String db = queryInfo.split("\\|")[0];
        String query = queryInfo.split("\\|")[1];
        if (Objects.nonNull(values)) {
//            query = String.format(query, (Object[]) values);
            query = query.replace("%s", values);
            System.out.println(query);
        }
        return executeQuery1(db + Environment, query);
    }

//    private static Connection getConnection(String databaseName) throws InterruptedException {
//        int retry = 10;
//        Connection connection = null;
//        String connectionUrl = Constants.dbconfig.getProperty(databaseName);
//        while (retry-- > 0 && Objects.isNull(connection)) {
//            try {
//                String dbClass = CONFIG.getProperty("dbClass");
//                Class.forName(dbClass);
//                DriverManager.setLoginTimeout(15);
//                connection = DriverManager.getConnection(connectionUrl);
//            } catch (SQLException e) {
//                LogCapture.error("Could not connect to database. Retrying again!!");
//                key.pause("2","");
//            }
//        }
//        return connection;
//    }

    public static Map<String, String> executeQuery1(String databaseName, String query) throws ClassNotFoundException {
        Map<String, String> trnDetails = new HashMap<>();
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String dbUrl = Constants.dbconfig.getProperty(databaseName);
        try (Connection connection = java.sql.DriverManager.getConnection(dbUrl)) {
            PreparedStatement ps = connection.prepareStatement(query);
            boolean retry = true;
            int retryCount = 5;
            while (retry && retryCount-- > 0) {
                try (ResultSet rs = ps.executeQuery()) {
                    ResultSetMetaData rsMD = rs.getMetaData();
                    while (rs.next()) {
                        retry = false;
                        for (int i = 1; i <= rsMD.getColumnCount(); i++) {
                            trnDetails.put(rsMD.getColumnName(i), rs.getString(rsMD.getColumnName(i)));
                        }
                        break;
                    }
                    key.pause("1", "");
                } catch (Exception e) {
                    LogCapture.error("Exception occurred while fetching the result set: " + e.getLocalizedMessage());
                }
            }
        } catch (Exception e) {
            LogCapture.error("Exception occurred while querying the " + databaseName + " database: " + e.getLocalizedMessage());
        }
        return trnDetails;
    }

    public static Map<String, String> executeQuery(String connectionUrl, String DB_USER, String DB_PASSWORD, String query) {
        Map<String, String> result = new HashMap<>();
        try (Connection connection = java.sql.DriverManager.getConnection(connectionUrl, DB_USER, DB_PASSWORD)) {
            if (connection != null) {
                LogCapture.info("Connected to DB");
            }
            PreparedStatement ps = connection.prepareStatement(query);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData rsMD = rs.getMetaData();
                while (rs.next()) {
                    for (int i = 1; i <= rsMD.getColumnCount(); i++) {
                        result.put(rsMD.getColumnName(i), rs.getString(rsMD.getColumnName(i)));
                    }
                }

            } catch (Exception e) {
                LogCapture.error("Exception occurred while fetching the result set: " + e.getLocalizedMessage());
            }
        } catch (SQLException e) {
            LogCapture.error("Exception occurred while querying the database: " + e.getLocalizedMessage());
        }
        return result;
    }

    public String VerifyDBDetails(String environment, String data, String operationType) throws Exception {
        //For connection
        java.sql.Connection connection = null;
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String query = null;
        String value = null;
        String AccountNumber = null;
        int Count = 0;
        String vTitanTransactionReference = null;
        String vTradeAmount = null;
        String StatementID = null;
        String StatementLineID = null;
        String MSL_ID = null;
        String Account_ID = null;
        String Legal_Entity_ID = null;
        String Legal_Entity = null;
        String ROF_ID = null;
        String ConfirmationID = null;
        String IntradayStatement = null;
//        String IntradayStatementLineID=null;
        String ActualRemitterAccountNumber = null;
        String ActualRemitterAccountName = null;
        String vIsParsed = null, vParsedStatus = null;
        List<String> list = new ArrayList<String>();
        HashMap<String, List<String>> ActualRemitter = new HashMap<>();
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("SITDB_URL") + ":" + Constants.dbconfig.getProperty("SITDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("SITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("UATDB_URL") + ":" + Constants.dbconfig.getProperty("UATDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("UATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("UATDB_Password");

        } else if (environment.equalsIgnoreCase("SIT_Titan")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanSITDB_URL") + ":" + Constants.dbconfig.getProperty("TitanSITDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanSITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanSITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT_Titan")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanUATDB_URL") + ":" + Constants.dbconfig.getProperty("TitanUATDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanUATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanUATDB_Password");

        }
        Constants.connectionUrl = DB_URL;
        Constants.dBUsername = DB_USER;
        Constants.dbPassword = DB_PASSWORD;


//        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//        Class.forName(dbClass).newInstance();

        LogCapture.info("Get connection to DB");

        if (operationType.equalsIgnoreCase("FetchTANforCDLGBPFX")) {
            query = "Select Top 50 CustomerWallet From Titan.Titan.CustomerwalletBalance where TotalBalance ='0.00' order by CreatedOn desc";
            Statement stmt = connection.createStatement();
            ps = connection.prepareStatement(query);
            //ps.setNString(1, data);
            ResultSet res = stmt.executeQuery(query);
            while (res.next()) {
                String CustWallet = res.getString("CustomerWallet");

                String QuerruAccountnumber = "Select Account from Titan.Titan.CustomerWallet where ID='" + CustWallet + "'";
                ResultSet res1 = connection.createStatement().executeQuery(QuerruAccountnumber);

                while (res1.next()) {
                    String AccountNo = res1.getString("Account");

                    String QuerruCDLGBPFXCust = "Select Organization,LegalEntity,AccountNumber,CustomerAccountType,AccountStatus From Titan.Titan.Account where ID ='" + AccountNo + "'";
                    ResultSet re2 = connection.createStatement().executeQuery(QuerruCDLGBPFXCust);

                    while (re2.next()) {
                        AccountNumber = re2.getString("AccountNumber");
                        String Organization = re2.getString("Organization");
                        String LegalEntity = re2.getString("LegalEntity");
                        String CustomerAccountType = re2.getString("CustomerAccountType");
                        String AccountStatus = re2.getString("AccountStatus");
                        if (Organization.equals("2") && LegalEntity.equals("3") && CustomerAccountType.equals("1") && AccountStatus.equals("2")) {
                            Count++;
                            value = AccountNumber;
                            System.out.println("CDLGB PFX Customer TAN is >>>>>>>>>>>>>>>>>>>>>>>>>>> " + value);
                            break;
                        }
                    }
                }
            }
        } else if (operationType.equalsIgnoreCase("Verify Deal Details")) {

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN_Order", "");
            String Dealid = result.get("ID");
            value = Dealid;
            LogCapture.info("deal id is" + value);
        } else if (operationType.equalsIgnoreCase("Fetch Latest Payment Titan Transaction Reference Number")) {
            Map<String, String> result = Reusables.getSqlQueryResult("TI_PaymentInstructionsDetails", data);
            value = result.get("Td_txn_ref_number");
            LogCapture.info("Latest Payment Titan Transaction Reference Number is" + value);

        } else if (operationType.equalsIgnoreCase("Find the StatementLineID")) {
            Constants.key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus = result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);

            Assert.assertTrue(vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));

            Map<String, String> result1 = Reusables.getSqlQueryResult("Statement_940", data);
            StatementID = result1.get("ID");
            LogCapture.info("Value of StatementID: " + StatementID);
            Assert.assertFalse(false, String.valueOf(StatementID.contains("null")));
            Constants.RemitterNameID = StatementID;
            Map<String, String> result2 = Reusables.getSqlQueryResult("StatementLine_940", StatementID);
            StatementLineID = result2.get("ID");
            LogCapture.info("Value of StatementLineID: " + StatementLineID);
            Assert.assertFalse(false, String.valueOf(StatementLineID.contains("null")));
            value = StatementLineID;
            LogCapture.info("StatementLineID is " + value);


        } else if (operationType.equalsIgnoreCase("Find the MSL_ID")) {
            String StatementID1 = Constants.StatementLineID;
            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine53", StatementID1);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, String.valueOf(MSL_ID.contains("null")));
            value = MSL_ID;
        } else if (operationType.equalsIgnoreCase("ConfirmationPaymentAdvice ID")) {
//                Constants.key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus = result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);
            Assert.assertTrue(vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));


            Map<String, String> result1 = Reusables.getSqlQueryResult("ConfirmationPaymentAdvice", data);
            ConfirmationID = result1.get("ID");
            LogCapture.info("Value of ConfirmationID: " + ConfirmationID);
            Assert.assertFalse(false, String.valueOf(ConfirmationID.contains("null")));
            value = ConfirmationID;
        } else if (operationType.equalsIgnoreCase("Find the MSL_ID for CAMT54")) {
            String ConfirmationID1 = Constants.ConfirmationID;
            key.pause("2", "");
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine54", ConfirmationID1);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, String.valueOf(MSL_ID.contains("null")));
            value = MSL_ID;
        } else if (operationType.equalsIgnoreCase("Find the StatementLineID for Indraday")) {

//            Constants.key.pauseforSchedular();

            Map<String, String> result = Reusables.getSqlQueryResult("MESSAGE_IN", data);
            vIsParsed = result.get("IsParsed");
            vParsedStatus = result.get("parsedStatus");
            LogCapture.info("Value of IsParsed is " + vIsParsed
                    + "\n and Value of parsedStatus is " + vParsedStatus);
            Assert.assertTrue(vIsParsed.equals("1"));
            Assert.assertTrue(vIsParsed.equalsIgnoreCase(vParsedStatus));


            Map<String, String> result1 = Reusables.getSqlQueryResult("IntradayStatement", data);
            IntradayStatement = result1.get("ID");
            LogCapture.info("Value of IntradayStatement: " + IntradayStatement);
            Assert.assertFalse(false, String.valueOf(IntradayStatement.contains("null")));
            Constants.IntradayStatementID = IntradayStatement;

            Map<String, String> result2 = Reusables.getSqlQueryResult("IntradayStatementLine", IntradayStatement);
            IntradayStatementLineID = result2.get("ID");

            value = IntradayStatementLineID;
            LogCapture.info("IntradayStatementLineID is " + IntradayStatementLineID);

        } else if (operationType.equalsIgnoreCase("Find the MSL_ID for Indraday")) {

//            String StatementID1 = IntradayStatementLineID;
            LogCapture.info("IntradayStatementLineID : " + IntradayStatementLineID);
//            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("MasterStatementLine52", IntradayStatementLineID);
            MSL_ID = result.get("ID");
            LogCapture.info("Value of MSL_ID is: " + MSL_ID);
            Assert.assertFalse(false, String.valueOf(MSL_ID.contains("null")));
            value = MSL_ID;

        } else if (operationType.equalsIgnoreCase("Checking Description")) {
//            String Pendingid = Constants.PendingB2BID;
            Map<String, String> result = Reusables.getSqlQueryResult("RFQ_Contract_Detail", data);
            value = result.get("Description");
            LogCapture.info("Description is : " + value);
        } else if (operationType.equalsIgnoreCase("Fetch latest message out BACS file name")) {

            Map<String, String> result = Reusables.getSqlQueryResult("LatestBACSMessageOutFile", "");
            String MessageText = result.get("Message");

            LogCapture.info("Message string is: " + MessageText);
            value = MessageText;

        } else if (operationType.equalsIgnoreCase("Find the CreditAdviceID")) {
//            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("CustomerCreditTransfer", MessageInId);
            String CreditAdviceID = result.get("ID");
            LogCapture.info("Value of Credit Advice ID is: " + CreditAdviceID);
            Assert.assertFalse(false, String.valueOf(CreditAdviceID.contains("null")));

            value = CreditAdviceID;

        } else if (operationType.equalsIgnoreCase("Transaction Reference From Message Out table")) {

            String ID = Constants.StatementLineID;
            LogCapture.info("StatementLineID : " + ID);
            Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("StatementLineIDLegalEntity", ID);
            Legal_Entity = result.get("LegalEntityCode");
            LogCapture.info("Legal Entity : " + Legal_Entity);
            Assert.assertFalse(false, String.valueOf(Legal_Entity.contains("null")));
            value = Legal_Entity;

        } else if (operationType.equalsIgnoreCase("Find the BankPaymentEntriesID")) {
            key.pause("70", "");
//             Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("BankPaymentEntries", data);
            String BankPaymentEntries = result.get("ID");
            LogCapture.info("BankPaymentEntriesID : " + BankPaymentEntries);
            Assert.assertFalse(false, String.valueOf(BankPaymentEntries.contains("null")));
            value = BankPaymentEntries;

        } else if (operationType.equalsIgnoreCase("Find CustomerInstructionID")) {

//             Constants.key.pauseforSchedular();
            key.pause("2", "");
            Map<String, String> result = Reusables.getSqlQueryResult("CustomerInstructionID", data);
            String CustomerInstructionID = result.get("ID");
            LogCapture.info("CustomerInstructionID : " + CustomerInstructionID);
            Assert.assertFalse(false, String.valueOf(CustomerInstructionID.contains("null")));

            value = CustomerInstructionID;

        } else if (operationType.equalsIgnoreCase("Find CustomerPaymentInID")) {

//             Constants.key.pauseforSchedular();
            key.pause("30", "");
            Map<String, String> result1 = Reusables.getSqlQueryResult("CustomerPaymentInID", CustomerInstructionID);
            String CustomerPaymentInID = result1.get("ID");
            LogCapture.info("CustomerPaymentInID : " + CustomerPaymentInID);
            Assert.assertFalse(false, String.valueOf(CustomerPaymentInID.contains("null")));
            value = CustomerPaymentInID;

        } else if (operationType.equalsIgnoreCase("Find InstructionIdReference")) {

////             Constants.key.pauseforSchedular();
            key.pause("60", "");
            Map<String, String> result = Reusables.getSqlQueryResult("InstructionIdReference", data);
            String InstructionIdReference = result.get("ID");
            LogCapture.info("InstructionIdReference : " + InstructionIdReference);
            Assert.assertFalse(false, String.valueOf(InstructionIdReference.contains("null")));
            value = InstructionIdReference;

        } else if (operationType.equalsIgnoreCase("Find CustomerPaymentInID using InstructionIdReference")) {

////             Constants.key.pauseforSchedular();
//             key.pause("30","");
            Map<String, String> result = Reusables.getSqlQueryResult("CustomerPaymentInIDUsingInstructionIdReference", data);
            String CustomerPaymentInID = result.get("ID");
            LogCapture.info("CustomerPaymentInID : " + CustomerPaymentInID);
            Assert.assertFalse(false, String.valueOf(CustomerPaymentInID.contains("null")));
            value = CustomerPaymentInID;

        } else if (operationType.equalsIgnoreCase("VerifyPtTokenID")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_PtTokenID", data);
            value = result.get("ptToken");
            LogCapture.info("PtToken ID is : " + value);

        } else if (operationType.equalsIgnoreCase("VerifyPtTokenWallet")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_PtTokenWallet", data);
            value = result.get("ptWallet");
            LogCapture.info("PtToken Wallet is : " + value);
        } else if (operationType.equalsIgnoreCase("VerifyConsolidatedWalletBalances")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_ConsolidatedWalletBalances", data);
            value = result.get("ConsolidatedWalletBalances");
            LogCapture.info("Consolidated Wallet Balances is : " + value);
        } else if (operationType.equalsIgnoreCase("Find LimitOrderID")) {

//             Constants.key.pauseforSchedular();
//             key.pause("50","");
            Map<String, String> result = Reusables.getSqlQueryResult("LimitOrder", data);
            String ID = result.get("ID");
            LogCapture.info("Limit order ID : " + ID);
            Assert.assertFalse(false, String.valueOf(ID.contains("null")));

            value = ID;

        } else if (operationType.equalsIgnoreCase("Find CustomerPaymentOutID")) {

//             Constants.key.pauseforSchedular();
            key.pause("64", "");
            Map<String, String> result1 = Reusables.getSqlQueryResult("CustomerPaymentOutID", CustomerInstructionID);
            String CustomerPaymentOutID = result1.get("ID");
            Constants.InstructionNumber1 = result1.get("InstructionNumber");
            LogCapture.info("CustomerPaymentOutID : " + CustomerPaymentOutID);
            Assert.assertFalse(false, String.valueOf(CustomerPaymentOutID.contains("null")));
            value = CustomerPaymentOutID;

        } else if (operationType.equalsIgnoreCase("Find achMandateId")) {

//             Constants.key.pauseforSchedular();
            Map<String, String> result = Reusables.getSqlQueryResult("achMandateId", InstructionNumber1);
            String achMandateId = result.get("achMandateId");
            LogCapture.info("achMandateId : " + achMandateId);
            Assert.assertFalse(false, String.valueOf(achMandateId.contains("null")));
            value = achMandateId;


        } else if (operationType.equalsIgnoreCase("GetGBPCSTransactionsAmount")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_GBPCardSpentTxnAmount", data);
            value = result.get("Amount");
            LogCapture.info("Fetched Card Spent Transactions Amount is : " + value);
        } else if (operationType.equalsIgnoreCase("GetGBPCardSpentTxnNumber")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_GBPCardSpentTxnNumber", data);
            value = result.get("NoOfTransaction");
            LogCapture.info("Fetched No Of Transaction is : " + value);
        } else if (operationType.equalsIgnoreCase("GetGBPCardSpentIsSendToSF")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_GBPCardSpentIsSendToSF", data);
            value = result.get("IsSendToSF");
            LogCapture.info("Fetched Is Send to Atlas value is : " + value);
        } else if (operationType.equalsIgnoreCase("GetGBPCardSpentSendToSFOn")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_GBPCardSpentSendToSFOn", data);
            value = result.get("SendToSFOn");
            LogCapture.info("Fetched Card Spent Transactions send to SF on Date : " + value);
        } else if (operationType.equalsIgnoreCase("GeGBPCardSpentUpdatedOn")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_GBPCardSpentUpdatedOn", data);
            value = result.get("UpdatedOn");
            LogCapture.info("Fetched Card Spent Transactions Updated on Date : " + value);

        } else if (operationType.equalsIgnoreCase("Find FundType and StatusEnum")) {

            Map<String, String> result = Reusables.getSqlQueryResult("BankPaymentEntries", external_reference_id);
            Constants.FundType = result.get("FundType");
            Constants.StatusEnum = result.get("StatusEnum");
            LogCapture.info("FundType is : " + FundType + "StatusEnum : " + StatusEnum);
            Assert.assertFalse(false, String.valueOf(FundType.contains("null")));
            value = FundType;

        } else if (operationType.equalsIgnoreCase("Find AccountNumber Details")) {
            query = SQLQUERIES.getProperty("BankDetails1");
            query = query.replace("%s", data);
            System.out.println(query);
            Map<String, String> result = executeQuery(Constants.connectionUrl, Constants.dBUsername, Constants.dbPassword, query);

            Constants.Currency_code = result.get("Currency_code");
            Constants.bank_name = result.get("bank_name");
            Constants.BIC = result.get("BIC");
            Constants.Address = result.get("Address");
            Constants.Name = result.get("Name");
            Constants.org_code = result.get("org_code");
            Constants.legal_entity = result.get("legal_entity");
            Constants.hyperion_bank_account_reference_id = result.get("External_BankAccount_Reference_Id");
            LogCapture.info("Currency_code is : " + Currency_code);
//             Assert.assertFalse(false, String.valueOf(Currency_code.contains("null")));
            value = Currency_code;

        } else if (operationType.equalsIgnoreCase("GetEURCSTransactionsAmount")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_EURCardSpentTxnAmount", data);
            value = result.get("Amount");
            LogCapture.info("Fetched Card Spent Transactions Amount is : " + value);
        } else if (operationType.equalsIgnoreCase("GetEURCardSpentTxnNumber")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_EURCardSpentTxnNumber", data);
            value = result.get("NoOfTransaction");
            LogCapture.info("Fetched No Of Transaction is : " + value);
        } else if (operationType.equalsIgnoreCase("GetEURCardSpentIsSendToSF")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_EURCardSpentIsSendToSF", data);
            value = result.get("IsSendToSF");
            LogCapture.info("Fetched Is Send to Atlas value is : " + value);
        } else if (operationType.equalsIgnoreCase("GetEURCardSpentSendToSFOn")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_EURCardSpentSendToSFOn", data);
            value = result.get("SendToSFOn");
            LogCapture.info("Fetched Card Spent Transactions send to SF on Date : " + value);
        } else if (operationType.equalsIgnoreCase("GeEURCardSpentUpdatedOn")) {
            Map<String, String> result = Reusables.getSqlQueryResult("Fetch_EURCardSpentUpdatedOn", data);
            value = result.get("UpdatedOn");
            LogCapture.info("Fetched Card Spent Transactions Updated on Date : " + value);

        } else if (operationType.equalsIgnoreCase("VerifyStatusOnFXTicket")) {
            Map<String, String> result = Reusables.getSqlQueryResult("FetchStatusOnFXTicket", data);
            value = result.get("StatusEnum");
            LogCapture.info("Fetched Status Enum value for reversal card Transactions : " + value);

        } else if (operationType.equalsIgnoreCase("VerifyStatusOnCustomerInstruction")) {
            Map<String, String> result = Reusables.getSqlQueryResult("FetchStatusOnCustomerInstruction", data);
            value = result.get("StatusEnum");
            LogCapture.info("Fetched Status Enum ID for reversal card Transactions : " + value);

        } else if (operationType.equalsIgnoreCase("VerifyStatusEnum")) {
            Map<String, String> result = Reusables.getSqlQueryResult("FetchStatusEnumvalue", data);
            value = result.get("Status");
            LogCapture.info("Fetched Status Enum value for reversal card Transactions is: " + value);

        } else if (operationType.equalsIgnoreCase("VerifyTotalAmountUnderDOF")) {
            Map<String, String> result = Reusables.getSqlQueryResult("FetchTotalAmountfromDOF", data);
            value = result.get("TotalAmount");
            LogCapture.info("Fetched Total Amount from Destination of Fund table is: " + value);

        } else if (operationType.equalsIgnoreCase("ToGetCustomerInstructionID")) {
            Map<String, String> result = Reusables.getSqlQueryResult("FetchCustomerInstructionID", data);
            value = result.get("ID");
            LogCapture.info("Fetched CustomerInstruction ID is: " + value);

        } else if (operationType.equalsIgnoreCase("CheckNotifyToBankE1")) {
            Map<String, String> result = Reusables.getSqlQueryResult("FetchNotifyTobankE1", data);
            value = result.get("NotificationSentToBank");
            LogCapture.info("Captured value for Notification Sent To Bank for E1 is: " + value);
            if (value.equalsIgnoreCase("") || value.equalsIgnoreCase("null")) {
                LogCapture.info("User verified Notification not sent to bank for E1 type Inter Company >> " + value);
            } else {
                LogCapture.info("TC Failed : User verified Notification sent to bank for E1 type Inter Company >> " + value);
                Assert.fail();
            }

        } else if (operationType.equalsIgnoreCase("CheckNotifyToBankE2")) {
            Map<String, String> result = Reusables.getSqlQueryResult("FetchNotifyTobankE2", data);
            value = result.get("NotificationSentToBank");
            LogCapture.info("Captured value for Notification Sent To Bank for E2 is: " + value);

        } else if (operationType.equalsIgnoreCase("GetExternalReferenceID")) {
            Map<String, String> result = Reusables.getSqlQueryResult("FetchExternalReferenceID", data);
            value = result.get("ExternalReferenceID");
            LogCapture.info("Captured value for External Reference ID for E2 Inter Company is: " + value);

        }
        else if(operationType.equalsIgnoreCase("Connection To Contact Table")){
            Map<String, String> result =   Reusables.getSqlQueryResult("ContactTableConnection", data);
            sqlResult.putAll(result);
            value = result.get("Emailaddress") ;
        }
        return value;
       /* } catch (Exception e) {
            System.out.println("Unable to do operation"+operationType+ "--"+ e.getMessage());
            takeSnapShot();
            return Constants.KEYWORD_FAIL;
        } finally {
            // Close DB connection
            if (connection != null) {
                connection.close();
            }*/
        //}


    }

    // Pricing Enginee Reusables
    public static File RenameCAMTFile(String FileType, String Bank, String AccountNumber) throws Exception {
        DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime now = LocalDateTime.now();
        Constants.nameDate = date.format(now);

        String RandomNumber = RandomStringUtils.randomNumeric(5);
        String number = RandomNumber;

        File camtFile = null;
        File Rename = null;
        File directoryPath = new File("Files/" + Bank + "/");

        String contents[] = directoryPath.list(); //List of all files and directories
        // key.pause("2","");
        LogCapture.info("List of files and directories in the specified directory:" + directoryPath);
        for (int i = 0; i < contents.length; i++) {
            if (contents[i].contains(FileType)) {
                camtFile = new File("Files/" + Bank + "/" + contents[i]);
                LogCapture.info("old file name " + camtFile.getName());
                break;
            }
        }
        if (FileType.contains("camt.")) {
            Rename = new File("Files/" + Bank + "/" + FileType + "001.02.stm_D" + nameDate + "_R667" + number + ".F020002");
        } else if (FileType.contains("pain.002")) {
            Rename = new File("Files/" + Bank + "/" + FileType + "001.03.D" + nameDate + "_R667" + number + ".F020002.SNL35343D23678530057799989S");
        } else {
            LogCapture.info("old Amount is " + oldAmountStarting);

            Constants.oldAmountStarting = camtFile.getName().split("%")[1];

            LogCapture.info("Old Amount was starts with " + oldAmountStarting);
            RandomNumber = String.valueOf(RandomNumber(1000));
            if (newAmount == null) {
                Constants.newAmount = RandomNumber;
            }

            LogCapture.info("New Amount starts with" + newAmount);
            Constants.dateReplace = camtFile.getName().split("%")[2];
            LogCapture.info("Old date was " + dateReplace);
            Constants.OldAccountNumber = camtFile.getName().split("%")[3];
            LogCapture.info("Old Account Number was " + OldAccountNumber);

            if (FileType.contains("BMO")) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMdd");
                Constants.currentDate = dtf.format(now);
                Rename = new File("Files/" + Bank + "/" + FileType + "%" + newAmount + "%" + currentDate + "%58gcnn00ingulkar7k002dar.txt");
            } else if (FileType.contains("JPM")) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                Constants.currentDate = dtf.format(now);
                Rename = new File("Files/" + Bank + "/" + FileType + "%" + newAmount + "%" + currentDate + "%" + AccountNumber + "%45_132_00_01_436.json");
            } else if (FileType.contains("MT940") || FileType.contains("MT942")) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMddMMdd");
                Constants.currentDate = dtf.format(now);
                Rename = new File("Files/" + Bank + "/" + FileType + "%" + newAmount + "%" + currentDate + "%" + AccountNumber + "%45_132_00_01_436.text");
            } else if (FileType.contains("MT103") || FileType.contains("MT103ROF")) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMdd");
                Constants.currentDate = dtf.format(now);
                Rename = new File("Files/" + Bank + "/" + FileType + "%" + newAmount + "%" + currentDate + "%45_132_00_01_436.text");
            }
        }

        camtFile.renameTo(Rename);
        return Rename;
    }

    public static Integer RandomNumber(Integer data) throws Exception {
        Random rand = new Random();
        int value = rand.nextInt(data);
        return value;
    }

    public static void updateXmlFile(String Tag, String NewValue) {

        NodeList NodeList = doc1.getElementsByTagName(Tag); // Document object to find the tag that needs to be updated
        for (int i = 0; i < NodeList.getLength(); i++) {
            Node node = NodeList.item(i);
            node.setTextContent(NewValue);   //  Update the tag with the new value
            LogCapture.info("New value at Tag :" + Tag + " is " + NewValue);
        }

    }

    public static void updateXmlParentChild(String ParentTag, String ChildTag, String NewValue) {

        NodeList parentTags = doc1.getElementsByTagName(ParentTag);

        // Iterate through parent tags
        for (int i = 0; i < parentTags.getLength(); i++) {
            Node parentTag = parentTags.item(i);

            if (parentTag.getNodeType() == Node.ELEMENT_NODE) {
                Element parentElement = (Element) parentTag;

                // Find the child tags by tag name within the parent tag
                NodeList childTags = parentElement.getElementsByTagName(ChildTag);

                // Iterate through child tags
                for (int j = 0; j < childTags.getLength(); j++) {
                    Element childTag = (Element) childTags.item(j);

                    // Update the child tag's value
                    childTag.setTextContent(NewValue);
                }
            }
        }

    }

    public static void pauseforSchedular() throws InterruptedException {
        LocalDateTime now = LocalDateTime.now();
        int seconds = now.getSecond();
        int Actualpause = 77 - seconds;
        if (Actualpause < 20) {

            LogCapture.info("taking pause for 20 sec for processing");
            key.pause("20", "");
        } else {
            LogCapture.info("taking pause for " + Actualpause + " sec for processing");
            key.pause(String.valueOf(Actualpause), "");

//            key.pause("20","");
        }

    }

    public static void loginToKafkaUI() throws Exception {
        LogCapture.info("----------------User enters UserName and Password-------------------");
        String environment = CONFIG.getProperty("Environment");
        String username = Constants.CONFIG.getProperty("KafkaUsername" + environment);
        String password = Constants.CONFIG.getProperty("KafkaPassword" + environment);
        String vObjUser = Constants.KafkaUI.getProperty("Username");
        String vObjPass = Constants.KafkaUI.getProperty("Password");

        Assert.assertTrue(Constants.key.isElementDisplayed(vObjUser, 20), "Kafka Login page is not displayed");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, username));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, password));
        String vObjLoginButton = Constants.KafkaUI.getProperty("SignIn");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    public static JsonPath waitForKafkaMessage(String uniqueIdentifier) throws Exception {

        LogCapture.info("Waiting for Kafka message to populate on UI.....");
        LocalDateTime localDateTime = LocalDateTime.now();
        String kafkaJsonMessage;
        boolean isMessageLineDisplayed = false;

        String messageFieldXpath = Constants.KafkaUI.getProperty("MessageField");
        messageFieldXpath = messageFieldXpath.replace("{uniqueMessageId}", uniqueIdentifier);

        while (!isMessageLineDisplayed && Reusables.getTimeLapsedInSeconds(localDateTime) < 200) {
            isMessageLineDisplayed = Constants.key.isElementDisplayed(messageFieldXpath, 10);
        }

        kafkaJsonMessage = Constants.key.getText(messageFieldXpath, "");
        System.out.println(kafkaJsonMessage);
        Assert.assertTrue(isMessageLineDisplayed, "Message is not found within 3 minutes");
        JsonPath jsonPath = JsonPath.from(kafkaJsonMessage);
        return jsonPath;
    }

    public static String cleanJsonPathValue(String jsonPathValue) {
        try {
            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("(\\[string|double|boolean|int):(.*)(\\])");

            Matcher matcher = pattern.matcher(jsonPathValue);
            if (matcher.find()) {
                return matcher.group(2);
            } else {
                return jsonPathValue;
            }
        } catch (Exception ex) {
            LogCapture.error("Exception occurred cleaning Kafka Message JsonPath " + jsonPathValue);
        }
        return null;
    }

    public boolean isElementDisplayed(String object, int waitInSeconds) {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(waitInSeconds));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            return true;
        } catch (Exception e) {
        }
        return false;
    }

    //------------------------- API Values--------------------------------------------
    public static int getTimeLapsedInSeconds(LocalDateTime localDateTime) {
        return (int) ChronoUnit.SECONDS.between(LocalDateTime.now(), localDateTime);
    }

    public static Map<String, String> getSqlQueryResult(String environment, String data, String operationType) throws Exception {
        String DB_URL = null;
        String DB_USER = null;
        String DB_PASSWORD = null;
        //String value = null;
        Map<String, String> result = new HashMap<>();

        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("SITDB_URL") + ":" + Constants.dbconfig.getProperty("SITDB_PORT") + ";trustServerCertificate=true";
            DB_USER = Constants.dbconfig.getProperty("SITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("UATDB_URL") + ":" + Constants.dbconfig.getProperty("UATDB_PORT") + ";trustServerCertificate=true";
//            + ";integratedSecurity=true;trustServerCertificate=true";
            DB_USER = Constants.dbconfig.getProperty("UATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("UATDB_Password");

        } else if (environment.equalsIgnoreCase("CardsUAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("CardsUAT_URL") + "," + Constants.dbconfig.getProperty("Cards_PORT") + ";integratedSecurity=true;trustServerCertificate=true";
//            DB_USER = Constants.dbconfig.getProperty("CardsUATDB_User");
//            DB_PASSWORD = Constants.dbconfig.getProperty("CardsUATDB_Password");
        } else if (environment.equalsIgnoreCase("SIT_Titan")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanSITDB_URL") + ":" + Constants.dbconfig.getProperty("TitanSITDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanSITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanSITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT_Titan")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanUATDB_URL") + ":" + Constants.dbconfig.getProperty("TitanUATDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanUATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanUATDB_Password");

        }
        Constants.connectionUrl = DB_URL;
        Constants.dBUsername = DB_USER;
        Constants.dbPassword = DB_PASSWORD;

        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        Class.forName(dbClass).newInstance();

        // Get connection to DB
        LogCapture.info("Get connection to DB at " + environment);

        if (operationType.equalsIgnoreCase("Fetch Latest Account Details")) {
            result = Reusables.getSqlQueryResult("Fetch_Latest_CD_PFX_TAN", data);
        } else if (operationType.equalsIgnoreCase("Fetch Latest Contact Details")) {
            result = Reusables.getSqlQueryResult("Fetch_Latest_CD_PFX_Contact", data);
        } else if (operationType.equalsIgnoreCase("Payment In")) {
            result = Reusables.getSqlQueryResult("Fetch_FundsInDATA", data);

        } else if (operationType.equalsIgnoreCase("Find CustomerPaymentInID")) {
            result = Reusables.getSqlQueryResult("Fetch_CustomerPaymentInID", data);

        } else if (operationType.equalsIgnoreCase("Customer Instruction")) {
            String query = SQLQUERIES.getProperty("Fetch_CustomerInstruction3");
            query = query.replace("%s", data);
            System.out.println(query);
            result = executeQuery(Constants.connectionUrl, Constants.dBUsername, Constants.dbPassword, query);

        } else if (operationType.equalsIgnoreCase("Find LimitOrderID")) {
            result = Reusables.getSqlQueryResult("Fetch_LimitOrderID", data);
        } else if (operationType.equalsIgnoreCase("New Payment out")) {
            String query = SQLQUERIES.getProperty("Fetch_PaymentOutEvent2");
            query = query.replace("%s", CustomerInstructionID);
            System.out.println(query);
            result = executeQuery(Constants.connectionUrl, Constants.dBUsername, Constants.dbPassword, query);

        }
        return result;
    }

    private static Map<String, String> getAuditMappings(String mappingFilePath) {
        Properties mappings = ReusableMethod.getProperties(mappingFilePath);
        List<String> actualFieldName = new ArrayList<>(mappings.stringPropertyNames());
        Map<String, String> resultPaths = new HashMap<>();
        for (String path : actualFieldName) {
            String[] splitedPath = path.split("\\.");
            String pathPrefix = splitedPath[0];
            String auditColName = splitedPath[1].toLowerCase();
            if (pathPrefix.equalsIgnoreCase("MessageHeader")) {
                auditColName = "h" + auditColName;
            }
            resultPaths.put(auditColName, mappings.getProperty(path));
        }
        return resultPaths;
    }

    private static Map<String, String> getKafkaMappings(String mappingFilePath) {
        Properties mappings = ReusableMethod.getProperties(mappingFilePath);
        List<String> actualFieldName = new ArrayList<>(mappings.stringPropertyNames());
        Map<String, String> resultPaths = new HashMap<>();
        for (String path : actualFieldName) {
            resultPaths.put(path, mappings.getProperty(path));
        }
        return resultPaths;
    }

    public static void compareJsonAgainstGetTxnMappings(Map<String, String> DBData, JsonPath jsonPathObj, String mappingFilePath, boolean isAudit) {
        Map<String, String> fieldMappings;
        if (isAudit) {
            fieldMappings = getAuditMappings(mappingFilePath);
        } else {
            fieldMappings = getKafkaMappings(mappingFilePath);
        }
        String expectedValue;
//        boolean isCompareDouble = false;

//        Properties mappings = ReusableMethod.getProperties(mappingFilePath);
//        List<String> jsonPathList = new ArrayList<>(mappings.stringPropertyNames());
//        String expectedValue;
        for (String jsonPathStr : fieldMappings.keySet()) {
            String actualValue = jsonPathObj.getString(jsonPathStr);
            actualValue = Objects.isNull(actualValue) || actualValue.equalsIgnoreCase("null") ? "" : actualValue; //remove null pointer E
            actualValue = Reusables.cleanJsonPathValue(actualValue);
            if (actualValue.equals("f")) {
                actualValue = "false";
            } else if (actualValue.equals("t")) {
                actualValue = "true";
            }
            System.out.println("actualValue is " + actualValue);
            //Assert.assertNotNull(actualValue, "Could not parse JsonPath value from the actual Json Message");
            String expectedMappingPropertyValue = fieldMappings.get(jsonPathStr);

            if (expectedMappingPropertyValue.contains("skip")) {
                continue;
            }

            if (expectedMappingPropertyValue.contains("value=")) {
                expectedValue = expectedMappingPropertyValue.split("=")[1];
                System.out.println("expectedValue is " + expectedValue);
            } else if (expectedMappingPropertyValue.contains("compareDouble")) {
                String expectedMappingPropertyVal = expectedMappingPropertyValue.split("=")[1];

                expectedValue = DBData.get(expectedMappingPropertyVal);//ReusableMethod.getXpathValue(DBData, "//" + expectedMappingPropertyVal);
                // If no value in XML, then nothing to check //TODO put this as common to all conditions
                System.out.println("expectedValue is " + expectedValue);
                if (ReusableMethod.isNotNullOrEmpty(expectedValue)) {
                    if (expectedMappingPropertyValue.contains("compareDoubleIgnoreSign")) {
                        ReusableMethod.softAssert.assertEquals(Math.abs(Double.parseDouble(actualValue.trim())), Math.abs(Double.parseDouble(expectedValue)), "Assertion for " + jsonPathStr + " failed");
                    } else {
                        ReusableMethod.softAssert.assertEquals(Double.parseDouble(actualValue.trim()), Double.parseDouble(expectedValue), "Assertion for " + jsonPathStr + " failed");
                    }

                } else {
                    ReusableMethod.softAssert.assertTrue(actualValue.isEmpty(), "No value found for " + expectedMappingPropertyVal);
                }
                continue;
            } else if (expectedMappingPropertyValue.contains("concatenateXpathValues=")) {
                String allXpaths = expectedMappingPropertyValue.split("=")[1];
                String valueFromXML = "";
                // multiple Xpath values
                String[] columnNames = allXpaths.split(" ");
                for (String columnName : columnNames) {
                    valueFromXML = String.join(" ", valueFromXML, DBData.get(columnName));// ReusableMethod.getXpathValue(DBData, "//" + columnName));
                }
                expectedValue = valueFromXML;

            } else if (expectedMappingPropertyValue.contains("method=")) {
                String methodDetails = expectedMappingPropertyValue.split("=")[1];
                String methodName = methodDetails.split("\\|")[0];
                String methodArg = methodDetails.split("\\|")[1];
                String valueFromXML = DBData.get(methodArg);//ReusableMethod.getXpathValue(DBData, "//" + methodArg);

                if (ReusableMethod.isNotNullOrEmpty(valueFromXML)) {
                    try {
                        Class<Reusables> classObj = Reusables.class;
                        Method method = classObj.getDeclaredMethod(methodName, String.class);
                        expectedValue = (String) method.invoke(null, valueFromXML);
                        System.out.println("expectedValue is " + expectedValue);
                    } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }

                } else {
                    ReusableMethod.softAssert.assertTrue(actualValue.isEmpty(), "No value found in XML for " + methodDetails);
                    continue; // If no value in XML, then nothing to check
                }

            } else if (expectedMappingPropertyValue.contains("checkValueContainsKey")) {
                expectedMappingPropertyValue = expectedMappingPropertyValue.split("=")[1];
                expectedValue = DBData.get(expectedMappingPropertyValue);//ReusableMethod.getXpathValue(DBData, "//" + expectedMappingPropertyValue);
                ReusableMethod.softAssert.assertTrue(expectedValue.trim().contains(actualValue.trim()), "Assertion for " + jsonPathStr + " failed");
                continue;

            } else if (expectedMappingPropertyValue.contains("ignoreSpaces")) {
                expectedMappingPropertyValue = expectedMappingPropertyValue.split("=")[1];
                expectedValue = DBData.get(expectedMappingPropertyValue).replaceAll(" ", "");//ReusableMethod.getXpathValue(DBData, "//" + expectedMappingPropertyValue).replaceAll(" ", "");
                actualValue = actualValue.replaceAll(" ", "");
            } else {
                expectedValue = DBData.get(expectedMappingPropertyValue);//ReusableMethod.getXpathValue(DBData, "//" + expectedMappingPropertyValue);
            }

            actualValue = Objects.isNull(actualValue) ? "" : actualValue; //make json field value empty if null
            expectedValue = Objects.isNull(expectedValue) ? "" : expectedValue;
            ReusableMethod.softAssert.assertEquals(actualValue.trim(), expectedValue.trim(), "Assertion for " + jsonPathStr + " failed");
        }
    }

    public static String intToBoolean(String str) {
        String value = "";
        if (str.equals("0")) {
            value = "false";
        } else if (str.equals("1")) {
            value = "true";
        }
        return value;
    }

    public String AcceptCookies() {
        try {
            //If Cookies window exist then accept the cookies and proceed or else skip
            // Waiting for cookies to load hence 10 sec pause is implemented
            String vCookies_Accept = Constants.PFXOR.getProperty("Cookies_Accept");
            if (Constants.key.dynamicvisibleConditionWait(vCookies_Accept, 20).equalsIgnoreCase("Pass")) {
                Assert.assertEquals("PASS", Constants.key.click(vCookies_Accept, ""));
                Constants.key.pause("1", "");
                LogCapture.info("Cookies Accepted");
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogCapture.info("Cookies Not Accepted");
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }

    public String dynamicvisibleConditionWait(String object, int TimeoutSec) throws Exception {
        try {

            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(TimeoutSec));
            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to find...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String RecipientEdit(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath("//span[contains(text(),'" + data + "')]//following::span[contains(text(),'Edit')][1]")).click();
            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String RandomData(String object, String data) throws Exception {
        try {

            // Generate random name
            randomName = "User" + new Random().nextInt(1000);
            // Generate random number
            randomNumber = String.valueOf(new Random().nextInt(100000000));
            // Generate random email
            randomEmail = "user" + randomName + "@mailinator.com";
            // Generate past date
            long millisInDay = 24 * 60 * 60 * 1000;
            long pastMillis = -new Random().nextInt(30) * millisInDay;
            long currentTimeMillis = System.currentTimeMillis();
            long pastDateMillis = currentTimeMillis + pastMillis;
            pastDate = new java.sql.Date(pastDateMillis).toString();

            // Generate future date
            long futureMillis = new Random().nextInt(30) * millisInDay;
            long futureDateMillis = currentTimeMillis + futureMillis;
            futureDate = new java.sql.Date(futureDateMillis).toString();


            List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
            for (WebElement input : inputs) {
                input.clear();
                if (data.equalsIgnoreCase("randomname")) {
                    input.sendKeys(randomName);
                    System.out.println(randomName);
                } else if (data.equalsIgnoreCase("randomnumber")) {
                    input.sendKeys(randomNumber);
                    System.out.println(randomNumber);
                } else if (data.equalsIgnoreCase("randommail")) {
                    input.sendKeys(randomEmail);
                    System.out.println(randomEmail);
                } else if (data.equalsIgnoreCase("randompastdate")) {
                    input.sendKeys(pastDate);
                    System.out.println(pastDate);
                } else if (data.equalsIgnoreCase("randomfuturedate")) {
                    input.sendKeys(futureDate);
                    System.out.println(futureDate);
                }

                break;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String VerifyRandomText(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("actual value->>>>" + actual);
            }
            if (data.equalsIgnoreCase("randomname")) {
                String expected = randomName;
                if (actual.equals(expected)) {
                    takeSnapShot();
                    System.out.println(expected);
                    return KEYWORD_PASS;
                }
            } else if (data.equalsIgnoreCase("randomnumber")) {
                String expected = randomNumber;
                if (actual.equals(expected)) {
                    takeSnapShot();
                    System.out.println(expected);
                    return KEYWORD_PASS;
                }
            } else if (data.equalsIgnoreCase("randomnmail")) {
                String expected = randomEmail;
                if (actual.equals(expected)) {
                    takeSnapShot();
                    System.out.println(expected);
                    return KEYWORD_PASS;
                }
            } else if (data.equalsIgnoreCase("randomfuturedate")) {
                String expected = futureDate;
                if (actual.equals(expected)) {
                    takeSnapShot();
                    System.out.println(expected);
                    return KEYWORD_PASS;
                }
            } else if (data.equalsIgnoreCase("pastDate")) {
                String expected = futureDate;
                if (actual.equals(expected)) {
                    takeSnapShot();
                    System.out.println(expected);
                    return KEYWORD_PASS;
                }
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified not same" + actual + "  ";
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String mailinatoremailclick(String email, String Title, String Message) throws Exception {
        try {
            String vObjEmailInbox = "//input[@id='inbox_field']";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
            //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
            String vObjSearchButton = "//button[@class='primary-btn']";
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
            LogCapture.info("User enter emailAddress and click on search");
            Constants.key.pause("5", "");
//            String vObjFirestMail = "//td[contains(text(),'" + Title + "')]";

            String vObjFirestMail = "//td[text()[normalize-space() = '" + Title + "']]";
//            String vObjSecondMail = "(//td[contains(text(),'" + Title + "')])[2]";
//            Assert.assertEquals("PASS", Constants.key.notexist(vObjSecondMail,""));
            Constants.key.pause("10", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
            String vObjFrame = "//iframe[@id='html_msg_body']";
            Constants.key.frame(vObjFrame, "");
            JavascriptExecutor js = (JavascriptExecutor) driver;

            // Scroll down the page by pixel
            js.executeScript("window.scrollBy(0,1000)");
            String vObjMail = "//*[text()='" + Message + " ']";
            Constants.key.pause("5", "");
            String vObjReviwe = "//span[normalize-space()='" + Message + "']";
            Constants.key.scrollIntoViewElement(vObjReviwe, "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));
            // Switch to the new window
            String mainWindowHandle = driver.getWindowHandle();
            for (String windowHandle : driver.getWindowHandles()) {
                if (!windowHandle.equals(mainWindowHandle)) {
                    driver.switchTo().window(windowHandle);
                    break;
                }
            }


            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String Sign(String object, String objectsignck) throws Exception {
        try {
            String vObjSigne = Constants.key.notexist(objectsignck, "");
            Constants.key.pause("3", "");
            if (vObjSigne.equalsIgnoreCase("PASS")) {
                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(object, ""));
                Constants.key.pause("5", "");
//                Constants.key.pause("8", "");
                if (!objectsignck.equalsIgnoreCase("PASS")) {
                    WebElement popupButton = driver.findElement(By.xpath("//button[normalize-space()='Adopt and Sign']"));
                    popupButton.click();
                }
            }

            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String MultipleInput(String object, String data) throws Exception {
        try {

            List<WebElement> inputFields = driver.findElements(By.xpath(object));

            // Fill each input field with the value "100"
            for (WebElement inputField : inputFields) {
                inputField.clear();
                inputField.sendKeys(data);
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String Date(String object, String data) throws Exception {
        try {
            LocalDate today = LocalDate.now();

            // Define the date format
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

            // Format today's date as dd/MM/yyyy
            String formattedToday = today.format(formatter);
            // Get the date 2 days ago
            LocalDate twoDaysAgo = today.minusDays(2);
            String formattedTwoDaysAgo = twoDaysAgo.format(formatter);

            // Get the date 2 days from now
            LocalDate twoDaysLater = today.plusDays(2);
            String formattedTwoDaysLater = twoDaysLater.format(formatter);

            List<WebElement> inputFields = driver.findElements(By.xpath(object));

            // Fill each input field with the value "100"
            for (WebElement inputField : inputFields) {

                if (data.equalsIgnoreCase("future")) {
                    inputField.clear();
                    inputField.sendKeys(formattedTwoDaysLater);
                } else if (data.equalsIgnoreCase("present")) {
                    inputField.clear();
                    inputField.sendKeys(formattedToday);
                } else if (data.equalsIgnoreCase("past")) {
                    inputField.clear();
                    inputField.sendKeys(formattedTwoDaysAgo);
                }
            }
//            Constants.driver.findElement(By.xpath(object)).sendKeys(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String SpecificInput(String object, String data) throws Exception {
        try {
            Constants.driver.findElement(By.xpath(object)).clear();
            Constants.driver.findElement(By.xpath(object)).sendKeys(data);
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }


    public String backtowindowurl(String url) throws Exception {
        try {
            String mainWindowHandle = driver.getWindowHandle();

            // Perform actions that open new windows

            // Get all window handles
            Set<String> allWindowHandles = driver.getWindowHandles();

            // Iterate through all window handles
            for (String windowHandle : allWindowHandles) {
                // Switch to the window
                driver.switchTo().window(windowHandle);

                // Get the URL of the current window
                String currentUrl = driver.getCurrentUrl();

                // Check if the URL contains "https://www.mailinator.com/"
                if (currentUrl.contains(url)) {
                    // Perform actions in the window where URL contains "https://www.mailinator.com/"
                    // For example, print the URL
                    System.out.println("URL of Mailinator window: " + currentUrl);

                    // Switch back to the main window
//                    driver.switchTo().window(mainWindowHandle);
                    break;
                }
            }

            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

//    private static String extractTextFromPDF(File file) {
//        try {
//            PDDocument document = PDDocument.load(file);
//            PDFTextStripper pdfStripper = new PDFTextStripper();
//            String text = pdfStripper.getText(document);
//            document.close();
//            return text;
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }

//    public String ExtractPdf(String object, String data) throws Exception {
//        try {
//            // Open the PDF file
//            // Get the PDF file as a File object
//            File pdfFile = new File("C:/NOT/Downloads/payment_confirmation.pdf");
//
//            // Extract text from the PDF
//            String text = extractTextFromPDF(pdfFile);
//
//            // Save the extracted text to a text file in the specified folder
//            saveTextToFile(text, "C:/NOT/Downloads/extracted_text.txt");
//        } catch (Exception e) {
//            takeSnapShot();
//            return KEYWORD_FAIL + "file not found...." + e.getMessage();
//        }
//        return KEYWORD_PASS;
//    }

    private static void saveTextToFile(String text, String filePath) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
            writer.write(text);
            writer.close();
            System.out.println("Text saved to file: " + filePath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String Paidmailinatorlogin() throws Exception {
        try {
            driver.get("https://www.mailinator.com/v4/login.jsp");

            // Find the username and password fields and input the credentials
            WebElement usernameField = driver.findElement(By.xpath("//input[@id='many_login_email']"));
            WebElement passwordField = driver.findElement(By.xpath("//input[@id='many_login_password']"));

            // Input username and password
            usernameField.sendKeys("shailendra.pal@redpincompany.com");
            passwordField.sendKeys("Password@12");

            // Find and click the login button
            WebElement loginButton = driver.findElement(By.xpath("//a[@aria-label='Login link']"));
            loginButton.click();
            Constants.key.pause("2", "");

//            driver.get("https://www.mailinator.com/");
            Constants.key.pause("3", "");
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String GetListOfText(String object, String data) throws Exception {
        try {
            // Find the elements by the locator
            List<WebElement> elements = driver.findElements(By.xpath(object));

            // Get the text of each element and concatenate them into a single string separated by commas
            concatenatedText = elements.stream()
                    .map(WebElement::getText)
                    .collect(Collectors.joining(","));
            // Print the concatenated text
            System.out.println("Concatenated Text: " + concatenatedText);

            // Print the concatenated text
            System.out.println("Concatenated Text: " + concatenatedText);

            takeSnapShot();

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String VerifyListOfText(String object, String data) throws Exception {
        try {
            String data2 = concatenatedText;
            // Find the elements by the locator
            // Check if each text is present on the webpage
            // Check if the concatenated text is present on the second webpage
            List<String> individualTexts = Arrays.asList(concatenatedText.split(","));
            for (String text : individualTexts) {
                // Check if the text is present on the second webpage
                if (driver.getPageSource().contains(text)) {
                    System.out.println("Text \"" + text + "\" is present on the Second Website.");
                    return KEYWORD_PASS;
                } else {
                    System.out.println("Text \"" + text + "\" is not present on the Second Website.");
                    return KEYWORD_FAIL + "Not able to click....";
                }
            }


        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Not able to click...." + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public String langDetection(String object, String data) throws Exception {
        try {
            DetectorFactory.loadProfile("path_to_profiles");

            // Extracting text from the webpage
            List<WebElement> elements = driver.findElements(By.xpath(object)); // Exclude script tags
            StringBuilder textBuilder = new StringBuilder();
            for (WebElement element : elements) {
                textBuilder.append(element.getText()).append("\n");
            }
            String text = textBuilder.toString();

            // Detect language of the text
            Detector detector = DetectorFactory.create();
            detector.append(text);
            String detectedLanguage = detector.detect();

            // Print detected language
            System.out.println("Detected Language: " + detectedLanguage);
            if (detectedLanguage.equals(data)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  ";
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }


    public String VerifyMultipleText(String object, String data) throws Exception {
        try {
            String exampleString = "apple,banana,orange,grape";
            String[] fruits = exampleString.split(",");

            // Get the size of the array
            int sizeobj = fruits.length;
            By locator = By.xpath(object);

            // Find the list of elements using the locator
            List<WebElement> elements = driver.findElements(locator);

            // Get the size of the list
            int size = elements.size();

            // Loop through the elements
            for (int i = 0; i < size; i++) {
                // Get the i-th element from the list
                WebElement element = elements.get(i);

                // Get the text of the element
                String text = element.getText();

                // Print the locator and text
                System.out.println("Fruit " + (i + 1) + ": " + fruits[i]);
                System.out.println("Locator: " + locator + ", Text: " + text);
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public static void quitAllBrowsers(WebDriver driver) {
        // Get all window handles
        Set<String> windowHandles = driver.getWindowHandles();

        // Close each browser window
        for (String windowHandle : windowHandles) {
            driver.switchTo().window(windowHandle);
            driver.close();
        }
    }

    public static String getEmail(String emailAddress, String EmailTask) throws IOException, InterruptedException {

        parseEmailAddress(emailAddress);

        JsonPath emailContent = getFirstEmail(MAILINATOR_API_URL);
        assert emailContent != null;

        switch (EmailTask.toLowerCase()) {
            case "subject":
                return getEmailSubject(emailContent);

            case "links":
                return getEmailLinks();

            case "downloadattachment":
                return processAttachments();

            case "body":
                return getEmailBody(emailContent);

            case "from":
                return getEmailFrom(emailContent);

            case "date":
                return getEmailDate(emailContent);

            case "ReplyTo":
                return getEmailReplyTo(emailContent);

            case "Time":
                return getEmailTime(emailContent);

            case "attachmentsname":
                return processAttachmentsName();

            default:
                return "Data type not recognized.";
        }
    }

    /**
     * @CreatedBy: Shailendra Pal
     * @Description: This method retrieves the latest email in the provided email inbox for a specified subject.
     * @ExpectedInput: String emailAddress: The email address from which to fetch the email with the specified subject.
     * String EmailTask: The task to be performed on the email, such as fetching the subject, links, attachments, etc.
     * String Subject: The subject of the email to be fetched.
     * @ExpectedOutput: The method returns the requested email details based on the specified task. The output could include the subject, links, attachments, body content, sender information, date, reply-to address, time, or attachment names.
     */
    public static String getEmailUsingSubject(String emailAddress, String EmailTask, String Subject) throws IOException, InterruptedException {

        parseEmailAddress(emailAddress);

        JsonPath emailContent = getEmailUsingSubject(MAILINATOR_API_URL, Subject);
        assert emailContent != null;

        switch (EmailTask.toLowerCase()) {
            case "subject":
                return getEmailSubject(emailContent);

            case "links":
                return getEmailLinks();

            case "downloadattachment":
                return processAttachments();

            case "body":
                return getEmailBody(emailContent);

            case "from":
                return getEmailFrom(emailContent);

            case "date":
                return getEmailDate(emailContent);

            case "ReplyTo":
                return getEmailReplyTo(emailContent);

            case "Time":
                return getEmailTime(emailContent);

            case "attachmentsname":
                return processAttachmentsName();

            default:
                return "Data type not recognized.";
        }
    }

    private static void parseEmailAddress(String emailAddress) {
        int atIndex = emailAddress.indexOf('@');
        if (atIndex != -1) {
            EMAIL_NAME = emailAddress.substring(0, atIndex).trim();
            DOMAIN_NAME = emailAddress.substring(atIndex + 1).trim();
            MAILINATOR_API_URL = "https://api.mailinator.com/api/v2/domains/" + DOMAIN_NAME + "/inboxes/" + EMAIL_NAME;
        } else {
            LogCapture.info("Invalid email format. No @ character found.");
        }
    }

    private static String getEmailSubject(JsonPath emailContent) {
        return emailContent.getString("subject");
    }

    private static String getEmailDate(JsonPath emailContent) {
        String vDate = emailContent.getString("headers.date");
        LogCapture.info("Email received on date ===== " + vDate);
        return vDate;
    }

    private static String getEmailReplyTo(JsonPath emailContent) {
        String vReplyTo = emailContent.getString("headers.reply-to");
        LogCapture.info("Reply In Email ===== " + vReplyTo);
        return vReplyTo;
    }

    private static String getEmailTime(JsonPath emailContent) {
        String vTime = emailContent.getString("time");
        LogCapture.info("Email received Time ===== " + vTime);
        return vTime;
    }

    private static String getEmailLinks() throws IOException {
        String reqLink = MAILINATOR_API_URL + "/messages/" + MSG_ID + "/links";
        LogCapture.info("Links available in email are ===== " + reqLink);
        JsonPath jp = makeApiRequest(reqLink);
        String links = jp.getString("links");
        LogCapture.info("Links available in email are ===== " + links);
        return links;
    }

    private static String processAttachments() throws IOException, InterruptedException {
        String attachmentDetails = MAILINATOR_API_URL + "/messages/" + MSG_ID + "/attachments";
        JsonPath jp = makeApiRequest(attachmentDetails);
        int j = jp.getInt("attachments.size()");
        if (j == 0) {
            return "No Attachment Found in Email";
        }

        for (int i = 0; i < j; i++) {
            String attachmentName = jp.getString("attachments.filename[" + i + "]").replaceAll("\\[", "").replaceAll("]", "");
            String attachment = MAILINATOR_API_URL + "/messages/" + MSG_ID + "/attachments/" + attachmentName;
            downloadAttachment(attachment, attachmentName);
        }
        return "File Downloaded Successfully";
    }

    private static String processAttachmentsName() throws IOException, InterruptedException {
        String[] attachmentNames = new String[0];
        String attachmentDetails = MAILINATOR_API_URL + "/messages/" + MSG_ID + "/attachments";
        JsonPath jp = makeApiRequest(attachmentDetails);
        int j = jp.getInt("attachments.size()");
        if (j == 0) {
            return "No Attachment Found in Email";
        }
        for (int i = 0; i < j; i++) {
            String vattachmentName = jp.getString("attachments.filename[" + i + "]").replaceAll("\\[", "").replaceAll("]", "");
            attachmentNames = Arrays.copyOf(attachmentNames, attachmentNames.length + 1);
            attachmentNames[attachmentNames.length - 1] = vattachmentName;
        }
        //LogCapture.info("Attachment Name is  ----------> " + Arrays.toString(attachmentNames));
        return Arrays.toString(attachmentNames);
    }

    private static String getEmailBody(JsonPath emailContent) {
        String body = emailContent.getString("parts.body");
        Document document = Jsoup.parse(body);
        String bodyContent = document.text();
        LogCapture.info("Email Body Content ----------> " + bodyContent);
        return bodyContent;
    }

    private static String getEmailFrom(JsonPath emailContent) {
        String vFrom = emailContent.getString("fromfull");
        LogCapture.info("Email received from Email ID ----------> " + vFrom);
        return vFrom;
    }

    private static JsonPath getFirstEmail(String urlString) throws IOException {
        JsonPath jsonPath = makeApiRequest(urlString);
        MSG_ID = jsonPath.getString("msgs[0].id");
        if (Objects.nonNull(MSG_ID) && !MSG_ID.isEmpty()) {
            String firstEmail = MAILINATOR_API_URL + "/messages/" + MSG_ID;
            JsonPath res = makeApiRequest(firstEmail);
            LogCapture.info("Fetched Email is ===== " + res.getString("subject"));
            return res;
        } else {
            LogCapture.info("Error fetching MSG_ID. Ensure you have at least one email in your inbox | Please check your Email ID : 002 " + MSG_ID);
            return null;
        }
    }

    private static JsonPath getEmailUsingSubject(String urlString, String vSubject) throws IOException, InterruptedException {
        LogCapture.info("Looking for latest email with subject as \" " + vSubject + " \" " + "........................");
        for (int i = 0; i <= 12; i++) {
            Constants.key.pause("5", "");
            JsonPath jsonPath = makeApiRequest(urlString);
            int j = jsonPath.getInt("msgs.size()");
            for (int k = 0; k < j; k++) {
                String subject = jsonPath.getString("msgs[" + k + "].subject");
                int vTime = jsonPath.getInt("msgs[" + k + "].seconds_ago");
                if ((subject.contains(vSubject)) && vTime <=4000) {
                    //10800  5400
                    MSG_ID = jsonPath.getString("msgs[" + k + "].id");
                    break;
                }
            }
            if (Objects.nonNull(MSG_ID) && !MSG_ID.isEmpty()) {
                String firstEmail = MAILINATOR_API_URL + "/messages/" + MSG_ID;
                JsonPath res = makeApiRequest(firstEmail);
                //LogCapture.info("Fetched Email is ----------> " + res.getString("subject"));
                return res;
            } else {
                LogCapture.info("Trying for " + i + "/18 time in a interval of 5 secs");
            }
        }
        LogCapture.info("No Latest Email Fetched with Subject as " + vSubject + " Tried waiting for 60 Secs.");
        return null;
    }

    private static JsonPath makeApiRequest(String urlString) throws IOException {
        String responseBody = null;
        try {
            Response response = RestAssured.given().relaxedHTTPSValidation().log().all()
                    .header("Authorization", MAILINATOR_API_TOKEN)
                    .header("Accept", "*/*")
                    .get(urlString);

            if (response.getStatusCode() != 200) {
                LogCapture.info("Something Went Wrong While Fetching Email Error in makeApiRequest 001 : " + response.getBody().asString());
            }
            responseBody = response.getBody().asString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new JsonPath(responseBody);
    }

    private static void downloadAttachment(String urlString, String attachmentName) throws IOException, InterruptedException {
        Path emailDownloadDirectoryPath = Paths.get(EMAIL_DOWNLOAD_DIRECTORY);

        if (!Files.exists(emailDownloadDirectoryPath)) {
            Files.createDirectories(emailDownloadDirectoryPath);
        } else {
            FileUtils.cleanDirectory(emailDownloadDirectoryPath.toFile());
        }

        String saveFilePath = EMAIL_DOWNLOAD_DIRECTORY + File.separator + attachmentName;

        Response response = RestAssured.given().relaxedHTTPSValidation()
                .urlEncodingEnabled(false)
                .header("Authorization", MAILINATOR_API_TOKEN)
                .header("Content-Type", "application/octet-stream")
                .get(urlString);

        if (response.getStatusCode() != 200) {
            LogCapture.info("Something Went Wrong While Fetching Email Error in makeApiRequest 001 : " + response.getBody().asString());
        }

        try (InputStream inputStream = response.getBody().asInputStream();
             FileOutputStream outputStream = new FileOutputStream(saveFilePath)) {

            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }

        try {
            File[] listOfFiles = emailDownloadDirectoryPath.toFile().listFiles();
            if (Objects.nonNull(listOfFiles) && listOfFiles.length > 0) {
                String downloadedFileName = listOfFiles[0].getName();
                LogCapture.info(downloadedFileName + " File Downloaded Successfully in directory " + EMAIL_DOWNLOAD_DIRECTORY);
            } else {
                LogCapture.info("No File Detected in Email");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void modifyFile(String filePath, String oldString, String newString) {
        File fileToBeModified = new File(filePath);
        String oldContent = "";
        BufferedReader reader = null;
        FileWriter writer = null;
        try {
            reader = new BufferedReader(new FileReader(fileToBeModified));
            String line = reader.readLine();
            while (line != null) {
                oldContent = oldContent + line + System.lineSeparator();
                line = reader.readLine();
            }
            String newContent = oldContent.replaceAll(oldString, newString);
            if (filePath.contains("MT")) {
                Constants.messageInQuery = newContent;
            }
            writer = new FileWriter(fileToBeModified);
            writer.write(newContent);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public String verifyTextAdv(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
            }
            String expected = data;
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }


    public String plivodataotp2(String object, String data) throws Exception {
        String jdbcUrl = "jdbc:mysql://193.203.166.126:3306/u790911426_TestPlivo";
        String username = "u790911426_TestPlivo"; // Replace with your MySQL username
        String password = "Farukh007@"; // Replace with your MySQL password
        String tableName = "smsinbox"; // Replace with your table name

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create statement
            statement = connection.createStatement();

            // Execute query to retrieve all data from the table
            resultSet = statement.executeQuery("SELECT * FROM " + tableName);

            // Print and process data, then delete row if condition met
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                // Print the current row
                for (int i = 1; i <= columnCount; i++) {
                    System.out.print(resultSet.getString(i) + "\t");
                }
                System.out.println();

                // Check if the text column contains the keyword "Amazon"
                String textColumn = resultSet.getString("text"); // Replace "text" with the actual column name
                if (textColumn.contains("Amazon")) {
                    int id = resultSet.getInt("id"); // Replace "id" with the actual primary key column name

                    // Delete the row
                    String deleteSQL = "DELETE FROM " + tableName + " WHERE id = " + id;
                    statement.executeUpdate(deleteSQL);
                    System.out.println("Deleted row with ID: " + id);
                    break; // Exit loop after deleting the first row with keyword "Amazon"
                }
            }
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database.");
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return jdbcUrl;
    }

    public String plivodataotp3(String object, String data) throws Exception {
        String jdbcUrl = "jdbc:mysql://193.203.166.126:3306/u790911426_TestPlivo";
        String username = "u790911426_TestPlivo"; // Replace with your MySQL username
        String password = "Farukh007@"; // Replace with your MySQL password
        String tableName = "smsinbox"; // Replace with your table name

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        StringBuilder outputStringBuilder = new StringBuilder();

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create statement
            statement = connection.createStatement();

            // Execute query to retrieve all data from the table
            resultSet = statement.executeQuery("SELECT * FROM " + tableName);

            // Process data, then delete row if condition met
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                // Accumulate the current row data into the StringBuilder
                for (int i = 1; i <= columnCount; i++) {
                    outputStringBuilder.append(resultSet.getString(i)).append("\t");
                }
                outputStringBuilder.append("\n");

                // Check if the text column contains the keyword "Amazon"
                String textColumn = resultSet.getString("text"); // Replace "text" with the actual column name
                if (textColumn.contains("Amazon")) {
                    int id = resultSet.getInt("id"); // Replace "id" with the actual primary key column name

                    // Delete the row
                    String deleteSQL = "DELETE FROM " + tableName + " WHERE id = " + id;
                    statement.executeUpdate(deleteSQL);
                    outputStringBuilder.append("Deleted row with ID: ").append(id).append("\n");
                    break; // Exit loop after deleting the first row with keyword "Amazon"
                }
            }
        } catch (ClassNotFoundException e) {
            outputStringBuilder.append("MySQL JDBC Driver not found.\n");
            e.printStackTrace();
        } catch (SQLException e) {
            outputStringBuilder.append("Failed to connect to the database.\n");
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return outputStringBuilder.toString();
    }


    public String plivodataotpfinal(String object, String data) throws Exception {
//        String jdbcUrl = "jdbc:mysql://193.203.166.126:3306/u790911426_TestPlivo";
        String jdbcUrl = "jdbc:mysql://193.203.166.126:3306/" + object;
        String username = "u790911426_TestPlivo"; // Replace with your MySQL username
        String password = "Farukh007@"; // Replace with your MySQL password
        String tableName = "smsinbox"; // Replace with your table name

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        StringBuilder outputStringBuilder = new StringBuilder();

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create statement
            statement = connection.createStatement();

            // Execute query to retrieve all data from the table
            resultSet = statement.executeQuery("SELECT * FROM " + tableName);

            // Process data, then delete row if condition met
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                // Print the current row data
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String columnValue = resultSet.getString(i);
                    System.out.println(columnName + ": " + columnValue);
                    if (columnName.equalsIgnoreCase("phone")) {
                        phone = columnValue;
                    } else if (columnName.equalsIgnoreCase("text")) {
                        Message = columnValue;
                    } else if (columnName.equalsIgnoreCase("date")) {
                        MsgDate = columnValue;
                    }
                }

                // Check if the text column contains the keyword "DocuSign"
                String textColumn = resultSet.getString("text"); // Replace "text" with the actual column name
                if (textColumn.contains(data)) {
                    int id = resultSet.getInt("id"); // Replace "id" with the actual primary key column name

                    // Delete the row
                    String deleteSQL = "DELETE FROM " + tableName + " WHERE id = " + id;
                    statement.executeUpdate(deleteSQL);
                    outputStringBuilder.append("Deleted row with ID: ").append(id).append("\n");
                    break; // Exit loop after deleting the first row with keyword "Amazon"
                }
            }
        } catch (ClassNotFoundException e) {
            outputStringBuilder.append("MySQL JDBC Driver not found.\n");
            e.printStackTrace();
        } catch (SQLException e) {
            outputStringBuilder.append("Failed to connect to the database.\n");
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return outputStringBuilder.toString();
    }

    public String plivodataotp(String object, String data) throws Exception {
        String jdbcUrl = "jdbc:mysql://193.203.166.126:3306/u790911426_TestPlivo";
//        String jdbcUrl = "jdbc:mysql://193.203.166.126:3306/"+object;
        String username = "u790911426_TestPlivo"; // Replace with your MySQL username
        String password = "Farukh007@"; // Replace with your MySQL password
        String tableName = "smsinbox"; // Replace with your table name

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        StringBuilder outputStringBuilder = new StringBuilder();

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create statement
            statement = connection.createStatement();

            // Execute query to retrieve all data from the table
            resultSet = statement.executeQuery("SELECT * FROM " + tableName);

            // Process data, then delete row if condition met
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                // Print the current row data
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String columnValue = resultSet.getString(i);
                    System.out.println(columnName + ": " + columnValue);
                    if (columnName.equalsIgnoreCase("phone")) {
                        phone = columnValue;
                    } else if (columnName.equalsIgnoreCase("text")) {
                        Message = columnValue;
                    } else if (columnName.equalsIgnoreCase("date")) {
                        MsgDate = columnValue;
                    }
                }

                // Check if the text column contains the keyword "Amazon"
                String textColumn = resultSet.getString("text"); // Replace "text" with the actual column name
                if (textColumn.contains(data)) {
                    int id = resultSet.getInt("id"); // Replace "id" with the actual primary key column name

//                    // Delete the row
//                    String deleteSQL = "DELETE FROM " + tableName + " WHERE id = " + id;
//                    statement.executeUpdate(deleteSQL);
//                    outputStringBuilder.append("Deleted row with ID: ").append(id).append("\n");
                    break; // Exit loop after deleting the first row with keyword "Amazon"
                }
            }
        } catch (ClassNotFoundException e) {
            outputStringBuilder.append("MySQL JDBC Driver not found.\n");
            e.printStackTrace();
        } catch (SQLException e) {
            outputStringBuilder.append("Failed to connect to the database.\n");
            e.printStackTrace();
        }
        return outputStringBuilder.toString();
    }


    public String Send_OTP2(String object, String data) throws Exception {
        try {
//            plivodataotp(String object, String data)
            String database = "u790911426_TestPlivo";
            Constants.key.plivodataotp(database, data);

            List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
            for (WebElement input : inputs) {
                String OTPMessage = Message;
                // Extract only integers from the string
                String integersOnly = data.replaceAll("[^0-9]", "");

                // Print the result
                System.out.println("Extracted integers: " + integersOnly);
                input.clear();
                input.sendKeys(integersOnly);
                break;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String Send_OTP(String object, String data) throws Exception {
        String jdbcUrl = "jdbc:mysql://193.203.166.126:3306/u790911426_TestPlivo";
        String username = "u790911426_TestPlivo";
        String password = "Farukh007@";
        String tableName = "smsinbox";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM " + tableName + " ORDER BY date DESC")) {

                while (resultSet.next()) {

                    int id = resultSet.getInt("id"); // Assuming there is a unique id column in your table

                    for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
                        String columnName = resultSet.getMetaData().getColumnName(i);
                        String columnValue = resultSet.getString(i);
                        System.out.println(columnName + ": " + columnValue);

                        if (columnName.equalsIgnoreCase("phone")) {
                            phone = columnValue;
                        } else if (columnName.equalsIgnoreCase("text")) {
                            Message = columnValue;
                        } else if (columnName.equalsIgnoreCase("date")) {
                            MsgDate = columnValue;
                        }
                    }

                    String textColumn = resultSet.getString("text");
                    if (textColumn.contains(data)) {
                        String integersOnly = Message.replaceAll("[^0-9]", "");
                        System.out.println("Extracted integers: " + integersOnly);
                        List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
                        for (WebElement input : inputs) {
                            input.clear();
                            input.sendKeys(integersOnly);
                        }

                        // Delete the row after processing
//                        try (PreparedStatement deleteStatement = connection.prepareStatement("DELETE FROM " + tableName + " WHERE id = ?")) {
//                            deleteStatement.setInt(1, id);
//                            deleteStatement.executeUpdate();
//                        }
                        try (PreparedStatement deleteStatement = connection.prepareStatement("DELETE FROM " + tableName + " WHERE id IS NOT NULL")) {
                            deleteStatement.executeUpdate();
                        }

                        break; // Exit loop after sending OTP and deleting the row
                    }
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public String Send_OTP3(String object, String data) throws Exception {
        String jdbcUrl = "jdbc:mysql://193.203.166.126:3306/u790911426_TestPlivo";
        String username = "u790911426_TestPlivo";
        String password = "Farukh007@";
        String tableName = "smsinbox";
//        String phone = ""; // Initialize variables for phone, message, and message date
//        String Message = "";
//        String MsgDate = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM " + tableName)) {

                while (resultSet.next()) {
                    // Process each row
                    for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
                        String columnName = resultSet.getMetaData().getColumnName(i);
                        String columnValue = resultSet.getString(i);
                        System.out.println(columnName + ": " + columnValue);

                        if (columnName.equalsIgnoreCase("phone")) {
                            phone = columnValue;
                        } else if (columnName.equalsIgnoreCase("text")) {
                            Message = columnValue;
                        } else if (columnName.equalsIgnoreCase("date")) {
                            MsgDate = columnValue;
                        }
                    }


                    String MessageOTP = Message;
                    String textColumn = resultSet.getString("text");
                    if (textColumn.contains(data)) {
                        // Send OTP based on conditions
                        String integersOnly = MessageOTP.replaceAll("[^0-9]", "");
                        System.out.println("Extracted integers: " + integersOnly);
                        List<WebElement> inputs = Constants.driver.findElements(By.xpath(object));
                        for (WebElement input : inputs) {
                            input.clear();
                            input.sendKeys(integersOnly);
                        }
                        break; // Exit loop after sending OTP
                    }
                }
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL;
        }
        return KEYWORD_PASS;
    }


    public static String navigateotpurl(String object, String data) throws Exception {
        try {
            Constants.driver.navigate().to(data);

//            String vObjCont = "//button[@id='action-bar-btn-continue']";
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
            Constants.key.pause("2", "");
//            String vObjCont2 = "//div[@class='u-text-strong' and text()='Text Message']";
            String vObjCont2 = "//button[@class='olv-button olv-ignore-transform css-69ih2c']";
            //
            Constants.key.pause("7", "");
//            String OTPexist = Constants.key.VisibleConditionWait(vObjCont2, "");
            //https://verify-d.docusign.net/App/Callback
            //   https://verify-d.docusign.net/ChooseMethod
            // Get the URL of the current page
            String currentUrl = driver.getCurrentUrl();

            // Print the URL to the console
            System.out.println("Current URL: " + currentUrl);

            if (currentUrl.equalsIgnoreCase("https://verify-d.docusign.net/App/Callback") || currentUrl.equalsIgnoreCase("https://verify-d.docusign.net/ChooseMethod")) {
                Constants.key.Mouse_Events(vObjCont2, "");
                Constants.key.pause("2", "");
                Constants.key.navigateSubMenu(vObjCont2, "");
                Constants.key.pause("3", "");
//            Constants.key.Twilio_OTP("", "modifiedUrl");
                String object1 = "//input[@data-focus='verify-confirm-code-verification-code-input']";
//                String object1 = "//input[@data-qa='one-time-code-text-box']";
//                String object2 = "//button[@data-qa='sticky-button-primary']";
                String object2 = "//button[@data-qa='verify-confirm-code-primary-button']";
                //
//            Constants.key.receivesmss_OTP(object1, object2,"19174195208");
//            Constants.key.receivesmssApi_OTP(object1, object2,"19174195208");
//            Constants.key.NexmoSmsReceiver(object1, object2,"19174195208");
                Constants.key.Send_OTP(object1, "DocuSign");
                Constants.key.pause("2", "");
                Constants.key.Mouse_Events(object2, "");
                Constants.key.pause("8", "");
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "...not able to navigate";

        }
        return KEYWORD_PASS;
    }

    public String plivodataotpnew(String object, String data) throws Exception {
        try {
            // JDBC URL, username, and password
            String url = "jdbc:mysql://auth-db1284.hstgr.io:3306/u790911426_TestPlivo";
            String username = "u790911426_TestPlivo";
            String password = "Farukh007@";

            // SQL query to retrieve data ordered by created_at in ascending order
            String selectQuery = "SELECT * FROM smsinbox ORDER BY created_at ASC";
            // SQL query to delete a row by id
            String deleteQuery = "DELETE FROM smsinbox WHERE id = ?";

            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            try (Connection connection = DriverManager.getConnection(url, username, password);
                 Statement selectStatement = connection.createStatement()) {
                // Retrieve the data
                ResultSet resultSet = selectStatement.executeQuery(selectQuery);

                // Iterate over the result set
                while (resultSet.next()) {
                    String data2 = resultSet.getString("text");
                    int id = resultSet.getInt("id");

                    // Check if the retrieved data contains the keyword "Amazon"
                    if (data2.contains("Amazon")) {
                        // Print the data of each column of the same row before deleting it
                        ResultSetMetaData metaData = resultSet.getMetaData();
                        int columnCount = metaData.getColumnCount();

                        System.out.println("Row Data:");
                        for (int i = 1; i <= columnCount; i++) {
                            String columnName = metaData.getColumnName(i);
                            String columnValue = resultSet.getString(i);
                            System.out.println(columnName + ": " + columnValue);
                        }

                        // Delete the row
                        try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
                            deleteStatement.setInt(1, id);
                            int deletedRows = deleteStatement.executeUpdate();
                            System.out.println("Deleted " + deletedRows + " row(s) from the database.");
                        }

                        // Break out of the loop after deleting the first matching row
                        break;
                    }
                }

                Constants.driver.findElement(By.xpath(object)).sendKeys(data);
                takeSnapShot();
            } catch (Exception e) {
                takeSnapShot();
                return KEYWORD_FAIL + " Unable to write " + e.getMessage();
            }
            return KEYWORD_PASS;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    //    public String PDFCheck(String object, String data) throws Exception {
//        // Define the folder containing PDFs and the output folder
//        String pdfFolderPath = "C:\\NotaryProj\\Downloads\\payment_confirmation.pdf";
//        String outputFolderPath = "C:\\NotaryProj\\Downloads\\documentcheck";
//        try {
//            // Iterate through all PDF files in the folder
//            Files.list(Paths.get(pdfFolderPath))
//                    .filter(path -> path.toString().endsWith(".pdf"))
//                    .forEach(path -> {
//                        try {
//                            // Extract text from PDF
//                            String text = extractTextFromPDFck(path.toFile());
//
//                            // Remove date and time (assuming they follow a specific pattern)
//                            String cleanedText = removeDateTime(text);
//
//                            // Write cleaned text to a new file with the same name
//                            String outputFilePath = outputFolderPath + "/" + path.getFileName().toString().replace(".pdf", ".txt");
//                            writeTextToFile(outputFilePath, cleanedText);
//
////                            // Verify the content with another text file (txtfile2)
////                            String txtFile2Path = outputFolderPath + "/txtfile2/" + path.getFileName().toString().replace(".pdf", ".txt");
////                            boolean isContentEqual = compareTextFiles(outputFilePath, txtFile2Path);
////
////                            // Output the verification result
////                            System.out.println("Verification result for " + path.getFileName() + ": " + isContentEqual);
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                    });
//        } catch (IOException e) {
//
//            e.printStackTrace();
//        } finally {
//            // Close the WebDriver
////            driver.quit();
//        }
//
//        return object;
//    }


//    public String VerifyTextpdf(String actual, String expected) throws Exception {
//        try {
//            // Path to the PDF file
//            String pdfFilePath = "C:\\NotaryProj\\Downloads\\THIRD_PARTY_AUTHORISATION (2).pdf";
//            File pdfFile = new File(pdfFilePath);
//            if (!pdfFile.exists() || !pdfFile.isFile()) {
//                System.err.println("The provided path does not exist or is not a file: " + pdfFilePath);
//                System.exit(1);
//            }
//
//            // Output file path with the same name but .txt extension
//            String outputFilePath = pdfFilePath.replace(".pdf", ".txt");
//
//            // Extract text from the PDF and write it to a .txt file with the same name
//            extractTextFromPdfAndWriteToFile(pdfFilePath, outputFilePath);
//            extractTextFromPdfAndWriteToFile(pdfFilePath, outputFilePath);
//        } catch (Exception e) {
//            LogCapture.info("Something Went Wrong on VerifyTextMailinator Reusable");
//            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
//        }
//
//        return actual;
//    }

//    private static void extractTextFromPdfAndWriteToFile(String pdfFilePath, String outputFilePath) throws IOException {
//        // Extract text from the specified PDF file
//        StringBuilder extractedText = new StringBuilder();
//        try (PdfDocument pdfDoc = new PdfDocument(new PdfReader(pdfFilePath))) {
//            int numberOfPages = pdfDoc.getNumberOfPages();
//            for (int i = 1; i <= numberOfPages; i++) {
//                extractedText.append(PdfTextExtractor.getTextFromPage(pdfDoc.getPage(i))).append("\n");
//            }
//        }
//
//        // Write the extracted text to a .txt file
//        try (FileWriter writer = new FileWriter(outputFilePath)) {
//            writer.write(extractedText.toString());
//        }
//    }


    public String verifyPdfText(String object, String data) throws Exception {
        try {
            // Paths to the two text files
//            String filePath1 = "C:\\NotaryProj\\Downloads\\THIRD_PARTY.txt";
//            String filePath2 = "C:\\NotaryProj\\Downloads\\THIRD_PARTY_AUTHORISATION.txt";
//            // Read the contents of both files
//            String filePath1 = "path/to/first/text/file.txt";
//            String filePath2 = "path/to/second/text/file.txt";
            // Compare the sanitized contents of the files
//            String content1 = readTextFile(filePath1);
//            String content2 = readTextFile(filePath2);
            Path filePath1 = Paths.get("C:\\NotaryProj\\Downloads\\THIRD_PARTY_AUTHORISATION.txt");
            Path filePath2 = Paths.get("C:\\NotaryProj\\Downloads\\THIRD_PARTY_AUTHORISATION.txt");
            List<String> file1Lines = Files.readAllLines(filePath1);
            List<String> file2Lines = Files.readAllLines(filePath2);

            String compare = compareFiles(file1Lines, file2Lines);

            if (compare.equalsIgnoreCase("FAIL")) {
                return KEYWORD_FAIL;
            } else {
                return KEYWORD_PASS;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }


    }


    private static String compareFiles(List<String> file1Lines, List<String> file2Lines) {
        int maxLength = Math.max(file1Lines.size(), file2Lines.size());
        String Result = "";
        for (int i = 0; i < maxLength; i++) {
            String file1Line = i < file1Lines.size() ? file1Lines.get(i) : null;
            String file2Line = i < file2Lines.size() ? file2Lines.get(i) : null;

            if (file1Line != null && file2Line != null) {
                if (file1Line.equals(file2Line)) {
                    System.out.println("Same at line " + (i + 1) + ":");
                    System.out.println("File 1: " + file1Line);
                    System.out.println("File 2: " + file2Line);
                } else {
                    System.out.println("Difference at line " + (i + 1) + ":");
                    System.out.println("File 1: " + file1Line);
                    System.out.println("File 2: " + file2Line);
                    Assert.fail();

                }
            } else if (file1Line != null) {
                System.out.println("File 2 ended at line " + (i + 1));
                System.out.println("File 1: " + file1Line);
            } else if (file2Line != null) {
                System.out.println("File 1 ended at line " + (i + 1));
                System.out.println("File 2: " + file2Line);
            }
        }

        return Result;
    }


    public String ComparePdf(String object, String data) throws Exception {
        try {
            // Paths to the two text files
//            String filePath1 = "C:\\NotaryProj\\Downloads\\THIRD_PARTY.txt";
//            String filePath2 = "C:\\NotaryProj\\Downloads\\THIRD_PARTY_AUTHORISATION.txt";
//            // Read the contents of both files
//            String filePath1 = "path/to/first/text/file.txt";
//            String filePath2 = "path/to/second/text/file.txt";
            // Compare the sanitized contents of the files
//            String content1 = readTextFile(filePath1);
//            String content2 = readTextFile(filePath2);
            Path filePath1 = Paths.get("C:\\NotaryProj\\Downloads\\THIRD_PARTY_AUTHORISATION.txt");
            Path filePath2 = Paths.get("C:\\NotaryProj\\Downloads\\THIRD_PARTY_AUTHORISATION.txt");
            List<String> file1Lines = Files.readAllLines(filePath1);
            List<String> file2Lines = Files.readAllLines(filePath2);

            String compare = compareFiles(file1Lines, file2Lines);
//            compare.equalsIgnoreCase("FAIL");

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }


        return KEYWORD_PASS;
    }


    public String VerifyAndReplacetxt(String object, String data) throws Exception {
        try {

            String filePath = "C:\\NotaryProj\\Downloads\\THIRD_PARTY_AUTHORISATION.txt";

            // Text to search for and replace
            String searchText = "DocuSign Envelope ID: A6CC0165-6939-4028-9B5E-5AB37EDEBCDC";
            String replacementText = "";

            // Verify if the text is present and replace it
            boolean isTextReplaced = verifyAndReplaceText(filePath, searchText, replacementText);

            if (isTextReplaced) {
                System.out.println("Text replaced successfully.");
                return KEYWORD_PASS;
            } else {
                System.out.println("Text not found in the file.");
                return KEYWORD_FAIL;
            }

        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }


    private static boolean verifyAndReplaceText(String filePath, String searchText, String replacementText) throws IOException {
        Path path = Paths.get(filePath);
        List<String> lines = Files.readAllLines(path);
        AtomicBoolean isTextFound = new AtomicBoolean(false);

        List<String> updatedLines = lines.stream()
                .map(line -> {
                    if (line.contains(searchText)) {
                        isTextFound.set(true);
                        return line.replace(searchText, replacementText);
                    }
                    return line;
                })
                .collect(Collectors.toList());

        if (isTextFound.get()) {
            Files.write(path, updatedLines);
        }

        return isTextFound.get();
    }

//    public String PdfToText(String object, String data) throws Exception {
//        try {
//            // Process each PDF in the folder
//            String downloadFolderPath = System.getProperty("user.dir") + "/Downloads/";
//            System.out.println(downloadFolderPath);
//
//            File folder = new File(downloadFolderPath);
//            File[] listOfFiles = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".pdf"));
//
//            if (listOfFiles != null) {
//                for (File file : listOfFiles) {
//                    if (file.isFile()) {
//                        String pdfFilePath = file.getAbsolutePath();
//                        String textFilePath = pdfFilePath.replace(".pdf", ".txt");
//
//                        // Extract text from the PDF and save to a text file
//                        PdfReader pdfReader = new PdfReader(pdfFilePath);
//                        PdfDocument pdfDocument = new PdfDocument(pdfReader);
//                        StringBuilder extractedText = new StringBuilder();
//
//                        for (int i = 1; i <= pdfDocument.getNumberOfPages(); i++) {
//                            extractedText.append(PdfTextExtractor.getTextFromPage(pdfDocument.getPage(i)));
//                        }
//
//                        Files.write(Paths.get(textFilePath), extractedText.toString().getBytes());
//                        pdfDocument.close();
//                        pdfReader.close();
//                        System.out.println("Text extracted and saved to " + textFilePath);
//                    }
//                }
//            } else {
//                System.out.println("No PDF files found in the specified folder.");
//            }
//            takeSnapShot();
//        } catch (Exception e) {
//            takeSnapShot();
//            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
//        }
//        return KEYWORD_PASS;
//    }
//




    public static void replaceKeywordsInTextFiles(String folderPath, String oldKeyword, String newKeyword) throws IOException {
        File folder = new File(folderPath);
        File[] listOfFiles = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));

        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    Path filePath = Paths.get(file.getAbsolutePath());
                    String content = new String(Files.readAllBytes(filePath));
                    content = content.replace(oldKeyword, newKeyword);
                    Files.write(filePath, content.getBytes(), StandardOpenOption.TRUNCATE_EXISTING);
                    System.out.println("Keywords replaced in " + file.getName());
                }
            }
        } else {
            System.out.println("No text files found in the specified folder.");
        }
    }


//    public String compare(String object, String data, String data2) throws Exception {
//        try {
//            String folderPath1 = System.getProperty("user.dir") + "/Downloads/"+object;
//            String  folderPath2= System.getProperty("user.dir") + "/Downloads/"+object+"-downloaded";
//
//            // Call the method to compare text files
////            compareTextFiles(folderPath1, folderPath2);
//            // Call the method to compare PDF files
//            comparePDFFiles(folderPath1, folderPath2,data,data2);
//
//
//
//            // Delete the text files after comparison
//            deleteTextFiles(folderPath1);
//            deleteTextFiles(folderPath2);
//            takeSnapShot();
//        } catch (Exception e) {
//            takeSnapShot();
//            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
//        }
//        return KEYWORD_PASS;
//    }
//    public static void comparePDFFiles(String folderPath1, String folderPath2,String Data, String Data2) throws Exception {
//        File folder1 = new File(folderPath1);
//        File[] listOfFiles1 = folder1.listFiles((dir, name) -> name.toLowerCase().endsWith(".pdf"));
//
//        if (listOfFiles1 != null) {
//            for (File file1 : listOfFiles1) {
//                if (file1.isFile()) {
//                    String fileName = file1.getName();
//                    System.out.println("Processing file: " + fileName);
//                    File file2 = new File(folderPath2, fileName);
//
//                    if (file2.exists() && file2.isFile()) {
//                        // Create text files from PDFs
//                        String textFilePath1 = createTextFileFromPDF(file1.getAbsolutePath(), folderPath1);
//                        String textFilePath2 = createTextFileFromPDF(file2.getAbsolutePath(), folderPath2);
//System.out.println(textFilePath1);
//
////Buyer Disbursemengt.pdf
//
////                            gettextfromfile(textFilePath2, "DocuSign Envelope ID:");
////                            System.out.println(Newtxt);
////                            gettextfromfile(textFilePath2, "100");
////                            System.out.println(Newtxt1);
////                            gettextfromfile(textFilePath2, "ES9121000418450200051332");
////                            System.out.println(Newtxt2);
////                            gettextfromfile(textFilePath2, "Mario Casas");
////                            System.out.println(Newtxt3);
//
//
////  //Buyer Third Party Authorisation.pdf
////                        gettextfromfile(textFilePath2, "DocuSign Envelope ID:");
////                        System.out.println(Newtxt4);
////                        gettextfromfile(textFilePath2, "/2024");
////                        System.out.println(Newtxt5);
////
////  // Certificate of Fund.pdf
////                        gettextfromfile(textFilePath2, "EUR");
////                        System.out.println(Newtxt);
////                        gettextfromfile(textFilePath2, "/2024");
////                        System.out.println(Newtxt4);
////                        gettextfromfile(textFilePath2, "DocuSign Envelope ID:");
////                        System.out.println(Newtxt);
////
//// //Ready for Sale.pdf
////                        gettextfromfile(textFilePath2, "DocuSign Envelope ID:");
////                        System.out.println(Newtxt);
////                        //Buyer Third Party Authorisation.pdf
////                        gettextfromfile(textFilePath2, ".0");
////                        System.out.println(Newtxt);
////                        gettextfromfile(textFilePath2, "/2024");
////                        System.out.println(Newtxt4);
////   // Certificate of Fund.pdf
////                        gettextfromfile(textFilePath2, "EUR");
////                        System.out.println(Newtxt);
////                        gettextfromfile(textFilePath2, "/2024");
////                        System.out.println(Newtxt4);
////                        gettextfromfile(textFilePath2, "DocuSign Envelope ID:");
////                        System.out.println(Newtxt);
////
////  //Seller Disbursement.pdf
////                        gettextfromfile(textFilePath2, "DocuSign Envelope ID:");
////                        System.out.println(Newtxt);
////                        //Buyer Third Party Authorisation.pdf
////                        gettextfromfile(textFilePath2, "ES9121000418450200051332");
////                        System.out.println(Newtxt2);
////                        gettextfromfile(textFilePath2, "/2024");
////                        System.out.println(Newtxt4);
////                        gettextfromfile(textFilePath2, "100");
////                        System.out.println(Newtxt1);
////
////  //Seller Third Party Authorisation.pdf
////                        gettextfromfile(textFilePath2, "DocuSign Envelope ID:");
////                        System.out.println(Newtxt);
////                        gettextfromfile(textFilePath2, "/2024");
////                        System.out.println(Newtxt4);
////                        gettextfromfile(textFilePath2, "ES9121000418450200051332");
////                        System.out.println(Newtxt2);
////                        gettextfromfile(textFilePath2, "100");
////                        System.out.println(Newtxt1);
////                        gettextfromfile(textFilePath1, "100");/2024
////                        System.out.println(Newtxt);
//
////
////                        if(line.contains("DocuSign Envelope ID:")){
////                            Newtxt=foundLine;
////                        } else if(line.contains("100")){
////                            Newtxt1=foundLine;
////                        }else if(line.contains("ES9121000418450200051332")){
////                            Newtxt2=foundLine;
////                        }
////                        else if(line.contains("Mario Casas")){
////                            Newtxt3=foundLine;
////                        }
////                        else if(line.contains("/2024")){
////                            Newtxt4=foundLine;
////                        }
////                        else if(line.contains(".0")){
////                            Newtxt5=foundLine;
////                        }
//
//                        // Perform replacements in the text file1 gettextfromfile
////                        performReplacements(textFilePath1,Data,Data2);
////                        performReplacements(textFilePath2,Data,Data2);
//
//                        // Compare the created text files
//                        Set<String> file1Content = extractTextFromTextFile(textFilePath1);
//                        Set<String> file2Content = extractTextFromTextFile(textFilePath2);
//
//                        printDissimilarData(fileName, file1Content, file2Content);
//                    } else {
//                        System.out.println("File " + fileName + " does not exist in folder " + folderPath2);
//                    }
//                }
//            }
//        } else {
//            System.out.println("No PDF files found in folder " + folderPath1);
//        }
//    }
//
////    public static String createTextFileFromPDF(String pdfFilePath, String folderPath) throws IOException {
////        PdfReader pdfReader = new PdfReader(pdfFilePath);
////        PdfDocument pdfDocument = new PdfDocument(pdfReader);
////        StringBuilder extractedText = new StringBuilder();
////
////        for (int i = 1; i <= pdfDocument.getNumberOfPages(); i++) {
////            extractedText.append(PdfTextExtractor.getTextFromPage(pdfDocument.getPage(i)));
////        }
////
////        pdfDocument.close();
////        pdfReader.close();
////
////        // Create text file
////        String textFilePath = pdfFilePath.replace(".pdf", ".txt");
////        try (FileWriter writer = new FileWriter(textFilePath)) {
////            writer.write(extractedText.toString());
////        }
////
////        return textFilePath;
////    }
////
//
//


    public static String gettextfromfile(String object, String data) throws Exception {
        // Path to the text file
        String filePath = object;
        String keyword = data;
        String foundLine = null;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains(keyword)) {
                    foundLine = line;

    Newtxt=foundLine;
// else if(line.contains("100")){
//    Newtxt1=foundLine;
//}else if(line.contains("ES9121000418450200051332")){
//    Newtxt2=foundLine;
//}
//else if(line.contains("Mario Casas")){
//    Newtxt3=foundLine;
//}
//else if(line.contains("/2024")){
//    Newtxt4=foundLine;
//}
//else if(line.contains(".0")){
//    Newtxt5=foundLine;
//}
//else if(line.contains("DocuSign Envelope ID:")){
//    Newtxt=foundLine;
//}
//else if(line.contains("DocuSign Envelope ID:")){
//    Newtxt=foundLine;
//}


                    break;
                }
            }
            takeSnapShot();
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Unable to write " + e.getMessage();
        }
        return KEYWORD_PASS;
    }

    public static void performReplacements(String filePath,String Variable1,String Variable2) throws IOException {
        File file = new File(filePath);
        StringBuilder fileContent = new StringBuilder();
        // Get today's date
        LocalDate today = LocalDate.now();

        // Format the date as DD/MM/YYYY
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String formattedDate = today.format(formatter);

        // Print today's date
        System.out.println(Variable1+" "+Variable2+formattedDate);
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                //Processing file: Buyer Disbursement.pdf
//                line = line.replace("DocuSign Envelope ID: EF81C449-6A78-417C-A4AB-AEDE11E045F9",
//                        "");
//                line = line.replace("qtgkv 100", Variable1+" "+Variable2);
//                line = line.replace("ES9121000418450200051332 qtgkv",
//                        "ES9121000418450200051332"+Variable1);
////                line = line.replace("DocuSign Envelope ID: 6A874D4E-5576-4D23-8637-8505C962A84C",
////                        Newtxt);
//
//                line = line.replace("20/05/2024", formattedDate);
//                line = line.replace("EUR 446469.00", "");
//                line = line.replace("EUR 446469.00", formattedDate);

//                line = line.replace("Mario Casas 595", Newtxt3);
//
//                //Buyer Third Party Authorisation.pdf
//                line = line.replace("DocuSign Envelope ID: 523CC0BD-8538-4BB8-901C-9585933493FB",
//                        Newtxt);
//                line = line.replace("21/05/2024", Newtxt4);
//
//               // Certificate of Fund.pdf
//                line = line.replace("EUR 445003.00",
//                        Newtxt);
//                line = line.replace("DocuSign Envelope ID: C83ADF8C-0295-41E6-B55B-C796D530D9C5", Newtxt);
//                line = line.replace("21/05/2024", Newtxt4);
//
//                //Ready for Sale.pdf
//                line = line.replace("DocuSign Envelope ID: 1D66E0CE-6407-409A-A478-63084A6BEBC9",
//                        Newtxt);
//                line = line.replace("604.0", Newtxt5);
//                line = line.replace("21/05/2024", Newtxt4);
//
//                //Seller Disbursement.pdf
//
//                line = line.replace("DocuSign Envelope ID: 373D624C-EEB6-4420-A9C0-D0184B920B48",
//                        Newtxt);
//                line = line.replace("ES9121000418450200051332 SaurabhSeller1fadyw", Newtxt2);
//                line = line.replace("21/05/2024", Newtxt4);
//                line = line.replace("SaurabhSeller1fadyw 100", Newtxt1);
//
//                //Seller Third Party Authorisation.pdf
//
//                line = line.replace("DocuSign Envelope ID: 7BFD327E-A040-4C7D-9A7E-7ADA27FA599D",
//                        Newtxt);
////                line = line.replace("ES9121000418450200051332 SaurabhSeller1fadyw", "ES9121000418450200051332 SaurabhSeller1btoae");
//                line = line.replace("21/05/2024", Newtxt4);
//




//                if(line.contains("DocuSign Envelope ID:")){
//                    Newtxt=foundLine;
//                } else if(line.contains("100")){
//                    Newtxt1=foundLine;
//                }else if(line.contains("ES9121000418450200051332")){
//                    Newtxt2=foundLine;
//                }
//                else if(line.contains("Mario Casas")){
//                    Newtxt3=foundLine;
//                }
//                else if(line.contains("/2024")){
//                    Newtxt4=foundLine;
//                }
//                else if(line.contains(".0")){
//                    Newtxt5=foundLine;
//                }
                //////////////////////////////////
//                line = line.replace("DocuSign Envelope ID: EF81C449-6A78-417C-A4AB-AEDE11E045F9",
//                        Newtxt);
//                line = line.replace("qtgkv 100", "SaurabhBuyer1xeqaz 100");
//                line = line.replace("ES9121000418450200051332 qtgkv",
//                        "ES9121000418450200051332 SaurabhBuyer1xeqaz");
//                line = line.replace("Mario Casas 595", "Mario Casas 506");
//
//                //Buyer Third Party Authorisation.pdf
//                line = line.replace("DocuSign Envelope ID: 523CC0BD-8538-4BB8-901C-9585933493FB",
//                        "DocuSign Envelope ID: 460F5864-FDDB-4B09-8FA4-5FDB2095C6B7");
//                line = line.replace("21/05/2024", "20/05/2024");
//
//                // Certificate of Fund.pdf
//                line = line.replace("EUR 445003.00",
//                        "EUR 446469.00");
//                line = line.replace("DocuSign Envelope ID: C83ADF8C-0295-41E6-B55B-C796D530D9C5", "DocuSign Envelope ID: 20CC1550-7AAC-4DEA-A984-FC6CACA6A3C9");
//                line = line.replace("21/05/2024", "20/05/2024");
//
//                //Ready for Sale.pdf
//                line = line.replace("DocuSign Envelope ID: 1D66E0CE-6407-409A-A478-63084A6BEBC9",
//                        "DocuSign Envelope ID: 0707EB99-A892-41C9-A06D-B7FB2079FE48");
//                line = line.replace("604.0", "506.0");
//                line = line.replace("21/05/2024", "20/05/2024");
//
//                //Seller Disbursement.pdf
//
//                line = line.replace("DocuSign Envelope ID: 373D624C-EEB6-4420-A9C0-D0184B920B48",
//                        "DocuSign Envelope ID: 35BCD7BA-A747-4889-A185-CD900A1E32E1");
//                line = line.replace("ES9121000418450200051332 SaurabhSeller1fadyw", "ES9121000418450200051332 SaurabhSeller1btoae");
//                line = line.replace("21/05/2024", "20/05/2024");
//                line = line.replace("SaurabhSeller1fadyw 100", "SaurabhSeller1btoae 100");
//
//                //Seller Third Party Authorisation.pdf
//
//                line = line.replace("DocuSign Envelope ID: 7BFD327E-A040-4C7D-9A7E-7ADA27FA599D",
//                        "DocuSign Envelope ID: 2C7B5B73-0CE4-4579-95E6-EBE5271A6E15");
////                line = line.replace("ES9121000418450200051332 SaurabhSeller1fadyw", "ES9121000418450200051332 SaurabhSeller1btoae");
//                line = line.replace("21/05/2024", "20/05/2024");




                fileContent.append(line).append(System.lineSeparator());
            }
        }

        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(fileContent.toString());
        }
    }

    public static Set<String> extractTextFromTextFile(String filePath) throws IOException {
        Set<String> extractedText = new HashSet<>();
        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                extractedText.add(scanner.nextLine());
            }
        }
        return extractedText;
    }

    public static void printDissimilarData(String fileName, Set<String> file1Content, Set<String> file2Content) {
        Set<String> dissimilarData = new HashSet<>(file2Content);
        dissimilarData.removeAll(file1Content);

        if (!dissimilarData.isEmpty()) {
            System.out.println("Differences found in file: " + fileName);
            for (String data : dissimilarData) {

             //   System.out.println(dissimilarData);
                if(data.contains("DocuSign Envelope ID:")|| data.contains("SaurabhBuyer") ||data.contains("/2024") || data.contains("Mario Casas") || data.contains("ES9121000418450200051332")|| data.contains("-c")|| data.contains("-a")|| data.contains("EUR")|| data.contains(".0")){
                    System.out.println("Expected Disimillar word"+data);
                }
                else
                {
                    System.out.println("Disimillar word"+data);
                    Assert.fail("Expected char not found in " );
                }

                System.out.println("pdf files are correct");
            }
        } else {
            System.out.println("No differences found in file: " + fileName);
        }
    }

    public static void deleteTextFiles(String folderPath) {
        File folder = new File(folderPath);
        File[] listOfFiles = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));

        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    if (file.delete()) {
                        System.out.println("Deleted text file: " + file.getName());
                    } else {
                        System.out.println("Failed to delete text file: " + file.getName());
                    }
                }
            }
        }
    }
//
//
//    public static void compareTextFiles(String folderPath1, String folderPath2) throws IOException {
//        File folder1 = new File(folderPath1);
//        File[] listOfFiles1 = folder1.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));
//
//        if (listOfFiles1 != null) {
//            for (File file1 : listOfFiles1) {
//                if (file1.isFile()) {
//                    String fileName = file1.getName();
//                    System.out.println("Comparing file: " + fileName);
//                    File file2 = new File(folderPath2, fileName);
//
//                    if (file2.exists() && file2.isFile()) {
//                        List<String> file1Lines = Files.readAllLines(Paths.get(file1.getAbsolutePath()));
//                        List<String> file2Lines = Files.readAllLines(Paths.get(file2.getAbsolutePath()));
//
//                        printDissimilarData(fileName, file1Lines, file2Lines);
//                    } else {
//                        System.out.println("File " + fileName + " does not exist in folder " + folderPath2);
//                    }
//                }
//            }
//        } else {
//            System.out.println("No text files found in folder " + folderPath1);
//        }
//    }
//
//    public static void printDissimilarData(String fileName, List<String> file1Lines, List<String> file2Lines) {
//        int maxLines = Math.max(file1Lines.size(), file2Lines.size());
//        boolean hasDifferences = false;
//
//        for (int i = 0; i < maxLines; i++) {
//            String line1 = (i < file1Lines.size()) ? file1Lines.get(i) : "";
//            String line2 = (i < file2Lines.size()) ? file2Lines.get(i) : "";
//
//            if (!line1.equals(line2)) {
//                if (!hasDifferences) {
//                    System.out.println("Differences found in file: " + fileName);
//                    hasDifferences = true;
//                }
//                System.out.println("Line " + (i + 1) + ":");
//                System.out.println("Folder1: " + line1);
//                System.out.println("Folder2: " + line2);
//            }
//        }
//
//        if (!hasDifferences) {
//            System.out.println("No differences found in file: " + fileName);
//        }
//    }


    private static void printAlternatingLines(List<String> file1Content, List<String> file2Content) {
        int maxSize = Math.max(file1Content.size(), file2Content.size());
        for (int i = 0; i < maxSize; i++) {
            if (i < file1Content.size()) {
                System.out.println("File 1, Line " + (i + 1) + ": " + file1Content.get(i));
            }
            if (i < file2Content.size()) {
                System.out.println("File 2, Line " + (i + 1) + ": " + file2Content.get(i));
            }
        }
    }


    public String verifyText1OrText2(String object, String data1, String data2) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("actual value->>>>" + actual);
            }
            String expected1 = data1;
            String expected2 = data2;
            System.out.println("actual value    ->>>>" + actual);
            System.out.println("Expected value1 ->>>>" + data1);
            System.out.println("Expected value2 ->>>>" + data2);
            if (actual.equals(expected1)  || actual.equals(expected2))
            {
                LogCapture.info("User verify Actual value as "+actual);
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected1 +" / "+ expected2;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

    public String getAttributeValue(String object, String Attribute, String Value) throws Exception {
        try {
            actual = Constants.driver.findElement(By.xpath(object)).getAttribute(Attribute);
            if (actual.equals(Value))
            {
                System.out.println("Actual Attribute Value   >> " + actual);
                System.out.println("Expected Attribute Value >> " + Value);
                return KEYWORD_PASS;
            }else
            {
                return KEYWORD_FAIL + "Attribute not Matched....";
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Attribute not found...." + e.getMessage();
        }
    }


    public String isNotNull(String object, String data) throws Exception {
        String actualText = null;
        try {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(object, ""));
            actualText = Constants.driver.findElement(By.xpath(object)).getText();
            if (!actualText.equals("")) {
                LogCapture.info("User verify " + data + " as " + actualText);
            } else {
                Assert.fail();
            }
        } catch (Exception e) {
            takeSnapShot();
            LogCapture.info("User unable to verify " + data + " as " + actualText);
        }
        return actualText;
    }

    public String verifyTextNew(String object, String data) throws Exception {
        try {
            String actual = Constants.driver.findElement(By.xpath(object)).getText();
            if (actual.length() < 1) {
                actual = Constants.driver.findElement(By.xpath(object)).getAttribute("value");
                System.out.println("actual value->>>>" + actual);
            }
            String expected = data;
            if (actual.equals(expected)) {
                takeSnapShot();
                return KEYWORD_PASS;
            } else {
                takeSnapShot();
                return KEYWORD_FAIL + "...text not verified " + actual + "  " + expected;
            }
        } catch (Exception e) {
            takeSnapShot();
            return KEYWORD_FAIL + "Object not found...." + e.getMessage();
        }

    }

}



