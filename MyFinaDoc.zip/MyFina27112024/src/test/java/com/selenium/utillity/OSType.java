package com.selenium.utillity;

public enum OSType {
    WINDOWS,
    LINUX,
    MAC
}
