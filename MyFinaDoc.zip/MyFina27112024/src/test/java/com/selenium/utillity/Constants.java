package com.selenium.utillity;

import com.google.common.base.Stopwatch;
import com.service.utillity.ReusableMethod;
import com.utility.LogCapture;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.w3c.dom.Document;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Constants {
    public static String BIC ;
    public static String VIEW;
    public static String paymentLifeCycleID;
    public static String MSL_ID;
    public static Map<String, String> MessageInIdMap = new HashMap<>();
    public static Map<String, String> KafkaMsg =new HashMap<>();
    public static Properties KafkaUI;
    public static Map<String, String> kafkaExpectedKeyValues = null;
    public static String EODMSL_ID ;
    public static Reusables key;
    public static WebDriver driver;
    public static String KEYWORD_PASS = "PASS";
    public static String KEYWORD_FAIL = "FAIL";
    public static Properties CONFIG;
    public static String JenkinsBrowser = System.getProperty("jenkinsBrowser");
    public static Properties loginPageOR;
    public static Properties DashboardOR;
    public static Properties NewRateAlertOR;
    public static String messageInQuery;
    public static String RANDOM_VALUE = "";
    public static LogCapture logs;
    public static Properties TopupWalletOR;
    public static Properties MakeTransferOR;
    public static Properties TitanLoginOR;
    public static Properties CreateFxTicketOR;
    public static Properties AtlasloginOR;
    public static Properties AtlasDashboardOR;
    public static Properties AtlasPaymentInOR;
    public static Properties AtlasPaymentOutOR;
    public static Properties SFLoginOR;
    public static Properties LeadGenerationOR;
    public static Properties ProfileManagementOR;
    public static Properties SignUp;
    public static Properties HelpOR;
    public static Properties PaymentTrackingOR;
    public static String PTData;
    public static Properties CalypsologinPageOR;
    public static Properties FrenchDashboardOR;
    public static Properties OccupationGenericOR;
    public static Properties AtlasRegistrationOR;

    public static Properties TitanDashboardOR;
    public static Properties TitanCustomersOR;
    public static Properties TitanConflictsOR;
    public static Properties TitanQueuesOR;
    public static Properties TitanPaymentInOR;
    public static Properties TitanPaymentOutOR;
    public static Properties TitanPayeeOR;
    public static Properties TitanFXTicketsOR;
    public static Properties TitanInstructionsOR;
    public static Properties TitanTreasuryOR;
    public static Properties TitanReportsOR;
    public static Properties TitanCDSAPhase1OR;

    public static Properties PropertyPayDashboardOR;

    public static Properties PFXOR;
    public static Properties OnTheFlyValue;

    public static String parentDirPath = System.getProperty("user.dir");
    public static String downloadFilesPath = parentDirPath + File.separator + "Downloads" + File.separator;

    //-----------------Jenkins-Grafana checkpoint below-------------------------------
    public static String uniqueAlphaNumericJobID = "";
    public static long stopwatchTime = 0L;
    public static Stopwatch stopwatch=null;
    public static String grafanaApplicationName="Titan";
    public static java.sql.Connection Connection;
    //-----------------Jenkins-Grafana checkpoint above-------------------------------

    //------------------------- API Values--------------------------------------------
    public static HashMap<String, String> DynamicValue = new HashMap<>();
    public static ReusableMethod APIkey;
    public static String apiBodyValue;
    public static String TCCaseID = "";

    public static String SHEET_NAME = "";
    public static String RESPONSE = "";
    public static String BuyersAccountDetails = "";
    public static String BuyerSolicitorDetails = "";
    public static String SellerSolicitorDetails = "";
    public static String SellersAccountDetails = "";
    public static String ACCESS_TOKEN = "";

    public static String apiBody;

    public static String RegressionExecutionStatus = "TRUE";

    public static String Execution = "";
    public static String ApplicationName = "";
    public static String tcIDs = "";
    public static String scenrioName = "";
    public static String org_code = "";
    public static String legal_entity = "";
    public static String partner_tag = "";

    public static String excelExecutionStatus = "";

    public static Integer rowCount;
    public static XSSFWorkbook workbookRead=null;
    public static XSSFSheet sheetRead=null;

    public static Integer counter=0;
    public static String connectionUrl;
    public static String dBUsername;
    public static String dbPassword;
    public static Properties SQLQUERIES;
    public static Properties dbconfig;
    public static String RandomUUID = "";
    public static String UniquePaymentLifeCycleId = "";
    public static String ReusablePaymentLifeCycleId = "";
    public static String RandomPtTokenID = "";
    public static String Bank;
    public static String FileType;
    public static String NewFileName;
    public static String currentDate;
    public static String OldAccountNumber;
    public static String dateReplace;
    public static String oldAmountStarting;
    public static String nameDate;
    public static String newAmount;
    public static Document doc1;
    public static String PaymentInAmount;
    public static String MessageInId;
    public static String RemitterNameID;
    public static String StatementLineID;
    public static String ConfirmationID;
    public static String IntradayStatementID;
    public static String IntradayStatementLineID;
    public static double InAmount=0.00;
    public static String BankPaymentEntriesID;

    public static String JsonMessageActual;
    public static String IndradayMSL_ID;
    public static String InstructionNumber;
    public static String CustomerPaymentInID;
    public static String InstructionNumber1;
    public static String CustomerInstructionID;
    public static String InstructionIdReference;
    public static String Kafka_ID;
    public static String LimitOrderID;
    public static String CustomerPaymentOutID;
    public static String FullInstructionNumber;
    public static String InstructionReferenceNumber;
    public static String vBrowserName;
    public static String BankPaymentEntries_ID;
    public static String achMandateId;
    public static String external_reference_id;
    public static String FundType;
    public static String StatusEnum;
    public static String Currency_code;
    public static String bank_name;
    public static String Name;
    public static String hyperion_bank_account_reference_id;
    public static String Address;
    public static String filePath;

    public static String CardTransactionCurrency;
    public static String CardTransactionAmount;
    public static String CardBillingCurrency;
    public static String CardBillingAmount;
    public static String CardAmountToBlock;
    public static String CardAmountToBlockCurrency;
    public static String CardBaseCurrency;
    public static String CardATMFees;
    public static String CardCrossBorderFee;
    public static String CardSettelmentAmount;
    public static String CardSettelmentCurrency;
    public static String CardFeeCurrency;
    public static String NoTEmail;
    public static String NOTFullName;
    public static String NOTAddress;
    public static String NOTPassportNumber;
    public static String NOTPhoneNumber;
    public static String NOTcrmAccountId;
    public static String NOTcrmContactId;
    public static String NOTUniqueReferenceId;
    public static String NOTPayeeFirstName;
    public static String NOTPayeeLastName;
    public static String NOTPayeeIBAN;
    public static String NOTPayeeID;

    public static String NotaryEmail;

    public static String NotaryName;
    public static String NOTCompanyName;
    public static String NOTOfficePhoneNumber;
    public static String caseID;

    public static String PPPartyFullName;
    public static String PPParty2FullName;
    public static String PPPartyEmail;
    public static String PPParty2Email;
    public static String PPPartyMobileNo;
    public static String PPParty2MobileNo;

    public static String PPTransactionRefereneID="281";
    public static String PPFileReference="AUTOS4UR48H27082024180807";
    public static String PPPurchaseValue;

    public static String NoOfParties="2";

    public static String PPTransactionStatus;
    public static String PPPropertyAddress="Andador Alberto Albericio Conchán 1";

    public static String PPCreateAddressID="";

    public static String PaymentTypesOption="";
    public static String PaymentRequestsValue="";
    public static String PaymentRequestsCurrency="";
    public static String PaymentRequestsDueDate="";


    //------------------------- API Values--------------------------------------------
    //----------------------- FP and TP Map
    public static HashMap<String, String> FPDebtorName = new HashMap<>();

    public static String ref_code= "";
    public static String RESPONSE_CODE = "";
    public static String RESPONSE_DESCRIPTION = "";

    //---------------- FOR PP-124--------------------//
    public static HashMap<String, String> responseMap = new HashMap<>();
    public static HashMap<String, String> dbCapturedValues = new HashMap<>();
    public static HashMap<String, String> sqlResult = new HashMap<>();


}
