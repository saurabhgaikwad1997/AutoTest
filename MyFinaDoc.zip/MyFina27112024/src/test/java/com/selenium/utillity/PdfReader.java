package com.selenium.utillity;

import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import java.io.IOException;

public class PdfReader extends PDFTextStripper {
    public PdfReader() throws IOException {
        super();
    }

    @Override
    protected void processTextPosition(TextPosition text) {
        // Retrieve the coordinates of the text
        float x = text.getXDirAdj();
        float y = text.getYDirAdj();

        // Print the text and its coordinates
        System.out.println("Text: " + text.getUnicode() + " - Position: (" + x + ", " + y + ")");
    }

}


