package com.selenium.utillity;

public enum DriverType {
    CHROME,
    FIREFOX,
    EDGE,
    SAFARI
}
