package com.selenium.utillity.drivers;

import com.selenium.utillity.Constants;
import com.selenium.utillity.OSType;
import com.selenium.utillity.WebDriverManagerCustom;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.HashMap;
import java.util.Map;

import static com.selenium.utillity.Constants.downloadFilesPath;
import static com.selenium.utillity.OSType.*;

public class EdgeDriverManager extends WebDriverManagerCustom {
    private WebDriver driver;
    private OSType osType;

    public EdgeDriverManager(OSType osType) {

        this.osType = osType;
    }

    @Override
    public WebDriver getDriver(String object) {
        if (driver == null) {
            setupDriver(object);
        }
        return driver;
    }

    @Override
    public void setupDriver(String object) {
        WebDriverManager.edgedriver().setup();

        EdgeOptions options = new EdgeOptions();
        // Common preferences
        Map<String, Object> prefsMap = new HashMap<>();
        prefsMap.put("profile.default_content_settings.popups", 0);
        prefsMap.put("download.default_directory", downloadFilesPath);
        options.setExperimentalOption("prefs", prefsMap);

        switch (osType) {
            case WINDOWS:
                setupWindowsOptions(options, object);
                break;
            case LINUX:
                setupLinuxOptions(options, object);
                break;
            case MAC:
                setupMacOptions(options, object);
                break;
            default:
                throw new UnsupportedOperationException("Unsupported operating system");
        }

        driver = new EdgeDriver(options);
        Constants.driver = driver; // Initializing Constants.driver with the EdgeDriver instance
    }

    private void setupWindowsOptions(EdgeOptions options, String object) {
        // Set options specific to Windows
        options.addArguments("--remote-allow-origins=*");
        if (object.equalsIgnoreCase("Mobile") || object.equalsIgnoreCase("Tablet") || object.equalsIgnoreCase("Desktop")) {
            options.addArguments("start-maximized");
        } else if (object.equalsIgnoreCase("")) {
            options.addArguments("start-maximized");
        }
    }

    private void setupLinuxOptions(EdgeOptions options, String object) {
        // Set options specific to Linux
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--no-sandbox");
        options.addArguments("--headless");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-gpu");
        options.addArguments("--disable-extensions");
        options.setExperimentalOption("useAutomationExtension", false);
        options.addArguments("--proxy-server='direct://'");
        options.addArguments("--proxy-bypass-list=*");
        options.addArguments("--start-maximized");
        options.addArguments("--whitelisted-ips");
        if (object.equalsIgnoreCase("SalesForce")) {
            options.addArguments("--window-size=1536,753");
        } else {
            options.addArguments("--window-size=1920,1080");
        }
    }

    private void setupMacOptions(EdgeOptions options, String object) {
        // Set options specific to Mac
        options.addArguments("--remote-allow-origins=*");
        if (object.equalsIgnoreCase("Mobile") || object.equalsIgnoreCase("Tablet") || object.equalsIgnoreCase("Desktop")) {
            options.addArguments("start-maximized");
        } else if (object.equalsIgnoreCase("")) {
            options.addArguments("start-maximized");
        }
    }
}
