package com.service.utillity;

import com.selenium.utillity.Constants;
import com.selenium.utillity.Reusables;
import com.utility.LogCapture;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
//import jdk.internal.org.xml.sax.InputSource;
//import jdk.internal.org.xml.sax.SAXException;
import net.bytebuddy.asm.Advice;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;



import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;




import static com.selenium.utillity.Constants.key;
import static io.restassured.RestAssured.given;

public class ReusableMethod {

    static String fileName = Constants.CONFIG.getProperty("excelName");
    public static SoftAssert softAssert = new SoftAssert();

    /*
    Description: This method converts a string separated in piped(|) format and stores it in a Map. Used for Header and Query conversions
    Expected Input: Piped string, eg: "header1","value1"|"header2","value2"|"header3","value3"...etc
    Expected Output: Map Object
    */
    public static Map<String, String> getStringStringMap(String parameter) {
        Map<String, String> headerMap = null;
        try {
            headerMap = new HashMap<String, String>();
            String[] array = parameter.split("\\|");
            System.out.println(array.length);
            if (!parameter.equalsIgnoreCase("") && !parameter.equalsIgnoreCase("NA")) {
                for (int i = 0; i < array.length; i++) {
                    String[] headersList = array[i].split("\",\"");
                    String key = headersList[0].replaceAll("\"", "").trim();
                    String value = headersList[1].replaceAll("\"", "").trim();
                    if (key.equalsIgnoreCase("Authorization")) {
                        headerMap.put(key, value + " " + Constants.ACCESS_TOKEN);
                    } else if (key.equalsIgnoreCase("UUID")) {
                        headerMap.put(key, Constants.RandomUUID);
                    } else {
                        headerMap.put(key, value);
                    }
                }
            } else {
                LogCapture.info("----------Parameter is empty for getStringStringMap method---------------");
            }
            return headerMap;
        } catch (Exception e) {
            LogCapture.info("Error occurred in getStringStringMap method. The error is: " + e);
            e.printStackTrace();
        }
        return headerMap;
    }

    /*
    Description: This method converts the String response from API calls to Json Object for easy data extraction
    Expected Input: JSON String input
    Expected Output: JsonPath object
    */
    public static JsonPath waitForKafkaMessage(String messageFieldXpath) throws Exception {

        LogCapture.info("Waiting for Kafka message to populate on UI.....");
        LocalDateTime localDateTime = LocalDateTime.now();
        String kafkaJsonMessage;
        boolean isMessageLineDisplayed = false;
        Constants.key.VisibleConditionWait(messageFieldXpath, "");

//        }
        key.pause("1","");
        kafkaJsonMessage = Constants.key.getText(messageFieldXpath,"");
//        Assert.assertTrue(isMessageLineDisplayed, "Message is not found within 3 minutes");
        JsonPath jsonPath = JsonPath.from(kafkaJsonMessage);
        return jsonPath;
    }


    public static void verifyKafkaMessage(Map<String, String> expectedKafkaKeyValues, JsonPath actualKafkaMessageJsonObj) {
        //Map<String, String> expectedKeyValues = ReusableMethod.getSqlQueryResult(expectedMsgFieldsSqlQueryProperty, expectedMsgFieldsSqlQueryParameters);
        String transactionName = expectedKafkaKeyValues.get("MessageHeader.transactionName");

        for (String expectedKey : expectedKafkaKeyValues.keySet()) {

            String kafkaJsonPathPrefix = expectedKey.startsWith("MessageHeader.") ? "" : "MessageData.";
            String kafkaJsonPath = kafkaJsonPathPrefix + expectedKey;
            String actualValue = actualKafkaMessageJsonObj.getString(kafkaJsonPath);
            actualValue = Reusables.cleanJsonPathValue(actualValue);

            String expectedValue = expectedKafkaKeyValues.get(expectedKey);
            compareValue(expectedValue, actualValue, expectedKey, transactionName);
        }
    }


    public static void verifyKafkaAuditLog(Map<String, String> expectedKeyValues, Map<String, String> actualAuditRecord) {
        String transactionName = expectedKeyValues.get("MessageHeader.transactionName");

        for (String expectedKey : expectedKeyValues.keySet()) {
            String auditColumnNamePrefix = expectedKey.startsWith("MessageHeader.") ? "h" : "";
            String auditColumnName = auditColumnNamePrefix + expectedKey;
            String actualValue = actualAuditRecord.get(auditColumnName);

            if(actualValue!=null && actualValue.equalsIgnoreCase("t")) {
                actualValue = "true";
            }else if(actualValue!=null && actualValue.equalsIgnoreCase("f")) {
                actualValue = "false";
            }
            String expectedValue = expectedKeyValues.get(expectedKey.toLowerCase());
            compareValue(expectedValue, actualValue, auditColumnName, transactionName);
        }
    }

    private static void compareValue(String expectedValue, String actualValue, String key, String transactionName) {
        try {
            if (expectedValue != null && !expectedValue.equalsIgnoreCase("NULL")) {
                if (expectedValue.equalsIgnoreCase("NOTNULL")) {
                    ReusableMethod.softAssert.assertNotNull(actualValue, String.format("Assertion for %s failed for %s Kafka Audit Log", key, transactionName));
                }
                if (expectedValue.isEmpty()) {
                    ReusableMethod.softAssert.assertTrue(ReusableMethod.isNullOrEmpty(actualValue), String.format("Assertion for %s failed for %s Kafka Audit Log", key, transactionName));

                } else {
                    if (NumberUtils.isCreatable(expectedValue)) {
                        ReusableMethod.softAssert.assertEquals(NumberUtils.createDouble(expectedValue), NumberUtils.createDouble(actualValue), String.format("Assertion for %s failed for %s Kafka Audit Log", key, transactionName));
                    } else {
                        ReusableMethod.softAssert.assertEquals(actualValue, expectedValue, String.format("Assertion for %s failed for %s Kafka Audit Log", key, transactionName));
                    }
                }
            } else if (expectedValue == null) {
                ReusableMethod.softAssert.assertNull(actualValue, String.format("Assertion for %s failed for %s Kafka Audit Log", key, transactionName));
            }
        } catch (Exception e) {
            LogCapture.error(String.format("Exception occurred comparing %s. EXPECTED value is %s and ACTUAL value found is %s", expectedValue, expectedValue, actualValue));
        }
    }

    public static JsonPath rawToJson(String response) {
        JsonPath js1 = null;
        try {
            LogCapture.info("-------------Converting to JSON, response => " + response + "--------");
            js1 = new JsonPath(response);
            return (js1);
        } catch (Exception e) {
            LogCapture.info("Error occurred in rawToJson method. The error is: " + e);
            e.printStackTrace();
        }
        return js1;
    }

    /* This method converts string response into xml path. This method makes easy extraction of xml data
    Expected Input: Xml String input
    Expected Output: Xml object
     */
    public static XmlPath rawToXml(String response) {
        XmlPath xml_Obj = null;
        try {
            LogCapture.info("-------------Converting to Xml Object, response => " + response + "--------");
            xml_Obj = new XmlPath(response);
            return (xml_Obj);
        } catch (Exception e) {
            LogCapture.info("Error occurred while converting to Xml Object. The error is: " + e);
            e.printStackTrace();
        }
        return xml_Obj;
    }


    /*
    Description: This method reads the excel and returns value based on the testcaseID(row) and parameter name(Column header). This is a one on one mapping excel reading.
    Expected Input: String 1-TestcaseID, String 2-Parameter name to be fetched
    Expected Output: String of the excel cell value.
    */
    public static String readExcel(String testCaseID, String parameterName) throws IOException {
        try {
            LogCapture.info("--------------Started to Fetch value for testCase ID " + testCaseID + " for " + parameterName + " from excel-----------------");
            //Create an object of File class to open xlsx file
            File file = new File(System.getProperty("user.dir") + "/src/main/resources/" + fileName);
            //File file = new File(filePath + "\\" + fileName);
            //Create an object of FileInputStream class to read excel file
            FileInputStream inputStream = new FileInputStream(file);
            Workbook APIWorkbook = null;
            //Find the file extension by splitting file name in substring  and getting only extension name
            String fileExtensionName = fileName.substring(fileName.indexOf("."));
            //Check condition if the file is xlsx file
            if (fileExtensionName.equals(".xlsx")) {
                //If it is xlsx file then create object of XSSFWorkbook class
                APIWorkbook = new XSSFWorkbook(inputStream);
            }
            //Check condition if the file is xls file
            else if (fileExtensionName.equals(".xls")) {
                //If it is xls file then create object of HSSFWorkbook class
                APIWorkbook = new HSSFWorkbook(inputStream);

            }
            //Read sheet inside the workbook by its name
            Sheet excelSheet = APIWorkbook.getSheet(Constants.SHEET_NAME);
            if (excelSheet != null) {
                //Find number of rows in excel file
                int rowCount = excelSheet.getLastRowNum() - excelSheet.getFirstRowNum();
                //Create a loop over all the rows of excel file to read it
                Row rw = excelSheet.getRow(0);
                int cellNum = rw.getPhysicalNumberOfCells();
                Iterator<Cell> c = rw.cellIterator();
                int inc = -1;
                while (c.hasNext()) {
                    Cell cl = c.next();
                    String cellHeaderName = "";
                    inc++;
                    int rowSize = rw.getPhysicalNumberOfCells() - 1;
                    String cellType = cl.getCellType().toString();
                    if (cellType.equalsIgnoreCase("NUMERIC")) {
                        cellHeaderName = Double.toString(cl.getNumericCellValue()).trim();
                    } else if (cellType.equalsIgnoreCase("STRING")) {
                        cellHeaderName = cl.getStringCellValue().trim();
                    }
                    if (cellHeaderName.equalsIgnoreCase(parameterName.trim())) {
                        break;
                    }
                    if (rowSize == inc) {
                        inc = -1;
                    }
                }
                if (inc != -1) {
                    for (int i = 1; i < rowCount + 1; i++) {
                        //Create a loop to print cell values in a row
                        Row row = excelSheet.getRow(i);
                        if (row != null) {
                            if (row.getCell(2).getStringCellValue().equalsIgnoreCase(testCaseID)) {
                                String cllTyp = "";
                                if (row.getCell(inc).equals(null) || row.getCell(inc).getCellType() == CellType.BLANK) {
                                    cllTyp = "STRING";
                                } else {
                                    cllTyp = row.getCell(inc).getCellType().toString();
                                }
                                String cellDate = "";
                                if (cllTyp.equalsIgnoreCase("NUMERIC")) {
                                    cellDate = Double.toString(row.getCell(inc).getNumericCellValue());
                                } else if (cllTyp.equalsIgnoreCase("STRING")) {
                                    cellDate = row.getCell(inc).getStringCellValue();
                                    /*if (cellDate.contains("<Random_char>")){
                                        Constants.Recipient_Name = Constants.key.generateRandomWords(1) + " " + Constants.key.generateRandomWords(1);
                                        cellDate = cellDate.replaceAll("<Random_char>",Constants.Recipient_Name);
                                    }*/
                                }
                                LogCapture.info("--------------Value fetched from excel for: " + parameterName + " => " + cellDate + "-----------------");
                                return cellDate;
                            }
                        }
                    }
                }
                return null;
            }
        } catch (Exception e) {
            LogCapture.info("Error occurred in readExcel method for testcaseID = " + testCaseID + " while fetching parameter = " + parameterName + ", while reading excel. The error is: " + e);
            LogCapture.info("The Sheet name is not present in the excel");
            e.printStackTrace();
        }
        return null;
    }


    /*
    Description: This method is used for creating a new excel to log only the PASSED/FAILED status of test cases
    Expected Input: Object[][]: 2D object array of row to be populated in excel, Integer: row number to populate the object[][]
    Expected Output: NA
    */
    public static void writeFullExcel(Object[][] bookData, Integer rowNum) throws IOException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String dateString = format.format(new Date());
        for (Object[] aBook : bookData) {
            Row row = Constants.sheetRead.createRow(++rowNum - 1);
            String statusObject = (String) bookData[0][4];
            CellStyle cs;
            int columnCount = -1;
            for (Object field : aBook) {
                Cell cell = row.createCell(++columnCount);
                if (field instanceof String) {
                    cs = Constants.workbookRead.createCellStyle();
                    if (statusObject.equalsIgnoreCase("PASSED")) {
                        cs.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
                    } else if (statusObject.equalsIgnoreCase("SKIPPED")) {
                        cs.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
                    } else if (statusObject.equalsIgnoreCase("FAILED")) {
                        cs.setFillForegroundColor(IndexedColors.RED.getIndex());
                    } else if (statusObject.equalsIgnoreCase("Status")) {
                        cs.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
                    } else {
                        System.out.println("Response status doesn't match");
                        LogCapture.info("Response status doesn't match");
                    }
                    cs.setFillPattern(FillPatternType.FINE_DOTS);
                    cell.setCellValue((String) field);
                    cell.setCellStyle(cs);

                } else if (field instanceof Integer) {
                    cell.setCellValue((Integer) field);
                }
            }
        }

        try (FileOutputStream outputStream = new FileOutputStream(new File(System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "APIData_Reports" + File.separator + "API_ExecutionReport.xlsx"))) {
            Constants.workbookRead.write(outputStream);
        }
    }

    /*
    Description: This method is used to add the json objects that needs to be replaced at run time and its given as one of the inputs to the getDynamic, postDynamic methods
    Expected Input: String 1-Json key object who's value will be replaced dynamically, String 2-Json value which will update the dynamic value in excel json body
    Expected Output: NA
    */
    public static void PutInHashMap(String key, String Value) {
        try {
            Constants.DynamicValue.put(key, Value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void createReportParameters(String testCaseID) throws IOException {
        try {
            String scenarioName = Constants.APIkey.readExcel(testCaseID, "Scenario Name");
            String org_code = Constants.APIkey.readExcel(testCaseID, "org_code");
            String legal_entity = Constants.APIkey.readExcel(testCaseID, "legal_entity");
            String partner_tag = Constants.APIkey.readExcel(testCaseID, "Partner Tag");
            Constants.scenrioName = scenarioName;
            Constants.org_code = org_code;
            Constants.legal_entity = legal_entity;
            Constants.partner_tag = partner_tag;
        } catch (IOException e) {
            LogCapture.info("---Some error occurred while fetching report excel parameters---");
        }
    }

    public static String compareString(String expected, String actual) {
        try {
            if (actual.equals(expected)) {
                return Constants.KEYWORD_PASS;
            } else {
                LogCapture.info("Expected value :" + expected + " and Actual value :" + actual + " is not matching.");
                return Constants.KEYWORD_FAIL;
            }
        } catch (Exception e) {
            LogCapture.info("Expected value :" + expected + " and Actual value :" + actual + " is not matching. " + e);
            return Constants.KEYWORD_FAIL;
        }

    }

    /*
    Description: This method is used to update OnTheFlyValue
    Expected Input: Just Need to mention dynamic contain in Excel in <dynamic_value> format
    Expected Output: It will update dynamicConfig.properties file and Constants.DynamicValue with mentioned <dynamic_value>
    */
    public static void updateProperties() {
        try {
            Set<Object> set = Constants.OnTheFlyValue.keySet();
            Iterator<Object> iter = set.iterator();
            ArrayList<String> list = new ArrayList<>();
            while (iter.hasNext()) {
                list.add(iter.next().toString());
            }
            for (int a = 0; a < list.size(); a++) {
                String orignalKey = list.get(a);
                String modifiedkey = orignalKey.replaceAll("<", "").replaceAll(">", "").replaceAll(" ", "");
                if (Constants.RESPONSE.contains(modifiedkey)) {
                    JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
                    String value = jp.get(modifiedkey).toString();
                    updateConfig(orignalKey, value);
                    if (value != null) {
                        ReusableMethod.PutInHashMap(orignalKey, value);
                    }
                    System.out.println("KEY " + orignalKey + " VALUE " + Constants.OnTheFlyValue.getProperty(orignalKey) + " Is updated in your config File.....");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    Description: This method is used to update value in dynamicConfig.properties file
    Expected Input: Its required Key and value which needs to be updated in dynamicConfig.properties file
    Expected Output: It will update dynamicConfig.properties file with mentioned value
    */
    public static void updateConfig(String key, String value) {
        File file = new File(System.getProperty("user.dir") + "/src/Config/dynamicConfig.properties");
        try (FileInputStream in = new FileInputStream(file)) {
            if (!value.isEmpty() || value != null) {
                Constants.OnTheFlyValue.setProperty(key, value);
            } else {
                System.out.println("already updated");
            }
            FileOutputStream out = new FileOutputStream(file);
            Constants.OnTheFlyValue.store(out, null);
        } catch (NullPointerException | IOException e) {
            e.printStackTrace();
        }
    }

    /*
    Description: This method is used to add key and value in Constants.DynamicValue HashMap at the start of the execution
    Expected Input: Just need to mention .properties file name which have dynamic value
    Expected Output: Constants.DynamicValue will be updated with values mention in .properties
    */
    public static HashMap<String, String> OnTheFlyValues(String file) {
        Properties prop = new Properties();
        HashMap<String, String> map = new HashMap<String, String>();
        try {
            FileInputStream inputStream = new FileInputStream(file);
            prop.load(inputStream);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Some issue finding or loading file....!!! " + e.getMessage());

        }
        for (final HashMap.Entry<Object, Object> entry : prop.entrySet()) {
            map.put((String) entry.getKey(), (String) entry.getValue());
        }
        return map;
    }

    /*
    Description: This method is used to update OnTheFlyValue
    Expected Input: Just Need to mention dynamic value which needs to be updated in <dynamic_value> format
    Expected Output: It will update dynamicConfig.properties file and Constants.DynamicValue with mentioned <dynamic_value>
    */
    public static void UpdateSpecificProperties(String propertyName) {
        try {
            String modifiedkey = propertyName.replaceAll("<", "").replaceAll(">", "").replaceAll(" ", "");
            if (Constants.RESPONSE.contains(modifiedkey)) {
                JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
                String value = jp.get(modifiedkey).toString();
                updateConfig(propertyName, value);
                if (value != null) {
                    ReusableMethod.PutInHashMap(propertyName, value);
                }
                System.out.println("#############################  KEY " + propertyName + " VALUE " + Constants.OnTheFlyValue.getProperty(propertyName) + " Is updated in your config File #########################################");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    Description: This method is used to get Value of desire Key form API Body
    Expected Input: Just Need to mention Test Case ID and Key
    Expected Output: It will return value for mention key if it exists in API Body for mention test cases ID
    */
    public static String getSpecificProperties(String testCaseID, String Key) {
        try {
            String body = Constants.APIkey.readExcel(testCaseID, "Body").replace("\n", "");
            JsonPath jp = Constants.APIkey.rawToJson(body);
            String value = jp.get(Key).toString().replace("[", "").replace("]", "");
            LogCapture.info("For Key " + Key + " We have Value as ===========> " + value + " in API Body");
            return value;
        } catch (Exception e) {
            e.printStackTrace();
            return "Key not found in Body please check " + testCaseID + " body contain " + Key + " in Excel";
        }
    }

    public static String getSpecificPropertiesFormXML(String testCaseID, String Key) {
        try {
            String body = Constants.APIkey.readExcel(testCaseID, "Body").replace("\n", "");

            XmlPath xml = Constants.APIkey.rawToXml(body);
            //xml.get("SFLead.email");
            String value = xml.get(Key).toString().replace("[", "").replace("]", "");
            LogCapture.info("For Key " + Key + " We have Value as ===========> " + value + " in API Body");
            return value;
        } catch (Exception e) {
            e.printStackTrace();
            return "Key not found in Body please check " + testCaseID + " body contain " + Key + " in Excel";
        }
    }

    public static boolean findKeyInJson(String testCaseID, String Key) {
        try {
            String body = Constants.APIkey.readExcel(testCaseID, "Body").replace("\n", "");
            JsonPath jp = new JsonPath(body);
            String str = jp.getString("payload.referral_text");
            if (str != null)
                return true;
            else
                return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String getDate(int day) {
        Date dt = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.DATE, 1);
        dt = c.getTime();
        if (dt.toString().contains("Sat") || dt.toString().contains("Sun")) {
            c.add(Calendar.DAY_OF_YEAR, 2);
        } else {
            c.add(Calendar.DAY_OF_YEAR, 0);
        }
        System.out.println(dt);

        String pattern = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        return simpleDateFormat.format(dt);
    }

    // This method will update the current date Dynamically in request body with required format
    public static Void getCurrentDateOfFormat() {

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
        String CurrentDateFor1 = dtf1.format(now);
        Constants.DynamicValue.put("<currentDate1>", CurrentDateFor1);

        DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        String CurrentDateFor2 = dtf2.format(now);
        Constants.DynamicValue.put("<currentDate2>", CurrentDateFor2);

        DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String CurrentDateFor3 = dtf3.format(now);
        Constants.DynamicValue.put("<currentDate3>", CurrentDateFor3);

        DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
        String CurrentDateFor4 = dtf4.format(now);
        Constants.DynamicValue.put("<currentDate4>", CurrentDateFor4);

        return null;
    }

    public static Void CardOrderMappingRandomData() {

        String RandomPubToken = RandomStringUtils.randomNumeric(8);
        Constants.DynamicValue.put("<RandomPubToken>", RandomPubToken);

        Constants.RandomUUID = RandomStringUtils.randomAlphanumeric(30);

        Constants.RandomPtTokenID = RandomStringUtils.randomNumeric(9);
        Constants.DynamicValue.put("<RandomPtTokenID>", Constants.RandomPtTokenID);

        return null;
    }

    public String VerifyDBDetails(String environment, String data, String operationType) throws Exception {
        // For Statement object
        PreparedStatement ps;
        String DB_URL = null;
        // For Database Username
        String DB_USER = null;
        // For Database Password
        String DB_PASSWORD = null;
        //To store OTP
        String Dealid = null;
        String vTradeContractNumber = null;
        String vTradeContactID = null;
        String query = null;
        String value = null;
        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("SITDB_URL") + ":" + Constants.dbconfig.getProperty("SITDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("SITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("TitanUATDB_URL") + ":" + Constants.dbconfig.getProperty("TitanUATDB_PORT");
            DB_USER = Constants.dbconfig.getProperty("TitanUATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("TitanUATDB_Password");
        }

        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        //String dbClass = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
        Class.forName(dbClass).newInstance();

        // Get connection to DB
        LogCapture.info("Get connection to DB");

        try (Connection connection = java.sql.DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            if (connection != null) {
                LogCapture.info("Connected to DB");
            }

            if (operationType.equalsIgnoreCase("FetchTANWithZeroWalletBalance")) {
                query = "Select Top 1 CustomerWallet From Titan.Titan.CustomerwalletBalance where AvailableBalance='0.00' order by CreatedOn desc";
                Statement stmt = connection.createStatement();
                ps = connection.prepareStatement(query);
                //ps.setNString(1, data);
                ResultSet res = stmt.executeQuery(query);

                while (res.next()) {
                    Dealid = res.getString("ID");
                    break;
                    // System.out.println("OTP :" + OTP);
                }
                value = Dealid;
                System.out.println("deal id is" + value);
            }
            if (operationType.equalsIgnoreCase("VerifyPtTokenID")) {
                query = "SELECT ptToken FROM Titan.Titan.CardTransactionMonitoringData where PaymentLifeId = '"+Constants.UniquePaymentLifeCycleId+"'";
                Statement stmt = connection.createStatement();
                ps = connection.prepareStatement(query);
                //ps.setNString(1, data);
                ResultSet res = stmt.executeQuery(query);

                while (res.next()) {
                    Dealid = res.getString("ID");
                    break;
                    // System.out.println("OTP :" + OTP);
                }
                value = Dealid;
                System.out.println("PtToken ID is ["+value+"]");
            }
            if (operationType.equalsIgnoreCase("VerifyPtTokenWallet")) {
                query = "SELECT ptWallet FROM Titan.Titan.CardTransactionMonitoringData where PaymentLifeId = '"+Constants.UniquePaymentLifeCycleId+"'";
                Statement stmt = connection.createStatement();
                ps = connection.prepareStatement(query);
                //ps.setNString(1, data);
                ResultSet res = stmt.executeQuery(query);

                while (res.next()) {
                    Dealid = res.getString("ID");
                    break;
                    // System.out.println("OTP :" + OTP);
                }
                value = Dealid;
                System.out.println("PtToken Wallet is ["+value+"]");
            }
        } catch (Exception e) {
            LogCapture.error("Unable to connect to Database");
        }
        return value;
    }

    public static int getTimeLapsedInSeconds(LocalDateTime localDateTime) {
        return (int) ChronoUnit.SECONDS.between(LocalDateTime.now(), localDateTime);
    }

    public static Properties getProperties(String fileName) {
        Properties properties = null;
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + File.separator + fileName);
            properties = new Properties();
            properties.load(fs);
        } catch (IOException e) {
            LogCapture.error("Exception occurred when loading config file - " + fileName);
        }
        return properties;
    }
//
//    public static String getXpathValue(String inputXml, String xpathStr) {
//        String result;
//        try {
//            XPathFactory xpathFactory = XPathFactory.newInstance();
//            XPath xpathObj = xpathFactory.newXPath();
//            InputSource source = new InputSource(new StringReader(inputXml));
//
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//            DocumentBuilder db = dbf.newDocumentBuilder();
//            Document document = db.parse(source);
//
////            Document doc = xpathObj.evaluate("/", source, XPathConstants.NODE);
//            result = xpathObj.evaluate(xpathStr, document);
//            LogCapture.debug("Value at xml Xpath is " + result);
//        } catch (XPathExpressionException | ParserConfigurationException | IOException | SAXException e) {
//            throw new RuntimeException(e);
//        }
//        return result;
//    }

    public static boolean isNullOrEmpty(String value) {
        return Objects.isNull(value) || value.isEmpty();
    }

    public static boolean isNotNullOrEmpty(String value) {
        return !isNullOrEmpty(value);
    }

    public static Map<String, String> verifyDBDetailsEnhanced(String environment, String data, String operationType) throws Exception {
        String DB_URL = null;
        String DB_USER = null;
        String DB_PASSWORD = null;
        //String value = null;
        Map<String, String> result = new HashMap<>();

        if (environment.equalsIgnoreCase("SIT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("SITDB_URL") + ":" + Constants.dbconfig.getProperty("SITDB_PORT") + ";trustServerCertificate=true";
            DB_USER = Constants.dbconfig.getProperty("SITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("SITDB_Password");

        } else if (environment.equalsIgnoreCase("UAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("UATDB_URL") + ":" + Constants.dbconfig.getProperty("UATDB_PORT") + ";trustServerCertificate=true";
//            + ";integratedSecurity=true;trustServerCertificate=true";
            DB_USER = Constants.dbconfig.getProperty("UATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("UATDB_Password");

        } else if (environment.equalsIgnoreCase("CardsUAT")) {
            DB_URL = "jdbc:sqlserver://" + Constants.dbconfig.getProperty("CardsUAT_URL") + "," + Constants.dbconfig.getProperty("Cards_PORT") + ";integratedSecurity=true;trustServerCertificate=true";
//            DB_USER = Constants.dbconfig.getProperty("CardsUATDB_User");
//            DB_PASSWORD = Constants.dbconfig.getProperty("CardsUATDB_Password");
        }
        else if (environment.equalsIgnoreCase("UAT_Notary")) {
            DB_URL = Constants.dbconfig.getProperty("Notary_UATDB_URL");
            DB_USER = Constants.dbconfig.getProperty("Notary_UATDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("Notary_UATDB_Password");
        }
        else if (environment.equalsIgnoreCase("SIT_Notary")) {
            DB_URL = Constants.dbconfig.getProperty("Notary_SITDB_URL");
            DB_USER = Constants.dbconfig.getProperty("Notary_SITDB_User");
            DB_PASSWORD = Constants.dbconfig.getProperty("Notary_SITDB_Password");
        }
        Constants.connectionUrl = DB_URL;
        Constants.dBUsername = DB_USER;
        Constants.dbPassword = DB_PASSWORD;

        String dbClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        Class.forName(dbClass).newInstance();

        // Get connection to DB
        LogCapture.info("Get connection to DB");

        if (operationType.equalsIgnoreCase("Fetch Latest Account Details")) {
            result = Reusables.getSqlQueryResult("Fetch_Latest_CD_PFX_TAN", data);
        } else if (operationType.equalsIgnoreCase("Fetch Latest Contact Details")) {
            result = Reusables.getSqlQueryResult("Fetch_Latest_CD_PFX_Contact", data);
        } else if (operationType.equalsIgnoreCase("Fetch FundsInDATA")) {
            result = Reusables.getSqlQueryResult("Fetch_FundsInDATA", data);
        } else if (operationType.equalsIgnoreCase("Fetch_Notary_Seller_Details")) {
            result = Reusables.getSqlQueryResult("FetchNotarySellerDetails", data);
        }

        return result;
    }

    public boolean isElementDisplayed(String object, int waitInSeconds) {
        try {
            WebDriverWait w = new WebDriverWait(Constants.driver, Duration.ofSeconds(waitInSeconds));

            w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(object)));
            return true;
        } catch (Exception e) {
        }
        return false;
    }

    public static String GenerateUniquepaymentLifeCycleID() {

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.UniquePaymentLifeCycleId = "AUTO-"+CurrentDateyyyymmdd+"-MARUT"+CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<UniquePaymentLifeID>", Constants.UniquePaymentLifeCycleId);

        return Constants.UniquePaymentLifeCycleId;
    }

        public static JsonPath rawToJason(String response) {
            JsonPath js1 = null;
            try {
                LogCapture.info("-------------Converting to JSON, response => " + response + "--------");
                js1 = new JsonPath(response);
                return (js1);
            } catch (Exception e) {
                LogCapture.info("Error occurred in rawToJason method. The error is: " + e);
                e.printStackTrace();
            }
            return js1;
        }

}
