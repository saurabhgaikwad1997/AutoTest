package com.cucumber.stepdefinition;

import com.selenium.utillity.Constants;
import com.utility.LogCapture;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import static com.selenium.utillity.Constants.driver;
import static com.selenium.utillity.Constants.sqlResult;

public class PropertyPayStepDefination {

    @Then("^User Stores the values captured from the above response$")
    public void userStoresTheValuesCapturedFromTheAboveResponse() {
        JsonPath jp = new JsonPath(Constants.RESPONSE);
        Constants.responseMap.put("title", jp.get("data.title"));
        Constants.responseMap.put("firstName", jp.get("data.firstName"));
        Constants.responseMap.put("middleName", jp.get("data.middleName"));
        Constants.responseMap.put("lastName", jp.get("data.lastName"));
        Constants.responseMap.put("email", jp.get("data.email"));
        Constants.responseMap.put("contactNo", jp.get("data.contactNo"));
        Constants.responseMap.put("titanCustomerNo", jp.get("data.titanCustomerNo"));

        LogCapture.info("---------- Values Fetched from API ----------- ");

        if(Constants.responseMap.size() == 0){
            Assert.assertTrue(false, "****** No Values Found ******");
        }

        for(Map.Entry<String, String> entry :Constants.responseMap.entrySet()){
            LogCapture.info(entry.getKey() + ": " + entry.getValue() );
        }

        LogCapture.info("---------------------*******----------------------------");
    }

    @When("^User Connects with Titan \"([^\"]*)\" DB and Captures the values from ContactTable$")
    public void userConnectsWithTitanDBAndCapturesTheValuesFromContactTable(String Environment ) throws Throwable {
        Constants.key.VerifyDBDetails(Environment,Constants.responseMap.get("email") , "Connection To Contact Table");

        Constants.dbCapturedValues.put("title" , sqlResult.get("Salutation")) ;
        Constants.dbCapturedValues.put("firstName" , sqlResult.get("FirstName")) ;
        Constants.dbCapturedValues.put("middleName" , sqlResult.get("MiddleName")) ;
        Constants.dbCapturedValues.put("lastName" , sqlResult.get("LastName")) ;
        Constants.dbCapturedValues.put("email" , sqlResult.get("Emailaddress")) ;
        Constants.dbCapturedValues.put("contactNo" , sqlResult.get("MobilePhoneNumber")) ;
        Constants.dbCapturedValues.put("titanCustomerNo", sqlResult.get("AccountNumber"));


        LogCapture.info("---------- Values Captured From DB ----------");
        for (Map.Entry<String, String> dbValue : Constants.dbCapturedValues.entrySet()){
            LogCapture.info(dbValue.getKey() +": " + dbValue.getValue());
        }
        LogCapture.info("---------------------*******----------------------------");
        Assert.assertTrue(Constants.responseMap.equals(Constants.dbCapturedValues));
    }

    @Then("^User landed on Homepage Dashboard to verify details$")
    public void userLandedOnHomepageDashboardToVerifyDetails() throws Exception {

        String vobjPropertyPayLogo = Constants.PropertyPayDashboardOR.getProperty("PropertyPayLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPropertyPayLogo, "visible"));
        LogCapture.info("User verified Property Pay logo is visible");

        String vobjSidebarDashboard = Constants.PropertyPayDashboardOR.getProperty("SidebarDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarDashboard, "Dashboard"));
        LogCapture.info("User verified Dashboard option is visible under Sidebar");

        String vobjSidebarContactUs = Constants.PropertyPayDashboardOR.getProperty("SidebarContactUs");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarContactUs, "Contact us"));
        LogCapture.info("User verified Contact us option is visible under Sidebar");

        String vobjSidebarSettings = Constants.PropertyPayDashboardOR.getProperty("SidebarSettings");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarSettings, "Settings"));
        LogCapture.info("User verified Settings option is visible under Sidebar");

        String vobjFooterTerms = Constants.PropertyPayDashboardOR.getProperty("FooterTerms");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterTerms, "Terms"));
        LogCapture.info("User verified Terms option is visible under footer of the Sidebar");

        String vobjFooterPrivacy = Constants.PropertyPayDashboardOR.getProperty("FooterPrivacy");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterPrivacy, "Privacy"));
        LogCapture.info("User verified Privacy option is visible under footer of the Sidebar");

        String vobjFooterCookies = Constants.PropertyPayDashboardOR.getProperty("FooterCookies");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterCookies, "Cookies"));
        LogCapture.info("User verified Cookies option is visible under footer of the Sidebar");

        String vobjFooterRegulatory = Constants.PropertyPayDashboardOR.getProperty("FooterRegulatory");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterRegulatory, "Regulatory"));
        LogCapture.info("User verified Regulatory option is visible under footer of the Sidebar");

        String vobjFooterRedpinLogo = Constants.PropertyPayDashboardOR.getProperty("FooterRedpinLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFooterRedpinLogo, "visible"));
        LogCapture.info("User verified Redpin logo is visible under footer");

        String vobjRecentTransactionsHeader = Constants.PropertyPayDashboardOR.getProperty("RecentTransactionsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRecentTransactionsHeader, "Recent transactions"));
        LogCapture.info("User verified Header as Recent transactions is visible on Dashboard");

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCreateTransactionButton, "Create transaction"));
        LogCapture.info("User verified Create transaction button is visible on Dashboard");

        String vobjUserNameDashboard = Constants.PropertyPayDashboardOR.getProperty("UserNameDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjUserNameDashboard, "Thomas Alva Edison"));
        LogCapture.info("User verified username as Thomas Alva Edison is visible on Dashboard");

        String vobjFirstAndLastNameInitials = Constants.PropertyPayDashboardOR.getProperty("FirstAndLastNameInitials");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFirstAndLastNameInitials, "TE"));
        LogCapture.info("User verified Initials of First name and last name as TE is visible on Dashboard");

        String vobjDashboardColumnHeaderTransactionsDetails = Constants.PropertyPayDashboardOR.getProperty("DashboardColumnHeaderTransactionsDetails");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardColumnHeaderTransactionsDetails, "Transaction details"));
        LogCapture.info("User verified column header as Transaction details is visible on Dashboard");

        String vobjDashboardColumnHeaderPartyName = Constants.PropertyPayDashboardOR.getProperty("DashboardColumnHeaderPartyName");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardColumnHeaderPartyName, "Party name"));
        LogCapture.info("User verified column header as Party name is visible on Dashboard");

        String vobjDashboardColumnHeaderStatus = Constants.PropertyPayDashboardOR.getProperty("DashboardColumnHeaderStatus");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardColumnHeaderStatus, "Status"));
        LogCapture.info("User verified column header as Status is visible on Dashboard");

        String vobjDashboardColumnHeaderCompletionDue = Constants.PropertyPayDashboardOR.getProperty("DashboardColumnHeaderCompletionDue");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardColumnHeaderCompletionDue, "Completion due"));
        LogCapture.info("User verified column header as Completion due is visible on Dashboard");

        String vobjDashboardFilterAll = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterAll");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterAll, "All"));
        LogCapture.info("User verified filter for All transactions is visible on Dashboard");

        String vobjDashboardFilterOpen = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterOpen");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterOpen, "Open"));
        LogCapture.info("User verified filter for Open transactions is visible on Dashboard");

        String vobjDashboardFilterCompleted = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterCompleted");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterCompleted, "Completed"));
        LogCapture.info("User verified filter for Completed transactions is visible on Dashboard");

        String vobjDashboardFilterCancelled = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterCancelled");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterCancelled, "Cancelled"));
        LogCapture.info("User verified filter for Cancelled transactions is visible on Dashboard");

        String vobjDashboardFilterDraft = Constants.PropertyPayDashboardOR.getProperty("DashboardFilterDraft");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjDashboardFilterDraft, "Draft"));
        LogCapture.info("User verified filter for Draft transactions is visible on Dashboard");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String currentTime = now.format(timeFormatter);

        LocalTime GoodNightstartTime = LocalTime.of(00, 00, 01); // 00:00:01
        LocalTime GoodNightendTime = LocalTime.of(05, 59, 59);  // 05:59:59

        LocalTime GoodMorningstartTime = LocalTime.of(06, 00, 01); // 06:00:01
        LocalTime GoodMorningendTime = LocalTime.of(11, 59, 59);  // 11:59:59
        LocalTime currentLocalTime = LocalTime.parse(currentTime, timeFormatter);

        LocalTime GoodAfternoonstartTime = LocalTime.of(12, 0, 01); // 12:00:01
        LocalTime GoodAfternoonendTime = LocalTime.of(17, 59, 59);  // 17:59:59

        LocalTime GoodEveningstartTime = LocalTime.of(18, 0, 01); // 18:00:01
        LocalTime GoodEveningendTime = LocalTime.of(23, 59, 59);  // 23:59:59

        String vObjDashboardGreetingMessage = Constants.PropertyPayDashboardOR.getProperty("DashboardGreetingMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDashboardGreetingMessage, ""));
        String greetingMessage = Constants.driver.findElement(By.xpath(vObjDashboardGreetingMessage)).getText();

        // Compare current time within the range
        if (currentLocalTime.isAfter(GoodNightstartTime) && currentLocalTime.isBefore(GoodNightendTime)) {

            if(greetingMessage.contains("Good night"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Night");
                Assert.fail();
            }

        }

        if (currentLocalTime.isAfter(GoodMorningstartTime) && currentLocalTime.isBefore(GoodMorningendTime)) {

            if(greetingMessage.contains("Good morning"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Morning");
                Assert.fail();
            }
        }

        if (currentLocalTime.isAfter(GoodAfternoonstartTime) && currentLocalTime.isBefore(GoodAfternoonendTime)) {

            if(greetingMessage.contains("Good afternoon"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Afternoon");
                Assert.fail();
            }
        }

        if (currentLocalTime.isAfter(GoodEveningstartTime) && currentLocalTime.isBefore(GoodEveningendTime)) {

            if(greetingMessage.contains("Good evening"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Evening");
                Assert.fail();
            }
        }



    }

    @Then("^User landed on Homepage Dashboard to verify details in Mobile view$")
    public void userLandedOnHomepageDashboardToVerifyDetailsInMobileView() throws Exception {

        String vobjPropertyPayLogo = Constants.PropertyPayDashboardOR.getProperty("PropertyPayLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPropertyPayLogo, "visible"));
        LogCapture.info("User verified Property Pay logo is visible");

        String vobjRecentTransactionsHeader = Constants.PropertyPayDashboardOR.getProperty("RecentTransactionsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRecentTransactionsHeader, "Recent transactions"));
        LogCapture.info("User verified Header as Recent transactions is visible on Dashboard");

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCreateTransactionButton, "Create transaction"));
        LogCapture.info("User verified Create transaction button is visible on Dashboard");

        String vobjHeaderMenuIcon = Constants.PropertyPayDashboardOR.getProperty("HeaderMenuIcon");
        Assert.assertEquals("PASS", Constants.key.click(vobjHeaderMenuIcon, ""));
        LogCapture.info("User click on Header Menu Icon");

        String vobjSidebarDashboard = Constants.PropertyPayDashboardOR.getProperty("SidebarDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarDashboard, "Dashboard"));
        LogCapture.info("User verified Dashboard option is visible under Sidebar");

        String vobjSidebarContactUs = Constants.PropertyPayDashboardOR.getProperty("SidebarContactUs");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarContactUs, "Contact us"));
        LogCapture.info("User verified Contact us option is visible under Sidebar");

        String vobjSidebarSettings = Constants.PropertyPayDashboardOR.getProperty("SidebarSettings");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarSettings, "Settings"));
        LogCapture.info("User verified Settings option is visible under Sidebar");

        String vobjUserNameDashboardMobile = Constants.PropertyPayDashboardOR.getProperty("UserNameDashboardMobile");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjUserNameDashboardMobile, "Thomas Alva Edison"));
        LogCapture.info("User verified username as Thomas Alva Edison is visible on Dashboard");

        String vobjFirstAndLastNameInitialsMobile = Constants.PropertyPayDashboardOR.getProperty("FirstAndLastNameInitialsMobile");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFirstAndLastNameInitialsMobile, "TE"));
        LogCapture.info("User verified Initials of First name and last name as TE is visible on Dashboard");

        String vobjCloseSidebarMobile = Constants.PropertyPayDashboardOR.getProperty("CloseSidebarMobile");
        Assert.assertEquals("PASS", Constants.key.click(vobjCloseSidebarMobile, ""));
        LogCapture.info("User click on Close sidebar button");

        String vobjMobileViewFilter = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilter");
        Assert.assertEquals("PASS", Constants.key.click(vobjMobileViewFilter, ""));
        LogCapture.info("User click on Filter button");

        String vobjMobileViewFilterList = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilterList");
        List<WebElement> elements = driver.findElements(By.xpath(vobjMobileViewFilterList));
        int numberOfElements = elements.size();

        for(int i=1; i<=numberOfElements; i++)
        {
            String FilterOptions = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li["+i+"]";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();

            if(ActualFilterOptions.equals("All") || ActualFilterOptions.equals("Open") || ActualFilterOptions.equals("Completed") || ActualFilterOptions.equals("Cancelled") || ActualFilterOptions.equals("Draft"))
            {
                LogCapture.info("User verified filter "+i+" with search option "+ActualFilterOptions+" is Present");
            }else
            {
                LogCapture.info("TC FailedUser verified filter with search option "+ActualFilterOptions+" is not Present");
                Assert.fail();
            }
        }

        String vobjMobileSearchBar = Constants.PropertyPayDashboardOR.getProperty("MobileSearchBar");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjMobileSearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileSearchBar, ""));
        LogCapture.info("User click on Search bar");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjMobileSearchBar, "REF98785"));
        LogCapture.info("User entered value as REF98785 in search bar ");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileSearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vobjMobileSearchBar));
        LogCapture.info("User Cleared value from search bar ");



    }

    @Then("^User landed on Homepage Dashboard to verify details in Tablet view$")
    public void userLandedOnHomepageDashboardToVerifyDetailsInTabletView() throws Exception {

        String vobjPropertyPayLogo = Constants.PropertyPayDashboardOR.getProperty("PropertyPayLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjPropertyPayLogo, "visible"));
        LogCapture.info("User verified Property Pay logo is visible");

        String vobjTabletToggleBarExpansion = Constants.PropertyPayDashboardOR.getProperty("TabletToggleBarExpansion");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTabletToggleBarExpansion, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTabletToggleBarExpansion, ""));
        LogCapture.info("User click on expand sidebar in tablet view");

        String vobjSidebarDashboard = Constants.PropertyPayDashboardOR.getProperty("SidebarDashboard");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSidebarDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarDashboard, "Dashboard"));
        LogCapture.info("User verified Dashboard option is visible under Sidebar");

        String vobjSidebarContactUs = Constants.PropertyPayDashboardOR.getProperty("SidebarContactUs");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarContactUs, "Contact us"));
        LogCapture.info("User verified Contact us option is visible under Sidebar");

        String vobjSidebarSettings = Constants.PropertyPayDashboardOR.getProperty("SidebarSettings");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjSidebarSettings, "Settings"));
        LogCapture.info("User verified Settings option is visible under Sidebar");

        String vobjFooterTerms = Constants.PropertyPayDashboardOR.getProperty("FooterTerms");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterTerms, "Terms"));
        LogCapture.info("User verified Terms option is visible under footer of the Sidebar");

        String vobjFooterPrivacy = Constants.PropertyPayDashboardOR.getProperty("FooterPrivacy");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterPrivacy, "Privacy"));
        LogCapture.info("User verified Privacy option is visible under footer of the Sidebar");

        String vobjFooterCookies = Constants.PropertyPayDashboardOR.getProperty("FooterCookies");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterCookies, "Cookies"));
        LogCapture.info("User verified Cookies option is visible under footer of the Sidebar");

        String vobjFooterRegulatory = Constants.PropertyPayDashboardOR.getProperty("FooterRegulatory");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFooterRegulatory, "Regulatory"));
        LogCapture.info("User verified Regulatory option is visible under footer of the Sidebar");

        String vobjFooterRedpinLogo = Constants.PropertyPayDashboardOR.getProperty("FooterRedpinLogo");
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vobjFooterRedpinLogo, "visible"));
        LogCapture.info("User verified Redpin logo is visible under footer");

        String vobjTabletToggleBarClosure = Constants.PropertyPayDashboardOR.getProperty("TabletToggleBarClosure");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjTabletToggleBarClosure, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjTabletToggleBarClosure, ""));
        LogCapture.info("User click on Close sidebar in tablet view");

        String vobjRecentTransactionsHeader = Constants.PropertyPayDashboardOR.getProperty("RecentTransactionsHeader");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjRecentTransactionsHeader, "Recent transactions"));
        LogCapture.info("User verified Header as Recent transactions is visible on Dashboard");

        String vobjCreateTransactionButton = Constants.PropertyPayDashboardOR.getProperty("CreateTransactionButton");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjCreateTransactionButton, "Create transaction"));
        LogCapture.info("User verified Create transaction button is visible on Dashboard");

        String vobjUserNameDashboard = Constants.PropertyPayDashboardOR.getProperty("UserNameDashboard");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjUserNameDashboard, "Thomas Alva Edison"));
        LogCapture.info("User verified username as Thomas Alva Edison is visible on Dashboard");

        String vobjFirstAndLastNameInitials = Constants.PropertyPayDashboardOR.getProperty("FirstAndLastNameInitials");
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjFirstAndLastNameInitials, "TE"));
        LogCapture.info("User verified Initials of First name and last name as TE is visible on Dashboard");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String currentTime = now.format(timeFormatter);

        LocalTime GoodNightstartTime = LocalTime.of(00, 00, 01); // 00:00:01
        LocalTime GoodNightendTime = LocalTime.of(05, 59, 59);  // 05:59:59

        LocalTime GoodMorningstartTime = LocalTime.of(06, 00, 01); // 06:00:01
        LocalTime GoodMorningendTime = LocalTime.of(11, 59, 59);  // 11:59:59
        LocalTime currentLocalTime = LocalTime.parse(currentTime, timeFormatter);

        LocalTime GoodAfternoonstartTime = LocalTime.of(12, 0, 01); // 12:00:01
        LocalTime GoodAfternoonendTime = LocalTime.of(17, 59, 59);  // 17:59:59

        LocalTime GoodEveningstartTime = LocalTime.of(18, 0, 01); // 18:00:01
        LocalTime GoodEveningendTime = LocalTime.of(23, 59, 59);  // 23:59:59

        String vObjDashboardGreetingMessage = Constants.PropertyPayDashboardOR.getProperty("DashboardGreetingMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDashboardGreetingMessage, ""));
        String greetingMessage = Constants.driver.findElement(By.xpath(vObjDashboardGreetingMessage)).getText();

        // Compare current time within the range
        if (currentLocalTime.isAfter(GoodNightstartTime) && currentLocalTime.isBefore(GoodNightendTime)) {

            if(greetingMessage.contains("Good night"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Night");
                Assert.fail();
            }

        }

        if (currentLocalTime.isAfter(GoodMorningstartTime) && currentLocalTime.isBefore(GoodMorningendTime)) {

            if(greetingMessage.contains("Good morning"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Morning");
                Assert.fail();
            }
        }

        if (currentLocalTime.isAfter(GoodAfternoonstartTime) && currentLocalTime.isBefore(GoodAfternoonendTime)) {

            if(greetingMessage.contains("Good afternoon"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Afternoon");
                Assert.fail();
            }
        }

        if (currentLocalTime.isAfter(GoodEveningstartTime) && currentLocalTime.isBefore(GoodEveningendTime)) {

            if(greetingMessage.contains("Good evening"))
            {
                System.out.println("User verified greeting message as " +greetingMessage);
            }
            else
            {
                System.out.println("TC Failed : User unable to verify Greeting message for Evening");
                Assert.fail();
            }
        }


        String vobjMobileViewFilter = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilter");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileViewFilter, ""));
        LogCapture.info("User click on Filter button");

        String vobjMobileViewFilterList = Constants.PropertyPayDashboardOR.getProperty("MobileViewFilterList");
        List<WebElement> elements = driver.findElements(By.xpath(vobjMobileViewFilterList));
        int numberOfElements = elements.size();

        for(int i=1; i<=numberOfElements; i++)
        {
            String FilterOptions = "//ul[@class='MuiAutocomplete-listbox css-fgzeft']//li["+i+"]";
            Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(FilterOptions, ""));
            String ActualFilterOptions = Constants.driver.findElement(By.xpath(FilterOptions)).getText();

            if(ActualFilterOptions.equals("All") || ActualFilterOptions.equals("Open") || ActualFilterOptions.equals("Completed") || ActualFilterOptions.equals("Cancelled") || ActualFilterOptions.equals("Draft"))
            {
                LogCapture.info("User verified filter "+i+" with search option "+ActualFilterOptions+" is Present");
            }else
            {
                LogCapture.info("TC FailedUser verified filter with search option "+ActualFilterOptions+" is not Present");
                Assert.fail();
            }
        }

        String vobjMobileSearchBar = Constants.PropertyPayDashboardOR.getProperty("MobileSearchBar");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjMobileSearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileSearchBar, ""));
        LogCapture.info("User click on Search bar");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vobjMobileSearchBar, "REF98785"));
        LogCapture.info("User entered value as REF98785 in search bar ");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjMobileSearchBar, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vobjMobileSearchBar));
        LogCapture.info("User Cleared value from search bar ");

    }



}
