package com.cucumber.stepdefinition;


import com.selenium.utillity.Constants;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;
import com.utility.LogCapture;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.selenium.utillity.Constants.*;
import static com.selenium.utillity.Constants.NOTUniqueReferenceId;

public class NotaryStepDefination {
    String ExpNumberOfTransactions;
    String ExpCardSpendTxnAmount;


    String SellerBen1;
    String SellerBen2;
    String SellerBen3;
    String SellerBen4;
    String SellerBen5;
    String SellerBen6;
    String BuyerBen1;
    String BuyerBen2;
    String BuyerBen3;
    String BuyerBen4;
    String BuyerBen5;
    String BuyerBen6;
    String TPALang;
    String DocuSignformsLang;
    int NoofSellerBeni;
    int NoofBuyerBeni;
    int Amount1;
    int Amount2;
    int Amount3;
    int finaldisAmount;
    Float CardBilling_Amount;
    String Pdfdownload;
    String   languageverification;


    public static String generateRandomName() {
        Random rand = new Random();
        StringBuilder name = new StringBuilder();

        // Generating a random name with 5 characters
        for (int i = 0; i < 5; i++) {
            char randomChar = (char) ('a' + rand.nextInt(26));
            name.append(randomChar);
        }

        return name.toString();
    }


    public static int generateRandomThreeDigitNumber() {
        Random rand = new Random();
        // Generate a random number between 100 and 999
        return rand.nextInt(900) + 100;
    }


    @Given("^User launched application through \"([^\"]*)\" in \"([^\"]*)\" view$")
    public void userLaunchedApplicationThroughInView(String data, String view) throws Throwable {
        String vBrowser = Constants.CONFIG.getProperty(data);
        LogCapture.info(data + " Application is launching....");
        String vView = "";
        if (view.equals("View")) {
            LogCapture.info("Value of View is picked up from Config");
            vView = Constants.CONFIG.getProperty(view);
            LogCapture.info("Opening browser in " + vView + " view");
        } else if (view.contains("Mobile") || view.contains("Tablet") || view.contains("Desktop")) {
            LogCapture.info("Browser will open in " + view);
            vView = view;
            LogCapture.info("Successfully overridden the config view value with parameterised view value");
            LogCapture.info("Opening browser in " + vView + " view");
        }
        Constants.VIEW = vView;
        //Constants.JenkinsBrowser = (Objects.equals(Constants.JenkinsBrowser, "null")) ? "" : "";
        try {
            if (Objects.equals(Constants.JenkinsBrowser, null)) {
                Constants.JenkinsBrowser = "";
            } else if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                vBrowser = Constants.JenkinsBrowser;
                LogCapture.info("Browser is : " + Constants.JenkinsBrowser);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Assert.assertTrue(Constants.key.openBrowser(vView, vBrowser));
        LogCapture.info("Browser is : " + vBrowser);
    }

    @And("^User navigate to (Registration CD portal|Registration TORFX portal|Registration TORAU portal|KYC Loader Page|Account Error Page|Landing Page|Register Page|XFrame Checker Site|RAF Expired Screen|Landing page from RAF Link) \"([^\"]*)\"$")
    public void userNavigateToRegistrationCDPortal(String pageType, String pageURL) throws Throwable {
        LogCapture.info(pageType + " is loading....");
        String url = Constants.CONFIG.getProperty(pageURL);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.AcceptCookies());
        LogCapture.info(pageType + " successfully loaded....");

    }


    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for (Enterprise|Titan|Notary)$")
    public void forACallUserCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String enviroment, String App) throws Throwable {
        //Constants.APIkey.checkNotEnabled(testCaseID);
        DynamicValue.put("<PayeeID>", NOTPayeeID);
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate errorCode \"([^\"]*)\" errorDescription \"([^\"]*)\" and fileUploadStatus as \"([^\"]*)\"$")
    public void userValidateErrorCodeErrorDescriptionAndFileUploadStatusAs(String errorCode, String errorDescription, String fileUploadStatus) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(errorCode, jp.get("errorCode")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(errorDescription, jp.get("errorDescription")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(fileUploadStatus, jp.get("fileUploadStatus")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Capture (Document ID) \"([^\"]*)\" form Response and update in OnTheyFly property$")
    public void userCaptureDocumentIDFormResponseAndUpdateInOnTheyFlyProperty(String arg, String property) throws Throwable {
        // This will get the value of Specified Properties from Constants.RESPONSE and update the same in dynamicConfig.properties and HashMap so that we can use this in later execution
        ReusableMethod.UpdateSpecificProperties(property);
    }

    @And("^From \"([^\"]*)\" User get (Document Name) \"([^\"]*)\" for API Body$")
    public void fromUserGetDocumentNameForAPIBody(String testCaseID, String arg1, String key) throws Throwable {
        Constants.apiBodyValue = ReusableMethod.getSpecificProperties(testCaseID, key);
    }

    @Given("^User \"([^\"]*)\" from API \"([^\"]*)\" call for \"([^\"]*)\" and observed status code as \"([^\"]*)\"$")
    public void userFromAPICallForAndObservedStatusCodeAs(String actionType, String methodType, String testCaseID, String statCode) throws Throwable {
        Constants.TCCaseID = testCaseID;
        LogCapture.info("----------------Started API calls for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate Description \"([^\"]*)\" and Code \"([^\"]*)\" and api response status \"([^\"]*)\"$")
    public void userValidateDescriptionAndCodeAndApiResponseStatus(String code, String description, String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("api_status.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("api_status.description")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("api_response.status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Description \"([^\"]*)\" and Code \"([^\"]*)\"$")
    public void userValidateDescriptionAndCode(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("api_status.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("api_status.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User validate \"([^\"]*)\"$")
    public void userValidate(String comment) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(comment, jp.get("api_response.comment")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User validate recommended BIC field \"([^\"]*)\"$")
    public void userValidateRecommendedBICField(String recBIC) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(recBIC, jp.get("api_response.recommendedBIC")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }


    @Then("^User validate status \"([^\"]*)\"$")
    public void userValidateStatus(String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validates response_code \"([^\"]*)\" and response_status \"([^\"]*)\"$")
    public void userValidatesResponse_codeAndResponse_status(String response_code, String response_status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_status, jp.get("response_status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^user validate the city \"([^\"]*)\" and country \"([^\"]*)\"$")
    public void userValidateTheCityAndCountry(String city, String country) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(city, jp.get("ipCity")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(country, jp.get("ipCountry")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate city \"([^\"]*)\"$")
    public void userValidateCity(String city) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(city, jp.get("city")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate status \"([^\"]*)\" and code \"([^\"]*)\"$")
    public void userValidateStatusAndCode(String status, String code) throws Throwable {
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\"$")
    public void userValidateResponseCodeAndResponseDescription(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response_description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validates response_code \"([^\"]*)\"$")
    public void userValidatesResponse_code(String response_code) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate errorCode \"([^\"]*)\" errorDescription \"([^\"]*)\"$")
    public void userValidateErrorCodeErrorDescription(String errorCode, String errorDescription) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(errorCode, jp.get("errorCode")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(errorDescription, jp.get("errorDescription")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate status_code \"([^\"]*)\" status_description \"([^\"]*)\"$")
    public void userValidateStatus_codeStatus_description(String status_code, String status_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(status_code, jp.get("status_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(status_description, jp.get("status_description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\"$")
    public void userValidateCodeAndDescription(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the soap service$")
    public void userValidateCodeAndDescriptionForTheSoapService(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.result.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.result.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the soap service for fee management$")
    public void userValidateCodeAndDescriptionForTheSoapServiceForFeeManagement(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getPaymentFeesResponse.PaymentFeeServiceResponse.result.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getPaymentFeesResponse.PaymentFeeServiceResponse.result.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for Apply Financials$")
    public void userValidateCodeAndDescriptionForApplyFinancials(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getValidateBankDetailsResponse.ResponseStatusHeader.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getValidateBankDetailsResponse.ResponseStatusHeader.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate status \"([^\"]*)\" for DNB Service$")
    public void userValidateStatusForDNBService(String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("company_detail.status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and status \"([^\"]*)\"$")
    public void userValidateCodeAndStatus(String code, String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate response code \"([^\"]*)\" and response message \"([^\"]*)\"$")
    public void userValidateResponseCodeAndResponseMessage(String code, String message) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(message, jp.get("response_message")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate uploaded Document ID from the api response$")
    public void userValidateUploadedDocumentIDFromTheApiResponse() {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        List AllDoc = jp.getList("documentList.document_id");
        String docID = Constants.DynamicValue.get("<document_id>");
        boolean Flag = false;
        for (Object doc : AllDoc) {
            String doc1 = doc.toString();
            if (doc1.equals(docID)) {
                Flag = true;
                break;
            }
        }
        Assert.assertTrue(Flag);

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the cancel quote$")
    public void userValidateCodeAndDescriptionForTheCancelQuote(String response_code, String response_description) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("resp_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("resp_desc")));
        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for the cancel quote$")
    public void userValidateResponseCodeAndResponseDescriptionForTheCancelQuote(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("fx_deal.response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("fx_deal.response_description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }


    @Then("^User check Quote id and store Quote id$")
    public void userCheckQuoteIdAndStoreQuoteId() {
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        ReusableMethod.updateConfig("<quote_id>", jp.get("create_quote.quote_id"));
    }

    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for subscribe rate alert$")
    public void userValidateResponseCodeAndResponseDescriptionForSubscribeRateAlert(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        ReusableMethod.updateConfig("<subscription_id>", Integer.toString(jp.get("subscription_details.subscription_id")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for Get Subscription rate alert$")
    public void userValidateResponseCodeAndResponseDescriptionForGetSubscriptionRateAlert(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User verify latest quote rate$")
    public void userVerifyLatestQuoteRate() {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(jp.get("latest_quote.quote_rate"), jp.get("latest_quote.quote_rate")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User Verify \"([^\"]*)\" from responce body$")
    public void userVerifyFromResponceBody(String liveRate) throws Throwable {
        LogCapture.info("----------------Response Validations Live Rate Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        String res = xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.debug");
        res = res.split(",")[0].split(":")[1];
        Assert.assertEquals(true, res.startsWith(liveRate));
        LogCapture.info("----------------Response Validations Live Rate Ended-------------------");
    }

    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Currency Pair \"([^\"]*)\"$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForCurrencyPair(String methodType, String statCode, String testCaseID, String enviroment, String App) throws Throwable {
        Constants.TCCaseID = testCaseID;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            if (Constants.DynamicValue.containsKey("CurrencyPair")) {
                Constants.DynamicValue.replace("CurrencyPair", Constants.DynamicValue.get("CurrencyPair"), App);
            } else {
                Constants.DynamicValue.put("CurrencyPair", App);
            }
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            LogCapture.info("---------------POST call ended----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User validate Quote \"([^\"]*)\" from response body$")
    public void userValidateQuoteFromResponseBody(String qutRate) throws Throwable {
        LogCapture.info("----------------Response Validations Live Rate Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        String res = xml.get("Envelope.Body.getRateSingularResponse.return");
        JsonPath jp = Constants.APIkey.rawToJson(res);
        res = jp.get("Result.Quote");
        Assert.assertEquals(true, res.startsWith(qutRate));
        LogCapture.info("----------------Response Validations Live Rate Ended-------------------");
    }


    @Given("^User Generate Token from API \"([^\"]*)\" call for \"([^\"]*)\" on \"([^\"]*)\" and observed status code as \"([^\"]*)\"$")
    public void userGenerateTokenFromAPICallForOnAndObservedStatusCodeAs(String methodType, String testCaseID, String Environment, String statCode) throws Throwable {
        Constants.TCCaseID = testCaseID;
        LogCapture.info("----------------Started API calls for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls for testcase ID " + testCaseID + "---------------------");

    }


    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and \"([^\"]*)\" for get balance API$")
    public void userValidateStatusDescriptionAndStatusCodeAndForGetBalanceAPI(String ResponseDescription, String ResponseCode, String CCY) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String RespActBal = Float.toString(jp.get("actualBalance"));
        String RespAvailBal = Float.toString(jp.get("availableBalance"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(jp.get("currency"), CCY));
        LogCapture.info("-------------User verified Currency as >> " + jp.get("currency"));

        LogCapture.info("-------------Able to see Actual balance >> " + RespActBal);
        LogCapture.info("-------------Able to see Available balance >> " + RespAvailBal);

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" (for unsupported currency|when date is missing)$")
    public void userValidateStatusDescriptionAndStatusCodeForUnsupportedCurrency(String ResponseDescription, String ResponseCode, String MissingField) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for invalid (customer reference|contact ID)$")
    public void userValidateStatusDescriptionAndStatusCodeForInvalidCustomerReference(String ResponseDescription, String ResponseCode, String InvalidField) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when base currency is missing$")
    public void userValidateStatusDescriptionAndStatusCodeWhenBaseCurrencyIsMissing(String ResponseDescription, String ResponseCode) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\"$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmount(String ResponseCode, String ResponseDescription, String BLKCCY, String BLKAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY = Constants.OnTheFlyValue.getProperty(BLKCCY);
        String Amount = Constants.OnTheFlyValue.getProperty(BLKAmount);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("blockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, Amount));
        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("blockedAmount.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (customer reference number|fee currency|PaymentLifeCycleID field|Wallet currency|Base Currency) is missing$")
    public void userValidateStatusDescriptionAndStatusCodeWhenCustomerReferenceNumberIsMissing(String ResponseDescription, String ResponseCode, String MissingField) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when amount to (block|Credit|Debit) is missing$")
    public void userValidateStatusDescriptionAndStatusCodeWhenAmountToBlockIsMissing(String ResponseDescription, String ResponseCode, String AmtType) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (amountToBlock|amountToCredit|amountToDebit) currency is null$")
    public void userValidateStatusDescriptionAndStatusCodeWhenAmountToBlockCurrencyIsNull(String ResponseDescription, String ResponseCode, String AmtType) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (base currency|decline code|decline reason|Contact ID) field is null$")
    public void userValidateStatusDescriptionAndStatusCodeWhenBaseCurrencyFieldIsNull(String ResponseDescription, String ResponseCode, String Fieldtype) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" and Unblocked amount \"([^\"]*)\"$")
    public void userValidateThenVerifyUnblockedAmountCurrencyAndUnblockedAmount(String ResponseCode, String ResponseDescription, String BLKCCY, String BLKAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY = Constants.OnTheFlyValue.getProperty(BLKCCY);
        String Amount = Constants.OnTheFlyValue.getProperty(BLKAmount);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("unblockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, Amount));
        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("unblockedAmount.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when PaymentLifeCycleID field is null$")
    public void userValidateStatusDescriptionAndStatusCodeWhenPaymentLifeCycleIDFieldIsNull(String ResponseDescription, String ResponseCode) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when wallet balance is not present$")
    public void userValidateStatusDescriptionAndStatusCodeWhenWalletBalanceIsNotPresent(String ResponseDescription, String ResponseCode) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" Unblocked amount \"([^\"]*)\" and Debited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyUnblockedAmountCurrencyUnblockedAmountAndDebitedAmount(String ResponseCode, String ResponseDescription, String CKBLKCCY, String CKBLKAmount, String CKBLKDebitedAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);


        String CCY = Constants.OnTheFlyValue.getProperty(CKBLKCCY);
        String Amount = Constants.OnTheFlyValue.getProperty(CKBLKAmount);
        String DebitedAmount = Constants.OnTheFlyValue.getProperty(CKBLKDebitedAmount);


        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified UnblockedAmount Currency as >> " + jp.get("unblockedAmount.amount"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, Amount));
        LogCapture.info("-------------User verified Unblocked amount as >> " + jp.get("unblockedAmount.amount"));

        String DebitedAmt = def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(DebitedAmt, DebitedAmount));
        LogCapture.info("-------------User verified Debited amount as >> " + jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Credited Currency \"([^\"]*)\" and Credited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyAmountCreditedCurrencyAndCreditedAmount(String ResponseCode, String ResponseDescription, String CRDCCY, String CRDAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY = Constants.OnTheFlyValue.getProperty(CRDCCY);
        String Amount = Constants.OnTheFlyValue.getProperty(CRDAmount);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("amountCredited.currency")));
        LogCapture.info("-------------User verified amount Credited Currency as >> " + jp.get("amountCredited.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String CreditedAmt = def.format(jp.get("amountCredited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(CreditedAmt, Amount));
        LogCapture.info("-------------User verified amount Credited as >> " + jp.get("amountCredited.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Debited Currency \"([^\"]*)\" and Debited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyAmountDebitedCurrencyAndDebitedAmount(String ResponseCode, String ResponseDescription, String DebitedCCY, String DebitedAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY = Constants.OnTheFlyValue.getProperty(DebitedCCY);
        String Amount = Constants.OnTheFlyValue.getProperty(DebitedAmount);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified amount Debited Currency as >> " + jp.get("amountDebited.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String DebitedAmt = def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(DebitedAmt, Amount));
        LogCapture.info("-------------User verified amount Debited as >> " + jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" (for decline card transaction|For Send money)$")
    public void userValidateForDeclineCardTransaction(String ResponseCode, String ResponseDescription, String data) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify account_number\"([^\"]*)\" Organization \"([^\"]*)\" and PaymentLifeCycleID \"([^\"]*)\" details$")
    public void userValidateThenVerifyAccount_numberOrganizationAndPaymentLifeCycleIDDetails(String ResponseCode, String ResponseDescription, String ActivityTAN, String ActivityOrganization, String ActivityPamentLifeCycleID) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String TAN = Constants.OnTheFlyValue.getProperty(ActivityTAN);
        String Organization = Constants.OnTheFlyValue.getProperty(ActivityOrganization);
        String PamentLifeCycleID = Constants.OnTheFlyValue.getProperty(ActivityPamentLifeCycleID);

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"), ResponseDescription);
        LogCapture.info("User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals(jp.get("org_code"), Organization);
        Assert.assertEquals(jp.get("contract_note_search_criteria.filter.organization[0]"), Organization);
        LogCapture.info("User verified Organization as >> " + jp.get("org_code"));

        Assert.assertEquals(jp.get("card_activity_history_details[0].cdPaymentLifecycleId"), PamentLifeCycleID);

        LogCapture.info("User verified Instruction Number as >> " + jp.get("card_activity_history_details[0].instruction_number"));

        Assert.assertEquals(jp.get("account_number"), TAN);
        LogCapture.info("User verified account number as >> " + jp.get("account_number"));

        LogCapture.info("User verified transaction Date as >> " + jp.get("card_activity_history_details[0].transactionDate"));
        LogCapture.info("User verified merchant Name as >> " + jp.get("card_activity_history_details[0].merchantName"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for (invalid organization code|Organization Code is Missing|invalid PaymentlifeCycle ID)$")
    public void userValidateStatusDescriptionAndStatusCodeForInvalidOrganizationCode(String ResponseDescription, String ResponseCode, String OrgCodetype) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }


    @Given("^User Generate Token for Titan Card API Validation from \"([^\"]*)\" for Titan-Card Application$")
    public void userGenerateTokenForTitanCardAPIValidationFromForTitanCardApplication(String tcID) throws Throwable {
        LogCapture.info("--------------Token Generation started for testcase ID " + tcID + "---------------");
        Constants.RESPONSE = ServiceMethod.post(tcID, "200");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Constants.ACCESS_TOKEN = jp.get("access_token");
        LogCapture.info("--------------Token Generation ended--------------");
        LogCapture.info("--------------Token Generation ended for testcase ID " + tcID + "--------------");
        key.pause("2", "");

    }


    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Contact ID \"([^\"]*)\"$")
    public void userValidateThenVerifyContactID(String ResponseCode, String ResponseDescription, String CardOrderContactID) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String ContactID = Constants.OnTheFlyValue.getProperty(CardOrderContactID);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        String ContactId = Integer.toString(jp.get("contact_id"));
        Assert.assertEquals(ContactId, ContactID);
        LogCapture.info(".............User verified Contact ID as >> " + ContactId);

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Given("^User connects to Titan UAT DB and fetches the Customer (TAN) having zero wallet balance$")
    public void userConnectsToTitanUATDBAndFetchesTheCustomerHavingZeroWalletBalance(String TitanAccountNumber) throws Exception {

        TitanAccountNumber = Constants.APIkey.VerifyDBDetails("UAT", "", "FetchTANWithZeroWalletBalance");
        Constants.APIkey.VerifyDBDetails("UAT", "", "Fetch TitanAccountNumber");
        System.out.println("Titan Account Number having zero wallet balance : " + TitanAccountNumber);
    }


    @Given("^User connects to Titan UAT DB and verify the PtToken ID and PtToken Wallet fields on titan database$")
    public void userConnectsToTitanUATDBAndVerifyThePtTokenIDAndPtTokenWalletFieldsOnTitanDatabase() throws Exception {

        String ActPtTokenID = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyPtTokenID");
        String ExpPtTokenID = Constants.RandomPtTokenID;
        if (ActPtTokenID.equals(ExpPtTokenID)) {
            LogCapture.info("User verified PtToken ID stored in Titan DB as >> " + ActPtTokenID);
        } else {
            LogCapture.info("TC Failed : PtToken ID Not stored in Titan DB >> " + ActPtTokenID);
            Assert.fail();
        }

        String ActPtTokenWallet = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyPtTokenWallet");
        String ExpPtTokenWallet = Constants.OnTheFlyValue.getProperty("<PtTokenWallet1>");
        if (ActPtTokenWallet.equals(ExpPtTokenWallet)) {
            LogCapture.info("User verified PtToken Wallet stored in Titan DB as >> " + ActPtTokenWallet);
        } else {
            LogCapture.info("TC Failed : PtToken Wallet Not stored in Titan DB >> " + ActPtTokenWallet);
            Assert.fail();
        }
    }

    @Then("^User Verify Consolidated Wallet balances for Non Supported Currency on titan DB$")
    public void userVerifyConsolidatedWalletBalancesForNonSupportedCurrencyOnTitanDB() throws Exception {

        String ActConsolidatedWalletBalances = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyConsolidatedWalletBalances");
        if (!ActConsolidatedWalletBalances.equals("")) {
            LogCapture.info("User verified Consolidated Wallet Balances reflected for Non supported Currency on Titan DB  >> " + ActConsolidatedWalletBalances);
        } else {
            LogCapture.info("TC Failed : Consolidated Wallet Balances Not reflected for Non supported Currency on Titan DB >> " + ActConsolidatedWalletBalances);
            Assert.fail();
        }
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount newly added multi Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\"$")
    public void userValidateThenVerifyBlockedAmountNewlyAddedMultiCurrencyAndBlockedAmount(String ResponseCode, String ResponseDescription, String MultiCCY, String MultiAmount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String Amount = Constants.OnTheFlyValue.getProperty(MultiAmount);
        String BaseCCY = Constants.OnTheFlyValue.getProperty("<CkAndBlock_CCY>");

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(MultiCCY, jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("blockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, Amount));
        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("blockedAmount.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(BaseCCY, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @And("^User get the card transaction details from details from Titan DB before pushing details to SF for (Check and block|Debit) \"([^\"]*)\"$")
    public void userGetTheCardTransactionDetailsFromDetailsFromTitanDBBeforePushingDetailsToSFFor(String Txntype, String TransactionCurrency) throws Throwable {

        String ActTransactionCurrency = Constants.OnTheFlyValue.getProperty(TransactionCurrency);
        String CheckAndBlockTAN = "";
        if (Txntype.equals("Check and block")) {
            CheckAndBlockTAN = Constants.OnTheFlyValue.getProperty("<CkAndBlockTAN_Number>");
        } else if (Txntype.equals("Debit")) {
            CheckAndBlockTAN = Constants.OnTheFlyValue.getProperty("<DBT_TAN>");
        }

        if (ActTransactionCurrency.equals("GBP")) {
            ExpCardSpendTxnAmount = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCSTransactionsAmount");
            ExpNumberOfTransactions = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCardSpentTxnNumber");
        } else if (ActTransactionCurrency.equals("EUR")) {
            ExpCardSpendTxnAmount = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCSTransactionsAmount");
            ExpNumberOfTransactions = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCardSpentTxnNumber");
        }


    }

    @Then("^User Verify card transaction details is send to Salesforce for (Check and Block|Debit) \"([^\"]*)\"$")
    public void userVerifyCardTransactionDetailsIsSendToSalesforceFor(String TxnType, String TransactionCurrency) throws Throwable {

        String CheckAndBlockTAN = "";
        String CheckAndBlockAmount = "";


        if (TxnType.equals("Check and Block")) {
            CheckAndBlockTAN = Constants.OnTheFlyValue.getProperty("<CkAndBlockTAN_Number>");
            CheckAndBlockAmount = Constants.OnTheFlyValue.getProperty("<CkAndBlock_Amount>");

        } else if (TxnType.equals("Debit")) {
            CheckAndBlockTAN = Constants.OnTheFlyValue.getProperty("<DBT_TAN>");
            CheckAndBlockAmount = Constants.OnTheFlyValue.getProperty("<DBT_Amount>");

        }
        String ActTransactionCurrency = Constants.OnTheFlyValue.getProperty(TransactionCurrency);

        if (ActTransactionCurrency.equals("GBP")) {
            String ActCardSpendTxnAmt = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCSTransactionsAmount");
            float ActCardSpendTxnAmount = Float.parseFloat(ActCardSpendTxnAmt);

            float CardSpendTxnAmtDynamic = Float.parseFloat(CheckAndBlockAmount);
            float ExpCardSpendTxnAmt = Float.parseFloat(ExpCardSpendTxnAmount);
            float CardSpendTxnAmount = ExpCardSpendTxnAmt + CardSpendTxnAmtDynamic;
            if (ActCardSpendTxnAmount == CardSpendTxnAmount) {
                LogCapture.info("---------------User verify transactions amount for GBP CCY is : " + CardSpendTxnAmount + " == " + ActCardSpendTxnAmount + " .......");
            } else {
                LogCapture.info("---------------User verify transactions amount for GBP CCY not equals to : " + CardSpendTxnAmount + " != " + ActCardSpendTxnAmount + " .......");
                Assert.fail();
            }

            String ActNumberOfTransactions = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCardSpentTxnNumber");
            int ExpIntTxnNo = Integer.parseInt(ExpNumberOfTransactions);
            String NoOfTxn = Integer.toString(ExpIntTxnNo + 1);
            if (NoOfTxn.equals(ActNumberOfTransactions)) {
                LogCapture.info("---------------User verify Total number of transactions for GBP CCY is : " + NoOfTxn + " == " + ActNumberOfTransactions + " .......");
            } else {
                LogCapture.info("---------------User verify Total number of transactions for GBP CCY not equals to : " + NoOfTxn + " != " + ActNumberOfTransactions + " .......");
                Assert.fail();
            }


            String ActIsSendToSF = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCardSpentIsSendToSF");
            if (ActIsSendToSF.equals("1")) {
                LogCapture.info("---------------User verify Card Spent Transactions Send to SF as : True .......");
            } else {
                LogCapture.info("---------------User verify Card Spent Transactions Send to SF as : False .......");
                Assert.fail();
            }

            TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date date = new Date();
            String CurrentDateGMT = dateFormat.format(date);

            String ActSendToSFonDate = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCardSpentSendToSFOn");
            String ExactDateTime = ActSendToSFonDate.substring(0, 16);
            if (ExactDateTime.equals(CurrentDateGMT)) {
                LogCapture.info("---------------User verify Card Spent Transaction details Send to SF on date : " + CurrentDateGMT + " .......");
            } else {
                LogCapture.info("---------------User verify Card Spent Transaction details not Send to SF on : " + CurrentDateGMT + " .......");
                Assert.fail();
            }

            String ActUpdatedOnDate = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GeGBPCardSpentUpdatedOn");
            String ExactCSUpdatedDateTime = ActUpdatedOnDate.substring(0, 16);
            if (ExactCSUpdatedDateTime.equals(CurrentDateGMT)) {
                LogCapture.info("---------------User verify Card Spent Transaction details Updated on date : " + CurrentDateGMT + " .......");
            } else {
                LogCapture.info("---------------User verify Card Spent Transaction details not Updated on Date : " + CurrentDateGMT + " .......");
                Assert.fail();
            }

        } else if (ActTransactionCurrency.equals("EUR")) {
            String ActCardSpendTxnAmt = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCSTransactionsAmount");
            float ActCardSpendTxnAmount = Float.parseFloat(ActCardSpendTxnAmt);
            float CardSpendTxnAmtDynamic = Float.parseFloat(CheckAndBlockAmount);

            float ExpCardSpendTxnAmt = Float.parseFloat(ExpCardSpendTxnAmount);
            float CardSpendTxnAmount = ExpCardSpendTxnAmt + CardSpendTxnAmtDynamic;
            if (ActCardSpendTxnAmount == CardSpendTxnAmount) {
                LogCapture.info("---------------User verify transactions amount for EUR CCY is : " + CardSpendTxnAmount + " == " + ActCardSpendTxnAmount + " .......");
            } else {
                LogCapture.info("---------------User verify transactions amount for EUR CCY not equals to : " + CardSpendTxnAmount + " != " + ActCardSpendTxnAmount + " .......");
                Assert.fail();
            }

            String ActNumberOfTransactions = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCardSpentTxnNumber");
            int ExpIntTxnNo = Integer.parseInt(ExpNumberOfTransactions);
            String NoOfTxn = Integer.toString(ExpIntTxnNo + 1);
            if (NoOfTxn.equals(ActNumberOfTransactions)) {
                LogCapture.info("---------------User verify Total number of transactions for EUR CCY is : " + NoOfTxn + " == " + ActNumberOfTransactions + " .......");
            } else {
                LogCapture.info("---------------User verify Total number of transactions for EUR CCY not equals to : " + NoOfTxn + " != " + ActNumberOfTransactions + " .......");
                Assert.fail();
            }


            String ActIsSendToSF = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCardSpentIsSendToSF");
            if (ActIsSendToSF.equals("1")) {
                LogCapture.info("---------------User verify Card Spent Transactions Send to SF as : True .......");
            } else {
                LogCapture.info("---------------User verify Card Spent Transactions Send to SF as : False .......");
                Assert.fail();
            }

            TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date date = new Date();
            String CurrentDateGMT = dateFormat.format(date);

            String ActSendToSFonDate = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCardSpentSendToSFOn");
            String ExactDateTime = ActSendToSFonDate.substring(0, 16);
            if (ExactDateTime.equals(CurrentDateGMT)) {
                LogCapture.info("---------------User verify Card Spent Transaction details Send to SF on date : " + CurrentDateGMT + " .......");
            } else {
                LogCapture.info("---------------User verify Card Spent Transaction details not Send to SF on : " + CurrentDateGMT + " .......");
                Assert.fail();
            }

            String ActUpdatedOnDate = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GeEURCardSpentUpdatedOn");
            String ExactCSUpdatedDateTime = ActUpdatedOnDate.substring(0, 16);
            if (ExactCSUpdatedDateTime.equals(CurrentDateGMT)) {
                LogCapture.info("---------------User verify Card Spent Transaction details Updated on date : " + CurrentDateGMT + " .......");
            } else {
                LogCapture.info("---------------User verify Card Spent Transaction details not Updated on Date : " + CurrentDateGMT + " .......");
                Assert.fail();
            }

        }

    }


    @Then("^User verify ATM Fee and Crossborder Fee visible under payment Out activity tab for (CheckAndBlock|Block|Debit)$")
    public void userVerifyATMFeeAndCrossborderFeeVisibleUnderPaymentOutActivityTabForChekAndBlock(String TxnType) throws Exception {


        String vObjPaymentOutActivityTab = Constants.TitanCustomersOR.getProperty("PaymentOutActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentOutActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutActivityTab, ""));
        LogCapture.info("User clicked on payment Out activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for (int i = 1; i <= 50; i++) {
            String vBojPaymentOutReference = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[4]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutReference, ""));
            String PaymentOutReference = Constants.driver.findElement(By.xpath(vBojPaymentOutReference)).getText();
            if (PaymentOutReference.equals(Constants.UniquePaymentLifeCycleId)) {
                LogCapture.info("Able to find PaymentlifeCycleId as " + PaymentOutReference + " on payment out activity tab.......");

                String vBojPaymentOutCardFees = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[16]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCardFees, ""));
                String PaymentOutCardFees = Constants.driver.findElement(By.xpath(vBojPaymentOutCardFees)).getText();

                String FeeCCY = "";

                if (TxnType.equals("CheckAndBlock")) {
                    FeeCCY = Constants.OnTheFlyValue.getProperty("<CkAndBlock_CCY>");
                } else if (TxnType.equals("Block")) {
                    FeeCCY = Constants.OnTheFlyValue.getProperty("<Block_CCY>");
                } else if (TxnType.equals("Debit")) {
                    FeeCCY = Constants.OnTheFlyValue.getProperty("<DBT_CCY>");
                }


                String ATM_Fees = PaymentOutCardFees.substring(0, 12);
                String ActualATMFeesAmount = Constants.OnTheFlyValue.getProperty("<ATMFees>");
                String ExpATMFee = "ATM-" + ActualATMFeesAmount + "-" + FeeCCY;
                if (ATM_Fees.equals(ExpATMFee)) {
                    LogCapture.info("User verify ATM Fee =" + ATM_Fees + " is visible on paymemt out tab.....");
                } else {
                    LogCapture.info("TC Failed : User Unable to verify Actual =" + ATM_Fees + " and Expected " + ExpATMFee + " on payment out tab.....");
                    Assert.fail();
                }

                String Crossborder_Fees = PaymentOutCardFees.substring(14, 26);
                String ActualCrossborderFeeAmount = Constants.OnTheFlyValue.getProperty("<CrossborderFees>");
                String ExpCBFee = "CBF-" + ActualCrossborderFeeAmount + "-" + FeeCCY;

                if (Crossborder_Fees.equals(ExpCBFee)) {
                    LogCapture.info("User verify Crossborder Fee =" + Crossborder_Fees + " is visible on payment out tab.....");
                } else {
                    LogCapture.info("TC Failed : User Unable to verify Actual =" + ATM_Fees + " and Expected " + ExpCBFee + " on payment out tab.....");
                    Assert.fail();
                }
                break;

            }
            if (i == 40) {
                LogCapture.info("Unable to find PaymentlifeCycleId in under payment out activity tab.......");
                Assert.fail();
            }
        }

    }

    @When("^User select Reversal Currency as \"([^\"]*)\" Reversal amount \"([^\"]*)\" and Reusable PaymentLifeCycle ID$")
    public void userSelectReversalCurrencyAsReversalAmountAndReusablePaymentLifeCycleID(String ReversalCurrency, String ReversalAmount) throws Throwable {

        DynamicValue.put("<Rev_Currency>", ReversalCurrency);
        LogCapture.info("-------------Reversal Currency is [" + ReversalCurrency + "]");
        DynamicValue.put("<RevCCY_Amount>", ReversalAmount);
        LogCapture.info("-------------Reversal amount is [" + ReversalAmount + "]");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.ReusablePaymentLifeCycleId = "AUTO-" + CurrentDateyyyymmdd + "-RAFALE" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<ReusableUniquePaymentLifeID>", Constants.ReusablePaymentLifeCycleId);
        LogCapture.info("-------------Generated Payment Life Cycle ID for reusable is [" + Constants.ReusablePaymentLifeCycleId + "]");

    }

    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\" for Reversal$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmountForReversal(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ReversalCurrency, jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("blockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, ReversalAmount));
        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" and Unblocked amount \"([^\"]*)\" for reversal$")
    public void userValidateThenVerifyUnblockedAmountCurrencyAndUnblockedAmountForReversal(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ReversalCurrency, jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("unblockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, ReversalAmount));
        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("unblockedAmount.amount"));

        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }


    @And("^User search for Instruction number using Reusable PaymentLifeCycleId and validate FXStatus \"([^\"]*)\"$")
    public void userSearchForInstructionNumberUsingReusablePaymentLifeCycleIdAndValidateFXStatus(String Status) throws Throwable {
        String vObjInstructionNumberSearch = Constants.TitanInstructionsOR.getProperty("InstructionNumberSearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionNumberSearch, ReusablePaymentLifeCycleId));

        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionNumberSearch, "enter"));
        LogCapture.info("User Searching PaymentLifeCycleID: " + Constants.ReusablePaymentLifeCycleId);
        Constants.key.pause("4", "");

        String vObjCloseFilterInstPage = CreateFxTicketOR.getProperty("CloseFilterInstPage");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjCloseFilterInstPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCloseFilterInstPage, ""));

        String vObjPaymentLifeCycleIdHeader = Constants.CreateFxTicketOR.getProperty("PaymentLifeCycleIdHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentLifeCycleIdHeader, ""));
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentLifeCycleIdHeader, ""));
        String ActualPaymentLifeId = Constants.driver.findElement(By.xpath(vObjPaymentLifeCycleIdHeader)).getText();
        LogCapture.info("Captured Payment life cycle id : " + ActualPaymentLifeId);

        String vObjFXStatusonInstruction = Constants.CreateFxTicketOR.getProperty("FXStatusHeader");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjFXStatusonInstruction, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXStatusonInstruction, ""));
        String FXStatus = Constants.driver.findElement(By.xpath(vObjFXStatusonInstruction)).getText();
        LogCapture.info("User verified FX Status as : " + FXStatus);
        if (FXStatus.equals(Status)) {
            LogCapture.info("User verified FX Status as : " + FXStatus);
        } else {
            LogCapture.info("User verified FX Status is not REVERSAL != : " + FXStatus);
            Assert.fail();
        }

        String vObjInstructionNumberHeader = Constants.CreateFxTicketOR.getProperty("InstructionNumberHeader");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjInstructionNumberHeader, ""));
        Constants.InstructionNumber = Constants.driver.findElement(By.xpath(vObjInstructionNumberHeader)).getText();
        LogCapture.info("Captured Instruction Number is: " + Constants.InstructionNumber);

        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberHeader, ""));
        LogCapture.info("User clicked on Instruction number on instruction page .....");

        String vObjAmountHeaderOnInstructionPage = Constants.CreateFxTicketOR.getProperty("AmountHeaderOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountHeaderOnInstructionPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAmountHeaderOnInstructionPage, "Amount"));

        String vObjAmountOnInstructionPage = Constants.CreateFxTicketOR.getProperty("AmountOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountOnInstructionPage, ""));
        String ActualAmountOnInstructionPage = Constants.driver.findElement(By.xpath(vObjAmountOnInstructionPage)).getText();

        if (!ActualAmountOnInstructionPage.equals("")) {
            LogCapture.info("Able to see Actual Amount on Instruction page: " + ActualAmountOnInstructionPage);

        } else {
            LogCapture.info("TC Failed : Unable to see Actual Amount on Instruction Number.......");
            Assert.fail();
        }


        String vObjCurrencyHeaderOnInstructionPage = Constants.CreateFxTicketOR.getProperty("CurrencyHeaderOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyHeaderOnInstructionPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCurrencyHeaderOnInstructionPage, "Currency"));

        String vObjCurrencyOnInstructionPage = Constants.CreateFxTicketOR.getProperty("CurrencyOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyOnInstructionPage, ""));
        String ActualCurrencyOnInstruction = Constants.driver.findElement(By.xpath(vObjCurrencyOnInstructionPage)).getText();

        if (!ActualCurrencyOnInstruction.equals("")) {
            LogCapture.info("Able to see Actual Currency on Instruction page: " + ActualCurrencyOnInstruction);

        } else {
            LogCapture.info("TC Failed : Unable to see Actual Currency on Instruction Number.......");
            Assert.fail();
        }


        Constants.key.pause("1", "");
        String vObjInstructionPageClientNumber = Constants.CreateFxTicketOR.getProperty("InstructionPageClientNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionPageClientNumber, ""));
        LogCapture.info("User clicked on client number on instruction page .....");

    }

    @Then("^User verify payment out status as FXStatus \"([^\"]*)\" on payment Out activity tab for reversal$")
    public void userVerifyPaymentOutStatusAsFXStatusOnPaymentOutActivityTabForReversal(String Status) throws Throwable {

        String vObjPaymentOutActivityTab = Constants.TitanCustomersOR.getProperty("PaymentOutActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentOutActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutActivityTab, ""));
        LogCapture.info("User clicked on payment Out activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for (int i = 1; i <= 50; i++) {
            String vBojPaymentOutReference = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[4]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutReference, ""));
            String PaymentOutReference = Constants.driver.findElement(By.xpath(vBojPaymentOutReference)).getText();
            if (PaymentOutReference.equals(Constants.ReusablePaymentLifeCycleId)) {
                LogCapture.info("Able to find PaymentlifeCycleId as " + PaymentOutReference + " on payment out activity tab.......");

                String vBojPaymentOutStatus = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[11]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutStatus, ""));
                String PaymentOutStatus = Constants.driver.findElement(By.xpath(vBojPaymentOutStatus)).getText();

                if (PaymentOutStatus.equals(Status)) {
                    LogCapture.info("User payment out status as = " + PaymentOutStatus + " is visible on payment out tab.....");
                } else {
                    LogCapture.info("TC Failed : User Unable to verify Actual payment out status =" + PaymentOutStatus + " and Expected " + Status + " is not matching on payment out tab.....");
                    Assert.fail();
                }
                break;

            }
            if (i == 40) {
                LogCapture.info("TC Failed : Unable to find Payment life Cycle Id under payment out activity tab.......");
                Assert.fail();
            }
        }

    }

    @Then("^User connect to titan UAT database to verify Fx status in FX Ticket and CustomerInstruction table$")
    public void userConnectToTitanUATDatabaseToVerifyFxStatusInFXTicketAndCustomerInstructionTable() throws Exception {

        String ActPtTokenID = Constants.key.VerifyDBDetails("UAT_Titan", ReusablePaymentLifeCycleId, "VerifyStatusOnFXTicket");
        String ExpPtTokenID = Constants.RandomPtTokenID;
        if (ActPtTokenID.equals(ExpPtTokenID)) {
            LogCapture.info("User verified PtToken ID stored in Titan DB as >> " + ActPtTokenID);
        } else {
            LogCapture.info("TC Failed : PtToken ID Not stored in Titan DB >> " + ActPtTokenID);
            Assert.fail();
        }
    }

    @Then("^User connect to titan UAT database to verify Fx status as \"([^\"]*)\" in FX Ticket and \"([^\"]*)\" in CustomerInstruction table$")
    public void userConnectToTitanUATDatabaseToVerifyFxStatusAsInFXTicketAndInCustomerInstructionTable(String FXTicketStatus, String CustInstStatus) throws Throwable {

        String StatusEnumFXTicket = Constants.key.VerifyDBDetails("UAT_Titan", ReusablePaymentLifeCycleId, "VerifyStatusOnFXTicket");
        String ActFXStatus = Constants.key.VerifyDBDetails("UAT_Titan", StatusEnumFXTicket, "VerifyStatusEnum");
        if (ActFXStatus.equals(FXTicketStatus)) {
            LogCapture.info("User verified Status as Closed under FX ticket table on Titan DB >> " + ActFXStatus);
        } else {
            LogCapture.info("TC Failed : User unable to verify status as Closed under FX ticket table on Titan DB >> " + FXTicketStatus);
            Assert.fail();
        }

        String StatusEnumCustomerInstruction = Constants.key.VerifyDBDetails("UAT_Titan", ReusablePaymentLifeCycleId, "VerifyStatusOnCustomerInstruction");
        String ActCustomerInstStatus = Constants.key.VerifyDBDetails("UAT_Titan", StatusEnumCustomerInstruction, "VerifyStatusEnum");
        if (ActCustomerInstStatus.equals(CustInstStatus)) {
            LogCapture.info("User verified Status as REVERSAL under Customer Instruction table on Titan DB >> " + ActFXStatus);
        } else {
            LogCapture.info("TC Failed : User unable verify status as REVERSAL Customer Instruction table on Titan DB >> " + ActFXStatus);
            Assert.fail();
        }

    }


    @Then("^User enter Transaction Currency \"([^\"]*)\" Transaction Amount \"([^\"]*)\" ATM Fee \"([^\"]*)\" Cross border Fee \"([^\"]*)\" and generate reusable payment life cycle ID$")
    public void userEnterTransactionCurrencyTransactionAmountATMFeeCrossBorderFeeAndGenerateReusablePaymentLifeCycleID(String TransactionCurrency, Float TransactionAmount, Float ATMFees, Float CrossBorderFee) throws Throwable {

        String RandomDigit = RandomStringUtils.randomNumeric(8);

        DynamicValue.put("<Transaction_Currency>", TransactionCurrency);
        LogCapture.info("Card transaction Currency is [" + TransactionCurrency + "]");

        DynamicValue.put("<Transaction_Amount>", TransactionAmount.toString());
        LogCapture.info("Card transaction amount is [" + TransactionAmount + "]");

        DynamicValue.put("<ATMFees>", ATMFees.toString());
        LogCapture.info("Card ATM Fees is [" + ATMFees + "]");

        DynamicValue.put("<CrossborderFees>", CrossBorderFee.toString());
        LogCapture.info("Card Cross Border Fee is [" + CrossBorderFee + "]");

        CardBilling_Amount = TransactionAmount + ATMFees + CrossBorderFee;
        DynamicValue.put("<Billing_Amount>", CardBilling_Amount.toString());
        LogCapture.info("Card Billing amount is [" + CardBilling_Amount + "]");


        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.ReusablePaymentLifeCycleId = "AUTO-" + CurrentDateyyyymmdd + "-RAFALE" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<ReusableUniquePaymentLifeID>", Constants.ReusablePaymentLifeCycleId);
        LogCapture.info("Payment Life Cycle ID  is [" + Constants.ReusablePaymentLifeCycleId + "]");


    }

    @Then("^User connect to Titan UAT DB and verify transaction amount \"([^\"]*)\" is reflecting at Total Amount column under DOF table$")
    public void userConnectToTitanUATDBAndVerifyTransactionAmountIsReflectingAtTotalAmountColumnUnderDOFTable(String ExpectedTotalAmount) throws Throwable {
        String ActualTotalAmount = Constants.key.VerifyDBDetails("UAT_Titan", ReusablePaymentLifeCycleId, "VerifyTotalAmountUnderDOF");
        if (ExpectedTotalAmount.equals(ActualTotalAmount)) {
            LogCapture.info("User verified Total amount under DOF table excluding Fee is >> " + ActualTotalAmount);
        } else {
            LogCapture.info("TC Failed : User unable to verified Total amount under DOF table is >> " + ActualTotalAmount);
            Assert.fail();
        }
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Debited Currency \"([^\"]*)\" and Debited amount \"([^\"]*)\" for DOF$")
    public void userValidateThenVerifyAmountDebitedCurrencyAndDebitedAmountForDOF(String ResponseCode, String ResponseDescription, String CCY, String Amount) throws Throwable {
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified amount Debited Currency as >> " + jp.get("amountDebited.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String DebitedAmt = def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(DebitedAmt, Amount));
        LogCapture.info("-------------User verified amount Debited as >> " + jp.get("amountDebited.amount"));

        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Credited Currency \"([^\"]*)\" and Credited amount \"([^\"]*)\" for DOF$")
    public void userValidateThenVerifyAmountCreditedCurrencyAndCreditedAmountForDOF(String ResponseCode, String ResponseDescription, String CCY, String Amount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("amountCredited.currency")));
        LogCapture.info("-------------User verified amount Credited Currency as >> " + jp.get("amountCredited.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String CreditedAmt = def.format(jp.get("amountCredited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(CreditedAmt, Amount));
        LogCapture.info("-------------User verified amount Credited as >> " + jp.get("amountCredited.amount"));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");


    }


    @Then("^User connect to Titan Database and verify transaction amount \"([^\"]*)\" is reflecting at Total Amount column under DOF table for environment \"([^\"]*)\"$")
    public void userConnectToTitanDatabaseAndVerifyTransactionAmountIsReflectingAtTotalAmountColumnUnderDOFTableForEnvironment(String ExpectedTotalAmount, String DBEnvironment) throws Throwable {
        String ActualTotalAmount = Constants.key.VerifyDBDetails(DBEnvironment, ReusablePaymentLifeCycleId, "VerifyTotalAmountUnderDOF");
        if (ExpectedTotalAmount.equals(ActualTotalAmount)) {
            LogCapture.info("User verified Total amount under DOF table excluding Fee is >> " + ActualTotalAmount);
        } else {
            LogCapture.info("TC Failed : User unable to verified Total amount under DOF table is >> " + ActualTotalAmount);
            Assert.fail();
        }
    }

    @When("^User select Transaction Currency as \"([^\"]*)\" Transaction amount \"([^\"]*)\" and Reusable PaymentLifeCycle ID$")
    public void userSelectTransactionCurrencyAsTransactionAmountAndReusablePaymentLifeCycleID(String TransactionCurrency, String TransactionAmount) throws Throwable {
        DynamicValue.put("<Rev_Currency>", TransactionCurrency);
        LogCapture.info("-------------Transaction Currency is [" + TransactionCurrency + "]");
        DynamicValue.put("<RevCCY_Amount>", TransactionAmount);
        LogCapture.info("-------------Transaction amount is [" + TransactionAmount + "]");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.ReusablePaymentLifeCycleId = "AUTO-" + CurrentDateyyyymmdd + "-RAFALE" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<ReusableUniquePaymentLifeID>", Constants.ReusablePaymentLifeCycleId);
        LogCapture.info("-------------Generated Payment Life Cycle ID for reusable is [" + Constants.ReusablePaymentLifeCycleId + "]");
    }

    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\" for Check And Block$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmountForCheckAndBlock(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ReversalCurrency, jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("blockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, ReversalAmount));
        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User search for Instruction number using Reusable PaymentLifeCycleId to get the Instruction Number$")
    public void userSearchForInstructionNumberUsingReusablePaymentLifeCycleIdToGetTheInstructionNumber() throws Exception {
        String vObjInstructionNumberSearch = Constants.TitanInstructionsOR.getProperty("InstructionNumberSearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionNumberSearch, ReusablePaymentLifeCycleId));

        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionNumberSearch, "enter"));
        LogCapture.info("User Searching PaymentLifeCycleID: " + Constants.ReusablePaymentLifeCycleId);
        Constants.key.pause("4", "");

        String vObjCloseFilterInstPage = CreateFxTicketOR.getProperty("CloseFilterInstPage");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjCloseFilterInstPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCloseFilterInstPage, ""));

        String vObjPaymentLifeCycleIdHeader = Constants.CreateFxTicketOR.getProperty("PaymentLifeCycleIdHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentLifeCycleIdHeader, ""));
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentLifeCycleIdHeader, ""));
        String ActualPaymentLifeId = Constants.driver.findElement(By.xpath(vObjPaymentLifeCycleIdHeader)).getText();
        LogCapture.info("Captured Payment life cycle id : " + ActualPaymentLifeId);

        String vObjInstructionNumberHeader = Constants.CreateFxTicketOR.getProperty("InstructionNumberHeader");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjInstructionNumberHeader, ""));
        Constants.InstructionNumber = Constants.driver.findElement(By.xpath(vObjInstructionNumberHeader)).getText();
        LogCapture.info("Captured Instruction Number is: " + Constants.InstructionNumber);

        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberHeader, ""));
        LogCapture.info("User clicked on Instruction number on instruction page .....");

        String vObjAmountHeaderOnInstructionPage = Constants.CreateFxTicketOR.getProperty("AmountHeaderOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountHeaderOnInstructionPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAmountHeaderOnInstructionPage, "Amount"));

        String vObjAmountOnInstructionPage = Constants.CreateFxTicketOR.getProperty("AmountOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountOnInstructionPage, ""));
        String ActualAmountOnInstructionPage = Constants.driver.findElement(By.xpath(vObjAmountOnInstructionPage)).getText();

        if (!ActualAmountOnInstructionPage.equals("")) {
            LogCapture.info("Able to see Actual Amount on Instruction page: " + ActualAmountOnInstructionPage);

        } else {
            LogCapture.info("TC Failed : Unable to see Actual Amount on Instruction Number.......");
            Assert.fail();
        }


        String vObjCurrencyHeaderOnInstructionPage = Constants.CreateFxTicketOR.getProperty("CurrencyHeaderOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyHeaderOnInstructionPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCurrencyHeaderOnInstructionPage, "Currency"));

        String vObjCurrencyOnInstructionPage = Constants.CreateFxTicketOR.getProperty("CurrencyOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyOnInstructionPage, ""));
        String ActualCurrencyOnInstruction = Constants.driver.findElement(By.xpath(vObjCurrencyOnInstructionPage)).getText();

        if (!ActualCurrencyOnInstruction.equals("")) {
            LogCapture.info("Able to see Actual Currency on Instruction page: " + ActualCurrencyOnInstruction);

        } else {
            LogCapture.info("TC Failed : Unable to see Actual Currency on Instruction Number.......");
            Assert.fail();
        }


        Constants.key.pause("1", "");
        String vObjInstructionPageClientNumber = Constants.CreateFxTicketOR.getProperty("InstructionPageClientNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionPageClientNumber, ""));
        LogCapture.info("User clicked on client number on instruction page .....");

    }

    @Then("^User verify Notification (Send|Not Send) to bank visible under FX activity tab for (CheckAndBlock|Block|Debit)$")
    public void userVerifyNotificationSendToBankVisibleUnderFXActivityTabForCheckAndBlock(String Flag, String TxnType) throws Exception {
        String NotificationFlag = "";
        if (Flag.equalsIgnoreCase("Send")) {
            NotificationFlag = "YES";
        } else if (Flag.equalsIgnoreCase("Not Send")) {
            NotificationFlag = "-";
        }
        String vObjFXActivityTab = Constants.TitanCustomersOR.getProperty("FXActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjFXActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXActivityTab, ""));
        LogCapture.info("User clicked on FX activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for (int i = 1; i <= 50; i++) {
            String vBojFXReference = "//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[3]//a";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojFXReference, ""));
            String FXReference = Constants.driver.findElement(By.xpath(vBojFXReference)).getText();
            LogCapture.info("Expected Instruction Number is >> " + InstructionNumber);
            LogCapture.info("Actual   Instruction Number is >> " + FXReference);
            if (FXReference.equals(Constants.InstructionNumber)) {
                LogCapture.info("Able to find Instruction Number as " + FXReference + "for Payment life Cycle Id" + Constants.ReusablePaymentLifeCycleId + " under FX activity tab.......");

                String vBojNotificationSentToBank = "//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[4]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojNotificationSentToBank, ""));
                String NotificationSentToBank = Constants.driver.findElement(By.xpath(vBojNotificationSentToBank)).getText();

                if (NotificationSentToBank.equals(NotificationFlag)) {
                    LogCapture.info("User verify Notification " + Flag + " To Bank = [" + NotificationSentToBank + "] .....");
                } else {
                    LogCapture.info("TC Failed : User verify Notification " + Flag + " To Bank [=" + NotificationSentToBank + "] .....");
                    Assert.fail();
                }
                break;

            } else {
                LogCapture.info("Checking for PaymentlifeCycleId in Next row under FX activity tab.......");
            }
        }

    }


    @Then("^User verify Notification Not Sent to bank for InterCompany EOne on Titan database \"([^\"]*)\"$")
    public void userVerifyNotificationNotSentToBankForInterCompanyEOneOnTitanDatabase(String Environment) throws Throwable {
        Constants.key.pause("120", "");
        String CustomerInstructionIDE1 = Constants.key.VerifyDBDetails(Environment, ReusablePaymentLifeCycleId, "ToGetCustomerInstructionID");
        String ActualStatusNotifyToBankE1 = Constants.key.VerifyDBDetails(Environment, CustomerInstructionIDE1, "CheckNotifyToBankE1");
        if (ActualStatusNotifyToBankE1.equalsIgnoreCase("") || ActualStatusNotifyToBankE1.equalsIgnoreCase("null")) {
            LogCapture.info("User verified Notification not sent to bank for E1 type Inter Company >> " + ActualStatusNotifyToBankE1);
        } else {
            LogCapture.info("TC Failed : User verified Notification sent to bank for E1 type Inter Company >> " + ActualStatusNotifyToBankE1);
            Assert.fail();
        }

    }

    @Then("^User verify Notification Not Sent to bank for InterCompany ETwo on Titan database \"([^\"]*)\"$")
    public void userVerifyNotificationNotSentToBankForInterCompanyETwoOnTitanDatabase(String Environment) throws Throwable {

        String CustomerInstructionID = Constants.key.VerifyDBDetails(Environment, ReusablePaymentLifeCycleId, "ToGetCustomerInstructionID");
        String ActualStatusNotifyToBank = Constants.key.VerifyDBDetails(Environment, CustomerInstructionID, "CheckNotifyToBankE2");
        if (ActualStatusNotifyToBank.equalsIgnoreCase("0") || ActualStatusNotifyToBank.equalsIgnoreCase("1")) {
            LogCapture.info("User verified Notification not sent to bank for E2 type Inter Company >> " + ActualStatusNotifyToBank);
        } else {
            LogCapture.info("TC Failed : User unable to verify Notification sent to bank for E2 type Inter Company >> " + ActualStatusNotifyToBank);
            Assert.fail();
        }
    }


    @Then("^User verify Notification send to bank as \"([^\"]*)\" for ETwo InterCompany under Deal report page for \"([^\"]*)\"$")
    public void userVerifyNotificationSendToBankAsForETwoInterCompanyUnderDealReportPageFor(String Flag, String Environment) throws Throwable {
        String CustomerInstructionID = Constants.key.VerifyDBDetails(Environment, ReusablePaymentLifeCycleId, "ToGetCustomerInstructionID");
        String ActualExternalReferenceID = Constants.key.VerifyDBDetails(Environment, CustomerInstructionID, "GetExternalReferenceID");

        for (int i = 1; i <= 50; i++) {
            String vObjExternalReferenceID = "//tbody[@id='treasuryTicketTableBodyForDeal']//tr[" + i + "]//td[3]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjExternalReferenceID, ""));
            String ExternalReferenceID = Constants.driver.findElement(By.xpath(vObjExternalReferenceID)).getText();
            if (ExternalReferenceID.equals(ActualExternalReferenceID)) {
                LogCapture.info("User verified External Reference ID for E2 type Inter Company >> " + ExternalReferenceID);
                String vObjNotificationsSentToBank = "//tbody[@id='treasuryTicketTableBodyForDeal']//tr[" + i + "]//td[5]";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotificationsSentToBank, ""));
                String NotificationsSentToBank = Constants.driver.findElement(By.xpath(vObjNotificationsSentToBank)).getText();
                if (NotificationsSentToBank.equalsIgnoreCase(Flag)) {
                    LogCapture.info("User verified Notification sent to bank for E2 type Inter Company as on Titan>> " + NotificationsSentToBank);
                    break;
                } else {
                    LogCapture.info("TC Failed : User unable to verify Notification sent to bank for E2 type Inter Company as Yes on Titan >> " + ExternalReferenceID);
                    Assert.fail();
                }
            } else {
                LogCapture.info("TC Failed : User unable to verify External Reference ID for E2 type Inter Company >> " + ExternalReferenceID);
                Assert.fail();
            }
        }
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" Unblocked amount \"([^\"]*)\" and Debited amount \"([^\"]*)\" for UnblockAndDebit$")
    public void userValidateThenVerifyUnblockedAmountCurrencyUnblockedAmountAndDebitedAmountForUnblockAndDebit(String ResponseCode, String ResponseDescription, String TxnCCY, String BillAmount, String DebitedAmount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(TxnCCY, jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified UnblockedAmount Currency as >> " + jp.get("unblockedAmount.amount"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, BillAmount));
        LogCapture.info("-------------User verified Unblocked amount as >> " + jp.get("unblockedAmount.amount"));

        String DebitedAmt = def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(DebitedAmt, DebitedAmount));
        LogCapture.info("-------------User verified Debited amount as >> " + jp.get("amountDebited.amount"));

        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User verify Amount \"([^\"]*)\" Transaction CCY \"([^\"]*)\" ATM Fee \"([^\"]*)\" and Crossborder Fee \"([^\"]*)\" under payment Out activity tab for UnblockAndDebit$")
    public void userVerifyAmountTransactionCCYATMFeeAndCrossborderFeeUnderPaymentOutActivityTabForUnblockAndDebit(String BillingAmount, String TransactionCurrency, String ActualATMFeesAmount, String ActualCrossborderFeeAmount) throws Throwable {

        String vObjPaymentOutActivityTab = Constants.TitanCustomersOR.getProperty("PaymentOutActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentOutActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutActivityTab, ""));
        LogCapture.info("User clicked on payment Out activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for (int i = 1; i <= 50; i++) {
            String vBojPaymentOutReference = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[4]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutReference, ""));
            String PaymentOutReference = Constants.driver.findElement(By.xpath(vBojPaymentOutReference)).getText();
            if (PaymentOutReference.equals(Constants.ReusablePaymentLifeCycleId)) {
                LogCapture.info("Able to find PaymentlifeCycleId as " + PaymentOutReference + " on payment out activity tab.......");

                String vBojPaymentOutAmount = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[9]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutAmount, ""));
                String PaymentOutAmount = Constants.driver.findElement(By.xpath(vBojPaymentOutAmount)).getText();
                if (PaymentOutAmount.equals(CardAmountToBlock)) {
                    LogCapture.info("User verify Transaction Amount = [" + PaymentOutAmount + "] is visible on payment out tab.....");
                } else {
                    LogCapture.info("TC Failed : User verify Transaction Amount = [" + PaymentOutAmount + "] and Expected [" + CardAmountToBlock + "] is not matching on payment out tab.....");
                    Assert.fail();
                }


                String vBojPaymentOutCCY = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[10]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCCY, ""));
                String PaymentOutCCY = Constants.driver.findElement(By.xpath(vBojPaymentOutCCY)).getText();
                if (PaymentOutCCY.equals(CardAmountToBlockCurrency)) {
                    LogCapture.info("User verify Transaction Currency = [" + PaymentOutCCY + "] is visible under payment out activity tab.....");
                } else {
                    LogCapture.info("TC Failed : User verify Actual Transaction Currency = [" + PaymentOutCCY + "] and Expected [" + CardAmountToBlockCurrency + "] is not matching on payment out tab.....");
                    Assert.fail();
                }

                String vBojPaymentOutCardFees = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[16]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCardFees, ""));
                String PaymentOutCardFees = Constants.driver.findElement(By.xpath(vBojPaymentOutCardFees)).getText();

                String ATM_Fees = PaymentOutCardFees.substring(0, 12);
                String ExpATMFee = "ATM-" + CardATMFees + "-" + CardFeeCurrency;
                if (ATM_Fees.equals(ExpATMFee)) {
                    LogCapture.info("User verify ATM Fee = [" + ATM_Fees + "] is visible on payment out tab.....");
                } else {
                    LogCapture.info("TC Failed : User Unable to verify Actual = [" + ATM_Fees + "] and Expected [" + ExpATMFee + "] on payment out tab.....");
                    Assert.fail();
                }

                String Crossborder_Fees = PaymentOutCardFees.substring(14, 26);
                String ExpCBFee = "CBF-" + CardCrossBorderFee.substring(0, 4) + "-" + CardFeeCurrency;

                if (!CardCrossBorderFee.equals("")) {
                    if (Crossborder_Fees.equals(ExpCBFee)) {
                        LogCapture.info("User verify Cross border Fee = [" + Crossborder_Fees + "] is visible on payment out tab.....");
                    } else {
                        LogCapture.info("TC Failed : User Unable to verify Actual = [" + Crossborder_Fees + "] and Expected [" + ExpCBFee + "] on payment out tab.....");
                        Assert.fail();
                    }
                }

                break;

            }
            if (i == 40) {
                LogCapture.info("TC Failed : Unable to find Payment life Cycle Id under payment out activity tab.......");
                Assert.fail();
            }
        }


    }

    @Then("^User verify Amount without Fees \"([^\"]*)\" Transaction CCY \"([^\"]*)\" under payment in tab On TPL Account for Todays transaction$")
    public void userVerifyAmountWithoutFeesTransactionCCYUnderPaymentInTabOnTPLAccountForTodaysTransaction(String TransactionAmount, String TransactionCurrency) throws Throwable {

        for (int i = 1; i <= 50; i++) {
            String VObjPaymentInAmount = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInAmount, ""));
            String PaymentInAmount = Constants.driver.findElement(By.xpath(VObjPaymentInAmount)).getText();
            LogCapture.info("User verify Amount as [" + PaymentInAmount + "] under payment in activity tab on TPL account");

            String VObjPaymentInCCY = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[6]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInCCY, ""));
            String PaymentInCCY = Constants.driver.findElement(By.xpath(VObjPaymentInCCY)).getText();
            LogCapture.info("User verify Currency as [" + PaymentInCCY + "] under payment in activity tab on TPL account");

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String TodaysDate = dtf1.format(now);

            String VObjPaymentInDate = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[1]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInDate, ""));
            String PaymentInDatewithTime = Constants.driver.findElement(By.xpath(VObjPaymentInDate)).getText();
            String PaymentInDate = PaymentInDatewithTime.trim().substring(0, 10);
            LogCapture.info("User verify Today's date as [" + PaymentInDate + "] under payment in activity tab on TPL account");

            if (PaymentInAmount.equals(TransactionAmount) && PaymentInCCY.equals(TransactionCurrency) && PaymentInDate.equals(TodaysDate)) {

                LogCapture.info("User verify Opposite Entry with amount as [" + PaymentInAmount + "] and CCY as [" + PaymentInCCY + "]under payment in activity tab on TPL account for Todays date " + PaymentInDate);
                break;
            } else if (i == 49) {
                LogCapture.info("User unable to verify Opposite Entry with amount as [" + PaymentInAmount + "] and CCY as [" + PaymentInCCY + "]under payment in activity tab on TPL account" + i);
                Assert.fail();
            }
        }

    }


    @Then("^User verify Amount without Fees \"([^\"]*)\" Transaction CCY \"([^\"]*)\" under PaymentIn tab On (Client|TPL) Account for Credit transaction$")
    public void userVerifyAmountWithoutFeesTransactionCCYUnderPaymentInTabOnClientAccountForCreditTransaction(String TransactionAmt, String TransactionCurrency, String TxnType) throws Throwable {

        String TransactionAmount = "";
        if (TxnType.equals("TPL")) {
            TransactionAmount = "-" + TransactionAmt;
        } else {
            TransactionAmount = TransactionAmt;
        }

        for (int i = 1; i <= 50; i++) {
            String VObjPaymentInAmount = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInAmount, ""));
            String PaymentInAmount = Constants.driver.findElement(By.xpath(VObjPaymentInAmount)).getText();
            LogCapture.info("User verify Amount as [" + PaymentInAmount + "] under payment in activity tab on TPL account");

            String VObjPaymentInCCY = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[6]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInCCY, ""));
            String PaymentInCCY = Constants.driver.findElement(By.xpath(VObjPaymentInCCY)).getText();
            LogCapture.info("User verify Currency as [" + PaymentInCCY + "] under payment in activity tab on TPL account");

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String TodaysDate = dtf1.format(now);

            String VObjPaymentInDate = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[1]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInDate, ""));
            String PaymentInDatewithTime = Constants.driver.findElement(By.xpath(VObjPaymentInDate)).getText();
            String PaymentInDate = PaymentInDatewithTime.trim().substring(0, 10);
            LogCapture.info("User verify Today's date as [" + PaymentInDate + "] under payment in activity tab on TPL account");

            if (PaymentInAmount.equals(TransactionAmount) && PaymentInCCY.equals(TransactionCurrency) && PaymentInDate.equals(TodaysDate)) {

                LogCapture.info("User verify Opposite Entry [Debit] with amount as [" + PaymentInAmount + "] and CCY as [" + PaymentInCCY + "]under payment in activity tab on TPL account for Todays date " + PaymentInDate);
                break;
            } else if (i == 49) {
                LogCapture.info("TC Failed : User unable to verify Opposite Entry with amount as [" + PaymentInAmount + "] and CCY as [" + PaymentInCCY + "]under payment in activity tab on TPL account" + i);
                Assert.fail();
            }
        }
    }


    @Then("^Users Validate \"([^\"]*)\" \"([^\"]*)\" then verify debit amount currency \"([^\"]*)\" and debit amount \"([^\"]*)\"$")
    public void usersValidateThenVerifyDebitAmountCurrencyAndDebitAmount(String ResponseCode, String ResponseDescription, String DebitCCY, String DebitAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String Ccy = Constants.OnTheFlyValue.getProperty(DebitCCY);
        String Amount = Constants.OnTheFlyValue.getProperty(DebitAmount);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(Ccy, jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified DebitCurrency Currency as >> " + jp.get("amountDebited.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String DebitAmt = def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(DebitAmt, Amount));
        LogCapture.info("-------------User verified Debit amount as >> " + jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(Ccy, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^Users Validate \"([^\"]*)\" \"([^\"]*)\" then verify CheckandBlock amount currency \"([^\"]*)\" and CheckandBlock amount \"([^\"]*)\"$")
    public void usersValidateThenVerifyCheckandBlockAmountCurrencyAndCheckandBlockAmount(String ResponseCode, String ResponseDescription, String CkAndBlock_CCY, String CkAndBlock_Amount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String Ccy = Constants.OnTheFlyValue.getProperty(CkAndBlock_CCY);
        String Amount = Constants.OnTheFlyValue.getProperty(CkAndBlock_Amount);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(Ccy, jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified CheckandBlock Currency as >> " + jp.get("blockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String CheckandBlockAmt = def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(CheckandBlockAmt, Amount));
        LogCapture.info("-------------User verified CheckandBlock amount as >> " + jp.get("blockedAmount.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(Ccy, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify credit amount Currency \"([^\"]*)\" and credit amount \"([^\"]*)\"$")
    public void userValidateThenVerifyCreditAmountCurrencyAndCreditAmount(String ResponseCode, String ResponseDescription, String CreditCCy, String CreditAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY = Constants.OnTheFlyValue.getProperty(CreditCCy);
        String Amount = Constants.OnTheFlyValue.getProperty(CreditAmount);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("amountCredited.currency")));
        LogCapture.info("-------------User verified CreditAmount Currency as >> " + jp.get("amountCredited.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String CreditAmt = def.format(jp.get("amountCredited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(CreditAmt, Amount));
        LogCapture.info("-------------User verified Credit amount as >> " + jp.get("amountCredited.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CCY, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\" and FX Details for Check and Block$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmountAndFXDetailsForCheckAndBlock(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ReversalCurrency, jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("blockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, ReversalAmount));

        String SellCCY = jp.get("segregatedBlockedAmount[0].fxDetails.sellCurrency");
        if (!SellCCY.equals("")) {
            LogCapture.info("-------------User verified sell currency as >> " + SellCCY);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify sell currency as >> " + SellCCY);
            Assert.fail();
        }

        String SellAmount = jp.get("segregatedBlockedAmount[0].fxDetails.sellAmount").toString();
        if (!SellAmount.equals("")) {
            LogCapture.info("-------------User verified sell Amount as >> " + SellAmount);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify sell amount as >> " + SellAmount);
            Assert.fail();
        }

        String BuyCCY = jp.get("segregatedBlockedAmount[0].fxDetails.buyCurrency");
        if (!BuyCCY.equals("")) {
            LogCapture.info("-------------User verified Buying currency as >> " + BuyCCY);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify Buying currency as >> " + BuyCCY);
            Assert.fail();
        }

        String BuyAmount = jp.get("segregatedBlockedAmount[0].fxDetails.buyAmount").toString();
        if (!BuyAmount.equals("")) {
            LogCapture.info("-------------User verified Buying amount as >> " + BuyAmount);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify buying amount as >> " + BuyAmount);
            Assert.fail();
        }

        String PricePlanId = jp.get("segregatedBlockedAmount[0].fxDetails.pricePlanId").toString();
        if (!PricePlanId.equals("")) {
            LogCapture.info("-------------User verified price plan ID as >> " + PricePlanId);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify price plan ID as >> " + PricePlanId);
            Assert.fail();
        }

        String ClientRate = jp.get("segregatedBlockedAmount[0].fxDetails.clientRate").toString();
        if (!ClientRate.equals("")) {
            LogCapture.info("-------------User verified client rate as >> " + ClientRate);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify client rate as >> " + ClientRate);
            Assert.fail();
        }

        LogCapture.info("----------------USER VERIFIED FX DETAILS UNDER CHECK & BLOCK API RESPONSE-------------------");

        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\" and FX Details for Block$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmountAndFXDetailsForBlock(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ReversalCurrency, jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("blockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, ReversalAmount));

        String SellCCY = jp.get("segregatedBlockedAmount[0].fxDetails.sellCurrency");
        if (!SellCCY.equals("")) {
            LogCapture.info("-------------User verified sell currency as >> " + SellCCY);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify sell currency as >> " + SellCCY);
            Assert.fail();
        }

        String SellAmount = jp.get("segregatedBlockedAmount[0].fxDetails.sellAmount").toString();
        if (!SellAmount.equals("")) {
            LogCapture.info("-------------User verified sell Amount as >> " + SellAmount);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify sell amount as >> " + SellAmount);
            Assert.fail();
        }

        String BuyCCY = jp.get("segregatedBlockedAmount[0].fxDetails.buyCurrency");
        if (!BuyCCY.equals("")) {
            LogCapture.info("-------------User verified Buying currency as >> " + BuyCCY);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify Buying currency as >> " + BuyCCY);
            Assert.fail();
        }

        String BuyAmount = jp.get("segregatedBlockedAmount[0].fxDetails.buyAmount").toString();
        if (!BuyAmount.equals("")) {
            LogCapture.info("-------------User verified Buying amount as >> " + BuyAmount);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify buying amount as >> " + BuyAmount);
            Assert.fail();
        }

        String PricePlanId = jp.get("segregatedBlockedAmount[0].fxDetails.pricePlanId").toString();
        if (!PricePlanId.equals("")) {
            LogCapture.info("-------------User verified price plan ID as >> " + PricePlanId);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify price plan ID as >> " + PricePlanId);
            Assert.fail();
        }

        String ClientRate = jp.get("segregatedBlockedAmount[0].fxDetails.clientRate").toString();
        if (!ClientRate.equals("")) {
            LogCapture.info("-------------User verified client rate as >> " + ClientRate);
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify client rate as >> " + ClientRate);
            Assert.fail();
        }
        LogCapture.info("----------------USER VERIFIED FX DETAILS UNDER BLOCK API RESPONSE-------------------");

        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }


    @Then("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Titan to calculate settlement amount in EUR$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForTitanToCalculateSettlementAmountInEUR(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        JsonPath jp = JsonPath.given("");
        if (methodType.equalsIgnoreCase("Post")) {
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        }
        CardSettelmentAmount = jp.get("quoted_price").toString();
        DecimalFormat def = new DecimalFormat("0.00");
        CardSettelmentAmount = def.format(Float.parseFloat(CardSettelmentAmount));
        if (CardTransactionCurrency.equals("GBP") || CardTransactionCurrency.equals("EUR") || CardTransactionCurrency.equals("USD") || CardTransactionCurrency.equals("AUD")) {
            CardSettelmentAmount = def.format(Float.parseFloat(CardTransactionAmount));
            CardSettelmentCurrency = CardTransactionCurrency;
            DynamicValue.put("<SettlementAmount>", CardSettelmentAmount);
            LogCapture.info("Calculated Settlement amount is [" + CardSettelmentAmount + "]......");
            DynamicValue.put("<SettlementCurrency>", CardSettelmentCurrency);
            LogCapture.info("Settlement Currency is [" + CardSettelmentCurrency + "]......");
        } else {
            CardSettelmentCurrency = "EUR";
            DynamicValue.put("<SettlementAmount>", CardSettelmentAmount);
            LogCapture.info("Calculated Settlement amount is [" + CardSettelmentAmount + "]......");
            DynamicValue.put("<SettlementCurrency>", CardSettelmentCurrency);
            LogCapture.info("Settlement Currency is [" + CardSettelmentCurrency + "]......");
        }
    }

    @Then("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Titan to calculate Billing amount and amount to block for Base Currency \"([^\"]*)\"$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForTitanToCalculateBillingAmountAndAmountToBlockForBaseCurrency(String methodType, String statCode, String testCaseID, String enviroment, String BaseCurrencuy) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        JsonPath jp = JsonPath.given("");
        if (methodType.equalsIgnoreCase("Post")) {
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        }

        LogCapture.info("Calculated Settlement amount is [" + CardSettelmentAmount + "]......");
        LogCapture.info("Settlement Currency is [" + CardSettelmentCurrency + "]......");

        CardBillingAmount = jp.get("quoted_price").toString();

        if (CardTransactionCurrency.equals("GBP") || CardTransactionCurrency.equals("EUR") || CardTransactionCurrency.equals("USD") || CardTransactionCurrency.equals("AUD") || CardTransactionCurrency.equals("AED")
                || CardTransactionCurrency.equals("ZAR") || CardTransactionCurrency.equals("CAD") || CardTransactionCurrency.equals("CHF") || CardTransactionCurrency.equals("CZK") || CardTransactionCurrency.equals("DKK") || CardTransactionCurrency.equals("HKD") || CardTransactionCurrency.equals("ILS") || CardTransactionCurrency.equals("INR")
                || CardTransactionCurrency.equals("JPY") || CardTransactionCurrency.equals("NOK") || CardTransactionCurrency.equals("NZD") || CardTransactionCurrency.equals("PLN") || CardTransactionCurrency.equals("SAR") || CardTransactionCurrency.equals("SEK") || CardTransactionCurrency.equals("SGD") || CardTransactionCurrency.equals("THB")) {
            LogCapture.info("Card Transaction amount is [" + CardTransactionAmount + "]......");
            LogCapture.info("Card Transaction Currency is [" + CardTransactionCurrency + "]......");

            DecimalFormat def = new DecimalFormat("0.00");
            CardBillingAmount = def.format(Float.parseFloat(CardTransactionAmount));
            DynamicValue.put("<BillingAmount>", CardBillingAmount);
            LogCapture.info("Card Billing amount is [" + CardBillingAmount + "]......");
            CardBillingCurrency = CardTransactionCurrency;
            DynamicValue.put("<BillingCurrency>", CardBillingCurrency);
            LogCapture.info("Card Billing Currency is [" + CardBillingCurrency + "]......");

            CardAmountToBlock = Float.toString(Float.parseFloat(CardTransactionAmount) + Float.parseFloat(CardATMFees));
            CardAmountToBlock = def.format(Float.parseFloat(CardAmountToBlock));
            LogCapture.info("Card Amount to block is [" + CardAmountToBlock + "]");
            DynamicValue.put("<AmountToBlock>", CardAmountToBlock);
            CardAmountToBlockCurrency = CardTransactionCurrency;
            DynamicValue.put("<AmountToBlockCurrency>", CardAmountToBlockCurrency);
            LogCapture.info("Card Amount to block currency is [" + CardAmountToBlockCurrency + "]");

            DynamicValue.put("<ATMFees>", CardATMFees);
            LogCapture.info("Card ATM Fees is [" + CardATMFees + "]");
            DynamicValue.put("<CrossborderFees>", "0");
            LogCapture.info("Card Cross Border Fee is [" + 0 + "]");
            CardCrossBorderFee = "";

            CardFeeCurrency = CardTransactionCurrency;
            DynamicValue.put("<CardFeeCurrency>", CardFeeCurrency);
            LogCapture.info("Card Fee Currency is [" + CardFeeCurrency + "]......");
        } else {
            LogCapture.info("Card Transaction amount is [" + CardTransactionAmount + "]......");
            LogCapture.info("Card Transaction Currency is [" + CardTransactionCurrency + "]......");

            DynamicValue.put("<BillingAmount>", CardBillingAmount);
            LogCapture.info("Card billing amount is [" + CardBillingAmount + "]......");
            CardBillingCurrency = CardBaseCurrency;
            DynamicValue.put("<BillingCurrency>", CardBillingCurrency);
            LogCapture.info("Card billing currency is [" + CardBillingCurrency + "]......");

            float f = (float) (0.02 * Float.parseFloat(CardBillingAmount));
            CardCrossBorderFee = Float.toString(f);

            DynamicValue.put("<ATMFees>", CardATMFees);
            LogCapture.info("Card ATM Fees is [" + CardATMFees + "]");

            DynamicValue.put("<CrossborderFees>", CardCrossBorderFee);
            LogCapture.info("Card Cross Border Fee is [" + CardCrossBorderFee + "]");

            CardFeeCurrency = CardBaseCurrency;
            DynamicValue.put("<CardFeeCurrency>", CardFeeCurrency);
            LogCapture.info("Card Fee Currency is [" + CardFeeCurrency + "]......");

            CardAmountToBlock = Float.toString(Float.parseFloat(CardBillingAmount) + Float.parseFloat(CardATMFees) + Float.parseFloat(CardCrossBorderFee));
            DecimalFormat def = new DecimalFormat("0.00");
            CardAmountToBlock = def.format(Float.parseFloat(CardAmountToBlock));
            LogCapture.info("Card amount to block is [" + CardAmountToBlock + "]");
            DynamicValue.put("<AmountToBlock>", CardAmountToBlock);
            CardAmountToBlockCurrency = CardBaseCurrency;

            DynamicValue.put("<AmountToBlockCurrency>", CardAmountToBlockCurrency);
            LogCapture.info("Card amount to block currency is [" + CardAmountToBlockCurrency + "]");
        }

    }

    @Given("^User perform Check and Block Transaction for Transaction currency \"([^\"]*)\" Transaction Amount \"([^\"]*)\" Cross border Fee and ATM Fees \"([^\"]*)\" then generate reusable PaymentLifeID for Base Currency \"([^\"]*)\"$")
    public void userPerformCheckAndBlockTransactionForTransactionCurrencyTransactionAmountCrossBorderFeeAndATMFeesThenGenerateReusablePaymentLifeIDForBaseCurrency(String TransactionCurrency, String TransactionAmount, String ATMFees, String BaseCCY) throws Throwable {
        DynamicValue.put("<Transaction_Currency>", TransactionCurrency);
        CardTransactionCurrency = TransactionCurrency;
        CardTransactionAmount = TransactionAmount;
        CardBaseCurrency = BaseCCY;
        CardATMFees = ATMFees;

        DynamicValue.put("<Transaction_Currency>", TransactionCurrency);
        DynamicValue.put("<Transaction_Amount>", TransactionAmount);
        DynamicValue.put("<BaseCCY>", BaseCCY);

        if (BaseCCY.equals("GBP")) {
            DynamicValue.put("<LegalEntity>", "CDLGB");
        } else if (BaseCCY.equals("EUR")) {
            DynamicValue.put("<LegalEntity>", "CDLEU");
        }

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.ReusablePaymentLifeCycleId = "AUTO-" + CurrentDateyyyymmdd + "-RAFALE" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<ReusableUniquePaymentLifeID>", Constants.ReusablePaymentLifeCycleId);
        LogCapture.info("Generated reusable Payment Life Cycle ID  is [" + Constants.ReusablePaymentLifeCycleId + "]");

    }


    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify the response for Check  and Block$")
    public void userValidateThenVerifyTheResponseForCheckAndBlock(String ResponseCode, String ResponseDescription) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CardAmountToBlockCurrency, jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> " + jp.get("blockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("blockedAmount.amount"));
        CardAmountToBlock = def.format(Float.parseFloat(CardAmountToBlock));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, CardAmountToBlock));
        LogCapture.info("-------------User verified blocked amount as >> " + jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify response for Unblock and Debit$")
    public void userValidateThenVerifyResponseForUnblockAndDebit(String ResponseCode, String ResponseDescription) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CardAmountToBlockCurrency, jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified UnblockedAmount Currency as >> " + jp.get("unblockedAmount.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String BlocekAmt = def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(BlocekAmt, CardAmountToBlock));
        LogCapture.info("-------------User verified Unblocked amount as >> " + jp.get("unblockedAmount.amount"));

        String DebitedAmt = def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS", ReusableMethod.compareString(DebitedAmt, CardAmountToBlock));
        LogCapture.info("-------------User verified Debited amount as >> " + jp.get("amountDebited.amount"));

        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User verify Amount Currency ATM Fee and CrossBorder Fee under payment Out activity tab for UnblockAndDebit$")
    public void userVerifyAmountCurrencyATMFeeAndCrossBorderFeeUnderPaymentOutActivityTabForUnblockAndDebit() throws Exception {

        String vObjPaymentOutActivityTab = Constants.TitanCustomersOR.getProperty("PaymentOutActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentOutActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutActivityTab, ""));
        LogCapture.info("User clicked on payment Out activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for (int i = 1; i <= 50; i++) {
            String vBojPaymentOutReference = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[4]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutReference, ""));
            String PaymentOutReference = Constants.driver.findElement(By.xpath(vBojPaymentOutReference)).getText();
            if (PaymentOutReference.equals(Constants.ReusablePaymentLifeCycleId)) {
                LogCapture.info("Able to find PaymentlifeCycleId as " + PaymentOutReference + " on payment out activity tab.......");

                String vBojPaymentOutAmount = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[9]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutAmount, ""));
                String PaymentOutAmount = Constants.driver.findElement(By.xpath(vBojPaymentOutAmount)).getText();
                if (PaymentOutAmount.equals(CardAmountToBlock)) {
                    LogCapture.info("User verify Transaction Amount = [" + PaymentOutAmount + "] is visible on payment out tab.....");
                } else {
                    LogCapture.info("TC Failed : User verify Transaction Amount = [" + PaymentOutAmount + "] and Expected [" + CardAmountToBlock + "] is not matching on payment out tab.....");
                    Assert.fail();
                }


                String vBojPaymentOutCCY = "//tbody[@id='profilePaymentOutBody']//tr[" + i + "]//td[10]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCCY, ""));
                String PaymentOutCCY = Constants.driver.findElement(By.xpath(vBojPaymentOutCCY)).getText();
                if (PaymentOutCCY.equals(CardAmountToBlockCurrency)) {
                    LogCapture.info("User verify Transaction Currency = [" + PaymentOutCCY + "] is visible under payment out activity tab.....");
                } else {
                    LogCapture.info("TC Failed : User verify Actual Transaction Currency = [" + PaymentOutCCY + "] and Expected [" + CardAmountToBlockCurrency + "] is not matching on payment out tab.....");
                    Assert.fail();
                }

//                String vBojPaymentOutCardFees = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[16]//a";
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCardFees, ""));
//                String PaymentOutCardFees = Constants.driver.findElement(By.xpath(vBojPaymentOutCardFees)).getText();
//
//                String ATM_Fees = PaymentOutCardFees.substring(0,12);
//                String ExpATMFee = "ATM-"+CardATMFees+"-"+CardFeeCurrency;
//                if(ATM_Fees.equals(ExpATMFee))
//                {
//                    LogCapture.info("User verify ATM Fee = ["+ATM_Fees+"] is visible on payment out tab.....");
//                }else {
//                    LogCapture.info("TC Failed : User Unable to verify Actual = ["+ATM_Fees+"] and Expected ["+ExpATMFee+"] on payment out tab.....");
//                    Assert.fail();
//                }
//
//                if(!CardCrossBorderFee.equals(""))
//                {
//                    String Crossborder_Fees = PaymentOutCardFees.substring(14,26);
//                    String ExpCBFee = "CBF-"+CardCrossBorderFee.substring(0,4)+"-"+CardFeeCurrency;
//                    if(Crossborder_Fees.equals(ExpCBFee))
//                    {
//                        LogCapture.info("User verify Cross border Fee = ["+Crossborder_Fees+"] is visible on payment out tab.....");
//                    }else {
//                        LogCapture.info("TC Failed : User Unable to verify Actual = ["+Crossborder_Fees+"] and Expected ["+ExpCBFee+"] on payment out tab.....");
//                        Assert.fail();
//                    }
//                }

                break;

            }
            if (i == 40) {
                LogCapture.info("TC Failed : Unable to find Payment life Cycle Id under payment out activity tab.......");
                Assert.fail();
            }
        }


    }

    @Then("^User verify Amount without Fees Transaction currency under payment in tab On TPL Account for Todays transaction$")
    public void userVerifyAmountWithoutFeesTransactionCurrencyUnderPaymentInTabOnTPLAccountForTodaysTransaction() throws Exception {

        for (int i = 1; i <= 50; i++) {
            String VObjPaymentInAmount = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInAmount, ""));
            String PaymentInAmount = Constants.driver.findElement(By.xpath(VObjPaymentInAmount)).getText();

            String VObjPaymentInCCY = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[6]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInCCY, ""));
            String PaymentInCCY = Constants.driver.findElement(By.xpath(VObjPaymentInCCY)).getText();

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String TodaysDate = dtf1.format(now);

            String VObjPaymentInDate = "//tbody[@id='profilePaymentInBody']//tr[" + i + "]//td[1]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInDate, ""));
            String PaymentInDatewithTime = Constants.driver.findElement(By.xpath(VObjPaymentInDate)).getText();
            String PaymentInDate = PaymentInDatewithTime.trim().substring(0, 10);

            if (PaymentInAmount.equals(CardBillingAmount) && PaymentInCCY.equals(CardBillingCurrency) && PaymentInDate.equals(TodaysDate)) {

                LogCapture.info("User verify Opposite Entry with amount as [" + PaymentInAmount + "] and CCY as [" + PaymentInCCY + "]under payment in activity tab on TPL account for Todays date " + PaymentInDate);
                break;
            } else if (i == 20) {
                LogCapture.info("User unable to verify Opposite Entry with amount as [" + PaymentInAmount + "] and CCY as [" + PaymentInCCY + "]under payment in activity tab on TPL account" + i);
                LogCapture.info("User verify Actual Amount as [" + PaymentInAmount + "] under payment in activity tab on TPL account");
                LogCapture.info("User verify Expected Amount as [" + CardBillingAmount + "] under payment in activity tab on TPL account");

                LogCapture.info("User verify Actual Currency as [" + PaymentInCCY + "] under payment in activity tab on TPL account");
                LogCapture.info("User verify Expected Currency as [" + CardBillingCurrency + "] under payment in activity tab on TPL account");

                LogCapture.info("User verify Today's date as [" + PaymentInDate + "] under payment in activity tab on TPL account");
                LogCapture.info("User verify Today's date as [" + TodaysDate + "] under payment in activity tab on TPL account");
                Assert.fail();
            }
        }


    }

    @And("^User able to verify FX created for Additional Supported currency under FX Activity tab on TPL Account$")
    public void userAbleToVerifyFXCreatedForAdditionalSupportedCurrencyUnderFXActivityTabOnTPLAccount() throws Exception {

        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 50; i++) {
            String VObjSellAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[7]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellAmount, ""));
            String ActSellAmount = Constants.driver.findElement(By.xpath(VObjSellAmount)).getText();

            String VObjBuyingAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[8]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingAmount, ""));
            String ActBuyingAmount = Constants.driver.findElement(By.xpath(VObjBuyingAmount)).getText();

            String VObjSellingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[9]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellingCCY, ""));
            String ActSellingCCY = Constants.driver.findElement(By.xpath(VObjSellingCCY)).getText();

            String VObjBuyingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[10]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingCCY, ""));
            String ActBuyingCCY = Constants.driver.findElement(By.xpath(VObjBuyingCCY)).getText();

            if (ActSellAmount.equals(CardBillingAmount) && ActBuyingAmount.equals(CardSettelmentAmount) && ActSellingCCY.equals(CardBillingCurrency) && ActBuyingCCY.equals(CardSettelmentCurrency)) {

                LogCapture.info("User verify FX Created with Selling Amount = [" + ActSellAmount + " " + ActSellingCCY + "] and Buying Amount = [" + ActBuyingAmount + " " + ActBuyingCCY + "]under FX Activity tab on TPL account for Additional Supported Currency.....");
                break;
            } else if (i == 50) {
                LogCapture.info("TC Failed : verified FX not Created with Selling Amount = [" + CardBillingAmount + " " + CardBillingCurrency + "] and Buying Amount = [" + CardSettelmentAmount + " " + CardSettelmentCurrency + "]under FX Activity tab on TPL account for Additional Supported Currency.....");
                LogCapture.info("User verify Actual Sell Amount as [" + ActSellAmount + " " + ActSellingCCY + "] under FX activity tab on TPL account");
                LogCapture.info("User verify Expected Sell Amount as [" + CardBillingAmount + " " + CardBillingCurrency + "] under FX activity tab on TPL account");
                LogCapture.info("User verify Actual Buy Amount as [" + ActBuyingAmount + " " + ActBuyingCCY + "] under FX activity tab on TPL account");
                LogCapture.info("User verify Expected Buy Amount as [" + CardSettelmentAmount + " " + CardSettelmentCurrency + "] under FX activity tab on TPL account");
                Assert.fail();
            }
        }

    }


    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify response for Debit$")
    public void userValidateThenVerifyResponseForDebit(String ResponseCode, String ResponseDescription) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CardAmountToBlockCurrency, jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified amount Debited Currency as >> " + jp.get("amountDebited.currency"));

        DecimalFormat def = new DecimalFormat("0.00");
        String DebitedAmt = def.format(jp.get("amountDebited.amount"));
        CardAmountToBlock = def.format(Float.parseFloat(CardAmountToBlock));
        Assert.assertEquals("PASS", ReusableMethod.compareString(DebitedAmt, CardAmountToBlock));
        LogCapture.info("-------------User verified amount Debited as >> " + jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(CardBaseCurrency, jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> " + jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> " + jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> " + jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User able to verify FX not created for Supported currency under FX Activity tab on TPL Account$")
    public void userAbleToVerifyFXNotCreatedForSupportedCurrencyUnderFXActivityTabOnTPLAccount() throws Exception {

        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 50; i++) {
            String VObjSellAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[7]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellAmount, ""));
            String ActSellAmount = Constants.driver.findElement(By.xpath(VObjSellAmount)).getText();

            String VObjBuyingAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[8]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingAmount, ""));
            String ActBuyingAmount = Constants.driver.findElement(By.xpath(VObjBuyingAmount)).getText();

            String VObjSellingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[9]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellingCCY, ""));
            String ActSellingCCY = Constants.driver.findElement(By.xpath(VObjSellingCCY)).getText();

            String VObjBuyingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[10]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingCCY, ""));
            String ActBuyingCCY = Constants.driver.findElement(By.xpath(VObjBuyingCCY)).getText();

            if (ActSellAmount.equals(CardBillingAmount) && ActBuyingAmount.equals(CardSettelmentAmount) && ActSellingCCY.equals(CardBillingCurrency) && ActBuyingCCY.equals(CardSettelmentCurrency)) {

                LogCapture.info("TC Failed: User verify FX Created with Selling Amount = [" + ActSellAmount + " " + ActSellingCCY + "] and Buying Amount = [" + ActBuyingAmount + " " + ActBuyingCCY + "]under FX Activity tab on TPL account for Supported Currency.....");

                LogCapture.info("User verify Actual Sell Amount as [" + ActSellAmount + " " + ActSellingCCY + "] under FX activity tab on TPL account");
                LogCapture.info("User verify Expected Sell Amount as [" + CardBillingAmount + " " + CardBillingCurrency + "] under FX activity tab on TPL account");
                LogCapture.info("User verify Actual Buy Amount as [" + ActBuyingAmount + " " + ActBuyingCCY + "] under FX activity tab on TPL account");
                LogCapture.info("User verify Expected Buy Amount as [" + CardSettelmentAmount + " " + CardSettelmentCurrency + "] under FX activity tab on TPL account");
                Assert.fail();
            } else if (i == 50) {
                LogCapture.info("Verified FX not Created for supported currency [" + CardTransactionCurrency + "] under FX activity tab on TPL account.....");
                break;

            }
        }
    }


    @And("^User able to verify (FX created|FX not created) for Non Supported currency under FX Activity tab on TPL Account for Base Currency \"([^\"]*)\"$")
    public void userAbleToVerifyFXCreatedForNonSupportedCurrencyUnderFXActivityTabOnTPLAccountForBaseCurrency(String FXCreated, String BaseCCY) throws Throwable {

        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 50; i++) {
            String VObjSellAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[7]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellAmount, ""));
            String ActSellAmount = Constants.driver.findElement(By.xpath(VObjSellAmount)).getText();

            String VObjBuyingAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[8]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingAmount, ""));
            String ActBuyingAmount = Constants.driver.findElement(By.xpath(VObjBuyingAmount)).getText();

            String VObjSellingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[9]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellingCCY, ""));
            String ActSellingCCY = Constants.driver.findElement(By.xpath(VObjSellingCCY)).getText();

            String VObjBuyingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[10]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingCCY, ""));
            String ActBuyingCCY = Constants.driver.findElement(By.xpath(VObjBuyingCCY)).getText();

            if (BaseCCY.equals("GBP")) {
                if (ActSellAmount.equals(CardBillingAmount) && ActBuyingAmount.equals(CardSettelmentAmount) && ActSellingCCY.equals(CardBillingCurrency) && ActBuyingCCY.equals(CardSettelmentCurrency)) {

                    LogCapture.info("User verify FX Created with Selling Amount = [" + ActSellAmount + " " + ActSellingCCY + "] and Buying Amount = [" + ActBuyingAmount + " " + ActBuyingCCY + "]under FX Activity tab on TPL account for Additional Supported Currency.....");
                    break;
                } else if (i == 50) {
                    LogCapture.info("TC Failed : verified FX not Created with Selling Amount = [" + ActSellAmount + " " + ActSellingCCY + "] and Buying Amount = [" + ActBuyingAmount + " " + ActBuyingCCY + "]under FX Activity tab on TPL account for Additional Supported Currency.....");
                    LogCapture.info("User verify Actual Sell Amount as [" + ActSellAmount + " " + ActSellingCCY + "] under FX activity tab on TPL account");
                    LogCapture.info("User verify Expected Sell Amount as [" + CardBillingAmount + " " + CardBillingCurrency + "] under FX activity tab on TPL account");
                    LogCapture.info("User verify Actual Buy Amount as [" + ActBuyingAmount + " " + ActBuyingCCY + "] under FX activity tab on TPL account");
                    LogCapture.info("User verify Expected Buy Amount as [" + CardSettelmentAmount + " " + CardSettelmentCurrency + "] under FX activity tab on TPL account");
                    Assert.fail();
                }
            } else if (BaseCCY.equals("EUR")) {
                if (ActSellAmount.equals(CardBillingAmount) && ActBuyingAmount.equals(CardSettelmentAmount) && ActSellingCCY.equals(CardBillingCurrency) && ActBuyingCCY.equals(CardSettelmentCurrency)) {

                    LogCapture.info("TC Failed: User verify FX Created with Selling Amount = [" + ActSellAmount + " " + ActSellingCCY + "] and Buying Amount = [" + ActBuyingAmount + " " + ActBuyingCCY + "]under FX Activity tab on TPL account for Supported Currency.....");

                    LogCapture.info("User verify Actual Sell Amount as [" + ActSellAmount + " " + ActSellingCCY + "] under FX activity tab on TPL account");
                    LogCapture.info("User verify Expected Sell Amount as [" + CardBillingAmount + " " + CardBillingCurrency + "] under FX activity tab on TPL account");
                    LogCapture.info("User verify Actual Buy Amount as [" + ActBuyingAmount + " " + ActBuyingCCY + "] under FX activity tab on TPL account");
                    LogCapture.info("User verify Expected Buy Amount as [" + CardSettelmentAmount + " " + CardSettelmentCurrency + "] under FX activity tab on TPL account");
                    Assert.fail();
                } else if (i == 50) {
                    LogCapture.info("Verified FX not Created for supported currency [" + CardTransactionCurrency + "] under FX activity tab on TPL account.....");
                    break;

                }
            }

        }
    }


    @When("^For a \"([^\"]*)\" call user generate Prerequisite Data and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Notary$")
    public void forACallUserGeneratePrerequisiteDataAndCheckStatusCodeAsForOnEnvironmentForNotary(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.NoTEmail = "saurabhautotest" + CurrentTimeTimeHHMM + "@gmail.com";
        Constants.DynamicValue.put("<EmailAddress>", NoTEmail);

        Constants.NOTFullName = "Saurabh NOT" + RandomStringUtils.randomAlphabetic(6);
        Constants.DynamicValue.put("<FullName>", NOTFullName);

        String Street = RandomStringUtils.randomAlphabetic(5);
        String City = RandomStringUtils.randomAlphabetic(5);
        Constants.NOTAddress = Street + " " + City + " Beas-Cortijos 47 Alcanadre La Rioja 26509";
        Constants.DynamicValue.put("<Address>", NOTAddress);

        NOTPassportNumber = "PN-007" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<PassportNumber>", NOTPassportNumber);

        NOTPhoneNumber = "011-8975" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<PhoneNumber>", NOTPhoneNumber);

        Constants.NOTcrmAccountId = "0030D00000" + RandomStringUtils.randomAlphabetic(8);
        Constants.DynamicValue.put("<crmAccountId>", NOTcrmAccountId);

        Constants.NOTcrmContactId = "0010D00000" + RandomStringUtils.randomAlphabetic(8);
        Constants.DynamicValue.put("<crmContactId>", NOTcrmContactId);


        //Constants.APIkey.checkNotEnabled(testCaseID);
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");


    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and UniqueReference ID$")
    public void userValidateStatusDescriptionAndStatusCodeAndUniqueReferenceID(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        String uniqueReference = jp.get("data.uniqueReference");
        NOTUniqueReferenceId = uniqueReference;
        if (!NOTUniqueReferenceId.equals("")) {
            LogCapture.info("-------------Notary : User verified unique Reference ID generated as >> " + uniqueReference);
        } else if (NOTUniqueReferenceId.equals("")) {
            LogCapture.info("-------------Notary : User verified unique Reference ID generated as Null >>" + uniqueReference);
        }


        String id = jp.get("data.id").toString();
        if (!id.equals("")) {
            LogCapture.info("-------------Notary : User verified ID generated as " + id);
        } else if (id.equals("")) {
            LogCapture.info("-------------Notary : User verified ID not generated >> Null" + id);
        }

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @When("^For a \"([^\"]*)\" call user Fetch Single notary Details and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on Environment \"([^\"]*)\" for Notary$")
    public void forACallUserFetchSingleNotaryDetailsAndCheckStatusCodeAsForOnEnvironmentForNotary(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {

        Constants.DynamicValue.put("<NOTUniqueReferenceId>", NOTUniqueReferenceId);

        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and Verify Seller details$")
    public void userValidateStatusDescriptionAndStatusCodeAndVerifySellerDetails(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and Verify Notary office details$")
    public void userValidateStatusDescriptionAndStatusCodeAndVerifyNotaryOfficeDetails(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        NOTPayeeID = jp.get("data.payeeId").toString();

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        String PayeeId = jp.get("data.payeeId").toString();
        if (!PayeeId.equals("")) {
            LogCapture.info("-------------Notary : User verified Payee ID created as >> " + PayeeId);
        } else if (PayeeId.equals("") || PayeeId.equals("0")) {
            LogCapture.info("-------------Notary : User verified Payee ID not created as >>" + PayeeId);
        }
        String PayeeStatus = jp.get("data.payeeStatus");
        if (!PayeeStatus.equals("")) {
            LogCapture.info("-------------Notary : User verified " + PayeeStatus);
        } else if (PayeeStatus.equals("PAYEE_ERROR")) {
            LogCapture.info("-------------Notary : User verified " + PayeeStatus);
        }
        LogCapture.info("======================================= Response Validations Ended =======================================");


    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for Invalid notary office ID$")
    public void userValidateStatusDescriptionAndStatusCodeForInvalidNotaryOfficeID(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");

        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for Invalid customer Type$")
    public void userValidateStatusDescriptionAndStatusCodeForInvalidCustomerType(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        String response_description = jp.get("response_description");
        if (response_description.contains(ResponseDescription)) {
            LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));
        } else {
            LogCapture.info("-------------TC Failed : User unable to verify Response Description as >> " + jp.get("response_description"));
        }

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }


    @Then("^User connect to Notary Database and verify the Buyer Notary details stored on DB for environment \"([^\"]*)\"$")
    public void userConnectToNotaryDatabaseAndVerifyTheBuyerNotaryDetailsStoredOnDBForEnvironment(String Environment) throws Throwable {

        Map<String, String> BuyerNotaryDetails = ReusableMethod.verifyDBDetailsEnhanced(Environment, NOTUniqueReferenceId, "Fetch_Notary_Seller_Details");
        String ActID = BuyerNotaryDetails.get("id");
        if (!ActID.equals("") || !ActID.equals(null)) {
            LogCapture.info("User verified Unique ID created for Buyer on Notary DB >> " + ActID);
        } else {
            LogCapture.info("TC Failed : Unique ID not created for Buyer on Notary DB >> " + ActID);
            Assert.fail();
        }

        String ActUnique_reference = BuyerNotaryDetails.get("unique_reference");
        if (!ActUnique_reference.equals("") || !ActUnique_reference.equals(null)) {
            LogCapture.info("User verified Unique reference ID created on Notary DB >> " + ActUnique_reference);
        } else {
            LogCapture.info("TC Failed : Unique reference ID not created for Buyer on Notary DB >> " + ActUnique_reference);
            Assert.fail();
        }

        String ActBuyer_email = BuyerNotaryDetails.get("buyer_email");

        if (ActBuyer_email.equals(NoTEmail)) {
            LogCapture.info("User verified Buyer Email address on Notary DB >> " + ActBuyer_email);
        } else {
            LogCapture.info("TC Failed : User unable to verify Buyer Email address on Notary DB >> " + ActBuyer_email);
            Assert.fail();
        }

        String ActBuyer_titan_account_number = BuyerNotaryDetails.get("buyer_titan_account_number");
        if (!ActBuyer_titan_account_number.equals("") || !ActBuyer_titan_account_number.equals(null)) {
            LogCapture.info("User verified Buyer's Titan Account Number on Notary DB >> " + ActBuyer_titan_account_number);
        } else {
            LogCapture.info("TC Failed : User unable to verify Buyer's Titan Account Number on Notary DB >> " + ActBuyer_titan_account_number);
            Assert.fail();
        }

        String ActBuyer_crm_account_id = BuyerNotaryDetails.get("buyer_crm_account_id");
        if (ActBuyer_crm_account_id.equals(NOTcrmAccountId)) {
            LogCapture.info("User verified Buyer CRM Account ID on Notary DB >> " + ActBuyer_crm_account_id);
        } else {
            LogCapture.info("TC Failed : User unable verify Buyer CRM Account ID on Notary DB >> " + ActBuyer_crm_account_id);
            Assert.fail();
        }

        String ActBuyer_crm_contact_id = BuyerNotaryDetails.get("buyer_crm_contact_id");
        if (ActBuyer_crm_contact_id.equals(NOTcrmContactId)) {
            LogCapture.info("User verified Buyer CRM Contact ID on Notary DB >> " + ActBuyer_crm_contact_id);
        } else {
            LogCapture.info("TC Failed : User unable verify Buyer CRM Contact ID on Notary DB >> " + ActBuyer_crm_contact_id);
            Assert.fail();
        }

        String ActBuyer_full_name = BuyerNotaryDetails.get("buyer_full_name");
        if (ActBuyer_full_name.equals(NOTFullName)) {
            LogCapture.info("User verified Buyer Full name on Notary DB >> " + ActUnique_reference);
        } else {
            LogCapture.info("TC Failed : User unable verify Buyer Full name on Notary DB >> " + ActUnique_reference);
            Assert.fail();
        }

        String ActBuyer_address = BuyerNotaryDetails.get("buyer_address").trim();
        if (ActBuyer_address.equals(NOTAddress)) {
            LogCapture.info("User verified Buyer Address on Notary DB >> " + ActBuyer_address);
        } else {
            LogCapture.info("TC Failed : User unable verify  Buyer Address on Notary DB >> " + ActBuyer_address);
            Assert.fail();
        }

        String ActBuyer_passport_number = BuyerNotaryDetails.get("buyer_passport_number");
        if (ActBuyer_passport_number.equals(NOTPassportNumber)) {
            LogCapture.info("User verified Buyer Passport Number on Notary DB >> " + ActBuyer_passport_number);
        } else {
            LogCapture.info("TC Failed : User unable verify  Buyer Passport Number on Notary DB >> " + ActBuyer_passport_number);
            Assert.fail();
        }

        String ActBuyer_phone_number = BuyerNotaryDetails.get("buyer_phone_number");
        if (ActBuyer_phone_number.equals(NOTPhoneNumber)) {
            LogCapture.info("User verified Buyer Phone Number on Notary DB >> " + ActBuyer_phone_number);
        } else {
            LogCapture.info("TC Failed : User unable verify  Buyer Phone Number on Notary DB >> " + ActBuyer_phone_number);
            Assert.fail();
        }

        String ActNotary_status = BuyerNotaryDetails.get("notary_status");
        if (ActNotary_status.equals("CASE_CREATED")) {
            LogCapture.info("User verified Buyer Notary Status as CASE_CREATED on Notary DB >> ");
        } else {
            LogCapture.info("TC Failed : User unable verify  Notary Status as CASE_CREATED on Notary DB >> ");
            Assert.fail();
        }
    }

    @Then("^User connect to Notary Database and verify the Seller Notary details stored on DB for environment \"([^\"]*)\"$")
    public void userConnectToNotaryDatabaseAndVerifyTheSellerNotaryDetailsStoredOnDBForEnvironment(String Environment) throws Throwable {

        Map<String, String> SellerNotaryDetails = ReusableMethod.verifyDBDetailsEnhanced(Environment, NOTUniqueReferenceId, "Fetch_Notary_Seller_Details");
        String ActID = SellerNotaryDetails.get("id");
        if (!ActID.equals("") || !ActID.equals(null)) {
            LogCapture.info("User verified Unique ID created for Seller on Notary DB >> " + ActID);
        } else {
            LogCapture.info("TC Failed : Unique ID not created for Seller on Notary DB >> " + ActID);
            Assert.fail();
        }

        String ActUnique_reference = SellerNotaryDetails.get("unique_reference");
        if (!ActUnique_reference.equals("") || !ActUnique_reference.equals(null)) {
            LogCapture.info("User verified Unique reference ID created for seller on Notary DB >> " + ActUnique_reference);
        } else {
            LogCapture.info("TC Failed : Unique reference ID not Created for Seller on Notary DB >> " + ActUnique_reference);
            Assert.fail();
        }

        String Actseller_email = SellerNotaryDetails.get("seller_email");

        if (Actseller_email.equals(NoTEmail)) {
            LogCapture.info("User verified Seller Email address on Notary DB >> " + Actseller_email);
        } else {
            LogCapture.info("TC Failed : User unable to verify Seller Email address on Notary DB >> " + Actseller_email);
            Assert.fail();
        }

        String Actseller_titan_account_number = SellerNotaryDetails.get("seller_titan_account_number");
        if (!Actseller_titan_account_number.equals("") || !Actseller_titan_account_number.equals(null)) {
            LogCapture.info("User verified Seller's Titan Account Number on Notary DB >> " + Actseller_titan_account_number);
        } else {
            LogCapture.info("TC Failed : User unable to verify Seller's Titan Account Number on Notary DB >> " + Actseller_titan_account_number);
            Assert.fail();
        }

        String Actseller_crm_account_id = SellerNotaryDetails.get("seller_crm_account_id");
        if (Actseller_crm_account_id.equals(NOTcrmAccountId)) {
            LogCapture.info("User verified Seller CRM Account ID on Notary DB >> " + Actseller_crm_account_id);
        } else {
            LogCapture.info("TC Failed : User unable verify Seller CRM Account ID on Notary DB >> " + Actseller_crm_account_id);
            Assert.fail();
        }

        String Actseller_crm_contact_id = SellerNotaryDetails.get("seller_crm_contact_id");
        if (Actseller_crm_contact_id.equals(NOTcrmContactId)) {
            LogCapture.info("User verified Seller CRM Contact ID on Notary DB >> " + Actseller_crm_contact_id);
        } else {
            LogCapture.info("TC Failed : User unable verify Seller CRM Contact ID on Notary DB >> " + Actseller_crm_contact_id);
            Assert.fail();
        }

        String Actseller_full_name = SellerNotaryDetails.get("seller_full_name");
        if (Actseller_full_name.equals(NOTFullName)) {
            LogCapture.info("User verified Seller Full name on Notary DB >> " + Actseller_full_name);
        } else {
            LogCapture.info("TC Failed : User unable verify Seller Full name on Notary DB >> " + Actseller_full_name);
            Assert.fail();
        }

        String Actseller_address = SellerNotaryDetails.get("seller_address").trim();
        if (Actseller_address.equals(NOTAddress)) {
            LogCapture.info("User verified Seller Address on Notary DB >> " + Actseller_address);
        } else {
            LogCapture.info("TC Failed : User unable verify  Seller Address on Notary DB >> " + Actseller_address);
            Assert.fail();
        }

        String Actseller_passport_number = SellerNotaryDetails.get("seller_passport_number");
        if (Actseller_passport_number.equals(NOTPassportNumber)) {
            LogCapture.info("User verified Seller Passport Number on Notary DB >> " + Actseller_passport_number);
        } else {
            LogCapture.info("TC Failed : User unable verify  Seller Passport Number on Notary DB >> " + Actseller_passport_number);
            Assert.fail();
        }

        String Actseller_phone_number = SellerNotaryDetails.get("seller_phone_number");
        if (Actseller_phone_number.equals(NOTPhoneNumber)) {
            LogCapture.info("User verified Seller Phone Number on Notary DB >> " + Actseller_phone_number);
        } else {
            LogCapture.info("TC Failed : User unable verify  Seller Phone Number on Notary DB >> " + Actseller_phone_number);
            Assert.fail();
        }

        String ActNotary_status = SellerNotaryDetails.get("notary_status");
        if (ActNotary_status.equals("CASE_CREATED")) {
            LogCapture.info("User verified Seller Notary Status as CASE_CREATED on Notary DB >> ");
        } else {
            LogCapture.info("TC Failed : User unable verify  Notary Status as CASE_CREATED on Notary DB >> ");
            Assert.fail();
        }
    }


    @Then("^For a \"([^\"]*)\" call user update Buyer Details and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Notary$")
    public void forACallUserUpdateBuyerDetailsAndCheckStatusCodeAsForOnEnvironmentForNotary(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {
        Thread.sleep(1000);
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.NoTEmail = "saurabhautotest" + CurrentTimeTimeHHMM + "@gmail.com";
        Constants.DynamicValue.put("<EmailAddress>", NoTEmail);

        Constants.NOTFullName = "Saurabh NOT" + RandomStringUtils.randomAlphabetic(6);
        Constants.DynamicValue.put("<FullName>", NOTFullName);

        String Street = RandomStringUtils.randomAlphabetic(5);
        String City = RandomStringUtils.randomAlphabetic(5);
        Constants.NOTAddress = Street + " " + City + " Beas-Cortijos 47 Alcanadre La Rioja 26509";
        Constants.DynamicValue.put("<Address>", NOTAddress);

        NOTPassportNumber = "PN-007" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<PassportNumber>", NOTPassportNumber);

        NOTPhoneNumber = "011-8975" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<PhoneNumber>", NOTPhoneNumber);

        LogCapture.info("Unique reference ID Is >>" + NOTUniqueReferenceId);
        Constants.DynamicValue.put("<UniqueReferenceId>", NOTUniqueReferenceId);

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("PUT")) {
            LogCapture.info("---------------PUT call started----------------");
            Constants.RESPONSE = ServiceMethod.putAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------PUT call ended----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");


    }

    @And("^User connect to Notary Database and verify the updated Buyer details stored on DB for environment \"([^\"]*)\"$")
    public void userConnectToNotaryDatabaseAndVerifyTheUpdatedBuyerDetailsStoredOnDBForEnvironment(String Environment) throws Throwable {
        Map<String, String> BuyerNotaryDetails = ReusableMethod.verifyDBDetailsEnhanced(Environment, NOTUniqueReferenceId, "Fetch_Notary_Seller_Details");

        String ActBuyer_email = BuyerNotaryDetails.get("buyer_email");
        if (ActBuyer_email.equals(NoTEmail)) {
            LogCapture.info("User verified Updated Buyer Email address on Notary DB >> " + ActBuyer_email);
        } else {
            LogCapture.info("TC Failed : User unable to verify Updated Buyer Email address on Notary DB >> " + ActBuyer_email);
            Assert.fail();
        }


        String ActBuyer_full_name = BuyerNotaryDetails.get("buyer_full_name");
        if (ActBuyer_full_name.equals(NOTFullName)) {
            LogCapture.info("User verified Updated Buyer Full name on Notary DB >> " + ActBuyer_full_name);
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Buyer Full name on Notary DB >> " + ActBuyer_full_name);
            Assert.fail();
        }

        String ActBuyer_address = BuyerNotaryDetails.get("buyer_address").trim();
        if (ActBuyer_address.equals(NOTAddress)) {
            LogCapture.info("User verified Updated Buyer Address on Notary DB >> " + ActBuyer_address);
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Buyer Address on Notary DB >> " + ActBuyer_address);
            Assert.fail();
        }

        String ActBuyer_passport_number = BuyerNotaryDetails.get("buyer_passport_number");
        if (ActBuyer_passport_number.equals(NOTPassportNumber)) {
            LogCapture.info("User verified Updated Buyer Passport Number on Notary DB >> " + ActBuyer_passport_number);
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Buyer Passport Number on Notary DB >> " + ActBuyer_passport_number);
            Assert.fail();
        }

        String ActBuyer_phone_number = BuyerNotaryDetails.get("buyer_phone_number");
        if (ActBuyer_phone_number.equals(NOTPhoneNumber)) {
            LogCapture.info("User verified Updated Buyer Phone Number on Notary DB >> " + ActBuyer_phone_number);
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Buyer Phone Number on Notary DB >> " + ActBuyer_phone_number);
            Assert.fail();
        }

        String ActNotary_status = BuyerNotaryDetails.get("notary_status");
        if (ActNotary_status.equals("BUYER_DETAIL_UPDATED")) {
            LogCapture.info("User verified Updated Notary Status as BUYER_DETAIL_UPDATED on Notary DB >> ");
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Notary Status as BUYER_DETAIL_UPDATED on Notary DB >> ");
            Assert.fail();
        }
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for update Details$")
    public void userValidateStatusDescriptionAndStatusCodeForUpdateDetails(String ResponseDescription, String ResponseCode) throws Throwable {
        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @Then("^For a \"([^\"]*)\" call user update Seller Details and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Notary$")
    public void forACallUserUpdateSellerDetailsAndCheckStatusCodeAsForOnEnvironmentForNotary(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {
        Thread.sleep(1000);
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.NoTEmail = "saurabhautotest" + CurrentTimeTimeHHMM + "@gmail.com";
        Constants.DynamicValue.put("<EmailAddress>", NoTEmail);

        Constants.NOTFullName = "Saurabh NOT" + RandomStringUtils.randomAlphabetic(6);
        Constants.DynamicValue.put("<FullName>", NOTFullName);

        String Street = RandomStringUtils.randomAlphabetic(5);
        String City = RandomStringUtils.randomAlphabetic(5);
        Constants.NOTAddress = Street + " " + City + " Beas-Cortijos 47 Alcanadre La Rioja 26509";
        Constants.DynamicValue.put("<Address>", NOTAddress);

        NOTPassportNumber = "PN-007" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<PassportNumber>", NOTPassportNumber);

        NOTPhoneNumber = "011-8975" + CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<PhoneNumber>", NOTPhoneNumber);

        LogCapture.info("Unique reference ID Is >>" + NOTUniqueReferenceId);
        Constants.DynamicValue.put("<UniqueReferenceId>", NOTUniqueReferenceId);

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("PUT")) {
            LogCapture.info("---------------PUT call started----------------");
            Constants.RESPONSE = ServiceMethod.putAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------PUT call ended----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @And("^User connect to Notary Database and verify the updated Seller details stored on DB for environment \"([^\"]*)\"$")
    public void userConnectToNotaryDatabaseAndVerifyTheUpdatedSellerDetailsStoredOnDBForEnvironment(String Environment) throws Throwable {
        Map<String, String> BuyerNotaryDetails = ReusableMethod.verifyDBDetailsEnhanced(Environment, NOTUniqueReferenceId, "Fetch_Notary_Seller_Details");

        String ActBuyer_email = BuyerNotaryDetails.get("seller_email");
        if (ActBuyer_email.equals(NoTEmail)) {
            LogCapture.info("User verified Updated Buyer Email address on Notary DB >> " + ActBuyer_email);
        } else {
            LogCapture.info("TC Failed : User unable to verify Updated Buyer Email address on Notary DB >> " + ActBuyer_email);
            Assert.fail();
        }


        String ActBuyer_full_name = BuyerNotaryDetails.get("seller_full_name");
        if (ActBuyer_full_name.equals(NOTFullName)) {
            LogCapture.info("User verified Updated Buyer Full name on Notary DB >> " + ActBuyer_full_name);
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Buyer Full name on Notary DB >> " + ActBuyer_full_name);
            Assert.fail();
        }

        String ActBuyer_address = BuyerNotaryDetails.get("seller_address").trim();
        if (ActBuyer_address.equals(NOTAddress)) {
            LogCapture.info("User verified Updated Buyer Address on Notary DB >> " + ActBuyer_address);
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Buyer Address on Notary DB >> " + ActBuyer_address);
            Assert.fail();
        }

        String ActBuyer_passport_number = BuyerNotaryDetails.get("seller_passport_number");
        if (ActBuyer_passport_number.equals(NOTPassportNumber)) {
            LogCapture.info("User verified Updated Buyer Passport Number on Notary DB >> " + ActBuyer_passport_number);
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Buyer Passport Number on Notary DB >> " + ActBuyer_passport_number);
            Assert.fail();
        }

        String ActBuyer_phone_number = BuyerNotaryDetails.get("seller_phone_number");
        if (ActBuyer_phone_number.equals(NOTPhoneNumber)) {
            LogCapture.info("User verified Updated Buyer Phone Number on Notary DB >> " + ActBuyer_phone_number);
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Buyer Phone Number on Notary DB >> " + ActBuyer_phone_number);
            Assert.fail();
        }

        String ActNotary_status = BuyerNotaryDetails.get("notary_status");
        if (ActNotary_status.equals("SELLER_DETAIL_UPDATED")) {
            LogCapture.info("User verified Updated Notary Status as SELLER_DETAIL_UPDATED on Notary DB.......");
        } else {
            LogCapture.info("TC Failed : User unable verify Updated Notary Status as SELLER_DETAIL_UPDATED on Notary DB......");
            Assert.fail();
        }
    }

    @Given("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\"  clientNumber \"([^\"]*)\" and IBAN \"([^\"]*)\" for Notary on Environment \"([^\"]*)\"$")
    public void forACallUserCheckStatusCodeAsForClientNumberAndIBANForNotaryOnEnvironment(String methodType, String statCode, String testCaseID, String clientNumber, String IBAN, String enviroment) throws Throwable {
        Constants.DynamicValue.put("<clientTANNumber>", clientNumber);

        NOTPayeeFirstName = "SaurabhNOT";
        Constants.DynamicValue.put("<PayeeFirstName>", NOTPayeeFirstName);

        NOTPayeeLastName = RandomStringUtils.randomAlphabetic(6);
        Constants.DynamicValue.put("<PayeeLastName>", NOTPayeeLastName);

        Constants.DynamicValue.put("<PayeeReference>", RandomStringUtils.randomAlphabetic(6));
        String AccountName = NOTPayeeFirstName + " " + NOTPayeeLastName;
        Constants.DynamicValue.put("<AccountName>", AccountName);
        NOTPayeeIBAN = IBAN;
        Constants.DynamicValue.put("<IBAN>", NOTPayeeIBAN);

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("POST")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
    }

    @When("^For a \"([^\"]*)\" call Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Notary$")
    public void forACallCheckStatusCodeAsForOnEnvironmentForNotary(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {

        Constants.DynamicValue.put("<NOTUniqueReferenceId>", NOTUniqueReferenceId);

        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and Verify single Notary office details$")
    public void userValidateStatusDescriptionAndStatusCodeAndVerifySingleNotaryOfficeDetails(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        String UniqueReference = jp.get("data.uniqueReference");
        if (!UniqueReference.equals(NOTUniqueReferenceId)) {
            LogCapture.info("-------------Notary : User verified Unique reference ID created as >> " + NOTUniqueReferenceId);
        } else if (NOTUniqueReferenceId.equals("")) {
            LogCapture.info("-------------Notary : User verified unique reference ID not created >>" + NOTUniqueReferenceId);
        }

        String sellerEmail = jp.get("data.sellerEmail");

        String sellerTitanAccountNumber = jp.get("data.sellerTitanAccountNumber");

        String sellerCrmAccountId = jp.get("data.sellerCrmAccountId");

        String sellerCrmContactId = jp.get("data.sellerCrmContactId");

        String sellerFullName = jp.get("data.sellerFullName");

        String sellerAddress = jp.get("data.sellerAddress");

        String sellerPassportNumber = jp.get("data.sellerPassportNumber");

        String sellerPhoneNumber = jp.get("data.sellerPhoneNumber");


        if (!sellerEmail.equals("") && !sellerTitanAccountNumber.equals("") && !sellerCrmAccountId.equals("") && !sellerCrmContactId.equals("")) {
            LogCapture.info("-------------Notary : User verified Seller email " + sellerEmail);

            LogCapture.info("-------------Notary : User verified Seller Titan Account Number " + sellerTitanAccountNumber);

            LogCapture.info("-------------Notary : User verified Seller Crm Account Id " + sellerCrmAccountId);

            LogCapture.info("-------------Notary : User verified Seller Crm Contact Id " + sellerCrmContactId);

        } else if (sellerEmail.equals("") || sellerTitanAccountNumber.equals("") || sellerCrmAccountId.equals("") || sellerCrmContactId.equals("")) {
            LogCapture.info("-------------Notary : User Unable to verify  sellerEmail or sellerTitanAccountNumber or sellerCrmAccountId or sellerCrmContactId");
            Assert.fail();
        }

        if (!sellerFullName.equals("") && !sellerAddress.equals("") && !sellerPassportNumber.equals("") && !sellerPhoneNumber.equals("")) {
            LogCapture.info("-------------Notary : User verified Seller Full Name " + sellerFullName);

            LogCapture.info("-------------Notary : User verified Seller Address " + sellerAddress);

            LogCapture.info("-------------Notary : User verified Seller Passport Number " + sellerPassportNumber);

            LogCapture.info("-------------Notary : User verified Seller Phone Number " + sellerPhoneNumber);

        } else if (sellerFullName.equals("") || sellerAddress.equals("") || sellerPassportNumber.equals("") || sellerPhoneNumber.equals("")) {
            LogCapture.info("-------------Notary : User unable to verify sellerFullName or sellerAddress or sellerPassportNumber or sellerPhoneNumber  ");
            Assert.fail();
        }


        String buyerEmail = jp.get("data.buyerEmail");

        String buyerTitanAccountNumber = jp.get("data.buyerTitanAccountNumber");

        String buyerCrmAccountId = jp.get("data.buyerCrmAccountId");

        String buyerCrmContactId = jp.get("data.buyerCrmContactId");

        String buyerFullName = jp.get("data.buyerFullName");

        String buyerAddress = jp.get("data.buyerAddress");

        String buyerPassportNumber = jp.get("data.buyerPassportNumber");

        String buyerPhoneNumber = jp.get("data.buyerPhoneNumber");

        if (!buyerEmail.equals("") && !buyerTitanAccountNumber.equals("") && !buyerCrmAccountId.equals("") && !buyerCrmContactId.equals("")) {
            LogCapture.info("-------------Notary : User verified Buyer email " + buyerEmail);

            LogCapture.info("-------------Notary : User verified Buyer Titan Account Number " + buyerTitanAccountNumber);

            LogCapture.info("-------------Notary : User verified Buyer Crm Account Id " + buyerCrmAccountId);

            LogCapture.info("-------------Notary : User verified Buyer Crm Contact Id " + buyerCrmContactId);

        } else if (buyerEmail.equals("") || buyerTitanAccountNumber.equals("") || buyerCrmAccountId.equals("") || buyerCrmContactId.equals("")) {
            LogCapture.info("-------------Notary : User Unable to verify  buyerEmail or buyerTitanAccountNumber or buyerCrmAccountId or buyerCrmContactId");
            Assert.fail();
        }

        if (!buyerFullName.equals("") && !buyerAddress.equals("") && !buyerPassportNumber.equals("") && !buyerPhoneNumber.equals("")) {
            LogCapture.info("-------------Notary : User verified Buyer Full Name " + buyerFullName);

            LogCapture.info("-------------Notary : User verified Buyer Address " + buyerAddress);

            LogCapture.info("-------------Notary : User verified Buyer Passport Number " + buyerPassportNumber);

            LogCapture.info("-------------Notary : User verified Buyer Phone Number " + buyerPhoneNumber);

        } else if (buyerFullName.equals("") || !buyerAddress.equals("") || buyerPassportNumber.equals("") || buyerPhoneNumber.equals("")) {
            LogCapture.info("-------------Notary : User unable to verify buyerFullName or buyerAddress or buyerPassportNumber or buyerPhoneNumber  ");
            Assert.fail();
        }

        String notaryStatus = jp.get("data.notaryStatus");
        String caseStatus = jp.get("data.caseStatus");

        if (!notaryStatus.equals("") && !caseStatus.equals("")) {
            LogCapture.info("-------------Notary : User verified Notary status as " + notaryStatus);

            LogCapture.info("-------------Notary : User verified case status as " + caseStatus);

        } else if (sellerEmail.equals("")) {
            LogCapture.info("-------------Notary : User unable to verify notaryStatus or caseStatus");
            Assert.fail();
        }

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and for invalid unique reference ID$")
    public void userValidateStatusDescriptionAndStatusCodeAndForInvalidUniqueReferenceID(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and other Details for latest Notary$")
    public void userValidateStatusDescriptionAndStatusCodeAndOtherDetailsForLatestNotary(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        String ID = jp.get("data[0].id").toString();

        String uniqueReference = jp.get("data[0].uniqueReference");

        String buyerFullName = jp.get("data[0].buyerFullName");

        String caseStatus = jp.get("data[0].caseStatus");

        if (!ID.equals("") && !uniqueReference.equals("") && !buyerFullName.equals("") && !caseStatus.equals("")) {
            LogCapture.info("-------------Notary : User verified ID " + ID);

            LogCapture.info("-------------Notary : User verified uniqueReference " + uniqueReference);

            LogCapture.info("-------------Notary : User verified Buyer Full Namer " + buyerFullName);

            LogCapture.info("-------------Notary : User verified case Status " + caseStatus);

        } else if (ID.equals("") || uniqueReference.equals("") || buyerFullName.equals("") || caseStatus.equals("")) {
            LogCapture.info("-------------Notary : User unable to verify ID or uniqueReference or buyerFullName or caseStatus for latest Notary Case");
            Assert.fail();
        }
        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and Notary office details for latest entry$")
    public void userValidateStatusDescriptionAndStatusCodeAndNotaryOfficeDetailsForLatestEntry(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        String ID = jp.get("data[0].id").toString();

        String notaryName = jp.get("data[0].notaryName");

        String email = jp.get("data[0].email");

        String companyName = jp.get("data[0].companyName");

        if (!ID.equals("") && !notaryName.equals("") && !companyName.equals("") && !email.equals("")) {
            LogCapture.info("-------------Notary : User verified ID " + ID);

            LogCapture.info("-------------Notary : User verified notaryName " + notaryName);

            LogCapture.info("-------------Notary : User verified companyName " + companyName);

            LogCapture.info("-------------Notary : User verified email " + email);

        } else if (ID.equals("") || notaryName.equals("") || companyName.equals("") || email.equals("")) {
            LogCapture.info("-------------Notary : User unable to verify ID or notaryName or email or caseStatus for latest Notary Case");
            Assert.fail();
        }

        String address1 = jp.get("data[0].address1");
        String address2 = jp.get("data[0].address2");
        String stateCounty = jp.get("data[0].stateCounty");
        String townCity = jp.get("data[0].townCity");
        String postCode = jp.get("data[0].postCode");
        String phoneNumber = jp.get("data[0].phoneNumber");

        if (!address1.equals("") || !address2.equals("") || !stateCounty.equals("") || !townCity.equals("") || !postCode.equals("") || !phoneNumber.equals("")) {
            LogCapture.info("-------------Notary : User verified address1 " + address1);

            LogCapture.info("-------------Notary : User verified address2 " + address2);

            LogCapture.info("-------------Notary : User verified stateCounty " + stateCounty);

            LogCapture.info("-------------Notary : User verified townCity " + townCity);

            LogCapture.info("-------------Notary : User verified postCode " + postCode);

            LogCapture.info("-------------Notary : User verified phoneNumber " + phoneNumber);

        } else if (address1.equals("") || address2.equals("") || stateCounty.equals("") || townCity.equals("") || postCode.equals("") || phoneNumber.equals("")) {
            LogCapture.info("-------------Notary : User unable to verify address1 or address2 or stateCounty or townCity or postCode or phoneNumber for latest Notary Case");
            Assert.fail();
        }

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @When("^For a \"([^\"]*)\" call user generate Prerequisite Data and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment to fetch \"([^\"]*)\" Details$")
    public void forACallUserGeneratePrerequisiteDataAndCheckStatusCodeAsForOnEnvironmentToFetchDetails(String methodType, String statCode, String testCaseID, String enviroment, String AccountEmail) throws Throwable {

        DynamicValue.put("<AccountEmail>", AccountEmail);
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call ended----------------");
        } else if (methodType.equalsIgnoreCase("Delete")) {
            LogCapture.info("---------------DELETE call started----------------");
            Constants.RESPONSE = ServiceMethod.deleteAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------DELETE call ended----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and Verify \"([^\"]*)\" details$")
    public void userValidateStatusDescriptionAndStatusCodeAndVerifyDetails(String ResponseDescription, String ResponseCode, String AccountEmail) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(AccountEmail, jp.get("data.emailAddress")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("data.emailAddress"));

        String fullName = jp.get("data.fullName");
        String titanAccountNo = jp.get("data.titanAccountNo");
        String crmAccountId = jp.get("data.crmAccountId");
        String crmContactId = jp.get("data.crmContactId");

        if (!fullName.equals("") && !titanAccountNo.equals("") && !crmAccountId.equals("") && !crmContactId.equals("")) {
            LogCapture.info("-------------Notary : User verified Full Name as >> " + fullName);
            LogCapture.info("-------------Notary : User verified Titan Account Number as >> " + titanAccountNo);
            LogCapture.info("-------------Notary : User verified crm Account Id as >> " + crmAccountId);
            LogCapture.info("-------------Notary : User verified crm Contact Id as >> " + crmContactId);

        } else if (fullName.equals("") || titanAccountNo.equals("") || crmAccountId.equals("") || crmContactId.equals("")) {
            LogCapture.info("-------------TC Failed : User verify fullName or titanAccountNo or crmAccountId or crmContactId is NULL......");
        }
        LogCapture.info("======================================= Response Validations Ended =======================================");


    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and Verify solicitor \"([^\"]*)\" details$")
    public void userValidateStatusDescriptionAndStatusCodeAndVerifySolicitorDetails(String ResponseDescription, String ResponseCode, String AccountEmail) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(AccountEmail, jp.get("data.emailAddress")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("data.emailAddress"));

        String fullName = jp.get("data.fullName");
        String crmAccountId = jp.get("data.crmAccountId");
        String crmContactId = jp.get("data.crmContactId");

        if (!fullName.equals("") && !crmAccountId.equals("") && !crmContactId.equals("")) {
            LogCapture.info("-------------Notary : User verified Full Name as >> " + fullName);
            LogCapture.info("-------------Notary : User verified crm Account Id as >> " + crmAccountId);
            LogCapture.info("-------------Notary : User verified crm Contact Id as >> " + crmContactId);

        } else if (fullName.equals("") || crmAccountId.equals("") || crmContactId.equals("")) {
            LogCapture.info("-------------TC Failed : User verify fullName or crmAccountId or crmContactId is NULL or titanAccountNo is Null for solicitor......");
        }
        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and for Fetch Notary details$")
    public void userValidateStatusDescriptionAndStatusCodeAndForFetchNotaryDetails(String ResponseDescription, String ResponseCode) throws Throwable {
        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and response for Inactivate Payee$")
    public void userValidateStatusDescriptionAndStatusCodeAndResponseForInactivatePayee(String ResponseDescription, String ResponseCode) throws Throwable {

        LogCapture.info("======================================= Response Validations Started =======================================");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseDescription, jp.get("response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(ResponseCode, jp.get("data.response_code")));
        LogCapture.info("-------------Notary : User verified Response Code as >> " + jp.get("data.response_code"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("Success", jp.get("data.response_description")));
        LogCapture.info("-------------Notary : User verified Response Description as >> " + jp.get("data.response_description"));

        Assert.assertEquals("PASS", ReusableMethod.compareString("false", jp.get("data.active_status")));
        LogCapture.info("-------------Notary : User verified active status as >> " + jp.get("data.active_status"));

        Assert.assertEquals("PASS", ReusableMethod.compareString(NOTPayeeID, jp.get("data.payee_id")));
        LogCapture.info("-------------Notary : User verified Payee ID as >> " + jp.get("data.payee_id"));

        LogCapture.info("======================================= Response Validations Ended =======================================");

    }

    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for (SIT_Notary Application|UAT_Notary Application)$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForCDSIT_NotaryApplication(String methodType, String statCode, String testCaseID, String enviroment, String App) throws Throwable {
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);

            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            Constants.RESPONSE_CODE = jp.get("response_code");
            Constants.RESPONSE_DESCRIPTION = jp.get("response_description");
            LogCapture.info("---------------POST call ended----------------");

        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            if (Constants.ref_code != null) {
                Constants.DynamicValue.put("reference_code", Constants.ref_code);
            }
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            Constants.RESPONSE_CODE = jp.get("code");
            Constants.RESPONSE_DESCRIPTION = jp.get("description");
            LogCapture.info("---------------GET call started----------------");
        } else if (methodType.equalsIgnoreCase("Put")) {
            LogCapture.info("---------------PUT call started----------------");
            Constants.RESPONSE = ServiceMethod.putAdvance(testCaseID, statCode, Constants.DynamicValue);

            JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
            Constants.RESPONSE_CODE = jp.get("response_code");
            Constants.RESPONSE_DESCRIPTION = jp.get("response_description");
            LogCapture.info("---------------PUT call ended----------------");

        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate Response Code \"([^\"]*)\" and Response Description as \"([^\"]*)\"$")
    public void userValidateResponseCodeAndResponseDescriptionAs(String responseCode, String responsedesc) throws Throwable {
        //Constants.APIkey.checkNotEnabled(Constants.TCCaseID);
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJason(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(responseCode, jp.get("response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(responsedesc, jp.get("response_description")));
        if (jp.get("reference_code") != null) {
            Constants.ref_code = jp.get("reference_code");
            Constants.DynamicValue.put("<powerOfAttorneyEnid>", jp.get("data"));
        }
        LogCapture.info("----------------Response Validations Ended-------------------" + Constants.DynamicValue.get("<powerOfAttorneyEnid>"));
    }

    @And("^User navigate to Notary Application \"([^\"]*)\"$")
    public void userNavigateToNotaryApplication(String vUrl) throws Throwable {
        LogCapture.info("Notary Application is loading....");
        String url = Constants.CONFIG.getProperty(vUrl);
        Assert.assertEquals("PASS", Constants.key.navigate("", url));

        String zoomJS;
        JavascriptExecutor js = (JavascriptExecutor) driver;
        zoomJS = "document.body.style.zoom='0.7'";
        js.executeScript(zoomJS);
        Constants.key.pause("2", "");
    }

    @Then("^User successfully landed on Notary Dashboard page$")
    public void userSuccessfullyLandedOnNotaryDashboardPage() throws Exception {
        LogCapture.info("Notary Dashboard loading ......");
        Constants.key.pause("2", "");
        String vobjectNotaryDashboard = Constants.PropertyPayDashboardOR.getProperty("NotaryDashboardPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectNotaryDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectNotaryDashboard, "Hi Notary Admin"));
        LogCapture.info("Dashboard loaded successfully");

    }

    @And("^User click on (Notary office|Add New Case|Dashboard)$")
    public void userClickOnNotaryOffice(String option) throws Exception {
        String vObjButton = "";
        if (option.equals("Notary office")) {
            vObjButton = Constants.PropertyPayDashboardOR.getProperty("NotaryOfficeButton");
        }
        if (option.equals("Add New Case")) {
            vObjButton = Constants.PropertyPayDashboardOR.getProperty("NotaryAddNewCase");
        }
        if (option.equals("Dashboard")) {
            vObjButton = Constants.PropertyPayDashboardOR.getProperty("NotaryDashboardButton");
        }

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjButton, ""));
        LogCapture.info("User click on " + option + "...");

    }

    @Then("^User click on Create new case and landed on create new case$")
    public void userClickOnCreateNewCaseAndLandedOnCreateNewCase() throws Exception {

        String vObjCreateNewNotaryButton = Constants.PropertyPayDashboardOR.getProperty("CreateNewNotaryButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCreateNewNotaryButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCreateNewNotaryButton, ""));
        LogCapture.info("User click on Create new case...");

        String vObjNotaryOfficeHeader = Constants.PropertyPayDashboardOR.getProperty("NotaryOfficeHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryOfficeHeader, ""));
        String NotaryOfficeHeaderText = Constants.driver.findElement(By.xpath(vObjNotaryOfficeHeader)).getText();
        if (NotaryOfficeHeaderText.equals("Notary Offices")) {
            LogCapture.info("User landed on Notary Offices page...");
        } else {
            LogCapture.info("User not landed on Notary Offices page...");
            Assert.fail();
        }
    }


    @When("^User enters NotaryName NotaryEmail CompanyName and PhoneNumber and address details and click on Add button$")
    public void userEntersNotaryNameNotaryEmailCompanyNameAndPhoneNumberAndAddressDetailsAndClickOnAddButton() throws Exception {

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.NotaryEmail = "saurabhnotary" + CurrentTimeTimeHHMM + "@mailinator.com";
        String vObjNO_Email = Constants.PropertyPayDashboardOR.getProperty("NO_Email");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_Email, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_Email, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_Email, NotaryEmail));
        LogCapture.info("User Enter Notary Email as " + NotaryEmail + "...");

        Constants.NotaryName = "Saurabh Notarial Office " + RandomStringUtils.randomAlphabetic(6);
        String vObjNO_NoratyName = Constants.PropertyPayDashboardOR.getProperty("NO_NoratyName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_NoratyName, NotaryName));
        LogCapture.info("User Enter Notary Name as " + NotaryName + "...");

        NOTCompanyName = "Silver Oak Notarial Office " + RandomStringUtils.randomAlphabetic(6) + " ltd";
        String vObjNO_CompanyName = Constants.PropertyPayDashboardOR.getProperty("NO_CompanyName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_CompanyName, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_CompanyName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_CompanyName, NOTCompanyName));
        LogCapture.info("User Enter Company Name as " + NOTCompanyName + "...");

        NOTOfficePhoneNumber = "+91 900001" + RandomStringUtils.randomNumeric(4);
        String vObjNO_PhoneNumber = Constants.PropertyPayDashboardOR.getProperty("NO_PhoneNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_PhoneNumber, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_PhoneNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_PhoneNumber, NOTOfficePhoneNumber));
        LogCapture.info("User Enter Phone Number as " + NOTOfficePhoneNumber + "...");

        String Address1 = "Ctra. de Fuentenueva 99 " + RandomStringUtils.randomAlphabetic(4);
        String vObjNO_AddressLine1 = Constants.PropertyPayDashboardOR.getProperty("NO_AddressLine1");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_AddressLine1, Address1));
        LogCapture.info("User Enter address line1  as " + Address1 + "...");

        String Address2 = RandomStringUtils.randomAlphabetic(6);
        String vObjNO_AddressLine2 = Constants.PropertyPayDashboardOR.getProperty("NO_AddressLine2");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_AddressLine2, Address2));
        LogCapture.info("User Enter address line2  as " + Address2 + "...");

        String State = "Madrid";
        String vObjNO_State = Constants.PropertyPayDashboardOR.getProperty("NO_State");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_State, State));
        LogCapture.info("User Enter State  as " + State + "...");

        String Town = "Galapagar";
        String vObjNO_TownCity = Constants.PropertyPayDashboardOR.getProperty("NO_TownCity");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_TownCity, Town));
        LogCapture.info("User Enter Town/City  as " + Town + "...");

        String PostCode = RandomStringUtils.randomNumeric(6);
        String vObjNO_PostCode = Constants.PropertyPayDashboardOR.getProperty("NO_PostCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_PostCode, PostCode));
        LogCapture.info("User Enter Post Code  as " + PostCode + "...");

        String vObjAddNotaryOfficeButton = Constants.PropertyPayDashboardOR.getProperty("AddNotaryOfficeButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddNotaryOfficeButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjAddNotaryOfficeButton, ""));
        LogCapture.info("User Clicks on Add new Notary button ......");

    }

    @Then("^User Verify Notary office details and click on Save and Continue$")
    public void userVerifyNotaryOfficeDetailsAndClickOnSaveAndContinue() throws Exception {

        String vObjNOTOfficeDetailsEmail = Constants.PropertyPayDashboardOR.getProperty("NOTOfficeDetailsEmail");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNOTOfficeDetailsEmail, ""));
        String NotaryOfficeEmailText = Constants.driver.findElement(By.xpath(vObjNOTOfficeDetailsEmail)).getText();
        if (NotaryOfficeEmailText.equals(NotaryEmail)) {
            LogCapture.info("User Verify email as " + NotaryEmail + " on notary office details page...");
        } else {
            LogCapture.info("User Unable to verify email on Notary office details page...");
            Assert.fail();
        }

        String vObjNOTOfficeDetailsNotaryName = Constants.PropertyPayDashboardOR.getProperty("NOTOfficeDetailsNotaryName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNOTOfficeDetailsNotaryName, ""));
        String NOTOfficeDetailsNotaryName = Constants.driver.findElement(By.xpath(vObjNOTOfficeDetailsNotaryName)).getText();
        if (NOTOfficeDetailsNotaryName.equals(NotaryName)) {
            LogCapture.info("User Verify Notary Name as " + NotaryName + " on notary office details page...");
        } else {
            LogCapture.info("User Unable to verify Notary name on Notary office details page...");
            Assert.fail();
        }

        String vObjNOTOfficeDetailsCompanyName = Constants.PropertyPayDashboardOR.getProperty("NOTOfficeDetailsCompanyName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNOTOfficeDetailsCompanyName, ""));
        String NOTOfficeDetailsCompanyName = Constants.driver.findElement(By.xpath(vObjNOTOfficeDetailsCompanyName)).getText();
        if (NOTOfficeDetailsCompanyName.equals(NOTCompanyName)) {
            LogCapture.info("User Verify Company Name as " + NOTCompanyName + " on notary office details page...");
        } else {
            LogCapture.info("User Unable to verify Company name on Notary office details page...");
            Assert.fail();
        }

        String vObjNOTOfficeDetailsPhoneNumber = Constants.PropertyPayDashboardOR.getProperty("NOTOfficeDetailsPhoneNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNOTOfficeDetailsPhoneNumber, ""));
        String NOTOfficePhoneNumber = Constants.driver.findElement(By.xpath(vObjNOTOfficeDetailsPhoneNumber)).getText();
        if (NOTOfficePhoneNumber.equals(Constants.NOTOfficePhoneNumber)) {
            LogCapture.info("User Verify Phone No as " + Constants.NOTOfficePhoneNumber + " on notary office details page...");
        } else {
            LogCapture.info("User Unable to verify Notary phone number on Notary office details page...");
            Assert.fail();
        }

        String vObjNotaryOfficeSaveAndContinue = Constants.PropertyPayDashboardOR.getProperty("NotaryOfficeSaveAndContinue");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryOfficeSaveAndContinue, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNotaryOfficeSaveAndContinue, ""));

    }


    @Then("^User verify newly created office reflected on Notary office Dashboard$")
    public void userVerifyNewlyCreatedOfficeReflectedOnNotaryOfficeDashboard() throws Exception {
        Constants.key.pause("2", "");
        String vObjNotaryOfficeButton = Constants.PropertyPayDashboardOR.getProperty("NotaryOfficeButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryOfficeButton, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNotaryOfficeButton, ""));
        LogCapture.info("User click on Notary office button...");

        String vObjNotaryOfficeCompany = "//*[text()='" + NOTCompanyName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryOfficeCompany, ""));
        String NOTOfficeCompanyName = Constants.driver.findElement(By.xpath(vObjNotaryOfficeCompany)).getText();

        String vObjNotaryOfficeName = "//*[text()='" + NotaryName + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryOfficeName, ""));
        String NOTOfficeName = Constants.driver.findElement(By.xpath(vObjNotaryOfficeName)).getText();

        if (NOTOfficeCompanyName.equals(NOTCompanyName) && NOTOfficeName.equals(NotaryName)) {
            LogCapture.info("User verify company name [" + NOTCompanyName + "] & Notary Name [" + NOTOfficeName + "] visible on dashboard...");
        } else {
            LogCapture.info("User Unable to verify company name [" + NOTCompanyName + "] & Notary Name [" + NOTOfficeName + "] on dashboard...");
            Assert.fail();
        }

    }

    @Then("^User verify user unable to create notary office without mandatory details$")
    public void userVerifyUserUnableToCreateNotaryOfficeWithoutMandatoryDetails() throws Exception {

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.NotaryEmail = "saurabhnotary" + CurrentTimeTimeHHMM + "@mailinator.com";
        String vObjNO_Email = Constants.PropertyPayDashboardOR.getProperty("NO_Email");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_Email, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_Email, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_Email, NotaryEmail));
        LogCapture.info("User Enter Notary Email as " + NotaryEmail + "...");

        Constants.NotaryName = "Saurabh Notarial Office " + RandomStringUtils.randomAlphabetic(6);
        String vObjNO_NoratyName = Constants.PropertyPayDashboardOR.getProperty("NO_NoratyName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_NoratyName, NotaryName));
        LogCapture.info("User Enter Notary Name as " + NotaryName + "...");

        NOTCompanyName = "Silver Oak Notarial Office " + RandomStringUtils.randomAlphabetic(6) + " ltd";
        String vObjNO_CompanyName = Constants.PropertyPayDashboardOR.getProperty("NO_CompanyName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_CompanyName, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_CompanyName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_CompanyName, NOTCompanyName));
        LogCapture.info("User Enter Company Name as " + NOTCompanyName + "...");

        NOTOfficePhoneNumber = "+91 900001" + RandomStringUtils.randomNumeric(4);
        String vObjNO_PhoneNumber = Constants.PropertyPayDashboardOR.getProperty("NO_PhoneNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_PhoneNumber, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_PhoneNumber, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_PhoneNumber, NOTOfficePhoneNumber));
        LogCapture.info("User Enter Phone Number as " + NOTOfficePhoneNumber + "...");

        String Address1 = "Ctra. de Fuentenueva 99 " + RandomStringUtils.randomAlphabetic(4);
        String vObjNO_AddressLine1 = Constants.PropertyPayDashboardOR.getProperty("NO_AddressLine1");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_AddressLine1, Address1));
        LogCapture.info("User Enter address line1  as " + Address1 + "...");

        String Address2 = RandomStringUtils.randomAlphabetic(6);
        String vObjNO_AddressLine2 = Constants.PropertyPayDashboardOR.getProperty("NO_AddressLine2");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_AddressLine2, Address2));
        LogCapture.info("User Enter address line2  as " + Address2 + "...");

        String State = "Madrid";
        String vObjNO_State = Constants.PropertyPayDashboardOR.getProperty("NO_State");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_State, State));
        LogCapture.info("User Enter State  as " + State + "...");

        String Town = "Galapagar";
        String vObjNO_TownCity = Constants.PropertyPayDashboardOR.getProperty("NO_TownCity");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_TownCity, Town));
        LogCapture.info("User Enter Town/City  as " + Town + "...");

        String PostCode = RandomStringUtils.randomNumeric(6);
        String vObjNO_PostCode = Constants.PropertyPayDashboardOR.getProperty("NO_PostCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_PostCode, PostCode));
        LogCapture.info("User Enter Post Code  as " + PostCode + "...");

        String vObjAddNotaryOfficeButton = Constants.PropertyPayDashboardOR.getProperty("AddNotaryOfficeButton");

        boolean ActButtonState;
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_NoratyName, "selectall"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_NoratyName, "delete"));
        LogCapture.info("Clear Notary name ......");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("TC Failed : Add new office button is Enable...");
            Assert.fail();
        } else {
            LogCapture.info("Add new office button is disabled...");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_NoratyName, NotaryName));
        LogCapture.info("User Enter Notary Name as " + NotaryName + "...");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("Add new office button is Enable...");
        } else {
            LogCapture.info("TC Failed : Add new office button is disabled...");
            Assert.fail();
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_AddressLine1, "selectall"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_AddressLine1, "delete"));
        LogCapture.info("Clear Address1 field ......");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("TC Failed : Add new office button is Enable...");
            Assert.fail();
        } else {
            LogCapture.info("Add new office button is disabled...");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_AddressLine1, Address1));
        LogCapture.info("User Enter address line1  as " + Address1 + "...");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("Add new office button is Enable...");
        } else {
            LogCapture.info("TC Failed : Add new office button is disabled...");
            Assert.fail();
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_AddressLine2, "selectall"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_AddressLine2, "delete"));
        LogCapture.info("Clear Address2 field ......");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("TC Failed : Add new office button is Enable...");
            Assert.fail();
        } else {
            LogCapture.info("Add new office button is disabled...");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_AddressLine2, Address2));
        LogCapture.info("User Enter address line2  as " + Address2 + "...");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("Add new office button is Enable...");
        } else {
            LogCapture.info("TC Failed : Add new office button is disabled...");
            Assert.fail();
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_State, "selectall"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_State, "delete"));
        LogCapture.info("Clear State field ......");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("TC Failed : Add new office button is Enable...");
            Assert.fail();
        } else {
            LogCapture.info("Add new office button is disabled...");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_State, State));
        LogCapture.info("User Enter State  as " + State + "...");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("Add new office button is Enable...");
        } else {
            LogCapture.info("TC Failed : Add new office button is disabled...");
            Assert.fail();
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_TownCity, "selectall"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_TownCity, "delete"));
        LogCapture.info("Clear Town field ......");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("TC Failed : Add new office button is Enable...");
            Assert.fail();
        } else {
            LogCapture.info("Add new office button is disabled...");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_TownCity, Town));
        LogCapture.info("User Enter Town/City  as " + Town + "...");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("Add new office button is Enable...");
        } else {
            LogCapture.info("TC Failed : Add new office button is disabled...");
            Assert.fail();
        }

        Assert.assertEquals("PASS", Constants.key.click(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_PostCode, "selectall"));
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjNO_PostCode, "delete"));
        LogCapture.info("Clear Town field ......");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("TC Failed : Add new office button is Enable...");
            Assert.fail();
        } else {
            LogCapture.info("Add new office button is disabled...");
        }

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjNO_PostCode, PostCode));
        LogCapture.info("User Enter Post Code  as " + PostCode + "...");
        Constants.key.pause("2", "");
        ActButtonState = driver.findElement(By.xpath(vObjAddNotaryOfficeButton)).isEnabled();
        if (ActButtonState) {
            LogCapture.info("Add new office button is Enable...");
        } else {
            LogCapture.info("TC Failed : Add new office button is disabled...");
            Assert.fail();
        }

    }


    @Then("^User Select newly created Notary office$")
    public void userSelectNewlyCreatedNotaryOffice() throws Exception {

        String vObjSelectNotaryOffice = Constants.PropertyPayDashboardOR.getProperty("SelectNotaryOffice");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectNotaryOffice, ""));
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));

        String vObjlistbox = Constants.TitanLoginOR.getProperty("listbox");
        List<WebElement> listElements = driver.findElements(By.xpath(vObjlistbox));

        for (WebElement element : listElements) {
            if (element.getText().contains(NotaryName + " - ")) {
                element.click();
                LogCapture.info("User Select notary office " + NotaryName);
                break;
            } else {
                LogCapture.info("User unable to select newly created notary office " + NotaryName);
                Assert.fail();
            }
        }
        String vObjdetail4 = "//h2[@type='bold']";
        Constants.caseID = Constants.key.getText(vObjdetail4, "");
        LogCapture.info("User Captured Notary CASE ID >> " + caseID);

    }

    @Then("^User enter  Amount paid date and Completion Date on property details page$")
    public void userEnterAmountPaidDateAndCompletionDateOnPropertyDetailsPage() throws Exception {

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 5);
        String TargetComplectionDate = dateFormat.format(cal.getTime());
        System.out.println("User Entering Target completion date as " + TargetComplectionDate);

        String AmountPaidToDate = Integer.toString(ThreadLocalRandom.current().nextInt(500, 999));

        Constants.key.pause("3", "");
        String vObjTargetCompletionDate = "//*[contains(text(),'Target completion date')]//ancestor::*[@data-testid='form-control']//input";
        LogCapture.info("entering");
        Assert.assertEquals("PASS", Constants.key.click(vObjTargetCompletionDate, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjTargetCompletionDate));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjTargetCompletionDate, TargetComplectionDate));

        Constants.key.pause("3", "");
        String vObjAmountPaidToDate = "//*[contains(text(),'Amount paid to date')]//ancestor::*[@data-testid='form-control']//input";
        LogCapture.info("entering" + vObjAmountPaidToDate);
        Assert.assertEquals("PASS", Constants.key.click(vObjAmountPaidToDate, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAmountPaidToDate));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmountPaidToDate, AmountPaidToDate));

    }

    @Then("^User enter  Final amount and Select Currency as \"([^\"]*)\"$")
    public void userEnterFinalAmountAndSelectCurrencyAs(String Currecny) throws Throwable {

        String FinalAmount = Integer.toString(ThreadLocalRandom.current().nextInt(1000, 1500));
        Constants.key.pause("3", "");
        String vObjFinalAmount = "//*[contains(text(),'Final amount')]//ancestor::*[@data-testid='form-control']//input";
        LogCapture.info("entering" + vObjFinalAmount);
        Assert.assertEquals("PASS", Constants.key.click(vObjFinalAmount, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjFinalAmount));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFinalAmount, FinalAmount));

        String vObjSelectAmountPaidCurrency = "//*[contains(text(),'Select amount paid currency')]//ancestor::*[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectAmountPaidCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));

        String vObjlistbox = Constants.TitanLoginOR.getProperty("listbox");
        List<WebElement> AmountPaidToDateCCYlist = driver.findElements(By.xpath(vObjlistbox));

        for (WebElement element : AmountPaidToDateCCYlist) {
            System.out.println(" element containing " + element + element.getText());
            if (element.getText().contains(Currecny)) {

                element.click();
                System.out.println("User select Amount paid to date Currency as " + Currecny);
                break;
            }
        }


        String vObjSelectFinalAmountCurrency = "//*[contains(text(),'Select final amount currency')]//ancestor::*[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectFinalAmountCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));

        List<WebElement> FinalAmountCCYlist = driver.findElements(By.xpath(vObjlistbox));

        for (WebElement element : FinalAmountCCYlist) {
            System.out.println(" element containing " + element + element.getText());
            if (element.getText().contains(Currecny)) {

                element.click();
                System.out.println("User select Final amount Currency as " + Currecny);
                break;
            }
        }

    }

    @And("^user click on Save and continue button on Select Language page$")
    public void userClickOnSaveAndContinueButtonOnSelectLanguagePage() throws Exception {

        String vObjSaveAndContinuelangPage = Constants.TitanLoginOR.getProperty("detail3");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveAndContinuelangPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveAndContinuelangPage, ""));
        LogCapture.info("User click on Save and Continue button after selecting language ......");

        Thread.sleep(5000);

    }

    @And("^user click on Save and continue button on Buyers details page$")
    public void userClickOnSaveAndContinueButtonOnBuyersDetailsPage() throws Exception {

        String vObjSaveAndContinueBuyDetailsPage = "//p[@text='Save and continue']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveAndContinueBuyDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveAndContinueBuyDetailsPage, ""));
        LogCapture.info("User click on Save and Continue button after reviewing Buyers Account details ......");


    }

    @Then("^User enter Buyer solicitor's Email address \"([^\"]*)\" on Buyer’s legal representative page$")
    public void userEnterBuyerSolicitorSEmailAddressOnBuyerSLegalRepresentativePage(String BuyersSoliEmail) throws Throwable {

        String vObjBuyersSoliEmail = "//label[text()='Email address']//ancestor::div[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBuyersSoliEmail, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjBuyersSoliEmail, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjBuyersSoliEmail, BuyersSoliEmail));
        LogCapture.info("User enter Buyers solicitor email as " + BuyersSoliEmail);

        String vObjFetchBuySoliDetailsPage = "//button[@name='createLoginContinueButton']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFetchBuySoliDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFetchBuySoliDetailsPage, ""));
        LogCapture.info("User click on Fetch Buyer Solicitor details ......");
        Thread.sleep(2000);

    }

    @And("^user click on Save and continue button after reviewing Buyers Solicitors details$")
    public void userClickOnSaveAndContinueButtonAfterreviewingBuyersSolicitorsDetails() throws Exception {

        String vObjSaveAndContinueBuySoliDetailsPage = Constants.TitanLoginOR.getProperty("SaveAndContinueonBuyerSolicitiorDetails");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveAndContinueBuySoliDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSaveAndContinueBuySoliDetailsPage, ""));
        LogCapture.info("User click on Save and Continue button after reviewing Buyer solicitors details ......");
        Thread.sleep(2000);
    }

    @When("^User enter buyers Email address \"([^\"]*)\" to fetch buyers account details$")
    public void userEnterBuyersEmailAddressToFetchBuyersAccountDetails(String BuyerEmail) throws Throwable {

        String ObjBuyerEmail = Constants.TitanLoginOR.getProperty("LabelInput");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ObjBuyerEmail, ""));
        Assert.assertEquals("PASS", Constants.key.click(ObjBuyerEmail, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(ObjBuyerEmail, BuyerEmail));
        String Button = "//p[@type='button-large']";
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(Button, ""));
        Constants.key.pause("3", "");
        LogCapture.info("User enters Buyer email to fetch Account details");
    }

    @When("^User enter Seller's Email address \"([^\"]*)\" to fetch sellers account details$")
    public void userEnterSellerSEmailAddressToFetchSellersAccountDetails(String SellerEmail) throws Throwable {

        Thread.sleep(2000);
        String vObjSellerEmail = "//label[text()='Email address']//ancestor::div[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSellerEmail, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSellerEmail, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellerEmail, SellerEmail));
        LogCapture.info("User enter Sellers email as " + SellerEmail);
        Thread.sleep(2000);

        String vObjLookUpDetails = "(//button[@data-testid='rp-button'])[2]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLookUpDetails, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjLookUpDetails, ""));
        LogCapture.info("User Click on look up details to fetch seller details");
        Thread.sleep(2000);


    }

    @And("^user click on Save and continue button after reviewing Sellers account detail$")
    public void userClickOnSaveAndContinueButtonAfterreviewingSellersAccountDetail() throws Exception {

        String vObjSaveAndContinueSellerDetailsPage = "//p[@text='Save and continue']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveAndContinueSellerDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveAndContinueSellerDetailsPage, ""));
        LogCapture.info("User click on Save and Continue button after reviewing sellers account details");

    }

    @Then("^User enter Seller solicitor's Email address \"([^\"]*)\" on Seller’s legal representative page$")
    public void userEnterSellerSolicitorSEmailAddressOnSellerSLegalRepresentativePage(String SellerSoliEmail) throws Throwable {

        String vObjSellerSoliEmail = "//label[text()='Email address']//ancestor::div[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSellerSoliEmail, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSellerSoliEmail, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjSellerSoliEmail, SellerSoliEmail));
        LogCapture.info("User enter Seller solicitor's email as " + SellerSoliEmail);

        String vObjFetchBuySoliDetailsPage = "//button[@name='createLoginContinueButton']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFetchBuySoliDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFetchBuySoliDetailsPage, ""));
        LogCapture.info("User click on Fetch Seller Solicitor details ......");
        Thread.sleep(2000);

    }

    @And("^user click on Save and continue button after reviewing seller Solicitors details$")
    public void userClickOnSaveAndContinueButtonAfterReviewingSellerSolicitorsDetails() throws Exception {

        String vObjSaveAndContinueSellerSoliDetailsPage = Constants.TitanLoginOR.getProperty("detail3");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveAndContinueSellerSoliDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSaveAndContinueSellerSoliDetailsPage, ""));
        LogCapture.info("User click on Save and Continue button after reviewing Seller solicitors details ......");
        Thread.sleep(2000);

    }

    @Then("^User enter  Address \"([^\"]*)\" , Completion Date , Amount paid to date , Final amount and Select Currency as \"([^\"]*)\"$")
    public void userEnterAddressCompletionDateAmountPaidToDateFinalAmountAndSelectCurrencyAs(String PropAddress, String Currecny) throws Throwable {

        Constants.key.pause("2", "");
        String vObjPropertyAddress = "//*[contains(text(),'Address')]//ancestor::*[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.click(vObjPropertyAddress, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjPropertyAddress));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPropertyAddress, PropAddress));
        LogCapture.info("User Enter Property address as " + PropAddress);

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 5);
        String TargetComplectionDate = dateFormat.format(cal.getTime());

        String AmountPaidToDate = Integer.toString(ThreadLocalRandom.current().nextInt(500, 999));

        String vObjTargetCompletionDate = "//*[contains(text(),'Target completion date')]//ancestor::*[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.click(vObjTargetCompletionDate, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjTargetCompletionDate));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjTargetCompletionDate, TargetComplectionDate));
        LogCapture.info("User Enter Target completion date as " + TargetComplectionDate);

        String vObjAmountPaidToDate = "//*[contains(text(),'Amount paid to date')]//ancestor::*[@data-testid='form-control']//input";
        LogCapture.info("entering" + vObjAmountPaidToDate);
        Assert.assertEquals("PASS", Constants.key.click(vObjAmountPaidToDate, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjAmountPaidToDate));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjAmountPaidToDate, AmountPaidToDate));
        LogCapture.info("User Enter Amount paid to date as " + AmountPaidToDate);

        String FinalAmount = Integer.toString(ThreadLocalRandom.current().nextInt(1000, 1500));
        String vObjFinalAmount = "//*[contains(text(),'Final amount')]//ancestor::*[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.click(vObjFinalAmount, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjFinalAmount));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjFinalAmount, FinalAmount));
        LogCapture.info("User Enter Final amount as " + FinalAmount);

        String vObjSelectAmountPaidCurrency = "(//input[@class='MuiInputBase-input MuiFilledInput-input MuiInputBase-inputAdornedStart MuiInputBase-inputAdornedEnd Mui-readOnly MuiInputBase-readOnly css-1g7d3df'])[1]";
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSelectAmountPaidCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectAmountPaidCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.pause("3", ""));

        String vObjlistbox = Constants.TitanLoginOR.getProperty("listbox");
        List<WebElement> AmountPaidToDateCCYlist = driver.findElements(By.xpath(vObjlistbox));

        for (WebElement element : AmountPaidToDateCCYlist) {
            if (element.getText().contains(Currecny)) {

                element.click();
                LogCapture.info("User select Amount paid to date Currency as " + Currecny);
                break;
            }
        }


        String vObjSelectFinalAmountCurrency = "(//input[@class='MuiInputBase-input MuiFilledInput-input MuiInputBase-inputAdornedStart MuiInputBase-inputAdornedEnd Mui-readOnly MuiInputBase-readOnly css-1g7d3df'])[2]";
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSelectFinalAmountCurrency, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));

        List<WebElement> FinalAmountCCYlist = driver.findElements(By.xpath(vObjlistbox));

        for (WebElement element : FinalAmountCCYlist) {
            if (element.getText().contains(Currecny)) {

                element.click();
                System.out.println("User select Final amount Currency as " + Currecny);
                break;
            }
        }
    }

    @And("^user click on Save-continue button after entering mandatory property details$")
    public void userClickOnSaveContinueButtonAfterEnteringMandatoryPropertyDetails() throws Exception {

        String vObjSaveAndContinuePropertyDetailsPage = "//p[@text='Save and continue']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveAndContinuePropertyDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveAndContinuePropertyDetailsPage, ""));
        LogCapture.info("User click on Save and Continue button after entering property details information......");
        Thread.sleep(2000);

    }


    @And("^user click on Save-continue button after selecting (newly created Notary office|Existing Notary office)$")
    public void userClickOnSaveContinueButtonAfterSelectingNewlyCreatedNotaryOffice(String NotartOffice) throws Exception {
        String vObjSaveAndContinuePropertyDetailsPage = "//p[@text='Save and continue']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveAndContinuePropertyDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveAndContinuePropertyDetailsPage, ""));
        LogCapture.info("User click on Save and Continue button after entering property details information......");
        Thread.sleep(2000);

    }

    @Then("^User verify Notary office details on review Notary office details page$")
    public void userVerifyNotaryOfficeDetailsOnReviewNotaryOfficeDetailsPage() throws Exception {

        String vObjNotaryName = "((//div[@class='MuiListItemText-root MuiListItemText-dense MuiListItemText-multiline css-1xar93x']//p))[1]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryName, ""));
        String ActNotaryName = Constants.driver.findElement(By.xpath(vObjNotaryName)).getText();
        if (ActNotaryName.equals(NotaryName)) {
            LogCapture.info("User verify Notary name on notary office details page [" + NotaryName + "]");
        } else {
            LogCapture.info("TC Failed : User unable to verify Notary name on notary office details page");
            Assert.fail();
        }

        String vObjCompanyName = "((//div[@class='MuiListItemText-root MuiListItemText-dense MuiListItemText-multiline css-1xar93x']//p))[2]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCompanyName, ""));
        String ActCompanyName = Constants.driver.findElement(By.xpath(vObjCompanyName)).getText();
        if (ActCompanyName.equals(NOTCompanyName)) {
            LogCapture.info("User verify company name on notary office details page [" + NOTCompanyName + "]");
        } else {
            LogCapture.info("TC Failed : User unable to verify company name on notary office details page");
            Assert.fail();
        }

        String vObjNotaryEmail = "((//div[@class='MuiListItemText-root MuiListItemText-dense MuiListItemText-multiline css-1xar93x']//p))[4]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryEmail, ""));
        String ActNotaryEmail = Constants.driver.findElement(By.xpath(vObjNotaryEmail)).getText();
        if (ActNotaryEmail.equals(NotaryEmail)) {
            LogCapture.info("User verify Notary Email on notary office details page [" + NotaryEmail + "]");
        } else {
            LogCapture.info("TC Failed : User unable to verify Notary Email on notary office details page");
            Assert.fail();
        }


        String vObjNOTOfficePhoneNumber = "((//div[@class='MuiListItemText-root MuiListItemText-dense MuiListItemText-multiline css-1xar93x']//p))[5]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNOTOfficePhoneNumber, ""));
        String ActNOTOfficePhoneNumber = Constants.driver.findElement(By.xpath(vObjNOTOfficePhoneNumber)).getText();
        if (ActNOTOfficePhoneNumber.equals(NOTOfficePhoneNumber)) {
            LogCapture.info("User verify Notary Phone Number on notary office details page [" + NOTOfficePhoneNumber + "]");
        } else {
            LogCapture.info("TC Failed : User unable to verify Notary Phone Number on notary office details page");
            Assert.fail();
        }
    }

    @When("^User fetch (Buyer's|Seller's) account details from RDS database for \"([^\"]*)\" and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment$")
    public void userFetchBuyerSAccountDetailsFromRDSDatabaseForAndCheckStatusCodeAsForOnEnvironment(String Type, String Email, String statCode, String testCaseID, String enviroment) throws Throwable {

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME = enviroment;

        if (Type.equals("Buyer's")) {
            Constants.DynamicValue.put("<CustomerEmail>", Email);
            LogCapture.info("---------------POST call started to fetch Buyer's details----------------");
            Constants.BuyersAccountDetails = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath BuyersAccountDetail = Constants.APIkey.rawToJson(Constants.BuyersAccountDetails);
            LogCapture.info("---------------POST call ended----------------" + BuyersAccountDetails);
        }
        if (Type.equals("Seller's")) {
            Constants.DynamicValue.put("<CustomerEmail>", Email);
            LogCapture.info("---------------POST call started fetch Seller's details----------------");
            Constants.SellersAccountDetails = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath BuyersAccountDetail = Constants.APIkey.rawToJson(Constants.SellersAccountDetails);
            LogCapture.info("---------------POST call ended----------------" + SellersAccountDetails);
        }


    }

    @Then("^User Select language as \"([^\"]*)\"$")
    public void userSelectLanguageAs(String Language) throws Throwable {

        String vObjLang1 = "//span[text()='English (EN) + Español (SPA)']";

        String vObjLang2 = "//span[text()='English (EN) + Español (SPA) + Norsk (NOR)']";

        String vObjLang3 = "//span[text()='English (EN) + Español (SPA) + Svenska (SV)']";

        String vObjLanguage = "//span[text()='" + Language + "']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjLanguage, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjLanguage, ""));


    }


    @And("^User Verify Notary Dashboard with correct details$")
    public void userVerifyNotaryDashboardWithCorrectDetails() throws Exception {
        Constants.key.pause("2", "");
//        String vObjPending = "//p[normalize-space()='Pending']";
//        String vObjprogress = "//p[normalize-space()='In progress']";
//        String vObjCompleted = "//p[normalize-space()='Completed']";
        String vObjPending = Constants.TitanLoginOR.getProperty("vObjPending");
        String vObjprogress = Constants.TitanLoginOR.getProperty("vObjprogress");
        String vObjCompleted = Constants.TitanLoginOR.getProperty("vObjCompleted");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPending, ""));
        LogCapture.info("Pending section visible");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjprogress, ""));
        LogCapture.info("Progress section visible");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCompleted, ""));
        LogCapture.info("Completed section visible");
        Constants.key.pause("2", "");

        String vObj = Constants.TitanLoginOR.getProperty("vObj");
        String vObj5 = Constants.TitanLoginOR.getProperty("vObj5");
        String vObj25 = Constants.TitanLoginOR.getProperty("vObj25");
        Constants.key.click(vObj, "");
        String ObjelementsToClick = Constants.TitanLoginOR.getProperty("elementsToClick");
        String ObjCaseList = Constants.TitanLoginOR.getProperty("CaseList");
        String ObjView = Constants.TitanLoginOR.getProperty("View");
        List<WebElement> elementsToClick = driver.findElements(By.xpath(ObjelementsToClick));
        for (WebElement element : elementsToClick) {
            Constants.key.pause("2", "");
            List<WebElement> CaseList = driver.findElements(By.xpath(ObjCaseList));
            List<WebElement> View = driver.findElements(By.xpath(ObjView));
            String CaseListsizeAsString = String.valueOf(CaseList.size());
            String ViewsizeAsString = String.valueOf(View.size());
            String fiveelement = Constants.key.exist(vObj5, "");
            String tenelement = Constants.key.exist(vObj, "");
            String element25 = Constants.key.exist(vObj25, "");
//            if(fiveelement.equalsIgnoreCase("PASS")){
//                LogCapture.info(fiveelement);
//                LogCapture.info("5 row present");
//                if(!CaseListsizeAsString.equalsIgnoreCase("5") || !ViewsizeAsString.equalsIgnoreCase("5")){
//                    Assert.fail();
//                }
//            }
//            else if(tenelement.equalsIgnoreCase("PASS")){
//                LogCapture.info(tenelement);
//                LogCapture.info("10 row present");
//                if(!CaseListsizeAsString.equalsIgnoreCase("10") || !ViewsizeAsString.equalsIgnoreCase("10")){
//                    Assert.fail();
//                }
//
//            }else if(element25.equalsIgnoreCase("PASS")){
//                LogCapture.info(element25);
//                LogCapture.info("25 row present");
//                if(!CaseListsizeAsString.equalsIgnoreCase("25") || !ViewsizeAsString.equalsIgnoreCase("25")){
//                    Assert.fail();
//                }
//            }
//            Constants.key.pause("2", "");
//            String vObjArrow ="//*[name()='svg'  and @data-testid='ArrowDropDownIcon']";
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjArrow, ""));
//            Constants.key.pause("2", "");
//            LogCapture.info("clicking to page");
//            LogCapture.info(element.getText());
//            Constants.key.pause("2", "");
//            element.click();
        }
    }

//    @And("^User Verify Notary Dashboard with correct details$")
//    public void userVerifyNotaryDashboardWithCorrectDetails() throws Exception {
//
//        Constants.key.pause("2", "");
//        String vObjPending ="//p[normalize-space()='Pending']";
//        String vObjprogress ="//p[normalize-space()='In progress']";
//        String vObjCompleted ="//p[normalize-space()='Completed']";
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjPending, ""));
//        LogCapture.info("Pending section visible");
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjprogress, ""));
//        LogCapture.info("Progress section visible");
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCompleted, ""));
//        LogCapture.info("Completed section visible");
//
//        Constants.key.pause("2", "");
//
//        String vObj ="//*[@class='MuiSelect-select MuiTablePagination-select MuiSelect-standard MuiInputBase-input css-1cccqvr'  and text()='10']";
//        String vObj5 ="//*[@class='MuiSelect-select MuiTablePagination-select MuiSelect-standard MuiInputBase-input css-1cccqvr'  and text()='5']";
//        String vObj25 ="//*[@class='MuiSelect-select MuiTablePagination-select MuiSelect-standard MuiInputBase-input css-1cccqvr'  and text()='25']";
//        List<WebElement> CaseList = driver.findElements(By.xpath("//div[text()='Case']//ancestor::div[@role='grid']//div[@class='MuiDataGrid-cellContent'  and contains(text(),'case')]"));
//        List<WebElement> View = driver.findElements(By.xpath("//*[contains(text(),'View')]"));
//        String CaseListsizeAsString = String.valueOf(CaseList.size());
//        String ViewsizeAsString = String.valueOf(View.size());
//        String  fiveelement =Constants.key.exist(vObj5, "");
//        String  tenelement =Constants.key.exist(vObj, "");
//        String  element25 =Constants.key.exist(vObj25, "");
//        if(tenelement.equalsIgnoreCase("PASS")){
//            LogCapture.info(tenelement);
//            LogCapture.info("10 row present");
//            if(!CaseListsizeAsString.equalsIgnoreCase("10") || !ViewsizeAsString.equalsIgnoreCase("10")){
//                Assert.fail();
//            }
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObj, ""));
//           List<WebElement> elementsToClick = driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
//        for (WebElement element : elementsToClick) {
//
//            Constants.key.click(vObj5, "");
//            Constants.key.click(vObj25, "");
//            element.click();
////div[@aria-label='Cases']//ancestor::div[@role="grid"]
//            List<WebElement> CaseList = driver.findElements(By.xpath("//div[text()='Case']//ancestor::div[@role='grid']//div[@class='MuiDataGrid-cellContent'  and contains(text(),'case')]"));
//            List<WebElement> View = driver.findElements(By.xpath("//*[contains(text(),'View')]"));
//            String CaseListsizeAsString = String.valueOf(CaseList.size());
//            String ViewsizeAsString = String.valueOf(View.size());
//            String  fiveelement =Constants.key.exist(vObj5, "");
//            String  tenelement =Constants.key.exist(vObj, "");
//            String  element25 =Constants.key.exist(vObj25, "");
//            if(fiveelement.equalsIgnoreCase("PASS")){
//                LogCapture.info(fiveelement);
//                LogCapture.info("5 row present");
//                if(!CaseListsizeAsString.equalsIgnoreCase("5") || !ViewsizeAsString.equalsIgnoreCase("5")){
//                    Assert.fail();
//                }
////                Assert.assertEquals("PASS", Constants.key.click(vObj5, ""));
//            }
//            else if(tenelement.equalsIgnoreCase("PASS")){
//                LogCapture.info(tenelement);
//                LogCapture.info("10 row present");
//                if(!CaseListsizeAsString.equalsIgnoreCase("10") || !ViewsizeAsString.equalsIgnoreCase("10")){
//                    Assert.fail();
//                }
////                Assert.assertEquals("PASS", Constants.key.click(vObj , ""));
//
//            }else if(element25.equalsIgnoreCase("PASS")){
//                LogCapture.info(element25);
//                LogCapture.info("25 row present");
//                if(!CaseListsizeAsString.equalsIgnoreCase("25") || !ViewsizeAsString.equalsIgnoreCase("25")){
//                    Assert.fail();
//                }
////               Assert.assertEquals("PASS", Constants.key.click(vObj25 , ""));
//            }
////            System.out.println("Clicked on element: " + element.getText());
////           String vObjArrow ="//*[name()='svg'  and @data-testid='ArrowDropDownIcon']";
////            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjArrow, ""));
//        }
//    }

    @Then("^User lands on (Buyer's details|) page and validate (Email address|)\"([^\"]*)\" (Full name|)\"([^\"]*)\" (CD Account number|)\"([^\"]*)\" Address\"([^\"]*)\" Passport number\"([^\"]*)\" Phone number\"([^\"]*)\"$")
    public void userLandsOnBuyerSDetailsPageAndValidateEmailAddressFullNameCDAccountNumberAddressPassportNumberPhoneNumber(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        //*[contains(text(),' Buyer’s details')]
        //*[text()='Email address']/following-sibling::p
    }

    //    Postcode "<Postcode>" Paid date "<Paid date>" Completion date
    //   Address"<Address>" Passport number"<Passport>" Phone numberNotary name"<Fullname>" Company namePaid date"<Paid date>" Completion date"<Completion date>" Amount"<Amount>
    @Then("^User lands on (Transaction details|Notary’s detail|Buyer's details|Seller’s details|Seller’s legal|Notary details|Buyer’s information|Buyer’s legal|Seller’s information|Seller’s legal|Property information|Seller's POA|Buyer's POA|) page and validate (Email address|Address|Final amount|Paid date|Buyer's Email address|Seller's Email address)\"([^\"]*)\" (Full name|Passport number|Email Address|Notary name|Paid date|Buyer's name|Seller's name|Notary Name|Amount to be Paid)\"([^\"]*)\" (CD Account number|Phone number|Company name|Completion date|Address|Company Name|Target completion date)\"([^\"]*)\"$")
    public void userLandsOnBuyerSDetailsPageAndValidateEmailAddressFullNameCDAccountNumber(String Page, String detail1, String value1, String detail2, String value2, String detail3, String value3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjPage = "//*[contains(text(),'" + Page + "')]";
        String vObjdetail1 = "//*[text()='" + detail1 + "']/following-sibling::*[text()='" + value1 + "']";
        String vObjdetail2 = "//*[text()='" + detail2 + "']/following-sibling::*[text()='" + value2 + "']";
        String vObjdetail3 = "//*[text()='" + detail3 + "']/following-sibling::*[text()='" + value3 + "']";

//        String vObjdetail1 = "//*[text()='" + detail1 + "']/following-sibling::*[contains(normalize-space(),='" + value1 + "')]";
//        String vObjdetail2 = "//*[text()='" + detail2 + "']/following-sibling::*[contains(normalize-space(), '" + value2 + "')]";
//        String vObjdetail3 = "//*[text()='" + detail3 + "']/following-sibling::*[contains(normalize-space(), '" + value3 + "')]";

        //*[text()='Address']/following-sibling::*[contains(normalize-space(), "test 03501 testcity test D03")]
        LogCapture.info(vObjPage + vObjdetail1 + vObjdetail2 + vObjdetail3);

        LogCapture.info("Verifying" + Page);
//        Assert.assertEquals("PASS", Constants.key.exist(vObjPage, ""));
        LogCapture.info("Verifying" + detail1 + value1);
        Assert.assertEquals("PASS", Constants.key.exist(vObjdetail1, ""));
        LogCapture.info("Verifying" + detail2 + value2);
        Assert.assertEquals("PASS", Constants.key.exist(vObjdetail2, ""));
        LogCapture.info("Verifying" + detail3 + value3);
//        Assert.assertEquals("PASS", Constants.key.exist(vObjdetail3, ""));
    }

    @And("^user click on Save and continue button$")
    public void userClickOnSaveAndContinueButton() throws Exception {
        Constants.key.pause("3", "");

        //*[contains(text(),'case-')]
        String vObjdetail3 = Constants.TitanLoginOR.getProperty("detail3");
        String vObjdetail4 = Constants.TitanLoginOR.getProperty("detail4");
        String vObjdetail6 = Constants.TitanLoginOR.getProperty("detail6");
        String vObjdetail7 = "//p[@type='button-medium']";

        LogCapture.info("Verifying Save and continue");
        String vObjdetail = Constants.key.Mouse_Events(vObjdetail3, "");
        LogCapture.info("Verifying Save and continue in first");
        if (!vObjdetail.equalsIgnoreCase("PASS")) {

            String vObjdetail5 = Constants.key.navigateSubMenu(vObjdetail4, "");
            LogCapture.info("Verifying Save and continue in 2");
            if (!vObjdetail5.equalsIgnoreCase("PASS")) {

                String vObjde7 = Constants.key.click(vObjdetail6, "");
                LogCapture.info("Verifying Save and continue in 3");
                if (!vObjde7.equalsIgnoreCase("PASS")) {
                    Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail7, ""));

                }
            }
        }
        Constants.key.pause("2", "");
    }

    @Then("^User enter (Email address|)\"([^\"]*)\" on (Buyer’s legal|Seller’s information|Seller’s legal) page$")
    public void userEnterEmailAddressOnBuyerSLegalPage(String detail, String value, String page) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjPage = "//*[contains(text(),'" + page + "')]";
        LogCapture.info("Verifying " + page);
//        Assert.assertEquals("PASS", Constants.key.exist(vObjPage, ""));
        String vObjdetail1 = "//label[text()='" + detail + "']//ancestor::div[@data-testid='form-control']//input";
        Assert.assertEquals("PASS", Constants.key.click(vObjdetail1, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail1, value));
        LogCapture.info("User enter Buyers solicitor email as " + value);

    }


//    Then User enter  Postcode "<Emailaddress>" Paid date "<Emailaddress>" Completion date"<Emailaddress>"Amount paid"<Emailaddress>" on Seller’s information page

    @Then("^User enter  (Address Line1|Postcode|Final) \"([^\"]*)\" (Address Line2|Paid date|Notary Name) \"([^\"]*)\" (State|Completion date|final amt|Company Name)\"([^\"]*)\"(Town|Amount|Phone Number)\"([^\"]*)\" on (Seller’s information|Property details|Notary’s details) page$")
    public void userEnterAddressLineAddressLineStateTownOnSellerSInformationPage(String detail1, String value1, String detail2, String value2, String detail3, String value3, String detail4, String value4, String page) throws Throwable {
        // Write code here that turns the phrase above into concrete actions //*[contains(text(),'final amt')]//parent::div
        String vObjPage = "//*[contains(text(),'" + page + "')]";
        LogCapture.info("Verifying" + page);
        String vObjdetail1 = "//*[contains(text(),'" + detail1 + "')]//ancestor::*[@data-testid='form-control']//input";
        LogCapture.info("Verifying" + detail1 + value1);
        Assert.assertEquals("PASS", Constants.key.click(vObjdetail1, ""));

        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail1, value1));
        String vObjdetail2 = "//*[contains(text(),'" + detail2 + "')]//ancestor::*[@data-testid='form-control']//input";
        LogCapture.info("Verifying" + detail2 + value2);
        Assert.assertEquals("PASS", Constants.key.click(vObjdetail2, ""));

        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail2, value2));
        String vObjdetail3 = "//*[contains(text(),'" + detail3 + "')]//ancestor::*[@data-testid='form-control']//input";
        String vObj3 = Constants.key.exist(vObjdetail3, "");
        String vObjdetail4 = "//*[contains(text(),'" + detail4 + "')]//ancestor::*[@data-testid='form-control']//input";
        String vObj4 = Constants.key.exist(vObjdetail4, "");
        String vArrow1 = "//*[contains(text(),'" + detail3 + "')]//parent::div//*[local-name()='svg' ]";
        String Arrow1 = Constants.key.exist(vObjdetail3, "");
        String vArrow2 = "//*[contains(text(),'" + detail4 + "')]//parent::div//*[local-name()='svg' ]";
        String Arrow2 = Constants.key.exist(vObjdetail4, "");
        LogCapture.info("Verifying" + detail3 + value3);
        Assert.assertEquals("PASS", Constants.key.click(vObjdetail3, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail3, value3));

        LogCapture.info("Verifying" + detail4 + value4);
        Assert.assertEquals("PASS", Constants.key.click(vObjdetail4, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail4, value4));

//
////*[contains(text(),'final amt')]//parent::div//*[local-name()='svg' ]
//        if (Arrow1.equalsIgnoreCase("PASS")) {
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.click(vArrow1, ""));
//            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(value3, "enter"));
//
//        }else if(Arrow2.equalsIgnoreCase("PASS"))
//        {
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.click(vArrow2, ""));
//            Assert.assertEquals("PASS", Constants.key.pause("5", ""));
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(value4, "enter"));
//
//        }else if(vObj3.equalsIgnoreCase("PASS"))
//        {
//            LogCapture.info("Verifying"+detail3+value3);
//            Assert.assertEquals("PASS", Constants.key.click(vObjdetail3, ""));
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail3, value3));
//
//
//        }
//        else if(vObj4.equalsIgnoreCase("PASS"))
//        {
//            LogCapture.info("Verifying"+detail4+value4);
//            Assert.assertEquals("PASS", Constants.key.click(vObjdetail4, ""));
//            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail4, value4));
//
//        }
    }

//    @Then("^User enter or select (Final amount|final amt currency|paid currency) \"<Finalamount>$")
//    public void userEnterOrSelectFinalAmountFinalamount(String detail,String value ) throws Throwable {
//
//    }

    @Then("^User enter or select (Select notary|Select amount paid currency|Select final amount currency|Final amount|final amt currency|paid currency|your notary|Select language) \"([^\"]*)\"$")
    public void userEnterOrSelectFinalAmount(String detail, String value) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        String vObjdetail ="//*[contains(text(),'"+detail+"')]//ancestor::*[@data-testid='form-control']//input";
//        String vObj = Constants.key.exist(vObjdetail, "");
//        LogCapture.info("Verifying" +caseID );
        String vArrow = "//*[contains(text(),'" + detail + "')]//parent::div//*[local-name()='svg' ]";
//        String Arrow = Constants.key.exist(vArrow, "");
        // Write code here that turns the phrase above into concrete actions
        if (detail.equalsIgnoreCase("Select language")) {
            TPALang = value;
        }
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vArrow, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(value, "enter"));
        String vObjlistbox = Constants.TitanLoginOR.getProperty("listbox");
        List<WebElement> listElements = driver.findElements(By.xpath(vObjlistbox));

        // Iterate through the list elements
        for (WebElement element : listElements) {
            // Check if the element text contains "Bahraini Dinar"
//            System.out.println(" element containing " + element + element.getText());
            if (element.getText().contains(value)) {
                // Click on the element
                element.click();
//                Assert.assertEquals("PASS", Constants.key.pause("50000", ""));
                System.out.println("Clicked on the element containing ." + value);
                break; // Exit the loop after clicking the element
            }
        }
    }


    @And("^user click on button (Send TPA form to Buyer|Send TPA form to Seller|Request buyer disbursements)$")
    public void userClickOnButtonSendPOAFormToBuyer(String button) throws Exception {
        String vObjdetail = "//button//*[normalize-space()='" + button + "']";
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));

        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjdetail, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));

        String vObjCase = "//*[contains(text(),'case-')]";

//        caseID = vObjCase.getText();

//        String vObjRecipientName = "//span[@id='confirmationBenificiaryName0']";
        caseID = driver.findElement(By.xpath(vObjCase)).getText();
        LogCapture.info("######  caseID : " + caseID);
        LogCapture.info(caseID);
//       Assert.assertEquals("PASS", Constants.key.verifyText(vObjdetail, caseID));

        //h2[@type='bold']

    }

    @And("^user verify text \"([^\"]*)\" on (Seller Disbursements|Sent|Buyer Disbursements) page$")
    public void userVerifyTextOnSellerDisbursementsPage(String text, String page) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjdetail = "//*[text()='" + text + "']";
//        LogCapture.info(vObjPage+vObjdetail1+vObjdetail2+vObjdetail3 );
        Assert.assertEquals("PASS", Constants.key.exist(vObjdetail, ""));
    }

    @And("^User selects the (Add a new case|Dashboard) option and lands to same page$")
    public void userSelectsTheAddANewCaseOptionAndLandsToSamePage(String Page) throws Exception {

        // Get all the text on the page
//        String allText = driver.findElement(By.tagName("body")).getText();
//        System.out.println(allText); //p[text()='Add a new case']

//        Constants.key.pause("5", "");
        String ObjPage = "//p[text()='" + Page + "']";
        Constants.key.pause("2", "");
        //    String ObjPage = Constants.TitanLoginOR.getProperty("ObjPage");
//        String ObjPage = "//div[@class='MuiCardContent-root css-9ym5fk']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ObjPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(ObjPage, ""));
//        String ObjPage = "//p[@class='MuiTypography-root MuiTypography-body1 css-ev1pjb']";
////        String ObjPage = "//*[@text='"+Page+"']";
//        Constants.key.pause("2", "");
//        LogCapture.info(ObjPage);
//        Constants.key.Mouse_Events(Page,"");
//        Assert.assertEquals("PASS", Constants.key.exist(Page, ""));
    }

    @Then("^User validates default language option is selected$")
    public void userValidatesDefaultLanguageOptionIsSelected() throws Exception {

        String ObjPage = Constants.TitanLoginOR.getProperty("checked");
        String Button = Constants.TitanLoginOR.getProperty("Button");
//        Constants.key.click(Page,"");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.exist(ObjPage, ""));

        //p[@type='button-large']
        Constants.key.pause("2", "");
        LogCapture.info("verifying defoult lang en-es");

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(Button, ""));
    }

    @When("^User verify label (Email address|) and write \"([^\"]*)\"$")
    public void userVerifyLabelEmailAddressAndWrite(String label, String labelinput) throws Throwable {
//        String ObjLabel = "//label[normalize-space()='" + label + "']";
        String ObjLabelInput = Constants.TitanLoginOR.getProperty("LabelInput");
//        String Button = Constants.TitanLoginOR.getProperty("Button");
//        String ObjLabelInput = "//input[@name='email']";

//        String ObjLabel = "//input[@name='email']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(ObjLabelInput, ""));
        Assert.assertEquals("PASS", Constants.key.click(ObjLabelInput, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(ObjLabelInput, labelinput));
        String Button = "//p[@type='button-large']";
        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(Button, ""));
        Constants.key.pause("5", "");
    }


    @Then("^User enter  (Completion date|Final amount|final amt currency|paid currency|Email address|Address|Amount paid|Target completion date|Total|Buyer email address|CD account number|House register|Finca no|Tomo|Libro|Folio) \"([^\"]*)\"$")
    public void userEnterFinalAmount(String detail, String value) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Constants.key.pause("3", "");
        String vObjdetail = "//*[contains(text(),'"+detail+"')]//ancestor::*[@data-testid='form-control']//input";
        LogCapture.info("entering" + detail);
        Assert.assertEquals("PASS", Constants.key.click(vObjdetail, ""));
        Assert.assertEquals("PASS", Constants.key.clearText(vObjdetail));
        Constants.key.pause("2", "");
        if(detail.equalsIgnoreCase("Target completion date")){
            Assert.assertEquals("PASS", Constants.key.Date(vObjdetail, "future"));

        }
        else {
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail, value));
        }

    }

    @Then("^User change language to \"([^\"]*)\"$")
    public void userChangeLanguageTo(String lang) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjdetail = "//span[normalize-space()='" + lang + "']";
        LogCapture.info("Verifying" + lang);
        DocuSignformsLang = lang;
        Constants.key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
        Constants.key.pause("2", "");
    }


    @And("^User selects the Add a new case option from Notaries frame$")
    public void userSelectsTheAddANewCaseOptionFromNotariesFrame() throws Exception {
        String vObjdetail = Constants.TitanLoginOR.getProperty("newcase");

//        LogCapture.info("Verifying" + lang);


        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
        Constants.key.pause("2", "");
    }


    @Then("^User enter or select Select language \"([^\"]*)\" for seller$")
    public void userEnterOrSelectSelectLanguageForSeller(String value) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        //  String listbox = Constants.TitanLoginOR.getProperty("newcase");
        String vArrow = Constants.TitanLoginOR.getProperty("Arrow");
        String Arrow = Constants.key.exist(vArrow, "");
        // Write code here that turns the phrase above into concrete actions

        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.click(vArrow, ""));
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
//            Assert.assertEquals("PASS", Constants.key.KeyboardAction(value, "enter"));

        List<WebElement> listElements = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        // Iterate through the list elements
        for (WebElement element : listElements) {
            // Check if the element text contains "Bahraini Dinar"
            if (element.getText().contains(value)) {
                // Click on the element
                element.click();
                System.out.println("Clicked on the element containing ." + value);
                break; // Exit the loop after clicking the element
            }
        }
    }

    @And("^User selects the Notaries offices option from Notaries frame$")
    public void userSelectsTheNotariesOfficesOptionFromNotariesFrame() throws Exception {

//        String vObjdetail = "//p[normalize-space()='Notary offices']";
        String vObjdetail = Constants.TitanLoginOR.getProperty("offices");
        String vObjdetail2 = Constants.TitanLoginOR.getProperty("button-medium");
//        LogCapture.info("Verifying" + lang);
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
        Constants.key.pause("3", "");

//        String vObjdetail2 = "//p[@type='button-medium']";
//        LogCapture.info("Verifying" + lang);
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail2, ""));
        Constants.key.pause("2", "");
        //p[@type='button-medium']

    }


    @Then("^User in Notary Offices page added detail appear in first row  (companyName|notaryName|)\"([^\"]*)\"$")
    public void userInNotaryOfficesPageAddedDetailAppearInFirstRowCompanyName(String data, String value) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjdetail = "//*[@data-field='" + data + "'and @class='MuiDataGrid-cell MuiDataGrid-cell--textLeft MuiDataGrid-withBorderColor']";
//        LogCapture.info("Verifying" + lang);
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.verifyText(vObjdetail, value));
        Constants.key.pause("2", "");

    }

    @And("^User navigate to mailinator Calypso portal \"([^\"]*)\"$")
    public void userNavigateToMailinatorCalypsoPortal(String mailinator) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String url = mailinator;
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
    }

    @Then("^User capture case ID for reuse$")
    public void userCaptureCaseIDForReuse() throws Exception {
        String vObjdetail4 = "//*[contains(text(),'case-')]";

        Constants.key.pause("3", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjdetail4, ""));
//        Assert.assertEquals("PASS", Constants.key.getText(vObjdetail4, ""));

//        caseID = vObjdetail4.getText();
        caseID = Constants.key.getText(vObjdetail4, "");
        LogCapture.info("Verifying" + caseID);
//        WebElement element = driver.findElement(By.xpath("//h2[@type='bold']"));
//        caseID = element.getText();
//        LogCapture.info("Verifying" +caseID );
    }

    @Then("^User click on save button$")
    public void userClickOnSaveButton() throws Exception {
        Constants.key.pause("2", "");
        String vObjdetail4 = "//*[@type='button-medium' and @text='Save and continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail4, ""));
//        String vObjdetail5 =   Constants.key.navigateSubMenu(vObjdetail4, "");
        Constants.key.pause("2", "");
//        String vObjdetailc="//*[@type=\"button-medium\" and @text=\"Save and continue\"]";
//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjdetailc, ""));
//        Constants.key.pause("2", "");
//        String vObjdetaild="//button[@class=\"MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium css-cvy2gw\"]";
//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjdetaild, ""));
//        Constants.key.pause("2", "");
//        String vObjdetaile="//button[@class=\"MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium MuiButton-root MuiButton-contained MuiButton-containedPrimary MuiButton-sizeMedium MuiButton-containedSizeMedium css-cvy2gw\"]";
//        Assert.assertEquals("PASS", Constants.key.click(vObjdetaild, ""));
    }

    @When("^User enter Calypso UserName \"([^\"]*)\" and click on search button$")
    public void userEnterCalypsoUserNameAndClickOnSearchButton(String email) throws Throwable {
        //  String vObjEmailInbox=Constants.CalypsoRecipientOR.getProperty("EmailInbox");
        //input[@name="search"  and  @id="search"]
        String vObjEmailInbox = "//input[@name='search'  and  @id='search']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
        //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
        String vObjSearchButton = "//button[@value='Search for public inbox for free']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
        LogCapture.info("User enter emailAddress and click on search");
        Constants.key.pause("2", "");
    }

    @And("^User received \"([^\"]*)\" and \"([^\"]*)\" into mail$")
    public void userReceivedAndIntoMail(String Title, String Message) throws Throwable {
        String vObjFirestMail = "//td[contains(text(),'" + Title + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
        String vObjFrame = "//iframe[@id='html_msg_body']";
        Constants.key.frame(vObjFrame, "");
        String vObjMail = "//*[text()='" + Message + " ']";
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMail, ""));
//        Constants.key.verifyText(vObjMail, Message);
        Constants.key.pause("2", "");
        String vObjReviwe = "//span[normalize-space()='REVIEW DOCUMENT']";
//        Constants.key.navigateSubMenu(vObjReviwe, "");
//        LogCapture.info("User verify text from received mail");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));


        // Switch to the new window
        String mainWindowHandle = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(mainWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

        Constants.key.pause("3", "");


        // Find the element using the provided locator
        WebElement element = driver.findElement(By.xpath("//div[@class='fixed-top' and @style='position: fixed;']"));

        // Click on the element
        element.click();

        // Get the text of the clicked element
        String text = element.getText();
        System.out.println("Text of the element: " + text);

        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
//        Constants.key.navigateSubMenu(vObjReviwe, "");
//        LogCapture.info("User verify text from received mail");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
//        WebElement newPageButton = driver.findElement(By.id("//*[@id=\"disclosureAccepted\" and @type=\"checkbox\"]"));
//        newPageButton.click();
//        Constants.key.pause("2", "");
        Constants.key.pause("2", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        String vObjpdfname1 = "//div[@id='tab-form-element-669d2e16-2aa3-46cf-ba86-c85055a7de58']";
        String vObjpdfname2 = "//div[@id='tab-form-element-143b3dae-8f25-47ee-9340-70351549c869']";
        String vObjpdfname3 = "//div[@id='tab-form-element-30de58c3-8edf-4ece-b693-a502720ed507']";
        String vObjpdfname4 = "//div[@id='tab-form-element-669d2e16-2aa3-46cf-ba86-c85055a7de58']";

        Constants.key.navigateSubMenu(vObjReviwe, "");
        LogCapture.info("User verify text from received mail");

        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname1, "Sathiyanew Sathiyanew"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname2, "Aboli NOT Soli"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname3, "Sathiyanew Sathiyanew"));
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname4, ""));
        // After finishing operations on the new window, you can switch back to the main window if needed
//        driver.switchTo().window(mainWindowHandle);
//        Constants.key.pause("5000", "");
        //button[@id='action-bar-btn-continue']
        //div[@id='tab-form-element-57c43ab3-c496-4722-951b-46015f0d0d06']//span[@aria-hidden='true'][normalize-space()='Sathiyanew Sathiyanew']

        //div[@id='tab-form-element-669d2e16-2aa3-46cf-ba86-c85055a7de58']


        //div[@class="tab-form-element locked singleline"]//span[@aria-hidden="true"]
        //div[@id='tab-form-element-a77586f6-be0b-4a32-a650-af813f565324']


        //label[@for="disclosureAccepted"  and @class="cb_label"]
    }

    @And("^User perform back and forward motion$")
    public void userPerformBackAndForwardMotion() throws Exception {
        String vObjdetail2 = Constants.TitanLoginOR.getProperty("back");
//        LogCapture.info("Verifying" + lang);
        Constants.key.pause("2", "");
        // Get the current URL
        String currentUrl = driver.getCurrentUrl();
        System.out.println("Current URL: " + currentUrl);
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail2, ""));


//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
        Constants.key.pause("3", "");
        driver.navigate().to(currentUrl);
        Constants.key.pause("2", "");

    }

    @And("^user click on Save-continue button$")
    public void userClickOnSaveContinueButton() throws Exception {
        String vObjdetail3 = "//p[@type='button-medium' and @text='Save and continue']";
        LogCapture.info("Verifying Save and continue");
        String vObjdetail = Constants.key.navigateSubMenu(vObjdetail3, "");
        Constants.key.pause("2", "");
    }

    @And("^User click on for reviwe document and verify details in POA form document$")
    public void userClickOnForReviweDocumentAndVerifyDetailsInPOAFormDocument() {
    }

    @And("^open mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" reviwe document and verify details\"([^\"]*)\" \"([^\"]*)\" in POA form document$")
    public void openMailAndReviweDocumentAndVerifyDetailsInPOAFormDocument(String mailinator, String Title, String Message, String email, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String currentUrlPage = driver.getCurrentUrl();
        System.out.println("Current URL of the first page: " + currentUrlPage);


        String url = mailinator;
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        String vObjEmailInbox = "//input[@name='search'  and  @id='search']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
        //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
        String vObjSearchButton = "//button[@value='Search for public inbox for free']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
        LogCapture.info("User enter emailAddress and click on search");
        Constants.key.pause("2", "");


        String vObjFirestMail = "//td[contains(text(),'" + Title + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
        String vObjFrame = "//iframe[@id='html_msg_body']";
        Constants.key.frame(vObjFrame, "");
        String vObjMail = "//*[text()='" + Message + " ']";
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjMail, ""));
//        Constants.key.verifyText(vObjMail, Message);
        Constants.key.pause("2", "");
        String vObjReviwe = "//span[normalize-space()='REVIEW DOCUMENT']";
//        Constants.key.navigateSubMenu(vObjReviwe, "");
//        LogCapture.info("User verify text from received mail");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));


        // Switch to the new window
        String mainWindowHandle = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(mainWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

        Constants.key.pause("3", "");


        // Find the element using the provided locator
        WebElement element = driver.findElement(By.xpath("//div[@class='fixed-top' and @style='position: fixed;']"));

        // Click on the element
        element.click();

        // Get the text of the clicked element
        String text = element.getText();
        System.out.println("Text of the element: " + text);

        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
//        Constants.key.navigateSubMenu(vObjReviwe, "");
//        LogCapture.info("User verify text from received mail");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
//        WebElement newPageButton = driver.findElement(By.id("//*[@id=\"disclosureAccepted\" and @type=\"checkbox\"]"));
//        newPageButton.click();
//        Constants.key.pause("2", "");
        Constants.key.pause("2", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        String vObjpdfname1 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[1]";
        String vObjpdfname2 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[2]";
        String vObjpdfname3 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[3]";
//        String vObjpdfname4 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[1]";

        Constants.key.navigateSubMenu(vObjReviwe, "");
        LogCapture.info("User verify text from received mail");

        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname1, "Sathiyanew Sathiyanew"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname2, "soli con 1"));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname3, "Sathiyanew Sathiyanew"));
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname4, ""));
        // After finishing operations on the new window, you can switch back to the main window if needed
//        driver.switchTo().window(mainWindowHandle);
//        Constants.key.pause("5000", "");
        //button[@id='action-bar-btn-continue']
        //div[@id='tab-form-element-57c43ab3-c496-4722-951b-46015f0d0d06']//span[@aria-hidden='true'][normalize-space()='Sathiyanew Sathiyanew']

        //div[@id='tab-form-element-669d2e16-2aa3-46cf-ba86-c85055a7de58']


        //div[@class="tab-form-element locked singleline"]//span[@aria-hidden="true"]
        //div[@id='tab-form-element-a77586f6-be0b-4a32-a650-af813f565324']


        //label[@for="disclosureAccepted"  and @class="cb_label"]


        driver.get(currentUrlPage);
    }

    @And("^open mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" reviwe document and verify details\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\" in POA form document$")
    public void openMailAndReviweDocumentAndVerifyDetailsInPOAFormDocument(String mailinator, String Title, String Message, String email, String Buyerseller, String legalrp) throws Throwable {
        Assert.assertEquals("PASS", Constants.key.mailinatorlink(email, Title));
        //String maillink = Constants.key.getEmailUsingSubject(email, "links", Title);
        String vObjReviwe = "//span[normalize-space()='" + Message + "']";
        Constants.key.pause("3", "");
        Constants.key.pause("5", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
        Constants.key.pause("4", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        String vObjpdfname1 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[1]";
        String vObjpdfname2 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[2]";
        String vObjpdfname3 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[4]";
//        String vObjfullname = "//input[@id='full-name']";
        String vObjinitials = "//input[@id='initials']";
        String vObjAdopt = "//button[normalize-space()='Adopt and Sign']";


        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";

        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";


        //        String vObjpdfname4 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[1]";

        Constants.key.navigateSubMenu(vObjReviwe, "");
        LogCapture.info("User verify text from received mail");
//
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname1, Buyerseller));
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname2, legalrp));
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname3, "Sathiyanew Sathiyanew"));
        Constants.key.pause("2", "");


        Assert.assertEquals("PASS", Constants.key.Date(vObjDate, "present"));
        String vObjSigne = Constants.key.notexist(vObjSigniture, "");
        Constants.key.pause("3", "");
        //      if(vObjSigne.equalsIgnoreCase("PASS")){
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjsign, ""));
        Constants.key.pause("5", "");
   //     Constants.key.pause("3", "");
        WebElement popupButton = driver.findElement(By.xpath("//button[normalize-space()='Adopt and Sign']"));
        popupButton.click();

        //  }

        Constants.key.pause("2", "");

        String vObjfinish = "//button[@id='end-of-document-btn-finish']";
//        String vObjfinish2 ="//button[@id='end-of-document-btn-finish']";
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));
//        Constants.key.Mouse_Events(vObjfinish, "");
        Constants.key.pause("2", "");
        Constants.key.navigateSubMenu(vObjfinish, "");
        Constants.key.pause("12", "");
        // Close the main window or continue with further operations

    }

    @Then("^User enter  (Notary Name *|Address Line1 *|Address Line2 *|Postcode *|State *|Town *|Company Name|Final amount|final amt currency|paid currency|Email address|Address|Amount paid|Completion date|Address Line1|Address Line2|Town|State|Phone Number|Postcode|Notary Name *)$")
    public void userEnterEmailAddress(String detail) throws Exception {
        String vObjdetail = "//*[contains(text(),'" + detail + "')]//ancestor::*[@data-testid='form-control']//input";

        LogCapture.info("Verifying" + detail);
        if (detail.equalsIgnoreCase("Address Line2 *") || detail.equalsIgnoreCase("Address Line1 *") || detail.equalsIgnoreCase("Notary Name *") || detail.equalsIgnoreCase("Postcode *") || detail.equalsIgnoreCase("State/County *") || detail.equalsIgnoreCase("Town/City *") || detail.equalsIgnoreCase("Notary Name *") || detail.equalsIgnoreCase("Address Line2")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randomname"));
        } else if (detail.equalsIgnoreCase("Final amount") || detail.equalsIgnoreCase("paid currency") || detail.equalsIgnoreCase("final amt currency") || detail.equalsIgnoreCase("Amount paid") || detail.equalsIgnoreCase("Postcode")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randomnumber"));
        } else if (detail.equalsIgnoreCase("Email address")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randommail"));
        } else if (detail.equalsIgnoreCase("Completion date")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randomfuturedate"));

        } else if (detail.equalsIgnoreCase("Phone Number")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randomnumber"));

        }

    }


    @Then("^Then User verify(Notary’s detail|Buyer's details|Seller’s details|Seller’s legal|Notary details|Buyer’s information|Buyer’s legal|Seller’s information|Seller’s legal|Property information|Seller's POA|Buyer's POA|) page and validate (Email address|Address|Final amount|Paid date|Buyer's Email address|Seller's Email address)(Full name|Passport number|Email Address|Notary name|Paid date|Buyer's name|Seller's name|Notary Name)(CD Account number|Phone number|Company name|Completion date|Address|Company Name)$")
    public void userLandsOnNotarySDetailPageAndValidateRandomCreatedEmailAddressNotaryNamePhoneNumber(String Page, String detail1, String detail2, String detail3) throws Exception {
        String vObjPage = "//*[contains(text(),'" + Page + "')]";
        String vObjdetail1 = "//*[text()='" + detail1 + "']";
        String vObjdetail2 = "//*[text()='" + detail2 + "']";
        String vObjdetail3 = "//*[text()='" + detail3 + "']";
        LogCapture.info(vObjPage + vObjdetail1 + vObjdetail2 + vObjdetail3);

        LogCapture.info("Verifying" + Page);
//        Assert.assertEquals("PASS", Constants.key.exist(vObjPage, ""));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail1, "randomname"));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail2, "randomnumber"));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail3, "randomnmail"));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail2, "randomnumber"));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail3, "randomfuturedate"));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail3, "randompastdate"));
//        Assert.assertEquals("PASS", Constants.key.exist(vObjdetail3, ""));

    }

    @Then("^User verify  (Notary’s detail|Buyer's details|Seller’s details|Seller’s legal|Notary details|Buyer’s information|Buyer’s legal|Seller’s information|Seller’s legal|Property information|Seller's POA|Buyer's POA|) page and validate random created (Email address|Address|Final amount|Paid date|Buyer's Email address|Seller's Email address) (Full name|Passport number|Email Address|Notary name|Paid date|Buyer's name|Seller's name|Notary Name) (Phone number|) (CD Account number|Phone number|Company name|Completion date|Address|Company Name|Notary Name|State/County *)$")
    public void userVerifyNotarySDetailPageAndValidateRandomCreatedEmailAddressNotaryNamePhoneNumberCompletionDate(String Page, String detail1, String detail2, String detail3, String detail4) throws Exception {
        String vObjPage = "//*[contains(text(),'" + Page + "')]";
        String vObjdetail1 = "//*[text()='" + detail1 + "']";
        String vObjdetail2 = "//*[text()='" + detail2 + "']";
        String vObjdetail3 = "//*[text()='" + detail3 + "']";
        String vObjdetail4 = "//*[text()='" + detail4 + "']";
        LogCapture.info(vObjPage + vObjdetail1 + vObjdetail2 + vObjdetail3);

        LogCapture.info("Verifying" + Page);
//        Assert.assertEquals("PASS", Constants.key.exist(vObjPage, ""));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail2, "randomname"));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail3, "randomnumber"));
        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail1, "randomnmail"));
//        Assert.assertEquals("PASS", Constants.key.exist(vObjdetail3, ""));

    }

    @Then("^User in Notary Offices page verify created data (notaryName|) in first row$")
    public void userInNotaryOfficesPageVerifyCreatedDataNotaryNameInFirstRow(String data) throws Exception {
        String vObjdetail = "//*[@data-field='" + data + "'and @class='MuiDataGrid-cell MuiDataGrid-cell--textLeft MuiDataGrid-withBorderColor']";
//        LogCapture.info("Verifying" + lang);
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.VerifyRandomText(vObjdetail, "randomname"));
        Constants.key.pause("2", "");
    }

    @Then("^User enter  (Notary Name *|Address Line1 *|Address Line2 *|Postcode *|State *|Town *|Company Name|Final amount|final amt currency|paid currency|Email address|Address|Amount paid|Completion date|Address Line1|Address Line2|Town|State|Phone Number|Postcode|Notary Name *|Town/City *|State/County *) \\*$")
    public void userEnterNotaryName(String detail) throws Exception {
        String vObjdetail = "//*[contains(text(),'" + detail + "')]//ancestor::*[@data-testid='form-control']//input";

        LogCapture.info("Verifying" + detail);
        if (detail.equalsIgnoreCase("Address Line2 *") || detail.equalsIgnoreCase("Address Line1 *") || detail.equalsIgnoreCase("Notary Name *") || detail.equalsIgnoreCase("Postcode *") || detail.equalsIgnoreCase("State/County *") || detail.equalsIgnoreCase("Town/City *") || detail.equalsIgnoreCase("Notary Name *") || detail.equalsIgnoreCase("Address Line2")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randomname"));
        } else if (detail.equalsIgnoreCase("Final amount") || detail.equalsIgnoreCase("paid currency") || detail.equalsIgnoreCase("final amt currency") || detail.equalsIgnoreCase("Amount paid") || detail.equalsIgnoreCase("Postcode")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randomnumber"));
        } else if (detail.equalsIgnoreCase("Email address")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randommail"));
        } else if (detail.equalsIgnoreCase("Completion date")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randomfuturedate"));

        } else if (detail.equalsIgnoreCase("Phone Number")) {
            Assert.assertEquals("PASS", Constants.key.RandomData(vObjdetail, "randomnumber"));

        }

    }

    @And("^user search newly added case and click on viwe$")
    public void userSearchNewlyAddedCaseAndClickOnViwe() throws Exception {


        Constants.key.pause("2", "");

//        driver.navigate().refresh();
        LogCapture.info("######  caseID : " + caseID);
        String CASEID = caseID;
        String vObjDash = "//p[normalize-space()='Dashboard']";
//        String vObjnewpage = "//*[contains(text(),'case-9cfe94e5865c494da86c')]//ancestor::*[@role='row']//*[text()='View']";
        Assert.assertEquals("PASS", Constants.key.click(vObjDash, ""));

//        Assert.assertEquals("PASS", Constants.key.click(vObjnewpage, ""));
        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.click(vObjDash, ""));

//       String vObjviwe = "//*[contains(text(),'" + CASEID + "')]//ancestor::*[@role='row']//*[text()='View']";
////         String vObjviwe = "//*[contains(text(),'case-0588efc6b7a84c7b9068')]//ancestor::*[@role='row']//*[text()='View']";

   String vObjviwe = "//*[contains(text(),'" + CASEID + "')]//ancestor::*[@role='row']//*[text()='View']";
//    String vObjviwe = "//*[contains(text(),'case-ab251553067c4bfbb2b0')]//ancestor::*[@role='row']//*[text()='View']";

//case-1562d3d9b8ca439d8430 case-db0e5c2634a54c519815 case-d3cb45562d6d4bb3805d
//       String vObjviwe = "(//p[@type='button-small'][normalize-space()='View'])[1]";
//        LogCapture.info("Verifying" + lang);case-ca2595ca37f3476285a3   case-7a6c68fe3fd440a5bc9d

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjviwe, ""));
        Constants.key.pause("2", "");
//p[normalize-space()='sent']
        String vObjSent = "//p[normalize-space()='sent']";
        String Sent = Constants.key.exist(vObjSent, "");
        if (Sent.equalsIgnoreCase("PASS")) {
            String ObjPage = "//p[text()='Add a new case']";
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(ObjPage, ""));
            String ObjPage2 = "//p[text()='Dashboard']";
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(ObjPage2, ""));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjviwe, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjviwe, ""));
            Constants.key.pause("2", "");
        }

    }

    @Then("^user Retrieve Payments into account for the property purchase\"([^\"]*)\"$")
    public void userRetrievePaymentsIntoAccountForThePropertyPurchase(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //*[contains(text(),'EUR 1111.00')]//ancestor::*[@role="row"]//input[@type="checkbox"]
//*[contains(text(),'EUR 1111.00')]//ancestor::*[@role="row"]//input[@type="checkbox"]
        String vObjviwe = "//*[contains(text(),'EUR 1111.00')]//ancestor::*[@role='row']//input[@type='checkbox']";
//        LogCapture.info("Verifying" + lang);
//        LogCapture.info("######  caseID : " +  caseID);
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjviwe, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User verify debited amount\"([^\"]*)\"$")
    public void userVerifyDebitedAmount(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String vObjviwe = "//*[contains(text(),'1111.00')]//ancestor::*[@role='row']//span";
//        LogCapture.info("Verifying" + lang);
//        LogCapture.info("######  caseID : " +  caseID);
        Constants.key.pause("2", "");

        Assert.assertEquals("PASS", Constants.key.exist(vObjviwe, ""));
        Constants.key.pause("2", "");
    }

    @Then("^User Select one signatory for each party to \"([^\"]*)\"$")
    public void userSelectOneSignatoryForEachPartyTo(String signatory) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        String vObjdetail = "//span[normalize-space()='" + signatory + "']";
        //*[contains(text(), 'buyermulti multi')]
        String vObjdetail = "//*[contains(text(), '"+ signatory +"')]";
                LogCapture.info("Verifying" + signatory);
        Constants.key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
        Constants.key.pause("2", "");
    }

    @Then("^User clicks on Skip button for notary$")
    public void userClicksOnSkipButtonForNotary() throws Exception {
        String vObjdetail = "//p[@type='button-medium' and text()='Skip and continue']";
//        LogCapture.info("Verifying" +  signatory);
        Constants.key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
        Constants.key.pause("3", "");
    }

    @And("^user Request for (disbursement|LookupFund)$")
    public void userRequestForDisbursement(String data) throws Exception {

        if(data.equalsIgnoreCase("LookupFund")){
            //p[@type='button-medium']
//            Constants.key.pause("3", "");
            String vObjdetail2 = "//button[@type='submit']";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjdetail2, ""));
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjdetail2, ""));
        }
else{
            String vObjdetail = "//p[@type='button-medium']";
//        LogCapture.info("Verifying" +  signatory);
            Constants.key.pause("6", "");

            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
            Constants.key.pause("2", "");

        }
//         Constants.key.navigateSubMenu(vObjdetail, "");

    }

    @And("^user click on   multiple checkbox and verify  in next page$")
    public void userClickOnMultipleCheckboxAndVerifyInNextPage() throws Exception {
////input[@name='startDate']
        String vObjdetail = "//input[@name='startDate']";
        Assert.assertEquals("PASS", Constants.key.clearText(vObjdetail));
        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjdetail, "29/04/2023"));
//        Constants.key.pause("3", "");

//        String vObjdetail = "(//*[name()='svg'  and @data-testid='unchecked-checkbox-icon'])[2]";
//        Constants.key.pause("2", "");
        // Scroll to the specific element
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("window.scrollBy(0,500)");
////        LogCapture.info("Verifying" +  signatory);
//        Constants.key.pause("3", "");
//        Assert.assertEquals("PASS", Constants.key.Scrollint(vObjdetail, ""));
        //div[@data-field="amount"]//div[@class="MuiDataGrid-cellContent"   ])[1]
//div[@class="MuiDataGrid-virtualScrollerRenderZone css-1inm7gi"]//div[@role="cell"  and @data-field="entryType"]
        //div[@class="MuiDataGrid-virtualScrollerRenderZone css-1inm7gi"]//div[@role="cell"  and @data-field="reference"]
        //div[@class="MuiDataGrid-virtualScrollerRenderZone css-1inm7gi"]//div[@role="cell"  and @data-field="amount"]
        List<WebElement> checkBoxes = driver.findElements(By.xpath("//input[@type='checkbox']"));

        // Click all checkboxes
        for (WebElement checkBox : checkBoxes) {
            try {
                checkBox.click();
            } catch (Exception e) {
                System.out.println("Unable to click checkbox: " + e.getMessage());
                // You can choose to handle the exception here, such as logging the error or skipping the checkbox
                // For now, we'll just continue to the next checkbox
                continue;
            }
        }


//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjdetail, ""));
//        Constants.key.pause("2", "");
//


//        Constants.key.pause("3", "");
//        // Find all checkboxes with the given xpath
//        List<WebElement> checkBoxList = driver.findElements(By.xpath("//input[@type='checkbox']"));
//
//        // Click on each checkbox
//        for (WebElement checkbox : checkBoxList) {
//            checkbox.click();
//        }

//        // Find elements with ancestor div[@role='row'] and get their text
//        List<WebElement> rows = driver.findElements(By.xpath("//input[@type='checkbox']//ancestor::div[@role='row']"));
//        for (WebElement row : rows) {
//            System.out.println(row.getText());
//        }

        // Close the browser
    }

    @Then("^User fill the form$")
    public void userFillTheForm() {
        List<WebElement> inputFields = driver.findElements(By.xpath("//input[@type='text']"));

        // Fill each input field with the value "100"
        for (WebElement inputField : inputFields) {
            inputField.sendKeys("100");
        }
    }

    @And("^user verify payment confirmation page$")
    public void userVerifyPaymentConfirmationPage() {
    }

    @Then("^user click on skip to skip$")
    public void userClickOnSkipToSkip() throws Exception {
        String vObjdetail = "//*[contains(text(),'kip')]";
//        String vObjdetail = "//a[normalize-space()='skip']";

//        LogCapture.info("Verifying" +  signatory);
        Constants.key.pause("3", "");

        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
        Constants.key.pause("3", "");
    }

//
//    @And("^open mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" verify form \"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\" and fill  details\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\"<BuyerEmailaddress>\"([^\"]*)\"<BuyerFullname>\"([^\"]*)\"<Buyer’slegalFullname>\"$")
//    public void openMailAndVerifyFormAndFillDetailsBuyerEmailaddressBuyerFullnameBuyerSlegalFullname(String mailinator,String Title, String Message, String email, String Buyerseller ,String legalrp, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10) throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
//    }
//
//    @And("^open mail\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" verify form \"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\" and fill  details\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\"<BuyerEmailaddress>\"([^\"]*)\"<BuyerFullname>\"([^\"]*)\"<Buyer’slegalFullname>\"$")
//    public void openMailVerifyFormAndFillDetailsBuyerEmailaddressBuyerFullnameBuyerSlegalFullname(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10) throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
//    }

    @And("^mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" verify details\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\" fill form \"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\"$")
    public void mailAndVerifyDetailsFillForm(String mailinator, String Title, String Message, String email, String Buyerseller, String legalrp, String arg6, String arg7, String arg8) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String url = mailinator;
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        String vObjEmailInbox = "//input[@name='search'  and  @id='search']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
        //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
        String vObjSearchButton = "//button[@value='Search for public inbox for free']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
        LogCapture.info("User enter emailAddress and click on search");
        Constants.key.pause("2", "");
        String vObjFirestMail = "//td[contains(text(),'" + Title + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
        String vObjFrame = "//iframe[@id='html_msg_body']";
        Constants.key.frame(vObjFrame, "");
        String vObjMail = "//*[text()='" + Message + " ']";
        Constants.key.pause("2", "");
        String vObjReviwe = "//span[normalize-space()='" + Message + "']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));
        // Switch to the new window
        String mainWindowHandle = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(mainWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
        Constants.key.pause("2", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        String vObjinitials = "//input[@id='initials']";
        String vObjAdopt = "//button[normalize-space()='Adopt and Sign']";
        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";
        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";
        Constants.key.navigateSubMenu(vObjReviwe, "");
        LogCapture.info("User verify text from received mail");
        Constants.key.pause("2", "");

        String vObjinput1 = "(//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input)[1]";
        String vObjinput2 = "(//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input)[2]";
        String vObjinput3 = "(//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input)[3]";
        String vObjinput4 = "(//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input)[4]";
        String vObjinput5 = "//label[contains(normalize-space(), 'Required - Text 17')]/preceding-sibling::input";
        String vObjinput6 = "//label[contains(normalize-space(), 'Date')]/preceding-sibling::input";

        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjDate, "04/04/2024"));

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjinput1, "farukh"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjinput2, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjinput3, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjinput4, "farukh"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjinput5, "farukh"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjinput6, "04/04/2024"));
        Constants.key.pause("2", "");


        String vObjSigne = Constants.key.notexist(vObjSigniture, "");
        Constants.key.pause("3", "");
        if (vObjSigne.equalsIgnoreCase("PASS")) {
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjsign, ""));
            Constants.key.pause("2", "");
            Constants.key.pause("3", "");
            WebElement popupButton = driver.findElement(By.xpath("//button[normalize-space()='Adopt and Sign']"));
            popupButton.click();

        }

        Constants.key.pause("2", "");

        String vObjfinish = "//button[@id='end-of-document-btn-finish']";
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));

        Constants.key.pause("5", "");
        // Close the main window or continue with further operations



    }

    @And("^mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" verify details\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\" fill form \"([^\"]*)\"\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\" for (Optional|Required - Text 47),(Required - Number - Text 11|Required - Text 17|Required - Text 6|Required - Text 47),(Date|Optional - Text 23|)docu\\.$")
    public void mailAndVerifyDetailsFillFormForOptionalRequiredTextDatedocu(String mailinator, String Title, String Message, String email, String Buyerseller, String legalrp, String arg6, String arg7, String arg8, String arg9, String arg10, String inputxp1, String inputxp2, String inputxp3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Assert.assertEquals("PASS", Constants.key.mailinatoremailclick(Title, Message, email));

        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
        Constants.key.pause("2", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        String vObjinitials = "//input[@id='initials']";
        String vObjAdopt = "//button[normalize-space()='Adopt and Sign']";
        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";
        String vObjDateforall = "//label[contains(normalize-space(), 'Date')]/preceding-sibling::input";
        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";
        String vObjinput = "//label[contains(normalize-space(), '" + inputxp1 + "')]/preceding-sibling::input";
//        Constants.key.navigateSubMenu(vObjReviwe, "");
        LogCapture.info("User verify text from received mail");
        Constants.key.pause("2", "");

        String vObjinput1 = "(//label[contains(normalize-space(), '" + inputxp1 + "')]/preceding-sibling::input)[1]";
        String vObjinput2 = "(//label[contains(normalize-space(), '" + inputxp1 + "')]/preceding-sibling::input)[2]";
        String vObjinput3 = "(//label[contains(normalize-space(), '" + inputxp1 + "')]/preceding-sibling::input)[3]";
        String vObjinput4 = "(//label[contains(normalize-space(), '" + inputxp1 + "')]/preceding-sibling::input)[4]";
        String vObjinput5 = "//label[contains(normalize-space(), '" + inputxp2 + "')]/preceding-sibling::input";
//        String vObjinput5= "//label[contains(normalize-space(), '"+Required - Number - Text 11+"')]/preceding-sibling::input";
//        String vObjinput5= "//label[contains(normalize-space(), 'Required - Text 17')]/preceding-sibling::input";
//        Optional - Text 23

        String vObjinput1a = "(//label[contains(normalize-space(), '" + inputxp3 + "')]/preceding-sibling::input)[1]";
        String vObjinput2a = "(//label[contains(normalize-space(), '" + inputxp3 + "')]/preceding-sibling::input)[2]";
        String vObjinput3a = "(//label[contains(normalize-space(), '" + inputxp3 + "')]/preceding-sibling::input)[3]";
        String vObjinput4a = "(//label[contains(normalize-space(), '" + inputxp3 + "')]/preceding-sibling::input)[4]";

//        String vObjinput2a = "(//label[contains(normalize-space(), 'Optional - Text 23')]/preceding-sibling::input)[2]";
//        String vObjinput3a= "(//label[contains(normalize-space(), 'Optional - Text 23')]/preceding-sibling::input)[3]";
//        String vObjinput4a ="(//label[contains(normalize-space(), 'Optional - Text 23')]/preceding-sibling::input)[4]";
        String vObjinput1b = "//label[contains(normalize-space(), 'Required - Text 6')]/preceding-sibling::input";
        String vObjinput1c = "//label[contains(normalize-space(), 'Required - Text 47')]/preceding-sibling::input";

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjinput, "Random"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput2a, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Sign(vObjsign, vObjSigniture));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Date(vObjDateforall, "present"));

        Constants.key.pause("2", "");

        String vObjfinish = "//button[@id='end-of-document-btn-finish']";
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));

        Constants.key.pause("2", "");
        // Close the main window or continue with further operations

    }

    @And("^open mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"open and close email$")
    public void openMailAndOpenAndCloseEmail(String email, String Title, String Message) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
//
//        Constants.key.pause("2", "");
//
////        String url ="https://www.mailinator.com/";
////        Assert.assertEquals("PASS", Constants.key.navigate("", url));
//        String vObjEmailInbox = "//input[@id='inbox_field']";
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
//        //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
//        String vObjSearchButton = "//button[@class='primary-btn']";
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
//        LogCapture.info("User enter emailAddress and click on search");
//        Constants.key.pause("2", "");
//        String vObjFirestMail = "(//td[contains(text(),'" + Title + "')])[1]";
//        //td[contains(text(),'We’ve')])[1] (//td[contains(text(),'We’ve')])[1]/following-sibling::*[contains(text(), 'hour')]
//        String vObjMailTimeck = " (//td[contains(text(),'" + Title + "')]/)[1]/following-sibling::*[contains(text(), 'hour')]";
////        (//td[contains(text(),'" + Title + "')]/)[1]/following-sibling::*[contains(text(), 'hour')]
//        String vObjMailafterhr =Constants.key.notexist(vObjMailTimeck, "");
//        if(vObjMailafterhr.equalsIgnoreCase("PASS")){
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
//            String vObjFrame = "//iframe[@id='html_msg_body']";
//            Constants.key.frame(vObjFrame, "");
//            String vObjMail = "//*[text()='" + Message + " ']";
//            Constants.key.pause("2", "");
//            String vObjReviwe = "//span[normalize-space()='"+Message+"']";
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));
//            // Switch to the new window
//            String mainWindowHandle = driver.getWindowHandle();
//            for (String windowHandle : driver.getWindowHandles()) {
//                if (!windowHandle.equals(mainWindowHandle)) {
//                    driver.switchTo().window(windowHandle);
//                    break;
//                }
//            }
//
//


        Assert.assertEquals("PASS", Constants.key.mailinatorlink(email, Title));


        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Constants.key.navigateSubMenu(vObjck, "");
        Constants.key.pause("2", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");


        String vObjfinish2 = "//button[@id='end-of-document-btn-finish']";
        Constants.key.Mouse_Events(vObjfinish2, "");
        Constants.key.pause("2", "");

        String vObjfinish = "//button[@id='end-of-document-btn-view-complete']";
        Constants.key.Mouse_Events(vObjfinish, "");
        Constants.key.pause("5", "");
//
//            Constants.key.pause("2", "");
//            driver.switchTo().window(mainWindowHandle);
//            Constants.key.pause("2", "");
//            String vObjchec="//a[normalize-space()='Delete']";
//            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjchec, ""));


    }
    // Close the main window or continue with further operations


    @And("^open mail \"([^\"]*)\"\"([^\"]*)\" and \"([^\"]*)\"verify details\"([^\"]*)\"\"([^\"]*)\" fill form \"([^\"]*)\"\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\" for Optional,Required - Text (\\d+),Date\\.$")
    public void openMailAndVerifyDetailsFillFormForOptionalRequiredTextDate(String email, String Title, String Message, String arg3, String arg4, String mailinator, String arg6, String arg7, String arg8, String arg9, int arg10) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
//        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
        String vObjEmailInbox = "//input[@id='inbox_field']";
        Assert.assertEquals("PASS", Constants.key.mailinatoremailclick(email, Title, Message));
        Constants.key.pause("2", "");

        String vObjinput = "//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input";
        String vObjamount = "//label[contains(normalize-space(), 'Number')]/preceding-sibling::input";
        String vObjIban1 = "//label[contains(normalize-space(), 'Optional - Text 5')]/preceding-sibling::input";
        String vObjIban2 = "//label[contains(normalize-space(), 'Optional - Text 16')]/preceding-sibling::input";
        String vObjIban3 = "//label[contains(normalize-space(), 'Optional - Text 3')]/preceding-sibling::input";
        String vObjClient = "//label[contains(normalize-space(), 'Required - Text 17')]/preceding-sibling::input";

        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";
        String vObjDateforall = "//label[contains(normalize-space(), 'Date')]/preceding-sibling::input";
        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";
        Constants.key.pause("5", "");

        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
        Constants.key.pause("2", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjinput, "Random"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjamount, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjClient, "Test"));

//        Constants.key.pause("2", ""); vObjClient
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput2a, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Date(vObjDateforall, "present"));

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Sign(vObjsign, vObjSigniture));
        Constants.key.pause("2", "");

        String vObjfinish = "//button[@id='end-of-document-btn-finish']";
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));

//        Constants.key.pause("2", "");
//        String url ="https://www.mailinator.com/";
//        Assert.assertEquals("PASS", Constants.key.backtowindowurl(url));
//        Constants.key.pause("2", "");
//        String vObjdel="//a[normalize-space()='Delete']";
//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjdel, ""));
//        Constants.key.pause("2", "");
//        // Close the main window or continue with further operations


    }

    @And("^open for BuyerformDisbursements\"([^\"]*)\"\"([^\"]*)\" and \"([^\"]*)\"verify details\"([^\"]*)\"\"([^\"]*)\" fill form \"([^\"]*)\"\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void openForBuyerformDisbursementsAndVerifyDetailsFillForm(String email, String Title, String Message, String arg3, String arg4, String mailinator, String arg6, String arg7, String arg8, String arg9) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
        Constants.key.pause("2", "");
//        String url = mailinator;
//        Assert.assertEquals("PASS", Constants.key.navigate("", url));
//        Constants.key.pause("2", "");
//        driver.get(url);
//        Constants.key.pause("2", "");
//        String url = "https://www.mailinator.com/";
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        Assert.assertEquals("PASS", Constants.key.mailinatoremailclick(email, Title, Message));
        Constants.key.pause("2", "");
        String vObjPaymentRef = "//label[contains(normalize-space(), 'Required - Text 6')]/preceding-sibling::input";

        String vObjinput = "//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input";
        String vObjamount = "//label[contains(normalize-space(), 'Number')]/preceding-sibling::input";
        String vObjIban1 = "//label[contains(normalize-space(), 'Optional - Text 25')]/preceding-sibling::input";
        String vObjIban2 = "//label[contains(normalize-space(), 'Optional - Text 35')]/preceding-sibling::input";
        String vObjIban3 = "//label[contains(normalize-space(), 'Optional - Text 27')]/preceding-sibling::input";
        String vObjIban4 = "//label[contains(normalize-space(), 'Optional - Text 29')]/preceding-sibling::input";
        String vObjIban5 = "//label[contains(normalize-space(), 'Optional - Text 31')]/preceding-sibling::input";
        String vObjIban6 = "//label[contains(normalize-space(), 'Optional - Text 33')]/preceding-sibling::input";


        String VCdAccount = "//label[contains(normalize-space(), 'Optional - Text 15')]/preceding-sibling::input";
        String vObjLegalEnt = "//label[contains(normalize-space(), 'Optional - Text 17')]/preceding-sibling::input";
//        String vObjIban6 = "//label[contains(normalize-space(), 'Optional - Text 33')]/preceding-sibling::input";

        String vObjClient = "//label[contains(normalize-space(), 'Required - Text 47')]/preceding-sibling::input";

        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";
        String vObjDateforall = "//label[contains(normalize-space(), 'Date')]/preceding-sibling::input";
        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";
        Constants.key.pause("5", "");

        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Constants.key.navigateSubMenu(vObjck, "");
        Constants.key.pause("2", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Constants.key.navigateSubMenu(vObjCont, "");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjPaymentRef, "Test"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjinput, "Random"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjamount, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban4, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban5, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban6, "ES9121000418450200051332"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjClient, "Test"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(VCdAccount, "0201001007739985"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjLegalEnt, "CDLEU"));

//        Constants.key.pause("2", ""); vObjClient
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput2a, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Date(vObjDateforall, "present"));

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Sign(vObjsign, vObjSigniture));
        Constants.key.pause("2", "");

//        String vObjfinish ="//button[@id='end-of-document-btn-view-complete']";


        String vObjfinish = "//button[text()='Finish' and @ id='end-of-document-btn-finish']";
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));
//        String url ="https://www.mailinator.com/";
//        Assert.assertEquals("PASS", Constants.key.backtowindowurl(url));
//        Constants.key.pause("2", "");
//        String vObjdel="//a[normalize-space()='Delete']";
//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjdel, ""));
//        Constants.key.pause("2", "");
//        Constants.key.pause("2", "");
        // Close the main window or continue with further operations

    }

    @And("^open for Certificate of fund\"([^\"]*)\"\"([^\"]*)\" and \"([^\"]*)\"verify details\"([^\"]*)\"\"([^\"]*)\" fill form \"([^\"]*)\"\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void openForCertificateOfFundAndVerifyDetailsFillForm(String email, String Title, String Message, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
//        Constants.key.pause("2", "");
////        String url = "https://www.mailinator.com/";
////        Assert.assertEquals("PASS", Constants.key.navigate("", url));
//        Assert.assertEquals("PASS", Constants.key.mailinatoremailclick(email, Title,Message));


        Assert.assertEquals("PASS", Constants.key.mailinatorlink(email, Title));

        Constants.key.pause("2", "");
        String vObjPaymentRef = "//label[contains(normalize-space(), 'Required - Text 23')]/preceding-sibling::input";

        String vObjinput = "//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input";
        String vObjamount = "//label[contains(normalize-space(), 'Number')]/preceding-sibling::input";
        String vObjIban1 = "//label[contains(normalize-space(), 'Optional - Text 25')]/preceding-sibling::input";
        String vObjIban2 = "//label[contains(normalize-space(), 'Optional - Text 35')]/preceding-sibling::input";
        String vObjIban3 = "//label[contains(normalize-space(), 'Optional - Text 27')]/preceding-sibling::input";
        String vObjIban4 = "//label[contains(normalize-space(), 'Optional - Text 39')]/preceding-sibling::input";
        String vObjIban5 = "//label[contains(normalize-space(), 'Optional - Text 31')]/preceding-sibling::input";
        String vObjIban6 = "//label[contains(normalize-space(), 'Optional - Text 33')]/preceding-sibling::input";

        String vObjClient = "//label[contains(normalize-space(), 'Required - Text 47')]/preceding-sibling::input";

        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";
        String vObjDateforall = "//label[contains(normalize-space(), 'Date')]/preceding-sibling::input";
        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";
        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
        Constants.key.pause("4", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        //        Constants.key.navigateSubMenu(vObjCont, "");
        Constants.key.pause("4", "");
        //label[contains(normalize-space(), 'Text')]//parent::div//span
        String vObjall = "//button[@id='action-bar-btn-continue']";

//        Locator: By.xpath: //label[contains(normalize-space(), 'Text')]//parent::div, Text: Text 5
//        15/04/2024
//        Fruit 2: banana
//        Locator: By.xpath: //label[contains(normalize-space(), 'Text')]//parent::div, Text: Text 1
//        Sathiyanew Sathiyanew
//        Fruit 3: orange
//        Locator: By.xpath: //label[contains(normalize-space(), 'Text')]//parent::div, Text: Text 3
//        0201001007739985
//        Fruit 4: grape
//        Locator: By.xpath: //label[contains(normalize-space(), 'Text')]//parent::div, Text: Text 2
//        EUR
//        Assert.assertEquals("PASS", Constants.key.VerifyMultipleText(vObjall, ""));
        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjinput, "Random"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjamount, "100"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjClient, "Test"));

//        Constants.key.pause("2", ""); vObjClient
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput2a, "100"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.Date(vObjDateforall, "present"));
//
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.Sign(vObjsign, vObjSigniture));
//        Constants.key.pause("2", "");


        List<WebElement> elements = driver.findElements(By.xpath("//label[contains(normalize-space(), 'Text')]//parent::div"));

        // Loop through each element
        for (int i = 0; i < elements.size(); i++) {
            WebElement element = elements.get(i);
            String text = element.getText();
//            String xpath = getXPath(driver, element);

            // Print the text and XPath of each element
            System.out.println("String vObjinput =(//label[contains(normalize-space(),'Text')]//parent::div)[" + i + "]" + text);
//
        }

        String vObjclose = "//button[@id='end-of-document-btn-view-complete']";

        String vObjfinish = "//button[@id='end-of-document-btn-finish'  and text()='Finish']";
        String finish = Constants.key.Mouse_Events(vObjfinish, "");
        if (!finish.equalsIgnoreCase("PASS")) {
            Constants.key.Mouse_Events(vObjclose, "");
        }

        Constants.key.pause("12", "");
        // Close the main window or continue with further operations
        // Get all window handles

    }

    @And("^open for mail Readyforsale of fund\"([^\"]*)\"\"([^\"]*)\" and \"([^\"]*)\"verify details\"([^\"]*)\"\"([^\"]*)\" fill form \"([^\"]*)\"\"([^\"]*)\" \"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void openForMailReadyforsaleOfFundAndVerifyDetailsFillForm(String email, String Title, String Message, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

//        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
       Constants.key.pause("5", "");
////        String url = "https://www.mailinator.com/";
////        Assert.assertEquals("PASS", Constants.key.navigate("", url));
//        Assert.assertEquals("PASS", Constants.key.mailinatoremailclick(email, Title,Message));

        Assert.assertEquals("PASS", Constants.key.mailinatorlink(email, Title));

        Constants.key.pause("2", "");
        String vObjPaymentRef = "//label[contains(normalize-space(), 'Required - Text 23')]/preceding-sibling::input";

        String vObjinput = "//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input";
        String vObjamount = "//label[contains(normalize-space(), 'Number')]/preceding-sibling::input";
        String vObjIban1 = "//label[contains(normalize-space(), 'Optional - Text 25')]/preceding-sibling::input";
        String vObjIban2 = "//label[contains(normalize-space(), 'Optional - Text 35')]/preceding-sibling::input";
        String vObjIban3 = "//label[contains(normalize-space(), 'Optional - Text 27')]/preceding-sibling::input";
        String vObjIban4 = "//label[contains(normalize-space(), 'Optional - Text 39')]/preceding-sibling::input";
        String vObjIban5 = "//label[contains(normalize-space(), 'Optional - Text 31')]/preceding-sibling::input";
        String vObjIban6 = "//label[contains(normalize-space(), 'Optional - Text 33')]/preceding-sibling::input";

        String vObjClient = "//label[contains(normalize-space(), 'Required - Text 47')]/preceding-sibling::input";

        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";
        String vObjDateforall = "//label[contains(normalize-space(), 'Date')]/preceding-sibling::input";
        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";
        Constants.key.pause("2", "");

        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Constants.key.navigateSubMenu(vObjck, "");
        Constants.key.pause("4", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Constants.key.navigateSubMenu(vObjCont, "");
        Constants.key.pause("2", "");
        //        Constants.key.navigateSubMenu(vObjCont, "");
        Constants.key.pause("4", "");
//        Assert.assertEquals("PASS", Constants.key.VerifyMultipleText(vObjPaymentRef, "Test"));

//        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjinput, "Random"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.MultipleInput(vObjamount, "100"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjClient, "Test"));

//        Constants.key.pause("2", ""); vObjClient
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput3a, "ES9121000418450200051332"));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjinput2a, "100"));

//
//        List<WebElement> elements = driver.findElements(By.xpath("//*"));
//
//
////        String vObjIban6 = "//label[contains(normalize-space(), 'Optional - Text 33')]/preceding-sibling::input";
//        // Loop through each element to get its text and locator
//        for (WebElement element : elements) {
//            String text = element.getText();
//            String locator = element.toString();
//            System.out.println("String " + text+"='"+locator+"'");
////            System.out.println("Locator: " + locator);
//            System.out.println("------------------------");
//        }
//
//


        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Date(vObjDateforall, "present"));

        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Sign(vObjsign, vObjSigniture));
        Constants.key.pause("2", "");

        String vObjfinish = "//button[@id='end-of-document-btn-finish'  and text()='Finish']";

        String vObjclose ="//button[@id='end-of-document-btn-view-complete']";
        Constants.key.pause("2", "");
        Constants.key.Mouse_Events(vObjclose, "");

        Constants.key.pause("2", "");
        Constants.key.Mouse_Events(vObjfinish, "");
        Constants.key.pause("6", "");
        // Close the main window or continue with further operations

    }

    @And("^user click on continue button$")
    public void userClickOnContinueButton() throws Exception {
        Constants.key.pause("2", "");
        String vObjCont = "//p[normalize-space()='Continue']";
        String vObbutton = "//p[@type='button-medium']";
        String Cont = Constants.key.navigateSubMenu(vObjCont, "");
        if (!Cont.equalsIgnoreCase("PASS")) {
            Constants.key.navigateSubMenu(vObbutton, "");
        }
    }

    @And("^open paymentconfirmation mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"open and close email$")
    public void openPaymentconfirmationMailAndOpenAndCloseEmail(String email, String Title, String Message) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
//        String url ="https://www.mailinator.com/";
//        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        String vObjEmailInbox = "//input[@id='inbox_field']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
        //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");


        String vObjSearchButton = "//button[@class='primary-btn']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
        LogCapture.info("User enter emailAddress and click on search");
//        Constants.key.pause("50", "");
        Constants.key.pause("3", "");
        String vObjFirestMail = "//td[contains(text(),'" + Title + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
        String vObjFrame = "//iframe[@id='html_msg_body']";
        Constants.key.frame(vObjFrame, "");
        String vObjMail = "//*[text()='" + Message + " ']";
        Constants.key.pause("2", "");
        String vObjReviwe = "//span[normalize-space()='" + Message + "']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));
        // Switch to the new window
        String mainWindowHandle = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(mainWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

        String currency = "//*[normalize-space(text()) = 'Text 1']/parent::div";  //  EUR
        String amount = "//*[normalize-space(text()) = 'Text 2']/parent::div";
        String Date = "//*[normalize-space(text()) = 'Text 3']/parent::div";
//*[normalize-space(text()) = 'Text 2']/parent::div    100.0
//*[normalize-space(text()) = 'Text 3']/parent::div    15/04/2024
//        Assert.assertEquals("PASS", Constants.key.writeInInput(currency, "EUR"));
//        Assert.assertEquals("PASS", Constants.key.writeInInput(amount, "100.0"));
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));


        Constants.key.pause("3", "");
//        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Constants.key.navigateSubMenu(vObjck, "");
        Constants.key.pause("2", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Constants.key.navigateSubMenu(vObjCont, "");
        Constants.key.pause("3", "");

//        Constants.key.pause("2", "");

        String vObjfinish = "//button[@id='end-of-document-btn-finish']";
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));

        Constants.key.pause("2", "");
        // Close the main window or continue with further operations

    }

    @And("^open paymentconfirmation mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" and verify detaild\"([^\"]*)\"$")
    public void openPaymentconfirmationMailAndAndVerifyDetaild(String email, String Title, String Message, String arg3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
//        String url ="https://www.mailinator.com/v4/private/inboxes.jsp?msgid=solicon1-1713295184-34484265902#";
//        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        String vObjEmailInbox = "//input[@id='inbox_field']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
        //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
        String vObjSearchButton = "//button[@class='primary-btn']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
        LogCapture.info("User enter emailAddress and click on search");
        Constants.key.pause("3", "");
        String vObjFirestMail = "//td[contains(text(),'" + Title + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
        String vObjFrame = "//iframe[@id='html_msg_body']";
        Constants.key.frame(vObjFrame, "");
        String vObjMail = "//*[text()='" + Message + " ']";
        Constants.key.pause("2", "");
        String vObjReviwe = "//span[normalize-space()='" + Message + "']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));
        // Switch to the new window
        String mainWindowHandle = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(mainWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

        String currency = "//*[normalize-space(text()) = 'Text 1']/parent::div";  //  EUR
        String amount = "//*[normalize-space(text()) = 'Text 2']/parent::div";
        String Date = "//*[normalize-space(text()) = 'Text 3']/parent::div";
//*[normalize-space(text()) = 'Text 2']/parent::div    100.0
//*[normalize-space(text()) = 'Text 3']/parent::div    15/04/2024
        //button[text()='Continue']
//        Assert.assertEquals("PASS", Constants.key.writeInInput(currency, "EUR"));
//        Assert.assertEquals("PASS", Constants.key.writeInInput(amount, "100.0"));
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));


        Constants.key.pause("2", "");
//        Constants.key.pause("2", "");
//        String vObjck = "//label[@for='disclosureAccepted']";
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
//        Constants.key.pause("2", "");
        String vObjCont = "//button[text()='Continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("3", "");

//        Constants.key.pause("2", "");

        String vObjfinish = "//button[text()='Finish' and @id='end-of-document-btn-finish']";
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));

        Constants.key.pause("3", "");
        // Close the main window or continue with further operations


    }

    @And("^open mail \"([^\"]*)\"\"([^\"]*)\" and \"([^\"]*)\"verify details\"([^\"]*)\"\"([^\"]*)\" fill form \"([^\"]*)\"\"([^\"]*)\" and checking for (\\d+) (benificary|benificary for 2seller|benificary for 2User)$")
    public void openMailAndVerifyDetailsFillFormAndCheckingForBenificary(String email, String Title, String Message, String arg3, String arg4, String SellerFullname, String iban, int benificary,String mailnumber) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Constants.key.pause("5", "");
        NoofSellerBeni = benificary;

//        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
////        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
//        String vObjEmailInbox = "//input[@id='inbox_field']";
//        Assert.assertEquals("PASS", Constants.key.mailinatoremailclick(email, Title,Message));


        Assert.assertEquals("PASS", Constants.key.mailinatorlink(email, Title));
        Constants.key.pause("2", "");

        String vObjBen1 = "//label[contains(normalize-space(), 'Optional - Text 2')]/preceding-sibling::input";
        String vObjBen2 = "//label[contains(normalize-space(), 'Optional - Text 6')]/preceding-sibling::input";
        String vObjBen3 = "//label[contains(normalize-space(), 'Optional - Text 7')]/preceding-sibling::input";
        String vObjinput = "//label[contains(normalize-space(), 'Optional - Text 2')]/preceding-sibling::input";


        String vObjamount = "(//label[contains(normalize-space(), 'Number')]/preceding-sibling::input)[1]";
        String vObjamount1 = "(//label[contains(normalize-space(), 'Number')]/preceding-sibling::input)[1]";
        String vObjamount2 = "(//label[contains(normalize-space(), 'Number')]/preceding-sibling::input)[2]";
        String vObjamount3 = "(//label[contains(normalize-space(), 'Number')]/preceding-sibling::input)[3]";

        String vObjIban1 = "//label[contains(normalize-space(), 'Optional - Text 5')]/preceding-sibling::input";
        String vObjIban2 = "//label[contains(normalize-space(), 'Optional - Text 16')]/preceding-sibling::input";
        String vObjIban3 = "//label[contains(normalize-space(), 'Optional - Text 3')]/preceding-sibling::input";

        String vObjRef1 = "//label[contains(normalize-space(), 'Optional - Text 10')]/preceding-sibling::input";
        String vObjRef2 = "//label[contains(normalize-space(), 'Optional - Text 13')]/preceding-sibling::input";
        String vObjRef3 = "//label[contains(normalize-space(), 'Optional - Text 14')]/preceding-sibling::input";

        String vObjClient = "//label[contains(normalize-space(), 'Required - Text 17')]/preceding-sibling::input";
//Optional - Text 10
        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";
        String vObjDateforall = "//label[contains(normalize-space(), 'Date')]/preceding-sibling::input";
        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";
        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
        Constants.key.pause("4", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        //        Constants.key.navigateSubMenu(vObjCont, "");
        Constants.key.pause("4", "");
        SellerBen1 = "SaurabhSeller1" + generateRandomName();
        SellerBen2 = "SaurabhSeller2" + generateRandomName();
        SellerBen3 = "SaurabhSeller3" + generateRandomName();
        SellerBen4 = "SaurabhSeller4" + generateRandomName();
        SellerBen5 = "SaurabhSeller5" + generateRandomName();
        SellerBen6 = "SaurabhSeller6" + generateRandomName();
        LogCapture.info(SellerBen1 + SellerBen2 + SellerBen3 + SellerBen4 + SellerBen5 + SellerBen6);

        if(mailnumber.equalsIgnoreCase("benificary")){
            if (benificary == 1) {
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, SellerBen1));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, SellerBen1));

        } else if (benificary == 2) {
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, SellerBen1));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, SellerBen1));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen2, SellerBen2));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount2, "101"));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "GB33BUKB20201555555555"));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef2, SellerBen2));


        } else if (benificary == 3) {
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, SellerBen1));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, SellerBen1));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen2, SellerBen2));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount2, "101"));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "GB33BUKB20201555555555"));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef2, SellerBen2));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen3, SellerBen3));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount3, "102"));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "DE75512108001245126199"));
            Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef3, SellerBen3));

        }

            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.Date(vObjDateforall, "present"));

        }
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjClient, email));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Sign(vObjsign, vObjSigniture));
        Constants.key.pause("2", "");


        String vObjfinish = "//button[@id='end-of-document-btn-finish']";
        Constants.key.scrollIntoViewElement(vObjfinish, "");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));
        Constants.key.pause("2", "");
        Constants.key.navigateSubMenu(vObjfinish, "");


        Constants.key.pause("10", "");


//        String vObjchec="//input[@id='bigcheckprivate']";
//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjchec, ""));
//        String vObjdel ="//button[@aria-label='Delete Button']";
//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjdel, ""));

        // Close the main window or continue with further operations


    }

    @And("^open mail BuyerformDisbursements \"([^\"]*)\"\"([^\"]*)\" and \"([^\"]*)\"verify details\"([^\"]*)\"\"([^\"]*)\" fill form \"([^\"]*)\"\"([^\"]*)\" and checking for (\\d+) (benificary|for 2mail)$")
    public void openMailBuyerformDisbursementsAndVerifyDetailsFillFormAndCheckingForBenificary(String email, String Title, String Message, String arg3, String arg4, String SellerFullname, String iban, int benificary,String mailck) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        NoofBuyerBeni = benificary;
//        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
//        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.mailinatoremailclick(email, Title,Message));

        Assert.assertEquals("PASS", Constants.key.mailinatorlink(email, Title));

        Constants.key.pause("2", "");
        String vObjPaymentRef = "//label[contains(normalize-space(), 'Required - Text 6')]/preceding-sibling::input";
        String vObjAmounttobe = "//label[contains(normalize-space(), 'Required - Number - Text 11')]/preceding-sibling::input";

        String vObjinput = "//label[contains(normalize-space(), 'Optional')]/preceding-sibling::input";
        String vObjamount = "//label[contains(normalize-space(), 'Number')]/preceding-sibling::input";
        String vObjClient = "//label[contains(normalize-space(), 'Required - Text 43')]/preceding-sibling::input";

        String vObjsign = "//div[@class='signature-tab-content tab-button-yellow v2']";
        String vCkObjsign = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";

        String vObjDate = "//input[@aria-invalid='false']";
        String vObjDateforall = "//label[contains(normalize-space(), 'Date')]/preceding-sibling::input";
        String vObjSigniture = "//div[@class='doc-tab signature-tab owned signing-required signed']/button";


        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
        Constants.key.pause("4", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("2", "");
        //        Constants.key.navigateSubMenu(vObjCont, "");
        Constants.key.pause("4", "");
        //div[@class='overlay']
        String vObjoutside = "//div[@class='overlay']";
        Constants.key.navigateSubMenu(vObjoutside, "");
        String AmountPaidToDate = Integer.toString(ThreadLocalRandom.current().nextInt(500, 999));
        finaldisAmount = Integer.parseInt(AmountPaidToDate);
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjLegalEnt, "CDLEU"));

        BuyerBen1 = "SaurabhBuyer  1" + generateRandomName();
        BuyerBen2 = "SaurabhBuyer  2" + generateRandomName();
        BuyerBen3 = "SaurabhBuyer  3" + generateRandomName();
        BuyerBen4 = "SaurabhBuyer  4" + generateRandomName();
        BuyerBen5 = "SaurabhBuyer  5" + generateRandomName();
        BuyerBen6 = "SaurabhBuyer  6" + generateRandomName();
        String vObjIban1 = "//label[contains(normalize-space(), 'Optional - Text 25')]/preceding-sibling::input";
        String vObjIban2 = "//label[contains(normalize-space(), 'Optional - Text 35')]/preceding-sibling::input";
        String vObjIban3 = "//label[contains(normalize-space(), 'Optional - Text 27')]/preceding-sibling::input";
        String vObjIban4 = "//label[contains(normalize-space(), 'Optional - Text 29')]/preceding-sibling::input";
        String vObjIban5 = "//label[contains(normalize-space(), 'Optional - Text 31')]/preceding-sibling::input";
        String vObjIban6 = "//label[contains(normalize-space(), 'Optional - Text 33')]/preceding-sibling::input";

        String vObjamount1 = "//label[contains(normalize-space(), 'Optional - Number - Text 24')]/preceding-sibling::input";
        String vObjamount2 = "//label[contains(normalize-space(), 'Optional - Number - Text 46')]/preceding-sibling::input";
        String vObjamount3 = "//label[contains(normalize-space(), 'Optional - Number - Text 38')]/preceding-sibling::input";
        String vObjamount4 = "//label[contains(normalize-space(), 'Optional - Number - Text 40')]/preceding-sibling::input";
        String vObjamount5 = "//label[contains(normalize-space(), 'Optional - Number - Text 42')]/preceding-sibling::input";
        String vObjamount6 = "//label[contains(normalize-space(), 'Optional - Number - Text 44')]/preceding-sibling::input";

        String vObjBen1 = "//label[contains(normalize-space(), 'Optional - Text 23')]/preceding-sibling::input";
        String vObjBen2 = "//label[contains(normalize-space(), 'Optional - Text 35')]/preceding-sibling::input";
        String vObjBen3 = "//label[contains(normalize-space(), 'Optional - Text 37')]/preceding-sibling::input";
        String vObjBen4 = "//label[contains(normalize-space(), 'Optional - Text 39')]/preceding-sibling::input";
        String vObjBen5 = "//label[contains(normalize-space(), 'Optional - Text 41')]/preceding-sibling::input";
        String vObjBen6 = "//label[contains(normalize-space(), 'Optional - Text 43')]/preceding-sibling::input";
        String vObjRef1 = "//label[contains(normalize-space(), 'Optional - Text 26')]/preceding-sibling::input";
        String vObjRef2 = "//label[contains(normalize-space(), 'Optional - Text 36')]/preceding-sibling::input";
        String vObjRef3 = "//label[contains(normalize-space(), 'Optional - Text 28')]/preceding-sibling::input";
        String vObjRef4 = "//label[contains(normalize-space(), 'Optional - Text 30')]/preceding-sibling::input";
        String vObjRef5 = "//label[contains(normalize-space(), 'Optional - Text 32')]/preceding-sibling::input";
        String vObjRef6 = "//label[contains(normalize-space(), 'Optional - Text 34')]/preceding-sibling::input";
        String VCdAccount = "//label[contains(normalize-space(), 'Optional - Text 15')]/preceding-sibling::input";
        String vObjLegalEnt = "//label[contains(normalize-space(), 'Optional - Text 17')]/preceding-sibling::input";
//        String vObjIban6 = "//label[contains(normalize-space(), 'Optional - Text 33')]/preceding-sibling::input";

if(mailck.equalsIgnoreCase("benificary")){

    Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjPaymentRef, "Test"));
    Constants.key.pause("2", "");
    Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjAmounttobe, AmountPaidToDate));
    Constants.key.pause("2", "");

    if (benificary == 1) {
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, BuyerBen1));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, BuyerBen1));

    } else if (benificary == 2) {
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, BuyerBen1));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, BuyerBen1));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen2, BuyerBen2));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount2, "101"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "GB33BUKB20201555555555"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef2, BuyerBen2));


    } else if (benificary == 3) {
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, BuyerBen1));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, BuyerBen1));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen2, BuyerBen2));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount2, "101"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "GB33BUKB20201555555555"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef2, BuyerBen2));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen3, BuyerBen3));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount3, "102"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "DE75512108001245126199"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef3, BuyerBen3));

    } else if (benificary == 4) {
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, BuyerBen1));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, BuyerBen1));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen2, BuyerBen2));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount2, "101"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "GB33BUKB20201555555555"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef2, BuyerBen2));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen3, BuyerBen3));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount3, "102"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "DE75512108001245126199"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef3, BuyerBen3));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen4, BuyerBen4));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount4, "400"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban4, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef4, BuyerBen4));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen5, BuyerBen5));

    } else if (benificary == 5) {
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, BuyerBen1));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, BuyerBen1));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen2, BuyerBen2));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount2, "101"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "GB33BUKB20201555555555"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef2, BuyerBen2));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen3, BuyerBen3));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount3, "102"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "DE75512108001245126199"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef3, BuyerBen3));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen4, BuyerBen4));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount4, "400"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban4, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef4, BuyerBen4));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen5, BuyerBen5));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount5, "404"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban5, "GB33BUKB20201555555555"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef5, BuyerBen5));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen6, BuyerBen6));

    } else if (benificary == 6) {
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen1, BuyerBen1));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount1, "100"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban1, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef1, BuyerBen1));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen2, BuyerBen2));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount2, "101"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban2, "GB33BUKB20201555555555"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef2, BuyerBen2));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen3, BuyerBen3));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount3, "102"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban3, "DE75512108001245126199"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef3, BuyerBen3));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen4, BuyerBen4));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount4, "400"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban4, iban));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef4, BuyerBen4));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen5, BuyerBen5));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount5, "404"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban5, "GB33BUKB20201555555555"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef5, BuyerBen5));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjBen6, BuyerBen6));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjamount6, "405"));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjIban6, "DE75512108001245126199"));
        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjRef6, BuyerBen6));

    }
    Constants.key.pause("2", "");
    String Client = Constants.key.SpecificInput(vObjClient, "Test");
    Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(vObjLegalEnt, "CDLEU"));

    Constants.key.pause("2", "");
    Assert.assertEquals("PASS", Constants.key.Date(vObjDateforall, "present"));

}


        String vObjClient2 = "//label[contains(normalize-space(), 'Required - Text 47')]/preceding-sibling::input";
        String Client2 = Constants.key.SpecificInput(vObjClient2, "Test");


        Constants.key.pause("2", "");
//        Assert.assertEquals("PASS", Constants.key.SpecificInput(VCdAccount, "0201001007739985"));


        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.Sign(vObjsign, vObjSigniture));
        Constants.key.pause("2", "");
        String vObjfinish = "//button[text()='Finish' and @ id='end-of-document-btn-finish']";
        String vObjclose = "//button[@id='end-of-document-btn-view-complete']";


        Constants.key.scrollIntoViewElement(vObjfinish, "");
        Constants.key.pause("5", "");
        Constants.key.Mouse_Events(vObjfinish, "");
        Constants.key.pause("2", "");
        Constants.key.Mouse_Events(vObjclose, "");
        Constants.key.pause("7", "");
        // Close the main window or continue with further operations


    }


    @Given("^User launched application through \"([^\"]*)\"$")
    public void userLaunchedApplicationThrough(String data) throws Throwable {
        LogCapture.info(data + " Application is launching....");
        Constants.vBrowserName = Constants.CONFIG.getProperty("browser");
        try {
            if (Objects.equals(Constants.JenkinsBrowser, null)) {
                Constants.JenkinsBrowser = "";
            } else if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
                vBrowserName = Constants.JenkinsBrowser;
                LogCapture.info("Browser is :" + Constants.JenkinsBrowser);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));
    }


    @Given("^User navigate to Titan Application \"(.*?)\"$")
    public void user_navigate_to_Titan_Application(String vUrl) throws Throwable {
        LogCapture.info("Titan Applicatiion is loading....");
        String url = Constants.CONFIG.getProperty(vUrl);
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        Constants.key.pause("4", "");
        String vObjSignPage = "//h1[normalize-space(text()) = 'Sign in to your account']";
        String vObjSign = Constants.key.exist(vObjSignPage, "");

    }

    @When("^User enter UserName \"(.*?)\" password \"(.*?)\" and click log In button$")
    public void user_enter_UserName_password_and_click_log_In_button(String userName, String password) throws Throwable {
        String vUserName = Constants.CONFIG.getProperty(userName);
        String vPassword = Constants.CONFIG.getProperty(password);
        String vObjUser = Constants.TitanLoginOR.getProperty("Titan_Username");
        String vObjPass = Constants.TitanLoginOR.getProperty("Titan_Password");
        LogCapture.info("User Name " + vUserName + ", Password is validated ....");
        Constants.key.VisibleConditionWait(vObjUser, "");
        Assert.assertEquals("PASS", Constants.key.click(vObjUser, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPass, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
        String vObjLoginButton = Constants.TitanLoginOR.getProperty("LogInButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @When("^User enter UserName \"(.*?)\" Incorrect password \"(.*?)\" and click log In button$")
    public void user_enter_UserName_Incorrect_password_and_click_log_In_button(String usernName, String inPassword) throws Throwable {
        LogCapture.info("Validating incorrect credentials.......");
        String vUserName = Constants.CONFIG.getProperty(usernName);
        String vObjUser = Constants.TitanLoginOR.getProperty("Titan_Username");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
        String vObjPass = Constants.TitanLoginOR.getProperty("Titan_Password");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, inPassword));
        String vObjLoginButton = Constants.TitanLoginOR.getProperty("LogInButton");
        Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));
    }

    @Then("^User successfully landed on Titan Dashboard page$")
    public void user_successfully_landed_on_Titan_Dashboard_page() throws Throwable {
        LogCapture.info("Dashboard loading ......");
        Constants.key.pause("3", "");
        Constants.key.pause("2", "");
        String vobjectDashboard = Constants.TitanLoginOR.getProperty("DashboardPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjectDashboard, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjectDashboard, "Dashboard"));
        LogCapture.info("Dasehboard loaded successfully");
    }


    @And("^user verify downloaded files is \"([^\"]*)\"$")
    public void userVerifyDownloadedFilesIs(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        Assert.assertEquals("PASS", Constants.key.pdf(arg0, ""));
    }

    @And("^user   duplicate mail and delete all email for\"([^\"]*)\"$")
    public void userDuplicateMailAndDeleteAllEmailFor(String email) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //    Assert.assertEquals("PASS", Constants.key.freemailinator(email));
        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
        Constants.key.pause("2", "");

//        String url ="https://www.mailinator.com/";
//        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        String vObjEmailInbox = "//input[@id='inbox_field']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
        //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
        String vObjSearchButton = "//button[@class='primary-btn']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
        LogCapture.info("User enter emailAddress and click on search");

        String vObjEmailall = "//input[@id='bigcheckprivate']";
        String vObjEmaildele = "//button[@aria-label='Delete Button']";
        Constants.key.Mouse_Events(vObjEmailall, "");
        Constants.key.pause("2", "");
        WebElement checkBox = driver.findElement(By.xpath("//input[@id='bigcheckprivate']"));

        // Check if the checkbox is not checked
        if (!checkBox.isSelected()) {
            // If it's not checked, then check it
            checkBox.click();
            System.out.println("Checkbox checked.");
        } else {
            System.out.println("Checkbox already checked.");
        }

        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjEmaildele, ""));
        Constants.key.pause("5", "");
        // Close the main window or continue with further operations


    }

    @And("^open mail\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"open and ck all payment confirmation copy$")
    public void openMailAndOpenAndCkAllPaymentConfirmationCopy(String email, String Title, String Message) throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        Assert.assertEquals("PASS", Constants.key.freemailinator(email));
        Constants.key.pause("2", "");

//        String url ="https://www.mailinator.com/";
//        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        String vObjEmailInbox = "//input[@id='inbox_field']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
        //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
        String vObjSearchButton = "//button[@class='primary-btn']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
        LogCapture.info("User enter emailAddress and click on search");
        Constants.key.pause("2", "");
        String vObjFirestMail = "(//td[contains(text(),'" + Title + "')])[1]";
        //td[contains(text(),'We’ve')])[1] (//td[contains(text(),'We’ve')])[1]/following-sibling::*[contains(text(), 'hour')]
        String vObjMailTimeck = " (//td[contains(text(),'" + Title + "')]/)[1]/following-sibling::*[contains(text(), 'hour')]";
//        (//td[contains(text(),'" + Title + "')]/)[1]/following-sibling::*[contains(text(), 'hour')]
        String vObjMailafterhr = Constants.key.notexist(vObjMailTimeck, "");
        if (vObjMailafterhr.equalsIgnoreCase("PASS")) {
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
            String vObjFrame = "//iframe[@id='html_msg_body']";
            Constants.key.frame(vObjFrame, "");
            String vObjMail = "//*[text()='" + Message + " ']";
            Constants.key.pause("2", "");
            String vObjReviwe = "//span[normalize-space()='" + Message + "']";
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));
            // Switch to the new window
            String mainWindowHandle = driver.getWindowHandle();
            for (String windowHandle : driver.getWindowHandles()) {
                if (!windowHandle.equals(mainWindowHandle)) {
                    driver.switchTo().window(windowHandle);
                    break;
                }
            }


            Constants.key.pause("2", "");
            String vObjck = "//label[@for='disclosureAccepted']";
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
            Constants.key.pause("2", "");
            String vObjCont = "//button[@id='action-bar-btn-continue']";
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
            Constants.key.pause("2", "");

            Constants.key.pause("2", "");

            String vObjfinish = "//button[@id='end-of-document-btn-view-complete']";
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));
        }
        // Close the main window or continue with further operations

    }

    @And("^User validates the files \"([^\"]*)\" is (downloaded|deleted) successfully$")
    public void userValidatesTheFileIsDownloadedSuccessfully(String fileName, String operationType) throws Throwable {
//        LogCapture.info("Validating if the file is " + operationType +" successfully.....");
        Constants.key.pause("20", "");
//use[@xmlns:xlink='http://www.w3.org/1999/xlink' and contains(@xlink:href, '#svg-icon-material-download')]


        if (operationType.equalsIgnoreCase("downloaded")) {
            String vObjDownloadLink = "//button[@id='toolbar-download-menu-button']//span[@class='SVGInline']//*[name()='svg']";
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDownloadLink, ""));
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjDownloadLink, ""));
            Constants.key.pause("10", "");

            LogCapture.info("Validating if the file is " + operationType + " successfully.....");
            Assert.assertEquals("PASS", Constants.key.defaultDownloadFilesOperations("isFileAvailable", fileName));
            Constants.key.pause("10", "");
//            Assert.assertEquals("PASS", Constants.key.defaultDownloadFilesOperations2("isFileAvailable", fileName));

        } else if (operationType.equalsIgnoreCase("deleted")) {
            LogCapture.info("Validating if the file is " + operationType + " successfully.....");
            LogCapture.info("Process start");
            Assert.assertEquals("PASS", Constants.key.defaultDownloadFilesOperations("deleteSelectedFile", fileName));

        }

        Constants.key.pause("2", "");
//        LogCapture.info("File is " + operationType + " successfully.....");
    }

    @And("^open mail from \"([^\"]*)\" and\"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"open and ck all payment confirmation copy$")
    public void openMailFromAndAndOpenAndCkAllPaymentConfirmationCopy(String data, String email, String Title, String Message) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Constants.key.pause("20", "");
        int totalpaymentconfmailck;

        if (email.equalsIgnoreCase("sellersoli@redpinteam.testinator.com") || email.equalsIgnoreCase("mariocasas0204@redpinteam.testinator.com")) {
            totalpaymentconfmailck = NoofSellerBeni;
        } else {

            totalpaymentconfmailck = NoofBuyerBeni;
            //Property Completion Service - We’ve sent your fundstotalpaymentconfmailck + 1
        }
        Constants.key.pause("10","");
        //multilinkpaymentconfirmation
        Assert.assertEquals("PASS", Constants.key.multilinkpaymentconfirmation(email, Title,totalpaymentconfmailck));
//        for (int i = 0; i <3 ; i++) {
//
//
////            LogCapture.info(data + " Application is launching....");
////            Constants.vBrowserName = Constants.CONFIG.getProperty("browser");
////            try {
////                if (Objects.equals(Constants.JenkinsBrowser, null)) {
////                    Constants.JenkinsBrowser = "";
////                } else if (!Constants.JenkinsBrowser.isEmpty() || !Constants.JenkinsBrowser.equals("")) {
////                    vBrowserName = Constants.JenkinsBrowser;
////                    LogCapture.info("Browser is :" + Constants.JenkinsBrowser);
////                }
////            } catch (Exception e) {
////                e.printStackTrace();
////            }
////
////            Assert.assertTrue(Constants.key.openBrowser("", vBrowserName));
////            Assert.assertEquals("PASS", Constants.key.freemailinator(email));
////            Constants.key.pause("2", "");
////
////        String url ="https://www.mailinator.com/";
////        Assert.assertEquals("PASS", Constants.key.navigate("", url));
////            String vObjEmailInbox = "//input[@id='inbox_field']";
////            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
////            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, email));
////            //  String vObjSearchButton=Constants.CalypsoRecipientOR.getProperty("SearchButton");
////            String vObjSearchButton = "//button[@class='primary-btn']";
////            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
////            LogCapture.info("User enter emailAddress and click on search");
////            Constants.key.pause("2", "");
////            String vObjFirestMail = "(//td[contains(text(),'" + Title + "')])[1]";
////            //td[contains(text(),'We’ve')])[1] (//td[contains(text(),'We’ve')])[1]/following-sibling::*[contains(text(), 'hour')]
////            String vObjMailTimeck = " (//td[contains(text(),'" + Title + "')]/)[1]/following-sibling::*[contains(text(), 'hour')]";
//////        (//td[contains(text(),'" + Title + "')]/)[1]/following-sibling::*[contains(text(), 'hour')]
////            String vObjMailafterhr = Constants.key.notexist(vObjMailTimeck, "");
////            if (vObjMailafterhr.equalsIgnoreCase("PASS")) {
////                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
////                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
////                String vObjFrame = "//iframe[@id='html_msg_body']";
////                Constants.key.frame(vObjFrame, "");
////                String vObjMail = "//*[text()='" + Message + " ']";
////                Constants.key.pause("2", "");
////                String vObjReviwe = "//span[normalize-space()='" + Message + "']";
////                Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));
////                // Switch to the new window
////                String mainWindowHandle = driver.getWindowHandle();
////                for (String windowHandle : driver.getWindowHandles()) {
////                    if (!windowHandle.equals(mainWindowHandle)) {
////                        driver.switchTo().window(windowHandle);
////                        break;
////                    }
////                }
////
//
//
//
//            }

    }


//    @And("^User extract text from pdf and compare$")
//    public void userExtractTextFromPdfAndCompare() throws Exception {
//        String vObjfinish = "//button[@id='end-of-document-btn-view-complete']";
//
//        Assert.assertEquals("PASS", Constants.key.ExtractPdf(vObjfinish, ""));
//
//    }

    @And("^User navigate to notary  Application \"([^\"]*)\" enter UserName \"([^\"]*)\" password \"([^\"]*)\"$")
    public void userNavigateToNotaryApplicationEnterUserNamePassword(String vUrl, String userName, String password) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        LogCapture.info("Notary Applicatiion is loading....");
        String url = Constants.CONFIG.getProperty(vUrl);
        Constants.key.pause("4", "");
        Assert.assertEquals("PASS", Constants.key.navigate("", url));
        Constants.key.pause("4", "");
        String vObjSignPage = "//h1[normalize-space(text()) = 'Sign in to your account']";
        String vObjSign = Constants.key.exist(vObjSignPage, "");
        if (vObjSign.equalsIgnoreCase("PASS")) {
            String vUserName = Constants.CONFIG.getProperty(userName);
            String vPassword = Constants.CONFIG.getProperty(password);
            String vObjUser = Constants.TitanLoginOR.getProperty("Titan_Username");
            String vObjPass = Constants.TitanLoginOR.getProperty("Titan_Password");
            LogCapture.info("User Name " + vUserName + ", Password is validated ....");
            Constants.key.VisibleConditionWait(vObjUser, "");
            Assert.assertEquals("PASS", Constants.key.click(vObjUser, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjUser, vUserName));
            Constants.key.pause("2", "");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPass, ""));
            Assert.assertEquals("PASS", Constants.key.click(vObjPass, ""));
            Assert.assertEquals("PASS", Constants.key.writeInInput(vObjPass, vPassword));
            String vObjLoginButton = Constants.TitanLoginOR.getProperty("LogInButton");
            Assert.assertEquals("PASS", Constants.key.click(vObjLoginButton, ""));

        }
    }



    @And("^User navigate to (Customers|Conflicts|Incoming Funds|Payments in|Payments out|FX tickets|Payees|Invoices|Profit Adjustment|B2B Queue|Deal Report|Add Deal) section under (Titan|Queues|Reports|Treasury)$")
    public void userNavigateToCustomerSectionUnderTitan(String Section, String Header) throws Throwable {
        String vObjTreasuryIcon = Constants.TitanDashboardOR.getProperty("TreasuryIcon");
        Assert.assertEquals("PASS", Constants.key.MouseFunctions(vObjTreasuryIcon, "MoveToElement"));
        Constants.key.pause("2", "");
        if (Section.equalsIgnoreCase("Customers") && Header.equalsIgnoreCase("Titan")) {
            String vObjCustomersSection = Constants.TitanDashboardOR.getProperty("CustomersSection");
            String vObjProfilesInTitanHeader = Constants.TitanCustomersOR.getProperty("ProfilesInTitanHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomersSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjCustomersSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjCustomersSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProfilesInTitanHeader, ""));
            LogCapture.info("User is on Profiles in Titan page..");
        }
        if (Section.equalsIgnoreCase("Conflicts") && Header.equalsIgnoreCase("Titan")) {
            String vObjConflictsSection = Constants.TitanDashboardOR.getProperty("ConflictsSection");
            String vObjConflictsInTitanHeader = Constants.TitanConflictsOR.getProperty("ConflictsInTitanHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjConflictsSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjConflictsSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjConflictsSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjConflictsInTitanHeader, ""));
            LogCapture.info("User is on Conflicts in Titan page..");
        }
        if (Section.equalsIgnoreCase("Incoming Funds") && Header.equalsIgnoreCase("Queues")) {
            String vObjIncomingFundsSection = Constants.TitanDashboardOR.getProperty("IncomingFundsSection");
            String vObjIncomingFundsHeader = Constants.TitanQueuesOR.getProperty("IncomingFundsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIncomingFundsSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjIncomingFundsSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjIncomingFundsSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjIncomingFundsHeader, ""));
            LogCapture.info("User is on Incoming Funds in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments in") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuesPaymentInSection = Constants.TitanDashboardOR.getProperty("QueuesPaymentInSection");
            String vObjPaymentsInHeader = Constants.TitanQueuesOR.getProperty("PaymentsInHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuesPaymentInSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuesPaymentInSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuesPaymentInSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsInHeader, ""));
            LogCapture.info("User is on PaymentsIn in Titan page..");
        }
        if (Section.equalsIgnoreCase("FX tickets") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuefxTicketSection = Constants.TitanDashboardOR.getProperty("QueuefxTicketSection");
            String vObjFXTicketsHeader = Constants.TitanQueuesOR.getProperty("FXTicketsHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuefxTicketSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuefxTicketSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuefxTicketSection, ""));
            //Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
            LogCapture.info("User is on FX tickets in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payees") && Header.equalsIgnoreCase("Reports")) {
            String vObjPayeeReportSection = Constants.TitanDashboardOR.getProperty("PayeeReportSection");
            String vObjPayeeReportHeader = Constants.TitanPayeeOR.getProperty("PayeeReportHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPayeeReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPayeeReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeReportHeader, ""));
            LogCapture.info("User is on Payees report in Titan page..");
        }
        if (Section.equalsIgnoreCase("Add Deal") && Header.equalsIgnoreCase("Treasury")) {
            String vObjAddDealSection = Constants.TitanDashboardOR.getProperty("AddDealSection");
            String vObjAddDealPageHeader = Constants.TitanTreasuryOR.getProperty("AddDealPageHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddDealSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjAddDealSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjAddDealSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAddDealPageHeader, ""));
            LogCapture.info("User is on Add booking in Titan page..");
        }
        if (Section.equalsIgnoreCase("B2B Queue") && Header.equalsIgnoreCase("Treasury")) {
            String vObjB2BSection = Constants.TitanDashboardOR.getProperty("B2BSection");
            String vObjUpdateB2BPage = Constants.TitanTreasuryOR.getProperty("UpdateB2BPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjB2BSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjB2BSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjB2BSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjUpdateB2BPage, ""));
            LogCapture.info("User is on Update B2B in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments out") && Header.equalsIgnoreCase("Queues")) {
            String vObjQueuesPaymentOutSection = Constants.TitanDashboardOR.getProperty("QueuesPaymentOutSection");
            String vObjPaymentsOutHeader = Constants.TitanQueuesOR.getProperty("PaymentsOutHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjQueuesPaymentOutSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjQueuesPaymentOutSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjQueuesPaymentOutSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentsOutHeader, ""));
            LogCapture.info("User is on PaymentsOut in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments in") && Header.equalsIgnoreCase("Reports")) {
            String vObjPaymentInReportSection = Constants.TitanDashboardOR.getProperty("PaymentInReportSection");
            String vObjPaymentInReportPage = Constants.TitanReportsOR.getProperty("PaymentInReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentInReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentInReportPage, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentInReportPage, "visible"));
            LogCapture.info("User is on Payments In Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("Payments out") && Header.equalsIgnoreCase("Reports")) {
            String vObjPaymentOutReporSection = Constants.TitanDashboardOR.getProperty("PaymentOutReporSection");
            String vObjPaymentOutReportPage = Constants.TitanReportsOR.getProperty("PaymentOutReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReporSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjPaymentOutReporSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutReporSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentOutReportPage, ""));
            LogCapture.info("User is on Payments Out Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("FX tickets") && Header.equalsIgnoreCase("Reports")) {
            String vObjfxTicketReportSection = Constants.TitanDashboardOR.getProperty("fxTicketReportSection");
            String vObjFXTicketsHeader = Constants.TitanReportsOR.getProperty("FXticketsReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjfxTicketReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjfxTicketReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjfxTicketReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXTicketsHeader, ""));
            LogCapture.info("User is on FX tickets Reports in Titan page..");
        }
        if (Section.equalsIgnoreCase("Invoices") && Header.equalsIgnoreCase("Reports")) {
            String vObjInvoicesReportSection = Constants.TitanDashboardOR.getProperty("DeferredInvoiceSection");
            String vObjInvoicesReportPage = Constants.TitanReportsOR.getProperty("InvoicesReportPage");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvoicesReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjInvoicesReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.click(vObjInvoicesReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjInvoicesReportPage, ""));
            LogCapture.info("User is on Invoices in Titan page under Reports..");
        }
        if (Section.equalsIgnoreCase("Deal Report") && Header.equalsIgnoreCase("Treasury")) {
            String vObjDealReportSection = Constants.TitanDashboardOR.getProperty("DealReport");
            String vObjDealQueueHeader = Constants.TitanTreasuryOR.getProperty("DealQueueHeader");
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjDealReportSection, "visible"));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjDealReportSection, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjDealQueueHeader, ""));
            LogCapture.info("User is on Deal queue in Titan page..");
        }

    }



    @Then("^User clicks on Filter option$")
    public void user_clicks_on_Filter_option() throws Throwable {
        String vObjFilter = Constants.CreateFxTicketOR.getProperty("Filter");
        LogCapture.info("Opening Filter section");
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.click(vObjFilter, ""));
        Constants.key.pause("2", "");

    }


    @Then("^User search for client number \"(.*?)\" and hits Enter key$")
    public void user_enters_client_number_and_hits_Enter_key(String clientNumber) throws Throwable {
        String vOjbKeyword = Constants.CreateFxTicketOR.getProperty("Keyword");
        Assert.assertEquals("PASS", Constants.key.writeInInput(vOjbKeyword, clientNumber));
        LogCapture.info("Searching for Client number : " + clientNumber);
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vOjbKeyword, "enter"));
        Constants.key.pause("4", "");
    }


    @Then("^User clicks on client number\"([^\"]*)\" link to navigate to customer detail page$")
    public void userClicksOnClientNumberLinkToNavigateToCustomerDetailPage(String clientNumber) throws Throwable {

        String vclientNumberXpath = "//*[contains(text(),'" + clientNumber + "')]";
        //String vclientNumberXpath= Constants.TitanCustomersOR.getProperty("CustomerFirstLine");

        //String vObjCustomerDetailLink = Constants.CreateFxTicketOR.getProperty("CustomerDetailLink");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
    }

    @Then("^User navigate to Payee section under Activity tab on customer details page and click on view payee option$")
    public void userNavigateToPayeeSectionUnderActivityTabOnCustomerDetailsPageAndClickOnViewPayeeOption() throws Exception {

        String vObjPayeeSectionActivity = Constants.TitanPayeeOR.getProperty("PayeeSectionActivity");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeSectionActivity, ""));
        LogCapture.info("User navigate to Payee section under customer details page..");

        for(int i = 1; i <=10 ; i++) {
            String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
            String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();
            String ExpPayeeFullname = NOTPayeeFirstName + " " + NOTPayeeLastName;

            String vObjPayeeCCY = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[6]//a";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeCCY, ""));
            String ActPayeeCCY = Constants.driver.findElement(By.xpath(vObjPayeeCCY)).getText();

            String vObjPayeeIBAN = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[7]//a";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeIBAN, ""));
            String ActPayeeIBANumber = Constants.driver.findElement(By.xpath(vObjPayeeIBAN)).getText();

            if (ActPayeeFullname.equals(ExpPayeeFullname) && ActPayeeCCY.equals("EUR") && ActPayeeIBANumber.equals(NOTPayeeIBAN)) {

                LogCapture.info("User able to see Payee name as "+ActPayeeFullname+", payee CCY as EUR and IBAN as "+ActPayeeIBANumber+" under payee activity Tab.....");
                String VObjViewPayeeOption = "//tbody[@id='profilePayeeBody']//tr["+i+"]//td[14]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjViewPayeeOption, ""));
                Assert.assertEquals("PASS", Constants.key.click(VObjViewPayeeOption, ""));
                Constants.key.pause("2", "");
                break;
            }

            if(i==40)
            {
                LogCapture.info("TC Failed : User unable to see newly created payee under payee activity Tab.....");
                Assert.fail();
            }
        }
    }



//    @When("^User fetch (Buyer|Seller) solicitor details from RDS database for \"([^\"]*)\" and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment$")
//    public void userFetchBuyerSolicitorDetailsFromRDSDatabaseForAndCheckStatusCodeAsForOnEnvironment(String Type, String Email, String statCode, String testCaseID, String enviroment) throws Throwable {
//
//        Constants.TCCaseID = testCaseID;
//        Constants.SHEET_NAME=enviroment;
//
//        if(Type.equalsIgnoreCase("Buyer"))
//        {
//            Constants.DynamicValue.put("<SolicitorEmail>", Email);
//            LogCapture.info("---------------POST call started to fetch Buyer's details----------------");
//            Constants.BuyerSolicitorDetails = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
//            LogCapture.info("---------------POST call ended----------------");
//        }
//        if(Type.equalsIgnoreCase("Seller"))
//        {
//            Constants.DynamicValue.put("<SolicitorEmail>", Email);
//            LogCapture.info("---------------POST call started fetch Seller's details----------------");
//            Constants.SellerSolicitorDetails = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
//            ReusableMethod.updateProperties();
//            LogCapture.info("---------------POST call ended----------------");
//        }
//
//    }
//


    @When("^User fetch (Buyer|Seller) solicitor details from RDS database for \"([^\"]*)\" and Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment$")
    public void userFetchBuyerSolicitorDetailsFromRDSDatabaseForAndCheckStatusCodeAsForOnEnvironment(String Type, String Email, String statCode, String testCaseID, String enviroment) throws Throwable {

        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME=enviroment;

        if(Type.equalsIgnoreCase("Buyer"))
        {
            Constants.DynamicValue.put("<SolicitorEmail>", Email);
            LogCapture.info("---------------POST call started to fetch Buyer's details----------------");
            Constants.BuyerSolicitorDetails = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            LogCapture.info("---------------POST call ended----------------");
        }
        if(Type.equalsIgnoreCase("Seller"))
        {
            Constants.DynamicValue.put("<SolicitorEmail>", Email);
            LogCapture.info("---------------POST call started fetch Seller's details----------------");
            Constants.SellerSolicitorDetails = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            LogCapture.info("---------------POST call ended----------------");
        }

    }


    @Then("^User Select (newly created Notary office|Existing notary office)$")
    public void userSelectNewlyCreatedNotaryOffice(String NotaryOffice) throws Exception {

        String vObjSelectNotaryOffice = Constants.PropertyPayDashboardOR.getProperty("SelectNotaryOffice");
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSelectNotaryOffice, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));

        if (NotaryOffice.equals("newly created Notary office")) {
            String vObjlistbox = Constants.TitanLoginOR.getProperty("listbox");
            List<WebElement> listElements = driver.findElements(By.xpath(vObjlistbox));

            for (WebElement element : listElements) {
                if (element.getText().contains(NotaryName + " - ")) {
                    element.click();
                    LogCapture.info("User Select notary office " + NotaryName);
                    break;
                } else {
                    LogCapture.info("User unable to select newly created notary office " + NotaryName);
                    Assert.fail();
                }
            }
        } else if (NotaryOffice.equals("Existing notary office")) {
//            String vObjlistbox = Constants.TitanLoginOR.getProperty("listbox");
//            List<WebElement> listElements = driver.findElements(By.xpath(vObjlistbox));
//
//            for (WebElement element : listElements) {
//                if (element.getText().contains("Saurabh")) {
//                    element.click();
//                    LogCapture.info("User Select notary office " + element.getText());
//                    break;
//                }
//            }

            Assert.assertEquals("PASS", Constants.key.pause("2", ""));
            String vObjExistingNotaryOffice = "(//div[@class='css-9ndn07'])[1]//p";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjExistingNotaryOffice, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjExistingNotaryOffice, ""));
            LogCapture.info("User select existing notary office ");
        }
    }


    @Then("^User verify all the details on Property Information Review summary details page when there are both solicitors$")
    public void userVerifyAllTheDetailsOnPropertyInformationReviewSummaryDetailsPageWhenThereAreBothSolicitors() throws Exception {

        String vobjSummaryReviewHeader = Constants.PropertyPayDashboardOR.getProperty("SummaryReviewHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryReviewHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryReviewHeader, "Property Information - Review"));
        LogCapture.info("User verify its landed on Property Information - Summary Review page ");
        Thread.sleep(2000);

        JsonPath BuyersAccountDetail = Constants.APIkey.rawToJson(Constants.BuyersAccountDetails);
        String vobjSummaryBuyersInfoHeader = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyersInfoHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyersInfoHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyersInfoHeader, "Buyer’s information"));
        LogCapture.info("---------- User Started validating Buyer's details on Property Information - Summary Review page ----------");

        String vobjSummaryBuyerEmail = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyerEmail");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyerEmail, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyerEmail, BuyersAccountDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Buyer's Email ["+BuyersAccountDetail.get("data.searchContact[0].email")+"] on Property Information - Summary Review page ");

        String vobjSummaryBuyerFullName = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyerFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyerFullName, BuyersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer's Full Name ["+BuyersAccountDetail.get("data.searchContact[0].name")+"] on Property Information - Summary Review page ");

        String vobjSummaryBuyerTAN = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyerTAN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyerTAN, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyerTAN, BuyersAccountDetail.get("data.searchContact[0].titanCustomerNo")));
        LogCapture.info("User verified Buyer's Titan Customer No ["+BuyersAccountDetail.get("data.searchContact[0].titanCustomerNo")+"] on Property Information - Summary Review page ");

        String vobjSummaryBuyerPassportNo = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyerPassportNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyerPassportNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyerPassportNo, BuyersAccountDetail.get("data.searchContact[0].passportNumber")));
        LogCapture.info("User verified Buyer's passport Number ["+BuyersAccountDetail.get("data.searchContact[0].passportNumber")+"] on Property Information - Summary Review page ");

        String vobjSummaryBuyerPhoneNo = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyerPhoneNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyerPhoneNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyerPhoneNo, BuyersAccountDetail.get("data.searchContact[0].phone")));
        LogCapture.info("User verified Buyer's Phone Number ["+BuyersAccountDetail.get("data.searchContact[0].phone")+"] on Property Information - Summary Review page ");


        JsonPath BuyerSolicitorDetail = Constants.APIkey.rawToJson(Constants.BuyerSolicitorDetails);
        String vobjSummaryBuyersSoliInfoHeader = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyersSoliInfoHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyersSoliInfoHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyersSoliInfoHeader, "Buyer’s legal representative’s information"));
        LogCapture.info("---------- User Started validating Buyer solicitors details on Property Information - Summary Review page ----------");


        String vobjSummaryBuyerSoliEmail = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyerSoliEmail");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyerSoliEmail, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyerSoliEmail, BuyerSolicitorDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Buyer solicitor's email ["+BuyerSolicitorDetail.get("data.searchContact[0].email")+"] on Property Information - Summary Review page ");

        String vobjSummaryBuyerSoliFullName = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyerSoliFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyerSoliFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyerSoliFullName, BuyerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer solicitor's Full name ["+BuyerSolicitorDetail.get("data.searchContact[0].name")+"] on Property Information - Summary Review page ");

        String vobjSummaryBuyerSoliPhoneNo = Constants.PropertyPayDashboardOR.getProperty("SummaryBuyerSoliPhoneNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryBuyerSoliPhoneNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryBuyerSoliPhoneNo, BuyerSolicitorDetail.get("data.searchContact[0].phone")));
        LogCapture.info("User verified Buyer solicitor's Phone Number ["+BuyerSolicitorDetail.get("data.searchContact[0].phone")+"] on Property Information - Summary Review page ");

        JsonPath SellersAccountDetail = Constants.APIkey.rawToJson(Constants.SellersAccountDetails);
        String vobjSummarySellerInfoHeader = Constants.PropertyPayDashboardOR.getProperty("SummarySellerInfoHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerInfoHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerInfoHeader, "Seller’s information"));
        LogCapture.info("---------- User Started validating Seller's details on Property Information - Summary Review page ----------");

        String vobjSummarySellerEmail = Constants.PropertyPayDashboardOR.getProperty("SummarySellerEmail");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerEmail, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerEmail, SellersAccountDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Sellers' Email ["+SellersAccountDetail.get("data.searchContact[0].email")+"] on Property Information - Summary Review page ");

        String vobjSummarySellerFullName = Constants.PropertyPayDashboardOR.getProperty("SummarySellerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerFullName, SellersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Sellers' Full Name ["+SellersAccountDetail.get("data.searchContact[0].name")+"] on Property Information - Summary Review page ");

        String vobjSummarySellerTAN = Constants.PropertyPayDashboardOR.getProperty("SummarySellerTAN");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerTAN, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerTAN, SellersAccountDetail.get("data.searchContact[0].titanCustomerNo")));
        LogCapture.info("User verified Sellers' Titan Customer No ["+SellersAccountDetail.get("data.searchContact[0].titanCustomerNo")+"] on Property Information - Summary Review page ");

        String vobjSummarySellerPassportNo = Constants.PropertyPayDashboardOR.getProperty("SummarySellerPassportNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerPassportNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerPassportNo, SellersAccountDetail.get("data.searchContact[0].passportNumber")));
        LogCapture.info("User verified Sellers' passport Number ["+SellersAccountDetail.get("data.searchContact[0].passportNumber")+"] on Property Information - Summary Review page ");

        String vobjSummarySellerPhoneNo = Constants.PropertyPayDashboardOR.getProperty("SummarySellerPhoneNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerPhoneNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerPhoneNo, SellersAccountDetail.get("data.searchContact[0].phone")));
        LogCapture.info("User verified Sellers' Phone Number ["+SellersAccountDetail.get("data.searchContact[0].phone")+"] on Property Information - Summary Review page ");


        JsonPath SellerSolicitorDetail = Constants.APIkey.rawToJson(Constants.SellerSolicitorDetails);
        String vobjSummarySellerSoliInfoHeader = Constants.PropertyPayDashboardOR.getProperty("SummarySellerSoliInfoHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerSoliInfoHeader, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerSoliInfoHeader, "Seller’s legal representative’s information"));
        LogCapture.info("---------- User Started validating Seller solicitors details on Property Information - Summary Review page ----------");

        String vobjSummarySellerSoliEmail = Constants.PropertyPayDashboardOR.getProperty("SummarySellerSoliEmail");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerSoliEmail, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerSoliEmail, SellerSolicitorDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Seller solicitor's email ["+SellerSolicitorDetail.get("data.searchContact[0].email")+"] on Property Information - Summary Review page ");

        String vobjSummarySellerSoliFullName = Constants.PropertyPayDashboardOR.getProperty("SummarySellerSoliFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerSoliFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerSoliFullName, SellerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Seller solicitor's Full name ["+SellerSolicitorDetail.get("data.searchContact[0].name")+"] on Property Information - Summary Review page ");

        String vobjSummarySellerSoliPhoneNo = Constants.PropertyPayDashboardOR.getProperty("SummarySellerSoliPhoneNo");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummarySellerSoliPhoneNo, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummarySellerSoliPhoneNo, SellerSolicitorDetail.get("data.searchContact[0].phone")));
        LogCapture.info("User verified Seller solicitor's Phone Number ["+SellerSolicitorDetail.get("data.searchContact[0].phone")+"] on Property Information - Summary Review page ");

        String vobjSummaryPropertyInformation = Constants.PropertyPayDashboardOR.getProperty("SummaryPropertyInformation");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryPropertyInformation, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryPropertyInformation, "Property information"));
        LogCapture.info("---------- User Started validating Property information details on Property Information - Summary Review page ----------");

        for(int i=19; i<=22;i++) {
            String vObjPropertyDetails = "(//div[@class='MuiListItemText-root MuiListItemText-dense MuiListItemText-multiline css-1xar93x'])[" + i + "]//p";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPropertyDetails, ""));
            String PropertyDetails = Constants.driver.findElement(By.xpath(vObjPropertyDetails)).getText();

            String vObjPropertyDetailHeader = "(//div[@class='MuiListItemText-root MuiListItemText-dense MuiListItemText-multiline css-1xar93x'])[" + i + "]//span";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPropertyDetailHeader, ""));
            String PropertyDetailHeader = Constants.driver.findElement(By.xpath(vObjPropertyDetailHeader)).getText();
            if (!PropertyDetails.equals("")) {
                LogCapture.info("User verify property " + PropertyDetailHeader + " as [" + PropertyDetails + "] on Property Information - Summary Review page ");
            } else {
                LogCapture.info("User unable to verify property " + PropertyDetailHeader + " as [" + PropertyDetails + "] on Property Information - Summary Review page ");
                Assert.fail();
            }
        }


        String vobjSummaryNotaryOfficeInformation = Constants.PropertyPayDashboardOR.getProperty("SummaryNotaryOfficeInformation");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjSummaryNotaryOfficeInformation, ""));
        Assert.assertEquals("PASS", Constants.key.verifyTextAdv(vobjSummaryNotaryOfficeInformation, "Notary’s detail"));
        LogCapture.info("---------- User Started validating Notary details on Property Information - Summary Review page ----------");

        //       Because of some issue Notary office details is not coming correctly

//        for (int j = 23; j <= 26; j++) {
//            String vObjNotaryDetails = "(//div[@class='MuiListItemText-root MuiListItemText-dense MuiListItemText-multiline css-1xar93x'])[" + j + "]//p";
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryDetails, ""));
//            String NotaryDetails = Constants.driver.findElement(By.xpath(vObjNotaryDetails)).getText();
//
//            String vObjNotaryDetailHeader = "(//div[@class='MuiListItemText-root MuiListItemText-dense MuiListItemText-multiline css-1xar93x'])[" + j + "]//span";
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryDetailHeader, ""));
//            String NotaryDetailHeader = Constants.driver.findElement(By.xpath(vObjNotaryDetailHeader)).getText();
//            if (!NotaryDetails.equals("")) {
//                LogCapture.info("User verify Notary office " + NotaryDetailHeader + " as [" + NotaryDetails + "] on Property Information - Summary Review page ");
//            } else {
//                LogCapture.info("User unable to verify Notary office " + NotaryDetailHeader + " as [" + NotaryDetails + "] on Property Information - Summary Review page ");
//                Assert.fail();
//            }
//
//        }
    }


    @And("^User clicks on client number to navigate to customer detail page$")
    public void userClicksOnClientNumberToNavigateToCustomerDetailPage() throws Exception {

        String vclientNumberXpath = "//tbody[@id='accountSummaryTableBody']//td[6]//a";

        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vclientNumberXpath, ""));
        Constants.key.pause("2", "");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vclientNumberXpath, ""));
        Constants.key.pause("2", "");

    }

    @Then("^User click on submit button after reviewing summary details page$")
    public void userClickOnSubmitButtonAfterReviewingSummaryDetailsPage() throws Exception {

        String vObjSummarySubmitButton = PropertyPayDashboardOR.getProperty("SummarySubmitButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSummarySubmitButton, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSummarySubmitButton, ""));
        LogCapture.info("User click on Submit after reviewing all the details on Review summary page");
        Thread.sleep(5000);

        LogCapture.info("===================================== Property Information Stage Completed =====================================");

    }


    @Then("^User select \"([^\"]*)\" language for Buyer's TPA$")
    public void userSelectLanguageForBuyerSTPA(String TPALanguage) throws Throwable {

        LogCapture.info("===================================== Third party authorisation Stage Started =====================================");

        String vObjBuyerTPALanguage = "//*[contains(text(),'Select language')]//parent::div//*[local-name()='svg']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjBuyerTPALanguage, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjBuyerTPALanguage, ""));
        LogCapture.info("User click on select language dropdown for Buyer");

        String vObjlistbox = Constants.TitanLoginOR.getProperty("listbox");
        List<WebElement> listElements = driver.findElements(By.xpath(vObjlistbox));

        for (WebElement element : listElements) {
            if (element.getText().contains(TPALanguage)) {
                element.click();
                LogCapture.info("User select Buyer's TPA Language as " + TPALanguage);
                break;
            }
        }
    }

    @And("^User click on (Send TPA form to Buyer|Send TPA form to Seller)$")
    public void userClickOnSendTPAFormToBuyer(String button) throws Exception {

        String vObjTPAButton = "//button//*[normalize-space()='" + button + "']";
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjTPAButton, ""));
        LogCapture.info("User clicked on Send Buyer's TPA");
        Assert.assertEquals("PASS", Constants.key.pause("5", ""));

        if(button.equals("Send TPA form to Buyer"))
        {
            String BuyerTPAStatus = "(//p[text()='sent'])[1]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(BuyerTPAStatus, ""));
            String ActualBuyerTPAStatus = Constants.driver.findElement(By.xpath(BuyerTPAStatus)).getText();
            if(ActualBuyerTPAStatus.equals("sent"))
            {
                LogCapture.info("User verify Buyer's TPA Status as " +ActualBuyerTPAStatus);
            }
            else
            {
                LogCapture.info("User unable to verify Buyer's TPA Status as " +ActualBuyerTPAStatus);
                Assert.fail();
            }
        }
        if(button.equals("Send TPA form to Seller"))
        {
            String BuyerTPAStatus = "(//p[text()='sent'])[2]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(BuyerTPAStatus, ""));
            String ActualBuyerTPAStatus = Constants.driver.findElement(By.xpath(BuyerTPAStatus)).getText();
            if(ActualBuyerTPAStatus.equals("sent"))
            {
                LogCapture.info("User verify Seller's TPA Status as " +ActualBuyerTPAStatus);
            }
            else
            {
                LogCapture.info("User unable to verify Seller's TPA Status as " +ActualBuyerTPAStatus);
                Assert.fail();
            }
        }

    }

    @Then("^User select \"([^\"]*)\" language for Seller's TPA$")
    public void userSelectLanguageForSellerSTPA(String TPALanguage) throws Throwable {

        String vObjSellerTPALanguage = "//*[contains(text(),'Select language')]//parent::div//*[local-name()='svg']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSellerTPALanguage, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjSellerTPALanguage, ""));
        LogCapture.info("User click on select language dropdown for Seller");

        String vObjlistbox = Constants.TitanLoginOR.getProperty("listbox");
        List<WebElement> listElements = driver.findElements(By.xpath(vObjlistbox));

        for (WebElement element : listElements) {
            if (element.getText().contains(TPALanguage)) {
                ((JavascriptExecutor) Constants.driver).executeScript("arguments[0].scrollIntoView", element); element.click();
                LogCapture.info("User select Seller's TPA Language as " + TPALanguage);
                break;
            }
        }
    }


//    @And("^User click on (Send TPA form to Buyer|Send TPA form to Seller)$")
//    public void userClickOnSendTPAFormToBuyer(String button) throws Exception {
//
//        String vObjTPAButton = "//button//*[normalize-space()='" + button + "']";
//        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
//        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjTPAButton, ""));
//        LogCapture.info("User clicked on Send Buyer's TPA");
//        Assert.assertEquals("PASS", Constants.key.pause("5", ""));
//
//        if(button.equals("Send TPA form to Buyer"))
//        {
//            String BuyerTPAStatus = "(//p[text()='sent'])[1]";
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(BuyerTPAStatus, ""));
//            String ActualBuyerTPAStatus = Constants.driver.findElement(By.xpath(BuyerTPAStatus)).getText();
//            if(ActualBuyerTPAStatus.equals("sent"))
//            {
//                LogCapture.info("User verify Buyer's TPA Status as " +ActualBuyerTPAStatus);
//            }
//            else
//            {
//                LogCapture.info("User unable to verify Buyer's TPA Status as " +ActualBuyerTPAStatus);
//                Assert.fail();
//            }
//        }
//        if(button.equals("Send TPA form to Seller"))
//        {
//            String BuyerTPAStatus = "(//p[text()='sent'])[2]";
//            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(BuyerTPAStatus, ""));
//            String ActualBuyerTPAStatus = Constants.driver.findElement(By.xpath(BuyerTPAStatus)).getText();
//            if(ActualBuyerTPAStatus.equals("sent"))
//            {
//                LogCapture.info("User verify Seller's TPA Status as " +ActualBuyerTPAStatus);
//            }
//            else
//            {
//                LogCapture.info("User unable to verify Seller's TPA Status as " +ActualBuyerTPAStatus);
//                Assert.fail();
//            }
//        }
//
//    }


    @Then("^User verify Proceed to disbursements button is disable$")
    public void userVerifyProceedToDisbursementsButtonIsDisable() throws Exception {
        Thread.sleep(5000);
        String vObjProceedToDisbursementsButton = PropertyPayDashboardOR.getProperty("ProceedToDisbursementsButton");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjProceedToDisbursementsButton, ""));
        Assert.assertEquals("PASS", Constants.key.verifyElementProperties(vObjProceedToDisbursementsButton, "disabled"));
        LogCapture.info("User verify proceed to disbursements button is disabled");

    }


    @Then("^User navigate to Payee section under Activity tab on customer details page$")
    public void userNavigateToPayeeSectionUnderActivityTabOnCustomerDetailsPage() throws Exception {

        String vObjPayeeSectionActivity = Constants.TitanPayeeOR.getProperty("PayeeSectionActivity");
        Assert.assertEquals("PASS", Constants.key.click(vObjPayeeSectionActivity, ""));
        LogCapture.info("User navigate to Payee section under customer details page..");
    }



    @Then("^User verify Newly added payee are visible Under payee section on Titan after signing Buyer disbursement$")
    public void userVerifyNewlyAddedPayeeAreVisibleUnderPayeeSectionOnTitanAfterSigningBuyerDisbursement() throws Exception {

        Thread.sleep(2000);
        LogCapture.info("TC Failed : >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+BuyerBen1);

        if(NoofBuyerBeni==1)
        {
            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" under payee activity Tab for buyer disbursement.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee under payee activity Tab for buyer disbursement.....");
                    Assert.fail();
                }
            }
        }else if(NoofBuyerBeni==2)
        {
            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }


            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen2)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
        }else if(NoofBuyerBeni==3)
        {
            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen2)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen3)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
        }else if(NoofBuyerBeni==4)
        {
            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen2)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen3)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen4)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
        }else if(NoofBuyerBeni==5)
        {
            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen2)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen3)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen4)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for buyer disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen5)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
        }else if(NoofBuyerBeni==6)
        {
            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for buyer disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen2)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen3)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen4)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen5)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=50 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(BuyerBen6)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==50)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
        }
    }


    @And("^User Click on Payment in activity tab Button$")
    public void userClickOnPaymentInActivityTabButton() throws Exception {

        LogCapture.info("User clicking On Payment in Button");
        String VobjPaymentInButton = Constants.TitanCustomersOR.getProperty("PaymentInBtn");
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(VobjPaymentInButton, ""));
        Assert.assertEquals("PASS", Constants.key.pause("2", ""));
        LogCapture.info("User Clicked on Payment In activity tab Button.. ");
    }

    @Then("^User verify Seller disbursement Amount under payment in for Today's transaction date$")
    public void userVerifySellerDisbursementAmountUnderPaymentInForTodaySTransactionDate() throws Exception {

        String ExpFinaldisAmount = Integer.toString(finaldisAmount);

        for (int i = 1; i <= 50; i++) {
            String VObjPaymentInAmount = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInAmount, ""));
            String ActPaymentInAmount = Constants.driver.findElement(By.xpath(VObjPaymentInAmount)).getText();
            String PaymentInAmount = ActPaymentInAmount.replace(",", "").replace(".00", "");

            String VObjPaymentInCCY = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[6]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInCCY, ""));
            String PaymentInCCY = Constants.driver.findElement(By.xpath(VObjPaymentInCCY)).getText();

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String TodaysDate = dtf1.format(now);

            String VObjPaymentInDate = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[1]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInDate, ""));
            String PaymentInDatewithTime = Constants.driver.findElement(By.xpath(VObjPaymentInDate)).getText();
            String PaymentInDate = PaymentInDatewithTime.trim().substring(0,10);

            if (PaymentInAmount.equals(ExpFinaldisAmount) && PaymentInCCY.equals("EUR") && TodaysDate.equals(PaymentInDate)) {

                LogCapture.info("User verify verify seller disbursement amount as ["+PaymentInAmount+"] and CCY as ["+PaymentInCCY+"] under payment in activity tab for Today's date "+PaymentInDate);
                break;
            }else
            if(i==20)
            {
                LogCapture.info("TC Failed : User unable to verify seller disbursement amount as ["+ExpFinaldisAmount+"] and CCY as [EUR] under payment in activity tab for Today's date "+PaymentInDate);
                Assert.fail();
            }
        }
    }

    @Then("^User verify Buyer disbursement Amount under payment in for Today's transaction date$")
    public void userVerifyBuyerDisbursementAmountUnderPaymentInForTodaySTransactionDate() throws Exception {
        String ExpFinaldisAmount = Integer.toString(finaldisAmount);
        for (int i = 1; i <= 50; i++) {
            String VObjPaymentInAmount = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInAmount, ""));
            String ActPaymentInAmount = Constants.driver.findElement(By.xpath(VObjPaymentInAmount)).getText();
            String PaymentInAmount = ActPaymentInAmount.replace(",", "").replace(".00", "");
            String VObjPaymentInCCY = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[6]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInCCY, ""));
            String PaymentInCCY = Constants.driver.findElement(By.xpath(VObjPaymentInCCY)).getText();
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String TodaysDate = dtf1.format(now);
            String VObjPaymentInDate = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[1]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInDate, ""));
            String PaymentInDatewithTime = Constants.driver.findElement(By.xpath(VObjPaymentInDate)).getText();
            String PaymentInDate = PaymentInDatewithTime.trim().substring(0,10);
            if (PaymentInAmount.equals("-"+ExpFinaldisAmount) && PaymentInCCY.equals("EUR") && TodaysDate.equals(PaymentInDate)) {
                LogCapture.info("User verify buyer disbursement amount as ["+PaymentInAmount+"] and CCY as ["+PaymentInCCY+"]under payment in activity tab for Today's date "+PaymentInDate);
                break;
            }else
            if(i==20)
            {
                LogCapture.info("TC Failed : User unable to verify buyer disbursement amount as [-"+ExpFinaldisAmount+"] and CCY as [EUR] under payment in activity tab for Today's date "+PaymentInDate);
                Assert.fail();
            }
        }
    }

    @Then("^User able to see error message when mandatory details is missing for while creating Notary office$")
    public void userAbleToSeeErrorMessageWhenMandatoryDetailsIsMissingForWhileCreatingNotaryOffice() throws Exception {

        String vObjNO_NoratyNameIsReq = Constants.PropertyPayDashboardOR.getProperty("NO_NoratyNameIsReq");
        String vObjNO_AddressLine1IsRequired = Constants.PropertyPayDashboardOR.getProperty("NO_AddressLine1IsRequired");
        String vObjNO_AddressLine2IsRequired = Constants.PropertyPayDashboardOR.getProperty("NO_AddressLine2IsRequired");
        String vObjNO_StateCountryISRequired = Constants.PropertyPayDashboardOR.getProperty("NO_StateCountryISRequired");
        String vObjNO_TownCityIsRequired = Constants.PropertyPayDashboardOR.getProperty("NO_TownCityIsRequired");
        String vObjNO_PostCodeIsRequired = Constants.PropertyPayDashboardOR.getProperty("NO_PostCodeIsRequired");
        String vObjNotaryAdmin = Constants.PropertyPayDashboardOR.getProperty("NotaryAdmin");


        String vObjNO_NoratyName = Constants.PropertyPayDashboardOR.getProperty("NO_NoratyName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_NoratyName, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_NoratyNameIsReq, ""));
        String NO_NoratyNameIsReq = driver.findElement(By.xpath(vObjNO_NoratyNameIsReq)).getText();
        if(NO_NoratyNameIsReq.equals("Notary Name is required"))
        {
            LogCapture.info("User Able to see error as [Notary Name is required] ...");

        }else {
            LogCapture.info("TC Failed : User unable to see error as [Notary Name is required] ...");
            Assert.fail();
        }


        String vObjNO_AddressLine1 = Constants.PropertyPayDashboardOR.getProperty("NO_AddressLine1");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine1, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine1IsRequired, ""));
        String NO_AddressLine1IsRequired = driver.findElement(By.xpath(vObjNO_AddressLine1IsRequired)).getText();
        if(NO_AddressLine1IsRequired.equals("Address Line 1 is required"))
        {
            LogCapture.info("User Able to see error as [Address Line 1 is required] ...");

        }else {
            LogCapture.info("TC Failed : User unable to see error as [Address Line 1 is required] ...");
            Assert.fail();
        }


        String vObjNO_AddressLine2 = Constants.PropertyPayDashboardOR.getProperty("NO_AddressLine2");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_AddressLine2, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_AddressLine2IsRequired, ""));
        String NO_AddressLine2IsRequired = driver.findElement(By.xpath(vObjNO_AddressLine2IsRequired)).getText();
        if(NO_AddressLine2IsRequired.equals("Address Line 2 is required"))
        {
            LogCapture.info("User Able to see error as [Address Line 2 is required] ...");

        }else {
            LogCapture.info("TC Failed : User unable to see error as [Address Line 2 is required] ...");
            Assert.fail();
        }


        String vObjNO_State = Constants.PropertyPayDashboardOR.getProperty("NO_State");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_State, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_StateCountryISRequired, ""));
        String NO_StateCountryISRequired = driver.findElement(By.xpath(vObjNO_StateCountryISRequired)).getText();
        if(NO_StateCountryISRequired.equals("State/County is required"))
        {
            LogCapture.info("User Able to see error as [State/County is required] ...");

        }else {
            LogCapture.info("TC Failed : User unable to see error as [State/County is required] ...");
            Assert.fail();
        }


        String vObjNO_TownCity = Constants.PropertyPayDashboardOR.getProperty("NO_TownCity");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_TownCity, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_TownCityIsRequired, ""));
        String TownCityIsRequired = driver.findElement(By.xpath(vObjNO_TownCityIsRequired)).getText();
        if(TownCityIsRequired.equals("Town/City is required"))
        {
            LogCapture.info("User Able to see error as [Town/City is required] ...");

        }else {
            LogCapture.info("TC Failed : User unable to see error as [Town/City is required] ...");
            Assert.fail();
        }


        String vObjNO_PostCode = Constants.PropertyPayDashboardOR.getProperty("NO_PostCode");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNO_PostCode, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjNotaryAdmin, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNO_PostCodeIsRequired, ""));
        String NO_PostCodeIsRequired = driver.findElement(By.xpath(vObjNO_PostCodeIsRequired)).getText();
        if(NO_PostCodeIsRequired.equals("Postcode is required"))
        {
            LogCapture.info("User Able to see error as [Postcode is required] ...");

        }else {
            LogCapture.info("TC Failed : User unable to see error as [Postcode is required] ...");
            Assert.fail();
        }
    }

    @Then("^User verify Newly added payee are visible Under payee section on Titan after signing seller disbursement$")
    public void userVerifyNewlyAddedPayeeAreVisibleUnderPayeeSectionOnTitanAfterSigningSellerDisbursement() throws Exception {

        Thread.sleep(2000);

        if(NoofSellerBeni==1)
        {
            for(int i = 1; i <=20 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(SellerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==10)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee under payee activity Tab.....");
                    Assert.fail();
                }
            }
        }else if(NoofSellerBeni==2)
        {
            for(int i = 1; i <=20 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(SellerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==10)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }


            for(int i = 1; i <=20 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(SellerBen2)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==20)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
        }else if(NoofSellerBeni==3)
        {
            for(int i = 1; i <=20 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(SellerBen1)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==10)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    LogCapture.info("Actual PayeeName ="+ActPayeeFullname);
                    LogCapture.info("Actual PayeeName ="+SellerBen1);
                    Assert.fail();
                }
            }

            for(int i = 1; i <=20 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(SellerBen2)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }

                if(i==20)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }

            for(int i = 1; i <=20 ; i++) {
                String vObjPayeeName = "//tbody[@id='profilePayeeBody']//tr[" + i + "]//td[2]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPayeeName, ""));
                String ActPayeeFullname = Constants.driver.findElement(By.xpath(vObjPayeeName)).getText();

                if (ActPayeeFullname.equals(SellerBen3)) {

                    LogCapture.info("User able to see Payee name as "+ActPayeeFullname+" for Seller disbursement under payee activity Tab.....");
                    Constants.key.pause("2", "");
                    break;
                }
                if(i==20)
                {
                    LogCapture.info("TC Failed : User unable to verify newly created payee for Seller disbursement under payee activity Tab.....");
                    Assert.fail();
                }
            }
        }
    }

    @And("^user click on Save-continue button after reviewing existing Notary office details$")
    public void userClickOnSaveContinueButtonAfterReviewingExistingNotaryOfficeDetails() throws Exception {
        String vObjSaveAndContinuePropertyDetailsPage = "//p[@text='Save and continue']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjSaveAndContinuePropertyDetailsPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSaveAndContinuePropertyDetailsPage, ""));
        LogCapture.info("User click on Save and Continue button after entering property details information......");
        Thread.sleep(2000);
    }

    @And("^open Email on mailinator with Title \"([^\"]*)\" and subject \"([^\"]*)\" and verify details\"([^\"]*)\" , BuyerFullname and Buyer’slegalFullname in TPA form$")
    public void openEmailOnMailinatorWithTitleAndSubjectAndVerifyDetailsBuyerFullnameAndBuyerSlegalFullnameInTPAForm(String Title, String subject, String BuyerEmail) throws Throwable {

        Assert.assertEquals("PASS", Constants.key.Paidmailinatorlogin());

        String vObjEmailInbox = "//input[@id='inbox_field']";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjEmailInbox, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjEmailInbox, BuyerEmail));

        String vObjSearchButton = "//button[@class='primary-btn']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjSearchButton, ""));
        LogCapture.info("User enter emailAddress and click on search");
        Constants.key.pause("10", "");
        String vObjFirestMail = "//td[contains(text(),'" + Title + "')]";
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFirestMail, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjFirestMail, ""));
        String vObjFrame = "//iframe[@id='html_msg_body']";
        Constants.key.frame(vObjFrame, "");
        String vObjMail = "//*[text()='" + subject + " ']";
        Constants.key.pause("5", "");
        String vObjReviwe = "//span[normalize-space()='"+subject+"']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjReviwe, ""));
        // Switch to the new window
        String mainWindowHandle = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(mainWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

        Constants.key.pause("15", "");
        Constants.key.pause("10", "");
        String vObjck = "//label[@for='disclosureAccepted']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjck, ""));
        Constants.key.pause("5", "");
        String vObjCont = "//button[@id='action-bar-btn-continue']";
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCont, ""));
        Constants.key.pause("10", "");
        String vObjpdfname1 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[1]";
        String vObjpdfname2 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[2]";
        String vObjpdfname3 = "(//div[@class='tab-form-element locked singleline' ]//span[@aria-hidden='true'])[4]";
//        String vObjfullname = "//input[@id='full-name']";
        String vObjinitials = "//input[@id='initials']";
        String vObjAdopt = "//button[normalize-space()='Adopt and Sign']";


        String vObjsign = "//i[@class='sign-arrow']";
        String vObjDate = "//input[@aria-invalid='false']";
        String vObjSigniture ="//div[@class='doc-tab signature-tab owned signing-required signed']/button";

        Constants.key.navigateSubMenu(vObjReviwe, "");
        LogCapture.info("User verify text from received mail");

        JsonPath BuyersAccountDetail = Constants.APIkey.rawToJson(Constants.BuyersAccountDetails);
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname1, BuyersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer's Full Name ["+BuyersAccountDetail.get("data.searchContact[0].name")+"] on TPA Form");

        JsonPath BuyerSolicitorDetail = Constants.APIkey.rawToJson(Constants.BuyerSolicitorDetails);
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname2, BuyerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer solicitor's Full name ["+BuyerSolicitorDetail.get("data.searchContact[0].name")+"] on TPA Form");
        Constants.key.pause("5", "");

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        String CurrentDateDate = dateFormat.format(cal.getTime());

        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjDate, CurrentDateDate));
        String vObjSigne =  Constants.key.notexist(vObjSigniture, "");
        Constants.key.pause("3", "");
        if(vObjSigne.equalsIgnoreCase("PASS")){
            Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjsign, ""));
            Constants.key.pause("5", "");
            Constants.key.pause("8", "");
            WebElement popupButton = driver.findElement(By.xpath("//button[normalize-space()='Adopt and Sign']"));
            popupButton.click();

        }


        // Now you are in the new window/popup, you can interact with elements here
        // For example, click on a button in the popup


////        Assert.assertEquals("PASS", Constants.key.verifyText(vObjfullname, "Sathiyanew Sathiyanew"));
////        Assert.assertEquals("PASS", Constants.key.verifyText(vObjinitials, "SS"));
//        Constants.key.pause("5", "");
//
//
//        // Switch to the new window
//        String mainWindowHandle2 = driver.getWindowHandle();
//        for (String windowHandle2 : driver.getWindowHandles()) {
//            if (!windowHandle2.equals(mainWindowHandle)) {
//                driver.switchTo().window(windowHandle2);
//                break;
//            }
//        }
//
//        Constants.key.pause("10", "");
//
//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjAdopt, ""));
//        Constants.key.pause("5", "");
//        driver.switchTo().window(mainWindowHandle);
//        Constants.key.pause("5", "");
//        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjDate, "28/03/2024"));
//        Constants.key.pause("5", "");
        Constants.key.pause("10", "");

        String vObjfinish ="//button[@id='end-of-document-btn-finish']";
        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vObjfinish, ""));

        Constants.key.pause("20", "");
        // Close the main window or continue with further operations
        driver.close();
        Constants.key.pause("5", "");
        driver.quit();


        //input[@id='tab-form-element-e8a1111a-31c6-4ab5-8595-df6ed80b952e']
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname1, name));
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname2, Soli));
//        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname3, name));

        //        Assert.assertEquals("PASS", Constants.key.verifyText(vObjpdfname4, ""));
        // After finishing operations on the new window, you can switch back to the main window if needed
//        driver.switchTo().window(mainWindowHandle);
//        Constants.key.pause("5000", "");
        //button[@id='action-bar-btn-continue']
        //div[@id='tab-form-element-57c43ab3-c496-4722-951b-46015f0d0d06']//span[@aria-hidden='true'][normalize-space()='Sathiyanew Sathiyanew']

        //div[@id='tab-form-element-669d2e16-2aa3-46cf-ba86-c85055a7de58']


        //div[@class="tab-form-element locked singleline"]//span[@aria-hidden="true"]
        //div[@id='tab-form-element-a77586f6-be0b-4a32-a650-af813f565324']


        //label[@for="disclosureAccepted"  and @class="cb_label"]


//        driver.get(currentUrlPage);
    }


    @Then("^Verify User able to fetch Buyer Details for \"([^\"]*)\" when Phone number with hyphen is present$")
    public void verifyUserAbleToFetchBuyerDetailsForWhenPhoneNumberWithhyphenIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath BuyersAccountDetail = Constants.APIkey.rawToJson(Constants.BuyersAccountDetails);
        String vobjBuyerEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerEmailAddress, BuyersAccountDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Buyer's Email ["+BuyersAccountDetail.get("data.searchContact[0].email")+"] on Buyer details page");

        String vobjBuyerFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerFullName, BuyersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer's Full Name ["+BuyersAccountDetail.get("data.searchContact[0].name")+"] on Buyer details page");

        String vobjBuyerCDAccountNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerCDAccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerCDAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerCDAccountNumber, BuyersAccountDetail.get("data.searchContact[0].titanCustomerNo")));
        LogCapture.info("User verified Buyer's Titan Customer No ["+BuyersAccountDetail.get("data.searchContact[0].titanCustomerNo")+"] on Buyer details page");

        String vobjBuyerPhoneNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerPhoneNumber)).getText();
        if(BuyerPhoneNumberAct.contains("-"))
        {
            LogCapture.info("User User able to fetch details when Phone Number with hyphen [ "+BuyerPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch details when Phone Number with hyphen is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Buyer Solicitor Details for \"([^\"]*)\" when Phone number with hyphen is present$")
    public void verifyUserAbleToFetchBuyerSolicitorDetailsForWhenPhoneNumberWithhyphenIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath BuyerSolicitorDetail = Constants.APIkey.rawToJson(Constants.BuyerSolicitorDetails);
        String vobjBuyerSoliEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliEmailAddress, BuyerSolicitorDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Buyer solicitor's email ["+BuyerSolicitorDetail.get("data.searchContact[0].email")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliFullName, BuyerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer solicitor's Full name ["+BuyerSolicitorDetail.get("data.searchContact[0].name")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliPhoneNo = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerSoliPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerSoliPhoneNo)).getText();
        if(BuyerSoliPhoneNumberAct.contains("-"))
        {
            LogCapture.info("User User able to fetch Buyer Solicitor details when Phone Number with hyphen [ "+BuyerSoliPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Buyer Solicitor details when Phone Number with hyphen is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Seller Details for \"([^\"]*)\" when Phone number with hyphen is present$")
    public void verifyUserAbleToFetchSellerDetailsForWhenPhoneNumberWithhyphenIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath SellersAccountDetail = Constants.APIkey.rawToJson(Constants.SellersAccountDetails);
        String vobjBuyerEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerEmailAddress, SellersAccountDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Seller's Email ["+SellersAccountDetail.get("data.searchContact[0].email")+"] on Buyer details page");

        String vobjBuyerFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerFullName, SellersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Seller's Full Name ["+SellersAccountDetail.get("data.searchContact[0].name")+"] on Buyer details page");

        String vobjBuyerCDAccountNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerCDAccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerCDAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerCDAccountNumber, SellersAccountDetail.get("data.searchContact[0].titanCustomerNo")));
        LogCapture.info("User verified Seller's Titan Customer No ["+SellersAccountDetail.get("data.searchContact[0].titanCustomerNo")+"] on Buyer details page");

        String vobjBuyerPhoneNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerPhoneNumber)).getText();
        if(BuyerPhoneNumberAct.contains("-"))
        {
            LogCapture.info("User User able to fetch Seller details when Phone Number with hyphen [ "+BuyerPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Seller details when Phone Number with hyphen is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Seller Solicitor Details for \"([^\"]*)\" when Phone number with hyphen is present$")
    public void verifyUserAbleToFetchSellerSolicitorDetailsForWhenPhoneNumberWithhyphenIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath SellerSolicitorDetail = Constants.APIkey.rawToJson(Constants.SellerSolicitorDetails);
        String vobjBuyerSoliEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliEmailAddress, SellerSolicitorDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Seller solicitor's email ["+SellerSolicitorDetail.get("data.searchContact[0].email")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliFullName, SellerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Seller solicitor's Full name ["+SellerSolicitorDetail.get("data.searchContact[0].name")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliPhoneNo = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerSoliPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerSoliPhoneNo)).getText();
        if(BuyerSoliPhoneNumberAct.contains("-"))
        {
            LogCapture.info("User User able to fetch Seller Solicitor details when Phone Number with hyphen [ "+BuyerSoliPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Seller Solicitor details when Phone Number with hyphen is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Buyer Details for \"([^\"]*)\" when Phone number with Space is present$")
    public void verifyUserAbleToFetchBuyerDetailsForWhenPhoneNumberWithSpaceIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath BuyersAccountDetail = Constants.APIkey.rawToJson(Constants.BuyersAccountDetails);
        String vobjBuyerEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerEmailAddress, BuyersAccountDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Buyer's Email ["+BuyersAccountDetail.get("data.searchContact[0].email")+"] on Buyer details page");

        String vobjBuyerFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerFullName, BuyersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer's Full Name ["+BuyersAccountDetail.get("data.searchContact[0].name")+"] on Buyer details page");

        String vobjBuyerCDAccountNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerCDAccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerCDAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerCDAccountNumber, BuyersAccountDetail.get("data.searchContact[0].titanCustomerNo")));
        LogCapture.info("User verified Buyer's Titan Customer No ["+BuyersAccountDetail.get("data.searchContact[0].titanCustomerNo")+"] on Buyer details page");

        String vobjBuyerPhoneNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerPhoneNumber)).getText();
        if(BuyerPhoneNumberAct.contains(" ") && !BuyerPhoneNumberAct.contains("-"))
        {
            LogCapture.info("User User able to fetch Buyer's details when Phone Number with Space [ "+BuyerPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Buyer's details when Phone Number with Space is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Buyer Solicitor Details for \"([^\"]*)\" when Phone number with Space is present$")
    public void verifyUserAbleToFetchBuyerSolicitorDetailsForWhenPhoneNumberWithSpaceIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath BuyerSolicitorDetail = Constants.APIkey.rawToJson(Constants.BuyerSolicitorDetails);
        String vobjBuyerSoliEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliEmailAddress, BuyerSolicitorDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Buyer solicitor's email ["+BuyerSolicitorDetail.get("data.searchContact[0].email")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliFullName, BuyerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer solicitor's Full name ["+BuyerSolicitorDetail.get("data.searchContact[0].name")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliPhoneNo = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerSoliPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerSoliPhoneNo)).getText();
        if(BuyerSoliPhoneNumberAct.contains(" ") && !BuyerSoliPhoneNumberAct.contains("-"))
        {
            LogCapture.info("User User able to fetch Buyer Solicitor details when Phone Number with space [ "+BuyerSoliPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Buyer Solicitor details when Phone Number with space is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Seller Details for \"([^\"]*)\" when Phone number with space is present$")
    public void verifyUserAbleToFetchSellerDetailsForWhenPhoneNumberWithSpaceIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath SellersAccountDetail = Constants.APIkey.rawToJson(Constants.SellersAccountDetails);
        String vobjBuyerEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerEmailAddress, SellersAccountDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Seller's Email ["+SellersAccountDetail.get("data.searchContact[0].email")+"] on Buyer details page");

        String vobjBuyerFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerFullName, SellersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Seller's Full Name ["+SellersAccountDetail.get("data.searchContact[0].name")+"] on Buyer details page");

        String vobjBuyerCDAccountNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerCDAccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerCDAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerCDAccountNumber, SellersAccountDetail.get("data.searchContact[0].titanCustomerNo")));
        LogCapture.info("User verified Seller's Titan Customer No ["+SellersAccountDetail.get("data.searchContact[0].titanCustomerNo")+"] on Buyer details page");

        String vobjBuyerPhoneNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerPhoneNumber)).getText();
        if(BuyerPhoneNumberAct.contains(" ") && !BuyerPhoneNumberAct.contains("-"))
        {
            LogCapture.info("User User able to fetch Seller details when Phone Number with space [ "+BuyerPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Seller details when Phone Number with space is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Seller Solicitor Details for \"([^\"]*)\" when Phone number with space is present$")
    public void verifyUserAbleToFetchSellerSolicitorDetailsForWhenPhoneNumberWithSpaceIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath SellerSolicitorDetail = Constants.APIkey.rawToJson(Constants.SellerSolicitorDetails);
        String vobjBuyerSoliEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliEmailAddress, SellerSolicitorDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Seller solicitor's email ["+SellerSolicitorDetail.get("data.searchContact[0].email")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliFullName, SellerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Seller solicitor's Full name ["+SellerSolicitorDetail.get("data.searchContact[0].name")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliPhoneNo = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerSoliPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerSoliPhoneNo)).getText();
        if(BuyerSoliPhoneNumberAct.contains(" ") && !BuyerSoliPhoneNumberAct.contains("-"))
        {
            LogCapture.info("User User able to fetch Seller Solicitor details when Phone Number with space [ "+BuyerSoliPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Seller Solicitor details when Phone Number with space is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Buyer Details for \"([^\"]*)\" when Phone number with multiple Space is present$")
    public void verifyUserAbleToFetchBuyerDetailsForWhenPhoneNumberWithMultipleSpaceIsPresent(String arg0) throws Throwable {
        Thread.sleep(3000);
        JsonPath BuyersAccountDetail = Constants.APIkey.rawToJson(Constants.BuyersAccountDetails);
        String vobjBuyerEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerEmailAddress, BuyersAccountDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Buyer's Email ["+BuyersAccountDetail.get("data.searchContact[0].email")+"] on Buyer details page");

        String vobjBuyerFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerFullName, BuyersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer's Full Name ["+BuyersAccountDetail.get("data.searchContact[0].name")+"] on Buyer details page");

        String vobjBuyerCDAccountNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerCDAccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerCDAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerCDAccountNumber, BuyersAccountDetail.get("data.searchContact[0].titanCustomerNo")));
        LogCapture.info("User verified Buyer's Titan Customer No ["+BuyersAccountDetail.get("data.searchContact[0].titanCustomerNo")+"] on Buyer details page");

        String vobjBuyerPhoneNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerPhoneNumber)).getText();

        int SpaceCount =0;
        for (int i = 0; i < BuyerPhoneNumberAct.length() - 1; i++) {
            if (BuyerPhoneNumberAct.charAt(i) == ' ') {
                SpaceCount++;
            }
        }
        if(SpaceCount>1)
        {
            LogCapture.info("User User able to fetch Buyer's details when Phone Number with multiple Space [ "+BuyerPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Buyer's details when Phone Number with Space multiple is present");
            Assert.fail();
        }
    }

    @Then("^Verify User able to fetch Buyer Solicitor Details for \"([^\"]*)\" when Phone number with multiple Space is present$")
    public void verifyUserAbleToFetchBuyerSolicitorDetailsForWhenPhoneNumberWithMultipleSpaceIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath BuyerSolicitorDetail = Constants.APIkey.rawToJson(Constants.BuyerSolicitorDetails);
        String vobjBuyerSoliEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliEmailAddress, BuyerSolicitorDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Buyer solicitor's email ["+BuyerSolicitorDetail.get("data.searchContact[0].email")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliFullName, BuyerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Buyer solicitor's Full name ["+BuyerSolicitorDetail.get("data.searchContact[0].name")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliPhoneNo = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerSoliPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerSoliPhoneNo)).getText();

        int SpaceCount =0;
        for (int i = 0; i < BuyerSoliPhoneNumberAct.length() - 1; i++) {
            if (BuyerSoliPhoneNumberAct.charAt(i) == ' ') {
                SpaceCount++;
            }
        }
        if(SpaceCount>1)
        {
            LogCapture.info("User User able to fetch Buyer solicitor details when Phone Number with multiple Space [ "+BuyerSoliPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Buyer solicitor details when Phone Number with Space multiple is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Seller Details for \"([^\"]*)\" when Phone number with multiple space is present$")
    public void verifyUserAbleToFetchSellerDetailsForWhenPhoneNumberWithMultipleSpaceIsPresent(String arg0) throws Throwable {
        Thread.sleep(3000);
        JsonPath SellersAccountDetail = Constants.APIkey.rawToJson(Constants.SellersAccountDetails);
        String vobjBuyerEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerEmailAddress, SellersAccountDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Seller's Email ["+SellersAccountDetail.get("data.searchContact[0].email")+"] on Buyer details page");

        String vobjBuyerFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerFullName, SellersAccountDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Seller's Full Name ["+SellersAccountDetail.get("data.searchContact[0].name")+"] on Buyer details page");

        String vobjBuyerCDAccountNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerCDAccountNumber");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerCDAccountNumber, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerCDAccountNumber, SellersAccountDetail.get("data.searchContact[0].titanCustomerNo")));
        LogCapture.info("User verified Seller's Titan Customer No ["+SellersAccountDetail.get("data.searchContact[0].titanCustomerNo")+"] on Buyer details page");

        String vobjBuyerPhoneNumber = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerPhoneNumber)).getText();

        int SpaceCount =0;
        for (int i = 0; i < BuyerPhoneNumberAct.length() - 1; i++) {
            if (BuyerPhoneNumberAct.charAt(i) == ' ') {
                SpaceCount++;
            }
        }
        if(SpaceCount>1)
        {
            LogCapture.info("User User able to fetch Seller's details when Phone Number with multiple Space [ "+BuyerPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Seller's details when Phone Number with Space multiple is present");
            Assert.fail();
        }

    }

    @Then("^Verify User able to fetch Seller Solicitor Details for \"([^\"]*)\" when Phone number with multiple space is present$")
    public void verifyUserAbleToFetchSellerSolicitorDetailsForWhenPhoneNumberWithMultipleSpaceIsPresent(String arg0) throws Throwable {

        Thread.sleep(3000);
        JsonPath SellerSolicitorDetail = Constants.APIkey.rawToJson(Constants.SellerSolicitorDetails);
        String vobjBuyerSoliEmailAddress = Constants.PropertyPayDashboardOR.getProperty("BuyerEmailAddress");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliEmailAddress, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliEmailAddress, SellerSolicitorDetail.get("data.searchContact[0].email")));
        LogCapture.info("User verified Seller solicitor's email ["+SellerSolicitorDetail.get("data.searchContact[0].email")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliFullName = Constants.PropertyPayDashboardOR.getProperty("BuyerFullName");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjBuyerSoliFullName, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjBuyerSoliFullName, SellerSolicitorDetail.get("data.searchContact[0].name")));
        LogCapture.info("User verified Seller solicitor's Full name ["+SellerSolicitorDetail.get("data.searchContact[0].name")+"] on Buyer Solicitor details page");

        String vobjBuyerSoliPhoneNo = Constants.PropertyPayDashboardOR.getProperty("BuyerPhoneNumber");
        String BuyerSoliPhoneNumberAct = Constants.driver.findElement(By.xpath(vobjBuyerSoliPhoneNo)).getText();

        int SpaceCount =0;
        for (int i = 0; i < BuyerSoliPhoneNumberAct.length() - 1; i++) {
            if (BuyerSoliPhoneNumberAct.charAt(i) == ' ') {
                SpaceCount++;
            }
        }
        if(SpaceCount>1)
        {
            LogCapture.info("User User able to fetch Seller solicitor details when Phone Number with multiple Space [ "+BuyerSoliPhoneNumberAct+" ] is present");
        }else {
            LogCapture.info("User User unable to fetch Seller solicitor details when Phone Number with Space multiple is present");
            Assert.fail();
        }

    }

    @Then("^Verify User unable to fetch Buyer Details for \"([^\"]*)\" when Phone number present without Space and without hyphen$")
    public void verifyUserUnableToFetchBuyerDetailsForWhenPhoneNumberPresentWithoutSpaceAndWithoutHyphen(String arg0) throws Throwable {

        String vobjPhoneNumberErrorMessage = Constants.PropertyPayDashboardOR.getProperty("PhoneNumberErrorMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPhoneNumberErrorMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPhoneNumberErrorMessage, "Please ensure that the phone number is updated in the following format: Country code followed by a hyphen and the Mobile Number (e.g., +91-XXXXXXXX10)."));
        String PhoneNumberErrorMessage = Constants.driver.findElement(By.xpath(vobjPhoneNumberErrorMessage)).getText();
        LogCapture.info("User verified Error message for Invalid Phone Number ["+PhoneNumberErrorMessage+"] is visible");

    }

    @Then("^Verify User unable to fetch Buyer Solicitor Details for \"([^\"]*)\" when Phone number present without Space and without hyphen$")
    public void verifyUserUnableToFetchBuyerSolicitorDetailsForWhenPhoneNumberPresentWithoutSpaceAndWithoutHyphen(String arg0) throws Throwable {

        String vobjPhoneNumberErrorMessage = Constants.PropertyPayDashboardOR.getProperty("PhoneNumberErrorMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPhoneNumberErrorMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPhoneNumberErrorMessage, "Please ensure that the phone number is updated in the following format: Country code followed by a hyphen and the Mobile Number (e.g., +91-XXXXXXXX10)."));
        String PhoneNumberErrorMessage = Constants.driver.findElement(By.xpath(vobjPhoneNumberErrorMessage)).getText();
        LogCapture.info("User verified Error message for Invalid Phone Number ["+PhoneNumberErrorMessage+"] is visible");


    }

    @Then("^Verify User unable to fetch Seller Details for \"([^\"]*)\" when Phone number present without Space and without hyphen$")
    public void verifyUserUnableToFetchSellerDetailsForWhenPhoneNumberPresentWithoutSpaceAndWithoutHyphen(String arg0) throws Throwable {

        String vobjPhoneNumberErrorMessage = Constants.PropertyPayDashboardOR.getProperty("PhoneNumberErrorMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPhoneNumberErrorMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPhoneNumberErrorMessage, "Please ensure that the phone number is updated in the following format: Country code followed by a hyphen and the Mobile Number (e.g., +91-XXXXXXXX10)."));
        String PhoneNumberErrorMessage = Constants.driver.findElement(By.xpath(vobjPhoneNumberErrorMessage)).getText();
        LogCapture.info("User verified Error message for Invalid Phone Number ["+PhoneNumberErrorMessage+"] is visible");
    }

    @Then("^Verify User unable to fetch Seller Solicitor Details for \"([^\"]*)\" when Phone number present without Space and without hyphen$")
    public void verifyUserUnableToFetchSellerSolicitorDetailsForWhenPhoneNumberPresentWithoutSpaceAndWithoutHyphen(String arg0) throws Throwable {

        String vobjPhoneNumberErrorMessage = Constants.PropertyPayDashboardOR.getProperty("PhoneNumberErrorMessage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjPhoneNumberErrorMessage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vobjPhoneNumberErrorMessage, "Please ensure that the phone number is updated in the following format: Country code followed by a hyphen and the Mobile Number (e.g., +91-XXXXXXXX10)."));
        String PhoneNumberErrorMessage = Constants.driver.findElement(By.xpath(vobjPhoneNumberErrorMessage)).getText();
        LogCapture.info("User verified Error message for Invalid Phone Number ["+PhoneNumberErrorMessage+"] is visible");
    }


//    @And("^user verify pdf txt from file \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void userVerifyPdfTxtFromFileAnd(String file, String arg1, String arg2) throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        String vobjPhoneNumberErrorMessage = Constants.NotaryDashboardOR.getProperty("PhoneNumberErrorMessage");
//
////        Constants.key.PdfToText("", "");
//
//
//
////                        String change1= String.valueOf(finaldisAmount);
////                        String change2=BuyerBen1;
//        String change1="551";
//        String change2="SaurabhBuyer  1quuqj";
//                Constants.key.compare(file, change1,change2);
//
//
//
////       Constants.key.VerifyAndReplacetxt("", "");
////        Constants.key.verifyPdfText("", "");
////        PDFCheck VerifyPdfText
//    }
//
    @And("^User Execute test case for (pdf verification|) with language ck \"([^\"]*)\"$")
    public void userExecuteTestCaseForPdfVerificationWithLanguageCk(String download,String language) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Pdfdownload= download;
        languageverification =language;


    }

    @And("^user download all pdf$")
    public void userDownloadAllPdf() {

        // Find all elements that match the given XPath
        List<WebElement> svgElements = driver.findElements(By.xpath("//div[@class='MuiAccordionDetails-root css-u7qq7e']//*[name()='svg']"));

        // Loop through the list and click each element
        for (WebElement svgElement : svgElements) {
            svgElement.click();
        }
    }


    @Then("^User select (email|email for 1) and verify account name for\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"\"([^\"]*)\"$")
    public void userSelectEmailAndVerifyAccountNameFor(String noofmail,String email1, String name1,String email2, String name2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //p[text()='pfx_cdeu_sit@redpinteam.testinator.com']/parent::div/parent::div//div//label
        //p[text()='pfx_cdeu_sit@redpinteam.testinator.com']/parent::div/parent::div//div[3]
        if(noofmail.equalsIgnoreCase("noofmail") && email1.equalsIgnoreCase("")){

        }
        else if(noofmail.equalsIgnoreCase("noofmail") && email1.equalsIgnoreCase("")){

        }
        else if(noofmail.equalsIgnoreCase("noofmail") && email1.equalsIgnoreCase("")){

        }
        else if(noofmail.equalsIgnoreCase("noofmail") && email1.equalsIgnoreCase("")){

        }

        String vobjemail1 = "//*[text()='"+email1+"']/parent::div/parent::div//div//input[@type='checkbox']";
        String vobjname1 = "//*[text()='"+email1+"']/parent::div/parent::div//p[text()='"+name1+"']";



//        String vobjemail1 = "//div[@class='MuiBox-root css-4cae0p']//div[2]//div[1]//label[1]//span[1]//input[1]";
//        String vobjname1 = "//div[3]//div[1]//label[1]//span[1]//input[1]";

        String vobjemail2 = "//*[text()='"+email2+"']/parent::div/parent::div//div//input[@type='checkbox']";
        String vobjname2 = "//*[text()='"+email2+"']/parent::div/parent::div//p[text()='"+name2+"']";
        String vobjcon = "//p[normalize-space()='Continue']";
        LogCapture.info(vobjemail2);
        LogCapture.info(vobjname2);
        key.pause("3", "");
        if(noofmail.equalsIgnoreCase("email for 1")){
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjname1, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjemail1, ""));
        }
        else{
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjname1, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjemail1, ""));
            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vobjemail2, ""));
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjname2, ""));
            key.pause("3", "");

        }


        Assert.assertEquals("PASS", Constants.key.navigateSubMenu( vobjcon, ""));

//        Assert.assertEquals("PASS", Constants.key.Mouse_Events(vobjemail2, ""));

    }

    @And("^user click on find button$")
    public void userClickOnFindButton() throws Exception {
        String vobjname2 = "//p[@type='button-large']";
//        LogCapture.info(vobjemail1);
//        LogCapture.info(vobjname1);
//        key.pause("3", "");
//        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vobjname1, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu( vobjname2, ""));

    }

    @Then("^User Select  signatory user or lawyer \"([^\"]*)\"$")
    public void userSelectSignatoryUserOrLawyer(String signatory) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // Write code here that turns the phrase above into concrete actions
//        if(){
//            String vObjdetail = "//span[normalize-space()='" + signatory + "']";
//            LogCapture.info("Verifying" + signatory);
//            Constants.key.pause("3", "");
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
//            Constants.key.pause("2", "");
//        }
//        else if()
//        {
//            String vObjdetail = "//span[normalize-space()='" + signatory + "']";
//            LogCapture.info("Verifying" + signatory);
//            Constants.key.pause("2", "");
//            String vObjdetail2 = "//span[normalize-space()='" + signatory + "']";
//            LogCapture.info("Verifying" + signatory);
//            Constants.key.pause("2", "");
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
//            Constants.key.pause("2", "");
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail2, ""));
//        }
//        else if()
//        {
//            String vObjdetail = "//span[normalize-space()='" + signatory + "']";
//            LogCapture.info("Verifying" + signatory);
//            Constants.key.pause("3", "");
//            Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjdetail, ""));
//            Constants.key.pause("2", "");
//        }
//

    }

//    @And("^User selects language \"([^\"]*)\"$")
//    public void userSelectsLanguage(String arg0) throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
//    }

}



