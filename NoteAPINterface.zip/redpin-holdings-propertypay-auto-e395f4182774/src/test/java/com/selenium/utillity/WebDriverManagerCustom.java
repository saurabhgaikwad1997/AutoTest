package com.selenium.utillity;

import org.openqa.selenium.WebDriver;

public abstract class WebDriverManagerCustom {
    public abstract WebDriver getDriver(String object);
    public abstract void setupDriver(String object);
}

