package com.cucumber.stepdefinition;


import com.selenium.utillity.Constants;
import com.service.utillity.ReusableMethod;
import com.service.utillity.ServiceMethod;
import com.utility.LogCapture;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import freemarker.template.SimpleDate;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.velocity.runtime.directive.Break;
import org.openqa.selenium.By;
import org.testng.Assert;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import static com.selenium.utillity.Constants.*;

public class TitanCardAPIStepDefination {
    String ExpNumberOfTransactions;
    String ExpCardSpendTxnAmount;
    Float CardBilling_Amount;

    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for (Enterprise|Titan)$")
    public void forACallUserCheckStatusCodeAsForOnEnvironment(String methodType, String statCode, String testCaseID, String enviroment, String App) throws Throwable {
        //Constants.APIkey.checkNotEnabled(testCaseID);
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME=enviroment;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate errorCode \"([^\"]*)\" errorDescription \"([^\"]*)\" and fileUploadStatus as \"([^\"]*)\"$")
    public void userValidateErrorCodeErrorDescriptionAndFileUploadStatusAs(String errorCode, String errorDescription, String fileUploadStatus) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(errorCode, jp.get("errorCode")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(errorDescription, jp.get("errorDescription")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(fileUploadStatus, jp.get("fileUploadStatus")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Capture (Document ID) \"([^\"]*)\" form Response and update in OnTheyFly property$")
    public void userCaptureDocumentIDFormResponseAndUpdateInOnTheyFlyProperty(String arg, String property) throws Throwable {
        // This will get the value of Specified Properties from Constants.RESPONSE and update the same in dynamicConfig.properties and HashMap so that we can use this in later execution
        ReusableMethod.UpdateSpecificProperties(property);
    }

    @And("^From \"([^\"]*)\" User get (Document Name) \"([^\"]*)\" for API Body$")
    public void fromUserGetDocumentNameForAPIBody(String testCaseID, String arg1, String key) throws Throwable {
        Constants.apiBodyValue = ReusableMethod.getSpecificProperties(testCaseID, key);
    }

    @Given("^User \"([^\"]*)\" from API \"([^\"]*)\" call for \"([^\"]*)\" and observed status code as \"([^\"]*)\"$")
    public void userFromAPICallForAndObservedStatusCodeAs(String actionType, String methodType, String testCaseID, String statCode) throws Throwable {
        Constants.TCCaseID = testCaseID;
        LogCapture.info("----------------Started API calls for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        } else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User Validate Description \"([^\"]*)\" and Code \"([^\"]*)\" and api response status \"([^\"]*)\"$")
    public void userValidateDescriptionAndCodeAndApiResponseStatus(String code, String description, String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("api_status.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("api_status.description")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("api_response.status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Description \"([^\"]*)\" and Code \"([^\"]*)\"$")
    public void userValidateDescriptionAndCode(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("api_status.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("api_status.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User validate \"([^\"]*)\"$")
    public void userValidate(String comment) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(comment, jp.get("api_response.comment")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User validate recommended BIC field \"([^\"]*)\"$")
    public void userValidateRecommendedBICField(String recBIC) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(recBIC, jp.get("api_response.recommendedBIC")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }


    @Then("^User validate status \"([^\"]*)\"$")
    public void userValidateStatus(String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validates response_code \"([^\"]*)\" and response_status \"([^\"]*)\"$")
    public void userValidatesResponse_codeAndResponse_status(String response_code, String response_status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_status, jp.get("response_status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^user validate the city \"([^\"]*)\" and country \"([^\"]*)\"$")
    public void userValidateTheCityAndCountry(String city, String country) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(city, jp.get("ipCity")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(country, jp.get("ipCountry")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate city \"([^\"]*)\"$")
    public void userValidateCity(String city) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(city, jp.get("city")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate status \"([^\"]*)\" and code \"([^\"]*)\"$")
    public void userValidateStatusAndCode(String status, String code) throws Throwable {
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\"$")
    public void userValidateResponseCodeAndResponseDescription(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response_description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validates response_code \"([^\"]*)\"$")
    public void userValidatesResponse_code(String response_code) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response_code")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate errorCode \"([^\"]*)\" errorDescription \"([^\"]*)\"$")
    public void userValidateErrorCodeErrorDescription(String errorCode, String errorDescription) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(errorCode, jp.get("errorCode")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(errorDescription, jp.get("errorDescription")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate status_code \"([^\"]*)\" status_description \"([^\"]*)\"$")
    public void userValidateStatus_codeStatus_description(String status_code, String status_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(status_code, jp.get("status_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(status_description, jp.get("status_description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\"$")
    public void userValidateCodeAndDescription(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, jp.get("description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the soap service$")
    public void userValidateCodeAndDescriptionForTheSoapService(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.result.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.result.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the soap service for fee management$")
    public void userValidateCodeAndDescriptionForTheSoapServiceForFeeManagement(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getPaymentFeesResponse.PaymentFeeServiceResponse.result.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getPaymentFeesResponse.PaymentFeeServiceResponse.result.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for Apply Financials$")
    public void userValidateCodeAndDescriptionForApplyFinancials(String code, String description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, xml.get("Envelope.Body.getValidateBankDetailsResponse.ResponseStatusHeader.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(description, xml.get("Envelope.Body.getValidateBankDetailsResponse.ResponseStatusHeader.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate status \"([^\"]*)\" for DNB Service$")
    public void userValidateStatusForDNBService(String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("company_detail.status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and status \"([^\"]*)\"$")
    public void userValidateCodeAndStatus(String code, String status) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(status, jp.get("status")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate response code \"([^\"]*)\" and response message \"([^\"]*)\"$")
    public void userValidateResponseCodeAndResponseMessage(String code, String message) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(code, jp.get("response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(message, jp.get("response_message")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate uploaded Document ID from the api response$")
    public void userValidateUploadedDocumentIDFromTheApiResponse() {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        List AllDoc = jp.getList("documentList.document_id");
        String docID = Constants.DynamicValue.get("<document_id>");
        boolean Flag = false;
        for (Object doc : AllDoc) {
            String doc1 = doc.toString();
            if (doc1.equals(docID)) {
                Flag = true;
                break;
            }
        }
        Assert.assertTrue(Flag);

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate code \"([^\"]*)\" and description \"([^\"]*)\" for the cancel quote$")
    public void userValidateCodeAndDescriptionForTheCancelQuote(String response_code, String response_description) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("resp_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("resp_desc")));
        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for the cancel quote$")
    public void userValidateResponseCodeAndResponseDescriptionForTheCancelQuote(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("fx_deal.response_code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("fx_deal.response_description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }


    @Then("^User check Quote id and store Quote id$")
    public void userCheckQuoteIdAndStoreQuoteId() {
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        ReusableMethod.updateConfig("<quote_id>", jp.get("create_quote.quote_id"));
    }

    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for subscribe rate alert$")
    public void userValidateResponseCodeAndResponseDescriptionForSubscribeRateAlert(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        ReusableMethod.updateConfig("<subscription_id>", Integer.toString(jp.get("subscription_details.subscription_id")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User validate response code \"([^\"]*)\" and response description \"([^\"]*)\" for Get Subscription rate alert$")
    public void userValidateResponseCodeAndResponseDescriptionForGetSubscriptionRateAlert(String response_code, String response_description) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_code, jp.get("response.code")));
        Assert.assertEquals("PASS", ReusableMethod.compareString(response_description, jp.get("response.description")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User verify latest quote rate$")
    public void userVerifyLatestQuoteRate() {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Assert.assertEquals("PASS", ReusableMethod.compareString(jp.get("latest_quote.quote_rate"), jp.get("latest_quote.quote_rate")));
        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User Verify \"([^\"]*)\" from responce body$")
    public void userVerifyFromResponceBody(String liveRate) throws Throwable {
        LogCapture.info("----------------Response Validations Live Rate Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        String res = xml.get("Envelope.Body.getFXDealRateOrgResponse.FXDealRate.debug");
        res = res.split(",")[0].split(":")[1];
        Assert.assertEquals(true, res.startsWith(liveRate));
        LogCapture.info("----------------Response Validations Live Rate Ended-------------------");
    }

    @When("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Currency Pair \"([^\"]*)\"$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForCurrencyPair(String methodType, String statCode, String testCaseID, String enviroment, String App) throws Throwable {
        Constants.TCCaseID = testCaseID;
        LogCapture.info("----------------Started API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            if (Constants.DynamicValue.containsKey("CurrencyPair")) {
                Constants.DynamicValue.replace("CurrencyPair", Constants.DynamicValue.get("CurrencyPair"), App);
            }
            else {
                Constants.DynamicValue.put("CurrencyPair",App);
            }
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            LogCapture.info("---------------POST call ended----------------");
        }
        LogCapture.info("----------------Ended API calls in " + enviroment + " Environment for testcase ID " + testCaseID + "---------------------");

    }

    @Then("^User validate Quote \"([^\"]*)\" from response body$")
    public void userValidateQuoteFromResponseBody(String qutRate) throws Throwable {
        LogCapture.info("----------------Response Validations Live Rate Started-------------------");
        XmlPath xml = Constants.APIkey.rawToXml(Constants.RESPONSE);
        String res = xml.get("Envelope.Body.getRateSingularResponse.return");
        JsonPath jp=Constants.APIkey.rawToJson(res);
        res = jp.get("Result.Quote");
        Assert.assertEquals(true, res.startsWith(qutRate));
        LogCapture.info("----------------Response Validations Live Rate Ended-------------------");
    }




    @Given("^User Generate Token from API \"([^\"]*)\" call for \"([^\"]*)\" on \"([^\"]*)\" and observed status code as \"([^\"]*)\"$")
    public void userGenerateTokenFromAPICallForOnAndObservedStatusCodeAs(String methodType, String testCaseID, String Environment, String statCode) throws Throwable {
        Constants.TCCaseID = testCaseID;
        LogCapture.info("----------------Started API calls for testcase ID " + testCaseID + "---------------------");
        if (methodType.equalsIgnoreCase("Post")) {
            LogCapture.info("---------------POST call started----------------");
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------POST call ended----------------");
        }else if (methodType.equalsIgnoreCase("Get")) {
            LogCapture.info("---------------GET call started----------------");
            Constants.RESPONSE = ServiceMethod.getAdvance(testCaseID, statCode, Constants.DynamicValue);
            JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
            LogCapture.info("---------------GET call started----------------");
        }
        LogCapture.info("----------------Ended API calls for testcase ID " + testCaseID + "---------------------");

    }



    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" and \"([^\"]*)\" for get balance API$")
    public void userValidateStatusDescriptionAndStatusCodeAndForGetBalanceAPI(String ResponseDescription, String ResponseCode, String CCY) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String RespActBal = Float.toString(jp.get("actualBalance"));
        String RespAvailBal = Float.toString(jp.get("availableBalance"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(jp.get("currency"),CCY));
        LogCapture.info("-------------User verified Currency as >> "+jp.get("currency"));

        LogCapture.info("-------------Able to see Actual balance >> "+RespActBal);
        LogCapture.info("-------------Able to see Available balance >> "+RespAvailBal);

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" (for unsupported currency|when date is missing)$")
    public void userValidateStatusDescriptionAndStatusCodeForUnsupportedCurrency(String ResponseDescription, String ResponseCode, String MissingField) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for invalid (customer reference|contact ID)$")
    public void userValidateStatusDescriptionAndStatusCodeForInvalidCustomerReference(String ResponseDescription, String ResponseCode, String InvalidField) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when base currency is missing$")
    public void userValidateStatusDescriptionAndStatusCodeWhenBaseCurrencyIsMissing(String ResponseDescription, String ResponseCode) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\"$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmount(String ResponseCode, String ResponseDescription, String BLKCCY, String BLKAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(BLKCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(BLKAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,Amount));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (customer reference number|fee currency|PaymentLifeCycleID field|Wallet currency|Base Currency) is missing$")
    public void userValidateStatusDescriptionAndStatusCodeWhenCustomerReferenceNumberIsMissing(String ResponseDescription, String ResponseCode,String MissingField) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when amount to (block|Credit|Debit) is missing$")
    public void userValidateStatusDescriptionAndStatusCodeWhenAmountToBlockIsMissing(String ResponseDescription, String ResponseCode,String AmtType) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (amountToBlock|amountToCredit|amountToDebit) currency is null$")
    public void userValidateStatusDescriptionAndStatusCodeWhenAmountToBlockCurrencyIsNull(String ResponseDescription, String ResponseCode, String AmtType) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when (base currency|decline code|decline reason|Contact ID) field is null$")
    public void userValidateStatusDescriptionAndStatusCodeWhenBaseCurrencyFieldIsNull(String ResponseDescription, String ResponseCode,String Fieldtype) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" and Unblocked amount \"([^\"]*)\"$")
    public void userValidateThenVerifyUnblockedAmountCurrencyAndUnblockedAmount(String ResponseCode, String ResponseDescription, String BLKCCY, String BLKAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(BLKCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(BLKAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("unblockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,Amount));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("unblockedAmount.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when PaymentLifeCycleID field is null$")
    public void userValidateStatusDescriptionAndStatusCodeWhenPaymentLifeCycleIDFieldIsNull(String ResponseDescription, String ResponseCode) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" when wallet balance is not present$")
    public void userValidateStatusDescriptionAndStatusCodeWhenWalletBalanceIsNotPresent(String ResponseDescription, String ResponseCode) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" Unblocked amount \"([^\"]*)\" and Debited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyUnblockedAmountCurrencyUnblockedAmountAndDebitedAmount(String ResponseCode, String ResponseDescription, String CKBLKCCY, String CKBLKAmount, String CKBLKDebitedAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);


        String CCY= Constants.OnTheFlyValue.getProperty(CKBLKCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(CKBLKAmount);
        String DebitedAmount= Constants.OnTheFlyValue.getProperty(CKBLKDebitedAmount);


        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified UnblockedAmount Currency as >> "+jp.get("unblockedAmount.amount"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,Amount));
        LogCapture.info("-------------User verified Unblocked amount as >> "+jp.get("unblockedAmount.amount"));

        String DebitedAmt =def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitedAmt,DebitedAmount));
        LogCapture.info("-------------User verified Debited amount as >> "+jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Credited Currency \"([^\"]*)\" and Credited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyAmountCreditedCurrencyAndCreditedAmount(String ResponseCode, String ResponseDescription, String CRDCCY, String CRDAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(CRDCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(CRDAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("amountCredited.currency")));
        LogCapture.info("-------------User verified amount Credited Currency as >> "+jp.get("amountCredited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String CreditedAmt =def.format(jp.get("amountCredited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(CreditedAmt,Amount));
        LogCapture.info("-------------User verified amount Credited as >> "+jp.get("amountCredited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Debited Currency \"([^\"]*)\" and Debited amount \"([^\"]*)\"$")
    public void userValidateThenVerifyAmountDebitedCurrencyAndDebitedAmount(String ResponseCode, String ResponseDescription, String DebitedCCY, String DebitedAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(DebitedCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(DebitedAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified amount Debited Currency as >> "+jp.get("amountDebited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String DebitedAmt =def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitedAmt,Amount));
        LogCapture.info("-------------User verified amount Debited as >> "+jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" (for decline card transaction|For Send money)$")
    public void userValidateForDeclineCardTransaction(String ResponseCode, String ResponseDescription, String data) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify account_number\"([^\"]*)\" Organization \"([^\"]*)\" and PaymentLifeCycleID \"([^\"]*)\" details$")
    public void userValidateThenVerifyAccount_numberOrganizationAndPaymentLifeCycleIDDetails(String ResponseCode, String ResponseDescription, String ActivityTAN, String ActivityOrganization, String ActivityPamentLifeCycleID) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String TAN= Constants.OnTheFlyValue.getProperty(ActivityTAN);
        String Organization= Constants.OnTheFlyValue.getProperty(ActivityOrganization);
        String PamentLifeCycleID= Constants.OnTheFlyValue.getProperty(ActivityPamentLifeCycleID);

        Assert.assertEquals(jp.get("response_code"), ResponseCode);
        LogCapture.info("User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals(jp.get("response_description"),  ResponseDescription);
        LogCapture.info("User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals(jp.get("org_code"),  Organization);
        Assert.assertEquals(jp.get("contract_note_search_criteria.filter.organization[0]"),  Organization);
        LogCapture.info("User verified Organization as >> "+jp.get("org_code"));

        Assert.assertEquals(jp.get("card_activity_history_details[0].cdPaymentLifecycleId"),  PamentLifeCycleID);

        LogCapture.info("User verified Instruction Number as >> "+jp.get("card_activity_history_details[0].instruction_number"));

        Assert.assertEquals(jp.get("account_number"),  TAN);
        LogCapture.info("User verified account number as >> "+jp.get("account_number"));

        LogCapture.info("User verified transaction Date as >> "+jp.get("card_activity_history_details[0].transactionDate"));
        LogCapture.info("User verified merchant Name as >> "+jp.get("card_activity_history_details[0].merchantName"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate Status Description \"([^\"]*)\" and Status Code \"([^\"]*)\" for (invalid organization code|Organization Code is Missing|invalid PaymentlifeCycle ID)$")
    public void userValidateStatusDescriptionAndStatusCodeForInvalidOrganizationCode(String ResponseDescription, String ResponseCode, String OrgCodetype) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }


    @Given("^User Generate Token for Titan Card API Validation from \"([^\"]*)\" for Titan-Card Application$")
    public void userGenerateTokenForTitanCardAPIValidationFromForTitanCardApplication(String tcID) throws Throwable {
        LogCapture.info("--------------Token Generation started for testcase ID " + tcID + "---------------");
        Constants.RESPONSE = ServiceMethod.post(tcID, "200");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        Constants.ACCESS_TOKEN = jp.get("access_token");
        LogCapture.info("--------------Token Generation ended--------------");
        LogCapture.info("--------------Token Generation ended for testcase ID " + tcID + "--------------");
        key.pause("2","");

    }


    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Contact ID \"([^\"]*)\"$")
    public void userValidateThenVerifyContactID(String ResponseCode, String ResponseDescription, String CardOrderContactID) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String ContactID= Constants.OnTheFlyValue.getProperty(CardOrderContactID);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        String ContactId = Integer.toString(jp.get("contact_id"));
        Assert.assertEquals(ContactId,  ContactID);
        LogCapture.info(".............User verified Contact ID as >> "+ContactId);

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Given("^User connects to Titan UAT DB and fetches the Customer (TAN) having zero wallet balance$")
    public void userConnectsToTitanUATDBAndFetchesTheCustomerHavingZeroWalletBalance(String TitanAccountNumber) throws Exception {

        TitanAccountNumber= Constants.APIkey.VerifyDBDetails("UAT", "", "FetchTANWithZeroWalletBalance");
         Constants.APIkey.VerifyDBDetails("UAT", "", "Fetch TitanAccountNumber");
        System.out.println("Titan Account Number having zero wallet balance : " + TitanAccountNumber);
    }


    @Given("^User connects to Titan UAT DB and verify the PtToken ID and PtToken Wallet fields on titan database$")
    public void userConnectsToTitanUATDBAndVerifyThePtTokenIDAndPtTokenWalletFieldsOnTitanDatabase() throws Exception {

        String ActPtTokenID = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyPtTokenID");
        String ExpPtTokenID = Constants.RandomPtTokenID;
        if(ActPtTokenID.equals(ExpPtTokenID))
        {
            LogCapture.info("User verified PtToken ID stored in Titan DB as >> "+ActPtTokenID);
        }else
        {
            LogCapture.info("TC Failed : PtToken ID Not stored in Titan DB >> "+ActPtTokenID);
            Assert.fail();
        }

        String ActPtTokenWallet = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyPtTokenWallet");
        String ExpPtTokenWallet = Constants.OnTheFlyValue.getProperty("<PtTokenWallet1>");
        if(ActPtTokenWallet.equals(ExpPtTokenWallet))
        {
            LogCapture.info("User verified PtToken Wallet stored in Titan DB as >> "+ActPtTokenWallet);
        }else
        {
            LogCapture.info("TC Failed : PtToken Wallet Not stored in Titan DB >> "+ActPtTokenWallet);
            Assert.fail();
        }
    }

    @Then("^User Verify Consolidated Wallet balances for Non Supported Currency on titan DB$")
    public void userVerifyConsolidatedWalletBalancesForNonSupportedCurrencyOnTitanDB() throws Exception {

        String ActConsolidatedWalletBalances = Constants.key.VerifyDBDetails("UAT_Titan", Constants.UniquePaymentLifeCycleId, "VerifyConsolidatedWalletBalances");
        if(!ActConsolidatedWalletBalances.equals(""))
        {
            LogCapture.info("User verified Consolidated Wallet Balances reflected for Non supported Currency on Titan DB  >> "+ActConsolidatedWalletBalances);
        }else
        {
            LogCapture.info("TC Failed : Consolidated Wallet Balances Not reflected for Non supported Currency on Titan DB >> "+ActConsolidatedWalletBalances);
            Assert.fail();
        }
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount newly added multi Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\"$")
    public void userValidateThenVerifyBlockedAmountNewlyAddedMultiCurrencyAndBlockedAmount(String ResponseCode, String ResponseDescription, String MultiCCY, String MultiAmount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String Amount= Constants.OnTheFlyValue.getProperty(MultiAmount);
        String BaseCCY = Constants.OnTheFlyValue.getProperty("<CkAndBlock_CCY>");

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(MultiCCY,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,Amount));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(BaseCCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @And("^User get the card transaction details from details from Titan DB before pushing details to SF for (Check and block|Debit) \"([^\"]*)\"$")
    public void userGetTheCardTransactionDetailsFromDetailsFromTitanDBBeforePushingDetailsToSFFor(String Txntype, String TransactionCurrency) throws Throwable {

        String ActTransactionCurrency = Constants.OnTheFlyValue.getProperty(TransactionCurrency);
        String CheckAndBlockTAN="";
        if(Txntype.equals("Check and block"))
        {
            CheckAndBlockTAN = Constants.OnTheFlyValue.getProperty("<CkAndBlockTAN_Number>");
        } else if (Txntype.equals("Debit")) {
            CheckAndBlockTAN = Constants.OnTheFlyValue.getProperty("<DBT_TAN>");
        }

        if(ActTransactionCurrency.equals("GBP"))
        {
            ExpCardSpendTxnAmount = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCSTransactionsAmount");
            ExpNumberOfTransactions = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCardSpentTxnNumber");
        }else if(ActTransactionCurrency.equals("EUR"))
        {
            ExpCardSpendTxnAmount = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCSTransactionsAmount");
            ExpNumberOfTransactions = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCardSpentTxnNumber");
        }


    }

    @Then("^User Verify card transaction details is send to Salesforce for (Check and Block|Debit) \"([^\"]*)\"$")
    public void userVerifyCardTransactionDetailsIsSendToSalesforceFor(String TxnType , String TransactionCurrency) throws Throwable {

        String CheckAndBlockTAN="";
        String CheckAndBlockAmount="";


        if(TxnType.equals("Check and Block")){
            CheckAndBlockTAN = Constants.OnTheFlyValue.getProperty("<CkAndBlockTAN_Number>");
            CheckAndBlockAmount = Constants.OnTheFlyValue.getProperty("<CkAndBlock_Amount>");

        }else if(TxnType.equals("Debit"))
        {
            CheckAndBlockTAN = Constants.OnTheFlyValue.getProperty("<DBT_TAN>");
            CheckAndBlockAmount = Constants.OnTheFlyValue.getProperty("<DBT_Amount>");

        }
        String ActTransactionCurrency = Constants.OnTheFlyValue.getProperty(TransactionCurrency);

        if(ActTransactionCurrency.equals("GBP"))
        {
            String ActCardSpendTxnAmt = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCSTransactionsAmount");
            float ActCardSpendTxnAmount =Float.parseFloat(ActCardSpendTxnAmt);

            float CardSpendTxnAmtDynamic =Float.parseFloat(CheckAndBlockAmount);
            float ExpCardSpendTxnAmt =Float.parseFloat(ExpCardSpendTxnAmount);
            float CardSpendTxnAmount=  ExpCardSpendTxnAmt+CardSpendTxnAmtDynamic;
            if(ActCardSpendTxnAmount==CardSpendTxnAmount)
            {
                LogCapture.info("---------------User verify transactions amount for GBP CCY is : "+CardSpendTxnAmount+" == "+ActCardSpendTxnAmount+" .......");
            }else {
                LogCapture.info("---------------User verify transactions amount for GBP CCY not equals to : "+CardSpendTxnAmount+" != "+ActCardSpendTxnAmount+" .......");
                Assert.fail();
            }

            String ActNumberOfTransactions = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCardSpentTxnNumber");
            int ExpIntTxnNo =Integer.parseInt(ExpNumberOfTransactions);
            String NoOfTxn = Integer.toString(ExpIntTxnNo+1);
            if(NoOfTxn.equals(ActNumberOfTransactions))
            {
                LogCapture.info("---------------User verify Total number of transactions for GBP CCY is : "+NoOfTxn+" == "+ActNumberOfTransactions+" .......");
            }else {
                LogCapture.info("---------------User verify Total number of transactions for GBP CCY not equals to : "+NoOfTxn+" != "+ActNumberOfTransactions+" .......");
                Assert.fail();
            }


            String ActIsSendToSF = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCardSpentIsSendToSF");
            if(ActIsSendToSF.equals("1"))
            {
                LogCapture.info("---------------User verify Card Spent Transactions Send to SF as : True .......");
            }else {
                LogCapture.info("---------------User verify Card Spent Transactions Send to SF as : False .......");
                Assert.fail();
            }

            TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date date =  new Date();
            String CurrentDateGMT = dateFormat.format(date);

            String ActSendToSFonDate = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetGBPCardSpentSendToSFOn");
            String ExactDateTime = ActSendToSFonDate.substring(0,16);
            if(ExactDateTime.equals(CurrentDateGMT))
            {
                LogCapture.info("---------------User verify Card Spent Transaction details Send to SF on date : "+CurrentDateGMT+" .......");
            }else {
               LogCapture.info("---------------User verify Card Spent Transaction details not Send to SF on : "+CurrentDateGMT+" .......");
                Assert.fail();
            }

            String ActUpdatedOnDate = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GeGBPCardSpentUpdatedOn");
            String ExactCSUpdatedDateTime = ActUpdatedOnDate.substring(0,16);
            if(ExactCSUpdatedDateTime.equals(CurrentDateGMT))
            {
                LogCapture.info("---------------User verify Card Spent Transaction details Updated on date : "+CurrentDateGMT+" .......");
            }else {
                LogCapture.info("---------------User verify Card Spent Transaction details not Updated on Date : "+CurrentDateGMT+" .......");
                Assert.fail();
            }

         }else if(ActTransactionCurrency.equals("EUR"))
        {
            String ActCardSpendTxnAmt = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCSTransactionsAmount");
            float ActCardSpendTxnAmount =Float.parseFloat(ActCardSpendTxnAmt);
            float CardSpendTxnAmtDynamic =Float.parseFloat(CheckAndBlockAmount);

            float ExpCardSpendTxnAmt =Float.parseFloat(ExpCardSpendTxnAmount);
            float CardSpendTxnAmount=  ExpCardSpendTxnAmt+CardSpendTxnAmtDynamic;
            if(ActCardSpendTxnAmount==CardSpendTxnAmount)
            {
                LogCapture.info("---------------User verify transactions amount for EUR CCY is : "+CardSpendTxnAmount+" == "+ActCardSpendTxnAmount+" .......");
            }else {
                LogCapture.info("---------------User verify transactions amount for EUR CCY not equals to : "+CardSpendTxnAmount+" != "+ActCardSpendTxnAmount+" .......");
                Assert.fail();
            }

            String ActNumberOfTransactions = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCardSpentTxnNumber");
            int ExpIntTxnNo =Integer.parseInt(ExpNumberOfTransactions);
            String NoOfTxn = Integer.toString(ExpIntTxnNo+1);
            if(NoOfTxn.equals(ActNumberOfTransactions))
            {
                LogCapture.info("---------------User verify Total number of transactions for EUR CCY is : "+NoOfTxn+" == "+ActNumberOfTransactions+" .......");
            }else {
                LogCapture.info("---------------User verify Total number of transactions for EUR CCY not equals to : "+NoOfTxn+" != "+ActNumberOfTransactions+" .......");
                Assert.fail();
            }


            String ActIsSendToSF = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCardSpentIsSendToSF");
            if(ActIsSendToSF.equals("1"))
            {
                LogCapture.info("---------------User verify Card Spent Transactions Send to SF as : True .......");
            }else {
                LogCapture.info("---------------User verify Card Spent Transactions Send to SF as : False .......");
                Assert.fail();
            }

            TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date date =  new Date();
            String CurrentDateGMT = dateFormat.format(date);

            String ActSendToSFonDate = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GetEURCardSpentSendToSFOn");
            String ExactDateTime = ActSendToSFonDate.substring(0,16);
            if(ExactDateTime.equals(CurrentDateGMT))
            {
                LogCapture.info("---------------User verify Card Spent Transaction details Send to SF on date : "+CurrentDateGMT+" .......");
            }else {
                LogCapture.info("---------------User verify Card Spent Transaction details not Send to SF on : "+CurrentDateGMT+" .......");
                Assert.fail();
            }

            String ActUpdatedOnDate = Constants.key.VerifyDBDetails("UAT_Titan", CheckAndBlockTAN, "GeEURCardSpentUpdatedOn");
            String ExactCSUpdatedDateTime = ActUpdatedOnDate.substring(0,16);
            if(ExactCSUpdatedDateTime.equals(CurrentDateGMT))
            {
                LogCapture.info("---------------User verify Card Spent Transaction details Updated on date : "+CurrentDateGMT+" .......");
            }else {
                LogCapture.info("---------------User verify Card Spent Transaction details not Updated on Date : "+CurrentDateGMT+" .......");
                Assert.fail();
            }

        }

    }


    @Then("^User verify ATM Fee and Crossborder Fee visible under payment Out activity tab for (CheckAndBlock|Block|Debit)$")
    public void userVerifyATMFeeAndCrossborderFeeVisibleUnderPaymentOutActivityTabForChekAndBlock(String TxnType) throws Exception {


        String vObjPaymentOutActivityTab = Constants.TitanCustomersOR.getProperty("PaymentOutActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentOutActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutActivityTab, ""));
        LogCapture.info("User clicked on payment Out activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for(int i =1; i<=50; i++)
        {
            String vBojPaymentOutReference = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[4]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutReference, ""));
            String PaymentOutReference = Constants.driver.findElement(By.xpath(vBojPaymentOutReference)).getText();
            if(PaymentOutReference.equals(Constants.UniquePaymentLifeCycleId))
            {
                LogCapture.info("Able to find PaymentlifeCycleId as "+PaymentOutReference+" on payment out activity tab.......");

                String vBojPaymentOutCardFees = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[16]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCardFees, ""));
                String PaymentOutCardFees = Constants.driver.findElement(By.xpath(vBojPaymentOutCardFees)).getText();

                String FeeCCY = "";

                if(TxnType.equals("CheckAndBlock"))
                {
                    FeeCCY = Constants.OnTheFlyValue.getProperty("<CkAndBlock_CCY>");
                }else if(TxnType.equals("Block"))
                {
                    FeeCCY = Constants.OnTheFlyValue.getProperty("<Block_CCY>");
                }else if(TxnType.equals("Debit"))
                {
                    FeeCCY = Constants.OnTheFlyValue.getProperty("<DBT_CCY>");
                }


                String ATM_Fees = PaymentOutCardFees.substring(0,12);
                String ActualATMFeesAmount = Constants.OnTheFlyValue.getProperty("<ATMFees>");
                String ExpATMFee = "ATM-"+ActualATMFeesAmount+"-"+FeeCCY;
                if(ATM_Fees.equals(ExpATMFee))
                {
                    LogCapture.info("User verify ATM Fee ="+ATM_Fees+" is visible on paymemt out tab.....");
                }else {
                    LogCapture.info("TC Failed : User Unable to verify Actual ="+ATM_Fees+" and Expected "+ExpATMFee+" on payment out tab.....");
                    Assert.fail();
                }

                String Crossborder_Fees = PaymentOutCardFees.substring(14,26);
                String ActualCrossborderFeeAmount = Constants.OnTheFlyValue.getProperty("<CrossborderFees>");
                String ExpCBFee = "CBF-"+ActualCrossborderFeeAmount+"-"+FeeCCY;

                if(Crossborder_Fees.equals(ExpCBFee))
                {
                    LogCapture.info("User verify Crossborder Fee ="+Crossborder_Fees+" is visible on payment out tab.....");
                }else {
                    LogCapture.info("TC Failed : User Unable to verify Actual ="+ATM_Fees+" and Expected "+ExpCBFee+" on payment out tab.....");
                    Assert.fail();
                }
                break;

            }
            if (i==40)
            {
                LogCapture.info("Unable to find PaymentlifeCycleId in under payment out activity tab.......");
                Assert.fail();
            }
        }

    }

    @When("^User select Reversal Currency as \"([^\"]*)\" Reversal amount \"([^\"]*)\" and Reusable PaymentLifeCycle ID$")
    public void userSelectReversalCurrencyAsReversalAmountAndReusablePaymentLifeCycleID(String ReversalCurrency, String ReversalAmount) throws Throwable {

        DynamicValue.put("<Rev_Currency>", ReversalCurrency);
        LogCapture.info("-------------Reversal Currency is ["+ReversalCurrency+"]");
        DynamicValue.put("<RevCCY_Amount>", ReversalAmount);
        LogCapture.info("-------------Reversal amount is ["+ReversalAmount+"]");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.ReusablePaymentLifeCycleId = "AUTO-"+CurrentDateyyyymmdd+"-RAFALE"+CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<ReusableUniquePaymentLifeID>", Constants.ReusablePaymentLifeCycleId);
        LogCapture.info("-------------Generated Payment Life Cycle ID for reusable is ["+Constants.ReusablePaymentLifeCycleId+"]");

    }

    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\" for Reversal$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmountForReversal(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ReversalCurrency,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,ReversalAmount));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" and Unblocked amount \"([^\"]*)\" for reversal$")
    public void userValidateThenVerifyUnblockedAmountCurrencyAndUnblockedAmountForReversal(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ReversalCurrency,jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("unblockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,ReversalAmount));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("unblockedAmount.amount"));

        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }


    @And("^User search for Instruction number using Reusable PaymentLifeCycleId and validate FXStatus \"([^\"]*)\"$")
    public void userSearchForInstructionNumberUsingReusablePaymentLifeCycleIdAndValidateFXStatus(String Status) throws Throwable {
        String vObjInstructionNumberSearch = Constants.TitanInstructionsOR.getProperty("InstructionNumberSearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionNumberSearch, ReusablePaymentLifeCycleId));

        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionNumberSearch, "enter"));
        LogCapture.info("User Searching PaymentLifeCycleID: " + Constants.ReusablePaymentLifeCycleId);
        Constants.key.pause("4","");

        String vObjCloseFilterInstPage = CreateFxTicketOR.getProperty("CloseFilterInstPage");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjCloseFilterInstPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCloseFilterInstPage, ""));

        String vObjPaymentLifeCycleIdHeader = Constants.CreateFxTicketOR.getProperty("PaymentLifeCycleIdHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentLifeCycleIdHeader, ""));
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentLifeCycleIdHeader, ""));
        String ActualPaymentLifeId = Constants.driver.findElement(By.xpath(vObjPaymentLifeCycleIdHeader)).getText();
        LogCapture.info("Captured Payment life cycle id : " + ActualPaymentLifeId);

        String vObjFXStatusonInstruction = Constants.CreateFxTicketOR.getProperty("FXStatusHeader");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjFXStatusonInstruction, ""));
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjFXStatusonInstruction, ""));
        String FXStatus = Constants.driver.findElement(By.xpath(vObjFXStatusonInstruction)).getText();
        LogCapture.info("User verified FX Status as : " + FXStatus);
        if(FXStatus.equals(Status))
        {
            LogCapture.info("User verified FX Status as : " + FXStatus);
        }
        else
        {
            LogCapture.info("User verified FX Status is not REVERSAL != : " + FXStatus);
            Assert.fail();
        }

        String vObjInstructionNumberHeader = Constants.CreateFxTicketOR.getProperty("InstructionNumberHeader");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjInstructionNumberHeader, ""));
        Constants.InstructionNumber = Constants.driver.findElement(By.xpath(vObjInstructionNumberHeader)).getText();
        LogCapture.info("Captured Instruction Number is: " + Constants.InstructionNumber);

        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberHeader, ""));
        LogCapture.info("User clicked on Instruction number on instruction page .....");

        String vObjAmountHeaderOnInstructionPage = Constants.CreateFxTicketOR.getProperty("AmountHeaderOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountHeaderOnInstructionPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAmountHeaderOnInstructionPage, "Amount"));

        String vObjAmountOnInstructionPage = Constants.CreateFxTicketOR.getProperty("AmountOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountOnInstructionPage, ""));
        String ActualAmountOnInstructionPage = Constants.driver.findElement(By.xpath(vObjAmountOnInstructionPage)).getText();

        if(!ActualAmountOnInstructionPage.equals(""))
        {
            LogCapture.info("Able to see Actual Amount on Instruction page: " + ActualAmountOnInstructionPage);

        }else {
            LogCapture.info("TC Failed : Unable to see Actual Amount on Instruction Number.......");
            Assert.fail();
        }


        String vObjCurrencyHeaderOnInstructionPage = Constants.CreateFxTicketOR.getProperty("CurrencyHeaderOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyHeaderOnInstructionPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCurrencyHeaderOnInstructionPage, "Currency"));

        String vObjCurrencyOnInstructionPage = Constants.CreateFxTicketOR.getProperty("CurrencyOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyOnInstructionPage, ""));
        String ActualCurrencyOnInstruction = Constants.driver.findElement(By.xpath(vObjCurrencyOnInstructionPage)).getText();

        if(!ActualCurrencyOnInstruction.equals(""))
        {
            LogCapture.info("Able to see Actual Currency on Instruction page: " + ActualCurrencyOnInstruction);

        }else {
            LogCapture.info("TC Failed : Unable to see Actual Currency on Instruction Number.......");
            Assert.fail();
        }


        Constants.key.pause("1", "");
        String vObjInstructionPageClientNumber = Constants.CreateFxTicketOR.getProperty("InstructionPageClientNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionPageClientNumber, ""));
        LogCapture.info("User clicked on client number on instruction page .....");

    }

    @Then("^User verify payment out status as FXStatus \"([^\"]*)\" on payment Out activity tab for reversal$")
    public void userVerifyPaymentOutStatusAsFXStatusOnPaymentOutActivityTabForReversal(String Status) throws Throwable {

        String vObjPaymentOutActivityTab = Constants.TitanCustomersOR.getProperty("PaymentOutActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentOutActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutActivityTab, ""));
        LogCapture.info("User clicked on payment Out activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for(int i =1; i<=50; i++)
        {
            String vBojPaymentOutReference = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[4]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutReference, ""));
            String PaymentOutReference = Constants.driver.findElement(By.xpath(vBojPaymentOutReference)).getText();
            if(PaymentOutReference.equals(Constants.ReusablePaymentLifeCycleId))
            {
                LogCapture.info("Able to find PaymentlifeCycleId as "+PaymentOutReference+" on payment out activity tab.......");

                String vBojPaymentOutStatus = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[11]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutStatus, ""));
                String PaymentOutStatus = Constants.driver.findElement(By.xpath(vBojPaymentOutStatus)).getText();

                if(PaymentOutStatus.equals(Status))
                {
                    LogCapture.info("User payment out status as = "+PaymentOutStatus+" is visible on payment out tab.....");
                }else {
                    LogCapture.info("TC Failed : User Unable to verify Actual payment out status ="+PaymentOutStatus+" and Expected "+Status+" is not matching on payment out tab.....");
                    Assert.fail();
                }
                break;

            }
            if(i==40)
            {
                LogCapture.info("TC Failed : Unable to find Payment life Cycle Id under payment out activity tab.......");
                Assert.fail();
            }
        }

    }

    @Then("^User connect to titan UAT database to verify Fx status in FX Ticket and CustomerInstruction table$")
    public void userConnectToTitanUATDatabaseToVerifyFxStatusInFXTicketAndCustomerInstructionTable() throws Exception {

        String ActPtTokenID = Constants.key.VerifyDBDetails("UAT_Titan", ReusablePaymentLifeCycleId, "VerifyStatusOnFXTicket");
        String ExpPtTokenID = Constants.RandomPtTokenID;
        if(ActPtTokenID.equals(ExpPtTokenID))
        {
            LogCapture.info("User verified PtToken ID stored in Titan DB as >> "+ActPtTokenID);
        }else
        {
            LogCapture.info("TC Failed : PtToken ID Not stored in Titan DB >> "+ActPtTokenID);
            Assert.fail();
        }
    }

    @Then("^User connect to titan UAT database to verify Fx status as \"([^\"]*)\" in FX Ticket and \"([^\"]*)\" in CustomerInstruction table$")
    public void userConnectToTitanUATDatabaseToVerifyFxStatusAsInFXTicketAndInCustomerInstructionTable(String FXTicketStatus, String CustInstStatus) throws Throwable {

        String StatusEnumFXTicket = Constants.key.VerifyDBDetails("UAT_Titan", ReusablePaymentLifeCycleId, "VerifyStatusOnFXTicket");
        String ActFXStatus = Constants.key.VerifyDBDetails("UAT_Titan", StatusEnumFXTicket, "VerifyStatusEnum");
        if(ActFXStatus.equals(FXTicketStatus))
        {
            LogCapture.info("User verified Status as Closed under FX ticket table on Titan DB >> "+ActFXStatus);
        }else
        {
            LogCapture.info("TC Failed : User unable to verify status as Closed under FX ticket table on Titan DB >> "+FXTicketStatus);
            Assert.fail();
        }

        String StatusEnumCustomerInstruction = Constants.key.VerifyDBDetails("UAT_Titan", ReusablePaymentLifeCycleId, "VerifyStatusOnCustomerInstruction");
        String ActCustomerInstStatus = Constants.key.VerifyDBDetails("UAT_Titan", StatusEnumCustomerInstruction, "VerifyStatusEnum");
        if(ActCustomerInstStatus.equals(CustInstStatus))
        {
            LogCapture.info("User verified Status as REVERSAL under Customer Instruction table on Titan DB >> "+ActFXStatus);
        }else
        {
            LogCapture.info("TC Failed : User unable verify status as REVERSAL Customer Instruction table on Titan DB >> "+ActFXStatus);
            Assert.fail();
        }

    }


    @Then("^User enter Transaction Currency \"([^\"]*)\" Transaction Amount \"([^\"]*)\" ATM Fee \"([^\"]*)\" Cross border Fee \"([^\"]*)\" and generate reusable payment life cycle ID$")
    public void userEnterTransactionCurrencyTransactionAmountATMFeeCrossBorderFeeAndGenerateReusablePaymentLifeCycleID(String TransactionCurrency, Float TransactionAmount, Float ATMFees, Float CrossBorderFee) throws Throwable {

        String RandomDigit = RandomStringUtils.randomNumeric(8);

        DynamicValue.put("<Transaction_Currency>", TransactionCurrency);
        LogCapture.info("Card transaction Currency is ["+TransactionCurrency+"]");

        DynamicValue.put("<Transaction_Amount>", TransactionAmount.toString());
        LogCapture.info("Card transaction amount is ["+TransactionAmount+"]");

        DynamicValue.put("<ATMFees>", ATMFees.toString());
        LogCapture.info("Card ATM Fees is ["+ATMFees+"]");

        DynamicValue.put("<CrossborderFees>", CrossBorderFee.toString());
        LogCapture.info("Card Cross Border Fee is ["+CrossBorderFee+"]");

        CardBilling_Amount = TransactionAmount+ATMFees+CrossBorderFee;
        DynamicValue.put("<Billing_Amount>", CardBilling_Amount.toString());
        LogCapture.info("Card Billing amount is ["+CardBilling_Amount+"]");


        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.ReusablePaymentLifeCycleId = "AUTO-"+CurrentDateyyyymmdd+"-RAFALE"+CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<ReusableUniquePaymentLifeID>", Constants.ReusablePaymentLifeCycleId);
        LogCapture.info("Payment Life Cycle ID  is ["+Constants.ReusablePaymentLifeCycleId+"]");


    }

    @Then("^User connect to Titan UAT DB and verify transaction amount \"([^\"]*)\" is reflecting at Total Amount column under DOF table$")
    public void userConnectToTitanUATDBAndVerifyTransactionAmountIsReflectingAtTotalAmountColumnUnderDOFTable(String ExpectedTotalAmount) throws Throwable {
        String ActualTotalAmount = Constants.key.VerifyDBDetails("UAT_Titan", ReusablePaymentLifeCycleId, "VerifyTotalAmountUnderDOF");
        if(ExpectedTotalAmount.equals(ActualTotalAmount))
        {
            LogCapture.info("User verified Total amount under DOF table excluding Fee is >> "+ActualTotalAmount);
        }else
        {
            LogCapture.info("TC Failed : User unable to verified Total amount under DOF table is >> "+ActualTotalAmount);
            Assert.fail();
        }
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Debited Currency \"([^\"]*)\" and Debited amount \"([^\"]*)\" for DOF$")
    public void userValidateThenVerifyAmountDebitedCurrencyAndDebitedAmountForDOF(String ResponseCode, String ResponseDescription, String CCY, String Amount) throws Throwable {
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified amount Debited Currency as >> "+jp.get("amountDebited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String DebitedAmt =def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitedAmt,Amount));
        LogCapture.info("-------------User verified amount Debited as >> "+jp.get("amountDebited.amount"));

        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify amount Credited Currency \"([^\"]*)\" and Credited amount \"([^\"]*)\" for DOF$")
    public void userValidateThenVerifyAmountCreditedCurrencyAndCreditedAmountForDOF(String ResponseCode, String ResponseDescription, String CCY, String Amount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("amountCredited.currency")));
        LogCapture.info("-------------User verified amount Credited Currency as >> "+jp.get("amountCredited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String CreditedAmt =def.format(jp.get("amountCredited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(CreditedAmt,Amount));
        LogCapture.info("-------------User verified amount Credited as >> "+jp.get("amountCredited.amount"));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");


    }


    @Then("^User connect to Titan Database and verify transaction amount \"([^\"]*)\" is reflecting at Total Amount column under DOF table for environment \"([^\"]*)\"$")
    public void userConnectToTitanDatabaseAndVerifyTransactionAmountIsReflectingAtTotalAmountColumnUnderDOFTableForEnvironment(String ExpectedTotalAmount, String DBEnvironment) throws Throwable {
        String ActualTotalAmount = Constants.key.VerifyDBDetails(DBEnvironment, ReusablePaymentLifeCycleId, "VerifyTotalAmountUnderDOF");
        if(ExpectedTotalAmount.equals(ActualTotalAmount))
        {
            LogCapture.info("User verified Total amount under DOF table excluding Fee is >> "+ActualTotalAmount);
        }else
        {
            LogCapture.info("TC Failed : User unable to verified Total amount under DOF table is >> "+ActualTotalAmount);
            Assert.fail();
        }
    }

    @When("^User select Transaction Currency as \"([^\"]*)\" Transaction amount \"([^\"]*)\" and Reusable PaymentLifeCycle ID$")
    public void userSelectTransactionCurrencyAsTransactionAmountAndReusablePaymentLifeCycleID(String TransactionCurrency, String TransactionAmount) throws Throwable {
        DynamicValue.put("<Rev_Currency>", TransactionCurrency);
        LogCapture.info("-------------Transaction Currency is ["+TransactionCurrency+"]");
        DynamicValue.put("<RevCCY_Amount>", TransactionAmount);
        LogCapture.info("-------------Transaction amount is ["+TransactionAmount+"]");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.ReusablePaymentLifeCycleId = "AUTO-"+CurrentDateyyyymmdd+"-RAFALE"+CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<ReusableUniquePaymentLifeID>", Constants.ReusablePaymentLifeCycleId);
        LogCapture.info("-------------Generated Payment Life Cycle ID for reusable is ["+Constants.ReusablePaymentLifeCycleId+"]");
    }

    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\" for Check And Block$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmountForCheckAndBlock(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ReversalCurrency,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,ReversalAmount));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User search for Instruction number using Reusable PaymentLifeCycleId to get the Instruction Number$")
    public void userSearchForInstructionNumberUsingReusablePaymentLifeCycleIdToGetTheInstructionNumber() throws Exception {
        String vObjInstructionNumberSearch = Constants.TitanInstructionsOR.getProperty("InstructionNumberSearch");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberSearch, ""));
        Assert.assertEquals("PASS", Constants.key.writeInInput(vObjInstructionNumberSearch, ReusablePaymentLifeCycleId));

        Constants.key.pause("1", "");
        Assert.assertEquals("PASS", Constants.key.KeyboardAction(vObjInstructionNumberSearch, "enter"));
        LogCapture.info("User Searching PaymentLifeCycleID: " + Constants.ReusablePaymentLifeCycleId);
        Constants.key.pause("4","");

        String vObjCloseFilterInstPage = CreateFxTicketOR.getProperty("CloseFilterInstPage");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjCloseFilterInstPage, ""));
        Assert.assertEquals("PASS", Constants.key.navigateSubMenu(vObjCloseFilterInstPage, ""));

        String vObjPaymentLifeCycleIdHeader = Constants.CreateFxTicketOR.getProperty("PaymentLifeCycleIdHeader");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjPaymentLifeCycleIdHeader, ""));
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentLifeCycleIdHeader, ""));
        String ActualPaymentLifeId = Constants.driver.findElement(By.xpath(vObjPaymentLifeCycleIdHeader)).getText();
        LogCapture.info("Captured Payment life cycle id : " + ActualPaymentLifeId);

        String vObjInstructionNumberHeader = Constants.CreateFxTicketOR.getProperty("InstructionNumberHeader");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjInstructionNumberHeader, ""));
        Constants.InstructionNumber = Constants.driver.findElement(By.xpath(vObjInstructionNumberHeader)).getText();
        LogCapture.info("Captured Instruction Number is: " + Constants.InstructionNumber);

        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionNumberHeader, ""));
        LogCapture.info("User clicked on Instruction number on instruction page .....");

        String vObjAmountHeaderOnInstructionPage = Constants.CreateFxTicketOR.getProperty("AmountHeaderOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountHeaderOnInstructionPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjAmountHeaderOnInstructionPage, "Amount"));

        String vObjAmountOnInstructionPage = Constants.CreateFxTicketOR.getProperty("AmountOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjAmountOnInstructionPage, ""));
        String ActualAmountOnInstructionPage = Constants.driver.findElement(By.xpath(vObjAmountOnInstructionPage)).getText();

        if(!ActualAmountOnInstructionPage.equals(""))
        {
            LogCapture.info("Able to see Actual Amount on Instruction page: " + ActualAmountOnInstructionPage);

        }else {
            LogCapture.info("TC Failed : Unable to see Actual Amount on Instruction Number.......");
            Assert.fail();
        }


        String vObjCurrencyHeaderOnInstructionPage = Constants.CreateFxTicketOR.getProperty("CurrencyHeaderOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyHeaderOnInstructionPage, ""));
        Assert.assertEquals("PASS", Constants.key.verifyText(vObjCurrencyHeaderOnInstructionPage, "Currency"));

        String vObjCurrencyOnInstructionPage = Constants.CreateFxTicketOR.getProperty("CurrencyOnInstructionPage");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCurrencyOnInstructionPage, ""));
        String ActualCurrencyOnInstruction = Constants.driver.findElement(By.xpath(vObjCurrencyOnInstructionPage)).getText();

        if(!ActualCurrencyOnInstruction.equals(""))
        {
            LogCapture.info("Able to see Actual Currency on Instruction page: " + ActualCurrencyOnInstruction);

        }else {
            LogCapture.info("TC Failed : Unable to see Actual Currency on Instruction Number.......");
            Assert.fail();
        }


        Constants.key.pause("1", "");
        String vObjInstructionPageClientNumber = Constants.CreateFxTicketOR.getProperty("InstructionPageClientNumber");
        Assert.assertEquals("PASS", Constants.key.click(vObjInstructionPageClientNumber, ""));
        LogCapture.info("User clicked on client number on instruction page .....");

    }

    @Then("^User verify Notification (Send|Not Send) to bank visible under FX activity tab for (CheckAndBlock|Block|Debit)$")
    public void userVerifyNotificationSendToBankVisibleUnderFXActivityTabForCheckAndBlock(String Flag, String TxnType) throws Exception {
        String NotificationFlag = "";
        if(Flag.equalsIgnoreCase("Send"))
        {
            NotificationFlag="YES";
        }else if(Flag.equalsIgnoreCase("Not Send"))
        {
            NotificationFlag="-";
        }
        String vObjFXActivityTab = Constants.TitanCustomersOR.getProperty("FXActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjFXActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjFXActivityTab, ""));
        LogCapture.info("User clicked on FX activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for(int i =1; i<=50; i++)
        {
            String vBojFXReference = "//tbody[@id='profileFxTicketBody']//tr["+i+"]//td[3]//a";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojFXReference, ""));
            String FXReference = Constants.driver.findElement(By.xpath(vBojFXReference)).getText();
            LogCapture.info("Expected Instruction Number is >> "+InstructionNumber);
            LogCapture.info("Actual   Instruction Number is >> "+FXReference);
            if(FXReference.equals(Constants.InstructionNumber))
            {
                LogCapture.info("Able to find Instruction Number as "+FXReference+"for Payment life Cycle Id"+Constants.ReusablePaymentLifeCycleId+" under FX activity tab.......");

                String vBojNotificationSentToBank = "//tbody[@id='profileFxTicketBody']//tr["+i+"]//td[4]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojNotificationSentToBank, ""));
                String NotificationSentToBank = Constants.driver.findElement(By.xpath(vBojNotificationSentToBank)).getText();

                if(NotificationSentToBank.equals(NotificationFlag))
                {
                    LogCapture.info("User verify Notification "+Flag+" To Bank = ["+NotificationSentToBank+"] .....");
                }else {
                    LogCapture.info("TC Failed : User verify Notification "+Flag+" To Bank [="+NotificationSentToBank+"] .....");
                    Assert.fail();
                }
                break;

            }else {
                LogCapture.info("Checking for PaymentlifeCycleId in Next row under FX activity tab.......");
            }
        }

    }


    @Then("^User verify Notification Not Sent to bank for InterCompany EOne on Titan database \"([^\"]*)\"$")
    public void userVerifyNotificationNotSentToBankForInterCompanyEOneOnTitanDatabase(String Environment) throws Throwable {
        Constants.key.pause("120", "");
        String CustomerInstructionIDE1 = Constants.key.VerifyDBDetails(Environment, ReusablePaymentLifeCycleId, "ToGetCustomerInstructionID");
        String ActualStatusNotifyToBankE1 = Constants.key.VerifyDBDetails(Environment, CustomerInstructionIDE1, "CheckNotifyToBankE1");
        if(ActualStatusNotifyToBankE1.equalsIgnoreCase("")||ActualStatusNotifyToBankE1.equalsIgnoreCase("null"))
        {
            LogCapture.info("User verified Notification not sent to bank for E1 type Inter Company >> "+ActualStatusNotifyToBankE1);
        }else
        {
            LogCapture.info("TC Failed : User verified Notification sent to bank for E1 type Inter Company >> "+ActualStatusNotifyToBankE1);
            Assert.fail();
        }

    }

    @Then("^User verify Notification Not Sent to bank for InterCompany ETwo on Titan database \"([^\"]*)\"$")
    public void userVerifyNotificationNotSentToBankForInterCompanyETwoOnTitanDatabase(String Environment) throws Throwable {

        String CustomerInstructionID = Constants.key.VerifyDBDetails(Environment, ReusablePaymentLifeCycleId, "ToGetCustomerInstructionID");
        String ActualStatusNotifyToBank = Constants.key.VerifyDBDetails(Environment, CustomerInstructionID, "CheckNotifyToBankE2");
        if(ActualStatusNotifyToBank.equalsIgnoreCase("0")||ActualStatusNotifyToBank.equalsIgnoreCase("1"))
        {
            LogCapture.info("User verified Notification not sent to bank for E2 type Inter Company >> "+ActualStatusNotifyToBank);
        }else
        {
            LogCapture.info("TC Failed : User unable to verify Notification sent to bank for E2 type Inter Company >> "+ActualStatusNotifyToBank);
            Assert.fail();
        }
    }


    @Then("^User verify Notification send to bank as \"([^\"]*)\" for ETwo InterCompany under Deal report page for \"([^\"]*)\"$")
    public void userVerifyNotificationSendToBankAsForETwoInterCompanyUnderDealReportPageFor(String Flag, String Environment) throws Throwable {
        String CustomerInstructionID = Constants.key.VerifyDBDetails(Environment, ReusablePaymentLifeCycleId, "ToGetCustomerInstructionID");
        String ActualExternalReferenceID = Constants.key.VerifyDBDetails(Environment, CustomerInstructionID, "GetExternalReferenceID");

        for(int i=1; i <=50; i++)
        {
            String vObjExternalReferenceID = "//tbody[@id='treasuryTicketTableBodyForDeal']//tr["+i+"]//td[3]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjExternalReferenceID, ""));
            String ExternalReferenceID = Constants.driver.findElement(By.xpath(vObjExternalReferenceID)).getText();
            if(ExternalReferenceID.equals(ActualExternalReferenceID))
            {
                LogCapture.info("User verified External Reference ID for E2 type Inter Company >> "+ExternalReferenceID);
                String vObjNotificationsSentToBank = "//tbody[@id='treasuryTicketTableBodyForDeal']//tr["+i+"]//td[5]";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjNotificationsSentToBank, ""));
                String NotificationsSentToBank = Constants.driver.findElement(By.xpath(vObjNotificationsSentToBank)).getText();
                if(NotificationsSentToBank.equalsIgnoreCase(Flag))
                {
                    LogCapture.info("User verified Notification sent to bank for E2 type Inter Company as on Titan>> "+NotificationsSentToBank);
                    break;
                }else
                {
                    LogCapture.info("TC Failed : User unable to verify Notification sent to bank for E2 type Inter Company as Yes on Titan >> "+ExternalReferenceID);
                    Assert.fail();
                }
            }else
            {
                LogCapture.info("TC Failed : User unable to verify External Reference ID for E2 type Inter Company >> "+ExternalReferenceID);
                Assert.fail();
            }
        }
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify Unblocked amount Currency \"([^\"]*)\" Unblocked amount \"([^\"]*)\" and Debited amount \"([^\"]*)\" for UnblockAndDebit$")
    public void userValidateThenVerifyUnblockedAmountCurrencyUnblockedAmountAndDebitedAmountForUnblockAndDebit(String ResponseCode, String ResponseDescription, String TxnCCY, String BillAmount, String DebitedAmount) throws Throwable {

        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(TxnCCY,jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified UnblockedAmount Currency as >> "+jp.get("unblockedAmount.amount"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,BillAmount));
        LogCapture.info("-------------User verified Unblocked amount as >> "+jp.get("unblockedAmount.amount"));

        String DebitedAmt =def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitedAmt,DebitedAmount));
        LogCapture.info("-------------User verified Debited amount as >> "+jp.get("amountDebited.amount"));

        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User verify Amount \"([^\"]*)\" Transaction CCY \"([^\"]*)\" ATM Fee \"([^\"]*)\" and Crossborder Fee \"([^\"]*)\" under payment Out activity tab for UnblockAndDebit$")
    public void userVerifyAmountTransactionCCYATMFeeAndCrossborderFeeUnderPaymentOutActivityTabForUnblockAndDebit(String BillingAmount, String TransactionCurrency, String ActualATMFeesAmount, String ActualCrossborderFeeAmount) throws Throwable {

        String vObjPaymentOutActivityTab = Constants.TitanCustomersOR.getProperty("PaymentOutActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentOutActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutActivityTab, ""));
        LogCapture.info("User clicked on payment Out activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for(int i =1; i<=50; i++)
        {
            String vBojPaymentOutReference = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[4]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutReference, ""));
            String PaymentOutReference = Constants.driver.findElement(By.xpath(vBojPaymentOutReference)).getText();
            if(PaymentOutReference.equals(Constants.ReusablePaymentLifeCycleId))
            {
                LogCapture.info("Able to find PaymentlifeCycleId as "+PaymentOutReference+" on payment out activity tab.......");

                String vBojPaymentOutAmount = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[9]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutAmount, ""));
                String PaymentOutAmount = Constants.driver.findElement(By.xpath(vBojPaymentOutAmount)).getText();
                if(PaymentOutAmount.equals(CardAmountToBlock))
                {
                    LogCapture.info("User verify Transaction Amount = ["+PaymentOutAmount+"] is visible on payment out tab.....");
                }else {
                    LogCapture.info("TC Failed : User verify Transaction Amount = ["+PaymentOutAmount+"] and Expected ["+CardAmountToBlock+"] is not matching on payment out tab.....");
                    Assert.fail();
                }


                String vBojPaymentOutCCY = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[10]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCCY, ""));
                String PaymentOutCCY = Constants.driver.findElement(By.xpath(vBojPaymentOutCCY)).getText();
                if(PaymentOutCCY.equals(CardAmountToBlockCurrency))
                {
                    LogCapture.info("User verify Transaction Currency = ["+PaymentOutCCY+"] is visible under payment out activity tab.....");
                }else {
                    LogCapture.info("TC Failed : User verify Actual Transaction Currency = ["+PaymentOutCCY+"] and Expected ["+CardAmountToBlockCurrency+"] is not matching on payment out tab.....");
                    Assert.fail();
                }

                String vBojPaymentOutCardFees = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[16]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCardFees, ""));
                String PaymentOutCardFees = Constants.driver.findElement(By.xpath(vBojPaymentOutCardFees)).getText();

                String ATM_Fees = PaymentOutCardFees.substring(0,12);
                String ExpATMFee = "ATM-"+CardATMFees+"-"+CardFeeCurrency;
                if(ATM_Fees.equals(ExpATMFee))
                {
                    LogCapture.info("User verify ATM Fee = ["+ATM_Fees+"] is visible on payment out tab.....");
                }else {
                    LogCapture.info("TC Failed : User Unable to verify Actual = ["+ATM_Fees+"] and Expected ["+ExpATMFee+"] on payment out tab.....");
                    Assert.fail();
                }

                String Crossborder_Fees = PaymentOutCardFees.substring(14,26);
                String ExpCBFee = "CBF-"+CardCrossBorderFee.substring(0,4)+"-"+CardFeeCurrency;

                if(!CardCrossBorderFee.equals(""))
                {
                    if(Crossborder_Fees.equals(ExpCBFee))
                    {
                        LogCapture.info("User verify Cross border Fee = ["+Crossborder_Fees+"] is visible on payment out tab.....");
                    }else {
                        LogCapture.info("TC Failed : User Unable to verify Actual = ["+Crossborder_Fees+"] and Expected ["+ExpCBFee+"] on payment out tab.....");
                        Assert.fail();
                    }
                }

                break;

            }if(i==40)
            {
                LogCapture.info("TC Failed : Unable to find Payment life Cycle Id under payment out activity tab.......");
                Assert.fail();
            }
        }



    }

    @Then("^User verify Amount without Fees \"([^\"]*)\" Transaction CCY \"([^\"]*)\" under payment in tab On TPL Account for Todays transaction$")
    public void userVerifyAmountWithoutFeesTransactionCCYUnderPaymentInTabOnTPLAccountForTodaysTransaction(String TransactionAmount, String TransactionCurrency) throws Throwable {

        for (int i = 1; i <= 50; i++) {
            String VObjPaymentInAmount = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInAmount, ""));
            String PaymentInAmount = Constants.driver.findElement(By.xpath(VObjPaymentInAmount)).getText();
            LogCapture.info("User verify Amount as ["+PaymentInAmount+"] under payment in activity tab on TPL account");

            String VObjPaymentInCCY = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[6]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInCCY, ""));
            String PaymentInCCY = Constants.driver.findElement(By.xpath(VObjPaymentInCCY)).getText();
            LogCapture.info("User verify Currency as ["+PaymentInCCY+"] under payment in activity tab on TPL account");

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String TodaysDate = dtf1.format(now);

            String VObjPaymentInDate = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[1]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInDate, ""));
            String PaymentInDatewithTime = Constants.driver.findElement(By.xpath(VObjPaymentInDate)).getText();
            String PaymentInDate = PaymentInDatewithTime.trim().substring(0,10);
            LogCapture.info("User verify Today's date as ["+PaymentInDate+"] under payment in activity tab on TPL account");

            if (PaymentInAmount.equals(TransactionAmount) && PaymentInCCY.equals(TransactionCurrency) && PaymentInDate.equals(TodaysDate)) {

                LogCapture.info("User verify Opposite Entry with amount as ["+PaymentInAmount+"] and CCY as ["+PaymentInCCY+"]under payment in activity tab on TPL account for Todays date "+PaymentInDate);
                break;
            }else
            if(i==49)
            {
                LogCapture.info("User unable to verify Opposite Entry with amount as ["+PaymentInAmount+"] and CCY as ["+PaymentInCCY+"]under payment in activity tab on TPL account"+i);
                Assert.fail();
            }
        }

    }


    @Then("^User verify Amount without Fees \"([^\"]*)\" Transaction CCY \"([^\"]*)\" under PaymentIn tab On (Client|TPL) Account for Credit transaction$")
    public void userVerifyAmountWithoutFeesTransactionCCYUnderPaymentInTabOnClientAccountForCreditTransaction(String TransactionAmt, String TransactionCurrency, String TxnType) throws Throwable {

        String TransactionAmount="";
        if(TxnType.equals("TPL"))
        {TransactionAmount = "-"+TransactionAmt;}
        else
        {TransactionAmount=TransactionAmt;}

        for (int i = 1; i <= 50; i++) {
            String VObjPaymentInAmount = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInAmount, ""));
            String PaymentInAmount = Constants.driver.findElement(By.xpath(VObjPaymentInAmount)).getText();
            LogCapture.info("User verify Amount as ["+PaymentInAmount+"] under payment in activity tab on TPL account");

            String VObjPaymentInCCY = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[6]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInCCY, ""));
            String PaymentInCCY = Constants.driver.findElement(By.xpath(VObjPaymentInCCY)).getText();
            LogCapture.info("User verify Currency as ["+PaymentInCCY+"] under payment in activity tab on TPL account");

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String TodaysDate = dtf1.format(now);

            String VObjPaymentInDate = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[1]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInDate, ""));
            String PaymentInDatewithTime = Constants.driver.findElement(By.xpath(VObjPaymentInDate)).getText();
            String PaymentInDate = PaymentInDatewithTime.trim().substring(0,10);
            LogCapture.info("User verify Today's date as ["+PaymentInDate+"] under payment in activity tab on TPL account");

            if (PaymentInAmount.equals(TransactionAmount) && PaymentInCCY.equals(TransactionCurrency) && PaymentInDate.equals(TodaysDate)) {

                LogCapture.info("User verify Opposite Entry [Debit] with amount as ["+PaymentInAmount+"] and CCY as ["+PaymentInCCY+"]under payment in activity tab on TPL account for Todays date "+PaymentInDate);
                break;
            }else
            if(i==49)
            {
                LogCapture.info("TC Failed : User unable to verify Opposite Entry with amount as ["+PaymentInAmount+"] and CCY as ["+PaymentInCCY+"]under payment in activity tab on TPL account"+i);
                Assert.fail();
            }
        }
    }


    @Then("^Users Validate \"([^\"]*)\" \"([^\"]*)\" then verify debit amount currency \"([^\"]*)\" and debit amount \"([^\"]*)\"$")
    public void usersValidateThenVerifyDebitAmountCurrencyAndDebitAmount(String ResponseCode, String ResponseDescription, String DebitCCY, String DebitAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String Ccy= Constants.OnTheFlyValue.getProperty(DebitCCY);
        String Amount= Constants.OnTheFlyValue.getProperty(DebitAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(Ccy,jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified DebitCurrency Currency as >> "+jp.get("amountDebited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String DebitAmt =def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitAmt,Amount));
        LogCapture.info("-------------User verified Debit amount as >> "+jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(Ccy,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^Users Validate \"([^\"]*)\" \"([^\"]*)\" then verify CheckandBlock amount currency \"([^\"]*)\" and CheckandBlock amount \"([^\"]*)\"$")
    public void usersValidateThenVerifyCheckandBlockAmountCurrencyAndCheckandBlockAmount(String ResponseCode, String ResponseDescription, String CkAndBlock_CCY, String CkAndBlock_Amount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String Ccy= Constants.OnTheFlyValue.getProperty(CkAndBlock_CCY);
        String Amount= Constants.OnTheFlyValue.getProperty(CkAndBlock_Amount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(Ccy,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified CheckandBlock Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String CheckandBlockAmt =def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(CheckandBlockAmt,Amount));
        LogCapture.info("-------------User verified CheckandBlock amount as >> "+jp.get("blockedAmount.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(Ccy,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify credit amount Currency \"([^\"]*)\" and credit amount \"([^\"]*)\"$")
    public void userValidateThenVerifyCreditAmountCurrencyAndCreditAmount(String ResponseCode, String ResponseDescription, String CreditCCy, String CreditAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        String CCY= Constants.OnTheFlyValue.getProperty(CreditCCy);
        String Amount= Constants.OnTheFlyValue.getProperty(CreditAmount);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("amountCredited.currency")));
        LogCapture.info("-------------User verified CreditAmount Currency as >> "+jp.get("amountCredited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String CreditAmt =def.format(jp.get("amountCredited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(CreditAmt,Amount));
        LogCapture.info("-------------User verified Credit amount as >> "+jp.get("amountCredited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CCY,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");

    }

    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\" and FX Details for Check and Block$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmountAndFXDetailsForCheckAndBlock(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ReversalCurrency,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,ReversalAmount));

        String SellCCY = jp.get("segregatedBlockedAmount[0].fxDetails.sellCurrency");
        if(!SellCCY.equals(""))
        {
            LogCapture.info("-------------User verified sell currency as >> "+SellCCY);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify sell currency as >> "+SellCCY);
            Assert.fail();
        }

        String SellAmount = jp.get("segregatedBlockedAmount[0].fxDetails.sellAmount").toString();
        if(!SellAmount.equals(""))
        {
            LogCapture.info("-------------User verified sell Amount as >> "+SellAmount);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify sell amount as >> "+SellAmount);
            Assert.fail();
        }

        String BuyCCY = jp.get("segregatedBlockedAmount[0].fxDetails.buyCurrency");
        if(!BuyCCY.equals(""))
        {
            LogCapture.info("-------------User verified Buying currency as >> "+BuyCCY);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify Buying currency as >> "+BuyCCY);
            Assert.fail();
        }

        String BuyAmount = jp.get("segregatedBlockedAmount[0].fxDetails.buyAmount").toString();
        if(!BuyAmount.equals(""))
        {
            LogCapture.info("-------------User verified Buying amount as >> "+BuyAmount);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify buying amount as >> "+BuyAmount);
            Assert.fail();
        }

        String PricePlanId = jp.get("segregatedBlockedAmount[0].fxDetails.pricePlanId").toString();
        if(!PricePlanId.equals(""))
        {
            LogCapture.info("-------------User verified price plan ID as >> "+PricePlanId);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify price plan ID as >> "+PricePlanId);
            Assert.fail();
        }

        String ClientRate = jp.get("segregatedBlockedAmount[0].fxDetails.clientRate").toString();
        if(!ClientRate.equals(""))
        {
            LogCapture.info("-------------User verified client rate as >> "+ClientRate);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify client rate as >> "+ClientRate);
            Assert.fail();
        }

        LogCapture.info("----------------USER VERIFIED FX DETAILS UNDER CHECK & BLOCK API RESPONSE-------------------");

        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify blocked amount Currency \"([^\"]*)\" and blocked amount \"([^\"]*)\" and FX Details for Block$")
    public void userValidateThenVerifyBlockedAmountCurrencyAndBlockedAmountAndFXDetailsForBlock(String ResponseCode, String ResponseDescription, String ReversalCurrency, String ReversalAmount) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ReversalCurrency,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,ReversalAmount));

        String SellCCY = jp.get("segregatedBlockedAmount[0].fxDetails.sellCurrency");
        if(!SellCCY.equals(""))
        {
            LogCapture.info("-------------User verified sell currency as >> "+SellCCY);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify sell currency as >> "+SellCCY);
            Assert.fail();
        }

        String SellAmount = jp.get("segregatedBlockedAmount[0].fxDetails.sellAmount").toString();
        if(!SellAmount.equals(""))
        {
            LogCapture.info("-------------User verified sell Amount as >> "+SellAmount);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify sell amount as >> "+SellAmount);
            Assert.fail();
        }

        String BuyCCY = jp.get("segregatedBlockedAmount[0].fxDetails.buyCurrency");
        if(!BuyCCY.equals(""))
        {
            LogCapture.info("-------------User verified Buying currency as >> "+BuyCCY);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify Buying currency as >> "+BuyCCY);
            Assert.fail();
        }

        String BuyAmount = jp.get("segregatedBlockedAmount[0].fxDetails.buyAmount").toString();
        if(!BuyAmount.equals(""))
        {
            LogCapture.info("-------------User verified Buying amount as >> "+BuyAmount);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify buying amount as >> "+BuyAmount);
            Assert.fail();
        }

        String PricePlanId = jp.get("segregatedBlockedAmount[0].fxDetails.pricePlanId").toString();
        if(!PricePlanId.equals(""))
        {
            LogCapture.info("-------------User verified price plan ID as >> "+PricePlanId);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify price plan ID as >> "+PricePlanId);
            Assert.fail();
        }

        String ClientRate = jp.get("segregatedBlockedAmount[0].fxDetails.clientRate").toString();
        if(!ClientRate.equals(""))
        {
            LogCapture.info("-------------User verified client rate as >> "+ClientRate);
        }else
        {
            LogCapture.info("-------------TC Failed : User unable to verify client rate as >> "+ClientRate);
            Assert.fail();
        }
        LogCapture.info("----------------USER VERIFIED FX DETAILS UNDER BLOCK API RESPONSE-------------------");

        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }


    @Then("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Titan to calculate settlement amount in EUR$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForTitanToCalculateSettlementAmountInEUR(String methodType, String statCode, String testCaseID, String enviroment) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME=enviroment;
        JsonPath jp= JsonPath.given("");
        if (methodType.equalsIgnoreCase("Post")) {
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        }
        CardSettelmentAmount = jp.get("quoted_price").toString();
        DecimalFormat def=new DecimalFormat("0.00");
        CardSettelmentAmount = def.format(Float.parseFloat(CardSettelmentAmount));
        if(CardTransactionCurrency.equals("GBP")|| CardTransactionCurrency.equals("EUR")||CardTransactionCurrency.equals("USD")||CardTransactionCurrency.equals("AUD"))
        {
            CardSettelmentAmount = def.format(Float.parseFloat(CardTransactionAmount));
            CardSettelmentCurrency=CardTransactionCurrency;
            DynamicValue.put("<SettlementAmount>", CardSettelmentAmount);
            LogCapture.info("Calculated Settlement amount is ["+CardSettelmentAmount+"]......");
            DynamicValue.put("<SettlementCurrency>", CardSettelmentCurrency);
            LogCapture.info("Settlement Currency is ["+CardSettelmentCurrency+"]......");
        }
        else
        {
            CardSettelmentCurrency="EUR";
            DynamicValue.put("<SettlementAmount>", CardSettelmentAmount);
            LogCapture.info("Calculated Settlement amount is ["+CardSettelmentAmount+"]......");
            DynamicValue.put("<SettlementCurrency>", CardSettelmentCurrency);
            LogCapture.info("Settlement Currency is ["+CardSettelmentCurrency+"]......");
        }
    }

    @Then("^For a \"([^\"]*)\" call user Check Status code As \"([^\"]*)\" for \"([^\"]*)\" on \"([^\"]*)\" Environment for Titan to calculate Billing amount and amount to block for Base Currency \"([^\"]*)\"$")
    public void forACallUserCheckStatusCodeAsForOnEnvironmentForTitanToCalculateBillingAmountAndAmountToBlockForBaseCurrency(String methodType, String statCode, String testCaseID, String enviroment, String BaseCurrencuy) throws Throwable {
        Constants.TCCaseID = testCaseID;
        Constants.SHEET_NAME=enviroment;
        JsonPath jp= JsonPath.given("");
        if (methodType.equalsIgnoreCase("Post")) {
            Constants.RESPONSE = ServiceMethod.postAdvance(testCaseID, statCode, Constants.DynamicValue);
            ReusableMethod.updateProperties();
            jp = Constants.APIkey.rawToJson(Constants.RESPONSE);
        }

        LogCapture.info("Calculated Settlement amount is ["+CardSettelmentAmount+"]......");
        LogCapture.info("Settlement Currency is ["+CardSettelmentCurrency+"]......");

        CardBillingAmount = jp.get("quoted_price").toString();

        if(CardTransactionCurrency.equals("GBP")|| CardTransactionCurrency.equals("EUR")||CardTransactionCurrency.equals("USD")||CardTransactionCurrency.equals("AUD")||CardTransactionCurrency.equals("AED")
                ||CardTransactionCurrency.equals("ZAR")||CardTransactionCurrency.equals("CAD")||CardTransactionCurrency.equals("CHF")||CardTransactionCurrency.equals("CZK")||CardTransactionCurrency.equals("DKK")||CardTransactionCurrency.equals("HKD")||CardTransactionCurrency.equals("ILS")||CardTransactionCurrency.equals("INR")
                ||CardTransactionCurrency.equals("JPY")||CardTransactionCurrency.equals("NOK")||CardTransactionCurrency.equals("NZD")||CardTransactionCurrency.equals("PLN")||CardTransactionCurrency.equals("SAR")||CardTransactionCurrency.equals("SEK")||CardTransactionCurrency.equals("SGD")||CardTransactionCurrency.equals("THB"))
        {
            LogCapture.info("Card Transaction amount is ["+CardTransactionAmount+"]......");
            LogCapture.info("Card Transaction Currency is ["+CardTransactionCurrency+"]......");

            DecimalFormat def=new DecimalFormat("0.00");
            CardBillingAmount = def.format(Float.parseFloat(CardTransactionAmount));
            DynamicValue.put("<BillingAmount>", CardBillingAmount);
            LogCapture.info("Card Billing amount is ["+CardBillingAmount+"]......");
            CardBillingCurrency=CardTransactionCurrency;
            DynamicValue.put("<BillingCurrency>", CardBillingCurrency);
            LogCapture.info("Card Billing Currency is ["+CardBillingCurrency+"]......");

            CardAmountToBlock = Float.toString(Float.parseFloat(CardTransactionAmount) + Float.parseFloat(CardATMFees ));
            CardAmountToBlock = def.format(Float.parseFloat(CardAmountToBlock));
            LogCapture.info("Card Amount to block is ["+CardAmountToBlock+"]");
            DynamicValue.put("<AmountToBlock>", CardAmountToBlock);
            CardAmountToBlockCurrency=CardTransactionCurrency;
            DynamicValue.put("<AmountToBlockCurrency>", CardAmountToBlockCurrency);
            LogCapture.info("Card Amount to block currency is ["+CardAmountToBlockCurrency+"]");

            DynamicValue.put("<ATMFees>", CardATMFees);
            LogCapture.info("Card ATM Fees is ["+CardATMFees+"]");
            DynamicValue.put("<CrossborderFees>", "0");
            LogCapture.info("Card Cross Border Fee is ["+0+"]");
            CardCrossBorderFee="";

            CardFeeCurrency=CardTransactionCurrency;
            DynamicValue.put("<CardFeeCurrency>", CardFeeCurrency);
            LogCapture.info("Card Fee Currency is ["+CardFeeCurrency+"]......");
        }
        else
        {
            LogCapture.info("Card Transaction amount is ["+CardTransactionAmount+"]......");
            LogCapture.info("Card Transaction Currency is ["+CardTransactionCurrency+"]......");

            DynamicValue.put("<BillingAmount>", CardBillingAmount);
            LogCapture.info("Card billing amount is ["+CardBillingAmount+"]......");
            CardBillingCurrency=CardBaseCurrency;
            DynamicValue.put("<BillingCurrency>", CardBillingCurrency);
            LogCapture.info("Card billing currency is ["+CardBillingCurrency+"]......");

            float f = (float) (0.02 * Float.parseFloat(CardBillingAmount));
            CardCrossBorderFee = Float.toString(f);

            DynamicValue.put("<ATMFees>", CardATMFees);
            LogCapture.info("Card ATM Fees is ["+CardATMFees+"]");

            DynamicValue.put("<CrossborderFees>", CardCrossBorderFee);
            LogCapture.info("Card Cross Border Fee is ["+CardCrossBorderFee+"]");

            CardFeeCurrency=CardBaseCurrency;
            DynamicValue.put("<CardFeeCurrency>", CardFeeCurrency);
            LogCapture.info("Card Fee Currency is ["+CardFeeCurrency+"]......");

            CardAmountToBlock = Float.toString(Float.parseFloat(CardBillingAmount) + Float.parseFloat(CardATMFees )+ Float.parseFloat(CardCrossBorderFee));
            DecimalFormat def=new DecimalFormat("0.00");
            CardAmountToBlock = def.format(Float.parseFloat(CardAmountToBlock));
            LogCapture.info("Card amount to block is ["+CardAmountToBlock+"]");
            DynamicValue.put("<AmountToBlock>", CardAmountToBlock);
            CardAmountToBlockCurrency=CardBaseCurrency;

            DynamicValue.put("<AmountToBlockCurrency>", CardAmountToBlockCurrency);
            LogCapture.info("Card amount to block currency is ["+CardAmountToBlockCurrency+"]");
        }

    }

    @Given("^User perform Check and Block Transaction for Transaction currency \"([^\"]*)\" Transaction Amount \"([^\"]*)\" Cross border Fee and ATM Fees \"([^\"]*)\" then generate reusable PaymentLifeID for Base Currency \"([^\"]*)\"$")
    public void userPerformCheckAndBlockTransactionForTransactionCurrencyTransactionAmountCrossBorderFeeAndATMFeesThenGenerateReusablePaymentLifeIDForBaseCurrency(String TransactionCurrency, String TransactionAmount, String ATMFees, String BaseCCY) throws Throwable {
        DynamicValue.put("<Transaction_Currency>", TransactionCurrency);
        CardTransactionCurrency=TransactionCurrency;
        CardTransactionAmount=TransactionAmount;
        CardBaseCurrency=BaseCCY;
        CardATMFees=ATMFees;

        DynamicValue.put("<Transaction_Currency>", TransactionCurrency);
        DynamicValue.put("<Transaction_Amount>", TransactionAmount);
        DynamicValue.put("<BaseCCY>", BaseCCY);

        if(BaseCCY.equals("GBP"))
        {
            DynamicValue.put("<LegalEntity>", "CDLGB");
        }else if(BaseCCY.equals("EUR"))
        {
            DynamicValue.put("<LegalEntity>", "CDLEU");
        }

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter Dateyyyymmdd = DateTimeFormatter.ofPattern("yyyyMMdd");
        String CurrentDateyyyymmdd = Dateyyyymmdd.format(now);

        DateTimeFormatter TimeHHMM = DateTimeFormatter.ofPattern("HHMMss");
        String CurrentTimeTimeHHMM = TimeHHMM.format(now);

        Constants.ReusablePaymentLifeCycleId = "AUTO-"+CurrentDateyyyymmdd+"-RAFALE"+CurrentTimeTimeHHMM;
        Constants.DynamicValue.put("<ReusableUniquePaymentLifeID>", Constants.ReusablePaymentLifeCycleId);
        LogCapture.info("Generated reusable Payment Life Cycle ID  is ["+Constants.ReusablePaymentLifeCycleId+"]");

    }


    @And("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify the response for Check  and Block$")
    public void userValidateThenVerifyTheResponseForCheckAndBlock(String ResponseCode, String ResponseDescription) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CardAmountToBlockCurrency,jp.get("blockedAmount.currency")));
        LogCapture.info("-------------User verified blockedAmount Currency as >> "+jp.get("blockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("blockedAmount.amount"));
        CardAmountToBlock = def.format(Float.parseFloat(CardAmountToBlock));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,CardAmountToBlock));
        LogCapture.info("-------------User verified blocked amount as >> "+jp.get("blockedAmount.amount"));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify response for Unblock and Debit$")
    public void userValidateThenVerifyResponseForUnblockAndDebit(String ResponseCode, String ResponseDescription) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CardAmountToBlockCurrency,jp.get("unblockedAmount.currency")));
        LogCapture.info("-------------User verified UnblockedAmount Currency as >> "+jp.get("unblockedAmount.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String BlocekAmt =def.format(jp.get("unblockedAmount.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(BlocekAmt,CardAmountToBlock));
        LogCapture.info("-------------User verified Unblocked amount as >> "+jp.get("unblockedAmount.amount"));

        String DebitedAmt =def.format(jp.get("amountDebited.amount"));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitedAmt,CardAmountToBlock));
        LogCapture.info("-------------User verified Debited amount as >> "+jp.get("amountDebited.amount"));

        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @Then("^User verify Amount Currency ATM Fee and CrossBorder Fee under payment Out activity tab for UnblockAndDebit$")
    public void userVerifyAmountCurrencyATMFeeAndCrossBorderFeeUnderPaymentOutActivityTabForUnblockAndDebit() throws Exception {

        String vObjPaymentOutActivityTab = Constants.TitanCustomersOR.getProperty("PaymentOutActivityTab");
        Assert.assertEquals("PASS", Constants.key.scrollIntoViewElement(vObjPaymentOutActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjPaymentOutActivityTab, ""));
        LogCapture.info("User clicked on payment Out activity tab on Customer details page .....");
        Constants.key.pause("2", "");

        for(int i =1; i<=50; i++)
        {
            String vBojPaymentOutReference = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[4]";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutReference, ""));
            String PaymentOutReference = Constants.driver.findElement(By.xpath(vBojPaymentOutReference)).getText();
            if(PaymentOutReference.equals(Constants.ReusablePaymentLifeCycleId))
            {
                LogCapture.info("Able to find PaymentlifeCycleId as "+PaymentOutReference+" on payment out activity tab.......");

                String vBojPaymentOutAmount = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[9]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutAmount, ""));
                String PaymentOutAmount = Constants.driver.findElement(By.xpath(vBojPaymentOutAmount)).getText();
                if(PaymentOutAmount.equals(CardAmountToBlock))
                {
                    LogCapture.info("User verify Transaction Amount = ["+PaymentOutAmount+"] is visible on payment out tab.....");
                }else {
                    LogCapture.info("TC Failed : User verify Transaction Amount = ["+PaymentOutAmount+"] and Expected ["+CardAmountToBlock+"] is not matching on payment out tab.....");
                    Assert.fail();
                }


                String vBojPaymentOutCCY = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[10]//a";
                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCCY, ""));
                String PaymentOutCCY = Constants.driver.findElement(By.xpath(vBojPaymentOutCCY)).getText();
                if(PaymentOutCCY.equals(CardAmountToBlockCurrency))
                {
                    LogCapture.info("User verify Transaction Currency = ["+PaymentOutCCY+"] is visible under payment out activity tab.....");
                }else {
                    LogCapture.info("TC Failed : User verify Actual Transaction Currency = ["+PaymentOutCCY+"] and Expected ["+CardAmountToBlockCurrency+"] is not matching on payment out tab.....");
                    Assert.fail();
                }

//                String vBojPaymentOutCardFees = "//tbody[@id='profilePaymentOutBody']//tr["+i+"]//td[16]//a";
//                Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vBojPaymentOutCardFees, ""));
//                String PaymentOutCardFees = Constants.driver.findElement(By.xpath(vBojPaymentOutCardFees)).getText();
//
//                String ATM_Fees = PaymentOutCardFees.substring(0,12);
//                String ExpATMFee = "ATM-"+CardATMFees+"-"+CardFeeCurrency;
//                if(ATM_Fees.equals(ExpATMFee))
//                {
//                    LogCapture.info("User verify ATM Fee = ["+ATM_Fees+"] is visible on payment out tab.....");
//                }else {
//                    LogCapture.info("TC Failed : User Unable to verify Actual = ["+ATM_Fees+"] and Expected ["+ExpATMFee+"] on payment out tab.....");
//                    Assert.fail();
//                }
//
//                if(!CardCrossBorderFee.equals(""))
//                {
//                    String Crossborder_Fees = PaymentOutCardFees.substring(14,26);
//                    String ExpCBFee = "CBF-"+CardCrossBorderFee.substring(0,4)+"-"+CardFeeCurrency;
//                    if(Crossborder_Fees.equals(ExpCBFee))
//                    {
//                        LogCapture.info("User verify Cross border Fee = ["+Crossborder_Fees+"] is visible on payment out tab.....");
//                    }else {
//                        LogCapture.info("TC Failed : User Unable to verify Actual = ["+Crossborder_Fees+"] and Expected ["+ExpCBFee+"] on payment out tab.....");
//                        Assert.fail();
//                    }
//                }

                break;

            }if(i==40)
        {
            LogCapture.info("TC Failed : Unable to find Payment life Cycle Id under payment out activity tab.......");
            Assert.fail();
        }
        }




    }

    @Then("^User verify Amount without Fees Transaction currency under payment in tab On TPL Account for Todays transaction$")
    public void userVerifyAmountWithoutFeesTransactionCurrencyUnderPaymentInTabOnTPLAccountForTodaysTransaction() throws Exception {

        for (int i = 1; i <= 50; i++) {
            String VObjPaymentInAmount = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[5]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInAmount, ""));
            String PaymentInAmount = Constants.driver.findElement(By.xpath(VObjPaymentInAmount)).getText();

            String VObjPaymentInCCY = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[6]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInCCY, ""));
            String PaymentInCCY = Constants.driver.findElement(By.xpath(VObjPaymentInCCY)).getText();

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String TodaysDate = dtf1.format(now);

            String VObjPaymentInDate = "//tbody[@id='profilePaymentInBody']//tr["+i+"]//td[1]//a";
            Assert.assertEquals("PASS", key.VisibleConditionWait(VObjPaymentInDate, ""));
            String PaymentInDatewithTime = Constants.driver.findElement(By.xpath(VObjPaymentInDate)).getText();
            String PaymentInDate = PaymentInDatewithTime.trim().substring(0,10);

            if (PaymentInAmount.equals(CardBillingAmount) && PaymentInCCY.equals(CardBillingCurrency) && PaymentInDate.equals(TodaysDate)) {

                LogCapture.info("User verify Opposite Entry with amount as ["+PaymentInAmount+"] and CCY as ["+PaymentInCCY+"]under payment in activity tab on TPL account for Todays date "+PaymentInDate);
                break;
            }else
            if(i==20)
            {
                LogCapture.info("User unable to verify Opposite Entry with amount as ["+PaymentInAmount+"] and CCY as ["+PaymentInCCY+"]under payment in activity tab on TPL account"+i);
                LogCapture.info("User verify Actual Amount as ["+PaymentInAmount+"] under payment in activity tab on TPL account");
                LogCapture.info("User verify Expected Amount as ["+CardBillingAmount+"] under payment in activity tab on TPL account");

                LogCapture.info("User verify Actual Currency as ["+PaymentInCCY+"] under payment in activity tab on TPL account");
                LogCapture.info("User verify Expected Currency as ["+CardBillingCurrency+"] under payment in activity tab on TPL account");

                LogCapture.info("User verify Today's date as ["+PaymentInDate+"] under payment in activity tab on TPL account");
                LogCapture.info("User verify Today's date as ["+TodaysDate+"] under payment in activity tab on TPL account");
                Assert.fail();
            }
        }


    }

    @And("^User able to verify FX created for Additional Supported currency under FX Activity tab on TPL Account$")
    public void userAbleToVerifyFXCreatedForAdditionalSupportedCurrencyUnderFXActivityTabOnTPLAccount() throws Exception {

        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 50; i++) {
            String VObjSellAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[7]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellAmount, ""));
            String ActSellAmount = Constants.driver.findElement(By.xpath(VObjSellAmount)).getText();

            String VObjBuyingAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[8]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingAmount, ""));
            String ActBuyingAmount = Constants.driver.findElement(By.xpath(VObjBuyingAmount)).getText();

            String VObjSellingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[9]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellingCCY, ""));
            String ActSellingCCY = Constants.driver.findElement(By.xpath(VObjSellingCCY)).getText();

            String VObjBuyingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[10]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingCCY, ""));
            String ActBuyingCCY = Constants.driver.findElement(By.xpath(VObjBuyingCCY)).getText();

            if (ActSellAmount.equals(CardBillingAmount) && ActBuyingAmount.equals(CardSettelmentAmount) && ActSellingCCY.equals(CardBillingCurrency) && ActBuyingCCY.equals(CardSettelmentCurrency)) {

                LogCapture.info("User verify FX Created with Selling Amount = ["+ActSellAmount+" "+ActSellingCCY+"] and Buying Amount = ["+ActBuyingAmount+" "+ActBuyingCCY+"]under FX Activity tab on TPL account for Additional Supported Currency.....");
                break;
            }
            else if(i==50)
            {
                LogCapture.info("TC Failed : verified FX not Created with Selling Amount = ["+CardBillingAmount+" "+CardBillingCurrency+"] and Buying Amount = ["+CardSettelmentAmount+" "+CardSettelmentCurrency+"]under FX Activity tab on TPL account for Additional Supported Currency.....");
                LogCapture.info("User verify Actual Sell Amount as ["+ActSellAmount+" "+ActSellingCCY+"] under FX activity tab on TPL account");
                LogCapture.info("User verify Expected Sell Amount as ["+CardBillingAmount+" "+CardBillingCurrency+"] under FX activity tab on TPL account");
                LogCapture.info("User verify Actual Buy Amount as ["+ActBuyingAmount+" "+ActBuyingCCY+"] under FX activity tab on TPL account");
                LogCapture.info("User verify Expected Buy Amount as ["+CardSettelmentAmount+" "+CardSettelmentCurrency+"] under FX activity tab on TPL account");
                Assert.fail();
            }
        }

    }


    @Then("^User Validate \"([^\"]*)\" \"([^\"]*)\" then verify response for Debit$")
    public void userValidateThenVerifyResponseForDebit(String ResponseCode, String ResponseDescription) throws Throwable {
        LogCapture.info("----------------Response Validations Started-------------------");
        JsonPath jp = Constants.APIkey.rawToJson(Constants.RESPONSE);

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseDescription,jp.get("response_description")));
        LogCapture.info("-------------User verified Response Description as >> "+jp.get("response_description"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(ResponseCode,jp.get("response_code")));
        LogCapture.info("-------------User verified Response Code as >> "+jp.get("response_code"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CardAmountToBlockCurrency,jp.get("amountDebited.currency")));
        LogCapture.info("-------------User verified amount Debited Currency as >> "+jp.get("amountDebited.currency"));

        DecimalFormat def=new DecimalFormat("0.00");
        String DebitedAmt =def.format(jp.get("amountDebited.amount"));
        CardAmountToBlock = def.format(Float.parseFloat(CardAmountToBlock));
        Assert.assertEquals("PASS",ReusableMethod.compareString(DebitedAmt, CardAmountToBlock));
        LogCapture.info("-------------User verified amount Debited as >> "+jp.get("amountDebited.amount"));

        Assert.assertEquals("PASS",ReusableMethod.compareString(CardBaseCurrency,jp.get("balance.currency")));
        LogCapture.info("-------------User verified Base Currency as >> "+jp.get("balance.currency"));
        LogCapture.info("-------------Able to see Actual balance >> "+jp.get("balance.actualBalance"));
        LogCapture.info("-------------Able to see Available balance >> "+jp.get("balance.availableBalance"));

        LogCapture.info("----------------Response Validations Ended-------------------");
    }

    @And("^User able to verify FX not created for Supported currency under FX Activity tab on TPL Account$")
    public void userAbleToVerifyFXNotCreatedForSupportedCurrencyUnderFXActivityTabOnTPLAccount() throws Exception {

        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 50; i++) {
            String VObjSellAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[7]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellAmount, ""));
            String ActSellAmount = Constants.driver.findElement(By.xpath(VObjSellAmount)).getText();

            String VObjBuyingAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[8]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingAmount, ""));
            String ActBuyingAmount = Constants.driver.findElement(By.xpath(VObjBuyingAmount)).getText();

            String VObjSellingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[9]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellingCCY, ""));
            String ActSellingCCY = Constants.driver.findElement(By.xpath(VObjSellingCCY)).getText();

            String VObjBuyingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[10]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingCCY, ""));
            String ActBuyingCCY = Constants.driver.findElement(By.xpath(VObjBuyingCCY)).getText();

            if (ActSellAmount.equals(CardBillingAmount) && ActBuyingAmount.equals(CardSettelmentAmount) && ActSellingCCY.equals(CardBillingCurrency) && ActBuyingCCY.equals(CardSettelmentCurrency)) {

                LogCapture.info("TC Failed: User verify FX Created with Selling Amount = ["+ActSellAmount+" "+ActSellingCCY+"] and Buying Amount = ["+ActBuyingAmount+" "+ActBuyingCCY+"]under FX Activity tab on TPL account for Supported Currency.....");

                LogCapture.info("User verify Actual Sell Amount as ["+ActSellAmount+" "+ActSellingCCY+"] under FX activity tab on TPL account");
                LogCapture.info("User verify Expected Sell Amount as ["+CardBillingAmount+" "+CardBillingCurrency+"] under FX activity tab on TPL account");
                LogCapture.info("User verify Actual Buy Amount as ["+ActBuyingAmount+" "+ActBuyingCCY+"] under FX activity tab on TPL account");
                LogCapture.info("User verify Expected Buy Amount as ["+CardSettelmentAmount+" "+CardSettelmentCurrency+"] under FX activity tab on TPL account");
                Assert.fail();
            }
            else if(i==50)
            {
                LogCapture.info("Verified FX not Created for supported currency ["+CardTransactionCurrency+ "] under FX activity tab on TPL account.....");
                break;

            }
        }
    }


    @And("^User able to verify (FX created|FX not created) for Non Supported currency under FX Activity tab on TPL Account for Base Currency \"([^\"]*)\"$")
    public void userAbleToVerifyFXCreatedForNonSupportedCurrencyUnderFXActivityTabOnTPLAccountForBaseCurrency(String FXCreated, String BaseCCY) throws Throwable {

        Assert.assertEquals("PASS", Constants.key.pause("3", ""));
        String vObjCustomerActivityTab = TitanCustomersOR.getProperty("CustomerActivityTab");
        Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.click(vObjCustomerActivityTab, ""));
        Assert.assertEquals("PASS", Constants.key.pause("1", ""));
        LogCapture.info("User Click on FX Activity Tab...");

        for (int i = 1; i <= 50; i++) {
            String VObjSellAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[7]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellAmount, ""));
            String ActSellAmount = Constants.driver.findElement(By.xpath(VObjSellAmount)).getText();

            String VObjBuyingAmount = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[8]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingAmount, ""));
            String ActBuyingAmount = Constants.driver.findElement(By.xpath(VObjBuyingAmount)).getText();

            String VObjSellingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[9]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjSellingCCY, ""));
            String ActSellingCCY = Constants.driver.findElement(By.xpath(VObjSellingCCY)).getText();

            String VObjBuyingCCY = "(//tbody[@id='profileFxTicketBody']//tr[" + i + "]//td[10]//a)";
            Assert.assertEquals("PASS", Constants.key.VisibleConditionWait(VObjBuyingCCY, ""));
            String ActBuyingCCY = Constants.driver.findElement(By.xpath(VObjBuyingCCY)).getText();

            if(BaseCCY.equals("GBP"))
            {
                if (ActSellAmount.equals(CardBillingAmount) && ActBuyingAmount.equals(CardSettelmentAmount) && ActSellingCCY.equals(CardBillingCurrency) && ActBuyingCCY.equals(CardSettelmentCurrency)) {

                    LogCapture.info("User verify FX Created with Selling Amount = ["+ActSellAmount+" "+ActSellingCCY+"] and Buying Amount = ["+ActBuyingAmount+" "+ActBuyingCCY+"]under FX Activity tab on TPL account for Additional Supported Currency.....");
                    break;
                }
                else if(i==50)
                {
                    LogCapture.info("TC Failed : verified FX not Created with Selling Amount = ["+ActSellAmount+" "+ActSellingCCY+"] and Buying Amount = ["+ActBuyingAmount+" "+ActBuyingCCY+"]under FX Activity tab on TPL account for Additional Supported Currency.....");
                    LogCapture.info("User verify Actual Sell Amount as ["+ActSellAmount+" "+ActSellingCCY+"] under FX activity tab on TPL account");
                    LogCapture.info("User verify Expected Sell Amount as ["+CardBillingAmount+" "+CardBillingCurrency+"] under FX activity tab on TPL account");
                    LogCapture.info("User verify Actual Buy Amount as ["+ActBuyingAmount+" "+ActBuyingCCY+"] under FX activity tab on TPL account");
                    LogCapture.info("User verify Expected Buy Amount as ["+CardSettelmentAmount+" "+CardSettelmentCurrency+"] under FX activity tab on TPL account");
                    Assert.fail();
                }
            }else if(BaseCCY.equals("EUR"))
            {
                if (ActSellAmount.equals(CardBillingAmount) && ActBuyingAmount.equals(CardSettelmentAmount) && ActSellingCCY.equals(CardBillingCurrency) && ActBuyingCCY.equals(CardSettelmentCurrency)) {

                    LogCapture.info("TC Failed: User verify FX Created with Selling Amount = ["+ActSellAmount+" "+ActSellingCCY+"] and Buying Amount = ["+ActBuyingAmount+" "+ActBuyingCCY+"]under FX Activity tab on TPL account for Supported Currency.....");

                    LogCapture.info("User verify Actual Sell Amount as ["+ActSellAmount+" "+ActSellingCCY+"] under FX activity tab on TPL account");
                    LogCapture.info("User verify Expected Sell Amount as ["+CardBillingAmount+" "+CardBillingCurrency+"] under FX activity tab on TPL account");
                    LogCapture.info("User verify Actual Buy Amount as ["+ActBuyingAmount+" "+ActBuyingCCY+"] under FX activity tab on TPL account");
                    LogCapture.info("User verify Expected Buy Amount as ["+CardSettelmentAmount+" "+CardSettelmentCurrency+"] under FX activity tab on TPL account");
                    Assert.fail();
                }
                else if(i==50)
                {
                    LogCapture.info("Verified FX not Created for supported currency ["+CardTransactionCurrency+ "] under FX activity tab on TPL account.....");
                    break;

                }
            }

        }

    }
}





