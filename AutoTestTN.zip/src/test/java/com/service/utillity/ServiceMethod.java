package com.service.utillity;

import com.selenium.utillity.Constants;
import com.utility.LogCapture;
import io.restassured.RestAssured;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static io.restassured.RestAssured.given;
//import jdk.nashorn.internal.runtime.Context;

public class ServiceMethod {

    /*
    Description: This method is a basic GET call. It picks up the header/ Query parameter from excel in piped format.
    Expected Input: String 1-Testcase ID, String 2-Status code for validation
    Expected Output: String: Json response from POST call.
    */
    public static String getAdvance(String testCaseID, String statusCode, HashMap<String, String> ParamBody) {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            ReusableMethod.createReportParameters(testCaseID);
            if (Execution.equalsIgnoreCase("Y")) {

                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");

                if (queryPath != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryPath.contains(entry.getKey())) {
                                queryPath = queryPath.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }

                String url = Constants.APIkey.readExcel(testCaseID, "URL");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().headers(headerMap)
                            .when().get(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().headers(headerMap).queryParams(queryParameterMap)
                            .when().get(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;
        } catch (Exception | AssertionError ex) {
            LogCapture.info("Error occurred during a GET call. The error is: " + ex);
            ex.printStackTrace();
        }
        return "Error occurred during a GET call";
    }

    /*
    Description: This method makes a POST api call dynamically. If any parameter needs to be updated on the run it needs to be passed in as a Map object as one parameter.
    Expected Input: String 1-TestCaseId in excel, String 2-Expected Status Code, Map-The objects that needs to be updated dynamically
    Expected Output: String-Json String response
    */
    public static String postAdvance(String testCaseID, String statusCode, HashMap<String, String> ParamBody) {
        try {
            String response = "";

            Constants.APIkey.getCurrentDateOfFormat();
            Constants.APIkey.CardOrderMappingRandomData();
            Constants.APIkey.GenerateUniquepaymentLifeCycleID();
            Random r = new Random(System.currentTimeMillis() );
            String randomNumber = String.format("%05d", r.nextInt(10001));
            Constants.DynamicValue.put("<dynamic>" ,randomNumber);
            String email=ParamBody.get("<dynamic_email>");
            String str=email.substring(email.lastIndexOf("g")+1,email.lastIndexOf("@"));
            ReusableMethod.updateConfig("<dynamic_email>", ParamBody.get("<dynamic_email>").replace(str,randomNumber));
            ReusableMethod.updateConfig("<dyanamic_date>",ReusableMethod.getDate(1));
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
//                ReusableMethod.createReportParameters(testCaseID);
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                if (body != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (body.contains(entry.getKey())) {
                                body = body.replace(entry.getKey(), entry.getValue());
                                if(entry.getKey().equalsIgnoreCase("<CkAndBlock_PaymentLifeCycleID>")||entry.getKey().equalsIgnoreCase("<CkAndBlock_PaymentLifeCycleID1>")||entry.getKey().equalsIgnoreCase("<DBT_paymentLifeCycleID>")||entry.getKey().equalsIgnoreCase("<Block_PaymentLifeCycleID>")||entry.getKey().equalsIgnoreCase("<PendCRD_PaymentLifeCycleID>")||entry.getKey().equalsIgnoreCase("<CRD_PaymentLifeCycleID>")){
                                    Constants.paymentLifeCycleID=entry.getValue();
                                }
                            }
                        }
                    }
                }
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                if (queryParams != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryParams.contains(entry.getKey())) {
                                queryParams = queryParams.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
                Constants.apiBody=body;
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;


        } catch (Exception | AssertionError e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
            Assert.assertEquals("Expected","Actual");
        }
        return "Error occurred during a POST call";
    }

    /*
    Description: This method makes a DELETE api call dynamically. If any parameter needs to be updated on the run it needs to be passed in as a Map object as one parameter.
    Expected Input: String 1-TestCaseId in excel, String 2-Expected Status Code, Map-The objects that needs to be updated dynamically
    Expected Output: String-Json String response
    */
    public static String deleteAdvance(String testCaseID, String statusCode, HashMap<String, String> ParamBody) throws IOException {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
                ReusableMethod.createReportParameters(testCaseID);
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                if (body != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (body.contains(entry.getKey())) {
                                body = body.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                if (queryPath != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryPath.contains(entry.getKey())) {
                                queryPath = queryPath.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                if (queryParams != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryParams.contains(entry.getKey())) {
                                queryParams = queryParams.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().delete(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().delete(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (IOException | AssertionError e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a POST call";
    }

    /*
    Description: This method makes a PUT api call dynamically. If any parameter needs to be updated on the run it needs to be passed in as a Map object as one parameter.
    Expected Input: String 1-TestCaseId in excel, String 2-Expected Status Code, Map-The objects that needs to be updated dynamically
    Expected Output: String-Json String response
    */
    public static String putAdvance(String testCaseID, String statusCode, HashMap<String, String> ParamBody) throws IOException {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
                ReusableMethod.createReportParameters(testCaseID);
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                if (body != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (body.contains(entry.getKey())) {
                                body = body.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");

                if (queryPath != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryPath.contains(entry.getKey())) {
                                queryPath = queryPath.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }

                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                if (queryParams != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryParams.contains(entry.getKey())) {
                                queryParams = queryParams.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().put(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().put(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (IOException | AssertionError e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a POST call";
    }

    public static String post(String testCaseID, String statusCode) {
        try {
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;

            if (Execution.equalsIgnoreCase("Y")) {
//                ReusableMethod.createReportParameters(testCaseID);
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if(Constants.CONFIG.getProperty("Environment").equalsIgnoreCase("SIT")){
                    RestAssured.baseURI.replace("uat","sit");
                }
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt(statusCode)).extract().asString();
                }
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (Exception | AssertionError e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
        }
        return "Error occurred during a POST call";
    }

    public static String postAdvanceFileUploadToS3Bucket(String testCaseID, String statusCode,HashMap<String, String> ParamBody,String filePath,String destinationPath) {
        try {
            Random r = new Random(System.currentTimeMillis() );
            String randomNumber = String.format("%09d", r.nextInt(100000001));
            Constants.DynamicValue.put("<dynamic>" ,randomNumber);
            String response = "";
            String Execution = Constants.APIkey.readExcel(testCaseID, "Execution");
            Constants.TCCaseID = Execution;
            if (Execution.equalsIgnoreCase("Y")) {
//                ReusableMethod.createReportParameters(testCaseID);
                String HeaderFromExcel = Constants.APIkey.readExcel(testCaseID, "Headers");
                String body = Constants.APIkey.readExcel(testCaseID, "Body");
                if (body != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (body.contains(entry.getKey())) {
                                body = body.replace(entry.getKey(), entry.getValue());

                            }
                        }
                    }
                }
                LogCapture.info(body+" ");
                String queryPath = Constants.APIkey.readExcel(testCaseID, "Query Path");
                String queryParams = Constants.APIkey.readExcel(testCaseID, "Query Parameter");
                if (queryParams != null) {
                    for (int i = 0; i < ParamBody.size(); i++) {
                        for (Map.Entry<String, String> entry : ParamBody.entrySet()) {
                            if (queryParams.contains(entry.getKey())) {
                                queryParams = queryParams.replace(entry.getKey(), entry.getValue());
                            }
                        }
                    }
                }
                Map<String, String> headerMap = Constants.APIkey.getStringStringMap(HeaderFromExcel);
                Map<String, String> queryParameterMap = Constants.APIkey.getStringStringMap(queryParams);
                RestAssured.baseURI = Constants.APIkey.readExcel(testCaseID, "Base URI");
                if (queryParams.equalsIgnoreCase("NA") || queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().
                            headers(headerMap)
                            .contentType("multipart/form-data")
                            .multiPart("file", new File(filePath))
                            .multiPart("destinationPath", destinationPath)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt("200")).extract().asString();

                } else if (!queryParams.equalsIgnoreCase("")) {
                    response = given().relaxedHTTPSValidation().log().all().queryParams(queryParameterMap).
                            headers(headerMap)
                            .body(body)
                            .when().post(queryPath).then().assertThat().statusCode(Integer.parseInt("200")).extract().asString();
                }

                Constants.apiBody=body;
            } else if (Execution.equalsIgnoreCase("N")) {
                response = "The test Case '" + testCaseID + "' is marked as N in datasheet";
                LogCapture.info(response);
            }
            return response;

        } catch (Exception | AssertionError e) {
            LogCapture.info("Error occurred during a POST call. The error is: " + e);
            e.printStackTrace();
            String error = "The error is: "+e;
            Assert.assertFalse(error.contains("200"));

        }
        return "Error occurred during a POST call";
    }


}
